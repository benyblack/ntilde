using System;
using System.Collections.Generic;

namespace Ntilde.VT
{
    public readonly struct RenderSnapshotRequest
    {
        public int ViewportRows { get; init; }
        public int ViewportCols { get; init; }
        public int ScrollOffset { get; init; }
        public SelectionState? Selection { get; init; }
        /// <summary>Interpret selection rows relative to this actual captured viewport; default uses absolute history rows.</summary>
        public bool SelectionRelativeToViewport { get; init; }
        public IReadOnlyList<SearchMatch>? SearchMatches { get; init; }
        public int ActiveSearchIndex { get; init; }

        /// <summary>
        /// True for a capture that is not a frame of the live view: an agent-host screenshot, a
        /// PNG export, a golden render. Such a capture neither reads nor writes the buffer's
        /// row-diff baseline and render-row cache; it builds every row fresh and reports every
        /// renderable row as dirty.
        /// </summary>
        /// <remarks>
        /// The default (false) is the live view's mode. There, <see cref="TerminalRenderSnapshot.DirtySpans"/>
        /// holds the cells that changed since the previous live capture, and the renderer
        /// repaints only those spans over the row picture it drew last time. That contract
        /// breaks if anything else captures in between: the intervening capture advances the
        /// baseline, the next live frame's spans omit every change made before it, and the
        /// renderer keeps painting those cells from its older picture. The baseline belongs to
        /// the live renderer alone, so every other caller must set this.
        /// </remarks>
        public bool Isolated { get; init; }
        /// <summary>An active image-handle session; zero makes this snapshot own its source lease.</summary>
        public int SnapshotSessionId { get; init; }
    }

    /// <summary>A value-only mask: a render consumer cannot mutate the session's palette overrides.</summary>
    public readonly record struct PaletteOverrideMask(ulong First, ulong Second, ulong Third, ulong Fourth)
    {
        public bool Contains(int index)
        {
            if ((uint)index >= 256) return false;
            ulong bits = (index / 64) switch { 0 => First, 1 => Second, 2 => Third, _ => Fourth };
            return (bits & (1UL << (index % 64))) != 0;
        }
    }

    public readonly struct RenderThemeSnapshot
    {
        public TermColor Foreground { get; init; }
        public TermColor Background { get; init; }
        public TermColor CursorColor { get; init; }
        public TermColor[] AnsiPalette { get; init; }
        public bool HasForegroundOverride { get; init; }
        public bool HasBackgroundOverride { get; init; }
        public bool HasCursorOverride { get; init; }
        public bool HasSelectionBackgroundOverride { get; init; }
        public bool HasSelectionForegroundOverride { get; init; }
        public TermColor? SelectionBackground { get; init; }
        public TermColor? SelectionForeground { get; init; }
        public PaletteOverrideMask PaletteOverrides { get; init; }

        /// <summary>
        /// DECSCNM (?5) was set at capture. Informational: <see cref="Foreground"/>,
        /// <see cref="Background"/>, <see cref="CursorColor"/> and <see cref="Source"/> are already the
        /// presented (swapped) colors, so a renderer draws them as given and needs no mode logic.
        /// </summary>
        public bool IsReverseVideo { get; init; }

        /// <summary>
        /// The theme these colors came from, for the colors the renderer derives from a whole theme
        /// (selection, search, cursor text). Null only in snapshots built by hand.
        /// </summary>
        public TerminalTheme? Source { get; init; }
    }

    public readonly struct DirtySpan
    {
        // End-exclusive range: [ColStart, ColEnd)
        public int Row { get; init; }
        public int ColStart { get; init; }
        public int ColEnd { get; init; }
    }

    public readonly struct SelectionRowSnapshot
    {
        public int AbsRow { get; init; }
        public int ColStart { get; init; }
        public int ColEnd { get; init; }
    }

    public readonly struct SearchHighlightSnapshot
    {
        public int AbsRow { get; init; }
        public int StartCol { get; init; }
        public int EndCol { get; init; }
        public bool IsActive { get; init; }
    }

    public readonly struct PooledArray<T> : IDisposable
    {
        public readonly T[] Array;
        public readonly int Length;

        public PooledArray(T[] array, int length)
        {
            Array = array;
            Length = length;
        }

        public void Dispose()
        {
            if (Array != null)
            {
                System.Buffers.ArrayPool<T>.Shared.Return(Array, clearArray: true);
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1000:Do not declare static members on generic types",
            Justification = "Mirrors ImmutableArray<T>.Empty: the empty value belongs on the type it is the empty value of.")]
        public static PooledArray<T> Empty => new();
    }

    public readonly struct TerminalRenderSnapshot : IDisposable
    {
        public int ViewportRows { get; init; }
        public int ViewportCols { get; init; }
        /// <summary>Actual terminal dimensions at snapshot copy, independent of the requested viewport.</summary>
        public int BufferRows { get; init; }
        public int BufferCols { get; init; }
        public int TotalLines { get; init; }
        public int AbsDisplayStart { get; init; }
        public int ScrollOffset { get; init; }
        public int CursorRow { get; init; }
        public int CursorCol { get; init; }
        public CursorStyle CursorStyle { get; init; }
        public bool CursorStyleIsDefault { get; init; }
        public bool CursorVisible { get; init; }
        public bool CursorBlinkEnabled { get; init; }
        public RenderThemeSnapshot Theme { get; init; }
        public PooledArray<DirtySpan> DirtySpans { get; init; }
        public PooledArray<RenderRowSnapshot> RowsData { get; init; }
        public PooledArray<RenderImageSnapshot> Images { get; init; }
        internal IDisposable? ImageSourceLease { get; init; }
        public PooledArray<SelectionRowSnapshot> SelectionRows { get; init; }
        public PooledArray<SearchHighlightSnapshot> SearchHighlights { get; init; }

        public void Dispose()
        {
            DirtySpans.Dispose();
            RowsData.Dispose();
            Images.Dispose();
            ImageSourceLease?.Dispose();
            SelectionRows.Dispose();
            SearchHighlights.Dispose();
        }
    }

    public struct RenderCellSnapshot
    {
        public char Character;
        public string? Text;
        public CellTextSizing? TextSizing { get; init; }
        public TermColor Foreground;
        public TermColor Background;
        public bool IsInverse;
        public bool IsBold;
        public bool IsDefaultForeground;
        public bool IsDefaultBackground;
        public bool IsWide;
        public bool IsWideContinuation;
        public bool IsHidden;
        public bool IsFaint;
        public bool IsItalic;
        public bool IsUnderline;
        /// <summary>The underline's style and color when it is more than a straight line in the text color (#270).</summary>
        public CellUnderline? Underline;
        public bool IsBlink;
        public bool IsStrikethrough;
        public short FgIndex;
        public short BgIndex;
    }

    public struct RenderRowSnapshot
    {
        public int AbsRow;
        public uint Revision;
        public int Cols;
        public RenderCellSnapshot[] Cells;
        public long RowId;
        /// <summary>
        /// The row's VT100 line attribute. A row that is not single shows its first <c>Cols / 2</c> cells, each two
        /// cells wide; a double-height row shows the top or bottom half of glyphs drawn two rows tall.
        /// </summary>
        public LineSize LineSize;
        /// <summary>
        /// The page's width when the row was captured. <see cref="Cols"/> is the width the viewer asked for, which
        /// differs while a resize is in flight; a double-size row's half is measured against the page.
        /// </summary>
        public int BufferCols;
        /// <summary>At least one unhidden SGR 5 cell in this immutable row projection.</summary>
        public bool ContainsBlink { get; set; }
    }

    public struct RenderImageSnapshot
    {
        public Guid PlacementId { get; init; }
        public SixelPlacementProvenance? SixelPlacement { get; init; }
        public int CellX;
        public int CellY;
        public int CellWidth;
        public int CellHeight;
        /// <summary>
        /// The line attribute of the row at the image's origin (<see cref="CellY"/>). Its columns are that row's
        /// columns: on a double-size row each one is two cells wide, and the image is placed and stretched to match.
        /// Single width when that row no longer exists (scrolled off the alternate screen, trimmed from history).
        /// </summary>
        public LineSize LineSize;
        public object ImageHandle;
        /// <summary>Protocol-owned undistorted fit inside the placement cell envelope.</summary>
        public bool PreserveAspectRatio { get; init; }
        internal SixelSource? Source;
        public bool IsSticky;
        public int ClipTopRows { get; init; }
        public int ClipBottomRows { get; init; }
        public int ClipRightColumns { get; init; }
        /// <summary>
        /// For a Unicode placeholder run (<see cref="GridColumns"/> &gt; 0): the grid column of the run's first
        /// cell. The bitmap is fitted into the whole <see cref="GridColumns"/> x <see cref="GridRows"/> grid and
        /// this run shows its part of it.
        /// </summary>
        public int GridColumn { get; init; }
        /// <summary>For a placeholder run: the grid row the run shows.</summary>
        public int GridRow { get; init; }
        /// <summary>The virtual placement's width in cells; 0 for an ordinary placement.</summary>
        public int GridColumns { get; init; }
        /// <summary>The virtual placement's height in cells.</summary>
        public int GridRows { get; init; }
        /// <summary>A placeholder run's own background colour, shown through transparent pixels; null for the theme's.</summary>
        public TermColor? TileBackground { get; init; }
        /// <summary>A placeholder run's palette background index (resolved through the theme); null when it has none.</summary>
        public short? TileBackgroundIndex { get; init; }
    }
}
