import { randomInt } from 'node:crypto';
import { readFileSync, lstatSync } from 'node:fs';
import { join } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { inputPriorCaptureCap } from './input-plan.mjs';
import { animationCases, animationCasesByVersion, animationCommand, animationExpectedReplies, animationSuiteIds, currentAnimationVersion, animationAnchor, animationCellEnvelope, animationHoldMs, placeholderAnimationVersion, placeholderCellEnvelope, placeholderMaxImageId, placeholderStageCells, placeholderGridVersion, placeholderGridEnvelope, placeholderGridStageCells, placeholderGridExposedRow } from './kitty-animation-cases.mjs';
import { animationFrameInput, animationFrameIds, animationPngIds, animationPngInput, placeholderHalvesInput, placeholderQuadrantsInput } from './kitty-animation-inputs.mjs';
import { inspectAnimationPixels, inspectPlaceholderPixels, inspectPlaceholderGridPixels, evaluateAnimationTiming, timelineAppearance } from './kitty-animation-oracle.mjs';
import { checkImages, imagePlan, imageSetup, imageRestore, imagePosition, imageBoundScreen, StaticImageReport, validateImageCapture } from './static-images.mjs';
import { pngHash } from './pixels-capture.mjs';

/** Policies by suite version; a retained run's context names the one it was collected under, and its evidence is rederived under that version's plan. */
export const ownedAnimationPolicies = Object.freeze({ 1: 'owned-kitty-animation-paired-raw-render-v1', 2: 'owned-kitty-animation-paired-raw-render-v2', 3: 'owned-kitty-animation-paired-raw-render-restore-v1', 4: 'owned-kitty-animation-paired-raw-render-compose-v1', 5: 'owned-kitty-placeholders-paired-raw-render-v1', 6: 'owned-kitty-placeholders-paired-raw-render-grid-v1' });
export const ownedAnimationPolicy = ownedAnimationPolicies[currentAnimationVersion];
/** The suite version a retained policy string names, or null for an unknown one. */
export const animationVersionOfPolicy = policy => Object.keys(ownedAnimationPolicies).map(Number).find(version => ownedAnimationPolicies[version] === policy) ?? null;
const planOf = cases => Object.freeze([
    { kind: 'bind' }, ...cases.flatMap(item => [...item.stages.map(stage => ({ kind: 'read', caseId: item.id, stageId: stage.id })),
        { kind: 'restore', caseId: item.id }]), { kind: 'finish' },
].map(Object.freeze));
export const animationPlan = planOf(animationCases);
export const animationActionCount = animationPlan.length;
/** The input phase's challenge pairs plus the static-image suite's (one per capture) that this suite must also avoid. */
export const animationPriorCap = inputPriorCaptureCap + imagePlan.length + 1;
export const animationPlannedStages = animationCases.reduce((total, item) => total + item.stages.length, 0);
export const animationPixelPrefix = 'animation-pixels';
const framePixelFile = (index, side) => `${animationPixelPrefix}/frame-${String(index).padStart(3, '0')}-${side}.png`;
const uint = value => Number.isSafeInteger(value) && value >= 1 && value <= 0xffffffff;

const mayDiffer = cases => entry => {
    const stage = entry?.kind === 'read' ? cases.find(item => item.id === entry.caseId)?.stages.find(item => item.id === entry.stageId) : null;
    return stage !== undefined && stage !== null && stage.clock !== 'static';
};
/** A paired capture may differ only for a stage whose frame moves or is claimed frozen: a legitimate boundary can fall between the two. */
export const animationPairMayDiffer = mayDiffer(animationCases);

/** Parent chooses each case's image id; replies must echo it exactly. */
export function animationAction(entry, state, runId, initialCursorVisible, version = currentAnimationVersion) {
    if (entry.kind === 'bind' || entry.kind === 'restore') return { command: imageSetup(runId), skipReason: null };
    if (entry.kind === 'finish') return { command: imageRestore(initialCursorVisible), skipReason: null };
    checkImages(uint(state.imageId));
    return { command: imagePosition(runId) + animationCommand(entry.caseId, entry.stageId, state, version) + imagePosition(runId), skipReason: null };
}

/** Exact framing of consecutive APC replies; mixed or uncorrelated bytes invalidate the experiment. */
export function parseAnimationReplies(raw, imageId) {
    checkImages(typeof raw === 'string' && raw.length <= 1024 && uint(imageId));
    const prefix = '\x1b_Gi=', terminator = '\x1b\\', replies = []; let rest = raw;
    while (rest.length) {
        const end = rest.indexOf(terminator), body = end > 0 && rest.startsWith(prefix) ? rest.slice(prefix.length, end) : '', separator = body.indexOf(';');
        const fields = body.slice(0, separator).split(','), status = body.slice(separator + 1);
        checkImages(separator > 0 && fields.length <= 2 && /^\d{1,10}$/.test(fields[0]) && Number(fields[0]) === imageId
            && (fields.length === 1 || /^p=[1-9]\d{0,9}$/.test(fields[1])) && /^(OK|E[A-Z\d]+(?::[ -~]*)?)$/.test(status));
        replies.push({ status, placement: fields.length === 2 ? Number(fields[1].slice(2)) : null }); rest = rest.slice(end + terminator.length);
    }
    return replies;
}
/** Missing or error replies are semantic negatives; extra, reordered-id or malformed bytes are invalid. */
export function animationReply(raw, stage, imageId) {
    const expected = parseAnimationReplies(animationExpectedReplies(stage, imageId).join(''), imageId), parsed = parseAnimationReplies(raw, imageId);
    checkImages(parsed.length <= expected.length && parsed.every((reply, index) => reply.placement === expected[index].placement));
    const statuses = parsed.map(reply => reply.status);
    if (!expected.length) return { passed: true, statuses };
    // A reply passes when it has the status the stage expects: OK exactly, or the named error code (its message is the terminal's own wording).
    const code = status => status.split(':')[0];
    return { passed: statuses.length === expected.length && statuses.every((status, index) => (expected[index].status === 'OK' ? status === 'OK' : code(status) === expected[index].status)), statuses };
}

export function animationBoundScreen(initial, runId) { return imageBoundScreen(initial, runId); }
/** The retained protocol inputs of a suite version: raw frames for v1, plus the PNG frames from v2; the placeholder suite has its one red/blue image. */
export function animationInputs(version = currentAnimationVersion) {
    if (version === placeholderAnimationVersion) {
        const input = placeholderHalvesInput();
        return [{ file: 'animation-inputs/halves.rgba', bytes: input.bytes, sha256: input.sha256 }];
    }
    if (version === placeholderGridVersion) {
        const input = placeholderQuadrantsInput();
        return [{ file: 'animation-inputs/quadrants.rgba', bytes: input.bytes, sha256: input.sha256 }];
    }
    return [...animationFrameIds.map(frameId => {
        const input = animationFrameInput(frameId);
        return { file: `animation-inputs/${frameId}.rgba`, bytes: input.bytes, sha256: input.sha256 };
    }), ...(version >= 2 ? animationPngIds : []).map(pngId => {
        const input = animationPngInput(pngId);
        return { file: `animation-inputs/${pngId}.png`, bytes: input.bytes, sha256: input.sha256 };
    })];
}
/** The shared image-capture validator keys its original-theme rule on the carrier's start/finish kinds. */
export const imageCaptureKind = kind => kind.replace(/^kan-/, 'images-');
export function retainedAnimationPixel(output, pixel, screen, kind) {
    checkImages(/^animation-pixels\/frame-\d{3}-[01]\.png$/.test(pixel?.file ?? ''));
    const path = join(output, pixel.file), stat = lstatSync(path);
    checkImages(stat.isFile() && !stat.isSymbolicLink() && stat.size <= 16 * 1024 * 1024);
    const bytes = readFileSync(path); checkImages(pngHash(bytes) === pixel.sha256);
    return validateImageCapture({ ...pixel, pngBase64: bytes.toString('base64') }, screen, imageCaptureKind(kind));
}
export const animationSpanOf = frame => {
    const span = frame?.pairSpan;
    checkImages(span && Number.isSafeInteger(span.startMs) && Number.isSafeInteger(span.endMs) && span.startMs <= span.endMs);
    return { start: span.startMs, end: span.endMs };
};

const scopeTail = 'independently captured raw replies, paired original offscreen PNGs, complete cells/modes and wall-clock capture spans. '
    + 'Elapsed-time claims are bounded to this App build and run: no display-refresh cadence, other platform, frame-rate, snapshot/persistent-session or stock-grade claim.';
const scopes = Object.freeze({
    6: 'Two bounded Kitty Unicode placeholder grid cases in one tab (a 4 x 2 grid of cells over a four-quadrant image: the tile rows, the row marks and the inheritance of a nonzero row; and tiles that scroll, shrink and grow with the text rows that carry them); '
        + 'the run\'s collection scope says whether that tab is a persistent one or an ordinary one. One 16x16 raw RGBA image, one grid size and one cell font, so every observation is one exact color per cell; ' + scopeTail,
    5: 'Three bounded Kitty Unicode placeholder cases in one tab (U=1 virtual placements and U+10EEEE cells: the tiles a 2 x 1 grid shows, the tile the row and column marks choose, and the cells that must paint nothing); the run\'s collection scope says whether that tab is a persistent one or an ordinary one. '
        + 'One 16x16 raw RGBA image (left half red, right half blue), one grid size and one cell font, so every observation is one uniform color per cell; ' + scopeTail,
    4: 'Two bounded Kitty animation frame-composition cases in one tab (a=c: replace and blend onto frames, and refused compositions that change nothing); the run\'s collection scope says whether that tab is a persistent one or an ordinary one. '
        + 'Whole-frame compositions only, so every observation is one uniform color; ' + scopeTail,
    1: 'Three bounded Kitty animation cases; ' + scopeTail,
    2: 'Four bounded Kitty animation cases (a stationary control, playback, stop-freeze, and PNG and root-based frames); ' + scopeTail,
    3: 'Three bounded Kitty animation restore cases in a persistent tab (a running animation, a stopped one, and PNG and root-edited frames), each read again after the App was terminated with SIGTERM (not a graceful quit) and started again on the same persistent session; '
        + 'independently captured raw replies, paired original offscreen PNGs, complete cells/modes and wall-clock capture spans. Elapsed-time claims are bounded to this App build and run: '
        + 'no display-refresh cadence, other platform, frame-rate, second-client, remote-session or stock-grade claim.',
});

/** Rederives or builds the report of a suite version (default: the current one); a retained run is checked under the version its context names. */
export function buildAnimationReport(frames, actions, seal, runId, output, priorChallenges = [], version = currentAnimationVersion) {
    const suite = animationSuites[version];
    checkImages(suite !== undefined && /^[a-f\d]{32}$/.test(runId ?? '') && frames?.length === suite.plan.length + 1 && actions?.length === suite.plan.length
        && Array.isArray(priorChallenges) && priorChallenges.length <= animationPriorCap && new Set(priorChallenges).size === priorChallenges.length);
    const builder = new AnimationReport(frames, actions, runId, output, priorChallenges, version);
    frames.forEach((frame, index) => builder.processFrame(frame, index));
    builder.checkSeal(seal);
    return { schemaVersion: 1, suiteId: animationSuiteIds[version], runId, policy: ownedAnimationPolicies[version], scope: scopes[version],
        holdMs: animationHoldMs, inputs: animationInputs(version).map(({ bytes, ...value }) => ({ ...value, byteCount: bytes.length })), priorChallenges,
        queriedPrivateModes: [5, 66, 9, 1000, 1002, 1003, 1006], kittyKeyboardFlags: 0, backgroundControls: builder.backgrounds,
        initialSnapshot: 0, restoredSnapshot: suite.plan.length, snapshots: frames, actions, seal,
        caseResults: builder.caseResults(), observations: builder.observations };
}

// The cell grid's own reporting of a placeholder cell (#989): the default foreground flag cleared (the cell has an explicit 24-bit foreground) and the extended-text flag set (it holds a grapheme of
// more than one UTF-16 unit: the supplementary-plane placeholder, with or without combining marks). Only these two bits differ from a blank cell; the rest of a cell run is the controlled blank cell's.
const defaultForegroundFlag = 1 << 8, defaultBackgroundFlag = 1 << 9, extendedTextFlag = 1 << 13;

/**
 * The screen the cell grid must show once a placeholder stage's command has run: the bound blank screen with the anchor row holding exactly the cells the stage printed (their graphemes as text, their
 * image id as a 24-bit foreground, every other attribute the blank cell's). Placeholders are cells, so unlike every other image carrier the screen changes. Built from the stage's own command text.
 */
export function placeholderScreen(bound, entry, state) {
    if (entry.kind !== 'read') return bound;
    const cells = placeholderStageCells(entry.stageId, state?.imageId, animationAnchor.col).map(cell => ({ ...cell, row: animationAnchor.row }));
    return cells.length ? screenWithCells(bound, cells, state) : bound;
}

/**
 * The screen(s) the cell grid may show once a placeholder grid stage has run: the cells (several screen rows of them, wherever the stage left them) over the bound blank screen. A stage whose operation exposes a new
 * blank line (scrolling up, inserting a line) has two acceptable screens, since what such a line holds depends on the terminal: filled with the active background (background color erase), or the default cell.
 */
export function placeholderGridScreen(bound, entry, state) {
    if (entry.kind !== 'read') return bound;
    const cells = placeholderGridStageCells(entry.stageId, state?.imageId);
    if (!cells.length) return bound;
    const exposed = placeholderGridExposedRow(entry.stageId, bound.rows);
    const filled = screenWithCells(bound, cells, state);
    return exposed === undefined ? filled : [filled, screenWithCells(bound, cells, state, exposed)];
}

/**
 * The bound blank screen with `cells` ({ row, column, text, imageId }) on it: each row's graphemes as its text and each cell's image id as a 24-bit foreground, every other attribute the blank cell's.
 * With `defaultRow`, every cell of that screen row instead holds the default cell (default foreground and background), as a line a terminal scrolled or inserted in without background color erase does.
 */
function screenWithCells(bound, cells, state, defaultRow) {
    checkImages(uint(state?.imageId) && bound.cellDetails.length === 1);
    const screen = structuredClone(bound), [blank] = bound.cellDetails, ordered = [...cells].sort((a, b) => a.row - b.row || a.column - b.column);
    for (const row of new Set(ordered.map(cell => cell.row))) {
        const line = ordered.filter(cell => cell.row === row);
        checkImages(line.every((cell, index) => cell.column === line[0].column + index));
        screen.lines[row] = ' '.repeat(line[0].column) + line.map(cell => cell.text).join('');
    }
    const special = new Map(ordered.map(cell => [cell.row * bound.cols + cell.column,
        { ...blank, count: 1, flags: (blank.flags & ~defaultForegroundFlag) | extendedTextFlag, foregroundArgb: (0xff000000 | cell.imageId) >>> 0 }]));
    if (defaultRow !== undefined) for (let column = 0; column < bound.cols; column++) special.set(defaultRow * bound.cols + column, { ...blank, count: 1, flags: blank.flags | defaultBackgroundFlag, backgroundArgb: null });
    const runs = [];
    let cursor = 0;
    for (const index of [...special.keys()].sort((a, b) => a - b)) {
        if (index > cursor) runs.push({ ...blank, count: index - cursor });
        const run = special.get(index), last = runs.at(-1);
        if (index === cursor && last && last.flags !== blank.flags && last.flags === run.flags && last.foregroundArgb === run.foregroundArgb && last.backgroundArgb === run.backgroundArgb) last.count++;
        else runs.push(run);
        cursor = index + 1;
    }
    if (cursor < blank.count) runs.push({ ...blank, count: blank.count - cursor });
    screen.cellDetails = runs;
    return screen;
}

/** The suites whose image id rides in a 24-bit foreground colour (and so stays below 2^24). */
const isPlaceholderSuite = version => version === placeholderAnimationVersion || version === placeholderGridVersion;

/** What the shared image-carrier observer and report need to know about one suite version. */
function suiteOf(version) {
    const cases = animationCasesByVersion[version], stageOfEntry = entry => cases.find(value => value.id === entry.caseId).stages.find(value => value.id === entry.stageId);
    return Object.freeze({
        plan: planOf(cases), prefix: 'kan-', relaunches: entry => entry.kind === 'read' && stageOfEntry(entry).relaunch === true, pixelDir: animationPixelPrefix, inputDir: 'animation-inputs', priorCap: animationPriorCap, recordSpan: true,
        inputs: () => animationInputs(version), action: (entry, state, runId, cursorVisible) => animationAction(entry, state, runId, cursorVisible, version), buildReport: (frames, actions, seal, runId, output, prior) => buildAnimationReport(frames, actions, seal, runId, output, prior, version),
        retainPixel: retainedAnimationPixel, captureKind: imageCaptureKind, pairMayDiffer: mayDiffer(cases), stageOfEntry,
        acceptReply: (reply, entry, states) => { animationReply(reply.toString('ascii'), stageOfEntry(entry), states.get(entry.caseId).imageId); },
        newState(states) {
            // A placeholder image id rides in a 24-bit foreground colour, and the wrong-image stage names the next id.
            const limit = isPlaceholderSuite(version) ? placeholderMaxImageId + 1 : 0x100000000;
            let imageId;
            do { imageId = randomInt(1, limit); } while ([...states.values()].some(value => value.imageId === imageId));
            return { imageId };
        },
        actionFacts: state => ({ imageId: state.imageId ?? null }),
        registerState(action, states) {
            checkImages(uint(action.imageId) && (!isPlaceholderSuite(version) || action.imageId <= placeholderMaxImageId) && ![...states.values()].some(value => value.imageId === action.imageId));
            return { imageId: action.imageId };
        },
        factsMatch: (action, state) => action.imageId === (state.imageId ?? null),
        ...(version === placeholderAnimationVersion ? { screenAfter: (entry, state, bound) => placeholderScreen(bound, entry, state) } : {}),
        ...(version === placeholderGridVersion ? { screenAfter: (entry, state, bound) => placeholderGridScreen(bound, entry, state) } : {}),
    });
}
export const animationSuites = Object.freeze({ 1: suiteOf(1), 2: suiteOf(2), 3: suiteOf(3), 4: suiteOf(4), 5: suiteOf(5), 6: suiteOf(6) });
export const animationSuite = animationSuites[currentAnimationVersion];

class AnimationReport extends StaticImageReport {
    constructor(frames, actions, runId, output, priorChallenges, version) {
        super(frames, actions, runId, output, priorChallenges, animationSuites[version]);
        this.cases = animationCasesByVersion[version]; this.suite = animationSuites[version]; this.version = version;
        // What reads a capture, and over how many cells, differs by suite: one frame-colored square, a row of two placeholder cells, or a 4 x 2 grid of them.
        [this.inspector, this.cellEnvelope] = { [placeholderAnimationVersion]: [inspectPlaceholderPixels, placeholderCellEnvelope], [placeholderGridVersion]: [inspectPlaceholderGridPixels, placeholderGridEnvelope] }[version] ?? [inspectAnimationPixels, animationCellEnvelope];
        this.lastEnd = -Infinity; this.facts = new Map();
    }
    initialFrameFacts(frame) { this.lastEnd = animationSpanOf(frame).end; }
    validateAction(frame, index, entry) {
        const facts = super.validateAction(frame, index, entry);
        return { ...facts, actionTime: Date.parse(facts.action.ownership.at), frameTime: Date.parse(frame.ownership.at) };
    }
    /** Wall-clock facts: when a command could have taken effect, and the span the paired captures covered. */
    timingFacts(entry, stage, index, { action, actionTime, frameTime }) {
        const span = animationSpanOf(this.frames[index]);
        checkImages(frameTime <= span.start && this.lastEnd <= actionTime);
        if (stage.waitMs !== undefined) checkImages(actionTime - this.lastEnd >= stage.waitMs);
        const previousEnd = this.lastEnd;
        this.lastEnd = span.end;
        const caseFacts = this.facts.get(entry.caseId) ?? {};
        // The new App was started, and its pane showed the restored screen, within this window: a playhead it restarted could have begun anywhere in it.
        // The record is the one the validated frame carries (its epoch change was checked against it); the action must carry the very same one.
        if (stage.relaunch) {
            const relaunch = this.frames[index].ownership.relaunch;
            checkImages(isDeepStrictEqual(action.ownership.relaunch, relaunch));
            checkImages(Date.parse(relaunch.startedAt) >= previousEnd && Date.parse(relaunch.startedAt) <= Date.parse(relaunch.at) && Date.parse(relaunch.at) <= actionTime);
            caseFacts.relaunch = { earliest: Date.parse(relaunch.startedAt), latest: Date.parse(relaunch.at) };
        }
        if (stage.reply === 'build') caseFacts.build = { earliest: actionTime, latest: frameTime };
        if (stage.reply === 'start') caseFacts.start = { earliest: actionTime, latest: frameTime };
        if (stage.reply === 'stop') caseFacts.stop = { earliest: actionTime, latest: frameTime };
        this.facts.set(entry.caseId, caseFacts);
        return { ...caseFacts, capture: span };
    }
    observe(entry, index, pixels, replyBytes, context) {
        const item = this.cases.find(value => value.id === entry.caseId), stage = this.suite.stageOfEntry(entry);
        const reply = animationReply(replyBytes.toString('ascii'), stage, context.state.imageId);
        const facts = this.timingFacts(entry, stage, index, context);
        // A pair that differs means the frame changed between its two captures. Independent timing decides what that means: where a boundary could fall
        // inside the span it is legitimate and the stage is inconclusive; where only one frame can be on screen it is an inconsistency and fails.
        const pairStable = this.frames[index].pixels[0].sha256 === this.frames[index].pixels[1].sha256;
        const timing = evaluateAnimationTiming(stage, facts);
        // A relaunch stage that follows a running animation shows whichever frame the independent timeline gives for the capture span (when the App came back varies); an ambiguous span makes the timing invalid, so the placeholder can only leave the stage inconclusive.
        const appearance = stage.appearance === 'timeline' ? timelineAppearance(facts) ?? 'root' : stage.appearance;
        const inspect = observed => this.inspector({ baseline: this.boundPixel.image, observed: observed.image, grid: observed.details.grid,
            anchor: { col: animationAnchor.col, row: animationAnchor.row + (stage.anchorShift ?? 0) }, cells: this.cellEnvelope, appearance });
        const pixel = inspect(pixels[0]);
        checkImages(pixel.controls[0].passed);
        // Bleed is timing-independent, so a pair that differs must be clean in both members.
        const other = pairStable ? pixel : inspect(pixels[1]);
        checkImages(other.controls[0].passed);
        const bleed = { ...pixel.controls[1], passed: pixel.controls[1].passed && other.controls[1].passed };
        const assertions = [...pixel.assertions, ...(pairStable || !timing.valid ? [] : [{ description: 'paired captures show one frame inside a window only one frame can occupy', passed: false }]), bleed];
        this.observations.push({ featureId: item.id + '.' + stage.id, ...this.gradeStage(item, stage, reply, assertions, timing), snapshot: index,
            actionIndex: context.action.index, reply, assertions, classification: pixel.classification, measurement: pixel.measurement,
            timing: { clock: stage.clock, valid: timing.valid, reason: timing.reason, facts } });
    }
    gradeStage(item, stage, reply, assertions, timing) {
        const position = item.stages.findIndex(value => value.id === stage.id);
        const witnessIds = position === 0 ? [] : [...new Set(['blank', item.stages[position - 1].id])];
        const causality = witnessIds.map(id => {
            const featureId = item.id + '.' + id, witness = this.observations.find(value => value.featureId === featureId);
            checkImages(witness);
            return { featureId, snapshot: witness.snapshot, result: witness.result, passed: witness.result === 'passed' };
        });
        const missing = causality.filter(value => !value.passed);
        let inconclusiveReason = null;
        if (missing.length) inconclusiveReason = 'requires passed prior witness: ' + missing.map(value => value.featureId + ' (' + value.result + ')').join(', ');
        if (!inconclusiveReason && !timing.valid) inconclusiveReason = timing.reason;
        // A negative reply or bleed outside the target stands without timing; a pixel mismatch needs valid timing and witnesses.
        if (reply.passed === false || assertions.at(-1).passed === false) return { result: 'failed', causality, inconclusiveReason: null };
        if (inconclusiveReason) return { result: 'inconclusive', causality, inconclusiveReason };
        return { result: assertions.every(value => value.passed) ? 'passed' : 'failed', causality, inconclusiveReason };
    }
    caseResults() {
        return this.cases.map(item => {
            const stages = this.observations.filter(value => value.featureId.startsWith(item.id + '.'));
            checkImages(stages.length === item.stages.length);
            let result = 'passed';
            if (stages.some(value => value.result === 'inconclusive')) result = 'inconclusive';
            if (stages.some(value => value.result === 'failed')) result = 'failed';
            return { caseId: item.id, result, stages: stages.map(value => value.featureId) };
        });
    }
}
