using System;
using Ntilde.Shell;
using Ntilde.AgentHost.Contracts;
using Ntilde.VT;

namespace Ntilde.AgentHost
{
    /// <summary>Additive controls for an offscreen capture, independent of the live clock.</summary>
    public readonly record struct AgentCaptureOptions(long? PresentationTimeMs = null, bool IncludeRenderDetails = false, CaptureSelection? SyntheticSelection = null, bool IncludeImageDetails = false)
    {
        // Per-call seam for deterministic concurrent-resize regressions; never set by the wire handler.
        internal Action? BeforeRenderForTest { get; init; }
        internal Action? BeforeDrawForTest { get; init; }
        internal Action? AfterSnapshotForTest { get; init; }
        internal Action<SnapshotRenderContext?>? AfterRenderForTest { get; init; }
    }

    /// <summary>A rendered pane screenshot (A5), as returned by <see cref="AgentSessionRegistration.TryCapturePng"/>.</summary>
    public readonly record struct AgentCaptureInfo(
        byte[] Png,
        int Width,
        int Height,
        int Cols,
        int Rows,
        bool Downscaled,
        double Scale,
        CaptureRenderDetails? RenderDetails = null,
        CaptureImageDetails? ImageDetails = null);

    /// <summary>Why a capture could not be produced; mapped to a protocol error code by the endpoint.</summary>
    public enum AgentCaptureError
    {
        /// <summary>
        /// The pane has no usable render state right now: it has not been laid
        /// out and measured yet, is being torn down, or the render threw.
        /// </summary>
        Unavailable,

        /// <summary>
        /// The pane's grid would render larger than the per-capture pixel budget
        /// at the requested scale. Scale squares the pixel count, so a grid that
        /// fits at 1x can miss at 2x.
        /// </summary>
        TooLarge,
    }

    /// <summary>
    /// One live pane's entry in <see cref="AgentSessionRegistry"/>.
    ///
    /// Holds a lock-protected snapshot of the pane's metadata instead of live
    /// delegates into the control: the registry is queried from a background
    /// IPC thread (milestone A1/PR3), and Avalonia controls must not be read
    /// off the UI thread. The pane pushes updates on the UI thread
    /// (TerminalPane.UpdateAgentSessionSnapshot) whenever title, working
    /// directory, profile, or active state changes; readers on any thread get
    /// a consistent, tear-free view. Guid/bool fields are also read under the
    /// gate because Guid reads are not atomic.
    /// </summary>
    public sealed class AgentSessionRegistration
    {
        private readonly object _gate = new();
        private Guid _paneId;
        private Guid? _tabId;
        private string _title;
        private string _profileName;
        private string _kind;
        private bool _isActive;
        private Guid? _profileId;
        private bool _isAgentActable;

        // The window half of "the user can see this pane". Focus pushed to the
        // attention machine is the AND of this and _isActive: being the
        // selected pane only means "selected inside the app", which stays true
        // while the app is alt-tabbed away or minimized. Optimistic default so
        // a registration nobody tells about the window (every test that builds
        // one directly) behaves as it did before; MainWindow pushes the real
        // value the moment the registration reaches the registry, so the
        // default never survives into a running app.
        private bool _isWindowVisible = true;

        public AgentSessionRegistration(
            Guid paneId,
            TerminalBuffer buffer,
            string title,
            string profileName,
            string kind,
            bool isActive,
            Func<DateTimeOffset>? nowProvider = null,
            Guid? profileId = null)
        {
            ArgumentNullException.ThrowIfNull(buffer);
            _paneId = paneId;
            _buffer = buffer;
            _title = title;
            _profileName = profileName;
            _kind = kind;
            _isActive = isActive;
            _profileId = profileId;
            StatusMachine = new AgentSessionStatusMachine(nowProvider);
            AttentionMachine = new AgentAttentionMachine(nowProvider);
            AttentionMachine.NoteFocusChanged(isActive);
        }

        /// <summary>
        /// Per-session status state machine (A2). Signals are pushed by the
        /// pane on the UI thread; snapshots are safe from any thread.
        /// </summary>
        public AgentSessionStatusMachine StatusMachine { get; }

        /// <summary>
        /// Per-pane agent attention tiers (read / wrote). Signals come from the
        /// endpoint on its IPC and timer threads and from the pane on the UI
        /// thread; the machine is internally locked.
        /// </summary>
        public AgentAttentionMachine AttentionMachine { get; }

        /// <summary>
        /// Whether an agent may currently act on this pane: the global act
        /// toggle plus, for SSH panes, the per-profile allowlist. Published by
        /// <see cref="AgentHostService"/> rather than derived here — the
        /// registration does not know the settings or the allowlist. Drives
        /// whether the pane shows its agent status segment at all.
        /// </summary>
        public bool IsAgentActable
        {
            get { lock (_gate) { return _isAgentActable; } }
            internal set
            {
                // AgentHostService.RefreshActability writes this unconditionally
                // from a 1 s sweep on every registration. Raising on every write
                // would turn that into a perpetual once-per-second UI-post storm
                // per pane, so the event fires only on an actual value change.
                bool changed;
                lock (_gate)
                {
                    changed = _isAgentActable != value;
                    _isAgentActable = value;
                }

                // Raised outside the gate, same rule UpdateSnapshot follows for
                // AttentionMachine.NoteFocusChanged: invoking a subscriber while
                // holding this registration's lock is a deadlock hazard (a
                // subscriber that calls back into this registration would
                // re-enter the lock on the same thread's call stack, or block
                // forever against another thread that already holds it).
                if (changed)
                {
                    ActabilityChanged?.Invoke();
                }
            }
        }

        /// <summary>
        /// Raised outside <see cref="_gate"/> whenever <see cref="IsAgentActable"/>
        /// actually changes value (never on a same-value rewrite — see the
        /// setter). The owning pane uses this to re-render its status bar
        /// segment when act-reachability is republished with no attention-tier
        /// transition alongside it (global act toggle, allowlist edit).
        ///
        /// Deliberately payload-free: a handed-out <c>bool</c> is a stale
        /// channel. <c>AgentHostService.RefreshActability</c> can run
        /// concurrently (the 1 s sweep thread, the act-toggle setter, an
        /// allowlist edit on the UI thread) and two racing writers can compute
        /// different values for the same SSH pane. Whichever writer enters the
        /// setter first stores its value; it may then be descheduled and raise
        /// *after* the other. With a payload, the last value delivered can
        /// disagree with the value actually stored — and because the setter
        /// raises only on change, every later sweep sees no change and never
        /// corrects it, leaving a pane permanently unmarked while agents can
        /// type into it. With no payload the subscriber must read
        /// <see cref="IsAgentActable"/>, so whichever post runs last renders
        /// the current truth no matter how the raises interleave.
        /// </summary>
        public event Action? ActabilityChanged;

        // The PTY session behind this registration, published by the pane on the
        // UI thread whenever the session is created, swapped, or torn down —
        // the same push pattern as the metadata snapshot, so the endpoint's
        // sweep never dereferences pane state. Volatile: a reference published
        // here is safely visible to the timer thread. Widened from
        // ITerminalLifecycle in A4 so the endpoint can also reach the
        // flight-recorder surface (ITerminalFlightRecorder) without touching
        // the pane; the sweep still uses only the lifecycle members.
        private volatile Ntilde.Pty.ITerminalSession? _session;

        /// <summary>Identity-only lease for bounded read-only UI observations.</summary>
        internal Ntilde.Pty.ITerminalSession? ObservationSession => _session;

        // Desired flight-recording state pushed by the endpoint (A4). Kept on
        // the registration because the pane may publish the session *after*
        // the endpoint enabled recording (registration happens before spawn),
        // and reconnects swap sessions: every newly published session must
        // inherit the endpoint's decision. 0 = disabled.
        private long _flightRecordingMaxBytes;

        /// <summary>Publishes (or clears) the PTY session this registration runs on. UI thread.</summary>
        public void SetLifecycle(Ntilde.Pty.ITerminalSession? session)
        {
            var previous = _session;
            _session = session;

            // The flight ring follows the observe lifecycle of *this*
            // registration: a session this registration no longer owns
            // (reconnect swap, detach) must not keep retaining output until
            // its eventual disposal.
            if (previous != null && !ReferenceEquals(previous, session))
            {
                try
                {
                    previous.DisableFlightRecording();
                }
                catch
                {
                    // raced a dispose — the ring died with the session
                }
            }

            if (session != null)
            {
                var maxBytes = System.Threading.Interlocked.Read(ref _flightRecordingMaxBytes);
                if (maxBytes > 0)
                {
                    TryApplyFlightRecording(session, maxBytes);
                }

                // A pane whose session exited is live again (#610: the user signed in to an agent's SSH tab).
                StatusMachine.NotifySessionStarted();
            }
        }

        /// <summary>
        /// Endpoint lifecycle (A4): start retaining recent output on the
        /// current session and every session published later, bounded by
        /// <paramref name="maxBytes"/>. Idempotent.
        /// </summary>
        public void EnableFlightRecording(long maxBytes)
        {
            System.Threading.Interlocked.Exchange(ref _flightRecordingMaxBytes, maxBytes);
            if (_session is { } session)
            {
                TryApplyFlightRecording(session, maxBytes);
            }
        }

        /// <summary>Endpoint lifecycle (A4): stop retaining and drop the ring. Idempotent.</summary>
        public void DisableFlightRecording()
        {
            System.Threading.Interlocked.Exchange(ref _flightRecordingMaxBytes, 0);
            var session = _session;
            if (session == null) return;
            try
            {
                session.DisableFlightRecording();
            }
            catch
            {
                // raced a dispose — the ring died with the session
            }
        }

        /// <summary>
        /// Exports the session's flight recording to <paramref name="filePath"/>.
        /// False when no session is published, recording is not enabled, or the
        /// write failed (the session logs the reason).
        /// </summary>
        public bool TryExportFlightRecording(string filePath, out Ntilde.Replay.FlightExportInfo info)
        {
            var session = _session;
            if (session == null)
            {
                info = default;
                return false;
            }

            try
            {
                return session.TryExportFlightRecording(filePath, out info);
            }
            catch
            {
                info = default;
                return false; // raced a dispose — treat as unavailable
            }
        }

        private static void TryApplyFlightRecording(Ntilde.Pty.ITerminalSession session, long maxBytes)
        {
            try
            {
                session.EnableFlightRecording(maxBytes);
            }
            catch
            {
                // raced a dispose — the next published session will inherit the state
            }
        }

        /// <summary>
        /// PTY child-process probe for the heuristic status tier, invoked by
        /// the endpoint's 1 s sweep. Targets only the PTY layer
        /// (<c>ITerminalLifecycle.HasActiveChildProcesses</c>, thread-safe by
        /// contract) via the published reference above — never the pane. Null
        /// means "unknown right now" (no session yet, or the probe raced a
        /// teardown); the status machine keeps its last known value instead of
        /// flapping.
        /// </summary>
        public bool? ProbeHasActiveChildProcesses()
        {
            var lifecycle = _session;
            if (lifecycle == null) return null;
            try
            {
                return lifecycle.HasActiveChildProcesses;
            }
            catch
            {
                return null; // probe raced a dispose — unknown, not false
            }
        }

        /// <summary>The pane's VT buffer. Reads must take <see cref="TerminalBuffer.Lock"/> (endpoint milestone A1/PR3).</summary>
        private TerminalBuffer _buffer;
        public TerminalBuffer Buffer => Volatile.Read(ref _buffer);

        internal void SetBuffer(TerminalBuffer buffer) => Volatile.Write(ref _buffer, buffer);

        /// <summary>Stable pane identity; re-keyed via <see cref="AgentSessionRegistry.Rekey"/> on session restore.</summary>
        public Guid PaneId
        {
            get { lock (_gate) { return _paneId; } }
            internal set { lock (_gate) { _paneId = value; } }
        }

        /// <summary>Owning tab; null until MainWindow associates the pane via <see cref="AgentSessionRegistry.SetTabAssociation"/>.</summary>
        public Guid? TabId
        {
            get { lock (_gate) { return _tabId; } }
            internal set { lock (_gate) { _tabId = value; } }
        }

        /// <summary>Current display title (OSC title, or profile + cwd fallback) at the last snapshot push.</summary>
        public string Title
        {
            get { lock (_gate) { return _title; } }
        }

        /// <summary>Current profile name ("Terminal" when the pane has no profile) at the last snapshot push.</summary>
        public string ProfileName
        {
            get { lock (_gate) { return _profileName; } }
        }

        /// <summary>"ssh" or "local".</summary>
        public string Kind
        {
            get { lock (_gate) { return _kind; } }
        }

        /// <summary>
        /// Backing profile id (local settings profile or SSH store profile), or
        /// null for a profile-less pane. Used by the A3 act surface to check the
        /// per-profile SSH allowlist; null or a local session is governed by the
        /// global act toggle alone.
        /// </summary>
        public Guid? ProfileId
        {
            get { lock (_gate) { return _profileId; } }
        }

        /// <summary>
        /// Raised after <see cref="TrySendInput"/> has put bytes on the wire. The owning pane uses
        /// it to invalidate anything that models the command line from keystrokes alone: an agent
        /// typing for the user is text the keyboard path never saw.
        /// </summary>
        public Action? InputInjected { get; set; }

        /// <summary>
        /// Injects <paramref name="text"/> into the live session (A3). Returns
        /// false when no session is published or its process has already exited.
        /// Goes through <see cref="Ntilde.Pty.ITerminalIO.SendInput"/> —
        /// the same thread-safe, replay-recorded path human keystrokes take.
        /// </summary>
        public bool TrySendInput(string text)
        {
            var session = _session;
            if (session == null) return false;
            try
            {
                if (!session.IsProcessRunning) return false;
                session.SendInput(text);
                InputInjected?.Invoke();
                return true;
            }
            catch
            {
                return false; // raced a dispose
            }
        }

        /// <summary>True when this pane was the active pane of its tab at the last snapshot push.</summary>
        public bool IsActive
        {
            get { lock (_gate) { return _isActive; } }
        }

        // Render inputs for captureScreen (A5), pushed by the pane on the UI
        // thread whenever font metrics or font-related settings change. Kept as
        // plain values under the gate for the same reason as the metadata
        // snapshot: the endpoint renders on an IPC thread and must never read
        // the control. Null until the pane has measured its font.
        private PaneRenderParameters? _renderParameters;

        /// <summary>Publishes the pane's current render inputs. UI thread.</summary>
        public void UpdateRenderParameters(PaneRenderParameters parameters)
        {
            lock (_gate) { _renderParameters = parameters; }
        }

        /// <summary>The last published render inputs, or null when the pane has not been measured yet.</summary>
        public PaneRenderParameters? RenderParameters
        {
            get { lock (_gate) { return _renderParameters; } }
        }

        /// <summary>
        /// Renders the pane's visible grid to a PNG (A5), off the UI thread,
        /// through the same <see cref="TerminalSnapshotRenderer"/> the golden
        /// render tests use. <paramref name="maxWidth"/> (0 = no cap) resamples the
        /// result down afterwards; <paramref name="scale"/> sets how many device
        /// pixels a DIP renders as, so it adds real detail rather than resampling.
        /// Neither is taken from the user's monitor, so a capture cannot vary with
        /// the machine it runs on.
        /// </summary>
        public bool TryCapturePng(int maxWidth, double scale, out AgentCaptureInfo info, out AgentCaptureError error,
            AgentCaptureOptions captureOptions = default)
        {
            if (RenderParameters is not { } parameters || !parameters.IsUsable)
            {
                info = default;
                error = AgentCaptureError.Unavailable;
                return false;
            }

            return TryRenderPng(Buffer, parameters, maxWidth, scale, out info, out error, captureOptions);
        }

        /// <summary>
        /// The render behind <see cref="TryCapturePng"/>, for any buffer: a pane's, or the private buffer a windowless
        /// session's screen was imported into (Phase 5 §3), drawn with a pane's <paramref name="parameters"/>. Off the UI
        /// thread; takes the buffer's read lock only for the values it needs.
        /// </summary>
        internal static bool TryRenderPng(
            TerminalBuffer buffer, PaneRenderParameters parameters, int maxWidth, double scale,
            out AgentCaptureInfo info, out AgentCaptureError error,
            AgentCaptureOptions captureOptions = default)
        {
            info = default;
            error = AgentCaptureError.Unavailable;

            if (!parameters.IsUsable || (captureOptions.IncludeImageDetails && !captureOptions.IncludeRenderDetails))
            {
                return false;
            }

            int cols, rows;
            buffer.Lock.EnterReadLock();
            try
            {
                cols = buffer.Cols;
                rows = buffer.Rows;
            }
            finally
            {
                buffer.Lock.ExitReadLock();
            }

            if (cols <= 0 || rows <= 0 || !CaptureSelectionValidation.FitsGrid(captureOptions.SyntheticSelection, rows, cols))
            {
                return false;
            }

            // The draw snaps each cell independently and adds its pixel origin. Multiplying
            // fractional DIP metrics by the grid count clips the right/bottom after snapping.
            var effectiveScale = scale <= 0 ? 1.0 : Math.Min(scale, Contracts.AgentHostProtocol.MaxCaptureScale);
            var grid = TerminalDrawOperation.CreatePixelGrid(parameters.Metrics, effectiveScale);
            long gridWidth = grid.OriginXPx + (long)cols * grid.CellWidthPx;
            long gridHeight = grid.OriginYPx + (long)rows * grid.CellHeightPx;
            const long pixelBudget = Contracts.AgentHostProtocol.MaxCapturePixels;
            if (gridWidth > pixelBudget || gridHeight > pixelBudget || gridWidth * gridHeight > pixelBudget)
            {
                error = AgentCaptureError.TooLarge;
                return false;
            }
            // Capture accepts integer DIP bounds. Round upward so every snapped device
            // pixel fits, then budget the exact bitmap size the renderer will allocate.
            double widthDip = Math.Ceiling(gridWidth / effectiveScale);
            double heightDip = Math.Ceiling(gridHeight / effectiveScale);
            if (widthDip > int.MaxValue || heightDip > int.MaxValue)
            {
                error = AgentCaptureError.TooLarge;
                return false;
            }
            int width = (int)widthDip, height = (int)heightDip;
            var deviceWidth = (long)Math.Round(width * effectiveScale, MidpointRounding.AwayFromZero);
            var deviceHeight = (long)Math.Round(height * effectiveScale, MidpointRounding.AwayFromZero);
            if (deviceWidth * deviceHeight > pixelBudget)
            {
                error = AgentCaptureError.TooLarge;
                return false;
            }

            var options = new TerminalSnapshotOptions
            {
                // What the user is looking at: their font, their theme, an opaque
                // background. Not what they have selected — a selection highlight
                // is transient UI state, and including it would make two captures
                // of the same output differ.
                FontResolution = SnapshotFontResolution.LiveParity,
                FillBackground = true,
                TypefaceFamily = parameters.FontFamily,
                FontSize = parameters.FontSize,
                EnableLigatures = parameters.EnableLigatures,
                EnableComplexShaping = parameters.EnableComplexShaping,
                MinimumContrast = parameters.MinimumContrast,
                PreferredCursorStyle = parameters.PreferredCursorStyle,
                PreferredCursorBlink = parameters.PreferredCursorBlink,
                PresentationTimeMs = captureOptions.PresentationTimeMs,
                BeforeDrawForTest = captureOptions.BeforeDrawForTest,
                AfterSnapshotForTest = captureOptions.AfterSnapshotForTest,
                IncludeImageDetails = captureOptions.IncludeImageDetails,
                SelectionRelativeToViewport = captureOptions.SyntheticSelection is not null,
                Selection = captureOptions.SyntheticSelection is { } selected ? new SelectionState
                {
                    IsActive = true,
                    Start = (selected.StartRow, selected.StartCol),
                    End = (selected.EndRow, selected.EndCol),
                } : null,

                // Visibility/shape/blink facts come from the draw's own snapshot.
                // No live focus or clock is read; absent synthetic time keeps visible phases.
                HideCursor = false,

                // The caller's scale, not the monitor's. Worth stating plainly
                // because passing anything but 1.0 here was broken until #346:
                // the canvas is now scaled and the bitmap sized in device pixels,
                // so a box-drawing stroke picked in whole device pixels survives.
                RenderScaling = effectiveScale,
                NativeRasterPresenter = parameters.NativeRasterPresenter,
            };

            try
            {
                // A glyph cache of our own, per capture. Not an optimisation: the draw
                // operation's per-codepoint fallback resolution lives inside its
                // `_glyphCache != null` branch, and the branch taken without one draws
                // the whole run in the primary face - so every glyph the primary font
                // lacks came out as a notdef box. Found by looking at a real capture:
                // Claude Code's status line (U+23F5, U+29C9, U+23BF) rendered as boxes
                // while the live view showed them via Segoe UI Symbol, which sits first
                // in the fallback chain.
                //
                // Fresh rather than the live control's, which the render thread owns and
                // this IPC thread must not touch. Disposed with the capture; a screenshot
                // is rare enough that building one atlas per call costs nothing that
                // matters. Same remedy #346 used to get the primitive painter back on the
                // golden-baseline path.
                using var glyphCache = new Ntilde.Rendering.GlyphCache();
                options = options with { GlyphCache = glyphCache };

                captureOptions.BeforeRenderForTest?.Invoke();
                using var bitmap = TerminalSnapshotRenderer.CaptureWithContext(buffer, parameters.Metrics, width, height,
                    options, captureOptions.IncludeRenderDetails, out var captureFrame);
                captureOptions.AfterRenderForTest?.Invoke(captureFrame.Context);
                if (captureFrame.Cols != cols || captureFrame.Rows != rows ||
                    captureFrame.BufferCols != cols || captureFrame.BufferRows != rows)
                {
                    // The bitmap was sized before a concurrent resize. Retry rather than
                    // presenting a cropped/expanded viewport as a qualified full-grid frame.
                    return false;
                }
                using var downscaled = TerminalSnapshotRenderer.DownscaleToWidth(bitmap, maxWidth);
                var final = downscaled ?? bitmap;
                var details = AgentCaptureDetails.FromCapture(captureFrame.Context);
                info = new AgentCaptureInfo(
                    TerminalSnapshotRenderer.EncodePng(final),
                    final.Width,
                    final.Height,
                    cols,
                    rows,
                    Downscaled: downscaled != null,
                    Scale: effectiveScale,
                    RenderDetails: details.Render,
                    ImageDetails: details.Images);
                return true;
            }
            catch (Exception ex)
            {
                // Font resolution, Skia allocation, or a torn-down buffer. The
                // capture is a read: failing it must never take the endpoint down.
                System.Diagnostics.Debug.WriteLine($"[AgentHost] captureScreen render failed: {ex}");
                return false;
            }
        }

        /// <summary>Atomically replaces the pane-owned metadata. Called on the UI thread by the pane.</summary>
        public void UpdateSnapshot(string title, string profileName, string kind, bool isActive, Guid? profileId = null)
        {
            bool effectiveFocus;
            lock (_gate)
            {
                _title = title;
                _profileName = profileName;
                _kind = kind;
                _isActive = isActive;
                _profileId = profileId;
                effectiveFocus = isActive && _isWindowVisible;
            }

            // Focus feeds the write-acknowledgement rule, and it means "the
            // user is plausibly looking at this pane" — being the selected pane
            // of a window that is minimized or behind another application does
            // not qualify. Pushed after the gate is released: the machine locks
            // internally and raises Changed.
            AttentionMachine.NoteFocusChanged(effectiveFocus);
        }

        /// <summary>
        /// The owning window became front-and-visible, or stopped being so
        /// (deactivated, minimized). Pushed by MainWindow from the UI thread.
        ///
        /// This exists because <see cref="UpdateSnapshot"/> is driven by
        /// pane-level changes only, and a window losing focus is not one: with
        /// focus meaning nothing but <c>IsActivePane</c>, an agent write into
        /// the selected pane of an alt-tabbed-away app would be retired by the
        /// periodic tick ten seconds later, with the user never having seen the
        /// one mark in this feature that is designed to survive until seen.
        ///
        /// Like <see cref="UpdateSnapshot"/>, the machine is signalled outside
        /// <see cref="_gate"/>: it locks internally and raises Changed to
        /// subscribers who may call back into this registration.
        /// </summary>
        public void NoteWindowVisibilityChanged(bool isWindowVisible)
        {
            bool effectiveFocus;
            lock (_gate)
            {
                if (_isWindowVisible == isWindowVisible) return;
                _isWindowVisible = isWindowVisible;
                effectiveFocus = _isActive && isWindowVisible;
            }

            AttentionMachine.NoteFocusChanged(effectiveFocus);
        }
    }
}
