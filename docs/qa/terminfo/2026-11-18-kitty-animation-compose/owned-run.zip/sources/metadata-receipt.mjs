import { createHash } from 'node:crypto';
import { lstatSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { capturedV74SourceFiles, capturedV76SourceFiles, capturedV75SourceFiles, capturedV73SourceFiles, capturedV72SourceFiles, capturedOsc5ForkV63Files, capturedOsc5ForkV64Files, capturedV71SourceFiles, capturedCellSizeForkV70Files, isCellSizePolicy63, isKittyAnimationPolicy63, capturedV70SourceFiles, capturedOsc633ForkV61Files, capturedV69SourceFiles, capturedV68SourceFiles, capturedV67SourceFiles, capturedV66SourceFiles, capturedV65SourceFiles, capturedV64SourceFiles, capturedV63SourceFiles, capturedV62SourceFiles, capturedV61SourceFiles, capturedV60SourceFiles, capturedV59SourceFiles, capturedV8SourceFiles, legacyV8SourceFiles, capturedV8SourcePolicy, capturedV9SourceFiles, capturedV10SourceFiles, capturedV11SourceFiles, capturedV12SourceFiles, capturedV13SourceFiles, capturedV14SourceFiles, capturedV15SourceFiles, capturedV16SourceFiles, capturedV17SourceFiles, capturedV18SourceFiles, capturedV19SourceFiles, capturedV20SourceFiles, capturedV21SourceFiles, capturedV22SourceFiles, capturedV23SourceFiles, capturedV24SourceFiles, capturedV25SourceFiles, capturedV26SourceFiles, capturedV27SourceFiles, capturedV31SourceFiles, capturedV32SourceFiles, capturedV33SourceFiles, capturedV34SourceFiles, capturedV36SourceFiles, capturedV37SourceFiles, capturedV38SourceFiles, capturedV39SourceFiles, capturedV40SourceFiles, capturedV41SourceFiles, capturedV44SourceFiles, capturedV45SourceFiles, capturedV46SourceFiles, capturedV53SourceFiles, capturedV54SourceFiles, capturedV55SourceFiles, capturedV56SourceFiles, capturedV57SourceFiles, capturedV58SourceFiles, capturedV52SourceFiles, capturedV51SourceFiles, capturedV50SourceFiles, capturedV49SourceFiles, capturedV48SourceFiles, capturedV47SourceFiles, capturedV43SourceFiles, capturedV42SourceFiles, capturedV35SourceFiles, capturedV30SourceFiles, capturedV29SourceFiles, capturedV28SourceFiles, assertRetainedSourceClosure } from './owned-sources.mjs';
import { isHistoricOsc633Scope, isOsc5ForkScope, isOsc5V64Scope, isCellSizeV64Scope } from './collection-scope.mjs';
import { buildMetadataReport } from './metadata.mjs';
import { metadataSuiteId, ownedMetadataPolicy } from './metadata-cases.mjs';
import { validateOutputGeometry } from './terminal-output.mjs';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const same = (left, right) => JSON.stringify(left) === JSON.stringify(right);
const check = value => { if (!value) throw new Error('Invalid or incomplete v8 owned metadata-state receipt.'); };
export const metadataSources = {
    metadataCasesSourceSha256: 'metadata-cases.mjs', metadataCaptureSourceSha256: 'metadata-capture.mjs',
    metadataSuiteSourceSha256: 'metadata.mjs', metadataStateSourceSha256: 'metadata-state.mjs',
    metadataExpectationsSourceSha256: 'metadata-expectations.mjs', metadataReceiptSourceSha256: 'metadata-receipt.mjs',
    sourceRegistrySourceSha256: 'owned-sources.mjs',
};
function present(path) {
    try { lstatSync(path); return true; }
    catch (error) {
        if (error.code === 'ENOENT') return false;
        throw error;
    }
}
function bytes(output, file, maximum = 16 * 1024 * 1024) {
    const path = join(output, file), stat = lstatSync(path);
    check(stat.isFile() && !stat.isSymbolicLink() && stat.size <= maximum);
    const value = readFileSync(path); check(value.length <= maximum); return value;
}
/** Any retained suite/source/journal or parent declaration makes the complete v8 chain mandatory. */
export function includesMetadataEvidence(output, evidence, context, proof) {
    return context.metadataSuiteId !== undefined || context.ownedMetadataPolicy !== undefined || evidence.metadataEvidence !== undefined
        || Object.keys(metadataSources).some(key => context[key] !== undefined)
        || proof.proofs?.some(value => value.metadata !== undefined) === true
        || context.sourceSnapshotPolicy !== undefined || context.sourceInventorySha256 !== undefined
        || proof.sourceSnapshot !== undefined || present(join(output, 'source-snapshot.json'))
        || present(join(output, 'sources', 'owned-source-inventory.json'))
        || present(join(output, 'sources', 'terminfo-owned-runner.mjs'))
        || present(join(output, 'metadata-failed-observation.json'))
        || present(join(output, 'metadata-snapshots.jsonl'))
        || present(join(output, 'metadata-observations.json')) || present(join(output, 'metadata-unavailable.json'))
        || Object.values(metadataSources).some(file => present(join(output, 'sources', file)));
}
function snapshotMode(output, context) {
    return context.sourceSnapshotPolicy !== undefined || context.sourceInventorySha256 !== undefined
        || present(join(output, 'source-snapshot.json')) || present(join(output, 'sources', 'owned-source-inventory.json'))
        || present(join(output, 'sources', 'terminfo-owned-runner.mjs'));
}
function checkSnapshot(output, context, proof) {
    const policy = context.sourceSnapshotPolicy, inventory = retainedInventory(output, context);
    check([capturedV8SourcePolicy, 'readonly-owned-source-graph-v2', 'readonly-owned-source-graph-v3', 'readonly-owned-source-graph-v4', 'readonly-owned-source-graph-v5', 'readonly-owned-source-graph-v6', 'readonly-owned-source-graph-v7', 'readonly-owned-source-graph-v8', 'readonly-owned-source-graph-v9', 'readonly-owned-source-graph-v10', 'readonly-owned-source-graph-v11', 'readonly-owned-source-graph-v12', 'readonly-owned-source-graph-v13', 'readonly-owned-source-graph-v14', 'readonly-owned-source-graph-v15', 'readonly-owned-source-graph-v16', 'readonly-owned-source-graph-v17', 'readonly-owned-source-graph-v18', 'readonly-owned-source-graph-v19', 'readonly-owned-source-graph-v20', 'readonly-owned-source-graph-v21', 'readonly-owned-source-graph-v22', 'readonly-owned-source-graph-v23', 'readonly-owned-source-graph-v24', 'readonly-owned-source-graph-v25', 'readonly-owned-source-graph-v26', 'readonly-owned-source-graph-v27', 'readonly-owned-source-graph-v28', 'readonly-owned-source-graph-v29', 'readonly-owned-source-graph-v30', 'readonly-owned-source-graph-v31', 'readonly-owned-source-graph-v32', 'readonly-owned-source-graph-v33', 'readonly-owned-source-graph-v34', 'readonly-owned-source-graph-v35', 'readonly-owned-source-graph-v36', 'readonly-owned-source-graph-v37', 'readonly-owned-source-graph-v38', 'readonly-owned-source-graph-v39', 'readonly-owned-source-graph-v40', 'readonly-owned-source-graph-v41', 'readonly-owned-source-graph-v42', 'readonly-owned-source-graph-v43', 'readonly-owned-source-graph-v44', 'readonly-owned-source-graph-v45', 'readonly-owned-source-graph-v46', 'readonly-owned-source-graph-v47', 'readonly-owned-source-graph-v48', 'readonly-owned-source-graph-v49', 'readonly-owned-source-graph-v50', 'readonly-owned-source-graph-v51', 'readonly-owned-source-graph-v52', 'readonly-owned-source-graph-v53', 'readonly-owned-source-graph-v54', 'readonly-owned-source-graph-v55', 'readonly-owned-source-graph-v56', 'readonly-owned-source-graph-v57', 'readonly-owned-source-graph-v58', 'readonly-owned-source-graph-v59', 'readonly-owned-source-graph-v60', 'readonly-owned-source-graph-v61', 'readonly-owned-source-graph-v62', 'readonly-owned-source-graph-v63', 'readonly-owned-source-graph-v64', 'readonly-owned-source-graph-v65', 'readonly-owned-source-graph-v66', 'readonly-owned-source-graph-v67', 'readonly-owned-source-graph-v68', 'readonly-owned-source-graph-v69'].includes(policy) && /^[a-f\d]{64}$/.test(context.sourceSnapshotManifestSha256 ?? ''));
    const data = bytes(output, 'source-snapshot.json', 65536), manifest = JSON.parse(data);
    check(hash(data) === context.sourceSnapshotManifestSha256 && manifest.schemaVersion === 1 && manifest.policy === policy
        && Object.keys(manifest.hashes ?? {}).length === Object.keys(inventory).length
        && Object.keys(inventory).every(key => manifest.hashes[key] === context[key]));
    check(proof.sourceSnapshot?.policy === policy && typeof context.sourceSnapshotRoot === 'string'
        && proof.sourceSnapshot.root === context.sourceSnapshotRoot && !present(context.sourceSnapshotRoot)
        && Number.isFinite(Date.parse(proof.sourceSnapshot.removedAt))
        && Date.parse(proof.sourceSnapshot.removedAt) >= Date.parse(proof.cleanedUpAt));
}
/** Each source-snapshot policy maps to exactly its own captured file set. */
export function retainedInventory(output, context) {
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v69') return capturedV76SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v67') return capturedV74SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v68') return capturedV75SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v66') return capturedV73SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v65') return capturedV72SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v64') {
        if (isOsc5V64Scope(context)) return capturedOsc5ForkV64Files;
        if (isCellSizeV64Scope(context)) return capturedV71SourceFiles;
        throw new Error('Invalid or ambiguous historical v64 source graph.');
    }
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v63') {
        if (isOsc5ForkScope(context)) return capturedOsc5ForkV63Files;
        if (isCellSizePolicy63(context)) return capturedCellSizeForkV70Files;
        if (isKittyAnimationPolicy63(context)) return capturedV70SourceFiles;
        throw new Error('Invalid or ambiguous historical v63 source graph.');
    }
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v62') return capturedV69SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v61') return isHistoricOsc633Scope(context.collectionScope) ? capturedOsc633ForkV61Files : capturedV68SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v60') return capturedV67SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v59') return capturedV66SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v58') return capturedV65SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v57') return capturedV64SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v56') return capturedV63SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v55') return capturedV62SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v53') return capturedV60SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v54') return capturedV61SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v52') return capturedV59SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v51') return capturedV58SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v50') return capturedV57SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v48') return capturedV55SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v49') return capturedV56SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v11') return capturedV18SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v12') return capturedV19SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v20') return capturedV27SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v31') return capturedV38SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v32') return capturedV39SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v33') return capturedV40SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v37') return capturedV44SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v47') return capturedV54SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v46') return capturedV53SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v48') return capturedV55SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v45') return capturedV52SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v44') return capturedV51SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v43') return capturedV50SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v42') return capturedV49SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v41') return capturedV48SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v40') return capturedV47SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v39') return capturedV46SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v38') return capturedV45SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v36') return capturedV43SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v35') return capturedV42SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v34') return capturedV41SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v30') return capturedV37SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v29') return capturedV36SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v28') return capturedV35SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v27') return capturedV34SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v26') return capturedV33SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v25') return capturedV32SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v24') return capturedV31SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v23') return capturedV30SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v22') return capturedV29SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v21') return capturedV28SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v19') return capturedV26SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v18') return capturedV25SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v17') return capturedV24SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v16') return capturedV23SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v15') return capturedV22SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v14') return capturedV21SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v13') return capturedV20SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v10') return capturedV17SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v9') return capturedV16SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v8') return capturedV15SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v7') return capturedV14SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v6') return capturedV13SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v5') return capturedV12SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v4') return capturedV11SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v3') return capturedV10SourceFiles;
    if (context.sourceSnapshotPolicy === 'readonly-owned-source-graph-v2') return capturedV9SourceFiles;
    return snapshotMode(output, context) ? capturedV8SourceFiles : legacyV8SourceFiles;
}
function checkSources(output, context, marker) {
    check(context.metadataSuiteId === metadataSuiteId && context.ownedMetadataPolicy === ownedMetadataPolicy && marker?.policy === ownedMetadataPolicy
        && Object.keys(marker).every(key => ['policy', 'paneId', 'geometry'].includes(key)));
    check(context.retainedSources === 'sources' && context.retainedAdapterBundle === 'collector-adapter.mjs'
        && /^[a-f\d]{64}$/.test(context.adapterBundleSha256 ?? '')
        && hash(bytes(output, 'collector-adapter.mjs')) === context.adapterBundleSha256
        && hash(bytes(output, 'package-lock.json')) === context.collectorLockSha256);
    const dir = lstatSync(join(output, 'sources')); check(dir.isDirectory() && !dir.isSymbolicLink());
    const inventory = retainedInventory(output, context);
    check(Object.keys(context).filter(key => key.endsWith('SourceSha256')).every(key => Object.hasOwn(inventory, key)));
    const retained = readdirSync(join(output, 'sources')), expected = Object.values(inventory);
    check(retained.length === expected.length && retained.every(file => expected.includes(file)));
    if (snapshotMode(output, context)) check(same(JSON.parse(bytes(output, join('sources', 'owned-source-inventory.json'))), inventory));
    for (const [key, file] of Object.entries(inventory)) {
        check(/^[a-f\d]{64}$/.test(context[key] ?? '') && hash(bytes(output, join('sources', file), 2 * 1024 * 1024)) === context[key]);
    }
    assertRetainedSourceClosure(join(output, 'sources'), inventory);
}
/** Re-derive every staged active-state observation and match its original common-pane/kernel proof. */
export function checkMetadataEvidence(output, binding, runId, context, proof) {
    const marker = proof.proofs?.[0]?.metadata;
    checkSources(output, context, marker);
    if (snapshotMode(output, context)) checkSnapshot(output, context, proof);
    check(!present(join(output, 'metadata-failed-observation.json')));
    check(binding?.runId === runId && binding.suiteId === metadataSuiteId
        && ['metadata-observations.json', 'metadata-unavailable.json'].includes(binding.file));
    const otherReport = binding.file === 'metadata-observations.json' ? 'metadata-unavailable.json' : 'metadata-observations.json';
    check(!present(join(output, otherReport)));
    check(Object.keys(binding).every(key => ['runId', 'suiteId', 'file', 'sha256', 'counts', 'provisionalUntil', 'status', 'reason'].includes(key)));
    const reportBytes = bytes(output, binding.file);
    check(/^[a-f\d]{64}$/.test(binding.sha256 ?? '') && hash(reportBytes) === binding.sha256);
    const report = JSON.parse(reportBytes);
    check(report.runId === runId && report.suiteId === metadataSuiteId);
    const text = bytes(output, 'metadata-snapshots.jsonl').toString('utf8').trim();
    const frames = text ? text.split('\n').map(line => JSON.parse(line)) : [];
    if (binding.file === 'metadata-unavailable.json') {
        check(report.status === 'unavailable' && ['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(report.reason)
            && report.fixtureStarted === false && report.plannedExperiments === 13 && frames.length === 0
            && marker.paneId === undefined && marker.geometry === undefined
            && binding.status === 'unavailable' && binding.reason === report.reason && same(binding.counts, {}));
        return;
    }
    check(binding.status === undefined && binding.reason === undefined);
    const settingsBytes = bytes(output, 'initial-settings.json');
    check(hash(settingsBytes) === context.initialSettingsSha256);
    const settings = JSON.parse(settingsBytes);
    check(settings.Osc9NotificationsEnabled === true && settings.Osc9ProgressReportingEnabled === true
        && settings.AgentAccessObserveEnabled === true && settings.TabStripOrientation === 'Horizontal');
    const derived = buildMetadataReport(frames, runId);
    check(same(report, derived) && marker.paneId === frames[0].paneId
        && same(marker.geometry, { rows: frames[0].before.screen.rows, cols: frames[0].before.screen.cols }));
    const cell = JSON.parse(bytes(output, 'cell-observations.json'));
    check(cell.snapshots?.[0]?.paneId === marker.paneId && cell.snapshots[0].screen.rows === marker.geometry.rows
        && cell.snapshots[0].screen.cols === marker.geometry.cols);
    validateOutputGeometry(proof.proofs[0].terminalOutput.description, marker.geometry.rows, marker.geometry.cols);
    const counts = report.observations.reduce((values, item) => ({ ...values, [item.result]: (values[item.result] ?? 0) + 1 }), {});
    check(same(counts, binding.counts));
}

