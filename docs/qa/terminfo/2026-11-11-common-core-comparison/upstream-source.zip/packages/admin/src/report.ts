/** Report command — render the canonical selected observations and separate history. */

import { basename, dirname, join } from "node:path"
import { readFileSync, statSync } from "node:fs"
import { spawnSync } from "node:child_process"
import { createHash } from "node:crypto"
import { fileURLToPath } from "node:url"
import { loadFeatures } from "@terminfo/catalog"
import { parseJsonStrict, type LoadedRun } from "@terminfo/run-parser"
import { PROBE_STATUSES, readCollectorSelection, readCollectorAttempt } from "@terminfo/probe-defs"
import { loadCurrentResults } from "../../../docs/data/current-results.ts"
import { originalRunFor, type SelectedAttemptInput } from "../../../docs/data/selected-results.ts"
import { fullContextCensus } from "../../../docs/data/full-census.ts"
import { isStaleRelation } from "../../../docs/data/release-scope.ts"
import { readExplicitSuiteTarget } from "../suite-manifest.ts"
import { loadRawCapture } from "../raw-capture.ts"
import { renderReport } from "../report.tsx"

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..")

const record = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === "object" && !Array.isArray(value)

function revision(ref: string, optional = false): string | undefined {
  const result = spawnSync("git", ["rev-parse", "--verify", "--quiet", ref], { cwd: ROOT, encoding: "utf8" })
  if (optional && result.status === 1) return undefined
  if (result.error || result.status !== 0 || !/^[a-f0-9]{40}\s*$/.test(result.stdout)) {
    throw new Error(`Cannot read ${ref} in ${ROOT}: ${result.error?.message ?? result.stderr}`)
  }
  return result.stdout.trim()
}

/** Explicit inputs are evidence, not publication receipts. No pass is synthesized from raw captures. */
async function rawScoreboard(paths: readonly string[], contentDir: string): Promise<string> {
  const census = fullContextCensus(contentDir)
  const catalogIds = Object.keys(loadFeatures(contentDir))
  let observedAt = ""
  const workingRuns: LoadedRun[] = []
  type DeclaredContext = (typeof census.contexts)[number]
  const pendingAttempts: SelectedAttemptInput[] = []
  const rows = new Map<
    string,
    Array<{
      runId: string
      suite: string
      source: string
      sha256: string
      detail: string
      counts: string
      pass: string
      state: string
      selected: boolean
    }>
  >()
  type PassContext = {
    pass: string
    suite: string
    sourceRevision: string
    context?: DeclaredContext
  }
  type EvidenceRow = NonNullable<ReturnType<typeof rows.get>>[number]
  const append = (context: string, row: EvidenceRow): EvidenceRow => {
    rows.set(context, [...(rows.get(context) ?? []), row])
    return row
  }
  function readPass(path: string, bytes: string, header: Record<string, unknown>, contexts: unknown[]): void {
    if (typeof header.probeHash !== "string" || typeof header.sourceRevision !== "string") {
      throw new Error(`${path}: pass requires probeHash and sourceRevision`)
    }
    readExplicitSuiteTarget(ROOT, header.probeHash)
    const identity: PassContext = {
      pass: basename(dirname(path)),
      suite: header.probeHash,
      sourceRevision: header.sourceRevision,
    }
    for (const value of contexts) {
      if (!record(value) || !record(value.context)) throw new Error(`${path}: pass has no context identity`)
      const subject = value.context
      const context = census.contexts.find(
        (row) =>
          row.kind === subject.kind && row.terminalId === subject.id && (row.kind === "lib" || row.os === subject.os),
      )
      if (!context) throw new Error(`${path}: pass names a context outside the canonical census`)
      if (typeof value.rawRun === "string") {
        const declared = { ...identity, context }
        read(value.rawRun, declared)
      } else {
        append(context.context, {
          selected: false,
          pass: identity.pass,
          state: "to-measure",
          suite: `${header.probeHash}@${header.sourceRevision}`,
          runId: "no captured run supplied",
          source: path,
          sha256: createHash("sha256").update(bytes).digest("hex"),
          counts: "not measured",
          detail: String(value.error ?? value.reason ?? "not recorded"),
        })
      }
    }
  }
  function read(input: string, pass?: PassContext): EvidenceRow | undefined {
    const path = statSync(input).isDirectory() ? join(input, "pass.json") : input
    const bytes = readFileSync(path, "utf8")
    const header: unknown = parseJsonStrict(path, bytes)
    if (record(header) && Array.isArray(header.contexts)) {
      if (pass) throw new Error(`${path}: a pass context must cite a raw run, not another pass`)
      readPass(path, bytes, header, header.contexts)
      return
    }
    if (
      !record(header) ||
      typeof header.runId !== "string" ||
      typeof header.probeHash !== "string" ||
      typeof header.sourceRevision !== "string"
    ) {
      throw new Error(`${path}: a raw capture requires runId, probeHash and sourceRevision`)
    }
    const subject = header.subject ?? header.target
    if (!record(subject) || typeof subject.id !== "string" || typeof subject.os !== "string") {
      if (pass?.context) {
        if (!record(header.rawReplies)) throw new Error(`${path}: initialized draft has no retained rawReplies`)
        const rawReplies: Record<string, string> = {}
        for (const [key, value] of Object.entries(header.rawReplies)) {
          if (typeof value !== "string") throw new Error(`${path}: rawReplies.${key} is not retained text`)
          rawReplies[key] = value
        }
        if (pass.suite !== header.probeHash || pass.sourceRevision !== header.sourceRevision) {
          throw new Error(`${path}: raw suite/source disagrees with pass ${pass.pass}`)
        }
        const selection = readCollectorSelection(rawReplies)
        const attempt = readCollectorAttempt(rawReplies)
        if (selection) {
          pendingAttempts.push({
            context: pass.context,
            intendedSubject: record(header.intendedSubject) ? header.intendedSubject : {},
            runId: header.runId,
            path,
            rawReplies,
          })
        }
        return append(pass.context.context, {
          selected: false,
          pass: pass.pass,
          state: "to-measure",
          suite: `${header.probeHash}@${header.sourceRevision}`,
          runId: header.runId,
          source: path,
          sha256: createHash("sha256").update(bytes).digest("hex"),
          counts: "no measured subject or emitted result",
          detail:
            `${attempt?.result ?? "collector.collectionAttempt outcome absent"}; ${attempt?.error ?? ""}` +
            (selection ? "" : "; collector.selection absent; no selection inferred"),
        })
      }
      throw new Error(`${path}: raw capture has no recorded subject identity`)
    }
    const kind = subject.kind === "headless" ? "lib" : subject.kind === "app" ? "term" : subject.kind
    if (typeof header.measuredAt === "string" && header.measuredAt > observedAt) observedAt = header.measuredAt
    const context = census.contexts.find(
      (row) => row.kind === kind && row.terminalId === subject.id && (kind === "lib" || row.os === subject.os),
    )
    if (!context) {
      throw new Error(`${path}: ${String(subject.kind)}:${subject.id}/${subject.os} is outside the canonical census`)
    }
    if (pass && (pass.suite !== header.probeHash || pass.sourceRevision !== header.sourceRevision)) {
      throw new Error(`${path}: raw suite/source disagrees with pass ${pass.pass}`)
    }
    let detail = "baseline/unreviewed"
    let counts = "not validated"
    try {
      if (pass?.context && pass.context.context !== context.context) {
        throw new Error(`${path}: declared ${pass.context.context}; recorded ${context.context}`)
      }
      // The one raw-capture reader (shared with the preview site's hourly view); it throws on any invalid input.
      const run = loadRawCapture(path, { root: ROOT, catalogIds, bytes })
      if (!run.results) throw new Error(`${path}: raw capture has no recorded results`)
      workingRuns.push(run)
      const totals: Record<string, number> = {}
      for (const result of run.results) totals[result.status] = (totals[result.status] ?? 0) + 1
      counts = `raw catalog ${run.results.length}: ${PROBE_STATUSES.map((status) => `${status}=${totals[status] ?? 0}`).join(" ")}`
    } catch (error) {
      // Retain the named evidence row when its declaration is absent or invalid; it proves no probe result.
      detail += `; ${error instanceof Error ? error.message : String(error)}`
    }
    return append(pass?.context?.context ?? context.context, {
      selected: false,
      pass: pass?.pass ?? "no pass",
      state: "measured-unpublished",
      runId: header.runId,
      suite: `${header.probeHash}@${header.sourceRevision}`,
      source: path,
      sha256: createHash("sha256").update(bytes).digest("hex"),
      detail,
      counts,
    })
  }
  for (const path of paths) read(path)
  const head = revision("HEAD")
  const live = revision("refs/remotes/origin/live", true)
  const contentStatus = spawnSync("git", ["status", "--porcelain", "--untracked-files=all", "--", "content"], {
    cwd: ROOT,
    encoding: "utf8",
  })
  if (contentStatus.error || contentStatus.status !== 0) {
    throw new Error(
      `Cannot establish content revision in ${ROOT}: ${contentStatus.error?.message ?? contentStatus.stderr}`,
    )
  }
  const dirtyContent = contentStatus.stdout.length > 0
  const provenLive = head === live && !dirtyContent
  const projection = loadCurrentResults(contentDir, { workingRuns, workingAttempts: pendingAttempts }).projection
  for (const summary of Object.values(projection.contexts)) {
    for (const runId of summary.contributingRunIds) {
      // Private working inputs need factual rows, while admitted originals use the shared owner.
      if (!projection.history[summary.contextKey]?.some((run) => run.runId === runId)) {
        // Working captures already have factual private rows above; contributing to the composed
        // view does not admit them or give them a reviewed/publication identity.
        const original = Object.values(summary.cells).find((cell) => cell.origin.runId === runId)?.run
        if (!original) throw new Error(`Context ${summary.contextKey} names absent original contributor ${runId}`)
        const matching = [...rows.values()]
          .flat()
          .filter((row) => row.runId === runId && row.sha256 === original.sha256)
        if (matching.length === 0) {
          throw new Error(`Context ${summary.contextKey} contributor ${runId} has no retained private input row`)
        }
        const contribution = Object.values(summary.cells).filter((cell) => cell.origin.runId === runId).length
        for (const row of matching) {
          row.selected = true
          row.detail += `; contributes ${contribution} cells to ${summary.contextKey}; private original, not admitted`
        }
        continue
      }
      const selected = originalRunFor(projection, summary.contextKey, runId)
      if (selected.measuredAt > observedAt) observedAt = selected.measuredAt
      const context = census.contexts.find(
        (row) =>
          row.kind === selected.subject.kind &&
          row.terminalId === selected.subject.id &&
          (row.kind === "lib" || row.os === selected.subject.os),
      )
      if (!context) continue
      const publication = provenLive
        ? `selected at ${head}, live proven`
        : `selected at ${head}, live unproven (origin/live ${live ?? "absent"}${dirtyContent ? "; content differs from HEAD" : ""})`
      const contribution = Object.values(summary.cells).filter((cell) => cell.origin.runId === runId).length
      const detail = `${publication}; contributes ${contribution} cells to ${summary.contextKey}; original run ${selected.complete ? (provenLive ? "reviewed-pass; publication proven" : "reviewed-pass-awaiting-publish") : "reviewed-fail; recorded FAIL/TODO remains"}`
      const state = isStaleRelation(selected.suiteRelation)
        ? "stale"
        : provenLive && selected.complete
          ? "published"
          : "measured-unpublished"
      const matching =
        rows.get(context.context)?.filter((row) => row.runId === selected.runId && row.sha256 === selected.sha256) ?? []
      if (matching.length > 0) {
        for (const row of matching) {
          row.selected = true
          row.state = state
          row.detail = `${detail}; ${selected.suiteFreshness}`
        }
      } else {
        append(context.context, {
          selected: true,
          pass: "no pass",
          state,
          runId: selected.runId,
          suite: `${selected.probeHash}@${selected.sourceRevision}`,
          source: `loadCurrentResults(${contentDir}).projection.contexts[${summary.contextKey}] contributor`,
          sha256: selected.sha256,
          detail: `${detail}; ${selected.suiteFreshness}`,
          counts: `feature results ${selected.score.all}: ${Object.entries(selected.counts)
            .map(([status, count]) => `${status}=${count}`)
            .join(" ")}`,
        })
      }
    }
  }
  const escape = (value: string) => value.replaceAll("|", "\\|").replaceAll(/\r?\n/g, " ")
  const lines = [
    "Terminal context scoreboard — Not a pass, not an admission",
    `Content revision ${head}; origin/live ${live ?? "absent"}; provenLive=${provenLive}${dirtyContent ? "; content differs from HEAD" : ""}`,
    "Unselected raw observations remain baseline/unreviewed; admission and publication use recorded evidence only.",
    `Observation: ${observedAt || "no capture timestamp recorded"}; owner not recorded in inputs. Explicit inputs: ${paths.map(escape).join(", ")}`,
    ...projection.exclusions.map((row) => `Excluded run ${row.runId}: ${escape(row.reason)}; ${escape(row.path)}`),
    "| Context | State | Pass | Run / suite | Counts / evidence |",
    "| --- | --- | --- | --- | --- |",
  ]
  for (const context of census.contexts) {
    const sources = rows
      .get(context.context)
      ?.sort(
        (left, right) =>
          Number(left.selected) - Number(right.selected) ||
          left.source.localeCompare(right.source) ||
          left.runId.localeCompare(right.runId) ||
          left.pass.localeCompare(right.pass),
      )
    const latest = sources?.[0]
    if (!latest) {
      lines.push(
        `| ${context.context} | to-measure | no pass | no captured run supplied | not recorded; resolving query: explicit inputs above |`,
      )
      continue
    }
    const selectedStates = sources?.filter((row) => row.selected).map((row) => row.state) ?? []
    const state = latest.selected
      ? selectedStates.includes("stale")
        ? "stale"
        : selectedStates.every((value) => value === "published")
          ? "published"
          : "measured-unpublished"
      : latest.state
    lines.push(
      `| ${context.context} | ${state} | ${escape(latest.pass)} | ${escape(`${latest.runId} ${latest.suite}`)} | ${escape(`${latest.counts}; ${latest.detail}; ${latest.source}; sha256=${latest.sha256}`)}${sources
        ?.slice(1)
        .map((row) =>
          escape(
            `; earlier pass ${row.pass}${row.selected ? "; selected evidence" : ""}: ${row.runId} ${row.suite}; ${row.counts}; ${row.state}; ${row.detail}; ${row.source}; sha256=${row.sha256}`,
          ),
        )
        .join("")} |`,
    )
  }
  return `${lines.join("\n")}\n\n${await renderReport(projection, catalogIds)}`
}

export async function handleReport(options: { scoreboard?: string[] } = {}): Promise<void> {
  const contentDir = join(ROOT, "content")
  if (options.scoreboard) {
    console.log(await rawScoreboard(options.scoreboard, contentDir))
    return
  }
  const { projection } = loadCurrentResults(contentDir)
  // The selector has already validated this required catalog; its IDs supply the report's absent rows.
  const featureIds = Object.keys(loadFeatures(contentDir))
  console.log(await renderReport(projection, featureIds))
}
