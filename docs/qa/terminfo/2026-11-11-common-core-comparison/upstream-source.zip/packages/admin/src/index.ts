#!/usr/bin/env bun
/**
 * terminfo CLI — unified terminal feature testing.
 *
 * Four probe mechanisms:
 *   termless   Headless library probes via Termless backends (Vitest)
 *   server     Probe running daemons (HTTP servers in real terminals)
 *   app        Launch and probe macOS terminal apps (AppleScript)
 *   here       Probe this terminal inline (raw TTY I/O)
 *
 * @example
 * ```bash
 * terminfo                          # show help
 * terminfo probe                    # list probe mechanisms
 * terminfo probe termless --all     # run all headless probes
 * terminfo probe server --start     # start daemon in this terminal
 * terminfo probe app --all          # probe all installed terminals
 * terminfo probe here               # probe this terminal inline
 * terminfo report                   # show saved results
 * terminfo submit                   # probe + upload to terminfo.dev
 * terminfo status                   # config, cache, backends
 * terminfo detect                   # what terminal am I in?
 * ```
 */

import { Command, json } from "@silvery/commander"
import { collectorIds } from "@terminfo/probe-defs"
import { ensureSourceSuiteEnvironment } from "../versions.ts"

const program = new Command()
  .name("terminfo")
  .description("Terminal feature testing for terminfo.dev")
  .showHelpAfterError()

program.addHelpSection("Examples:", [
  ["$ terminfo probe termless --all", "Run all headless probes"],
  ["$ terminfo probe server --start", "Start daemon in this terminal"],
  ["$ terminfo probe app --all", "Probe all installed terminals"],
  ["$ terminfo probe here", "Probe this terminal inline"],
  ["$ terminfo report", "Show saved results"],
  ["$ terminfo submit", "Probe + upload to terminfo.dev"],
  ["$ terminfo status", "Config, cache, backends"],
  ["$ terminfo detect", "What terminal am I in?"],
])

// ── probe ──

const probe = program.command("probe").description("Run terminal probes (termless, server, app, mux, here)")

probe.addHelpSection("Examples:", [
  ["$ terminfo probe termless --all", "Probe all headless backends"],
  ["$ terminfo probe termless xtermjs", "Probe specific backend"],
  ["$ terminfo probe server --start", "Start daemon in this terminal"],
  ["$ terminfo probe server --all", "Probe all running daemons"],
  ["$ terminfo probe app ghostty", "Probe specific terminal app"],
  ["$ terminfo probe mux tmux", "Probe through tmux"],
  ["$ terminfo probe here", "Probe this terminal inline"],
])

// ── probe termless ──

probe
  .command("termless")
  .description("Headless library probes via Termless backends")
  .argument("[selectors...]", "Backend selectors to probe")
  .option("--all", "Probe all backends")
  .option("--probe-ids <json>", "Exact probe IDs as a JSON array; [] executes none", json)
  .option("-f, --force", "Re-run even if cached")
  .actionMerged(async (opts: { selectors: string[]; all?: boolean; force?: boolean; probeIds?: unknown }) => {
    const { runTermlessProbes } = await import("./termless.ts")
    const probeIds = opts.probeIds === undefined ? undefined : collectorIds(opts.probeIds, "--probe-ids")
    await runTermlessProbes(opts.all ? [] : opts.selectors, { ...opts, probeIds })
  })

// ── probe server ──

probe
  .command("server")
  .description("Probe running daemon servers")
  .argument("[daemon]", "Daemon name to probe")
  .option("--start", "Start daemon in this terminal")
  .option("-p, --port <port>", "Port for --start", parseInt)
  .option("--all", "Probe all running daemons")
  .actionMerged(async (opts: { daemon?: string; start?: boolean; port?: number; all?: boolean }) => {
    ensureSourceSuiteEnvironment()
    const { handleServer } = await import("./server.ts")
    await handleServer(opts.daemon, opts)
  })

// ── probe app ──

probe
  .command("app")
  .description("Launch and probe macOS terminal apps")
  .argument("[terminal]", "Terminal app to probe")
  .option("--all", "Probe all installed terminals")
  .option("-f, --force", "Re-run even if cached")
  .option("--output <directory>", "Retain the collected run and original HTTP response privately")
  .actionMerged(async (opts: { terminal?: string; all?: boolean; force?: boolean; output?: string }) => {
    ensureSourceSuiteEnvironment()
    const { handleApp } = await import("./app.ts")
    await handleApp(opts.terminal, opts)
  })

// ── probe mux ──

probe
  .command("mux")
  .description("Probe through terminal multiplexers (tmux, screen)")
  .argument("[multiplexer]", "Multiplexer to probe (tmux, screen)")
  .option("--output <directory>", "Retain collected runs and original HTTP responses privately")
  .option("--all", "Probe through all installed multiplexers")
  .option("-f, --force", "Re-run even if cached")
  .actionMerged(async (opts: { multiplexer?: string; all?: boolean; force?: boolean; output?: string }) => {
    ensureSourceSuiteEnvironment()
    const { handleMux } = await import("./mux.ts")
    await handleMux(opts.multiplexer, opts)
  })

// ── probe here ──

probe
  .command("here")
  .description("Probe this terminal inline")
  .option("--json", "Output results as JSON")
  .action(async (opts: { json?: boolean }) => {
    const { handleHere } = await import("./here.ts")
    await handleHere(opts)
  })

// ── report ──

program
  .command("report")
  .description("Show saved probe results")
  .option(
    "--scoreboard <inputs...>",
    "Show context progress from explicit raw captures or collection pass files/directories",
    (value: string, previous: string[] = []) => [...previous, value],
  )
  .action(async (opts: { scoreboard?: string[] }) => {
    const { handleReport } = await import("./report.ts")
    await handleReport(opts)
  })

// ── submit ──

program
  .command("submit")
  .description("Probe and submit results to terminfo.dev")
  .option("--terminal-name <name>", "Override detected terminal name")
  .option("--terminal-version <version>", "Override detected terminal version")
  .action(async (opts: { terminalName?: string; terminalVersion?: string }) => {
    const { handleSubmit } = await import("./submit.ts")
    await handleSubmit(opts)
  })

// ── status ──

program
  .command("status")
  .description("Show config, cache, backends")
  .action(async () => {
    const { handleStatus } = await import("./status.ts")
    await handleStatus()
  })

// ── detect ──

program
  .command("detect")
  .description("Detect current terminal")
  .option("--json", "Output as JSON")
  .action(async (opts: { json?: boolean }) => {
    const { handleDetect } = await import("./detect.ts")
    await handleDetect(opts)
  })

await program.parseAsync()
