import type { ProbeCallbackResult, ProbeDefinition } from "./types.ts"
import { captureRegionCallbackResult, type RegionReadback } from "./region-readback.ts"
import { RESET_FAMILY_CAPTURE } from "./reset-family-capture.ts"
import {
  declaredUntestableResult,
  decrpmReading,
  HEADLESS_OBSERVABLE_REVIEW,
  notTestedResult,
  parserStateResult,
  replyFailure,
  probe,
  queryDecrpm,
  reviewResult,
  sgrCaptureFrames,
  sgrCaptureTooSmall,
  sgrReadbackDecision,
  type DecrpmPs,
} from "./helpers.ts"

/**
 * The cell-aligned readback for DECALN. The compared region is rows 2-3 and never row 1: DECALN
 * homes the cursor there itself, and a cursor row is excluded from every compared region. Both
 * frames park the cursor on the last row and the witness cell sits on row 4. The expected frame is a
 * full grid of E written PLAINLY in the same run, which is exactly what ESC # 8 should leave behind.
 */
function decalnReadback(rows: number, cols: number): Omit<RegionReadback, "pixelGeometry"> | null {
  if (!Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 5 || cols < 9) return null
  const park = `\x1b[${rows};1H`
  const screen = (line: string): string => {
    let writes = "\x1b[0m\x1b[2J\x1b[H"
    for (let row = 1; row <= rows; row++) writes += `\x1b[${row};1H${line}`
    return `${writes}${park}`
  }
  return {
    region: { top: 2, left: 1, bottom: 3, right: 8 },
    sentinel: { row: 4, col: 1 },
    cursorRow: rows,
    seed: screen("AB".repeat(Math.ceil(cols / 2)).slice(0, cols)),
    edit: `\x1b#8${park}`,
    expected: screen("E".repeat(cols)),
    timeoutMs: 5000,
    pollMs: 250,
    minRows: 5,
    minCols: 9,
  }
}

export const resetProbes: ProbeDefinition[] = [
  {
    ...probe(
      "reset.sgr",
      (ctx) => {
        ctx.feed("\x1b[1;3;7mX\x1b[0mY")
        const before = ctx.getCell(0, 0)
        const after = ctx.getCell(0, 1)
        const state = { before, after }
        const expected = "SGR 0 clears measured bold, italic, and inverse styling on Y"
        if (before.char !== "X" || after.char !== "Y") {
          return parserStateResult(null, expected, state, "Styled control or reset cell was not measured")
        }
        // #30701, @cto ruling C: graded on the styles the control measurably shows. A style field the
        // adapter never populates is left out, and a control that shows none has no observable.
        const styles = (["bold", "italic", "inverse"] as const).filter((style) => before[style] === true)
        if (styles.length === 0) {
          return notTestedResult("bold, italic and inverse on the styled control cell in the headless readback", state)
        }
        const unshown = (["bold", "italic", "inverse"] as const).filter((style) => before[style] !== true)
        return parserStateResult(
          styles.every((style) => !after[style]),
          expected,
          state,
          unshown.length > 0
            ? `Graded on ${styles.join(" and ")}; ${unshown.join(" and ")} not shown by the styled control`
            : undefined,
        )
      },
      async (ctx) => {
        const captureRefusal = ctx.capture ? sgrCaptureTooSmall(ctx, "reset.sgr") : undefined
        if (captureRefusal) return captureRefusal
        const regionReadback = RESET_FAMILY_CAPTURE["reset.sgr"]
        let referenceFailure: ProbeCallbackResult | undefined
        // The immutable initial reference must precede DECRQSS's SGR0 prelude. Only a failed
        // qualification falls through: a changed made-up control or an unknown target is invalid.
        if (ctx.capture && ctx.captureKind !== "text-cells" && regionReadback?.savedRendition) {
          const captured = await captureRegionCallbackResult(ctx, "reset.sgr", regionReadback)
          if (captured && captured.criterionBranch !== "saved-rendition-unqualified") return captured
          if (captured) referenceFailure = captured
        }
        const measuredRoom =
          Number.isSafeInteger(ctx.rows) && Number.isSafeInteger(ctx.cols) && ctx.rows >= 1 && ctx.cols >= 2
        // A silent DECRQSS attempt still wrote its sequence and query, so the named refusal from
        // the region oracle must report QUERY evidence, not the zero-byte "none" shape.
        let readbackAttempted = false
        if (measuredRoom) {
          readbackAttempted = true
          const readback = await sgrReadbackDecision(
            ctx,
            "reset.sgr",
            "\x1b[0m",
            { require: [], forbid: [1, 3, 7] },
            {
              sequence: "\x1b[1;3;7m",
              baseline: { require: [], forbid: [1, 3, 7] },
              readback: { require: [1, 3, 7] },
            },
          )
          if (readback) {
            if (!referenceFailure) return readback
            const note = referenceFailure.tests?.[0]?.reason
            const retained = {
              response: JSON.stringify({ reference: referenceFailure.response, decrqss: readback.response }),
              note,
            }
            return readback.observation
              ? {
                  ...readback,
                  ...retained,
                  observation: {
                    ...readback.observation,
                    note: [note, readback.observation.note].filter(Boolean).join("; "),
                  },
                }
              : { ...readback, ...retained }
          }
        }
        if (ctx.capture) {
          if (regionReadback) {
            // Qualification cannot be retried after the query reset. Keep the existing named
            // refusal: a silent DECRQSS never reaches the old reset-derived frames.
            const { savedRendition: _savedRendition, ...fallback } = regionReadback
            const verdict = await captureRegionCallbackResult(ctx, "reset.sgr", fallback, readbackAttempted)
            if (verdict) {
              if (!referenceFailure) return verdict
              return {
                pass: false,
                response: referenceFailure.response,
                tests: [
                  {
                    id: "criterion",
                    status: "probe-invalid",
                    reason: `${referenceFailure.tests?.[0]?.reason}; ${verdict.tests?.[0]?.reason}`,
                  },
                ],
              }
            }
          }
          try {
            return await sgrCaptureFrames(
              ctx,
              "\x1b[0m\x1b[2J\x1b[3;3H\x1b[1;3;7mX",
              "\x1b[0m\x1b[2J\x1b[3;3H\x1b[1;3;7mX\x1b[0mY",
              "reset.sgr",
              { setup: "\x1b[1;3;7m", reset: "\x1b[0m" },
              "The control shows a bold+italic+inverse X; the target adds reset Y; the capture alone does not decide the reset effect",
            )
          } finally {
            ctx.write("\x1b[0m")
          }
        }
        if (!measuredRoom) {
          return {
            pass: false,
            tests: [
              {
                id: "criterion",
                status: "probe-todo",
                reason: `Reset fixture needs at least 1x2, measured ${ctx.rows}x${ctx.cols}`,
              },
            ],
          }
        }
        ctx.write("\x1b[1;1H\x1b[2K")
        ctx.write("\x1b[1m") // bold
        ctx.write("\x1b[0m") // reset
        ctx.write("X")
        const pos = await ctx.queryCursorPosition()
        if (!pos) {
          return replyFailure(
            "no parsable cursor position reply; the public projection returned null and retained no bytes",
          )
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          tests: [
            {
              id: "criterion",
              status: "probe-todo",
              reason: `Cursor advance does not measure SGR styling after reset${ctx.captureGeometryRefusal ? `; Pixel capture unavailable: ${ctx.captureGeometryRefusal}` : ""}`,
            },
          ],
        }
      },
    ),
    termNeedsGeometry: true,
    // Hosted Mac run 42836445788 still had this callback running at 30s.
    wallMs: 120_000,
  },

  {
    ...probe(
      "reset.ris",
      (ctx) => {
        ctx.feed("Hello World")
        const before = { ...ctx.getCursor(), text: ctx.getText() }
        ctx.feed("\x1bc")
        const after = { ...ctx.getCursor(), text: ctx.getText() }
        const expected = "RIS returns the cursor home and clears measured text"
        if (!before.text.includes("Hello World") || before.x === 0) {
          return parserStateResult(null, expected, { before, after }, "RIS control state was not measured")
        }
        return parserStateResult(after.x === 0 && after.y === 0 && !after.text.includes("Hello World"), expected, {
          before,
          after,
        })
      },
      async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 5 || ctx.cols < 5) {
          return {
            pass: false,
            tests: [
              {
                id: "criterion",
                status: "probe-todo",
                reason: `Reset fixture needs at least 5x5, measured ${ctx.rows}x${ctx.cols}`,
              },
            ],
          }
        }
        ctx.write("\x1b[5;5H") // Move somewhere away from 1;1
        const before = await ctx.queryCursorPosition()
        if (!before) {
          return replyFailure(
            "no parsable cursor position reply; the public projection returned null and retained no bytes",
          )
        }
        ctx.write("\x1bc") // RIS — full reset
        const pos = await ctx.queryCursorPosition()
        if (!pos) {
          return replyFailure(
            "no parsable cursor position reply; the public projection returned null and retained no bytes",
          )
        }
        const measured = { before, after: pos }
        const setup = before.row === 5 && before.col === 5
        const home = pos.row === 1 && pos.col === 1
        return {
          pass: setup && home,
          response: JSON.stringify(measured),
          observation: {
            outcome: setup ? (home ? "supported" : "unsupported") : "inconclusive",
            ...(setup ? {} : { reason: "insufficient-evidence" as const }),
            assertionType: "query_reply",
            note: "Measured RIS cursor reset; other reset effects were not inspected",
          },
          ...(setup && {
            assertions: [
              {
                assertionType: "query_reply" as const,
                kind: home ? ("positive" as const) : ("negative" as const),
                expected: "RIS homes cursor from 5;5",
                observed: JSON.stringify(measured),
              },
            ],
          }),
        }
      },
    ),
    termNeedsGeometry: true,
  },

  {
    ...probe(
      "reset.soft",
      (ctx) => {
        ctx.feed("\x1b[?1h") // enable application cursor
        const before = ctx.getMode("applicationCursor")
        ctx.feed("Hello")
        ctx.feed("\x1b[!p")
        const after = ctx.getMode("applicationCursor")
        // #30701, @cto ruling C: a getMode that reports no applicationCursor state is a field the backend
        // does not expose (PROBE TODO); an exposed mode that stayed off is still unmeasured.
        if (before === null || after === null) {
          const noObservable = "The headless getMode readback exposes no application-cursor mode (DECCKM) state"
          return reviewResult(
            HEADLESS_OBSERVABLE_REVIEW,
            `${noObservable}, so this run cannot decide it`,
            noObservable,
            {
              before,
              after,
            },
          )
        }
        return parserStateResult(
          before ? !after : null,
          "DECSTR clears an enabled application-cursor mode",
          { before, after },
          before ? undefined : "Application-cursor mode was not enabled before DECSTR",
        )
      },
      async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 5 || ctx.cols < 5) {
          return {
            pass: false,
            tests: [
              {
                id: "criterion",
                status: "probe-todo",
                reason: `Reset fixture needs at least 5x5, measured ${ctx.rows}x${ctx.cols}`,
              },
            ],
          }
        }
        const before = await queryDecrpm(ctx, 1)
        if (before === null || before === 0) {
          const { input, readInput } = ctx
          if (!input || !readInput) {
            const reason = "Soft-reset effect needs owned key injection and input readback"
            if (before === null) return replyFailure(reason)
            // Ps 0 is a complete reply; missing actuation is not a failed reply window.
            return {
              pass: false,
              response: JSON.stringify({ before }),
              note: `DECRPM mode 1 returned Ps 0; ${reason}`,
              tests: [{ id: "criterion", status: "probe-invalid", reason }],
            }
          }
          const readUp = async () =>
            (
              await readInput(/^(?:\x1b(?:\[|O)A)?a$/, 1000, async () => {
                await input.injectKey("Up")
                await input.injectKey("a")
              })
            )?.[0]
          try {
            ctx.write("\x1b[?1l")
            const control = await readUp()
            ctx.write("\x1b[?1h")
            const enabled = await readUp()
            if (control !== "\x1b[Aa" || enabled !== "\x1bOAa") {
              return {
                ...replyFailure(
                  "Soft-reset setup did not read distinct normal/application Up encodings with plain-a delivery controls",
                ),
                response: JSON.stringify({ before, control, enabled }),
              }
            }
            ctx.write("\x1b[!p")
            const after = await readUp()
            const response = JSON.stringify({ before, control, enabled, after })
            if (after !== "\x1b[Aa" && after !== "\x1bOAa") {
              return {
                ...replyFailure(
                  "Soft-reset target did not read an Up encoding followed by its plain-a delivery control",
                ),
                response,
              }
            }
            const pass = after === "\x1b[Aa"
            const note = `${before === 0 ? "DECRPM mode 1 returned Ps 0" : "No usable DECRPM reply for mode 1"}; DECSTR ${pass ? "cleared" : "did not clear"} the qualified application-cursor input effect`
            return {
              pass,
              response,
              note,
              observation: { outcome: pass ? "supported" : "unsupported", assertionType: "input_bytes", note },
              assertions: [
                {
                  assertionType: "input_bytes",
                  action: "reset.soft:decckm-reset-set-up",
                  kind: "positive",
                  expected: "Up+a changes from CSI A+a to SS3 A+a with DECCKM enabled",
                  observed: JSON.stringify({ control, enabled }),
                },
                {
                  assertionType: "input_bytes",
                  action: "reset.soft:decstr-up",
                  kind: pass ? "positive" : "negative",
                  expected:
                    "DECSTR returns the qualified SS3 Up encoding to normal CSI Up; injected plain a still arrives",
                  observed: response,
                },
              ],
            }
          } finally {
            // Unknown incoming state is confined to this disposable fixture's canonical normal-key setup.
            ctx.write("\x1b[?1l")
          }
        }
        ctx.write("\x1b[?1h")
        try {
          const enabled = await queryDecrpm(ctx, 1)
          ctx.write("\x1b[!p") // DECSTR — soft reset
          const after = await queryDecrpm(ctx, 1)
          // The stored readings keep the Ps (#30557 r2).
          const reading = (ps: DecrpmPs | null) => (ps === null ? null : decrpmReading(ps))
          const measured = { before: reading(before), enabled: reading(enabled), after: reading(after) }
          if (!(enabled === 1 || enabled === 3) || after === null || after === 0) {
            return {
              pass: false,
              response: JSON.stringify(measured),
              observation: {
                outcome: "inconclusive",
                reason: "insufficient-evidence",
                assertionType: "query_reply",
                note:
                  enabled === 4
                    ? "DECCKM is permanently reset (Ps 4); the terminal cannot enable it, so DECSTR's reset of it is unmeasured"
                    : "Application-cursor mode setup or reset readback was unavailable",
              },
            }
          }
          const pass = after === 2 || after === 4
          return {
            pass,
            response: JSON.stringify(measured),
            observation: { outcome: pass ? "supported" : "unsupported", assertionType: "query_reply" },
            assertions: [
              {
                assertionType: "query_reply" as const,
                kind: pass ? "positive" : "negative",
                expected: "DECSTR resets previously enabled DECCKM mode 1",
                observed: JSON.stringify(measured),
              },
            ],
          }
        } finally {
          if (before === 1 || before === 3) ctx.write("\x1b[?1h")
          else ctx.write("\x1b[?1l")
        }
      },
    ),
    termNeedsGeometry: true,
    termNeedsDisposable: true,
  },

  // DECALN — screen alignment test (fill screen with 'E')
  {
    ...probe(
      "reset.decaln",
      (ctx) => {
        ctx.feed("\x1b#8") // DECALN — fill screen with 'E'
        const cell = ctx.getCell(0, 0)
        return parserStateResult(cell.char === "E", "DECALN fills the measured cell (0,0) with E", { cell })
      },
      async (ctx) => {
        const rows = ctx.rows
        const cols = ctx.cols
        const capture = ctx.capture
        const readback = decalnReadback(rows, cols)
        if (readback) {
          // The verdict path owns this row wherever the run can map cells onto its own window.
          const verdict = await captureRegionCallbackResult(ctx, "reset.decaln", readback)
          if (verdict) return verdict
        }
        if (!capture || !Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 2 || cols < 2) {
          const note = `DECALN pixel fixture needs capture and measured 2x2 geometry; measured ${rows}x${cols}`
          return {
            pass: false,
            note,
            tests: [{ id: "criterion", status: "probe-todo", reason: note }],
          }
        }
        const seed = "AB".repeat(Math.ceil(cols / 2)).slice(0, cols)
        // The collector owns a disposable screen; cleanup does not claim restoration of arbitrary prior content.
        try {
          ctx.write("\x1b[0m\x1b[2J\x1b[H")
          for (let row = 1; row <= rows; row++) ctx.write(`\x1b[${row};1H${seed}`)
          ctx.write("\x1b[H")
          const control = await capture({ role: "control", label: "Known non-E AB grid before DECALN" })
          ctx.write("\x1b#8")
          const postAlignmentCursor = await ctx.queryCursorPosition()
          const target = await capture({ role: "target", label: "DECALN alignment grid after ESC # 8" })
          const delayedCaptureMs = 5000
          await new Promise<void>((resolve) => {
            setTimeout(resolve, delayedCaptureMs)
          })
          const delayedTarget = await capture({
            role: "target",
            label: "DECALN alignment grid after delayed checkpoint",
          })
          ctx.write("\x1b[H")
          const cursorOnlyControl = await capture({ role: "control", label: "Cursor-only control after CUP home" })
          ctx.write("X")
          const redrawControl = await capture({ role: "control", label: "Redraw control after one ordinary glyph" })
          const observed = JSON.stringify({
            rows,
            cols,
            seed,
            postAlignmentCursor,
            control,
            target,
            delayedCaptureMs,
            delayedTarget,
            cursorOnlyControl,
            redrawControl,
          })
          return {
            pass: false,
            response: observed,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              assertionType: "screenshot",
              screenshotRef: target.ref,
              frames: [control, target, delayedTarget, cursorOnlyControl, redrawControl],
              note: `${postAlignmentCursor === null ? "No post-DECALN CPR response; processing barrier unconfirmed. " : ""}Known non-E grid, initial and delayed DECALN targets, cursor-only control and ordinary-glyph redraw control captured; no same-run pixel check decides whether E glyphs repeat across measured rows and columns. CPR at the already-homed cursor records responsiveness, not DECALN recognition or render completion`,
            },
            assertions: [
              {
                assertionType: "screenshot" as const,
                kind: "positive",
                expected: `Control shows alternating A/B across ${rows} rows and ${cols} columns; DECALN target shows repeated E across that same measured grid`,
                observed,
                note: "capture-only assertion; glyphs and full-grid coverage must be independently reviewed",
              },
            ],
          }
        } finally {
          ctx.write("\x1b[0m\x1b[2J\x1b[H")
        }
      },
    ),
    termNeedsGeometry: true,
    cellReadback: true,
    textClaim: "characters",
  },

  {
    ...probe(
      "reset.method",
      (ctx) => {
        ctx.feed("Hello World")
        const before = { ...ctx.getCursor(), text: ctx.getText() }
        ctx.reset()
        const after = { ...ctx.getCursor(), text: ctx.getText() }
        const expected = "Reset method returns the cursor home and clears measured text"
        if (!before.text.includes("Hello World") || before.x === 0) {
          return parserStateResult(null, expected, { before, after }, "Reset-method control state was not measured")
        }
        return parserStateResult(after.x === 0 && after.y === 0 && !after.text.includes("Hello World"), expected, {
          before,
          after,
        })
      },
      () => {
        const note = "The app context has no reset() method or equivalent state readback"
        return Promise.resolve(declaredUntestableResult(note, {}))
      },
    ),
  },
]
