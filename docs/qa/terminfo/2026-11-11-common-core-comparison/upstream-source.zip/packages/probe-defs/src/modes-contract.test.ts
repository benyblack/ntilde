/**
 * @failure A Modes feature is graded without a bound contract row, or a re-grade of a decided
 *   observation moves it - so a group step reinvents its own fixture and silently drifts.
 * @level l2
 * @consumer 28450 slice B Modes group (29 definitions); 28453 harness. Outside Candidate-2 denominator 125.
 * @reach fs-walk vendor/terminfo.dev/packages/probe-defs/src/modes-contract.test.ts vendor/terminfo.dev/packages/probe-defs/src/modes-observations.test.ts vendor/terminfo.dev/packages/probe-defs/src/modes-geometry.test.ts vendor/terminfo.dev/packages/probe-defs/src/testing/semantic-surface.ts
 * @testonly none
 */
import { expect, test } from "vitest"
import { join } from "node:path"
import { decrpmStatus, NO_SAME_PATH_CONTROL } from "./helpers.ts"
import { modesProbes } from "./modes.ts"
import { createSemanticSurface } from "./testing/semantic-surface.ts"
import {
  contractGaps,
  inertLibProbeSource,
  libProbeSource,
  missingContractTests,
  regradeCommand,
  regradeRow,
  replayTermProbeSource,
  satisfiesContract,
  type GroupContract,
  type GroupContractSpec,
  type StoredQuery,
} from "./testing/group-harness.ts"

/** The 29 Modes features of 28450 slice B; ids drawn from modes.ts, claims are the contract. */
const MODES_CONTRACT: GroupContract = [
  { id: "modes.alt-screen.enter", expected: "decided", claim: "DECRPM 1049 recognizes alt-screen enter" },
  {
    id: "modes.alt-screen.exit",
    expected: "inconclusive",
    claim: "Alt-screen exit buffer restore needs pixel review; CPR after exit does not measure the buffer",
  },
  { id: "modes.bracketed-paste", expected: "decided", claim: "DECRPM 2004 recognizes bracketed paste" },
  { id: "modes.application-cursor", expected: "decided", claim: "DECRPM 1 recognizes application cursor keys" },
  { id: "modes.auto-wrap", expected: "decided", claim: "DECRPM 7 recognizes auto-wrap" },
  { id: "modes.mouse-tracking", expected: "decided", claim: "DECRPM 1000 recognizes mouse tracking" },
  {
    id: "modes.focus-tracking",
    expected: "inconclusive",
    claim: "Focus delivery needs the owned focus roundtrip fixture absent from DECRPM replay",
  },
  { id: "modes.reverse-video", expected: "decided", claim: "DECRPM 5 recognizes reverse video" },
  { id: "modes.synchronized-output", expected: "decided", claim: "DECRPM 2026 recognizes synchronized output" },
  {
    id: "modes.origin",
    expected: "inconclusive",
    claim: "Margin-relative addressing needs the controlled grid fixture and an owned capture adapter",
  },
  {
    id: "modes.insert-replace",
    expected: "inconclusive",
    claim: "Insert/replace mode needs a measured cell-shift fixture, not DECRPM alone",
  },
  { id: "modes.mouse-sgr", expected: "decided", claim: "DECRPM 1006 recognizes SGR mouse" },
  { id: "modes.mouse-all", expected: "decided", claim: "DECRPM 1003 recognizes all-motion mouse" },
  {
    id: "modes.application-keypad",
    expected: "decided",
    claim:
      "Application keypad: KP_Add reports SS3 k after ESC = and + after ESC >, after plain-a delivery control; + under both is unsupported",
  },
  {
    id: "modes.left-right-margin",
    expected: "inconclusive",
    claim: "Left/right margin mode needs a measured geometry fixture",
  },
  {
    id: "modes.altscreen-47",
    expected: "inconclusive",
    claim: "Alt-screen 47 buffer restore needs pixel review",
  },
  {
    id: "modes.altscreen-1047",
    expected: "inconclusive",
    claim: "Alt-screen 1047 buffer restore needs pixel review",
  },
  {
    id: "modes.altscreen-1048",
    expected: "inconclusive",
    claim: "Alt-screen 1048 cursor save/restore needs pixel review",
  },
  {
    id: "modes.alt-scroll-1007",
    expected: "decided",
    claim:
      "Alt-scroll 1007: wheel-4 reports CSI A after 1000+1006 click delivery control on alt-screen; remaining SGR is unsupported",
  },
  {
    id: "modes.utf8-mouse-1005",
    expected: "inconclusive",
    claim: "UTF8 mouse needs the owned sensitive-position resize fixture absent from DECRPM replay",
  },
  { id: "modes.deccolm", expected: "decided", claim: "Cell width moves 80 -> 132 -> 80 with ?40 honoured" },
  { id: "modes.decsclm", expected: "decided", claim: "DECRPM 4 recognizes smooth-scroll mode" },
  { id: "modes.color-scheme-reporting", expected: "decided", claim: "DECRPM 2031 recognizes color-scheme reporting" },
  {
    id: "modes.xtpushsgr",
    expected: "inconclusive",
    claim: "XTPUSHSGR stack roundtrip needs independent pixel review of both attributes",
  },
  {
    id: "modes.xtpopsgr",
    expected: "inconclusive",
    claim: "XTPOPSGR stack roundtrip needs independent pixel review of both attributes",
  },
  {
    id: "modes.xtsave",
    expected: "inconclusive",
    claim: "XTSAVE wrap restore needs a measured overflow fixture",
  },
  {
    id: "modes.xtrestore",
    expected: "inconclusive",
    claim: "XTRESTORE wrap restore needs a measured overflow fixture",
  },
  {
    id: "modes.xtpushcolors",
    expected: "inconclusive",
    claim: "XTPUSHCOLORS roundtrip needs independent pixel review",
  },
  {
    id: "modes.xtpopcolors",
    expected: "inconclusive",
    claim: "XTPOPCOLORS roundtrip needs independent pixel review",
  },
  {
    id: "modes.decsscls",
    expected: "decided",
    claim:
      "DECSSCLS: with a stable jump control, a target whose marker band reaches its settled row between a frame inside the measured throttled window and one after it scrolls at 9 lines/s, and a band already in place inside that window ignores the rate",
  },
]

test.each([
  "modes.alt-screen.exit",
  "modes.insert-replace",
  "modes.altscreen-1048",
  "modes.xtpushsgr",
  "modes.xtpopsgr",
  "modes.xtsave",
  "modes.xtrestore",
  "modes.xtpushcolors",
  "modes.xtpopcolors",
])("%s marks a null cursor projection without inferring silence", async (id) => {
  const definition = modesProbes.find((entry) => entry.id === id)!
  const positions =
    id === "modes.altscreen-1048"
      ? [
          { row: 5, col: 10 },
          { row: 15, col: 20 },
        ]
      : []
  const result = await definition.term!(
    replayTermProbeSource(new Map(), { queryCursorPosition: async () => positions.shift() ?? null }),
  )
  expect(result).toHaveProperty("replyFailureTestIds", ["criterion"])
  expect(result.tests?.[0]).toMatchObject({
    status: "probe-invalid",
    reason: expect.stringContaining("no parsable cursor position reply"),
  })
})

test.each([null, 0, 4])("alternate-buffer Ps %s keeps null distinct from usable mode replies", async (ps) => {
  const definition = modesProbes.find((entry) => entry.id === "modes.altscreen-1047")!
  const replies = new Map<string, StoredQuery>(
    ps === null
      ? []
      : [
          [
            "\x1b[?1047$p",
            {
              sequence: "\x1b[?1047$p",
              match: [`\x1b[?1047;${ps}$y`, String(ps)],
              raw: `\x1b[?1047;${ps}$y`,
              reason: "reply",
            },
          ],
        ],
  )
  const result = await definition.term!(replayTermProbeSource(replies))
  if (ps === null) {
    expect(result).toHaveProperty("replyFailureTestIds", ["criterion"])
    expect(result.tests?.[0]?.reason).toContain("no usable DECRPM reply")
  } else {
    expect(result).not.toHaveProperty("replyFailureTestIds")
    expect(result.observation?.outcome).toBe(ps === 4 ? "unsupported" : "inconclusive")
  }
})

const MODES_CONTRACT_SPEC: GroupContractSpec = {
  group: "modes",
  rows: MODES_CONTRACT,
  tests: [
    "packages/probe-defs/src/modes-contract.test.ts",
    "packages/probe-defs/src/modes-observations.test.ts",
    "packages/probe-defs/src/modes-geometry.test.ts",
    "packages/probe-defs/src/input-xtest-observations.test.ts",
  ],
}

/** Every private DECRQM answers Ps; queryMode keeps the fold for the arms that only ask whether a mode is on. */
function modeQuerySource(ps: 0 | 1 | 2 | 3 | 4 | null) {
  const reply = (sequence: string) => {
    const mode = /^\x1b\[\?(\d+)\$p$/.exec(sequence)?.[1]
    return mode === undefined || ps === null ? "" : `\x1b[?${mode};${ps}$y`
  }
  return replayTermProbeSource(new Map(), {
    queryMode: async () => (ps === null ? null : decrpmStatus(String(ps))),
    queryWithSentinel: async (sequence, pattern) => {
      const raw = reply(sequence)
      return raw === "" ? null : pattern.exec(raw)
    },
    queryWithSentinelOutcome: async (sequence, pattern) => {
      const raw = reply(sequence)
      return {
        match: raw === "" ? null : pattern.exec(raw),
        reason: raw === "" ? "timeout" : "reply",
        raw,
        rawBase64: "",
      }
    },
  })
}

function modesTermSource(id: string) {
  if (id === "modes.application-keypad") {
    // KP_Add answers SS3 k under DECKPAM, then + under DECKPNM (#32582); each run reads it twice, and the replay runs twice.
    let keypadReads = 0
    return replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async (pattern: RegExp) => {
        if (pattern.test("a")) return ["a"]
        keypadReads += 1
        const report = keypadReads % 2 === 1 ? "\x1bOk" : "+"
        return pattern.test(report) ? [report] : null
      },
    })
  }
  if (id === "modes.alt-scroll-1007") {
    let callCount = 0
    return replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async (pattern: RegExp) => {
        callCount += 1
        const report = callCount % 2 === 1 ? "\x1b[<0;10;5M" : "\x1b[A"
        if (pattern.test(report)) return [report]
        return null
      },
    })
  }
  if (id === "modes.decsscls") {
    let calls = 0
    const rectangle = { x: 0, y: 0, width: 800, height: 440 }
    return replayTermProbeSource(new Map(), {
      captureGeometry: {
        geometry: { cellWidth: 10, cellHeight: 20, textWidth: 800, textHeight: 480 },
        source: "measured by complete raster calibration",
      },
      capture: async ({ role, label, cells }) => {
        calls += 1
        const bandFrame = cells !== undefined && cells.top === cells.bottom
        const ref = bandFrame
          ? label === "DECSSCLS marker reference" || label.includes("jump control") || label.endsWith("t1 band")
            ? "marker-ref"
            : "no-band"
          : label.includes("jump")
            ? "jump-settled"
            : label.endsWith("t0")
              ? "slow-t0"
              : "slow-t1"
        return {
          role,
          label,
          capturedAt: calls,
          ref,
          regionDigest: ref,
          pixelsDigest: `whole:${ref}`,
          regionRectangle: rectangle,
        }
      },
    })
  }
  return modeQuerySource(1)
}

test("the Modes contract covers every Modes feature and names none unknown", () => {
  const gaps = contractGaps(modesProbes, MODES_CONTRACT)
  expect(gaps.uncovered).toEqual([])
  expect(gaps.unknown).toEqual([])
  expect(gaps.misdeclared).toEqual([])
  expect(modesProbes).toHaveLength(30)
  expect(MODES_CONTRACT).toHaveLength(30)
})

test("the Modes contract names its focused tests, and every named file exists", () => {
  const root = join(import.meta.dirname, "../../..")
  expect(missingContractTests(MODES_CONTRACT_SPEC, root)).toEqual([])
  const command = regradeCommand(MODES_CONTRACT_SPEC)
  expect(command).toContain("bunx --bun vitest run")
  expect(command).not.toContain("bun test")
  expect(command).not.toMatch(/[*?]/u)
  for (const path of MODES_CONTRACT_SPEC.tests) expect(command).toContain(path)
})

test("the harness replays every Modes feature deterministically through DECRPM replay", async () => {
  const headless = libProbeSource({
    cols: 80,
    feed: () => {},
    feedCapture: () => "",
    getCell: () => {
      throw new Error("Missing timing and event facilities cannot be established from cells")
    },
    getCursor: () => ({ x: 0, y: 0, visible: true, style: null }),
  })
  for (const row of MODES_CONTRACT) {
    const term = modesTermSource(row.id)
    const probe = modesProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing Modes probe ${row.id}`).toBeDefined()
    if (!probe) continue
    if (row.id === "modes.decsclm") {
      const result = probe.lib!(headless)
      expect(result.criterionBranch, row.id).toBe("os-input-review")
      expect(result.tests, row.id).toMatchObject([{ id: "review", status: "probe-todo" }])
      expect((await regradeRow(probe, row, { headless })).after, row.id).toBeUndefined()
    }
    expect(probe.lib !== null || probe.term !== null, `${row.id} has no callback`).toBe(true)
    const first = await regradeRow(probe, row, { term })
    const second = await regradeRow(probe, row, { term })
    expect(second.after, `${row.id} is not deterministic`).toBe(first.after)
    expect(second.satisfies, `${row.id} satisfaction is not deterministic`).toBe(first.satisfies)
    expect(first.satisfies, `${row.id} must route through satisfiesContract`).toBe(satisfiesContract(row, first.after))
  }
}, 20_000)

test("each Modes row retains its measured grade or named execution disposition under the replay fixture", async () => {
  for (const row of MODES_CONTRACT) {
    const term = modesTermSource(row.id)
    const probe = modesProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing Modes probe ${row.id}`).toBeDefined()
    if (!probe) continue
    if (row.id === "modes.focus-tracking" || row.id === "modes.utf8-mouse-1005") {
      const result = await probe.term?.(term)
      expect(result?.observation).toBeUndefined()
      expect(result?.notTested).toMatchObject({ reason: "no-semantic-observable" })
      expect(result?.notTested?.noObservable).toContain("owned")
      continue
    }
    if (row.id === "modes.alt-screen.exit") {
      const result = await probe.term?.(term)
      expect(result?.observation).toBeUndefined()
      expect(result?.assertions).toBeUndefined()
      expect(result?.tests).toMatchObject([
        expect.objectContaining({
          status: "probe-invalid",
          reason: "no parsable cursor position reply; the public projection returned null and retained no bytes",
        }),
      ])
      continue
    }
    if (row.id === "modes.origin" || row.id === "modes.left-right-margin") {
      const result = await probe.term?.(term)
      expect(result?.observation).toBeUndefined()
      expect(result?.assertions).toBeUndefined()
      expect(result?.tests).toMatchObject([
        expect.objectContaining({
          status: "probe-todo",
          reason:
            row.id === "modes.origin"
              ? "modes.origin: no owned capture adapter is installed in this run, so the region fixture cannot be read back"
              : "Margin mode left unchanged; this probe does not measure left/right margin behavior",
        }),
      ])
      continue
    }
    if (row.id === "modes.insert-replace") {
      const result = await probe.term?.(term)
      expect(result?.observation).toBeUndefined()
      expect(result?.assertions).toBeUndefined()
      expect(result?.tests).toMatchObject([
        expect.objectContaining({
          status: "probe-invalid",
          reason: "no parsable cursor position reply; the public projection returned null and retained no bytes",
        }),
      ])
      continue
    }
    if (row.id === "modes.altscreen-47" || row.id === "modes.altscreen-1048") {
      if (!probe.term) throw new Error(`${row.id}: expected the application callback`)
      const result = await probe.term(term)
      expect(result.observation).toBeUndefined()
      expect(result.assertions).toBeUndefined()
      expect(result.tests).toEqual([
        {
          id: "criterion",
          status: row.id === "modes.altscreen-47" ? "probe-todo" : "probe-invalid",
          reason:
            row.id === "modes.altscreen-47"
              ? "Alternate buffer left unchanged; this probe does not measure its visible contents"
              : "no parsable cursor position reply; the public projection returned null and retained no bytes",
        },
      ])
      continue
    }
    if (
      [
        "modes.xtpushsgr",
        "modes.xtpopsgr",
        "modes.xtsave",
        "modes.xtrestore",
        "modes.xtpushcolors",
        "modes.xtpopcolors",
      ].includes(row.id)
    ) {
      if (!probe.term) throw new Error(`${row.id}: expected the application callback`)
      const result = await probe.term(term)
      expect(result.observation).toBeUndefined()
      expect(result.assertions).toBeUndefined()
      expect(result.tests).toEqual([
        {
          id: "criterion",
          status: "probe-invalid",
          reason: "no parsable cursor position reply; the public projection returned null and retained no bytes",
        },
      ])
      continue
    }
    const graded = await regradeRow(probe, row, { term })
    expect(graded.satisfies, `${row.id} satisfies its contract row (after=${graded.after})`).toBe(true)
  }
}, 20_000)

test("a decided Modes row is unsatisfied when DECRPM is silent and its effect control is absent", async () => {
  const row = MODES_CONTRACT.find((entry) => entry.id === "modes.auto-wrap")
  const probe = modesProbes.find((entry) => entry.id === "modes.auto-wrap")
  expect(row, "the Modes contract names modes.auto-wrap").toBeDefined()
  expect(probe, "the Modes contract names a real modes.auto-wrap probe").toBeDefined()
  if (!row || !probe) return
  const silent = await regradeRow(probe, row, { term: modeQuerySource(null) })
  expect(silent.after).toBeUndefined()
  expect(silent.satisfies).toBe(false)
  const result = await probe.term?.(modeQuerySource(null))
  expect(result?.observation).toBeUndefined()
  expect(result?.assertions).toBeUndefined()
  expect(result?.tests).toMatchObject([
    expect.objectContaining({
      status: "probe-invalid",
      reason: "Auto-wrap cursor control did not measure home and ordinary text advancing to the right margin",
    }),
  ])
})

const MODES_SEMANTIC_SURFACE_CONTROLS: readonly (readonly [
  id: string,
  mutation: string,
  positiveOutcome: "supported" | "probe-todo",
  negativeOutcome: "unsupported" | "inconclusive",
])[] = [
  ["modes.alt-screen.enter", "altscreen-noop", "supported", "unsupported"],
  ["modes.alt-screen.exit", "altscreen-exit-noop", "supported", "inconclusive"],
  ["modes.bracketed-paste", "bracketed-paste-noop", "supported", "unsupported"],
  ["modes.application-cursor", "decckm-noop", "supported", "unsupported"],
  ["modes.auto-wrap", "decawm-noop", "supported", "unsupported"],
  ["modes.origin", "decom-noop", "supported", "unsupported"],
  ["modes.insert-replace", "irm-noop", "supported", "unsupported"],
  ["modes.reverse-video", "decscnm-noop", "supported", "unsupported"],
  ["modes.mouse-tracking", "mouse-1000-noop", "supported", "unsupported"],
  ["modes.focus-tracking", "focus-1004-noop", "supported", "unsupported"],
  ["modes.mouse-sgr", "mouse-1006-noop", "supported", "unsupported"],
  ["modes.synchronized-output", "sync-2026-noop", "supported", "unsupported"],
  ["modes.application-keypad", "deckpam-noop", "supported", "inconclusive"],
  ["modes.left-right-margin", "declrmm-noop", "supported", "unsupported"],
  ["modes.mouse-all", "mouse-1003-noop", "supported", "unsupported"],
  ["modes.utf8-mouse-1005", "mouse-1005-noop", "supported", "unsupported"],
  ["modes.alt-scroll-1007", "alt-scroll-1007-noop", "supported", "unsupported"],
  ["modes.altscreen-47", "altscreen-47-noop", "supported", "unsupported"],
  ["modes.altscreen-1047", "altscreen-1047-noop", "supported", "unsupported"],
  ["modes.altscreen-1048", "altscreen-1048-noop", "supported", "unsupported"],
  ["modes.deccolm", "deccolm-noop", "supported", "unsupported"],
  ["modes.decsclm", "decsclm-noop", "supported", "unsupported"],
  ["modes.xtpushsgr", "xtpushsgr-noop", "supported", "unsupported"],
  ["modes.xtpopsgr", "xtpopsgr-noop", "supported", "unsupported"],
  ["modes.xtsave", "xtsave-noop", "supported", "unsupported"],
  ["modes.xtrestore", "xtrestore-noop", "supported", "unsupported"],
  ["modes.xtpushcolors", "xtpushcolors-noop", "supported", "unsupported"],
  ["modes.xtpopcolors", "xtpopcolors-noop", "supported", "unsupported"],
  ["modes.color-scheme-reporting", "color-scheme-2031-noop", "supported", "unsupported"],
  // #32246: a consumed CSI 9 SP p with no visible effect has no same-path control, so it is PROBE TODO.
  ["modes.decsscls", "decsscls-noop", "probe-todo", "unsupported"],
]

test("MODES_SEMANTIC_SURFACE_CONTROLS covers all 30 Modes contract rows with distinct mutations", () => {
  expect(MODES_SEMANTIC_SURFACE_CONTROLS).toHaveLength(30)
  expect(MODES_SEMANTIC_SURFACE_CONTROLS.map(([id]) => id).sort()).toEqual(MODES_CONTRACT.map((row) => row.id).sort())
  expect(new Set(MODES_SEMANTIC_SURFACE_CONTROLS.map(([, mutation]) => mutation)).size).toBe(30)
})

test("the harness replays every Modes headless callback deterministically on createSemanticSurface", async () => {
  for (const row of MODES_CONTRACT) {
    const probe = modesProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing Modes probe ${row.id}`).toBeDefined()
    if (!probe) continue
    const first = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    const second = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    expect(second.after, `${row.id} is not deterministic`).toBe(first.after)
    expect(second.satisfies, `${row.id} satisfaction is not deterministic`).toBe(first.satisfies)
  }
})

test.each(MODES_SEMANTIC_SURFACE_CONTROLS)(
  "%s never reads supported on inertLibProbeSource, when %s is inactive reads %s on createSemanticSurface, and when active reads %s",
  async (id, mutation, positiveOutcome, negativeOutcome) => {
    const row = MODES_CONTRACT.find((entry) => entry.id === id)
    const probe = modesProbes.find((entry) => entry.id === id)
    expect(row, `the Modes contract names ${id}`).toBeDefined()
    expect(probe, `the Modes contract names a real ${id} probe`).toBeDefined()
    if (!row || !probe || !probe.lib) return

    const inertResult = probe.lib(inertLibProbeSource())
    expect(inertResult.pass).toBe(false)
    expect(inertResult.observation?.outcome).not.toBe("supported")
    if (id === "modes.decsscls") {
      expect(inertResult.criterionBranch).toBeUndefined()
    } else {
      const inertGraded = await regradeRow(probe, row, { headless: inertLibProbeSource() })
      expect(inertGraded.after).not.toBe("supported")
    }

    const positiveResult = probe.lib(libProbeSource(createSemanticSurface()))
    expect(positiveResult.pass).toBe(positiveOutcome === "supported")
    if (positiveOutcome === "supported") {
      expect(positiveResult.observation?.outcome).toBe(positiveOutcome)
      expect(positiveResult.assertions ?? []).toContainEqual(expect.objectContaining({ kind: "positive" }))
    } else {
      expect(positiveResult.observation).toBeUndefined()
      expect(positiveResult.criterionBranch).toBeUndefined()
      expect(positiveResult.notTested).toEqual({ reason: "no-semantic-observable", noObservable: NO_SAME_PATH_CONTROL })
    }
    const positiveGraded = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    expect(positiveGraded.after).toBe(positiveOutcome === "probe-todo" ? undefined : positiveOutcome)

    const negativeResult = probe.lib(libProbeSource(createSemanticSurface({ mutations: [mutation] })))
    expect(negativeResult.pass).toBe(false)
    expect(negativeResult.observation?.outcome).toBe(negativeOutcome)
    if (negativeOutcome === "unsupported") {
      expect(negativeResult.assertions ?? []).toContainEqual(expect.objectContaining({ kind: "negative" }))
    }
    const negativeGraded = await regradeRow(probe, row, {
      headless: libProbeSource(createSemanticSurface({ mutations: [mutation] })),
    })
    expect(negativeGraded.after).toBe(negativeOutcome)
  },
)

// #31904 (@cto 6e4f7300): each SGR-stack row grades its own operation. A stack that keeps a stale
// snapshot restores the POP fixture but returns the earlier state in the PUSH fixture, so only the
// push row is negative; the shared roundtrip graded both rows supported. A pop that resets to the
// default restores no non-default state, so neither row passes.
test.each([
  ["xtpushsgr-stale", "modes.xtpushsgr", "unsupported", "push saved no current snapshot"],
  ["xtpushsgr-stale", "modes.xtpopsgr", "supported", undefined],
  ["xtpopsgr-reset-default", "modes.xtpushsgr", "probe-todo", "no push-only observation"],
  ["xtpopsgr-reset-default", "modes.xtpopsgr", "probe-todo", "no pop-only observation"],
] as const)("%s grades %s %s on its own operation", (mutation, id, outcome, note) => {
  const probe = modesProbes.find((entry) => entry.id === id)!
  const result = probe.lib!(libProbeSource(createSemanticSurface({ mutations: [mutation] })))
  if (outcome === "probe-todo") expect(result.notTested).toMatchObject({ reason: "no-semantic-observable" })
  else expect(result.observation?.outcome).toBe(outcome)
  expect(result.pass).toBe(outcome === "supported")
  if (note) expect(result.note).toContain(note)
  if (outcome === "probe-todo") expect(result.assertions).toBeUndefined()
  else {
    expect(result.assertions?.[0]?.expected).toContain(id === "modes.xtpushsgr" ? "push time" : "restores the pushed")
  }
})

test.each(["modes.xtpushsgr", "modes.xtpopsgr"])(
  "%s carries the joint negative when neither fixture restores",
  (id) => {
    const probe = modesProbes.find((entry) => entry.id === id)!
    const result = probe.lib!(libProbeSource(createSemanticSurface({ mutations: ["xtpopsgr-noop"] })))
    expect(result.observation?.outcome).toBe("unsupported")
    expect(result.note).toBe("push then pop restored no earlier state")
    expect(result.assertions).toMatchObject([{ kind: "negative" }])
  },
)

// #31904 R3f: XTSAVE/XTRESTORE split with a restore control and an overwrite test (@cto 009e40cd).
// Wrap on is the DECAWM default, so a restore that resets to it restored nothing observable and
// both rows read the joint negative (@cto 0613b68d); on main it graded both rows supported.
test.each([
  ["xtsave-stale", "modes.xtsave", "unsupported", "save kept the earlier saved state"],
  ["xtsave-stale", "modes.xtrestore", "supported", undefined],
  ["xtrestore-reset-default", "modes.xtsave", "unsupported", "save then restore restored no earlier state"],
  ["xtrestore-reset-default", "modes.xtrestore", "unsupported", "save then restore restored no earlier state"],
  ["xtrestore-noop", "modes.xtsave", "unsupported", "save then restore restored no earlier state"],
  ["xtrestore-noop", "modes.xtrestore", "unsupported", "save then restore restored no earlier state"],
  ["xtrestore-always-off", "modes.xtsave", "probe-todo", "restoring always turned line wrap off, whatever we saved"],
  ["xtrestore-always-off", "modes.xtrestore", "unsupported", "restore returned DECAWM off after on was saved"],
] as const)("%s grades %s %s on its own operation", (mutation, id, outcome, note) => {
  const probe = modesProbes.find((entry) => entry.id === id)!
  const result = probe.lib!(libProbeSource(createSemanticSurface({ mutations: [mutation] })))
  if (outcome === "probe-todo") expect(result.notTested).toMatchObject({ reason: "no-semantic-observable" })
  else expect(result.observation?.outcome).toBe(outcome)
  expect(result.pass).toBe(outcome === "supported")
  if (note) expect(result.note).toContain(note)
  if (outcome === "probe-todo") expect(result.assertions).toBeUndefined()
  else {
    expect(result.assertions?.[0]?.expected).toContain(
      id === "modes.xtsave" ? "current at save time" : "restores the saved",
    )
  }
})

// #32476 (N-XTSAVE): on the audited vterm 0.13.1 engine identity, saving DECAWM on and saving DECAWM off restore the
// same value (DECAWM off, because screen.ts:2949 treats CSI ? Pm s and r as reset), so modes.xtsave grades unsupported.
test("vterm 0.13.1 grades modes.xtsave unsupported when saving on and saving off restore DECAWM off", () => {
  const probe = modesProbes.find((entry) => entry.id === "modes.xtsave")!
  const vterm0131Runtime = {
    kind: "js" as const,
    adapterVersion: "0.10.2",
    termlessRevision: "3d58d29a8265aafd928e0736dde6723e2bac2007",
    resolvedPath: "vendor/vterm/packages/vterm/src/index.ts",
    integrity: {
      kind: "source" as const,
      repository: "git@github.com:beorn/vterm.git",
      revision: "7b39f49e8a6bc03ce695c5ab7c143c2cc7379eb0",
      treeOid: "3d58d29a8265aafd928e0736dde6723e2bac2007",
      cleanTree: true,
    },
    runtimeFormat: "js" as const,
    engineVersion: "0.13.1",
  }
  const base = libProbeSource(createSemanticSurface({ mutations: ["xtrestore-always-off"] }))
  const result = probe.lib!({ ...base, backendName: "vterm", runtimeIdentity: vterm0131Runtime })
  expect(result.pass).toBe(false)
  expect(result.observation?.outcome).toBe("unsupported")
  expect(result.observation?.assertionType).toBe("buffer_state")
  expect(result.note).toContain("screen.ts:2949")
  expect(result.assertions).toMatchObject([{ assertionType: "buffer_state", kind: "negative" }])

  const driftedBase = libProbeSource(createSemanticSurface({ mutations: ["xtrestore-always-off"] }))
  const drifted = probe.lib!({
    ...driftedBase,
    backendName: "vterm",
    runtimeIdentity: {
      ...vterm0131Runtime,
      integrity: { ...vterm0131Runtime.integrity, treeOid: "f".repeat(40) },
    },
  })
  expect(drifted.notTested).toMatchObject({ reason: "no-semantic-observable" })
  expect(drifted.observation).toBeUndefined()
})

// #31904 R3e: the palette-stack rows split the same way as R3d (@cto 6e4f7300).
test.each([
  ["xtpushcolors-stale", "modes.xtpushcolors", "unsupported", "push saved no current snapshot"],
  ["xtpushcolors-stale", "modes.xtpopcolors", "supported", undefined],
  ["xtpopcolors-reset-default", "modes.xtpushcolors", "probe-todo", "no push-only observation"],
  ["xtpopcolors-reset-default", "modes.xtpopcolors", "probe-todo", "no pop-only observation"],
  ["xtpopcolors-noop", "modes.xtpushcolors", "unsupported", "push then pop restored no earlier state"],
  ["xtpopcolors-noop", "modes.xtpopcolors", "unsupported", "push then pop restored no earlier state"],
] as const)("%s grades %s %s on its own operation", (mutation, id, outcome, note) => {
  const probe = modesProbes.find((entry) => entry.id === id)!
  const result = probe.lib!(libProbeSource(createSemanticSurface({ mutations: [mutation] })))
  if (outcome === "probe-todo") expect(result.notTested).toMatchObject({ reason: "no-semantic-observable" })
  else expect(result.observation?.outcome).toBe(outcome)
  expect(result.pass).toBe(outcome === "supported")
  if (note) expect(result.note).toContain(note)
  if (outcome === "probe-todo") expect(result.assertions).toBeUndefined()
  else {
    expect(result.assertions?.[0]?.expected).toContain(
      id === "modes.xtpushcolors" ? "push time" : "restores the pushed",
    )
  }
})
