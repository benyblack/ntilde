/**
 * @failure Consumed SGR or an absent reply is reported as support, and measured parser/TTY state lacks a bound assertion.
 * @level l0
 * @consumer Shared app and headless probe definitions.
 * @testonly none
 */
import { expect, test } from "vitest"
import {
  decrpmModeProbe,
  cursorProbe,
  parserStateResult,
  recordExecutedProbe,
  NO_SAME_PATH_CONTROL,
  sgrProbe,
  sgrCaptureFrames,
  unmeasuredCellResult,
  type DecrpmPs,
} from "./helpers.ts"
import { sgrProbes } from "./sgr.ts"
import { resetProbes } from "./reset.ts"
import type { TermProbeSource, LibProbeSource, ProbeCallbackResult } from "./types.ts"

/**
 * #32246: a former source-review site no longer grades from source; it returns the PROBE TODO coverage record with
 * no observation, no negative assertion and no review branch.
 */
function expectNoSamePathTodo(result: ProbeCallbackResult, id?: string, noObservable = NO_SAME_PATH_CONTROL) {
  expect(result.pass, id).toBe(false)
  expect(result.notTested, id).toEqual({ reason: "no-semantic-observable", noObservable })
  expect(result.criterionBranch, id).toBeUndefined()
  expect(result.tests, id).toBeUndefined()
  expect(result.observation, id).toBeUndefined()
  expect(result.assertions, id).toBeUndefined()
}

test("a received cursor cannot measure changed cells and retains a named TODO", () => {
  const result = unmeasuredCellResult({ row: 2, col: 3 }, "changed cells")
  expect(result.tests).toContainEqual(
    expect.objectContaining({
      id: "review",
      status: "probe-todo",
      reason: "Cursor response does not measure changed cells",
    }),
  )
  expect(result.response).toBe("2;3")
})

const baseCell = {
  char: "X",
  bold: false,
  dim: false,
  italic: false,
  underline: false,
  underlineColor: null,
  strikethrough: false,
  inverse: false,
  hidden: false,
  blink: false,
  overline: null,
  fg: null,
  bg: null,
  wide: false,
}

const underlineColorUnexposed =
  "Open: we set an underline colour (SGR 58), but the screen cell shows none, so we cannot tell whether the library ignored it or does not report it."

// @failure Missing reset readback is interpreted as a measured reset (null becomes !null).
// @level l0
// @consumer DECSTR headless observations.
test("DECSTR retains unknown after-state instead of claiming a measured reset", () => {
  const probe = resetProbes.find((entry) => entry.id === "reset.soft")
  if (!probe?.lib) throw new Error("Missing reset.soft library arm")
  let reads = 0
  const result = probe.lib(headless({ getMode: () => (reads++ === 0 ? true : null) }))
  expect(result.observation).toBeUndefined()
  expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-todo" }))
})

function headless(overrides: Partial<LibProbeSource> = {}): LibProbeSource {
  return {
    backendName: "scripted-model",
    kind: "live",
    cols: 80,
    feed() {},
    feedCapture() {
      return ""
    },
    getCell() {
      return baseCell
    },
    getCursor() {
      return { x: 0, y: 0, visible: true, style: null }
    },
    getMode() {
      return false
    },
    getText() {
      return ""
    },
    getScrollback() {
      return { viewportOffset: 0, totalLines: 24, screenLines: 24 }
    },
    getTitle() {
      return ""
    },
    reset() {},
    capabilities: {
      truecolor: false,
      kittyKeyboard: false,
      kittyGraphics: false,
      sixel: false,
      osc8Hyperlinks: false,
      semanticPrompts: false,
      reflow: false,
      unicode: "unknown",
      extensions: new Set(),
    },
    ...overrides,
  }
}

function terminal(overrides: Partial<TermProbeSource> = {}): TermProbeSource {
  return {
    kind: "live",
    write() {},
    queryCursorPosition: async () => null,
    measureRenderedWidth: async () => ({ kind: "no-reply", step: "sample" }) as const,
    query: async () => null,
    queryWithSentinel: async () => null,
    queryOutcome: async () => ({ match: null, reason: "timeout", raw: "", rawBase64: "" }),
    queryWithSentinelOutcome: async () => ({ match: null, reason: "timeout", raw: "", rawBase64: "" }),
    queryMode: async () => null,
    cols: 80,
    rows: 24,
    ...overrides,
  }
}

test("app resets require measured effects and declare the backend-only reset method Untestable", async () => {
  const find = (id: string) => {
    const definition = resetProbes.find((entry) => entry.id === id)
    if (!definition?.term) throw new Error(`Missing ${id} app callback`)
    return definition.term
  }
  const sgr = await find("reset.sgr")(
    terminal({ rows: 24, cols: 80, queryCursorPosition: async () => ({ row: 1, col: 2 }) }),
  )
  expect(sgr.observation).toBeUndefined()
  expect(sgr).toMatchObject({
    tests: [
      expect.objectContaining({
        status: "probe-todo",
        reason: "Cursor advance does not measure SGR styling after reset",
      }),
    ],
  })
  expect(sgr.assertions ?? []).toEqual([])

  const risPositions = [
    { row: 5, col: 5 },
    { row: 1, col: 1 },
  ]
  const ris = await find("reset.ris")(
    terminal({ rows: 24, cols: 80, queryCursorPosition: async () => risPositions.shift() ?? null }),
  )
  expect(ris.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
  expect(ris.assertions).toMatchObject([{ kind: "positive", expected: "RIS homes cursor from 5;5" }])

  const writes: string[] = []
  const modeReplies = [2, 1, 2]
  let modeReplyIndex = 0
  const soft = await find("reset.soft")(
    terminal({
      rows: 24,
      cols: 80,
      write: (sequence) => writes.push(sequence),
      queryWithSentinel: async (_sequence, pattern) => {
        const ps = modeReplies[modeReplyIndex++]
        return ps === undefined ? null : pattern.exec(`\x1b[?1;${ps}$y`)
      },
    }),
  )
  expect(soft.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
  expect(soft.assertions).toMatchObject([{ kind: "positive" }])
  expect(soft.response).toBe(JSON.stringify({ before: "reset (Ps 2)", enabled: "set (Ps 1)", after: "reset (Ps 2)" }))
  expect(writes.at(-1)).toBe("\x1b[?1l")

  // #30557 r2: a DECCKM the terminal cannot enable (Ps 4) is named, instead of "readback was unavailable".
  const permanentWrites: string[] = []
  const permanent = await find("reset.soft")(
    terminal({
      rows: 24,
      cols: 80,
      write: (sequence) => permanentWrites.push(sequence),
      queryWithSentinel: async (_sequence, pattern) => pattern.exec("\x1b[?1;4$y"),
    }),
  )
  expect(permanent.observation).toMatchObject({
    outcome: "inconclusive",
    reason: "insufficient-evidence",
    assertionType: "query_reply",
    note: expect.stringContaining("permanently reset (Ps 4)"),
  })
  expect(permanent.response).toBe(
    JSON.stringify({
      before: "permanently reset (Ps 4)",
      enabled: "permanently reset (Ps 4)",
      after: "permanently reset (Ps 4)",
    }),
  )
  expect(permanentWrites.at(-1)).toBe("\x1b[?1l")

  const methodWrites: string[] = []
  const method = await find("reset.method")(terminal({ write: (sequence) => methodWrites.push(sequence) }))
  expect(method.observation).toBeUndefined()
  expect(method).toMatchObject({
    tests: [
      expect.objectContaining({
        status: "untestable",
        reason: "The app context has no reset() method or equivalent state readback",
      }),
    ],
  })
  expect(methodWrites).toEqual([])
  const recorded = recordExecutedProbe({
    featureId: "reset.method",
    attempt: { scope: "probe", startedAt: "2026-11-06T22:00:00.000Z" },
    coverage: method.notTested && { featureId: "reset.method", rawReplyRef: "reset.method", ...method.notTested },
    assertions: [],
    tests: method.tests,
    criterionBranch: method.criterionBranch,
    rawReplyRef: "reset.method",
  })
  expect(recorded.status).toBe("untestable")
  expect(recorded.tests[0]?.attempt.scope).toBe("probe")
})

// #30701 (@cto ruling C): the headless reset arms grade what the cells and modes expose. An adapter
// that never populates italic leaves SGR 0 graded on bold and inverse; one whose getMode reports no
// application-cursor state leaves DECSTR with no observable.
test("headless reset.sgr grades the measured styles and reset.soft needs an exposed mode", () => {
  const find = (id: string) => {
    const definition = resetProbes.find((entry) => entry.id === id)
    if (!definition?.lib) throw new Error(`Missing ${id} headless callback`)
    return definition.lib
  }
  const sgr = (before: Partial<typeof baseCell>, after: Partial<typeof baseCell> = {}) =>
    find("reset.sgr")(
      headless({
        getCell: (_row, col) => ({
          ...baseCell,
          ...[
            { char: "X", ...before },
            { char: "Y", ...after },
          ][col],
        }),
      }),
    )
  expect(sgr({ bold: true, inverse: true }).observation).toMatchObject({
    outcome: "supported",
    assertionType: "buffer_state",
    note: expect.stringContaining("italic"),
  })
  expect(sgr({ bold: true, inverse: true }, { inverse: true }).observation).toMatchObject({ outcome: "unsupported" })
  const unstyled = sgr({})
  expect(unstyled.observation).toBeUndefined()
  expect(unstyled.notTested?.noObservable).toContain("styled control")
  const soft = find("reset.soft")(headless({ getMode: () => null }))
  expect(soft.observation).toBeUndefined()
  expect(soft.notTested).toEqual({ reason: "no-semantic-observable", noObservable: expect.stringContaining("DECCKM") })
  expect(soft.criterionBranch).toBe("headless-observable-review")
  expect(soft.tests).toEqual([
    {
      id: "review",
      status: "probe-todo",
      reason:
        "The headless getMode readback exposes no application-cursor mode (DECCKM) state, so this run cannot decide it",
    },
  ])
  // An exposed mode that stayed off is unmeasured, never a coverage record.
  expect(find("reset.soft")(headless()).observation).toMatchObject({ outcome: "inconclusive" })
})

// Carrier B: existing tests never exercised null/false state with an explicit source-review request.
test("a former source-review request keeps PROBE TODO with its state and leaves omitted-argument results unchanged", () => {
  const state = { char: "X", dim: false }
  const response = '{"char":"X","dim":false}'
  const expected = "faint attribute applied"
  expect(JSON.stringify(parserStateResult(null, expected, state))).toBe(
    JSON.stringify({
      pass: false,
      response,
      observation: { outcome: "inconclusive", reason: "insufficient-evidence", assertionType: "buffer_state" },
    }),
  )
  expect(JSON.stringify(parserStateResult(false, expected, state))).toBe(
    JSON.stringify({
      pass: false,
      response,
      observation: { outcome: "unsupported", assertionType: "buffer_state" },
      assertions: [{ assertionType: "buffer_state", kind: "negative", expected, observed: response }],
    }),
  )
  const reason = "Cell readback cannot distinguish an absent style from an unreported attribute"
  for (const pass of [null, false]) {
    expect(parserStateResult(pass, expected, state, undefined, reason)).toEqual({
      pass: false,
      response,
      note: NO_SAME_PATH_CONTROL,
      notTested: { reason: "no-semantic-observable", noObservable: NO_SAME_PATH_CONTROL },
    })
  }
  expect(() => parserStateResult(true, expected, state, undefined, reason)).toThrow(/positive.*source review/i)
})

// Producer eligibility is independent of matching/writer tests: an unrendered fixture cannot be reviewed.
test("a former SGR source review keeps a rendered nonpositive cell PROBE TODO and preserves coverage", () => {
  const reason = "Cell readback cannot distinguish unsupported faint styling from an unreported attribute"
  const definition = sgrProbe("sgr.faint", "\x1b[2m", (cell) => cell.dim, undefined, undefined, reason)
  if (!definition.lib) throw new Error("Missing faint parser callback")
  const pending = definition.lib(headless())
  expectNoSamePathTodo(pending)
  const missing = definition.lib(headless({ getCell: () => ({ ...baseCell, char: "" }) }))
  expect(missing.criterionBranch).toBeUndefined()
  expect(missing.assertions).toBeUndefined()
  expect(missing.note).toBe("No rendered X cell to evaluate")
  const positive = definition.lib(headless({ getCell: () => ({ ...baseCell, dim: true }) }))
  expect(positive.criterionBranch).toBeUndefined()
  expect(positive.observation?.outcome).toBe("supported")
  const coverage = sgrProbe(
    "sgr.faint",
    "\x1b[2m",
    () => null,
    () => "No style observable",
    undefined,
    reason,
  )
  expect(coverage.lib?.(headless())).toMatchObject({
    notTested: { reason: "no-semantic-observable", noObservable: "No style observable" },
  })
  expect(coverage.lib?.(headless()).criterionBranch).toBeUndefined()
  for (const id of [
    "sgr.faint",
    "sgr.italic",
    "sgr.hidden",
    "sgr.strikethrough",
    "sgr.underline.double",
    "sgr.underline.curly",
    "sgr.underline.dotted",
    "sgr.underline.dashed",
  ]) {
    const definition = sgrProbes.find((probe) => probe.id === id)
    if (!definition?.lib) throw new Error(`Missing former source-review callback for ${id}`)
    expectNoSamePathTodo(definition.lib(headless()), id)
  }
})

test("SGR consumption stays inconclusive while headless cell state supports an assertion", async () => {
  const probe = sgrProbe("sgr.bold", "\x1b[1m", (cell) => cell.bold)
  if (!probe.term || !probe.lib) throw new Error("SGR needs both callbacks")

  const consumed = await probe.term(terminal({ queryCursorPosition: async () => ({ row: 1, col: 2 }) }))
  expect(consumed.pass).toBe(true)
  expect(consumed.observation).toBeUndefined()
  expect(consumed).toMatchObject({
    tests: [expect.objectContaining({ status: "probe-todo", reason: "Cursor advance does not verify SGR styling" })],
  })
  expect(consumed.assertions).toBeUndefined()

  const silent = await probe.term(terminal())
  expect(silent.observation).toBeUndefined()
  expect(silent.tests).toEqual([
    {
      id: "criterion",
      status: "probe-invalid",
      reason: "no parsable cursor position reply; the public projection returned null and retained no bytes",
    },
  ])

  const supported = probe.lib(headless({ getCell: () => ({ ...baseCell, bold: true }) }))
  expect(supported.observation).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
  expect(JSON.parse(supported.response ?? "")).toMatchObject({ char: "X", bold: true })
  expect(supported.assertions).toMatchObject([{ kind: "positive", observed: supported.response }])

  const unmeasured = probe.lib(headless())
  expect(unmeasured.observation).toMatchObject({ outcome: "inconclusive", assertionType: "buffer_state" })
  expect(JSON.parse(unmeasured.response ?? "")).toMatchObject({ char: "X", bold: false })
  expect(unmeasured.assertions).toBeUndefined()
})

// A consumed SGR and two screenshots are not comparable when the fixed text
// fixture wraps or lands outside the measured grid.
test("SGR app fixtures refuse undersized grids before writes and retain custom capture evidence", async () => {
  const definition = sgrProbe(
    "sgr.bold",
    "\x1b[1m",
    (cell) => cell.bold,
    undefined,
    undefined,
    undefined,
    (ctx, fixture) =>
      sgrCaptureFrames(
        ctx,
        `\x1b[0m\x1b[2J\x1b[3;3H${fixture.sample}`,
        `\x1b[0m\x1b[2J\x1b[3;3H${fixture.sequence}${fixture.sample}`,
        "sgr.bold",
        { sample: fixture.sample, startRow: 3, startCol: 3, sampleCells: fixture.sample.length },
        undefined,
        "Unstyled text sample",
      ),
  )
  if (!definition.term) throw new Error("Missing SGR app callback")

  for (const geometry of [
    { rows: 1, cols: 1, capture: false },
    { rows: 2, cols: 34, capture: true },
    { rows: 3, cols: 33, capture: true },
    { rows: Number.NaN, cols: 80, capture: false },
  ]) {
    const writes: string[] = []
    let queries = 0
    let captures = 0
    const result = await definition.term(
      terminal({
        rows: geometry.rows,
        cols: geometry.cols,
        write: (bytes) => writes.push(bytes),
        queryCursorPosition: async () => {
          queries++
          return { row: 1, col: 2 }
        },
        ...(geometry.capture && {
          capture: async ({ role, label }: { role: "control" | "target"; label: string }) => {
            captures++
            return { role, label, capturedAt: 1, ref: `sha256:${"a".repeat(64)}` }
          },
        }),
      }),
    )
    expect(result.observation, `${geometry.rows}x${geometry.cols}`).toBeUndefined()
    expect(result, `${geometry.rows}x${geometry.cols}`).toMatchObject({
      tests: [
        expect.objectContaining({
          status: "probe-todo",
          reason: `SGR fixture needs at least ${geometry.capture ? "3x34" : "1x2"}, measured ${geometry.rows}x${geometry.cols}`,
        }),
      ],
    })
    expect(result.response).toBeUndefined()
    expect(result.assertions).toBeUndefined()
    expect(writes).toEqual([])
    expect(queries).toBe(0)
    expect(captures).toBe(0)
  }
  expect(definition.termNeedsGeometry).toBe(true)

  const plainWrites: string[] = []
  const plain = await definition.term(
    terminal({
      rows: 1,
      cols: 2,
      write: (bytes) => plainWrites.push(bytes),
      queryCursorPosition: async () => ({ row: 1, col: 2 }),
    }),
  )
  expect(plain.observation).toBeUndefined()
  expect(plain).toMatchObject({
    tests: [expect.objectContaining({ status: "probe-todo", reason: "Cursor advance does not verify SGR styling" })],
  })
  expect(plainWrites.length).toBeGreaterThan(0)

  const captureWrites: string[] = []
  const roles: string[] = []
  const captured = await definition.term(
    terminal({
      rows: 3,
      cols: 34,
      write: (bytes) => captureWrites.push(bytes),
      capture: async ({ role, label }) => {
        roles.push(role)
        return { role, label, capturedAt: 1, ref: `sha256:${"a".repeat(64)}` }
      },
    }),
  )
  expect(captured.observation).toMatchObject({ outcome: "inconclusive", assertionType: "screenshot" })
  expect(JSON.parse(captured.response ?? "")).toMatchObject({
    sample: "AaBb 0123456789 - terminal text",
    startRow: 3,
    startCol: 3,
    sampleCells: 31,
    control: "Unstyled text sample",
    target: "sgr.bold",
  })
  expect(captured.observation?.frames).toHaveLength(2)
  expect(captured.pass).toBe(false)
  expect(captured.criterionBranch).toBe("visual-review")
  expect(captured.tests).toEqual([
    { id: "capture", status: "supported", assertionRefs: [0] },
    {
      id: "review",
      status: "probe-todo",
      reason: "Valid control and target capture; no same-run pixel check decides it",
    },
  ])
  expect(captured.assertions).toEqual([
    {
      kind: "positive",
      assertionType: "screenshot",
      expected: expect.any(String),
      observed: JSON.stringify({
        control: captured.observation?.frames?.[0],
        target: captured.observation?.frames?.[1],
      }),
    },
  ])
  expect(roles).toEqual(["control", "target"])
  expect(captureWrites.length).toBeGreaterThan(0)
})

// Every SGR capture fixture shares one guard, so a measured small terminal refuses before writes.
// The region fixture that now owns these rows needs a fourth row for its cursor park, so a 3-row
// terminal passes the guard and is then declined BY NAME. Saved-rendition references run first;
// the other reset rows retain the DECRQSS readback's attempted bytes before the region refusal.
test("SGR reset capture fixtures share the 3x34 guard and need a fourth row for the region fixture", async () => {
  const ids = [
    "sgr.fg.default",
    "sgr.bg.default",
    "sgr.underline-color-reset",
    "sgr.selective-reset.bold",
    "sgr.selective-reset.underline",
    "sgr.selective-reset.italic",
    "sgr.selective-reset.inverse",
    "sgr.reset",
  ]
  for (const id of ids) {
    const definition = sgrProbes.find((probe) => probe.id === id)
    if (!definition?.term) throw new Error(`missing app callback for ${id}`)

    const smallWrites: string[] = []
    let smallCaptures = 0
    const small = await definition.term(
      terminal({
        rows: 2,
        cols: 33,
        write: (bytes) => smallWrites.push(bytes),
        capture: async ({ role, label }) => {
          smallCaptures++
          return { role, label, capturedAt: 1, ref: "never" }
        },
      }),
    )
    expect(small.observation, id).toBeUndefined()
    expect(small, id).toMatchObject({
      tests: [
        expect.objectContaining({ status: "probe-todo", reason: "SGR fixture needs at least 3x34, measured 2x33" }),
      ],
    })
    expect(smallWrites, id).toEqual([])
    expect(smallCaptures, id).toBe(0)

    const writes: string[] = []
    const roles: string[] = []
    const ok = await definition.term(
      terminal({
        rows: 3,
        cols: 34,
        write: (bytes) => writes.push(bytes),
        capture: async ({ role, label }) => {
          roles.push(role)
          return { role, label, capturedAt: roles.length, ref: `sha256:${"d".repeat(64)}` }
        },
      }),
    )
    // A 3-row grid cannot map the 4-row region fixture. Saved-rendition references now refuse
    // before writes; the other rows first attempt the silent DECRQSS baseline. Neither captures.
    const referenceFirst = id === "sgr.reset" || id === "sgr.selective-reset.bold"
    expect(ok.observation, id).toBeUndefined()
    expect(ok.tests, id).toMatchObject([
      {
        id: "criterion",
        status: referenceFirst ? "probe-todo" : "probe-invalid",
        reason: referenceFirst
          ? `${id}: capture-region readback needs a measured grid of at least 4x6; measured 3x34`
          : expect.stringContaining("the caller wrote before this refusal"),
      },
    ])
    expect(ok.assertions, id).toBeUndefined()
    expect(roles, id).toEqual([])
    expect(ok.observation?.frames, id).toBeUndefined()
    // An unanswered DECRQSS baseline cleans up; an unavailable reference does not start it.
    expect(writes, id).toEqual(referenceFirst ? [] : ["\x1b[0m", "\x1b[0m"])
  }
})

test("unexposed overline and default conceal flags cannot establish negative support", () => {
  for (const id of ["sgr.overline", "sgr.hidden"]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib) throw new Error(`missing headless ${id} probe`)
    const result = probe.lib(headless())
    expect(result.pass, id).toBe(false)
    if (id === "sgr.overline") {
      expect(result.observation, id).toBeUndefined()
      expect(result.notTested, id).toEqual({
        reason: "no-semantic-observable",
        noObservable:
          "Open: our adapter for this library does not read overline from its screen cells yet, so our test cannot see overline.",
      })
    } else expectNoSamePathTodo(result, id)
    expect(JSON.parse(result.response ?? ""), id).toMatchObject({ char: "X" })
    expect(result.assertions, id).toBeUndefined()
    const measured = probe.lib(headless({ getCell: () => ({ ...baseCell, hidden: true, overline: true }) }))
    expect(measured.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    expect(measured.assertions, id).toMatchObject([{ kind: "positive" }])
    if (id === "sgr.hidden") {
      const unexposed = probe.lib(headless({ getCell: () => ({ ...baseCell, hidden: null }) }))
      expectNoSamePathTodo(
        unexposed,
        id,
        "Open: our adapter for this library does not read hidden text from its screen cells yet, so our test cannot see hidden text.",
      )
      expect(JSON.parse(unexposed.response ?? ""), id).toMatchObject({ char: "X", hidden: null })
    }
  }
})

test("underline color needs an observed color, not only an underline or a consumed sequence", async () => {
  for (const id of ["sgr.underline.color", "sgr.underline-color-rgb"]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib || !probe.term) throw new Error(`missing ${id} callback`)

    const unexposed = probe.lib(
      headless({
        getCell: (_row, col) => ({
          ...baseCell,
          char: ["A", "B", "X"][col] ?? "",
          underline: true,
          underlineColor: undefined,
        }),
      }),
    )
    // Missing cell readback retains its named cause without deciding terminal support.
    expectNoSamePathTodo(unexposed, id, underlineColorUnexposed)
    expect(JSON.parse(unexposed.response ?? ""), id).toMatchObject({ target: { char: "X" } })

    const colored = probe.lib(
      headless({
        getCell: (_row, col) => ({
          ...baseCell,
          char: ["A", "B", "X"][col] ?? "",
          underline: true,
          fg:
            [
              { r: 0, g: 0, b: 255 },
              { r: 0, g: 255, b: 0 },
              { r: 0, g: 255, b: 0 },
            ][col] ?? null,
          underlineColor: col === 2 ? { r: 255, g: 0, b: 128 } : null,
        }),
      }),
    )
    expect(colored.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    expect(colored.assertions, id).toMatchObject([{ kind: "positive", observed: colored.response }])

    const consumed = await probe.term(terminal({ queryCursorPosition: async () => ({ row: 1, col: 2 }) }))
    expect(consumed.observation, id).toBeUndefined()
    expect(consumed, id).toMatchObject({
      tests: [expect.objectContaining({ status: "probe-todo", reason: "Cursor advance does not verify SGR styling" })],
    })
    expect(consumed.assertions, id).toBeUndefined()
  }
})

test("indexed underline color follows two distinct measured palette controls", async () => {
  const probe = sgrProbes.find((item) => item.id === "sgr.underline-color-indexed")
  if (!probe?.lib || !probe.term) throw new Error("missing indexed underline color callback")
  const measure = probe.lib
  const index4 = { r: 10, g: 20, b: 30 }
  const index5 = { r: 40, g: 50, b: 60 }
  const run = (
    colorOnFive: typeof index4 | null | undefined,
    colorOnFour: typeof index5 | null | undefined,
    secondFg = index5,
    default4: typeof index4 | null | undefined = null,
    default5: typeof index5 | null | undefined = null,
  ) =>
    measure(
      headless({
        getCell: (_row, col) => ({
          ...baseCell,
          char: ["A", "X", "B", "Y"][col] ?? "",
          underline: true,
          fg: col < 2 ? index4 : secondFg,
          underlineColor: [default4, colorOnFive, default5, colorOnFour][col],
        }),
      }),
    )

  const unexposed = run(undefined, undefined)
  expectNoSamePathTodo(unexposed, undefined, underlineColorUnexposed)
  expect(JSON.parse(unexposed.response ?? "")).toMatchObject({ target5: { char: "X" }, target4: { char: "Y" } })

  const matched = run(index5, index4)
  expect(matched.observation).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
  expect(matched.assertions).toMatchObject([{ kind: "positive", observed: matched.response }])
  expect(JSON.parse(matched.response ?? "")).toMatchObject({
    default4: { fg: index4, underlineColor: null },
    target5: { fg: index4, underlineColor: index5 },
    default5: { fg: index5, underlineColor: null },
    target4: { fg: index5, underlineColor: index4 },
  })

  const ignoredColor = { r: 0, g: 0, b: 0 }
  const ignored = run(ignoredColor, ignoredColor, index5, index4, index5)
  expect(ignored.observation).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
  expect(ignored.assertions).toMatchObject([{ kind: "negative", observed: ignored.response }])

  const indistinguishable = run(index4, index4, index4)
  expect(indistinguishable.observation).toMatchObject({ outcome: "inconclusive", reason: "insufficient-evidence" })

  const consumed = await probe.term(terminal({ queryCursorPosition: async () => ({ row: 1, col: 2 }) }))
  expect(consumed.observation).toBeUndefined()
  expect(consumed).toMatchObject({
    tests: [expect.objectContaining({ status: "probe-todo", reason: "Cursor advance does not verify SGR styling" })],
  })
})

test("underline color reset needs both an observed colored before cell and default after cell", () => {
  const probe = sgrProbes.find((item) => item.id === "sgr.underline-color-reset")
  if (!probe?.lib) throw new Error("missing underline color reset callback")
  const color = { r: 255, g: 0, b: 128 }
  const baseline = { ...baseCell, char: "C", underline: true }
  const withCells = (before: ReturnType<LibProbeSource["getCell"]>, after: ReturnType<LibProbeSource["getCell"]>) =>
    headless({ getCell: (_row, col) => [baseline, before, after][col] ?? baseCell })

  const missingBefore = probe.lib(
    withCells({ ...baseCell, underline: true, underlineColor: undefined }, { ...baseCell, char: "Y", underline: true }),
  )
  // The missing coloured seed is a missing prerequisite with its own cause (@cto batch7 A-F5).
  expect(missingBefore.notTested).toEqual({
    reason: "no-semantic-observable",
    noObservable:
      "Open: after we set an underline colour (SGR 58), the screen cell showed none, so the setup did not show and the reset cannot be tested.",
  })

  const missingAfter = probe.lib(
    withCells(
      { ...baseCell, underline: true, underlineColor: color },
      { ...baseCell, char: "Y", underline: true, underlineColor: undefined },
    ),
  )
  expect(missingAfter.observation).toMatchObject({ outcome: "inconclusive", reason: "insufficient-evidence" })

  const reset = probe.lib(
    withCells({ ...baseCell, underline: true, underlineColor: color }, { ...baseCell, char: "Y", underline: true }),
  )
  expect(reset.observation).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
  expect(reset.assertions).toMatchObject([{ kind: "positive", observed: reset.response }])

  const stillColored = probe.lib(
    withCells(
      { ...baseCell, underline: true, underlineColor: color },
      { ...baseCell, char: "Y", underline: true, underlineColor: color },
    ),
  )
  expect(stillColored.observation).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
  expect(stillColored.assertions).toMatchObject([{ kind: "negative", observed: stillColored.response }])
})

test("a null underline color from an adapter with no color readback is PROBE TODO, not unsupported", () => {
  for (const id of ["sgr.underline.color", "sgr.underline-color-rgb", "sgr.underline-color-indexed"]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib) throw new Error(`missing ${id} callback`)
    const indexed = id === "sgr.underline-color-indexed"
    const chars = indexed ? ["A", "X", "B", "Y"] : ["A", "B", "X"]
    const firstFg = { r: 0, g: 0, b: 128 }
    const secondFg = { r: 128, g: 0, b: 128 }
    const result = probe.lib(
      headless({
        getCell: (_row, col) => ({
          ...baseCell,
          char: chars[col] ?? "",
          underline: true,
          fg: indexed ? (col < 2 ? firstFg : secondFg) : col === 0 ? firstFg : secondFg,
          underlineColor: null,
        }),
      }),
    )
    expectNoSamePathTodo(result, id, underlineColorUnexposed)
    expect(JSON.parse(result.response ?? ""), id).toMatchObject(
      indexed
        ? { target5: { char: "X", underlineColor: null }, target4: { char: "Y", underlineColor: null } }
        : { target: { char: "X", underlineColor: null } },
    )
  }
})

test("SGR 59 accepts the backend's measured non-null reset default", () => {
  const probe = sgrProbes.find((item) => item.id === "sgr.underline-color-reset")
  if (!probe?.lib) throw new Error("missing SGR 59 callback")
  const pink = { r: 255, g: 0, b: 128 }
  const white = { r: 255, g: 255, b: 255 }
  const cells = [
    { ...baseCell, char: "C", underline: true, underlineColor: white },
    { ...baseCell, char: "X", underline: true, underlineColor: pink },
    { ...baseCell, char: "Y", underline: true, underlineColor: white },
  ]
  const result = probe.lib(headless({ getCell: (_row, col) => cells[col] ?? baseCell }))
  expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
  expect(result.assertions).toMatchObject([{ kind: "positive", observed: result.response }])
})

test("indexed SGR 58 rejects a default underline that merely follows the foreground", () => {
  const probe = sgrProbes.find((item) => item.id === "sgr.underline-color-indexed")
  if (!probe?.lib) throw new Error("missing indexed underline callback")
  const blue = { r: 0, g: 0, b: 128 }
  const magenta = { r: 128, g: 0, b: 128 }
  const cells = [
    { ...baseCell, char: "A", underline: true, fg: blue, underlineColor: blue },
    { ...baseCell, char: "X", underline: true, fg: blue, underlineColor: blue },
    { ...baseCell, char: "B", underline: true, fg: magenta, underlineColor: magenta },
    { ...baseCell, char: "Y", underline: true, fg: magenta, underlineColor: magenta },
  ]
  const result = probe.lib(headless({ getCell: (_row, col) => cells[col] ?? baseCell }))
  expect(result.observation).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
  expect(result.assertions).toMatchObject([{ kind: "negative", observed: result.response }])
})

test("SGR reset results require an observed setup and preserve unrelated attributes", () => {
  const cases = [
    {
      id: "sgr.selective-reset.bold",
      before: { bold: true, dim: true, italic: true },
      after: { bold: false, dim: false, italic: true },
      erasedSentinel: { bold: false, dim: false, italic: false },
      unshown: "bold and dim and italic and underline",
    },
    {
      id: "sgr.selective-reset.underline",
      before: { underline: true, bold: true },
      after: { underline: false, bold: true },
      erasedSentinel: { underline: false, bold: false },
      unshown: "underline and bold",
    },
    {
      id: "sgr.selective-reset.italic",
      before: { italic: true, bold: true },
      after: { italic: false, bold: true },
      erasedSentinel: { italic: false, bold: false },
      unshown: "italic and bold",
    },
    {
      id: "sgr.selective-reset.inverse",
      before: { inverse: true, bold: true },
      after: { inverse: false, bold: true },
      erasedSentinel: { inverse: false, bold: false },
      unshown: "inverse and bold",
    },
    {
      id: "sgr.reset",
      before: { bold: true, italic: true, underline: true },
      after: { bold: false, italic: false, underline: false },
      erasedSentinel: null,
      unshown: "bold and italic and underline",
    },
  ] as const
  for (const { id, before, after, erasedSentinel, unshown } of cases) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib) throw new Error(`missing ${id} callback`)
    const lib = probe.lib
    const read = (style: Partial<typeof baseCell>) =>
      lib(
        headless({
          getCell: (_row, col) => ({ ...baseCell, char: ["C", "X", "Y"][col] ?? "", ...[{}, before, style][col] }),
        }),
      )
    const supported = read(after)
    expect(supported.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    expect(supported.assertions, id).toMatchObject([{ kind: "positive", observed: supported.response }])
    expect(JSON.parse(supported.response ?? ""), id).toMatchObject({
      baseline: { char: "C" },
      before: { char: "X" },
      after: { char: "Y" },
    })
    const ignored = read(before)
    expect(ignored.observation, id).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
    expect(ignored.assertions, id).toMatchObject([{ kind: "negative", observed: ignored.response }])
    const unobservedSetup = probe.lib(
      headless({ getCell: (_row, col) => ({ ...baseCell, char: ["C", "X", "Y"][col] ?? "" }) }),
    )
    // #30590: incomplete compound setup stays TODO and names every unobserved facet.
    expectNoSamePathTodo(
      unobservedSetup,
      id,
      `Open: ${unshown} did not show during setup, so our test cannot check the combined reset.`,
    )
    if (erasedSentinel) {
      const lost = read(erasedSentinel)
      expect(lost.observation, id).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
    }
  }
})

// #30701 (@cto ruling C): a reset is graded on the setup attributes the cell measurably shows. Each row
// is an adapter shape from the 11-engine headless collection: one with no italic and no dim field,
// one with no dim field, one with no faint field whose SGR 2 replaces bold, and one that keeps
// intensity exclusive (SGR 2 replaces bold, the field is present).
test.each([
  ["sgr.reset", { bold: true, underline: "single" }, {}, "supported", "italic"],
  ["sgr.selective-reset.bold", { bold: true, italic: true }, { italic: true }, "supported", "dim"],
  ["sgr.selective-reset.bold", { dim: true, italic: true }, { italic: true }, "supported", "bold"],
  ["sgr.selective-reset.bold", { italic: true }, { italic: true }, "todo", "bold and dim and underline"],
  ["sgr.selective-reset.bold", { bold: true }, {}, "todo", "dim and italic and underline"],
  ["sgr.selective-reset.italic", { bold: true }, { bold: true }, "todo", "italic"],
  ["sgr.selective-reset.bold", { bold: true, italic: true }, { bold: true, italic: true }, "unsupported", "dim"],
  // C16 (@cto routes-48): an engine that exposes neither dim nor italic, like vt220 0.13.1, still
  // decides the bold reset when SGR 22 keeps underline.
  ["sgr.selective-reset.bold", { bold: true, underline: true }, { underline: true }, "supported", "dim and italic"],
  [
    "sgr.selective-reset.bold",
    { bold: true, underline: true },
    { bold: true, underline: true },
    "unsupported",
    "dim and italic",
  ],
] as const)("%s grades setup %o reset to %o on the measured attributes: %s", (id, before, after, outcome, unshown) => {
  const probe = sgrProbes.find((item) => item.id === id)
  if (!probe?.lib) throw new Error(`missing ${id} callback`)
  const result = probe.lib(
    headless({
      getCell: (_row, col) => ({ ...baseCell, char: ["C", "X", "Y"][col] ?? "", ...[{}, before, after][col] }),
    }),
  )
  if (outcome === "todo") {
    expectNoSamePathTodo(
      result,
      id,
      `Open: ${unshown} did not show during setup, so our test cannot check the combined reset.`,
    )
  } else {
    expect(result.observation).toMatchObject({ outcome, assertionType: "buffer_state" })
    expect(result.observation?.note).toContain(unshown)
  }
})

test("named ANSI color probes require distinct exposed selection, without theme thresholds", () => {
  const lowRed = { r: 3, g: 1, b: 2 }
  const lowBlue = { r: 1, g: 2, b: 4 }
  for (const id of ["sgr.fg.standard", "sgr.bg.standard", "sgr.fg.bright", "sgr.bg.bright"]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib) throw new Error(`missing ${id} callback`)
    const channel = id.includes(".fg.") ? "fg" : "bg"
    const fed: string[] = []
    const run = (
      first: typeof lowRed | null,
      second: typeof lowBlue | null,
      chars = ["C", "X", "Y"],
      baseline: typeof lowRed | null = null,
    ) =>
      probe.lib?.(
        headless({
          feed: (sequence) => fed.push(sequence),
          getCell: (_row, col) => ({
            ...baseCell,
            char: chars[col] ?? "",
            [channel]: [baseline, first, second][col] ?? null,
          }),
        }),
      )
    const distinct = run(lowRed, lowBlue)
    const codes: Record<string, readonly number[]> = {
      "sgr.fg.standard": [31, 34],
      "sgr.bg.standard": [41, 44],
      "sgr.fg.bright": [91, 94],
      "sgr.bg.bright": [101, 104],
    }
    for (const code of codes[id] ?? []) expect(fed[0], id).toContain(`\x1b[${code}m`)
    expect(distinct?.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    expect(distinct?.assertions, id).toMatchObject([{ kind: "positive", observed: distinct?.response }])
    expect(JSON.parse(distinct?.response ?? ""), id).toMatchObject({
      baseline: { char: "C" },
      first: { char: "X" },
      second: { char: "Y" },
    })
    // #30701 (@cto cd391424): both named colors equal to an EXPOSED neutral is a measured ignore; a
    // neutral and two targets all reading no color show nothing about the color field (coverage
    // record); a default reported as absent (undefined) still differs from two exposed colors.
    const ignored = run(lowRed, lowRed, ["C", "X", "Y"], lowRed)
    expect(ignored?.observation, id).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
    expect(ignored?.assertions, id).toMatchObject([{ kind: "negative", observed: ignored?.response }])
    const unshown = run(null, null)
    expectNoSamePathTodo(unshown!, id)
    const absentDefault = probe.lib(
      headless({
        getCell: (_row, col) => ({
          ...baseCell,
          char: ["C", "X", "Y"][col] ?? "",
          [channel]: [undefined, lowRed, lowBlue][col],
        }),
      }),
    )
    expect(absentDefault.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    for (const uncertain of [
      run(lowRed, lowRed),
      run(lowRed, lowBlue, ["C", "?", "Y"]),
      run(lowRed, lowBlue, ["C", "X", "Y"], lowRed),
    ]) {
      expect(uncertain?.observation, id).toMatchObject({ outcome: "inconclusive", reason: "insufficient-evidence" })
      expect(uncertain?.assertions, id).toBeUndefined()
    }
  }
})

test("indexed cube colors require two exact direct-RGB reference controls", () => {
  const first = { r: 95, g: 135, b: 175 }
  const second = { r: 215, g: 135, b: 95 }
  for (const id of ["sgr.fg.256", "sgr.bg.256"]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib) throw new Error(`missing ${id} callback`)
    const channel = id.includes(".fg.") ? "fg" : "bg"
    const fed: string[] = []
    const run = (indexed: readonly (typeof first | null)[], direct: readonly (typeof first | null)[]) =>
      probe.lib?.(
        headless({
          feed: (sequence) => fed.push(sequence),
          getCell: (_row, col) => ({
            ...baseCell,
            char: ["C", "A", "B", "X", "Y"][col] ?? "",
            [channel]: [null, ...direct, ...indexed][col] ?? null,
          }),
        }),
      )
    const matched = run([first, second], [first, second])
    const selector = channel === "fg" ? 38 : 48
    for (const code of [
      `${selector};5;67`,
      `${selector};5;173`,
      `${selector};2;95;135;175`,
      `${selector};2;215;135;95`,
    ]) {
      expect(fed[0], id).toContain(`\x1b[${code}m`)
    }
    expect(matched?.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    expect(matched?.assertions, id).toMatchObject([{ kind: "positive", observed: matched?.response }])
    expect(JSON.parse(matched?.response ?? ""), id).toMatchObject({
      directFirst: { char: "A" },
      indexedSecond: { char: "Y" },
    })
    // #30701 (@cto cd391424): calibrated direct RGB that the indices miss is a custom palette OR an
    // adapter that does not resolve indices, so it stays inconclusive naming both; direct RGB that
    // misses its fed value is an uncalibrated reference (PROBE TODO).
    for (const palette of [run([first, first], [first, second]), run([null, null], [first, second])]) {
      expect(palette?.observation, id).toMatchObject({ outcome: "inconclusive", reason: "insufficient-evidence" })
      expect(palette?.observation?.note, id).toContain("does not resolve indices")
      expect(palette?.assertions, id).toBeUndefined()
    }
    const uncalibrated = run([first, second], [null, null])
    expectNoSamePathTodo(uncalibrated!, id)
  }
})

test("truecolor probes distinguish exact sampled RGB from calibrated wrong RGB", () => {
  const firstFg = { r: 255, g: 128, b: 0 }
  const firstBg = { r: 0, g: 255, b: 128 }
  const second = { r: 17, g: 97, b: 201 }
  const red = { r: 7, g: 1, b: 2 }
  const blue = { r: 2, g: 1, b: 7 }
  for (const id of ["sgr.fg.truecolor", "sgr.bg.truecolor"]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib) throw new Error(`missing ${id} callback`)
    const channel = id.includes(".fg.") ? "fg" : "bg"
    const first = channel === "fg" ? firstFg : firstBg
    const fed: string[] = []
    const run = (targets: readonly (typeof first | null)[], controls: readonly (typeof red | null)[] = [red, blue]) =>
      probe.lib?.(
        headless({
          feed: (sequence) => fed.push(sequence),
          getCell: (_row, col) => ({
            ...baseCell,
            char: ["C", "A", "B", "X", "Y"][col] ?? "",
            [channel]: [null, ...controls, ...targets][col] ?? null,
          }),
        }),
      )
    const exact = run([first, second])
    const selector = channel === "fg" ? 38 : 48
    expect(fed[0], id).toContain(`\x1b[${selector};2;${first.r};${first.g};${first.b}m`)
    expect(fed[0], id).toContain(`\x1b[${selector};2;17;97;201m`)
    expect(exact?.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    expect(exact?.assertions, id).toMatchObject([{ kind: "positive", observed: exact?.response }])
    const wrong = run([red, blue])
    expect(wrong?.observation, id).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
    expect(wrong?.assertions, id).toMatchObject([{ kind: "negative", observed: wrong?.response }])
    for (const uncertain of [run([red, blue], [red, red]), run([first, second], [red, first])]) {
      expect(uncertain?.observation, id).toMatchObject({ outcome: "inconclusive", reason: "insufficient-evidence" })
      expect(uncertain?.assertions, id).toBeUndefined()
    }
    // #30701 (@cto ruling C): targets that read no color are a measured ignore while the controls are
    // calibrated, and have no observable when the controls show no color either (PROBE TODO).
    const ignored = run([null, null])
    expect(ignored?.observation, id).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
    expect(ignored?.assertions, id).toMatchObject([{ kind: "negative", observed: ignored?.response }])
    const uncalibrated = run([null, null], [null, null])
    expectNoSamePathTodo(uncalibrated!, id)
  }
})

test("SGR 39 and 49 restore the measured default, including concrete RGB defaults", () => {
  const baseline = { r: 4, g: 5, b: 6 }
  const colored = { r: 90, g: 20, b: 10 }
  for (const id of ["sgr.fg.default", "sgr.bg.default"]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.lib) throw new Error(`missing ${id} callback`)
    const channel = id.includes(".fg.") ? "fg" : "bg"
    const fed: string[] = []
    const run = (colors: readonly (typeof baseline | null)[]) =>
      probe.lib?.(
        headless({
          feed: (sequence) => fed.push(sequence),
          getCell: (_row, col) => ({ ...baseCell, char: ["C", "X", "R"][col] ?? "", [channel]: colors[col] ?? null }),
        }),
      )
    const restored = run([baseline, colored, baseline])
    expect(fed[0], id).toContain(channel === "fg" ? "\x1b[31m" : "\x1b[42m")
    expect(fed[0], id).toContain(channel === "fg" ? "\x1b[39m" : "\x1b[49m")
    expect(restored?.observation, id).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
    expect(restored?.assertions, id).toMatchObject([{ kind: "positive", observed: restored?.response }])
    const ignored = run([baseline, colored, colored])
    expect(ignored?.observation, id).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
    expect(ignored?.assertions, id).toMatchObject([{ kind: "negative", observed: ignored?.response }])
    // #31766: a setup that reads back as the default leaves the reset no distinct colored seed.
    const uncalibrated = run([baseline, baseline, baseline])
    expect(uncalibrated?.notTested, id).toMatchObject({ reason: "no-semantic-observable" })
    expect(uncalibrated?.criterionBranch, id).toBe("headless-observable-review")
    expect(uncalibrated?.tests, id).toEqual([
      {
        id: "review",
        status: "probe-todo",
        reason:
          channel === "fg"
            ? "Open: the text colour we set first (SGR 31) read the same as the default, so we cannot tell whether the reset to default worked."
            : "Open: the background colour we set first (SGR 42) read the same as the default, so we cannot tell whether the reset to default worked.",
      },
    ])
    expect(uncalibrated?.observation, id).toBeUndefined()
    expect(uncalibrated?.assertions, id).toBeUndefined()
    // An unread seed cannot be described as equal to a concrete default colour.
    const unreadSeed = run([baseline, null, baseline])
    expect(unreadSeed?.tests, id).toEqual([
      {
        id: "review",
        status: "probe-todo",
        reason: `Open: our test could not read the ${channel === "fg" ? "text" : "background"} colour we set first (SGR ${channel === "fg" ? 31 : 42}), so we cannot tell whether the reset to default worked.`,
      },
    ])
    expect(unreadSeed?.observation, id).toBeUndefined()
    expect(unreadSeed?.assertions, id).toBeUndefined()
    expect(JSON.parse(unreadSeed!.response!)).toMatchObject({
      baseline: { [channel]: baseline },
      before: { [channel]: null },
      after: { [channel]: baseline },
    })
  }
})

test("all ten SGR color TTY replies remain inconclusive and restore style", async () => {
  for (const channel of ["fg", "bg"]) {
    for (const family of ["standard", "bright", "256", "truecolor", "default"]) {
      const id = `sgr.${channel}.${family}`
      const probe = sgrProbes.find((item) => item.id === id)
      if (!probe?.term) throw new Error(`missing ${id} TTY callback`)
      const writes: string[] = []
      const answered = await probe.term(
        terminal({ write: (text) => writes.push(text), queryCursorPosition: async () => ({ row: 1, col: 2 }) }),
      )
      expect(answered.observation, id).toBeUndefined()
      expect(answered.tests, id).toMatchObject([
        {
          id: "criterion",
          status: family === "default" ? "probe-invalid" : "probe-todo",
          reason:
            family === "default"
              ? "Cursor advance does not verify the reset rendered"
              : "Cursor advance does not verify SGR styling",
        },
      ])
      expect(answered.assertions, id).toBeUndefined()
      expect(writes.at(-1), id).toBe("\x1b[0m")
      const silent = await probe.term(terminal())
      expect(silent.observation, id).toBeUndefined()
      expect(silent.tests, id).toEqual([
        {
          id: "criterion",
          status: "probe-invalid",
          reason: "no parsable cursor position reply; the public projection returned null and retained no bytes",
        },
      ])
    }
  }
  const color = sgrProbes.find((item) => item.id === "sgr.fg.standard")
  if (!color?.term) throw new Error("missing standard foreground TTY callback")
  const failedWrites: string[] = []
  await expect(
    color.term(
      terminal({
        write: (text) => failedWrites.push(text),
        queryCursorPosition: async () => {
          throw new Error("TTY color query failed")
        },
      }),
    ),
  ).rejects.toThrow("TTY color query failed")
  expect(failedWrites.at(-1)).toBe("\x1b[0m")
})

test("SGR reset cursor replies remain inconclusive and style cleanup runs on query failure", async () => {
  for (const id of [
    "sgr.selective-reset.bold",
    "sgr.selective-reset.underline",
    "sgr.selective-reset.italic",
    "sgr.selective-reset.inverse",
    "sgr.reset",
  ]) {
    const probe = sgrProbes.find((item) => item.id === id)
    if (!probe?.term) throw new Error(`missing ${id} terminal callback`)
    const writes: string[] = []
    const result = await probe.term(
      terminal({
        write: (text) => writes.push(text),
        queryCursorPosition: async () => ({ row: 1, col: 3 }),
      }),
    )
    expect(result.observation, id).toBeUndefined()
    expect(result.tests, id).toEqual([
      { id: "criterion", status: "probe-todo", reason: "Cursor advance does not verify SGR reset" },
    ])
    expect(result.assertions, id).toBeUndefined()
    expect(writes.at(-1), id).toBe("\x1b[0m")
  }
  const probe = sgrProbes.find((item) => item.id === "sgr.reset")
  if (!probe?.term) throw new Error("missing sgr.reset terminal callback")
  const silence = await probe.term(terminal())
  expect(silence.observation).toBeUndefined()
  expect(silence.tests).toEqual([
    {
      id: "criterion",
      status: "probe-invalid",
      reason: "no parsable cursor position reply; the public projection returned null and retained no bytes",
    },
  ])
  expect(silence.assertions).toBeUndefined()
  const writes: string[] = []
  await expect(
    probe.term(
      terminal({
        write: (text) => writes.push(text),
        queryCursorPosition: async () => {
          throw new Error("TTY read failed")
        },
      }),
    ),
  ).rejects.toThrow("TTY read failed")
  expect(writes.at(-1)).toBe("\x1b[0m")
})

test("cursor movement binds measured positions and parser state, never a missing reply", async () => {
  const cursor = cursorProbe("cursor.move.absolute", "", "\x1b[5;10H", { row: 4, col: 9 })
  if (!cursor.term || !cursor.lib) throw new Error("missing cursor callback")

  let terminalPosition = { row: 8, col: 7 }
  const terminalCursor = await cursor.term(
    terminal({
      write(sequence) {
        if (sequence === "\x1b[1;1H") terminalPosition = { row: 1, col: 1 }
        if (sequence === "\x1b[5;10H") terminalPosition = { row: 5, col: 10 }
      },
      queryCursorPosition: async () => terminalPosition,
    }),
  )
  expect(terminalCursor.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
  expect(terminalCursor.assertions).toMatchObject([
    { kind: "positive", expected: expect.any(String), observed: expect.any(String) },
  ])
  const missingCursor = await cursor.term(terminal())
  expect(missingCursor.observation).toBeUndefined()
  expect(missingCursor.tests).toEqual([
    {
      id: "criterion",
      status: "probe-invalid",
      reason: "no parsable cursor position reply; the public projection returned null and retained no bytes",
    },
  ])
  expect(missingCursor.response).toBe(JSON.stringify({ origin: null, setup: null, final: null }))

  let headlessPosition = { x: 7, y: 8, visible: true, style: null }
  const parserCursor = cursor.lib(
    headless({
      feed(sequence) {
        if (sequence === "\x1b[1;1H") headlessPosition = { ...headlessPosition, x: 0, y: 0 }
        if (sequence === "\x1b[5;10H") headlessPosition = { ...headlessPosition, x: 9, y: 4 }
      },
      getCursor: () => headlessPosition,
    }),
  )
  expect(parserCursor.observation).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })
  expect(JSON.parse(parserCursor.response ?? "")).toMatchObject({ final: { x: 9, y: 4 } })
  expect(parserCursor.assertions).toMatchObject([{ kind: "positive", observed: parserCursor.response }])
})

test("DECRPM recognizes explicit set/reset/unknown without changing an existing mode", async () => {
  const written: string[] = []
  const makeSource = (ps: DecrpmPs | null) =>
    terminal({
      write(text) {
        written.push(text)
      },
      queryWithSentinel: async (sequence, pattern) => {
        expect(sequence).toBe("\x1b[?42$p")
        return ps === null ? null : pattern.exec(`\x1b[?42;${ps}$y`)
      },
      queryMode: async () => {
        throw new Error("the DECRQM arm reads Ps through queryWithSentinel, never the folded word (#30557)")
      },
    })
  const decrpm = decrpmModeProbe("modes.test", 42, null)
  if (!decrpm.term) throw new Error("missing mode callback")
  for (const [ps, reading] of [
    [1, "set (Ps 1)"],
    [2, "reset (Ps 2)"],
    [3, "permanently set (Ps 3)"],
  ] as const) {
    const result = await decrpm.term(makeSource(ps))
    expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
    expect(result.response).toBe(reading)
    expect(result.assertions).toMatchObject([{ kind: "positive", observed: reading }])
  }
  // Ps 4: known, cannot be set (#30557).
  const four = await decrpm.term(makeSource(4))
  expect(four.pass).toBe(false)
  expect(four.response).toBe("permanently reset (Ps 4)")
  expect(four.observation).toMatchObject({ outcome: "unsupported", assertionType: "query_reply" })
  expect(four.assertions).toMatchObject([
    { kind: "negative", expected: "DECRPM mode 42 can be set", observed: "permanently reset (Ps 4)" },
  ])
  const unknown = await decrpm.term(makeSource(0))
  expect(unknown.observation).toMatchObject({
    outcome: "inconclusive",
    reason: "insufficient-evidence",
    assertionType: "query_reply",
  })
  expect(unknown.response).toBe("not recognized (Ps 0)")
  expect(unknown.assertions).toBeUndefined()
  const missing = await decrpm.term(makeSource(null))
  expect(missing.observation).toBeUndefined()
  expect(missing.tests).toEqual([
    {
      id: "criterion",
      status: "probe-invalid",
      reason: "no usable DECRPM reply; the public projection returned null and retained no bytes",
    },
  ])
  expect(written).toEqual([])
})
