/**
 * @failure A group feature is graded without a bound contract row, or a re-grade of a decided
 *   observation moves it - so a group step reinvents its own fixture and silently drifts.
 * @level l2
 * @consumer 28018 candidate-2 SGR group (child 28019); the first adopter of the 28453 harness.
 * @reach fs-walk vendor/terminfo.dev/packages/probe-defs/src/sgr-contract.test.ts vendor/terminfo.dev/packages/probe-defs/src/helper-observations.test.ts vendor/terminfo.dev/packages/probe-defs/src/readback.test.ts
 * @testonly none
 */
import { expect, expectTypeOf, test } from "vitest"
import type { Cell } from "@termless/core/io"
import { join } from "node:path"
import { NO_SAME_PATH_CONTROL } from "./helpers.ts"
import { sgrProbes } from "./sgr.ts"
import type { LibProbeSource, ProbeCallbackResult } from "./types.ts"
import { createSemanticSurface } from "./testing/semantic-surface.ts"
import {
  contractGaps,
  libProbeSource,
  missingContractTests,
  regradeCommand,
  regradeRow,
  satisfiesContract,
  type GroupContract,
  type GroupContractSpec,
  type HeadlessModel,
} from "./testing/group-harness.ts"

/** #32246: a former source-review site returns the PROBE TODO coverage record, never a source-decided result. */
function expectNoSamePathTodo(result: ProbeCallbackResult, noObservable = NO_SAME_PATH_CONTROL) {
  expect(result.pass).toBe(false)
  expect(result.notTested).toEqual({ reason: "no-semantic-observable", noObservable })
  expect(result.criterionBranch).toBeUndefined()
  expect(result.tests).toBeUndefined()
  expect(result.observation).toBeUndefined()
  expect(result.assertions).toBeUndefined()
}

/** The 32 SGR features of 28018's SGR row; ids drawn from sgr.ts, claims are the contract. */
const SGR_CONTRACT: GroupContract = [
  { id: "sgr.bold", expected: "decided", claim: "SGR 1 selects the bold attribute" },
  { id: "sgr.faint", expected: "decided", claim: "SGR 2 selects the faint attribute" },
  { id: "sgr.italic", expected: "decided", claim: "SGR 3 selects the italic attribute" },
  { id: "sgr.underline.single", expected: "decided", claim: "SGR 4 selects a single underline" },
  { id: "sgr.blink", expected: "decided", claim: "SGR 5 selects the blink attribute" },
  { id: "sgr.inverse", expected: "decided", claim: "SGR 7 selects inverse video" },
  { id: "sgr.hidden", expected: "decided", claim: "SGR 8 selects the hidden attribute" },
  { id: "sgr.strikethrough", expected: "decided", claim: "SGR 9 selects strikethrough" },
  { id: "sgr.overline", expected: "decided", claim: "SGR 53 selects overline" },
  {
    id: "sgr.reset",
    expected: "decided",
    claim: "SGR 0 clears measured bold, italic, and underline after qualified setup",
  },
  { id: "sgr.fg.standard", expected: "decided", claim: "SGR 30-37 selects a standard foreground" },
  { id: "sgr.fg.bright", expected: "decided", claim: "SGR 90-97 selects a bright foreground" },
  { id: "sgr.fg.256", expected: "decided", claim: "SGR 38;5 selects a 256-colour foreground" },
  { id: "sgr.fg.truecolor", expected: "decided", claim: "SGR 38;2 selects a truecolor foreground" },
  { id: "sgr.fg.default", expected: "decided", claim: "SGR 39 restores the default foreground" },
  { id: "sgr.bg.standard", expected: "decided", claim: "SGR 40-47 selects a standard background" },
  { id: "sgr.bg.bright", expected: "decided", claim: "SGR 100-107 selects a bright background" },
  { id: "sgr.bg.256", expected: "decided", claim: "SGR 48;5 selects a 256-colour background" },
  { id: "sgr.bg.truecolor", expected: "decided", claim: "SGR 48;2 selects a truecolor background" },
  { id: "sgr.bg.default", expected: "decided", claim: "SGR 49 restores the default background" },
  { id: "sgr.underline.double", expected: "decided", claim: "SGR 21 selects a double underline" },
  { id: "sgr.underline.curly", expected: "decided", claim: "SGR 4:3 selects a curly underline" },
  { id: "sgr.underline.dotted", expected: "decided", claim: "SGR 4:4 selects a dotted underline" },
  { id: "sgr.underline.dashed", expected: "decided", claim: "SGR 4:5 selects a dashed underline" },
  { id: "sgr.underline.color", expected: "decided", claim: "SGR 58 selects an underline colour" },
  { id: "sgr.underline-color-indexed", expected: "decided", claim: "SGR 58;5 selects an indexed underline colour" },
  { id: "sgr.underline-color-rgb", expected: "decided", claim: "SGR 58;2 selects an RGB underline colour" },
  { id: "sgr.underline-color-reset", expected: "decided", claim: "SGR 59 resets the underline colour" },
  {
    id: "sgr.selective-reset.bold",
    expected: "decided",
    claim: "SGR 22 clears measured bold and faint while preserving measured italic",
  },
  {
    id: "sgr.selective-reset.italic",
    expected: "decided",
    claim: "SGR 23 clears measured italic while preserving measured bold",
  },
  {
    id: "sgr.selective-reset.underline",
    expected: "decided",
    claim: "SGR 24 clears measured underline while preserving measured bold",
  },
  {
    id: "sgr.selective-reset.inverse",
    expected: "decided",
    claim: "SGR 27 clears measured inverse while preserving measured bold",
  },
]

/** The named set 28454 reviews: SGR's rows plus the focused test files that bind them (no glob). */
const SGR_CONTRACT_SPEC: GroupContractSpec = {
  group: "sgr",
  rows: SGR_CONTRACT,
  tests: [
    "packages/probe-defs/src/sgr-contract.test.ts",
    "packages/probe-defs/src/helper-observations.test.ts",
    "packages/probe-defs/src/readback.test.ts",
  ],
}

type InertCell = ReturnType<HeadlessModel["getCell"]>

/** A neutral cell: no attribute, no colour. `underlineColor` is explicit so a reset comparison is measured. */
const INERT_CELL: InertCell = {
  char: " ",
  bold: false,
  dim: false,
  italic: false,
  underline: null,
  underlineColor: null,
  strikethrough: false,
  inverse: false,
  hidden: false,
  blink: false,
  overline: false,
  fg: null,
  bg: null,
  wide: false,
}

function inertModel(cols = 40, cell: Partial<InertCell> = {}): HeadlessModel {
  return {
    cols,
    feed: () => {},
    getCell: () => ({ ...INERT_CELL, ...cell }),
    getCursor: () => ({ x: 0, y: 0, visible: true, style: null }),
  }
}

type TableCell = Partial<InertCell> & { char: string }

/** A fixture X cell carrying only the attribute/colour the row's claim requires. */
const X = (cell: Partial<InertCell> = {}): TableCell => ({ char: "X", ...cell })

/**
 * One required headless cell state per SGR row: the state the row's claim says the sequence produces.
 * This is the satisfaction binding (the contract predicate and probe agree), not a claim that a real
 * terminal emits it - that is the term/capture path. Column n is the n-th cell the probe reads.
 * 2026-10-09 @adhoc/1 bounce + @dev/10 review: the old bold-only test plus a blanket "whole 32 rows"
 * reference to helper-observations.test.ts was false (that file pins several rows, not all).
 */
const SGR_SATISFACTION_CELLS: Record<string, readonly TableCell[]> = {
  // attributes
  "sgr.bold": [X({ bold: true })],
  "sgr.faint": [X({ dim: true })],
  "sgr.italic": [X({ italic: true })],
  "sgr.underline.single": [X({ underline: "single" })],
  "sgr.underline.double": [X({ underline: "double" })],
  "sgr.underline.curly": [X({ underline: "curly" })],
  "sgr.underline.dotted": [X({ underline: "dotted" })],
  "sgr.underline.dashed": [X({ underline: "dashed" })],
  "sgr.blink": [X({ blink: true })],
  "sgr.inverse": [X({ inverse: true })],
  "sgr.hidden": [X({ hidden: true })],
  "sgr.strikethrough": [X({ strikethrough: true })],
  // overline null means the engine exposes no bit: that row stays notTested, never a false off.
  "sgr.overline": [X({ overline: true })],
  // full + selective resets; measuredReset reads the C (baseline), X (styled), Y (reset) cells
  "sgr.reset": [{ char: "C" }, X({ bold: true, italic: true, underline: "single" }), { char: "Y" }],
  "sgr.selective-reset.bold": [{ char: "C" }, X({ bold: true, dim: true, italic: true }), { char: "Y", italic: true }],
  "sgr.selective-reset.italic": [{ char: "C" }, X({ bold: true, italic: true }), { char: "Y", bold: true }],
  "sgr.selective-reset.underline": [{ char: "C" }, X({ bold: true, underline: "single" }), { char: "Y", bold: true }],
  "sgr.selective-reset.inverse": [{ char: "C" }, X({ bold: true, inverse: true }), { char: "Y", bold: true }],
  // named + default colours
  "sgr.fg.standard": [{ char: "C" }, X({ fg: { r: 170, g: 0, b: 0 } }), { char: "Y", fg: { r: 0, g: 0, b: 170 } }],
  "sgr.fg.bright": [{ char: "C" }, X({ fg: { r: 170, g: 0, b: 0 } }), { char: "Y", fg: { r: 0, g: 0, b: 170 } }],
  "sgr.bg.standard": [{ char: "C" }, X({ bg: { r: 170, g: 0, b: 0 } }), { char: "Y", bg: { r: 0, g: 0, b: 170 } }],
  "sgr.bg.bright": [{ char: "C" }, X({ bg: { r: 170, g: 0, b: 0 } }), { char: "Y", bg: { r: 0, g: 0, b: 170 } }],
  "sgr.fg.default": [{ char: "C" }, X({ fg: { r: 170, g: 0, b: 0 } }), { char: "R" }],
  "sgr.bg.default": [{ char: "C" }, X({ bg: { r: 0, g: 170, b: 0 } }), { char: "R" }],
  // indexed + truecolor: C/A/B controls, X/Y targets
  "sgr.fg.256": [
    { char: "C" },
    { char: "A", fg: { r: 95, g: 135, b: 175 } },
    { char: "B", fg: { r: 215, g: 135, b: 95 } },
    X({ fg: { r: 95, g: 135, b: 175 } }),
    { char: "Y", fg: { r: 215, g: 135, b: 95 } },
  ],
  "sgr.bg.256": [
    { char: "C" },
    { char: "A", bg: { r: 95, g: 135, b: 175 } },
    { char: "B", bg: { r: 215, g: 135, b: 95 } },
    X({ bg: { r: 95, g: 135, b: 175 } }),
    { char: "Y", bg: { r: 215, g: 135, b: 95 } },
  ],
  "sgr.fg.truecolor": [
    { char: "C" },
    { char: "A", fg: { r: 0, g: 0, b: 255 } },
    { char: "B", fg: { r: 0, g: 255, b: 0 } },
    X({ fg: { r: 255, g: 128, b: 0 } }),
    { char: "Y", fg: { r: 17, g: 97, b: 201 } },
  ],
  "sgr.bg.truecolor": [
    { char: "C" },
    { char: "A", bg: { r: 0, g: 0, b: 255 } },
    { char: "B", bg: { r: 0, g: 255, b: 0 } },
    X({ bg: { r: 0, g: 255, b: 128 } }),
    { char: "Y", bg: { r: 17, g: 97, b: 201 } },
  ],
  // underline colours: A/B controls, X/Y targets
  "sgr.underline.color": [
    { char: "A", underline: "single", fg: { r: 0, g: 0, b: 255 } },
    { char: "B", underline: "single", fg: { r: 0, g: 255, b: 0 } },
    X({ underline: "single", underlineColor: { r: 255, g: 0, b: 128 } }),
  ],
  "sgr.underline-color-rgb": [
    { char: "A", underline: "single", fg: { r: 0, g: 0, b: 255 } },
    { char: "B", underline: "single", fg: { r: 0, g: 255, b: 0 } },
    X({ underline: "single", underlineColor: { r: 255, g: 0, b: 128 } }),
  ],
  "sgr.underline-color-indexed": [
    { char: "A", underline: "single", fg: { r: 0, g: 0, b: 255 } },
    X({ underline: "single", underlineColor: { r: 0, g: 255, b: 0 } }),
    { char: "B", underline: "single", fg: { r: 0, g: 255, b: 0 } },
    { char: "Y", underline: "single", underlineColor: { r: 0, g: 0, b: 255 } },
  ],
  "sgr.underline-color-reset": [
    { char: "C", underline: "single" },
    X({ underline: "single", underlineColor: { r: 255, g: 0, b: 128 } }),
    { char: "Y", underline: "single" },
  ],
}

/** A headless model whose column cells are fixed: the probe reads the cells its fed fixture names. */
function cellsModel(cells: readonly TableCell[]): HeadlessModel {
  return {
    cols: Math.max(40, cells.length),
    feed: () => {},
    getCell: (_row, col) => ({ ...INERT_CELL, ...cells[col] }),
    getCursor: () => ({ x: 0, y: 0, visible: true, style: null }),
  }
}

test("the SGR contract covers every SGR feature and names none unknown", () => {
  const gaps = contractGaps(sgrProbes, SGR_CONTRACT)
  expect(gaps.uncovered).toEqual([])
  expect(gaps.unknown).toEqual([])
  expect(sgrProbes).toHaveLength(32)
  expect(SGR_CONTRACT).toHaveLength(32)
})

test("the SGR contract names its focused tests, and every named file exists", () => {
  const root = join(import.meta.dirname, "../../..")
  expect(missingContractTests(SGR_CONTRACT_SPEC, root)).toEqual([])
  // The re-grade command names the runners and the files, and never a glob (2026-10-09 @dev/3 correction).
  const command = regradeCommand(SGR_CONTRACT_SPEC)
  expect(command).toContain("bunx --bun vitest run")
  expect(command).not.toContain("bun test")
  expect(command).not.toMatch(/[*?]/u)
  for (const path of SGR_CONTRACT_SPEC.tests) expect(command).toContain(path)
})

// Determinism only (2026-10-09 @dev/10 review): the inert model feeds nothing, so this replay can
// prove the harness is deterministic, NOT that a decided row is satisfied. The satisfaction binding is
// proven by SGR_SATISFACTION_CELLS below (one required cell state per row, driven through regradeRow);
// helper-observations.test.ts additionally pins several rows against real parse paths.
test("the harness replays every SGR feature deterministically (satisfaction is bound by the table test below)", async () => {
  for (const row of SGR_CONTRACT) {
    const probe = sgrProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing SGR probe ${row.id}`).toBeDefined()
    if (!probe) continue
    expect(probe.lib !== null || probe.term !== null, `${row.id} has no callback`).toBe(true)
    const first = await regradeRow(probe, row, { headless: libProbeSource(inertModel()) })
    const second = await regradeRow(probe, row, { headless: libProbeSource(inertModel()) })
    expect(second.after, `${row.id} is not deterministic`).toBe(first.after)
    expect(second.satisfies, `${row.id} satisfaction is not deterministic`).toBe(first.satisfies)
    // The harness APPLIES the contract predicate; a re-grade is never a rubber stamp.
    expect(first.satisfies, `${row.id} must route through satisfiesContract`).toBe(satisfiesContract(row, first.after))
  }
})

// The bound satisfaction proof: every decided row reads "supported" from the cell state its claim
// requires. This is the table proof the determinism replay above cannot show on its own
// (2026-10-09 @adhoc/1 bounce + @dev/10 review).
test("every SGR contract row is satisfied by the headless cell state its claim requires", async () => {
  for (const row of SGR_CONTRACT) {
    const probe = sgrProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing SGR probe ${row.id}`).toBeDefined()
    if (!probe) continue
    const cells = SGR_SATISFACTION_CELLS[row.id]
    expect(cells, `no satisfaction cell state declared for ${row.id}`).toBeDefined()
    if (!cells) continue
    const graded = await regradeRow(probe, row, { headless: libProbeSource(cellsModel(cells)) })
    expect(graded.after, `${row.id} reads supported from its claim's cell state`).toBe("supported")
    expect(graded.satisfies, `${row.id} satisfies its contract row`).toBe(true)
  }
  // The table names EVERY decided row, so a newly added SGR row cannot ride the contract unbound.
  const decided = SGR_CONTRACT.filter((row) => row.expected === "decided").map((row) => row.id)
  expect(Object.keys(SGR_SATISFACTION_CELLS).sort()).toEqual(decided.sort())
})

test("a row reading overline is notTested when the bit is null, bound when present", async () => {
  // null is "the engine exposes no bit" (d90759cc). Present true satisfies the row. null is not a false off.
  const row = SGR_CONTRACT.find((entry) => entry.id === "sgr.overline")
  const probe = sgrProbes.find((entry) => entry.id === "sgr.overline")
  expect(row, "the SGR contract names sgr.overline").toBeDefined()
  expect(probe, "the SGR contract names a real sgr.overline probe").toBeDefined()
  if (!row || !probe) return
  const present = await regradeRow(probe, row, { headless: libProbeSource(cellsModel([X({ overline: true })])) })
  expect(present.after).toBe("supported")
  expect(present.satisfies).toBe(true)
  const omittedSource = libProbeSource(cellsModel([{ char: "X", overline: null }]))
  const omitted = await regradeRow(probe, row, { headless: omittedSource })
  expect(omitted.after).toBeUndefined()
  expect(omitted.satisfies).toBe(false)
  expect(probe.lib?.(omittedSource).notTested).toEqual({
    reason: "no-semantic-observable",
    noObservable:
      "Open: our adapter for this library does not read overline from its screen cells yet, so our test cannot see overline.",
  })
})

/**
 * The assigned SGR effect rows decide absent target effects only with passing same-reader controls
 * (#32318). Missing observables or a failed control remain open; source never decides support.
 */
const underlineColorUnexposed =
  "Open: we set an underline colour (SGR 58), but the screen cell shows none, so we cannot tell whether the library ignored it or does not report it."
const SGR_SEMANTIC_SURFACE_CONTROLS: readonly (readonly [
  id: string,
  mutation: string,
  negativeOutcome: "inconclusive" | "unsupported" | "probe-todo",
  noObservable?: string,
])[] = [
  ["sgr.bold", "bold-noop", "inconclusive"],
  ["sgr.faint", "faint-noop", "unsupported"],
  ["sgr.italic", "italic-noop", "unsupported"],
  ["sgr.underline.single", "underline-single-noop", "inconclusive"],
  ["sgr.underline.double", "underline-double-noop", "unsupported"],
  ["sgr.underline.curly", "underline-curly-noop", "unsupported"],
  ["sgr.underline.dotted", "underline-dotted-noop", "unsupported"],
  ["sgr.underline.dashed", "underline-dashed-noop", "unsupported"],
  ["sgr.blink", "blink-noop", "unsupported"],
  ["sgr.inverse", "inverse-noop", "inconclusive"],
  ["sgr.hidden", "hidden-noop", "unsupported"],
  ["sgr.strikethrough", "strikethrough-noop", "unsupported"],
  ["sgr.overline", "overline-noop", "inconclusive"],
  ["sgr.underline.color", "underline-color-noop", "probe-todo", underlineColorUnexposed],
  ["sgr.underline-color-indexed", "underline-color-indexed-noop", "probe-todo", underlineColorUnexposed],
  ["sgr.underline-color-rgb", "underline-color-rgb-noop", "probe-todo", underlineColorUnexposed],
  ["sgr.underline-color-reset", "sgr59-noop", "unsupported"],
  ["sgr.fg.standard", "fg-standard-noop", "probe-todo"],
  ["sgr.bg.standard", "bg-standard-noop", "probe-todo"],
  ["sgr.fg.bright", "fg-bright-noop", "unsupported"],
  ["sgr.bg.bright", "bg-bright-noop", "unsupported"],
  ["sgr.fg.default", "fg-default-noop", "unsupported"],
  ["sgr.bg.default", "bg-default-noop", "unsupported"],
  ["sgr.fg.256", "fg-256-noop", "unsupported"],
  ["sgr.bg.256", "bg-256-noop", "unsupported"],
  ["sgr.fg.truecolor", "fg-truecolor-noop", "unsupported"],
  ["sgr.bg.truecolor", "bg-truecolor-noop", "unsupported"],
  ["sgr.selective-reset.bold", "sgr22-noop", "unsupported"],
  ["sgr.selective-reset.underline", "sgr24-noop", "unsupported"],
  ["sgr.selective-reset.italic", "sgr23-noop", "unsupported"],
  ["sgr.selective-reset.inverse", "sgr27-noop", "unsupported"],
  ["sgr.reset", "sgr0-noop", "unsupported"],
]

test("SGR_SEMANTIC_SURFACE_CONTROLS covers all 32 SGR contract rows with distinct mutations", () => {
  expect(SGR_SEMANTIC_SURFACE_CONTROLS).toHaveLength(32)
  expect(SGR_SEMANTIC_SURFACE_CONTROLS.map(([id]) => id).sort()).toEqual(SGR_CONTRACT.map((row) => row.id).sort())
  expect(new Set(SGR_SEMANTIC_SURFACE_CONTROLS.map(([, mutation]) => mutation)).size).toBe(32)
})

test.each(
  SGR_SEMANTIC_SURFACE_CONTROLS.map(([id, mutation, negativeOutcome, noObservable]) => ({
    id,
    mutation,
    negativeOutcome,
    noObservable,
  })),
)(
  "$id reads supported on createSemanticSurface and $mutation when $negativeOutcome is active",
  async ({ id, mutation, negativeOutcome, noObservable }) => {
    const row = SGR_CONTRACT.find((entry) => entry.id === id)
    const probe = sgrProbes.find((entry) => entry.id === id)
    expect(row, `the SGR contract names ${id}`).toBeDefined()
    expect(probe, `the SGR contract names a real ${id} probe`).toBeDefined()
    if (!row || !probe || !probe.lib) return

    const positiveSource = libProbeSource(createSemanticSurface())
    const positiveResult = probe.lib(positiveSource)
    expect(positiveResult.observation?.outcome).toBe("supported")
    expect(positiveResult.assertions ?? []).toContainEqual(
      expect.objectContaining({ kind: "positive", assertionType: "buffer_state" }),
    )
    const positiveGraded = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    expect(positiveGraded.after).toBe("supported")
    expect(positiveGraded.satisfies).toBe(true)

    const negativeSurface = createSemanticSurface({ mutations: [mutation] })
    const negativeResult = probe.lib(libProbeSource(negativeSurface))
    expect(negativeResult.pass).toBe(false)
    if (negativeOutcome === "probe-todo") expectNoSamePathTodo(negativeResult, noObservable)
    else expect(negativeResult.observation?.outcome).toBe(negativeOutcome)
    const negativeGraded = await regradeRow(probe, row, {
      headless: libProbeSource(createSemanticSurface({ mutations: [mutation] })),
    })
    expect(negativeGraded.after).toBe(negativeOutcome === "probe-todo" ? undefined : negativeOutcome)
    expect(negativeGraded.satisfies).toBe(negativeOutcome === "unsupported")
    if (
      negativeOutcome === "unsupported" &&
      [
        "sgr.faint",
        "sgr.italic",
        "sgr.blink",
        "sgr.hidden",
        "sgr.strikethrough",
        "sgr.underline.double",
        "sgr.underline.curly",
        "sgr.underline.dotted",
        "sgr.underline.dashed",
        "sgr.fg.bright",
        "sgr.bg.bright",
        "sgr.fg.256",
        "sgr.bg.256",
      ].includes(id)
    ) {
      expect(JSON.parse(negativeResult.response!)).toMatchObject({
        input: { target: expect.stringContaining("X"), control: expect.stringContaining("\x1b[") },
      })
      expect(negativeResult.assertions).toContainEqual(
        expect.objectContaining({ kind: "negative", assertionType: "buffer_state" }),
      )
      const controlMutation = id.startsWith("sgr.underline.")
        ? "underline-single-noop"
        : id.startsWith("sgr.fg.")
          ? "fg-standard-noop"
          : id.startsWith("sgr.bg.")
            ? "bg-standard-noop"
            : "bold-noop"
      const withoutControl = probe.lib(
        libProbeSource(createSemanticSurface({ mutations: [mutation, controlMutation] })),
      )
      expect(withoutControl.observation?.outcome).not.toBe("supported")
      expect(withoutControl.observation?.outcome).not.toBe("unsupported")
      const inert = probe.lib(libProbeSource(inertModel()))
      expect(inert.observation?.outcome).not.toBe("supported")
      expect(inert.observation?.outcome).not.toBe("unsupported")
      if (id.startsWith("sgr.underline.")) {
        const surface = createSemanticSurface({ mutations: [mutation] })
        const collapsed = libProbeSource(surface)
        collapsed.getCell = (row, col) => ({
          ...surface.getCell(row, col),
          // Actual yes/no adapters normalize every enabled style to "single".
          underline: surface.getCell(row, col).underline ? "single" : false,
        })
        const collapsedResult = probe.lib(collapsed)
        expect(collapsedResult.notTested).toMatchObject({ reason: "no-semantic-observable" })
        expect(collapsedResult.observation?.outcome).not.toBe("unsupported")
        const otherStyleMutation = id === "sgr.underline.double" ? "underline-curly-noop" : "underline-double-noop"
        const withoutStyleControl = probe.lib(
          libProbeSource(createSemanticSurface({ mutations: [mutation, otherStyleMutation] })),
        )
        expect(withoutStyleControl.observation?.outcome).not.toBe("unsupported")
      }
    }
  },
)

// DEC 0.13.1 exposes a boolean, not normalized hidden styles.
// Existing generic style-control tests do not exercise the versioned plain-cell exception.
test.each(
  (["vt100", "vt220"] as const).flatMap((backend) =>
    (
      [
        ["sgr.underline.curly", "underline-curly-noop"],
        ["sgr.underline.dotted", "underline-dotted-noop"],
        ["sgr.underline.dashed", "underline-dashed-noop"],
      ] as const
    ).map(([id, mutation]) => [backend, id, mutation] as const),
  ),
)("%s 0.13.1 decides %s from a controlled public boolean", (backend, id, mutation) => {
  const definition = sgrProbes.find((entry) => entry.id === id)!
  const source = (backendName: string = backend, engineVersion = "0.13.1") => {
    const surface = createSemanticSurface({ mutations: [mutation, "underline-double-noop"] })
    return {
      ...libProbeSource(surface),
      // DEC's adapter maps its real boolean directly: an off flag is false, not an unreported null.
      getCell: (row: number, col: number) => ({
        ...surface.getCell(row, col),
        underline: surface.getCell(row, col).underline ? ("single" as const) : (false as const),
      }),
      backendName,
      runtimeIdentity: {
        kind: "js" as const,
        runtimeFormat: "js" as const,
        engineVersion,
        adapterVersion: "test",
        termlessRevision: "fixture",
        resolvedPath: "/fixture/engine",
        integrity: { kind: "registry" as const, lockIntegrity: "fixture" },
      },
    }
  }
  const result = definition.lib!(source())
  expect(result.observation?.outcome).toBe("unsupported")
  expect(definition.lib!(source(backend, "0.13.2")).observation?.outcome).toBe("unsupported")
  expect(definition.lib!(source(backend, "0.14.0")).observation?.outcome).toBe("unsupported")
  expect(JSON.stringify(result)).toContain(
    `${backend}: ordinary SGR 4 sets the public underline flag; this colon form leaves it off and the cell has no style field`,
  )
  for (const changed of [source(backend, "0.13.3"), source(backend, "0.14.1"), source("another-backend")]) {
    expect(definition.lib!(changed).observation?.outcome).not.toBe("unsupported")
  }
  // A normalized single target, failed single control, or missing D marker proves no negative.
  for (const [col, patch] of [
    [0, { underline: "single" as const }],
    [1, { underline: false as const }],
    [2, { char: "" }],
  ] as const) {
    const changed = source()
    const read = changed.getCell
    changed.getCell = (row, x) => ({ ...read(row, x), ...(x === col ? patch : {}) })
    expect(definition.lib!(changed).observation?.outcome).not.toBe("unsupported")
  }
})

// One negative assertion, on bold: the table above is the positive proof for all 32 rows; this only
// pins that an inert cell is not satisfied. It is deliberately NOT a per-row negative suite, because
// the other rows carry no speculative negative (@dev/10 2026-10-09).
test("a decided SGR row reads unsatisfied from an inert cell", async () => {
  const row = SGR_CONTRACT.find((entry) => entry.id === "sgr.bold")
  const probe = sgrProbes.find((entry) => entry.id === "sgr.bold")
  expect(row, "the SGR contract names sgr.bold").toBeDefined()
  expect(probe, "the SGR contract names a real sgr.bold probe").toBeDefined()
  if (!row || !probe) return
  const inert = await regradeRow(probe, row, { headless: libProbeSource(inertModel()) })
  expect(inert.satisfies).toBe(false)
})

// Existing satisfaction rows cover true only; preserve false and missing-X failures separately.
// #32329: a generic null-field message does not identify the checked public prerequisite.
test.each([
  ["vt100", "0.10.1", "sgr.faint", "dim", "vt100.js 0.10.1 public ScreenCell has no dim field"],
  ["vt100", "0.10.1", "sgr.italic", "italic", "vt100.js 0.10.1 public ScreenCell has no italic field"],
  [
    "vt100",
    "0.10.1",
    "sgr.strikethrough",
    "strikethrough",
    "vt100.js 0.10.1 public ScreenCell has no strikethrough field",
  ],
  ["vt220", "0.10.1", "sgr.faint", "dim", "vt220.js 0.10.1 public ScreenCell has no dim field"],
  ["vt220", "0.10.1", "sgr.italic", "italic", "vt220.js 0.10.1 public ScreenCell has no italic field"],
  [
    "vt220",
    "0.10.1",
    "sgr.strikethrough",
    "strikethrough",
    "vt220.js 0.10.1 public ScreenCell has no strikethrough field",
  ],
  ["alacritty", "0.26.0", "sgr.blink", "blink", "alacritty_terminal 0.26.0 public term::cell::Flags has no blink flag"],
  ["vt100-rust", "0.16.2", "sgr.blink", "blink", "vt100 0.16.2 public Cell has no blink reader"],
  [
    "vt100-rust",
    "0.16.2",
    "sgr.strikethrough",
    "strikethrough",
    "vt100 0.16.2 public Cell has no strikethrough reader",
  ],
] as const)("%s %s names its checked %s reader prerequisite", (backendName, engineVersion, id, field, prerequisite) => {
  const probe = sgrProbes.find((probe) => probe.id === id)!
  const surface = createSemanticSurface()
  const source = {
    ...libProbeSource(surface),
    backendName,
    runtimeIdentity: {
      kind: "js" as const,
      runtimeFormat: "js" as const,
      engineVersion,
      adapterVersion: "test",
      termlessRevision: "fixture",
      resolvedPath: "/fixture/engine",
      integrity: { kind: "registry" as const, lockIntegrity: "fixture" },
    },
    getCell: (row: number, col: number) => ({ ...surface.getCell(row, col), [field]: null }),
  }
  expectNoSamePathTodo(
    probe.lib!(source),
    `Open: our test could not read ${field} from the screen cells and found no qualified alternative in this run. ${prerequisite}.`,
  )
  expectNoSamePathTodo(
    probe.lib!({ ...source, runtimeIdentity: { ...source.runtimeIdentity, engineVersion: "unreviewed" } }),
    `Open: our test could not read ${field} from the screen cells and found no qualified alternative in this run.`,
  )
  const measured = probe.lib!({ ...source, getCell: (row, col) => surface.getCell(row, col) })
  expect(measured.observation?.outcome).toBe("supported")
})

// #32246: an unreported or false attribute has no same-path control, so it is PROBE TODO with its retained state.
test.each([
  ["sgr.faint", "dim"],
  ["sgr.italic", "italic"],
  ["sgr.strikethrough", "strikethrough"],
  ["sgr.blink", "blink"],
] as const)("%s retains unreported %s as PROBE TODO without a same-path control", (id, field) => {
  const probe = sgrProbes.find((probe) => probe.id === id)!
  const run = (value: boolean | null, char = "X") =>
    probe.lib!(libProbeSource(inertModel(40, { [field]: value, char })))
  const surface = createSemanticSurface()
  const unreported = libProbeSource(surface)
  unreported.getCell = (row, col) => ({ ...surface.getCell(row, col), [field]: null })
  const missingReader = `Open: our test could not read ${field} from the screen cells and found no qualified alternative in this run.`
  expectNoSamePathTodo(probe.lib!(unreported), missingReader)
  const missing = run(null)
  expectNoSamePathTodo(missing, missingReader)
  expect(JSON.parse(missing.response!)).toEqual(expect.objectContaining({ [field]: null }))
  expect(run(true).observation?.outcome).toBe("supported")
  const measuredNegative = run(false)
  expectNoSamePathTodo(measuredNegative)
  expect(JSON.parse(measuredNegative.response!)).toEqual(expect.objectContaining({ [field]: false }))
  expect(run(null, " ").observation?.outcome).toBe("inconclusive")
  expect(run(null, " ").notTested).toBeUndefined()
  expect(run(null, " ").criterionBranch).toBeUndefined()
  expect(run(null, " ").assertions).toBeUndefined()
})

// #31766: these causes came from the retained VT100/VT220/libvterm/Rust states.
// A reset without a distinct colored seed is unmeasured, even when its parser lacks the setup.
test.each(["sgr.fg.default", "sgr.bg.default", "sgr.underline-color-reset"])(
  "%s names its missing colored seed as TODO without changing the retained state",
  (id) => {
    const probe = sgrProbes.find((entry) => entry.id === id)!
    const cells: TableCell[] = [
      { char: "C", underline: "single" },
      { char: "X" },
      { char: id === "sgr.underline-color-reset" ? "Y" : "R" },
    ]
    const result = probe.lib!(libProbeSource(cellsModel(cells)))
    // The missing coloured seed is a missing prerequisite with its own cause (@cto batch7 A-F5).
    if (id === "sgr.underline-color-reset") {
      expect(result.notTested).toEqual({
        reason: "no-semantic-observable",
        noObservable:
          "Open: after we set an underline colour (SGR 58), the screen cell showed none, so the setup did not show and the reset cannot be tested.",
      })
    } else {
      expect(result.criterionBranch).toBe("headless-observable-review")
      expect(result.tests).toContainEqual(
        expect.objectContaining({
          id: "review",
          status: "probe-todo",
          reason:
            id === "sgr.fg.default"
              ? "Open: our test could not read the text colour we set first (SGR 31), so we cannot tell whether the reset to default worked."
              : "Open: our test could not read the background colour we set first (SGR 42), so we cannot tell whether the reset to default worked.",
        }),
      )
    }
    expect(result.assertions).toBeUndefined()
    expect(JSON.parse(result.response!)).toMatchObject({
      before: { char: "X", fg: null, bg: null, underlineColor: null },
      after: { char: cells[2]!.char },
    })

    // A missing fixture cell is a different cause; it must not inherit the seed TODO.
    const missing = probe.lib!(libProbeSource(cellsModel([{ char: " " }, ...cells.slice(1)])))
    expect(missing.tests?.some((row) => row.status === "probe-todo")).not.toBe(true)
  },
)

test.each(["sgr.selective-reset.bold", "sgr.selective-reset.italic"])(
  "%s names the unobserved setup facets while retaining PROBE TODO",
  (id) => {
    const probe = sgrProbes.find((entry) => entry.id === id)!
    const result = probe.lib!(
      libProbeSource(
        cellsModel([
          { char: "C", dim: null, italic: null },
          { char: "X", bold: true, dim: null, italic: null },
          { char: "Y", bold: id.endsWith("italic"), dim: null, italic: null },
        ]),
      ),
    )
    expect(result.notTested).toEqual({
      reason: "no-semantic-observable",
      noObservable: `Open: ${id.endsWith("bold") ? "dim and italic and underline" : "italic"} did not show during setup, so our test cannot check the combined reset.`,
    })
    expect(result.pass).toBe(false)
    expect(result.observation).toBeUndefined()
    expect(result.assertions).toBeUndefined()
    expect(result.tests).toBeUndefined()
    expect(result.criterionBranch).toBeUndefined()
    expect(JSON.parse(result.response!)).toMatchObject({ before: { bold: true, dim: null, italic: null } })
  },
)

test.each(["fg", "bg"] as const)(
  "a distinct %s seed names its unexposed reset field while retaining PROBE TODO",
  (channel) => {
    const source = libProbeSource(
      cellsModel([{ char: "C" }, { char: "X", [channel]: { r: 205, g: 0, b: 0 } }, { char: "R" }]),
    )
    const read = source.getCell
    source.getCell = (row, col) => {
      const cell = read(row, col)
      // The reset field is unexposed; this is not a seedless fixture or an engine absence claim.
      if (col === 2) Reflect.deleteProperty(cell, channel)
      return cell
    }
    const result = sgrProbes.find((entry) => entry.id === `sgr.${channel}.default`)!.lib!(source)
    expect(result.notTested).toEqual({
      reason: "no-semantic-observable",
      noObservable: `reset cell exposes no ${channel === "fg" ? "foreground" : "background"} colour after a distinct seed; an unexposed value cannot show the reset`,
    })
    expect(result.pass).toBe(false)
    expect(result.observation).toBeUndefined()
    expect(result.assertions).toBeUndefined()
    expect(result.tests).toBeUndefined()
    expect(result.criterionBranch).toBeUndefined()
    expect(JSON.parse(result.response!)).toMatchObject({
      before: { [channel]: { r: 205, g: 0, b: 0 } },
      after: { char: "R" },
    })
  },
)

test.each(["wrong requested color", "baseline already requested color"])(
  "SGR59 names its requested-color prerequisite: %s",
  (cause) => {
    const pink = { r: 255, g: 0, b: 128 }
    const blue = { r: 0, g: 0, b: 255 }
    const result = sgrProbes.find((entry) => entry.id === "sgr.underline-color-reset")!.lib!(
      libProbeSource(
        cellsModel([
          { char: "C", underline: "single", underlineColor: cause.startsWith("baseline") ? pink : null },
          { char: "X", underline: "single", underlineColor: cause.startsWith("baseline") ? pink : blue },
          { char: "Y", underline: "single", underlineColor: null },
        ]),
      ),
    )
    expect(result.tests).toContainEqual(
      expect.objectContaining({
        id: "review",
        status: "probe-todo",
        reason: expect.stringContaining("requested rgb(255,0,128)"),
      }),
    )
    expect(result.assertions).toBeUndefined()
  },
)

/** @failure Missing cell attributes are falsely graded from an unqualified DECRQSS facility or DECSTBM fallback. @level l2 @consumer Group2 libvterm SGR effect readback */
test.each([
  ["1", "2", "supported"],
  ["1", "0", "unsupported"],
  ["0", "0", undefined],
  [null, "0", undefined],
] as const)("unreported faint uses only qualified SGR m control %s before target %s", (control, target, expected) => {
  const probe = sgrProbes.find((entry) => entry.id === "sgr.faint")!
  const surface = createSemanticSurface()
  const ctx = libProbeSource(surface)
  ctx.getCell = (row, col) => ({ ...surface.getCell(row, col), dim: null })
  const replies = [control, target]
  const queries: string[] = []
  ctx.queryWithSentinelOutcome = (sequence, pattern) => {
    queries.push(sequence)
    const value = replies.shift()
    const raw = value == null ? "\x1bP1$r1;24r\x1b\\" : `\x1bP1$r${value}m\x1b\\`
    return { match: raw.match(pattern), raw, rawBase64: Buffer.from(raw).toString("base64"), reason: "reply" }
  }
  const result = probe.lib!(ctx)
  expect(result.observation?.outcome).toBe(expected)
  expect(queries).toEqual(expected ? ["\x1bP$qm\x1b\\", "\x1bP$qm\x1b\\"] : ["\x1bP$qm\x1b\\"])
  if (expected) expect(result.response).toContain("sgrReadback")
  else expect(result.notTested?.reason).toBe("no-semantic-observable")
})

// AC3: runtime style tests can pass while the independently declared cell type drifts.
// The compiler must carry the canonical style/color types across this real source boundary.
test("library cells share core attribute types and retain optional metadata", () => {
  type ReadCell = ReturnType<LibProbeSource["getCell"]>
  expectTypeOf<ReadCell["underline"]>().toEqualTypeOf<Cell["underline"] | true | null>()
  expectTypeOf<ReadCell["dim"]>().toEqualTypeOf<Cell["dim"]>()
  expectTypeOf<ReadCell["fg"]>().toEqualTypeOf<Cell["fg"]>()
  expectTypeOf<ReadCell["hyperlink"]>().toEqualTypeOf<Cell["hyperlink"] | undefined>()
  expectTypeOf<ReadCell["underlineColor"]>().toEqualTypeOf<Cell["underlineColor"] | undefined>()
})
