/**
 * @failure An input feature is graded without a bound contract row, or a re-grade of a decided
 *   observation moves it - so input protocol steps reinvent their own fixture and silently drift.
 * @level l2
 * @consumer 28449 probe definitions slice A: input protocols.
 * @reach fs-walk vendor/terminfo.dev/packages/probe-defs/src/input-contract.test.ts vendor/terminfo.dev/packages/probe-defs/src/input-observations.test.ts vendor/terminfo.dev/packages/probe-defs/src/input-xtest-observations.test.ts vendor/terminfo.dev/packages/probe-defs/src/probe-automation.test.ts
 * @testonly none
 */
import { expect, test } from "vitest"
import { join } from "node:path"
import { inputProbes } from "./input.ts"
import type { TermProbeSource, LibProbeSource } from "./types.ts"
import {
  contractGaps,
  libProbeSource,
  missingContractTests,
  regradeCommand,
  regradeRow,
  replayTermProbeSource,
  satisfiesContract,
  type GroupContract,
  type GroupContractSpec,
  type HeadlessModel,
} from "./testing/group-harness.ts"

/**
 * The 11 input protocol features (10 defined in input.ts + 1 catalog-only in features.json).
 * input.modify-other-keys grades through OS XTEST after CSI >4;2m (ctrl+i vs Tab);
 * input.modify-other-keys-3 grades unmodified i after CSI >4;3m with delivery control before enable;
 * input.csi-u negotiates Kitty keyboard protocol flag 1;
 * input.pixel-mouse grades SGR pixel coords under 1016 after a 1000+1006 cell control;
 * input.urxvt-mouse grades CSI btn;x;yM under 1015 after a 1000+1006 SGR control;
 * input.x10-mouse grades CSI M + 3 bytes under mode 9 alone after a 1000+1006 SGR control it leaves;
 * input.button-event-mouse grades SGR motion (Pb+32) before the release under 1002 after a 1000+1006 SGR control;
 * remaining catalog mouse event probes stay inconclusive pending their regrade;
 * input.xtest-key, input.xtest-click, and input.xtest-wheel execute OS-level injection with same-run delivery control;
 * input.kitty-click-events marks an OSC 133 prompt and grades the click report with mouse modes off.
 */
const INPUT_CONTRACT: GroupContract = [
  {
    id: "input.modify-other-keys",
    expected: "decided",
    claim:
      "modifyOtherKeys: CSI >4;2m then ctrl+i reports CSI 27;5;105~ or 105;5u after plain-a delivery control; Tab is unsupported",
  },
  { id: "input.csi-u", expected: "decided", claim: "CSI u: Kitty keyboard protocol flag 1 enables disambiguate mode" },
  {
    id: "input.pixel-mouse",
    expected: "decided",
    claim:
      "pixel-mouse: CSI ? 1016 then click reports SGR pixel coords distinct from the 1000+1006 cell control; same cell coords is unsupported",
  },
  {
    id: "input.urxvt-mouse",
    expected: "decided",
    claim:
      "urxvt-mouse: CSI ? 1015 then click reports CSI btn;x;yM without < after the 1000+1006 SGR control; SGR after 1015 is unsupported",
  },
  {
    id: "input.x10-mouse",
    expected: "decided",
    claim:
      "x10-mouse: after the 1000+1006 SGR control, reset both, then CSI ? 9 and click reports CSI M + 3 bytes (btn+32,x+32,y+32); silence is unsupported; SGR after 9 is PROBE INVALID",
  },
  {
    id: "input.modify-other-keys-3",
    expected: "decided",
    claim:
      "modifyOtherKeys-3: CSI >4;3m then unmodified i reports CSI 27;1;105~ or 105;1u after plain-a delivery control before enable; bare i is unsupported",
  },
  {
    id: "input.button-event-mouse",
    expected: "decided",
    claim:
      "button-event-mouse: CSI ? 1002 then drag reports SGR motion (Pb+32) before the release after the 1000+1006 SGR control; a release with no motion is unsupported",
  },
  {
    id: "input.xtest-key",
    expected: "decided",
    claim: "xtest-key: OS XTEST ctrl+e report after plain-a delivery control",
  },
  {
    id: "input.xtest-click",
    expected: "decided",
    claim: "xtest-click: OS XTEST button-1 report under 1000+1006 after same-run control click",
  },
  {
    id: "input.xtest-wheel",
    expected: "decided",
    claim: "xtest-wheel: OS XTEST wheel-4 report under 1000+1006 after same-run control click",
  },
  {
    id: "input.kitty-click-events",
    expected: "decided",
    claim:
      "kitty-click-events: OSC 133;A;click_events=1 on the click cell reports SGR mouse with mouse modes off after a 1000+1006 delivery control",
  },
]

/** The named set 28454 reviews: Input's rows plus the focused test files that bind them. */
const INPUT_CONTRACT_SPEC: GroupContractSpec = {
  group: "input",
  rows: INPUT_CONTRACT,
  tests: [
    "packages/probe-defs/src/input-contract.test.ts",
    "packages/probe-defs/src/input-observations.test.ts",
    "packages/probe-defs/src/input-xtest-observations.test.ts",
    "packages/probe-defs/src/probe-automation.test.ts",
  ],
}

function inputModel(csiUAnswered = false): HeadlessModel {
  return {
    cols: 80,
    feed: () => {},
    feedCapture: () => (csiUAnswered ? "\x1b[?1u\x1b[?1;0c\x1b[?1u" : ""),
    getCell: () => ({
      char: " ",
      bold: false,
      dim: false,
      italic: false,
      underline: null,
      underlineColor: null,
      strikethrough: false,
      inverse: false,
      hidden: false,
      blink: false,
      overline: false,
      fg: null,
      bg: null,
      wide: false,
    }),
    getCursor: () => ({ x: 0, y: 0, visible: true, style: null }),
  }
}

function inputSatisfactionSources(id: string): { readonly headless?: LibProbeSource; readonly term?: TermProbeSource } {
  if (id === "input.modify-other-keys") {
    return {
      term: replayTermProbeSource(new Map(), {
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async (pattern) => {
          if (pattern.test("a")) return ["a"]
          if (pattern.test("\x1b[27;5;105~")) return ["\x1b[27;5;105~"]
          return null
        },
      }),
    }
  }
  if (id === "input.modify-other-keys-3") {
    return {
      term: replayTermProbeSource(new Map(), {
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async (pattern) => {
          if (pattern.test("a")) return ["a"]
          if (pattern.test("\x1b[27;1;105~")) return ["\x1b[27;1;105~"]
          return null
        },
      }),
    }
  }
  if (id === "input.xtest-key") {
    return {
      term: replayTermProbeSource(new Map(), {
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async (pattern) => {
          if (pattern.test("a")) return ["a"]
          if (pattern.test("\x1b[101;5u")) return ["\x1b[101;5u"]
          return null
        },
      }),
    }
  }
  if (id === "input.pixel-mouse") {
    let callCount = 0
    return {
      term: replayTermProbeSource(
        new Map([
          ["\x1b[16t", { sequence: "\x1b[16t", raw: "\x1b[6;16;16t", match: null, reason: "reply" as const }],
          ["\x1b[14t", { sequence: "\x1b[14t", raw: "\x1b[4;384;1280t", match: null, reason: "reply" as const }],
        ]),
        {
          input: { injectKey: async () => {}, injectClick: async () => {} },
          readInput: async () => {
            callCount++
            return callCount % 2 === 1 ? ["\x1b[<0;10;5M"] : ["\x1b[<0;160;80M"]
          },
        },
      ),
    }
  }
  if (id === "input.kitty-click-events") {
    const writes: string[] = []
    return {
      term: replayTermProbeSource(new Map(), {
        write: (text) => writes.push(text),
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async (pattern) => {
          // Kitty reports a prompt click only on the main linebuf at the current visible prompt;
          // the rejected alternate-screen fixture must therefore stay silent.
          if (pattern.test("\x1b[<0;10;5m") && !pattern.test("\x1b[<0;10;5M")) return null
          if (writes.some((write) => write.includes("?1049h"))) return null
          const mouseSet = writes.findLastIndex((write) => write.includes("\x1b[?1000h"))
          const mouseReset = writes.findLastIndex((write) => write.includes("\x1b[?1000l"))
          const promptStart = writes.findLastIndex((write) => write.includes("\x1b]133;A;click_events=1"))
          const promptEnd = writes.findLastIndex((write) => write.includes("\x1b]133;B"))
          if (mouseReset > mouseSet && promptEnd > promptStart) return null
          return ["\x1b[<0;10;5M"]
        },
      }),
    }
  }
  if (id === "input.urxvt-mouse") {
    let callCount = 0
    return {
      term: replayTermProbeSource(new Map(), {
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async () => {
          callCount++
          return callCount % 2 === 1 ? ["\x1b[<0;10;5M"] : ["\x1b[0;10;5M"]
        },
      }),
    }
  }
  if (id === "input.x10-mouse") {
    let callCount = 0
    return {
      term: replayTermProbeSource(new Map(), {
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async () => {
          callCount++
          return callCount % 2 === 1 ? ["\x1b[<0;10;5M"] : ["\x1b[M\x20\x2a\x25"]
        },
      }),
    }
  }
  if (id === "input.button-event-mouse") {
    let callCount = 0
    return {
      term: replayTermProbeSource(new Map(), {
        input: {
          injectKey: async () => {},
          injectClick: async () => {},
          injectDrag: async () => {},
        },
        readInput: async () => {
          callCount++
          return callCount % 2 === 1 ? ["\x1b[<0;10;5M"] : ["\x1b[<32;12;5M"]
        },
      }),
    }
  }
  if (id === "input.xtest-click") {
    return {
      term: replayTermProbeSource(new Map(), {
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async (pattern) => {
          if (pattern.test("\x1b[<0;1;1M")) return ["\x1b[<0;1;1M"]
          return null
        },
      }),
    }
  }
  if (id === "input.xtest-wheel") {
    let callCount = 0
    return {
      term: replayTermProbeSource(new Map(), {
        input: { injectKey: async () => {}, injectClick: async () => {} },
        readInput: async (pattern) => {
          callCount++
          if (callCount === 1) return ["\x1b[<0;10;10M"]
          return ["\x1b[<64;10;10M"]
        },
      }),
    }
  }
  return { headless: libProbeSource(inputModel(true)) }
}

test("the input contract covers every input feature and names none unknown", () => {
  const gaps = contractGaps(inputProbes, INPUT_CONTRACT, INPUT_CONTRACT_SPEC.namedUnavailable)
  expect(gaps.uncovered).toEqual([])
  expect(gaps.unknown).toEqual([])
  expect(gaps.misdeclared).toEqual([])
  expect(inputProbes).toHaveLength(11)
  expect(INPUT_CONTRACT).toHaveLength(11)
})

test("the input contract names its focused tests, and every named file exists", () => {
  const root = join(import.meta.dirname, "../../..")
  expect(missingContractTests(INPUT_CONTRACT_SPEC, root)).toEqual([])
  const command = regradeCommand(INPUT_CONTRACT_SPEC)
  expect(command).toContain("bunx --bun vitest run")
  expect(command).not.toContain("bun test")
  expect(command).not.toMatch(/[*?]/u)
  for (const path of INPUT_CONTRACT_SPEC.tests) expect(command).toContain(path)
})

test("the harness replays every input feature deterministically", async () => {
  for (const row of INPUT_CONTRACT) {
    const probe = inputProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing input probe ${row.id}`).toBeDefined()
    if (!probe) continue
    expect(probe.lib !== null || probe.term !== null, `${row.id} has no callback`).toBe(true)
    const context = inputSatisfactionSources(row.id)
    const first = await regradeRow(probe, row, context)
    const second = await regradeRow(probe, row, context)
    expect(second.after, `${row.id} is not deterministic`).toBe(first.after)
    expect(second.satisfies, `${row.id} satisfaction is not deterministic`).toBe(first.satisfies)
    expect(first.satisfies, `${row.id} must route through satisfiesContract`).toBe(satisfiesContract(row, first.after))
  }
})

test("every defined input contract row is satisfied by the harness context its claim requires", async () => {
  for (const row of INPUT_CONTRACT) {
    const probe = inputProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing input probe ${row.id}`).toBeDefined()
    if (!probe) continue
    const context = inputSatisfactionSources(row.id)
    const graded = await regradeRow(probe, row, context)
    expect(graded.satisfies, `${row.id} satisfies its contract row (after=${graded.after})`).toBe(true)
  }
})

test("input.csi-u reads unsatisfied when protocol query is unacknowledged", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.csi-u")
  const probe = inputProbes.find((entry) => entry.id === "input.csi-u")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const silent = probe.lib!(libProbeSource(inputModel(false)))
  expect(silent.observation).toBeUndefined()
  expect(silent.tests).toMatchObject([expect.objectContaining({ status: "probe-invalid", reason: expect.any(String) })])
})

test("input.xtest-key reads unsatisfied when delivery control fails", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.xtest-key")
  const probe = inputProbes.find((entry) => entry.id === "input.xtest-key")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const failingSources = {
    term: replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async () => null,
    }),
  }
  await expect(regradeRow(probe, row, failingSources)).rejects.toThrow(/delivery control/i)
})

test("input.modify-other-keys reads unsatisfied when delivery control fails", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.modify-other-keys")
  const probe = inputProbes.find((entry) => entry.id === "input.modify-other-keys")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const failingSources = {
    term: replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async () => null,
    }),
  }
  await expect(regradeRow(probe, row, failingSources)).rejects.toThrow(/delivery control|plain a/i)
})

test("input.pixel-mouse reads unsatisfied when delivery control fails", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.pixel-mouse")
  const probe = inputProbes.find((entry) => entry.id === "input.pixel-mouse")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const failingSources = {
    term: replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async () => null,
    }),
  }
  await expect(regradeRow(probe, row, failingSources)).rejects.toThrow(/delivery control|1000\+1006/i)
})

test("input.urxvt-mouse reads unsatisfied when delivery control fails", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.urxvt-mouse")
  const probe = inputProbes.find((entry) => entry.id === "input.urxvt-mouse")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const failingSources = {
    term: replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async () => null,
    }),
  }
  await expect(regradeRow(probe, row, failingSources)).rejects.toThrow(/delivery control|1000\+1006/i)
})

test("input.x10-mouse reads unsatisfied when delivery control fails", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.x10-mouse")
  const probe = inputProbes.find((entry) => entry.id === "input.x10-mouse")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const failingSources = {
    term: replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async () => null,
    }),
  }
  await expect(regradeRow(probe, row, failingSources)).rejects.toThrow(/delivery control|1000\+1006/i)
})

test("input.button-event-mouse reads unsatisfied when delivery control fails", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.button-event-mouse")
  const probe = inputProbes.find((entry) => entry.id === "input.button-event-mouse")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const failingSources = {
    term: replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {}, injectDrag: async () => {} },
      readInput: async () => null,
    }),
  }
  await expect(regradeRow(probe, row, failingSources)).rejects.toThrow(/delivery control|1000\+1006/i)
})

test("input.modify-other-keys-3 reads unsatisfied when delivery control fails", async () => {
  const row = INPUT_CONTRACT.find((entry) => entry.id === "input.modify-other-keys-3")
  const probe = inputProbes.find((entry) => entry.id === "input.modify-other-keys-3")
  expect(row).toBeDefined()
  expect(probe).toBeDefined()
  if (!row || !probe) return
  const failingSources = {
    term: replayTermProbeSource(new Map(), {
      input: { injectKey: async () => {}, injectClick: async () => {} },
      readInput: async () => null,
    }),
  }
  await expect(regradeRow(probe, row, failingSources)).rejects.toThrow(/delivery control|plain a/i)
})
