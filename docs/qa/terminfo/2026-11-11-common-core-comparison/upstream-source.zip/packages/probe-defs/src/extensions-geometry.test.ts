/**
 * @failure OSC 8 and OSC 66 app fixtures write and query when measured geometry cannot fit their complete samples.
 * @level l1
 * @consumer App extension observations collected for terminal support cells.
 * @testonly none
 */
import { expect, test } from "vitest"
import { extensionsProbes } from "./extensions.ts"
import type { TermProbeSource } from "./types.ts"

const fixtures = [
  { id: "extensions.osc8", rows: 1, cols: 7, columns: [7], outcome: "inconclusive", assertionType: "query_reply" },
  {
    id: "extensions.osc66-text-sizing",
    rows: 1,
    cols: 5,
    columns: [1, 3, 5],
    outcome: "supported",
    assertionType: "query_reply",
  },
] as const

function app(rows: number, cols: number, events: string[], columns: readonly number[]): TermProbeSource {
  const unexpected = (name: string): never => {
    throw new Error(`Unexpected ${name} in extension geometry fixture`)
  }
  let query = 0
  return {
    kind: "live",
    rows,
    cols,
    write(bytes): void {
      events.push(bytes)
    },
    queryCursorPosition: async () => {
      events.push("CPR")
      const col = columns[query++]
      if (col === undefined) return unexpected("extra CPR")
      return { row: 1, col }
    },
    measureRenderedWidth: async () => unexpected("measureRenderedWidth"),
    query: async () => unexpected("query"),
    queryWithSentinel: async () => unexpected("queryWithSentinel"),
    queryOutcome: async () => unexpected("queryOutcome"),
    queryWithSentinelOutcome: async () => unexpected("queryWithSentinelOutcome"),
    queryMode: async () => unexpected("queryMode"),
  }
}

test.each(fixtures)("$id declines invalid or undersized geometry before bytes or queries", async (fixture) => {
  const { id, rows, cols, columns, outcome, assertionType } = fixture
  const definition = extensionsProbes.find((probe) => probe.id === id)
  if (!definition?.term) throw new Error(`Missing app callback for ${id}`)
  const invalidDimensions: ReadonlyArray<readonly [number, number]> = [
    [rows - 1, cols],
    [rows, cols - 1],
    [NaN, cols],
    [rows, Infinity],
    [rows + 0.5, cols],
    [rows, Number.MAX_SAFE_INTEGER + 1],
  ]
  for (const [measuredRows, measuredCols] of invalidDimensions) {
    const events: string[] = []
    const result = await definition.term(app(measuredRows, measuredCols, events, columns))
    expect(events, `${id} at ${measuredRows}x${measuredCols}`).toEqual([])
    expect(result.observation, id).toBeUndefined()
    expect(result.tests, id).toMatchObject([
      expect.objectContaining({ status: "probe-todo", reason: expect.any(String) }),
    ])
  }
  expect(definition.termNeedsGeometry, id).toBe(true)
  const events: string[] = []
  const result = await definition.term(app(rows, cols, events, columns))
  expect(events.at(-1), id).toBe("CPR")
  if (id === "extensions.osc8") {
    expect(result.observation, id).toBeUndefined()
    expect(result.tests, id).toMatchObject([
      expect.objectContaining({
        status: "probe-todo",
        reason: "Cursor movement cannot verify OSC 8 link metadata or click behavior",
      }),
    ])
  } else {
    expect(result.observation, id).toMatchObject({ outcome, assertionType })
  }
})

// 32604: these App capture fallbacks now read geometry through the guarded collector source.
test.each([
  "extensions.osc104-reset-palette",
  "extensions.osc110-reset-fg",
  "extensions.osc112-reset-cursor",
  "extensions.osc30001-color-stack-push",
  "extensions.osc30101-color-stack-pop",
  "extensions.osc9-progress",
  "extensions.osc555-flash",
])("%s declares geometry and cannot grade an undersized capture", async (id) => {
  const definition = extensionsProbes.find((entry) => entry.id === id)!
  const events: string[] = []
  const context = app(0, 0, events, [])
  context.capture = async () => {
    throw new Error("Undersized fixture must not capture")
  }
  context.queryWithSentinelOutcome = async () => ({
    match: null,
    reason: "sentinel",
    raw: "\x1b[?1;2c",
    rawBase64: "G1s/MTsyYw==",
    sentinel: { atMs: 1, graceMs: 1 },
  })
  const result = await definition.term!(context)
  expect(events).toEqual([])
  expect(result.tests?.some((entry) => entry.status === "untestable")).not.toBe(true)
  expect(definition.termNeedsGeometry).toBe(true)
})
