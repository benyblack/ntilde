/**
 * @failure An extension feature is graded without a bound contract row, or a re-grade of a decided
 *   observation moves it - so extension probe steps reinvent their own fixture and silently drift.
 * @level l2
 * @consumer 28449 probe definitions slice A: extension protocols.
 * @reach fs-walk vendor/terminfo.dev/packages/probe-defs/src/extensions-contract.test.ts vendor/terminfo.dev/packages/probe-defs/src/probe-automation.test.ts vendor/terminfo.dev/packages/probe-defs/src/not-tested-coverage.test.ts vendor/terminfo.dev/packages/probe-defs/src/clipboard-observations.test.ts vendor/terminfo.dev/packages/probe-defs/src/extensions-capture-observations.test.ts vendor/terminfo.dev/packages/probe-defs/src/extensions-geometry.test.ts vendor/terminfo.dev/packages/probe-defs/src/extensions-qualification.test.ts
 * @testonly none
 */
import { expect, test } from "vitest"
import { join } from "node:path"
import { extensionsProbes, OSC22_SILENT_TERMINAL } from "./extensions.ts"
import { NO_SAME_PATH_CONTROL, withReplyFailureEvidence } from "./helpers.ts"
import {
  contractGaps,
  inertLibProbeSource,
  libProbeSource,
  missingContractTests,
  regradeCommand,
  regradeRow,
  replayTermProbeSource,
  satisfiesContract,
  type GroupContract,
  type GroupContractSpec,
  type HeadlessModel,
} from "./testing/group-harness.ts"
import { createSemanticSurface } from "./testing/semantic-surface.ts"
import type { TermProbeSource } from "./types.ts"

// Row 2.1: replies must follow the actual query/set/reset operations; canned replies cannot
// prove that disabling one feature changes its result while its same-path control still works.
const EXTENSIONS_SEMANTIC_SURFACE_CONTROLS = [
  ["osc10-fg-color", "osc10-query-noop"],
  ["osc11-bg-color", "osc11-query-noop"],
  ["osc12-cursor-color", "osc12-query-noop"],
  ["osc17-highlight-bg", "osc17-query-noop"],
  ["osc19-highlight-fg", "osc19-query-noop"],
  ["osc4-palette", "osc4-query-noop"],
  ["osc5-special-color", "osc5-query-noop"],
  ["osc104-reset-palette", "osc104-noop"],
  ["osc110-reset-fg", "osc110-noop"],
  ["osc111-reset-bg", "osc111-noop"],
  ["osc112-reset-cursor", "osc112-noop"],
  ["osc113-reset-pointer-fg", "osc113-noop"],
  ["osc114-reset-pointer-bg", "osc114-noop"],
  ["osc117-reset-highlight-bg", "osc117-noop"],
  ["osc119-reset-highlight-fg", "osc119-noop"],
  ["truecolor", "fg-truecolor-noop"],
  ["osc21-kitty-color", "osc21-query-noop"],
  ["osc30001-color-stack-push", "osc30001-noop"],
  ["osc30101-color-stack-pop", "osc30101-noop"],
  ["kitty-keyboard", "kitty-keyboard-noop"],
  ["kitty-keyboard.disambiguate", "kitty-disambiguate-noop"],
  ["kitty-keyboard.report-events", "kitty-report-events-noop"],
  ["kitty-keyboard.report-alternate", "kitty-report-alternate-noop"],
  ["kitty-keyboard.report-all-keys", "kitty-report-all-keys-noop"],
  ["kitty-keyboard.report-text", "kitty-report-text-noop"],
  ["osc1337-cellsize", "osc1337-cellsize-noop"],
  ["osc1337-capabilities", "osc1337-capabilities-noop"],
  ["osc7770-font-size", "osc7770-noop"],
  ["osc7777-font-window-size", "osc7777-noop"],
  ["osc701-locale", "osc701-noop"],
  ["osc702-version", "osc702-noop"],
  ["osc776-cell-size", "osc776-noop"],
  ["sixel-da1", "sixel-da1-noop"],
  ["sixel-geometry-report", "sixel-geometry-noop"],
  ["osc66-text-sizing", "osc66-noop"],
  ["osc99-kitty-notify", "osc99-noop"],
  ["osc2-title", "osc2-noop"],
  ["osc0-icon-title", "osc0-noop"],
  ["osc1-icon", "osc1-noop"],
  ["osc52-clipboard", "osc52-write-noop"],
  ["osc52-write", "osc52-write-noop"],
  ["osc52-read", "osc52-read-noop"],
  ["osc5522-clipboard", "osc5522-unsupported"],
  ["osc133-a", "osc133-a-noop"],
  ["osc133-b", "osc133-b-noop"],
  ["osc133-c", "osc133-c-noop"],
  ["osc133-d", "osc133-d-noop"],
  ["osc633-a", "osc633-a-noop"],
  ["osc633-b", "osc633-b-noop"],
  ["osc633-c", "osc633-c-noop"],
  ["osc633-d", "osc633-d-noop"],
  ["osc633-p", "osc633-p-noop"],
  ["osc7-cwd", "osc7-noop"],
  ["osc8", "osc8-noop"],
  ["osc720-scroll-up", "osc720-noop"],
] as const

function semanticSurfaceSource(mutations: readonly string[] = []) {
  const source = libProbeSource(createSemanticSurface({ mutations }))
  return {
    ...source,
    capabilities: {
      ...source.capabilities,
      extensions: new Set([...source.capabilities.extensions, "semantic-marks", "semantic-command-end", "hyperlinks"]),
    },
  }
}

// #32573: the App arm must use the bound title surface, not merely send OSC 2.
// Library-only contract tests stay green while that App arm is an unmeasured stub.
test.each([false, true])("App OSC 2 measures and restores its owned title, disabled=%s", async (disabled) => {
  const library = semanticSurfaceSource(disabled ? ["osc2-noop"] : [])
  const before = library.getTitle()
  const definition = extensionsProbes.find((probe) => probe.id === "extensions.osc2-title")!
  const result = await definition.term!({
    write: (text: string) => library.feed(text),
    readTitle: async () => library.getTitle(),
  } as unknown as TermProbeSource)
  if (disabled) expect(result.observation?.outcome).not.toBe("supported")
  else expect(result.observation).toMatchObject({ assertionType: "buffer_state", outcome: "supported" })
  expect(library.getTitle()).toBe(before)
})

test("App OSC 2 does not call an unexpected changed title Unsupported", async () => {
  let title = "incoming App title"
  const definition = extensionsProbes.find((probe) => probe.id === "extensions.osc2-title")!
  const result = await definition.term!({
    readTitle: async () => title,
    write: (bytes: string) => {
      const match = /^\x1b\]2;([^\x07]*)\x07$/.exec(bytes)
      if (match) title = match[1]!.includes("target-") ? "unexpected changed title" : match[1]!
    },
  } as unknown as TermProbeSource)
  expect(result.observation?.outcome).not.toBe("unsupported")
  expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-invalid" }))
  expect(title).toBe("incoming App title")
})

// Ghostty's public title fallback is distinct from library getCwd; this models that surface,
// including the explicit-title override, rather than returning canned expected readings.
// #33375: the title path is one-sided. A title that does not carry the OSC 7 path cannot prove the terminal
// lacks OSC 7, so only a subject with an established negative (Ghostty, readTitleAbsenceDecides) reads Unsupported.
test.each([
  "working",
  "no-cwd",
  "no-cwd-decides",
  "bad-control",
  "bad-control-decides",
  "bad-negative",
  "bad-restore",
] as const)("App OSC 7 reads the public title one-sidedly and restores it: %s", async (behavior) => {
  let explicitTitle = "incoming App title"
  let cwd = ""
  const definition = extensionsProbes.find((probe) => probe.id === "extensions.osc7-cwd")!
  const operation = definition.term!({
    write: (bytes: string) => {
      const match = /^\x1b\](2|7|7654);([^\x07]*)\x07$/.exec(bytes)
      if (!match) throw new Error(`Unexpected title fixture write ${JSON.stringify(bytes)}`)
      if (match[1] === "2" && !behavior.startsWith("bad-control")) {
        if (!(behavior === "bad-restore" && match[2] === "incoming App title")) explicitTitle = match[2]!
      }
      if (match[1] === "7" && !behavior.startsWith("no-cwd")) {
        cwd = match[2] === "" ? "" : new URL(match[2]!).pathname
      }
      if (match[1] === "7654" && behavior === "bad-negative") cwd = "/unexpected-path"
    },
    readTitle: async () => explicitTitle || cwd,
    ...(behavior.endsWith("-decides") && { readTitleAbsenceDecides: true }),
  } as unknown as TermProbeSource)
  if (behavior === "bad-restore") await expect(operation).rejects.toThrow(/restor/i)
  else {
    const result = await operation
    if (behavior === "working") {
      expect(result.observation).toMatchObject({ assertionType: "buffer_state", outcome: "supported" })
    } else if (behavior === "no-cwd-decides") {
      expect(result.observation).toMatchObject({ assertionType: "buffer_state", outcome: "unsupported" })
    } else if (behavior === "no-cwd") {
      // The deciding path is withheld: the row keeps its raw state and a true sentence, not a grade.
      expect(result.observation).toBeUndefined()
      expect(result.notTested).toMatchObject({ reason: "no-semantic-observable" })
      expect(result.note).toMatch(/carried neither OSC 7 path, and the title is the only surface/)
    } else if (behavior === "bad-control") {
      // A route whose title cannot be held stays open with the control it failed named.
      expect(result.observation).toBeUndefined()
      expect(result.criterionBranch).toBe("app-title-control")
      expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-todo" }))
      expect(result.note).toMatch(/did not hold the OSC 2 control titles/)
    } else if (behavior === "bad-control-decides") {
      // Where the title decides (Ghostty), a failed control is still our reader breaking.
      expect(result.observation).toBeUndefined()
      expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-invalid" }))
      expect(result.note).toMatch(/failed its handled OSC 2 controls/)
    } else {
      expect(result.observation).toBeUndefined()
      expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-invalid" }))
    }
    expect(explicitTitle).toBe("incoming App title")
    expect(cwd).toBe("")
  }
})

// #32451: Kitty's absent B needs its working A reader, while the lifecycle requires A/C/D
// and an inert unknown letter. Generic opposite-namespace controls miss this reader shape.
// R3: a capable native reader must reach that same lifecycle; backend-name routing missed it.
test.each(
  (
    [
      ["osc133-b", ["osc133-b-noop", "osc633-b-noop"], "unsupported"],
      ["osc133-b", ["osc633-b-noop"], "supported"],
      ["osc133-b", ["osc133-a-noop", "osc133-b-noop", "osc633-b-noop"], undefined],
      ["osc133-b", ["wrong-input-mark"], undefined],
      ["semantic-prompts", [], "supported"],
      ["semantic-prompts", ["osc133-a-noop"], undefined],
      ["semantic-prompts", ["osc133-c-noop"], undefined],
      ["semantic-prompts", ["osc133-d-noop"], undefined],
      ["semantic-prompts", ["unknown-mutates"], undefined],
      ["semantic-prompts", ["cached-reader"], undefined],
    ] as const
  ).flatMap((row) =>
    (row[0] === "semantic-prompts" ? ["kitty", "ghostty-native"] : ["kitty"]).map(
      (backendName) => [backendName, ...row] as const,
    ),
  ),
)("%s %s with %j observes %s", (backendName, name, faults, outcome) => {
  const working = semanticSurfaceSource(faults)
  const cached = working.getSemanticMarks!()
  const source = {
    ...working,
    backendName,
    feed(text: string) {
      working.feed(
        faults.some((fault) => fault === "unknown-mutates")
          ? text.replace("133;Z", "133;A")
          : faults.some((fault) => fault === "wrong-input-mark")
            ? text.replace("133;B", "133;C")
            : text,
      )
    },
    getSemanticMarks: faults.some((fault) => fault === "cached-reader") ? () => cached : working.getSemanticMarks,
  }
  const result = extensionsProbes.find((entry) => entry.id === `extensions.${name}`)!.lib!(source)
  expect(result.observation?.outcome).toBe(outcome)
  if (outcome === undefined) expect(result.notTested?.reason).toBe("no-semantic-observable")
})

const KITTY_DISABLED_BITS = new Map<string, number>([
  ["kitty-disambiguate-noop", 1],
  ["kitty-report-events-noop", 2],
  ["kitty-report-alternate-noop", 4],
  ["kitty-report-all-keys-noop", 8],
  ["kitty-report-text-noop", 16],
])

// #32262: a live parser with an inert state reader is not a controlled negative.
test.each([
  ["osc2-title", "reader"],
  ["osc1-icon", "reader"],
  ["osc1-icon", "title-reader"],
  ["osc52-write", "reader"],
  ["osc52-write", "osc52-write-noop"],
])("extensions.%s retains TODO with unqualified %s", (name, fault) => {
  const probe = extensionsProbes.find((entry) => entry.id === `extensions.${name}`)!
  const working = semanticSurfaceSource(fault === "reader" ? [] : [fault])
  const source =
    fault === "title-reader"
      ? { ...working, getTitle: () => "" }
      : fault !== "reader"
        ? working
        : name === "osc2-title"
          ? { ...working, getTitle: () => "" }
          : name === "osc1-icon"
            ? { ...working, getIconLabel: () => "" }
            : { ...working, getClipboardState: () => ({ writes: [] }) }
  const result = probe.lib!(source)
  expect(result.observation?.outcome).not.toBe("unsupported")
  expect(result.notTested).toEqual({
    reason: "no-semantic-observable",
    noObservable:
      "Open: no control in this run showed that our test can read this feature, so the observations do not decide the result.",
  })
  expect(source.feedCapture("\x1b[c")).toMatch(/^\x1b\[\?[0-9;]+c$/u)
})

// #32265: these state changes qualify the reader but do not establish the requested effect.
test("OSC 2 changing to a different title is inconclusive", () => {
  const working = semanticSurfaceSource()
  const source = {
    ...working,
    feed(text: string) {
      working.feed(/^\x1b\]2;/u.test(text) ? "\x1b]2;unexpected-title\x07" : text)
    },
  }
  const result = extensionsProbes.find((entry) => entry.id === "extensions.osc2-title")!.lib!(source)
  expect(result.observation?.outcome).toBe("inconclusive")
})

// Batch 11: the existing missing-target case did not cover a target recorded without its control.
test.each(["control", "target"])("OSC 52 missing %s cannot establish support", (missing) => {
  const working = semanticSurfaceSource()
  let writes = 0
  const source = {
    ...working,
    feed(text: string) {
      if (/^\x1b\]52;c;[^?]/u.test(text) && ++writes === (missing === "control" ? 1 : 2)) return
      working.feed(text)
    },
  }
  const result = extensionsProbes.find((entry) => entry.id === "extensions.osc52-write")!.lib!(source)
  expect(result.observation).toBeUndefined()
  expect(result.notTested).toEqual({
    reason: "no-semantic-observable",
    noObservable:
      missing === "control"
        ? "Open: no control in this run showed that our test can read this feature, so the observations do not decide the result."
        : "control OSC 52 c write recorded but the probe write was not; same-run observations disagree",
  })
})

test.each(["osc133-a", "osc133-b", "osc133-c", "osc133-d", "osc633-a", "osc633-b", "osc633-c", "osc7-cwd", "osc8"])(
  "extensions.%s keeps a declared but inert reader undecided",
  (name) => {
    const working = semanticSurfaceSource()
    const source =
      name === "osc8"
        ? { ...working, getHyperlinkAt: () => null }
        : name === "osc7-cwd"
          ? { ...working, getCwd: () => null }
          : { ...working, getSemanticMarks: () => [] }
    const result = extensionsProbes.find((entry) => entry.id === `extensions.${name}`)!.lib!(source)
    expect(result.observation?.outcome).not.toBe("unsupported")
    expect(result.notTested).toEqual({
      reason: "no-semantic-observable",
      noObservable:
        "Open: no control in this run showed that our test can read this feature, so the observations do not decide the result.",
    })
    expect(source.feedCapture("\x1b[c")).toMatch(/^\x1b\[\?[0-9;]+c$/u)
  },
)

test("OSC 7 restores its baseline when the control reader throws", () => {
  const working = semanticSurfaceSource()
  working.feed("\x1b]7;file://localhost/original\x07")
  let reads = 0
  const source = {
    ...working,
    getCwd() {
      if (++reads === 2) throw new Error("control reader failed")
      return working.getCwd!()
    },
  }
  expect(() => extensionsProbes.find((entry) => entry.id === "extensions.osc7-cwd")!.lib!(source)).toThrow(
    "control reader failed",
  )
  expect(working.getCwd!()).toBe("file://localhost/original")
})

// The real WezTerm public getter serializes localhost file URLs with an empty host.
// Literal metadata fixtures missed this valid engine state and left the registered probe TODO.
test("OSC 7 accepts WezTerm URL serialization without a 633 property reader", () => {
  const working = semanticSurfaceSource(["osc633-p-noop"])
  const source = {
    ...working,
    getCwd() {
      const value = working.getCwd!()
      return value === null ? null : new URL(value).href
    },
  }
  const result = extensionsProbes.find((entry) => entry.id === "extensions.osc7-cwd")!.lib!(source)
  expect(JSON.parse(result.response!)).toMatchObject({
    before: null,
    controlled: null,
    first: "file:///terminfo-cwd-A",
    second: "file:///terminfo-cwd-B",
    restored: null,
  })
  expect(result.pass).toBe(true)
})

// A target mismatch is a negative only after the same reader observes the control.
test.each([
  ["remote host", "file://otherhost/terminfo-cwd-A", "file://otherhost/terminfo-cwd-B"],
  ["bare path", "/terminfo-cwd-A", "/terminfo-cwd-B"],
  ["unparseable", "file://[", "file://["],
  ["empty", "", ""],
  ["unset", null, null],
])("OSC 7 keeps raw %s values and requires its control for a negative", (_, first, second) => {
  for (const control of [false, true]) {
    const working = semanticSurfaceSource(control ? [] : ["osc633-p-noop"])
    const source = {
      ...working,
      getCwd() {
        const value = working.getCwd!()
        if (value === "file://localhost/terminfo-cwd-A") return first
        if (value === "file://localhost/terminfo-cwd-B") return second
        return value === null ? null : new URL(value).href
      },
    }
    const result = extensionsProbes.find((entry) => entry.id === "extensions.osc7-cwd")!.lib!(source)
    expect(result.pass).toBe(false)
    expect(JSON.parse(result.response!)).toMatchObject({ first, second, restored: null })
    if (control) {
      expect(result.notTested).toBeUndefined()
      expect(result.observation?.outcome).toBe("unsupported")
    } else {
      expect(result.notTested).toBeDefined()
      expect(result.observation?.outcome).not.toBe("unsupported")
    }
  }
})

// Batch 11: successful A/B writes with ignored cleanup are a measurement error, not a target negative.
test("OSC 7 reports an error when target writes work but restoring an empty baseline is ignored", () => {
  const working = semanticSurfaceSource()
  expect(working.getCwd!()).toBeNull()
  const source = {
    ...working,
    feed(text: string) {
      if (text === "\x1b]7;\x07" || text === "\x1b]633;P;Cwd=\x07") return
      working.feed(text)
    },
  }
  const result = extensionsProbes.find((entry) => entry.id === "extensions.osc7-cwd")!.lib!(source)
  expect(result.observation).toMatchObject({ outcome: "error", reason: "invalid-reply" })
  expect(JSON.parse(result.response!)).toMatchObject({
    before: null,
    controlUri: "file://localhost/terminfo-cwd-control",
    controlled: "file://localhost/terminfo-cwd-control",
    first: "file://localhost/terminfo-cwd-A",
    second: "file://localhost/terminfo-cwd-B",
    restored: "file://localhost/terminfo-cwd-B",
  })
})

test.each(EXTENSIONS_SEMANTIC_SURFACE_CONTROLS)("controls for extensions.%s with %s", async (name, mutation) => {
  const id = `extensions.${name}`
  const probe = extensionsProbes.find((entry) => entry.id === id)!
  const row = EXTENSIONS_CONTRACT.find((entry) => entry.id === id)!
  expect(probe, id).toBeDefined()
  expect(row, id).toBeDefined()
  expect(probe.lib, id).toBeTypeOf("function")

  const inert = await regradeRow(probe, row, { headless: inertLibProbeSource() })
  expect(inert.after, `${id}: no-op source cannot establish support`).not.toBe("supported")
  const workingSource = semanticSurfaceSource()
  if (id === "extensions.osc2-title") workingSource.feed("\x1b]2;batch9-original-title\x07")
  const cwdUri = "file://localhost/e4-original-cwd"
  const cwdControl =
    id === "extensions.osc7-cwd"
      ? `\x1b]633;P;Cwd=${cwdUri}\x07`
      : id === "extensions.osc633-p"
        ? `\x1b]7;${cwdUri}\x07`
        : null
  if (cwdControl) workingSource.feed(cwdControl)
  const beforeTitle = workingSource.getTitle()
  const beforeIcon = workingSource.getIconLabel?.()
  const beforeCwd = workingSource.getCwd?.()
  const working = await regradeRow(probe, row, { headless: workingSource })
  expect(working.after, `${id}: working feature must establish support`).toBe("supported")
  expect(workingSource.getTitle(), `${id}: restores the title`).toBe(beforeTitle)
  expect(workingSource.getIconLabel?.(), `${id}: restores the icon`).toBe(beforeIcon)
  expect(workingSource.getCwd?.(), `${id}: restores the working directory`).toBe(beforeCwd)
  const disabledSource = semanticSurfaceSource([mutation])
  if (id === "extensions.osc2-title") disabledSource.feed("\x1b]2;batch9-original-title\x07")
  if (id === "extensions.osc52-write") disabledSource.feed(`\x1b]52;c;${btoa("batch9-prior-write")}\x07`)
  const disabledTitle = disabledSource.getTitle()
  const disabledIcon = disabledSource.getIconLabel?.()
  const priorWrites = disabledSource.getClipboardState?.().writes ?? []
  if (cwdControl) disabledSource.feed(cwdControl)
  const disabledCwd = disabledSource.getCwd?.()
  if (cwdControl) expect(disabledCwd, `${id}: the other protocol qualifies the Cwd reader`).toBe(cwdUri)
  const disabled = await regradeRow(probe, row, { headless: disabledSource })
  if (id === "extensions.osc1-icon") expect(disabledSource.getIconLabel?.()).toBe(disabledIcon)
  if (id === "extensions.osc2-title") expect(disabledSource.getTitle()).toBe(disabledTitle)
  if (id === "extensions.osc52-write") {
    expect(disabledSource.getClipboardState!().writes.slice(0, priorWrites.length)).toEqual(priorWrites)
  }
  expect(disabledSource.getCwd?.(), `${id}: negative control restores the working directory`).toBe(disabledCwd)
  // A roundtrip mismatch leaves the write/read combination undecided; it is not an engine negative.
  expect(disabled.after, `${id}: only ${mutation} is disabled`).toBe(
    id === "extensions.osc52-clipboard"
      ? "inconclusive"
      : id === "extensions.osc52-write" || id === "extensions.osc8"
        ? undefined
        : "unsupported",
  )
  if (id === "extensions.osc52-clipboard") {
    expect(probe.lib!(disabledSource).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "insufficient-evidence",
    })
  }
  expect(disabledSource.feedCapture("\x1b[c"), `${id}: unrelated DA1 still answers`).toMatch(/^\x1b\[\?[0-9;]+c$/u)

  const semantic = /^extensions\.osc(133|633)-([abcd])$/u.exec(id)
  // A stored negative must carry the successful independent control, not just the target's marks.
  if (semantic && semantic[2] !== "d") {
    const retained = JSON.parse(probe.lib!(disabledSource).response!)
    expect(retained).toMatchObject({
      endControl: { before: expect.any(Array), first: expect.any(Array), second: expect.any(Array) },
    })
  }
  if (id === "extensions.osc7-cwd") {
    expect(JSON.parse(probe.lib!(disabledSource).response!)).toMatchObject({
      controlUri: "file://localhost/terminfo-cwd-control",
      controlled: "file://localhost/terminfo-cwd-control",
    })
  }
  if (semantic) {
    const otherNamespace = semantic[1] === "133" ? "633" : "133"
    const selector = semantic[2]!
    const beforeMarks = disabledSource.getSemanticMarks!()
    const cursor = disabledSource.getCursor()
    disabledSource.feed(`\x1b]${otherNamespace};${selector.toUpperCase()}${selector === "d" ? ";23" : ""}\x07`)
    const marks = disabledSource.getSemanticMarks!()
    expect(marks.slice(0, -1), `${id}: preserves existing mark history`).toEqual(beforeMarks)
    expect(marks.at(-1), `${id}: the other namespace remains observable`).toEqual(
      selector === "d"
        ? { type: "command-end", rawStatus: "23" }
        : {
            type: selector === "a" ? "prompt" : selector === "b" ? "command" : "output",
            startRow: cursor.y,
            startCol: cursor.x,
          },
    )
  }

  const disabledBit = KITTY_DISABLED_BITS.get(mutation)
  if (disabledBit !== undefined) {
    expect(disabledSource.feedCapture("\x1b[?u"), "the probe popped its own flags").toBe("\x1b[?0u")
    disabledSource.feed("\x1b[>31u")
    expect(disabledSource.feedCapture("\x1b[?u"), "all unrelated requested flags survive").toBe(
      `\x1b[?${31 & ~disabledBit}u`,
    )
    disabledSource.feed("\x1b[<u")
    expect(disabledSource.feedCapture("\x1b[?u"), "pop restores the prior flag state").toBe("\x1b[?0u")
  }
})

// Without lifecycle capabilities, semantic prompts stay TODO. The capable lifecycle is covered above.
// The OSC 633 readers cannot observe the whole claim, even with the richer shared fixture.
// Reflow's real positive/negative/fault controls remain owned by packages/probes/headless-batch.test.ts.
test.each(["semantic-prompts", "osc-633-vscode", "osc633-e"])(
  "extensions.%s retains its explicit TODO without the required observables",
  (name) => {
    const probe = extensionsProbes.find((entry) => entry.id === `extensions.${name}`)!
    for (const [consumes, source] of [
      [false, inertLibProbeSource()],
      ...(name === "semantic-prompts" ? [] : ([[true, semanticSurfaceSource()]] as const)),
    ] as const) {
      const result = probe.lib!(source)
      expect(result.tests, name).toEqual(expect.arrayContaining([expect.objectContaining({ status: "probe-todo" })]))
      expect(result.observation?.outcome, name).not.toBe("supported")
      if (consumes && name === "osc633-e") {
        expect(result.tests?.[0]?.reason).toBe(
          "Open: the library did not print the shell property and command-line marks (OSC 133 P, 633 E) as text, but our test cannot read them back.",
        )
        expect(result.notTested?.noObservable).toBe("OSC 633;E commandline-with-nonce mark registration")
      }
    }
  },
)

// 133;P starts a secondary prompt. A 133-only reader must qualify its own negative.
test.each(["supported", "unsupported", "missing-reader"] as const)("OSC 133;P observes %s", (outcome) => {
  const working = semanticSurfaceSource(["osc633-a-noop", ...(outcome === "unsupported" ? ["osc133-p-noop"] : [])])
  const source = outcome === "missing-reader" ? { ...working, getSemanticMarks: undefined } : working
  const result = extensionsProbes.find((entry) => entry.id === "extensions.osc133-p")!.lib!(source)
  if (outcome === "missing-reader") {
    expect(result.tests).toEqual(expect.arrayContaining([expect.objectContaining({ status: "probe-todo" })]))
    expect(result.observation?.outcome).not.toBe("unsupported")
  } else {
    expect(result.observation?.outcome).toBe(outcome)
    const retained = JSON.parse(result.response!) as {
      endControl: { before: unknown[]; first: unknown[]; second: unknown[] }
    }
    expect(retained.endControl.first).toHaveLength(retained.endControl.before.length + 1)
    expect(retained.endControl.second).toHaveLength(retained.endControl.first.length + 1)
    expect(retained.endControl.second.slice(-2)).toEqual([
      expect.objectContaining({ type: "prompt" }),
      expect.objectContaining({ type: "prompt" }),
    ])
  }
})

/**
 * The 79 extension features (78 defined in extensions.ts + 1 catalog-only in features.json).
 * 42 protocol queries are decided in real terminal runs; 36 unasserted/state probes evaluate to
 * inconclusive pending external apparatus or capture; 1 catalog feature lacks a probe definition.
 */
const EXTENSIONS_CONTRACT: GroupContract = [
  { id: "extensions.truecolor", expected: "inconclusive", claim: "24-bit truecolor: ESC [ 38;2;R;G;B m" },
  { id: "extensions.kitty-keyboard", expected: "decided", claim: "Kitty keyboard protocol: ESC [ > flags u" },
  { id: "extensions.kitty-keyboard.disambiguate", expected: "decided", claim: "Kitty keyboard: DISAMBIGUATE (flag 1)" },
  {
    id: "extensions.kitty-keyboard.report-events",
    expected: "decided",
    claim: "Kitty keyboard: REPORT_EVENTS (flag 2)",
  },
  {
    id: "extensions.kitty-keyboard.report-alternate",
    expected: "decided",
    claim: "Kitty keyboard: REPORT_ALTERNATE (flag 4)",
  },
  {
    id: "extensions.kitty-keyboard.report-all-keys",
    expected: "decided",
    claim: "Kitty keyboard: REPORT_ALL_KEYS (flag 8)",
  },
  { id: "extensions.kitty-keyboard.report-text", expected: "decided", claim: "Kitty keyboard: REPORT_TEXT (flag 16)" },
  { id: "extensions.kitty-graphics", expected: "decided", claim: "Kitty graphics protocol" },
  { id: "extensions.kitty-graphics.transmit", expected: "decided", claim: "Kitty graphics: transmit" },
  { id: "extensions.kitty-graphics.display", expected: "decided", claim: "Kitty graphics: display" },
  { id: "extensions.kitty-graphics.animation", expected: "inconclusive", claim: "Kitty graphics: animation" },
  {
    id: "extensions.kitty-graphics.unicode-placeholders",
    expected: "inconclusive",
    claim: "Kitty graphics: Unicode placeholders",
  },
  { id: "extensions.sixel", expected: "inconclusive", claim: "Sixel graphics" },
  { id: "extensions.osc8", expected: "inconclusive", claim: "Hyperlinks (OSC 8): ESC ] 8 ; params ; uri BEL" },
  {
    id: "extensions.reflow",
    expected: "inconclusive",
    claim: "Text reflow on resize: (behavioral — resize the terminal)",
  },
  {
    id: "extensions.semantic-prompts",
    expected: "inconclusive",
    claim: "Semantic prompts (OSC 133): ESC ] 133 ; A BEL",
  },
  { id: "extensions.osc2-title", expected: "inconclusive", claim: "Window title (OSC 2): ESC ] 2 ; title BEL" },
  { id: "extensions.osc0-icon-title", expected: "decided", claim: "Icon and title (OSC 0): ESC ] 0 ; title BEL" },
  {
    id: "extensions.osc52-clipboard",
    expected: "decided",
    claim: "Clipboard access (OSC 52): ESC ] 52 ; c ; base64 BEL",
  },
  { id: "extensions.osc52-write", expected: "decided", claim: "OSC 52 clipboard write" },
  { id: "extensions.osc52-read", expected: "decided", claim: "OSC 52 clipboard read" },
  { id: "extensions.osc10-fg-color", expected: "decided", claim: "Foreground color query (OSC 10): ESC ] 10 ; ? BEL" },
  { id: "extensions.osc11-bg-color", expected: "decided", claim: "Background color query (OSC 11): ESC ] 11 ; ? BEL" },
  {
    id: "extensions.osc7-cwd",
    expected: "inconclusive",
    claim: "Current directory (OSC 7): ESC ] 7 ; file://host/path BEL",
  },
  {
    id: "extensions.osc-633-vscode",
    expected: "inconclusive",
    claim: "VS Code Shell Integration (OSC 633): ESC ] 633 ; A BEL",
  },
  {
    id: "extensions.osc133-a",
    expected: "inconclusive",
    claim: "OSC 133;A prompt start (FTCS_PROMPT): ESC ] 133 ; A BEL",
  },
  {
    id: "extensions.osc133-b",
    expected: "inconclusive",
    claim: "OSC 133;B command start (FTCS_COMMAND_START): ESC ] 133 ; B BEL",
  },
  {
    id: "extensions.osc133-c",
    expected: "inconclusive",
    claim: "OSC 133;C command executed (FTCS_COMMAND_EXECUTED): ESC ] 133 ; C BEL",
  },
  {
    id: "extensions.osc133-d",
    expected: "inconclusive",
    claim: "OSC 133;D command finished (FTCS_COMMAND_FINISHED): ESC ] 133 ; D ; exitcode BEL",
  },
  { id: "extensions.osc133-p", expected: "inconclusive", claim: "OSC 133;P secondary prompt start: ESC ] 133 ; P BEL" },
  { id: "extensions.osc633-a", expected: "inconclusive", claim: "OSC 633;A prompt start: ESC ] 633 ; A BEL" },
  { id: "extensions.osc633-b", expected: "inconclusive", claim: "OSC 633;B prompt end: ESC ] 633 ; B BEL" },
  { id: "extensions.osc633-c", expected: "inconclusive", claim: "OSC 633;C pre-execution: ESC ] 633 ; C BEL" },
  {
    id: "extensions.osc633-d",
    expected: "inconclusive",
    claim: "OSC 633;D command finished: ESC ] 633 ; D ; exitcode BEL",
  },
  {
    id: "extensions.osc633-e",
    expected: "inconclusive",
    claim: "OSC 633;E set commandline: ESC ] 633 ; E ; commandline ; nonce BEL",
  },
  { id: "extensions.osc633-p", expected: "inconclusive", claim: "OSC 633;P properties: ESC ] 633 ; P ; key=value BEL" },
  { id: "extensions.notifications", expected: "inconclusive", claim: "Desktop Notifications (OSC 9/777)" },
  { id: "extensions.iterm2-images", expected: "inconclusive", claim: "iTerm2 Inline Images (OSC 1337)" },
  { id: "extensions.osc1337-cellsize", expected: "decided", claim: "iTerm2 Cell Size Reporting (OSC 1337)" },
  { id: "extensions.osc1337-capabilities", expected: "decided", claim: "iTerm2 Capability Reporting (OSC 1337)" },
  { id: "extensions.osc9-progress", expected: "inconclusive", claim: "OSC 9;4 progress bar" },
  { id: "extensions.osc66-text-sizing", expected: "decided", claim: "OSC 66 text sizing" },
  { id: "extensions.osc5522-clipboard", expected: "decided", claim: "OSC 5522 advanced clipboard" },
  { id: "extensions.osc1-icon", expected: "inconclusive", claim: "Icon name (OSC 1): ESC ] 1 ; Pt BEL" },
  { id: "extensions.osc4-palette", expected: "decided", claim: "Color palette (OSC 4): ESC ] 4 ; c ; spec BEL" },
  { id: "extensions.osc5-special-color", expected: "decided", claim: "Special color (OSC 5): ESC ] 5 ; c ; spec BEL" },
  { id: "extensions.osc12-cursor-color", expected: "decided", claim: "Cursor color (OSC 12): ESC ] 12 ; color BEL" },
  {
    id: "extensions.osc104-reset-palette",
    expected: "decided",
    claim: "Reset color palette (OSC 104): ESC ] 104 ; c BEL",
  },
  { id: "extensions.osc110-reset-fg", expected: "decided", claim: "Reset foreground color (OSC 110): ESC ] 110 BEL" },
  { id: "extensions.osc111-reset-bg", expected: "decided", claim: "Reset background color (OSC 111): ESC ] 111 BEL" },
  { id: "extensions.osc112-reset-cursor", expected: "decided", claim: "Reset cursor color (OSC 112): ESC ] 112 BEL" },
  {
    id: "extensions.osc117-reset-highlight-bg",
    expected: "inconclusive",
    claim: "Reset highlight background (OSC 117): ESC ] 117 BEL",
  },
  {
    id: "extensions.osc119-reset-highlight-fg",
    expected: "inconclusive",
    claim: "Reset highlight foreground (OSC 119): ESC ] 119 BEL",
  },
  {
    id: "extensions.osc17-highlight-bg",
    expected: "decided",
    claim: "Highlight background (OSC 17): ESC ] 17 ; spec BEL",
  },
  {
    id: "extensions.osc19-highlight-fg",
    expected: "decided",
    claim: "Highlight foreground (OSC 19): ESC ] 19 ; spec BEL",
  },
  { id: "extensions.osc22-pointer", expected: "inconclusive", claim: "Pointer shape (OSC 22): ESC ] 22 ; shape BEL" },
  {
    id: "extensions.osc99-kitty-notify",
    expected: "decided",
    claim: "Desktop notifications (OSC 99): ESC ] 99 ; params BEL",
  },
  {
    id: "extensions.osc777-notify",
    expected: "inconclusive",
    claim: "Notifications (OSC 777): ESC ] 777 ; notify ; title ; body BEL",
  },
  {
    id: "extensions.osc666-termprop",
    expected: "inconclusive",
    claim: "VTE termprop (OSC 666): ESC ] 666 ; key=value BEL",
  },
  {
    id: "extensions.osc3008-context",
    expected: "inconclusive",
    claim: "Systemd context (OSC 3008): ESC ] 3008 ; params BEL",
  },
  {
    id: "extensions.osc113-reset-pointer-fg",
    expected: "decided",
    claim: "Reset pointer fg color (OSC 113): ESC ] 113 BEL",
  },
  {
    id: "extensions.osc114-reset-pointer-bg",
    expected: "decided",
    claim: "Reset pointer bg color (OSC 114): ESC ] 114 BEL",
  },
  {
    id: "extensions.osc21-kitty-color",
    expected: "decided",
    claim: "Kitty color protocol (OSC 21): ESC ] 21 ; key=value BEL",
  },
  {
    id: "extensions.osc30001-color-stack-push",
    expected: "decided",
    claim: "Kitty color stack push (OSC 30001): ESC ] 30001 BEL",
  },
  {
    id: "extensions.osc30101-color-stack-pop",
    expected: "decided",
    claim: "Kitty color stack pop (OSC 30101): ESC ] 30101 BEL",
  },
  {
    id: "extensions.osc176-app-id",
    expected: "inconclusive",
    claim: "Set Wayland app-id (OSC 176): ESC ] 176 ; app-id BEL",
  },
  { id: "extensions.osc555-flash", expected: "inconclusive", claim: "Screen flash (OSC 555): ESC ] 555 BEL" },
  { id: "extensions.osc440-audio", expected: "inconclusive", claim: "Audio sound (OSC 440): ESC ] 440 ; wavfile BEL" },
  {
    id: "extensions.osc7770-font-size",
    expected: "decided",
    claim: "Font size query/set (OSC 7770): ESC ] 7770 ; size BEL",
  },
  {
    id: "extensions.osc7777-font-window-size",
    expected: "decided",
    claim: "Font + window size (OSC 7777): ESC ] 7777 ; size BEL",
  },
  { id: "extensions.osc701-locale", expected: "decided", claim: "Locale query/set (OSC 701): ESC ] 701 ; locale BEL" },
  { id: "extensions.osc702-version", expected: "decided", claim: "Version query (OSC 702): ESC ] 702 ; ? BEL" },
  {
    id: "extensions.osc710-font-normal",
    expected: "inconclusive",
    claim: "Set normal font (OSC 710): ESC ] 710 ; font BEL",
  },
  { id: "extensions.osc720-scroll-up", expected: "inconclusive", claim: "Scroll view up (OSC 720): ESC ] 720 BEL" },
  { id: "extensions.osc776-cell-size", expected: "decided", claim: "Cell size report (OSC 776): ESC ] 776 BEL" },
  { id: "extensions.sixel-da1", expected: "decided", claim: "Sixel support in DA1" },
  {
    id: "extensions.sixel-geometry-report",
    expected: "decided",
    claim: "Sixel geometry report (CSI ? Pi;Pa;Pv S): CSI ? Pi ; Pa ; Pv S",
  },
  {
    id: "extensions.clipboard-paste",
    expected: "decided",
    claim:
      "clipboard-paste: owned clipboard nonce then ctrl+shift+v reports CSI 200~nonce201~ after plain-a delivery control and 2004; raw nonce is unsupported",
  },
  {
    id: "extensions.font-ligatures",
    expected: "not-tested",
    claim:
      "Font ligatures: the headless parser shapes no glyphs; app contexts capture a spaced control and a contiguous sample for review",
  },
]

/** The named set 28454 reviews: Extensions rows plus the focused test files that bind them. */
const EXTENSIONS_CONTRACT_SPEC: GroupContractSpec = {
  group: "extensions",
  rows: EXTENSIONS_CONTRACT,
  tests: [
    "packages/probe-defs/src/extensions-contract.test.ts",
    "packages/probe-defs/src/probe-automation.test.ts",
    "packages/probe-defs/src/not-tested-coverage.test.ts",
    "packages/probe-defs/src/clipboard-observations.test.ts",
    "packages/probe-defs/src/extensions-capture-observations.test.ts",
    "packages/probe-defs/src/extensions-geometry.test.ts",
    "packages/probe-defs/src/extensions-qualification.test.ts",
    "packages/probe-defs/src/extensions-osc0-observations.test.ts",
    "packages/probe-defs/src/kitty-capture.test.ts",
    "packages/probe-defs/src/kitty-rows.test.ts",
  ],
}

/** Rows whose missing reading carries its own ruled sentence instead of the generic one (@cto a7fb82cc, #33100). */
const NAMED_NO_OBSERVABLE: Readonly<Record<string, string>> = {
  "extensions.osc22-pointer": OSC22_SILENT_TERMINAL,
}

const EXECUTION_ONLY_INCONCLUSIVE_DISPOSITIONS: Readonly<
  Record<string, { status: "probe-todo" | "probe-invalid"; reason: string }>
> = {
  "extensions.osc777-notify": {
    status: "probe-todo",
    reason: "No owned desktop notification observer for OSC 777",
  },
  "extensions.osc666-termprop": {
    status: "probe-todo",
    reason: "Cursor response does not measure OSC 666 terminal property",
  },
  "extensions.osc3008-context": {
    status: "probe-todo",
    reason: "Cursor response does not measure OSC 3008 systemd context",
  },
  "extensions.osc176-app-id": {
    status: "probe-todo",
    reason: "Cursor response does not measure OSC 176 Wayland app-id",
  },
  "extensions.osc555-flash": {
    status: "probe-todo",
    reason: "extensions.osc555-flash: no owned whole-window pixel capture for this effect",
  },
  "extensions.osc440-audio": {
    status: "probe-todo",
    reason: "Cursor response does not measure OSC 440 audio playback",
  },
  "extensions.truecolor": { status: "probe-todo", reason: "No cursor response; RGB color was not measured" },
  // Both kitty pixel rows now have a deciding observation; without the terminal's own pixel report
  // the arm cannot map its rectangle onto cells and names the unanswered geometry queries.
  "extensions.kitty-graphics.animation": {
    status: "probe-invalid",
    reason: "No matching image allocation reply; no image ownership or transmission conclusion",
  },
  "extensions.kitty-graphics.unicode-placeholders": {
    status: "probe-invalid",
    reason: "No matching image allocation reply; no image ownership or transmission conclusion",
  },
  "extensions.sixel": {
    status: "probe-invalid",
    reason:
      "extensions.sixel: the terminal answered CSI 16 t (cell size in pixels) with timeout and CSI 14 t (text area in pixels) with timeout, so no cell size can be mapped, so this run cannot map cells onto the captured window",
  },
  "extensions.iterm2-images": {
    status: "probe-invalid",
    reason:
      "extensions.iterm2-images: the terminal answered CSI 16 t (cell size in pixels) with timeout and CSI 14 t (text area in pixels) with timeout, so no cell size can be mapped, so this run cannot map cells onto the captured window",
  },
  "extensions.osc8": {
    status: "probe-todo",
    reason: "Cursor movement cannot verify OSC 8 link metadata or click behavior",
  },
  "extensions.reflow": {
    status: "probe-todo",
    reason: "No controlled resize and cell-content readback to measure reflow",
  },
  "extensions.semantic-prompts": {
    status: "probe-todo",
    reason: "No shell prompt integration metadata or behavior readback for OSC 133",
  },
  "extensions.osc2-title": {
    status: "probe-todo",
    reason: "OSC 2 window title was not attempted; this probe has no effect readback or prior-state restoration",
  },
  "extensions.osc7-cwd": { status: "probe-todo", reason: "No working-directory metadata readback for OSC 7" },
  "extensions.osc-633-vscode": {
    status: "probe-todo",
    reason: "No VS Code shell integration metadata or behavior readback for OSC 633",
  },
  "extensions.osc133-a": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc133-b": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc133-c": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc133-d": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc133-p": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc633-a": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc633-b": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc633-c": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc633-d": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc633-e": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.osc633-p": {
    status: "probe-todo",
    reason: "Marker consumption was not confirmed; shell prompt integration was not observed",
  },
  "extensions.notifications": { status: "probe-todo", reason: "No owned desktop notification observer for OSC 9" },
  "extensions.osc9-progress": {
    status: "probe-todo",
    reason: "extensions.osc9-progress: no owned whole-window pixel capture for this effect",
  },
  "extensions.osc1-icon": { status: "probe-todo", reason: "No icon-name readback for OSC 1" },
  "extensions.osc117-reset-highlight-bg": {
    status: "probe-invalid",
    reason:
      "extensions.osc117-reset-highlight-bg: OSC 17 did not report a colour, so the initial highlight colour is unknown and a reset cannot be compared with it",
  },
  "extensions.osc119-reset-highlight-fg": {
    status: "probe-invalid",
    reason:
      "extensions.osc119-reset-highlight-fg: OSC 19 did not report a colour, so the initial highlight colour is unknown and a reset cannot be compared with it",
  },
  "extensions.osc710-font-normal": {
    status: "probe-todo",
    reason: "OSC 710 font selection was not attempted; this probe has no effect readback or prior-state restoration",
  },
  "extensions.osc720-scroll-up": {
    status: "probe-todo",
    reason: "Cursor answered; scrollback viewport was not measured",
  },
}

function inertModel(): HeadlessModel {
  return {
    cols: 80,
    feed: () => {},
    feedCapture: () => "",
    getCell: () => ({
      char: " ",
      bold: false,
      dim: false,
      italic: false,
      underline: null,
      underlineColor: null,
      strikethrough: false,
      inverse: false,
      hidden: false,
      blink: false,
      overline: false,
      fg: null,
      bg: null,
      wide: false,
    }),
    getCursor: () => ({ x: 0, y: 0, visible: true, style: null }),
  }
}

const DIRECT_QUERY_REPLIES: Record<string, string> = {
  "extensions.osc10-fg-color": "\x1b]10;rgb:ffff/0000/0000\x07",
  "extensions.osc11-bg-color": "\x1b]11;rgb:0000/ffff/0000\x07",
  "extensions.osc12-cursor-color": "\x1b]12;rgb:0000/0000/ffff\x07",
  "extensions.osc17-highlight-bg": "\x1b]17;rgb:ffff/ffff/0000\x07",
  "extensions.osc19-highlight-fg": "\x1b]19;rgb:ffff/0000/ffff\x07",
  "extensions.osc4-palette": "\x1b]4;0;rgb:ffff/0000/0000\x07",
  "extensions.osc5-special-color": "\x1b]5;0;rgb:ffff/0000/0000\x07",
  "extensions.osc1337-cellsize": "\x1b]1337;ReportCellSize=12;8\x07",
  "extensions.osc1337-capabilities": "\x1b]1337;Capabilities=alpha\x07",
  "extensions.osc7770-font-size": "\x1b]7770;14\x07",
  "extensions.osc7777-font-window-size": "\x1b]7777;14\x07",
  "extensions.osc701-locale": "\x1b]701;en_US.UTF-8\x07",
  "extensions.osc702-version": "\x1b]702;rxvt-unicode;rxvt;9;31\x07",
  "extensions.osc776-cell-size": "\x1b]776;8;16;2\x07",
  "extensions.sixel-da1": "\x1b[?1;4c",
  "extensions.sixel-geometry-report": "\x1b[?2;0;800;528S",
}

const COLOR_RESET_CODES: Record<string, string> = {
  "extensions.osc104-reset-palette": "4;0",
  "extensions.osc110-reset-fg": "10",
  "extensions.osc111-reset-bg": "11",
  "extensions.osc112-reset-cursor": "12",
  "extensions.osc113-reset-pointer-fg": "13",
  "extensions.osc114-reset-pointer-bg": "14",
}

function decidedSatisfactionSources(id: string) {
  if (DIRECT_QUERY_REPLIES[id]) {
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: () => DIRECT_QUERY_REPLIES[id] ?? "",
      }),
    }
  }
  if (id.startsWith("extensions.kitty-keyboard")) {
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: () => "\x1b[?31u\x1b[?1;0c",
      }),
    }
  }
  if (id === "extensions.kitty-graphics") {
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: () => "\x1b_Gi=31;OK\x1b\\",
      }),
    }
  }
  if (id === "extensions.kitty-graphics.transmit" || id === "extensions.kitty-graphics.display") {
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: (seq) => {
          const num = /I=(\d+)/.exec(seq)?.[1] || "1"
          if (/a=p,i=2,/.test(seq)) return "\x1b_Gi=2;OK\x1b\\"
          return `\x1b_Gi=1,I=${num};OK\x1b\\`
        },
      }),
    }
  }
  if (id.startsWith("extensions.osc52-")) {
    let last = ""
    return {
      headless: libProbeSource({
        ...inertModel(),
        feed: (text) => {
          last = text
        },
        feedCapture: () => last,
      }),
    }
  }
  if (id === "extensions.osc5522-clipboard") {
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: () => "\x1b[?5522;1$y",
      }),
    }
  }
  if (id === "extensions.osc21-kitty-color") {
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: () => "\x1b]21;foreground=rgb:ffff/ffff/ffff\x1b\\",
      }),
    }
  }
  if (COLOR_RESET_CODES[id]) {
    const code = COLOR_RESET_CODES[id]
    const color = (val: string) => `\x1b]${code};rgb:${val}\x07`
    const queue = [color("00/00/00"), color("aa/bb/cc"), color("00/00/00")]
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: () => queue.shift() ?? "",
      }),
    }
  }
  if (id === "extensions.osc30001-color-stack-push" || id === "extensions.osc30101-color-stack-pop") {
    let current = "rgb:1010/2020/3030"
    const stack: string[] = []
    return {
      headless: libProbeSource({
        ...inertModel(),
        feed: (seq) => {
          if (seq.includes("]30001")) stack.push(current)
          else if (seq.includes("]30101")) current = stack.pop() ?? current
          else {
            const m = /\x1b\]10;(rgb:[a-f\d/]+)/i.exec(seq)
            if (m) current = m[1] ?? current
          }
        },
        feedCapture: () => `\x1b]10;${current}\x1b\\`,
      }),
    }
  }
  if (id === "extensions.osc66-text-sizing") {
    let step = 0
    return {
      headless: libProbeSource({
        ...inertModel(),
        feed: () => {
          step++
        },
        getCursor: () => {
          if (step <= 1) return { x: 0, y: 0, visible: true, style: null }
          if (step === 2) return { x: 2, y: 0, visible: true, style: null }
          return { x: 4, y: 0, visible: true, style: null }
        },
      }),
    }
  }
  if (id === "extensions.osc0-icon-title") {
    const payload = "osc0-icon-title"
    return {
      headless: libProbeSource({
        ...inertModel(),
        feedCapture: (text) => {
          if (text === "\x1b[20t") return `\x1b]L${payload}\x07`
          if (text === "\x1b[21t") return `\x1b]l${payload}\x07`
          return ""
        },
      }),
    }
  }
  if (id === "extensions.osc99-kitty-notify") {
    return {
      term: replayTermProbeSource(new Map(), {
        queryWithSentinelOutcome: async (query: string, pattern: RegExp) => {
          const nonce = /i=([^:]+):/.exec(query)?.[1]
          const raw = `\x1b]99;i=${nonce}:p=?;p=title\x1b\\`
          return {
            match: pattern.exec(raw),
            reason: "reply",
            raw,
            rawBase64: Buffer.from(raw).toString("base64"),
          }
        },
      }),
    }
  }
  if (id === "extensions.clipboard-paste") {
    let nonce = ""
    let bracketed = false
    let pendingInput: string | null = null
    return {
      term: replayTermProbeSource(new Map(), {
        queryMode: async (modeNumber) => (modeNumber === 2004 ? (bracketed ? "set" : "reset") : null),
        write: (text) => {
          if (text === "\x1b[?2004h") bracketed = true
          else if (text === "\x1b[?2004l") bracketed = false
        },
        input: {
          injectKey: async (key) => {
            if (key === "a") pendingInput = "a"
            else if (key === "ctrl+shift+v") pendingInput = bracketed ? `\x1b[200~${nonce}\x1b[201~` : nonce
          },
          injectClick: async () => {},
        },
        withClipboardFixture: async (work) => {
          const before = nonce
          try {
            return await work({
              paste: { selection: "clipboard", key: "ctrl+shift+v", binding: "fixture binding" },
              readText: async () => nonce,
              writeText: async (text) => {
                nonce = text
              },
            })
          } finally {
            nonce = before
            pendingInput = null
          }
        },
        readInput: async (pattern: RegExp, _timeoutMs, inject) => {
          pendingInput = null
          await inject?.()
          const report = pendingInput
          pendingInput = null
          return report !== null && pattern.test(report) ? [report] : null
        },
      }),
    }
  }
  throw new Error(`No satisfaction context configured for decided row ${id}`)
}

test("the extensions contract covers every extension feature and names none unknown", () => {
  const gaps = contractGaps(extensionsProbes, EXTENSIONS_CONTRACT, EXTENSIONS_CONTRACT_SPEC.namedUnavailable)
  expect(gaps.uncovered).toEqual([])
  expect(gaps.unknown).toEqual([])
  expect(gaps.misdeclared).toEqual([])
  expect(extensionsProbes).toHaveLength(79)
  expect(EXTENSIONS_CONTRACT).toHaveLength(79)
})

test("the extensions contract names its focused tests, and every named file exists", () => {
  const root = join(import.meta.dirname, "../../..")
  expect(missingContractTests(EXTENSIONS_CONTRACT_SPEC, root)).toEqual([])
  const command = regradeCommand(EXTENSIONS_CONTRACT_SPEC)
  expect(command).toContain("bunx --bun vitest run")
  expect(command).not.toContain("bun test")
  expect(command).not.toMatch(/[*?]/u)
  for (const path of EXTENSIONS_CONTRACT_SPEC.tests) expect(command).toContain(path)
})

test("the harness replays every extension feature deterministically", async () => {
  const headless = libProbeSource(inertModel())
  // The operator's Nov 4 16:55 declaration (part A) reads Untestable on the same branch; the rest stay reviews.
  const declaredUntestable = new Set([
    "extensions.kitty-graphics.animation",
    "extensions.kitty-graphics.unicode-placeholders",
    "extensions.sixel",
    "extensions.iterm2-images",
  ])
  const headlessReviews = new Set([...declaredUntestable, "extensions.osc7-cwd", "extensions.notifications"])
  const term = replayTermProbeSource(new Map(), {
    queryCursorPosition: async () => ({ row: 0, col: 0 }),
  })

  for (const row of EXTENSIONS_CONTRACT) {
    if (row.expected === "not-tested") continue
    const probe = extensionsProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing extension probe ${row.id}`).toBeDefined()
    if (!probe) continue
    if (headlessReviews.has(row.id)) {
      const result = probe.lib!(headless)
      expect(result.criterionBranch, row.id).toBe("headless-observable-review")
      expect(result.tests, row.id).toMatchObject([
        declaredUntestable.has(row.id)
          ? { id: "declared-untestable", status: "untestable" }
          : { id: "review", status: "probe-todo" },
      ])
      expect((await regradeRow(probe, row, { headless })).after, row.id).toBeUndefined()
    }
    expect(probe.lib !== null || probe.term !== null, `${row.id} has no callback`).toBe(true)
    const first = await regradeRow(probe, row, { headless, term })
    const second = await regradeRow(probe, row, { headless, term })
    expect(second.after, `${row.id} is not deterministic`).toBe(first.after)
    expect(second.satisfies, `${row.id} satisfaction is not deterministic`).toBe(first.satisfies)
    expect(first.satisfies, `${row.id} must route through satisfiesContract`).toBe(satisfiesContract(row, first.after))
  }
})

test("every decided extension contract row is satisfied by its required protocol response", async () => {
  const decidedRows = EXTENSIONS_CONTRACT.filter((row) => row.expected === "decided")
  expect(decidedRows).toHaveLength(42)

  for (const row of decidedRows) {
    const probe = extensionsProbes.find((p) => p.id === row.id)
    expect(probe, `missing probe for ${row.id}`).toBeDefined()
    if (!probe) continue
    const context = decidedSatisfactionSources(row.id)
    const graded = await regradeRow(probe, row, context)
    expect(graded.after, `${row.id} outcome must be supported when simulated reply arrives`).toBe("supported")
    expect(graded.satisfies, `${row.id} must satisfy contract`).toBe(true)
  }
})

test("clipboard paste follows injected keys and nonce framing while its library arm stays pending", async () => {
  const id = "extensions.clipboard-paste"
  const probe = extensionsProbes.find((entry) => entry.id === id)!
  const row = EXTENSIONS_CONTRACT.find((entry) => entry.id === id)!
  for (const source of [inertLibProbeSource(), libProbeSource(createSemanticSurface())]) {
    expect(probe.lib!(source).tests, "a library surface cannot prove OS input").toMatchObject([
      { status: "probe-todo" },
    ])
  }
  const inert = await regradeRow(probe, row, { term: replayTermProbeSource(new Map()) })
  expect(inert.after, "missing input/clipboard facilities cannot establish support").not.toBe("supported")

  for (const rawNonce of [false, true]) {
    const context = decidedSatisfactionSources(id).term!
    const injected: string[] = []
    const writes: string[] = []
    const input: NonNullable<typeof context.input> = {
      ...context.input!,
      injectKey: async (key) => {
        injected.push(key)
        await context.input!.injectKey(key)
      },
    }
    const graded = await regradeRow(probe, row, {
      term: {
        ...context,
        input,
        write: (text) => {
          writes.push(text)
          context.write(text)
        },
        readInput: async (...args) => {
          const frames = await context.readInput!(...args)
          return rawNonce
            ? (frames?.map((frame) => frame.replace("\x1b[200~", "").replace("\x1b[201~", "")) ?? null)
            : frames
        },
      },
    })
    expect(graded.after, rawNonce ? "unbracketed nonce is an observed negative" : "owned bracketed nonce arrives").toBe(
      rawNonce ? "unsupported" : "supported",
    )
    expect(injected, "the read must execute plain-a and paste injection, not return canned input").toEqual([
      "a",
      "ctrl+shift+v",
      "ctrl+shift+v",
      "ctrl+shift+v",
    ])
    expect(
      writes.filter((text) => text.includes("2004")),
      "the callback restores bracketed-paste mode",
    ).toEqual(["\x1b[?2004l", "\x1b[?2004h", "\x1b[?2004l", "\x1b[?2004l"])
    expect(
      await context.readInput!(/^$/, 1000, () => context.input!.injectKey("ctrl+shift+v")),
      "after the owned fixture closes, the empty clipboard is pasted without bracket framing",
    ).toEqual([""])
  }
})

test("every inconclusive extension contract row evaluates to inconclusive under unasserted harness context", async () => {
  const inconclusiveRows = EXTENSIONS_CONTRACT.filter((row) => row.expected === "inconclusive")
  expect(inconclusiveRows).toHaveLength(36)

  const term = replayTermProbeSource(new Map(), {
    queryCursorPosition: async () => ({ row: 0, col: 0 }),
    write: () => {},
    capture: async () => ({ role: "control", label: "test", capturedAt: 1, ref: "sha256:0" }),
  })
  const headless = libProbeSource(inertModel())

  for (const row of inconclusiveRows) {
    const probe = extensionsProbes.find((p) => p.id === row.id)
    expect(probe, `missing probe for ${row.id}`).toBeDefined()
    if (!probe) continue
    const rowTerm = [
      "extensions.truecolor",
      "extensions.osc9-progress",
      "extensions.osc555-flash",
      "extensions.osc22-pointer",
    ].includes(row.id)
      ? replayTermProbeSource(new Map())
      : term
    const callbackResult = probe.term ? await probe.term(rowTerm) : probe.lib?.(headless)
    expect(callbackResult, `${row.id} has the selected callback`).toBeDefined()
    if (callbackResult?.notTested && EXECUTION_ONLY_INCONCLUSIVE_DISPOSITIONS[row.id] === undefined) {
      expect(callbackResult.assertions, row.id).toBeUndefined()
      expect(callbackResult.notTested, `${row.id} names its missing same-path reading`).toEqual({
        reason: "no-semantic-observable",
        noObservable: NAMED_NO_OBSERVABLE[row.id] ?? NO_SAME_PATH_CONTROL,
      })
      continue
    }
    if (callbackResult && callbackResult.observation === undefined) {
      expect(callbackResult.observation, row.id).toBeUndefined()
      const disposition = EXECUTION_ONLY_INCONCLUSIVE_DISPOSITIONS[row.id]
      expect(disposition, `${row.id} has an explicit execution-only contract`).toBeDefined()
      expect(callbackResult.assertions, row.id).toBeUndefined()
      expect(callbackResult.tests, row.id).toMatchObject([
        expect.objectContaining({ status: disposition?.status, reason: disposition?.reason }),
      ])
      continue
    }
    expect(EXECUTION_ONLY_INCONCLUSIVE_DISPOSITIONS[row.id], `${row.id} keeps its measured observation`).toBeUndefined()
    expect(callbackResult?.observation, `${row.id} outcome must be inconclusive`).toMatchObject({
      outcome: "inconclusive",
      assertionType: "query_reply",
    })
  }
})

test("a decided extension row reads unsatisfied when silent or unacknowledged", async () => {
  const probe = extensionsProbes.find((p) => p.id === "extensions.osc10-fg-color")
  const row = EXTENSIONS_CONTRACT.find((r) => r.id === "extensions.osc10-fg-color")
  expect(probe).toBeDefined()
  expect(row).toBeDefined()
  if (!probe?.lib || !row) throw new Error("Expected the OSC 10 lib callback and its contract row")

  const silentSource = libProbeSource(inertModel())
  const silent = await regradeRow(probe, row, { headless: silentSource })
  expect(silent.after).toBeUndefined()
  expect(silent.satisfies).toBe(false)
  const result = probe.lib(silentSource)
  expect(result.observation).toBeUndefined()
  expect(result.assertions).toBeUndefined()
  expect(result.tests).toMatchObject([expect.objectContaining({ status: "probe-invalid", reason: "no-response" })])
})

// The umbrella claims a whole lifecycle; a working A-only reader proves only its separate mark row.
test.each([
  ["extensions.semantic-prompts", "extensions.osc133-a"],
  ["extensions.osc-633-vscode", "extensions.osc633-a"],
])("%s stays TODO when its reader can observe only A registration", (id, markId) => {
  const makeSource = () => {
    const base = libProbeSource(inertModel())
    const marks: { type: "prompt"; startRow: number; startCol: number }[] = []
    let x = 0
    let y = 0
    return {
      ...base,
      capabilities: { ...base.capabilities, semanticPrompts: true, extensions: new Set(["semantic-marks"]) },
      getSemanticMarks: () => structuredClone(marks),
      getCursor: () => ({ ...base.getCursor(), x, y }),
      getCell: () => ({ ...base.getCell(0, 0), char: "X" }),
      feed: (bytes: string) => {
        if (bytes === "\x1b[1;1H") {
          x = 0
          y = 0
        }
        if (bytes === "\x1b[2;3H") {
          x = 2
          y = 1
        }
        if (/\x1b\](?:133|633);A\x07/u.test(bytes)) marks.push({ type: "prompt", startRow: y, startCol: x })
        if (bytes.endsWith("X")) x += 1
      },
    }
  }
  const mark = extensionsProbes.find((entry) => entry.id === markId)!
  expect(mark.lib!(makeSource()).observation?.outcome).toBe("supported")
  const umbrella = extensionsProbes.find((entry) => entry.id === id)!
  const result = umbrella.lib!(makeSource())
  expect(result.pass).toBe(false)
  expect(result.tests).toEqual([
    {
      id: "criterion",
      status: "probe-todo",
      reason:
        "Open: our test saw only some of the shell cycle's steps (prompt start, command start, output start, command end with exit status), so it cannot judge the whole cycle yet.",
    },
  ])
  expect(result.observation?.outcome).not.toBe("supported")
})

test("semantic observables omitted in headless mode return notTested without failing determinism", async () => {
  const omittedProbes = ["extensions.osc1-icon", "extensions.font-ligatures"]
  const headless = libProbeSource(inertModel())
  for (const id of omittedProbes) {
    const probe = extensionsProbes.find((p) => p.id === id)
    expect(probe).toBeDefined()
    if (!probe?.lib) continue
    const result = probe.lib(headless)
    expect(result.notTested).toBeDefined()
    expect(result.notTested?.reason).toBe("no-semantic-observable")
  }
})

// A non-empty reply the parser cannot read retains the raw reply and blocks the criterion.
test("a non-empty unparsed colour-stack readback fails with its raw reply retained", () => {
  const unparsed = "\x1b]10;not-a-colour\x07"
  for (const id of ["extensions.osc30001-color-stack-push", "extensions.osc30101-color-stack-pop"]) {
    const probe = extensionsProbes.find((p) => p.id === id)
    if (!probe?.lib) throw new Error(`Missing ${id} headless arm`)
    const result = probe.lib(libProbeSource({ ...inertModel(), feedCapture: () => unparsed }))
    expect(result.criterionBranch, id).toBeUndefined()
    expect(result.observation, id).toBeUndefined()
    expect(result.assertions, id).toBeUndefined()
    expect(result.tests, id).toMatchObject([
      { status: "probe-invalid", reason: `Malformed OSC 10 reply: ${JSON.stringify(unparsed)}` },
    ])
    expect(result).not.toHaveProperty("replyFailureTestIds")
    expect(JSON.parse(result.response ?? "null"), id).toEqual({ query: "\x1b]10;?\x07", originalRaw: unparsed })
  }
})

// Initial readback is valid, so these exercise the actual mutation/pop failure rather than
// the distinct embedder-owned initial-colour review. Both arms still restore the foreground.
test.each([
  ["changed", ""],
  ["restored", ""],
  ["changed", "\x1b]10;broken\x07"],
  ["restored", "\x1b]10;broken\x07"],
] as const)("colour-stack %s readback distinguishes raw %j", (stage, raw) => {
  const original = "\x1b]10;rgb:1010/2020/3030\x07"
  for (const id of ["extensions.osc30001-color-stack-push", "extensions.osc30101-color-stack-pop"]) {
    const definition = extensionsProbes.find((entry) => entry.id === id)
    if (!definition?.lib) throw new Error(`Missing ${id} headless arm`)
    const replies = [original, stage === "changed" ? raw : original, stage === "restored" ? raw : original]
    const result = definition.lib(libProbeSource({ ...inertModel(), feedCapture: () => replies.shift() ?? "" }))
    expect(result.tests, id).toMatchObject([{ id: "criterion", status: "probe-invalid" }])
    expect(result.observation, id).toBeUndefined()
    expect(result.assertions, id).toBeUndefined()
    if (raw === "") expect(result, id).toHaveProperty("replyFailureTestIds", ["criterion"])
    else {
      expect(result, id).not.toHaveProperty("replyFailureTestIds")
      expect(result.tests?.[0]?.reason, id).toBe(`Malformed OSC 10 reply: ${JSON.stringify(raw)}`)
    }
  }
})

test("colour-stack cleanup cancels reply intent on the returned failure object", () => {
  const definition = extensionsProbes.find((entry) => entry.id === "extensions.osc30001-color-stack-push")!
  const original = "rgb:1010/2020/3030"
  const replies = [`\x1b]10;${original}\x07`, "", `\x1b]10;${original}\x07`]
  const result = definition.lib!(
    libProbeSource({
      ...inertModel(),
      feedCapture: () => replies.shift() ?? "",
      feed(sequence) {
        if (sequence === `\x1b]10;${original}\x07`) throw new Error("cleanup restore unavailable")
      },
    }),
  )
  expect(result.tests).toMatchObject([{ status: "probe-invalid", reason: expect.stringContaining("cleanup") }])
  expect(result).not.toHaveProperty("replyFailureTestIds")
  expect(withReplyFailureEvidence(definition.id, result, { producer: "headless", attempts: [] })).toBe(result)
})

// Regression (#31754): the shared colour-stack helper served one sentence to both rows, so a green
// push result reported "after color-stack pop". Each row must name its own operation.
test("each colour-stack row names its own operation in the expected sentence", () => {
  for (const [id, operation] of [
    ["extensions.osc30001-color-stack-push", "push"],
    ["extensions.osc30101-color-stack-pop", "pop"],
  ] as const) {
    const probe = extensionsProbes.find((p) => p.id === id)
    const context = decidedSatisfactionSources(id)
    if (!probe?.lib || !context.headless) throw new Error(`missing headless arm for ${id}`)
    const result = probe.lib(context.headless)
    expect(result?.assertions?.[0]?.expected, id).toContain(`color-stack ${operation}`)
    expect(result?.assertions?.[0]?.expected, id).not.toContain(`color-stack ${operation === "push" ? "pop" : "push"}`)
  }
})

// CTO54bf1c9c: only a same-run moving Cwd observer can decide OSC633P, and a wrong
// property value is an error rather than an observed negative. Existing consumption
// controls never exposed getCwd, so they could not catch these metadata regressions.
test.each([
  { model: "plain", expected: "supported" },
  { model: "file-uri", expected: "supported" },
  { model: "ignored", expected: "unsupported" },
  { model: "inert", expected: "inconclusive" },
  { model: "missing", expected: "inconclusive" },
  { model: "wrong", expected: "error" },
  { model: "partial", expected: "error" },
  { model: "bad-control", expected: "error" },
  { model: "bad-restore", expected: "error" },
])("OSC633 Cwd readback: $model => $expected", ({ model, expected }) => {
  const initial = "file://original/old%20cwd"
  let current = initial
  let targetCount = 0
  const writes: string[] = []
  const source = libProbeSource({
    ...inertModel(),
    getCwd: model === "missing" ? undefined : () => current,
    feed: (text) => {
      writes.push(text)
      const osc7 = /^\x1b\]7;(.*)\x07$/.exec(text)
      if (osc7 && model !== "inert") {
        if (model === "bad-restore" && osc7[1] === initial) return
        current = model === "bad-control" ? "/wrong-control" : osc7[1]!
      }
      const property = /^\x1b\]633;P;Cwd=(.*)\x07$/.exec(text)
      if (property) {
        targetCount++
        if (["plain", "bad-restore"].includes(model) || (model === "partial" && targetCount === 1)) {
          current = property[1]!
        } else if (model === "file-uri") {
          current = `file://different-host${property[1]!.replaceAll("-", "%2D")}`
        } else if (model === "wrong") current = "/unexpected-value"
      }
    },
  })
  const result = extensionsProbes.find((entry) => entry.id === "extensions.osc633-p")!.lib!(source)
  expect(result.observation?.outcome).toBe(expected)
  if (model !== "missing") expect(writes.at(-1)).toBe(`\x1b]7;${initial}\x07`)
  if (!["missing", "inert", "bad-restore", "bad-control"].includes(model)) expect(current).toBe(initial)
  if (expected === "supported" || expected === "unsupported" || ["wrong", "partial"].includes(model)) {
    expect(targetCount).toBe(2)
    const state = JSON.parse(result.response!)
    expect(state).toMatchObject({
      controls: [{ value: expect.any(String) }, { value: expect.any(String) }],
      targets: [{ sent: "/terminfo-633-cwd-A" }, { sent: "/terminfo-633-cwd-B" }],
    })
  }
  if (expected === "inconclusive") {
    expect(targetCount).toBe(0)
    expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-todo" }))
  }
})

test.each([
  { model: "exact", expected: "supported" },
  { model: "ignored", expected: "unsupported" },
  { model: "inert", expected: "inconclusive" },
  { model: "missing", expected: "inconclusive" },
  { model: "wrong", expected: "error" },
  { model: "partial", expected: "error" },
])("OSC633 end reader: $model => $expected", ({ model, expected }) => {
  const base = inertModel()
  const initial = { type: "command-end" as const, rawStatus: "42" }
  const marks = [initial]
  const cells = new Map<string, string>()
  const writes: string[] = []
  let x = 0
  let y = 0
  let targets = 0
  const source = libProbeSource({
    ...base,
    capabilities: { ...libProbeSource(base).capabilities, extensions: new Set(["semantic-command-end"]) },
    getSemanticMarks: model === "missing" ? undefined : () => (model === "inert" ? [initial] : structuredClone(marks)),
    getCursor: () => ({ ...base.getCursor(), x, y }),
    getCell: (row, col) => ({ ...base.getCell(row, col), char: cells.get(`${row},${col}`) ?? " " }),
    feed: (text) => {
      writes.push(text)
      if (text === "\x1b[1;1H") {
        x = 0
        y = 0
      }
      if (text === "\x1b[2;3H") {
        x = 2
        y = 1
      }
      const end = /^\x1b\](133|633);D;([^\x07]*)\x07X?$/.exec(text)
      if (end?.[1] === "133") marks.push({ type: "command-end", rawStatus: end[2]! })
      if (end?.[1] === "633") {
        targets++
        if (model === "exact" || (model === "partial" && targets === 1)) {
          marks.push({ type: "command-end", rawStatus: end[2]! })
        }
        if (model === "wrong") marks.push({ type: "command-end", rawStatus: "wrong-status" })
      }
      if (text.endsWith("X")) {
        cells.set(`${y},${x}`, "X")
        x++
      }
    },
  })
  const result = extensionsProbes.find((entry) => entry.id === "extensions.osc633-d")!.lib!(source)
  expect(result.observation?.outcome).toBe(expected)
  expect(marks[0]).toEqual(initial)
  if (expected === "inconclusive") {
    expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-todo" }))
  }
  if (["supported", "unsupported", "error"].includes(expected)) {
    expect(writes).toContain("\x1b]133;D;0\x07")
    expect(writes).toContain("\x1b]133;D;17\x07")
    expect(writes).toContain("\x1b]633;D;0\x07X")
    expect(writes).toContain("\x1b]633;D;17\x07X")
    expect(targets).toBe(2)
  }
})

// #31904 R3a (@cto 6e4f7300): each colour-stack row grades its own operation. A pop that resets to
// the starting (default) foreground passed both rows when the fixture restored that same colour; a
// stack that keeps a stale snapshot passed the push row. Each fake below is a whole engine model.
function colourStackEngine(kind: "reset-default" | "stale" | "pop-noop" | "set-ignored") {
  const original = "rgb:1010/2020/3030"
  let current = original
  const stack: string[] = []
  return libProbeSource({
    ...inertModel(),
    feed: (seq) => {
      if (seq.includes("]30001")) {
        if (kind !== "stale" || stack.length === 0) stack.push(current)
      } else if (seq.includes("]30101")) {
        if (kind === "reset-default") {
          stack.pop()
          current = original
        } else if (kind === "stale") current = stack.at(-1) ?? current
        else if (kind !== "pop-noop") current = stack.pop() ?? current
      } else {
        const m = /\x1b\]10;(rgb:[a-f\d/]+)/i.exec(seq)
        if (m && kind !== "set-ignored") current = m[1] ?? current
      }
    },
    feedCapture: () => `\x1b]10;${current}\x1b\\`,
  })
}

test.each([
  ["reset-default", "extensions.osc30001-color-stack-push", "probe-todo", "no push-only observation"],
  ["reset-default", "extensions.osc30101-color-stack-pop", "probe-todo", "no pop-only observation"],
  ["stale", "extensions.osc30001-color-stack-push", "unsupported", "push saved no current snapshot"],
  ["stale", "extensions.osc30101-color-stack-pop", "supported", undefined],
  ["pop-noop", "extensions.osc30001-color-stack-push", "unsupported", "push then pop restored no earlier state"],
  ["pop-noop", "extensions.osc30101-color-stack-pop", "unsupported", "push then pop restored no earlier state"],
] as const)("a %s colour stack grades %s %s on its own operation", (kind, id, outcome, note) => {
  const probe = extensionsProbes.find((entry) => entry.id === id)!
  const result = probe.lib!(colourStackEngine(kind))
  if (outcome === "probe-todo") expect(result.notTested).toMatchObject({ reason: "no-semantic-observable" })
  else expect(result.observation?.outcome).toBe(outcome)
  expect(result.pass).toBe(outcome === "supported")
  if (note) expect(result.note).toContain(note)
  if (outcome === "probe-todo") expect(result.assertions).toBeUndefined()
})

// #32242 (@cto 4115d1bf): an engine that ignores the OSC 10 set never shows either stack operation,
// so both rows are a coverage record (PROBE TODO), never the negative main graded them.
test.each(["extensions.osc30001-color-stack-push", "extensions.osc30101-color-stack-pop"])(
  "%s with the OSC 10 set ignored is a coverage record, not a negative",
  (id) => {
    const probe = extensionsProbes.find((entry) => entry.id === id)!
    const result = probe.lib!(colourStackEngine("set-ignored"))
    expect(result.notTested).toMatchObject({ reason: "no-semantic-observable" })
    expect(result.assertions).toBeUndefined()
    expect(result.observation?.outcome).not.toBe("unsupported")
  },
)

// A declared capability and a working parser control cannot observe an OS or pixel effect.
test.each([
  "extensions.osc9-progress",
  "extensions.osc176-app-id",
  "extensions.osc440-audio",
  "extensions.osc555-flash",
  "extensions.osc666-termprop",
  "extensions.osc710-font-normal",
  "extensions.osc777-notify",
  "extensions.osc3008-context",
  "extensions.font-ligatures",
  "extensions.iterm2-images",
])("%s retains its missing-observer record with declared working and inert sources", (id) => {
  // Ligatures and iTerm2 images are declared Untestable for every library (operator Nov 4 16:55).
  const expected = id === "extensions.font-ligatures" || id === "extensions.iterm2-images" ? "untestable" : "probe-todo"
  const probe = extensionsProbes.find((entry) => entry.id === id)!
  for (const [profile, base] of [
    ["working", libProbeSource(createSemanticSurface())],
    ["inert", inertLibProbeSource()],
  ] as const) {
    const source = {
      ...base,
      capabilities: {
        ...base.capabilities,
        kittyGraphics: true,
        sixel: true,
        extensions: new Set(["osc7", "osc9", "iterm2Images"]),
      },
    }
    const control = source.feedCapture("\x1b[c")
    if (profile === "working") expect(control, `${id}: parser control works`).toMatch(/^\x1b\[\?[0-9;]+c$/u)
    else expect(control, `${id}: inert control stays silent`).toBe("")

    const result = probe.lib!(source)
    expect(result.pass, `${id}: ${profile} has no effect observer`).toBe(false)
    expect(result.notTested, id).toMatchObject({ reason: "no-semantic-observable" })
    expect(result.observation, id).toBeUndefined()
    expect(result.assertions, id).toBeUndefined()
    if (result.tests !== undefined) {
      for (const criterion of result.tests) expect(criterion.status, id).toBe(expected)
    }
  }
})
