import { describe, expect, test } from "vitest"
import { deviceProbes } from "./device.ts"
import { recordExecutedProbe } from "./helpers.ts"
import type { TermProbeSource, LibProbeSource, TerminalQueryOutcome } from "./types.ts"

const replies = [
  { id: "device.primary-da", query: "\x1b[c", valid: "\x1b[?62;52;c", partial: "\x1b[?62;52;" },
  { id: "device.status-report", query: "\x1b[5n", valid: "\x1b[0n", partial: "\x1b[4n" },
  { id: "device.secondary-da", query: "\x1b[>c", valid: "\x1b[>0;49;1c", partial: "\x1b[>0;;1c" },
  { id: "device.tertiary-da", query: "\x1b[=c", valid: "\x1bP!|1234ABCD\x1b\\", partial: "\x1bP!|1234ABCD" },
  { id: "device.decrqss", query: "\x1bP$qm\x1b\\", valid: "\x1bP1$r0m\x1b\\", partial: "\x1bP1$r" },
  {
    id: "device.xtgettcap",
    query: "\x1bP+q544e\x1b\\",
    valid: "\x1bP1+r544e=787465726d\x1b\\",
    partial: "\x1bP1+r544e=787",
  },
  { id: "device.decrpm", query: "\x1b[?7$p", valid: "\x1b[?7;1$y", partial: "\x1b[?1;1$y" },
  { id: "device.xtversion", query: "\x1b[>0q", valid: "\x1bP>|kitty(0.49.1)\x1b\\", partial: "\x1bP>|kitty(0.49.1)" },
] as const

function headless(raw: string): LibProbeSource {
  // Device query callbacks use only feedCapture; missing operations fail loudly if newly used.
  return { feedCapture: () => raw } as unknown as LibProbeSource
}

function terminal(
  raw: string,
  reason: TerminalQueryOutcome["reason"] = "reply",
  sentinel?: { atMs: number; graceMs: number },
): TermProbeSource {
  const reply = (sequence: string, pattern: RegExp): Promise<TerminalQueryOutcome> => {
    const item = replies.find((candidate) => candidate.query === sequence)
    if (!item) throw new Error(`unexpected query ${JSON.stringify(sequence)}`)
    // A reply the collector matched is a reply; the reason alone decides the rest. `sentinel` is the
    // measured ordering the live collector records when DA1 answered before this query's reply.
    const match = reason === "reply" ? pattern.exec(raw) : null
    return Promise.resolve({
      match,
      reason,
      raw,
      rawBase64: Buffer.from(raw).toString("base64"),
      ...(sentinel && { sentinel }),
    })
  }
  return {
    queryOutcome: reply,
    queryWithSentinelOutcome: reply,
  } as unknown as TermProbeSource
}

function callback(id: string) {
  const definition = deviceProbes.find((item) => item.id === id)
  if (!definition?.lib || !definition.term) throw new Error(`missing device callback ${id}`)
  return { headless: definition.lib, terminal: definition.term }
}

/**
 * @failure A title-stack checkpoint leaks into later probes after the app callback returns or its query rejects.
 * @level l1
 * @consumer Application device observations sharing one owned terminal.
 * @testonly none
 */
test("an absent App title reader leaves the terminal untouched", async () => {
  const writes: string[] = []
  const context = {
    write: (bytes: string) => writes.push(bytes),
  } as unknown as TermProbeSource

  for (const id of ["device.xtwinops-22", "device.xtwinops-23"]) {
    const callbackResult = await callback(id).terminal(context)
    expect(callbackResult.observation).toBeUndefined()
    expect(callbackResult.notTested).toMatchObject({ reason: "no-semantic-observable" })
  }
  expect(writes).toEqual([])
})

const DECRQSS_SGR_QUERY = "\x1bP$qm\x1b\\"
const DECRQSS_DECSTBM_QUERY = "\x1bP$qr\x1b\\"
const DECRQSS_DECSCL_QUERY = '\x1bP$q"p\x1b\\'
const DECRQSS_DECSCUSR_QUERY = "\x1bP$q q\x1b\\"
const DECRQSS_SGR_VALID = "\x1bP1$r0m\x1b\\"
const DECRQSS_REFUSAL = "\x1bP0$r\x1b\\"
const DECRQSS_DECSTBM_VALID = "\x1bP1$r1;24r\x1b\\"
const DECRQSS_DECSCL_VALID = '\x1bP1$r62;1"p\x1b\\'
// 32569: tmux's input.c answers `1$r q%d q`, an extra ` q` before the style; xterm answers `1$r%d q`.
const DECRQSS_DECSCUSR_TMUX = "\x1bP1$r q2 q\x1b\\"
const DECRQSS_DECSCUSR_XTERM = "\x1bP1$r2 q\x1b\\"
const DECRQSS_FOUR_REFUSALS = "SGR refused; DECSTBM refused; DECSCL refused; DECSCUSR refused"
const DA1 = "\x1b[?62;52;c"

test.each([
  { replies: [DECRQSS_SGR_VALID], outcome: "supported", observed: DECRQSS_SGR_VALID },
  {
    replies: [DECRQSS_REFUSAL, DECRQSS_DECSTBM_VALID],
    outcome: "supported",
    observed: DECRQSS_DECSTBM_VALID,
    response: DECRQSS_DECSTBM_VALID,
  },
  {
    replies: [DECRQSS_REFUSAL, DECRQSS_REFUSAL, DECRQSS_DECSCL_VALID],
    outcome: "supported",
    observed: DECRQSS_DECSCL_VALID,
  },
  {
    replies: [DECRQSS_REFUSAL, DECRQSS_REFUSAL, DECRQSS_REFUSAL, DECRQSS_DECSCUSR_TMUX],
    outcome: "supported",
    observed: DECRQSS_DECSCUSR_TMUX,
  },
  {
    replies: [DECRQSS_REFUSAL, DECRQSS_REFUSAL, DECRQSS_REFUSAL, DECRQSS_DECSCUSR_XTERM],
    outcome: "supported",
    observed: DECRQSS_DECSCUSR_XTERM,
  },
  {
    replies: [DECRQSS_REFUSAL, DECRQSS_REFUSAL, DECRQSS_REFUSAL, DECRQSS_REFUSAL],
    outcome: "unsupported",
    negative: DECRQSS_REFUSAL,
  },
  { replies: [DECRQSS_REFUSAL, "\x1bP1$r"], outcome: "inconclusive" },
  { replies: [DECRQSS_REFUSAL, ""], outcome: "probe-invalid" },
])(
  "plain library DECRQSS samples only after complete selector refusal: $replies",
  ({ replies, outcome, observed, response, negative }) => {
    const selectors = [DECRQSS_SGR_QUERY, DECRQSS_DECSTBM_QUERY, DECRQSS_DECSCL_QUERY, DECRQSS_DECSCUSR_QUERY]
    const queries: string[] = []
    const result = callback("device.decrqss").headless({
      feedCapture: (sequence: string) => {
        const at = queries.length
        queries.push(sequence)
        const raw = replies[at]
        if (raw === undefined) throw new Error(`unexpected selector ${JSON.stringify(sequence)}`)
        return raw
      },
    } as unknown as LibProbeSource)
    expect(queries).toEqual(selectors.slice(0, replies.length))
    if (outcome === "probe-invalid") {
      expect(result.observation).toBeUndefined()
      expect(result.tests).toMatchObject([expect.objectContaining({ status: "probe-invalid" })])
      return
    }
    expect(result.observation).toMatchObject({ outcome, assertionType: "query_reply" })
    if (observed !== undefined) {
      expect(result.assertions).toMatchObject([{ kind: "positive", observed }])
      expect(result.response).toBe(response ?? replies.join(""))
    } else if (negative !== undefined) {
      expect(result.assertions).toMatchObject([{ kind: "negative", observed: negative }])
      expect(result.response).toBe(replies.join(""))
      expect(result.observation?.note).toBe(DECRQSS_FOUR_REFUSALS)
    } else {
      expect(result.assertions).toBeUndefined()
      expect(result.observation?.note).toContain("SGR refused")
    }
  },
)

function terminalScript(
  replies: Record<
    string,
    { raw: string; reason: TerminalQueryOutcome["reason"]; sentinel?: { atMs: number; graceMs: number } }
  >,
): { ctx: TermProbeSource; lib: LibProbeSource; queries: string[] } {
  const queries: string[] = []
  const read = (sequence: string, pattern: RegExp): TerminalQueryOutcome => {
    queries.push(sequence)
    const item = replies[sequence]
    if (!item) throw new Error(`unexpected query ${JSON.stringify(sequence)}`)
    const match = item.reason === "reply" ? pattern.exec(item.raw) : null
    return {
      match,
      reason: item.reason,
      raw: item.raw,
      rawBase64: Buffer.from(item.raw).toString("base64"),
      ...(item.sentinel && { sentinel: item.sentinel }),
    }
  }
  const ctx = {
    queryWithSentinelOutcome: async (sequence: string, pattern: RegExp) => read(sequence, pattern),
  } as unknown as TermProbeSource
  const lib = { queryWithSentinelOutcome: read } as unknown as LibProbeSource
  return { ctx, lib, queries }
}

/**
 * @failure Arbitrary output, partial frames, and sentinel replies were promoted to supported device protocols.
 * @level l0
 * @consumer Unified headless and application device-query observations.
 * @testonly none
 */
describe("device query observations", () => {
  for (const item of replies) {
    test(`${item.id}: complete frame supports; unrelated and partial replies do not`, async () => {
      const probe = callback(item.id)
      for (const result of [probe.headless(headless(item.valid)), await probe.terminal(terminal(item.valid))]) {
        expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
        expect(result.response).toBe(item.valid)
        expect(result.assertions).toMatchObject([{ kind: "positive", observed: item.valid }])
      }
      const unrelated = "\x1b[12;20R"
      for (const result of [
        probe.headless(headless(unrelated)),
        await probe.terminal(terminal(unrelated, "sentinel")),
      ]) {
        expect(result.observation).toMatchObject({ outcome: "inconclusive", reason: "no-response" })
        expect(result.assertions).toBeUndefined()
      }
      for (const result of [
        probe.headless(headless(item.partial)),
        await probe.terminal(terminal(item.partial, "sentinel")),
      ]) {
        expect(result.observation).toMatchObject({ outcome: "inconclusive", reason: "invalid-reply" })
        expect(result.assertions).toBeUndefined()
      }
    })
  }

  test("a reply after the DA1 sentinel grades by the reply and is marked late", async () => {
    const da1 = "\x1b[?62;52;c"
    const measured = { atMs: 12, graceMs: 250 }
    for (const item of replies.filter((candidate) => candidate.id !== "device.primary-da")) {
      const lateRaw = da1 + item.valid
      const late = await callback(item.id).terminal(terminal(lateRaw, "reply", measured))
      expect(late.response, item.id).toBe(lateRaw)
      expect(late.observation, item.id).toMatchObject({
        outcome: "supported",
        assertionType: "query_reply",
        note: "reply after sentinel",
      })
      expect(late.assertions, item.id).toMatchObject([{ kind: "positive", observed: item.valid }])

      const earlyRaw = item.valid + da1
      const early = await callback(item.id).terminal(terminal(earlyRaw))
      expect(early.response, item.id).toBe(earlyRaw)
      expect(early.observation, item.id).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
      expect(early.observation?.note, item.id).toBeUndefined()
      expect(early.assertions, item.id).toMatchObject([{ kind: "positive", observed: item.valid }])
    }
  })

  test("DA1 answered alone through the window is a measured negative, not an unknown", async () => {
    const da1 = "\x1b[?62;52;c"
    for (const item of replies.filter((candidate) => candidate.id !== "device.primary-da")) {
      const result = await callback(item.id).terminal(terminal(da1, "sentinel", { atMs: 9, graceMs: 250 }))
      expect(result.response, item.id).toBe(da1)
      expect(result.observation, item.id).toMatchObject({
        outcome: "inconclusive",
        reason: "fenced-silence",
        assertionType: "query_reply",
        note: "DA1 answered at +9ms; no reply through the 250 ms window",
      })
      expect(result.assertions, item.id).toMatchObject([
        { kind: "negative", observed: "DA1 answered at +9ms; no reply through the 250 ms window" },
      ])
      // The negative names the feature's own reply contract, not a generic silence.
      expect(result.assertions?.[0]?.expected, item.id).toBeTruthy()
    }
  })

  test("without the measured ordering a frame after DA1 stays unreadable and silence stays unknown", async () => {
    const da1 = "\x1b[?62;52;c"
    for (const item of replies.filter((candidate) => candidate.id !== "device.primary-da")) {
      const lateRaw = da1 + item.valid
      const late = await callback(item.id).terminal(terminal(lateRaw, "sentinel"))
      expect(late.observation, item.id).toMatchObject({ outcome: "inconclusive", reason: "no-response" })
      expect(late.assertions, item.id).toBeUndefined()

      const silent = await callback(item.id).terminal(terminal(da1, "sentinel"))
      expect(silent.observation, item.id).toMatchObject({ outcome: "inconclusive", reason: "no-response" })
      expect(silent.assertions, item.id).toBeUndefined()
    }
  })

  // #30559 (@cto 86260f80 rules 1 and 3): the sentinel's answer is the LAST DA1-shaped answer, and every byte before
  // it is the query's reply. Terminal.app answers DA3 with a DA1-shaped reply, which is bytes, never silence.
  test("a DA1-shaped reply ahead of the DA1 answer is no measured negative", async () => {
    const da1 = "\x1b[?62;52;c"
    for (const item of replies.filter((candidate) => candidate.id !== "device.primary-da")) {
      const result = await callback(item.id).terminal(terminal(da1 + da1, "sentinel", { atMs: 9, graceMs: 250 }))
      expect(result.observation, item.id).toStrictEqual({
        outcome: "inconclusive",
        reason: "no-response",
        assertionType: "query_reply",
      })
      expect(result.assertions, item.id).toBeUndefined()
    }
  })

  test("a frame between a DA1-shaped reply and the DA1 answer arrived on time and grades by the frame", async () => {
    const da1 = "\x1b[?62;52;c"
    for (const item of replies.filter((candidate) => candidate.id !== "device.primary-da")) {
      const raw = da1 + item.valid + da1
      const result = await callback(item.id).terminal(terminal(raw))
      expect(result.response, item.id).toBe(raw)
      expect(result.observation, item.id).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
      expect(result.observation?.note, item.id).toBeUndefined()
      expect(result.assertions, item.id).toMatchObject([{ kind: "positive", observed: item.valid }])
    }
  })

  test("DA1 sentinel and one refused setting cannot establish facility support, late or early", async () => {
    const sentinel = "\x1b[?62;52;c"
    const measured = { atMs: 12, graceMs: 250 }
    for (const [id, refusal] of [
      ["device.xtgettcap", "\x1bP0+r\x1b\\"],
      ["device.decrpm", "\x1b[?7;0$y"],
    ] as const) {
      const lateRaw = sentinel + refusal
      const late = await callback(id).terminal(terminal(lateRaw, "reply", measured))
      expect(late.response, id).toBe(lateRaw)
      expect(late.observation, id).toMatchObject({
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        assertionType: "query_reply",
        note: "Requested setting or name refused; other settings or names unmeasured; reply after sentinel",
      })
      expect(late.assertions, id).toBeUndefined()

      const unmeasuredLate = await callback(id).terminal(terminal(lateRaw, "sentinel"))
      expect(unmeasuredLate.observation, id).toMatchObject({ outcome: "inconclusive", reason: "no-response" })

      const earlyRaw = refusal + sentinel
      const early = await callback(id).terminal(terminal(earlyRaw))
      expect(early.response, id).toBe(earlyRaw)
      expect(early.observation, id).toMatchObject({
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        assertionType: "query_reply",
      })
      expect(early.assertions, id).toBeUndefined()
    }
  })

  test("the first combined refusal or valid frame determines the DECRPM result", async () => {
    const refusal = "\x1b[?7;0$y"
    const valid = "\x1b[?7;1$y"
    const probe = callback("device.decrpm")
    for (const result of [probe.headless(headless(refusal + valid)), await probe.terminal(terminal(refusal + valid))]) {
      expect(result.response).toBe(refusal + valid)
      expect(result.observation).toMatchObject({
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        assertionType: "query_reply",
      })
      expect(result.assertions).toBeUndefined()
    }
    for (const result of [probe.headless(headless(valid + refusal)), await probe.terminal(terminal(valid + refusal))]) {
      expect(result.response).toBe(valid + refusal)
      expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
      expect(result.assertions).toMatchObject([{ kind: "positive", observed: valid }])
    }
  })

  test("silence is inconclusive and a TTY deadline remains a timeout", async () => {
    for (const item of replies) {
      const probe = callback(item.id)
      const missing = probe.headless(headless(""))
      expect(missing.observation).toBeUndefined()
      expect(missing.tests).toMatchObject([
        expect.objectContaining({ status: "probe-invalid", reason: expect.any(String) }),
      ])
      const timedOut = await probe.terminal(terminal("", "timeout"))
      expect(timedOut.observation).toBeUndefined()
      expect(timedOut.tests).toMatchObject([
        expect.objectContaining({ status: "probe-invalid", reason: expect.any(String) }),
      ])
    }
  })

  test("DA1 uses a direct query and a valid frame stays bound to raw output containing unrelated bytes", async () => {
    const primary = callback("device.primary-da")
    const raw = "\x1b[12;20R\x1b[?1;2c"
    const result = await primary.terminal({
      queryOutcome: (_sequence: string, pattern: RegExp) =>
        Promise.resolve({
          match: pattern.exec(raw),
          reason: "reply",
          raw,
          rawBase64: Buffer.from(raw).toString("base64"),
        }),
      queryWithSentinelOutcome: () => {
        throw new Error("DA1 must not use a DA1 sentinel")
      },
    } as unknown as TermProbeSource)
    expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
    expect(result.response).toBe(raw)
    expect(result.assertions).toMatchObject([{ kind: "positive", observed: "\x1b[?1;2c" }])
  })

  test("four DECRQSS refusals are Unsupported; other single-setting refusals are inconclusive; malfunction is still a DSR report", async () => {
    const sgrRefusal = "\x1bP0$r\x1b\\"
    expect(callback("device.decrqss").headless(headless(sgrRefusal)).observation).toMatchObject({
      outcome: "unsupported",
      assertionType: "query_reply",
      note: DECRQSS_FOUR_REFUSALS,
    })
    for (const [id, frame] of [
      ["device.xtgettcap", "\x1bP0+r\x1b\\"],
      ["device.decrpm", "\x1b[?7;0$y"],
    ] as const) {
      const probe = callback(id)
      for (const result of [probe.headless(headless(frame)), await probe.terminal(terminal(frame))]) {
        expect(result.observation).toMatchObject({
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          assertionType: "query_reply",
          note: "Requested setting or name refused; other settings or names unmeasured",
        })
        expect(result.assertions).toBeUndefined()
        expect(result.response).toBe(frame)
      }
    }
    const status = callback("device.status-report")
    const malfunction = status.headless(headless("\x1b[3n"))
    expect(malfunction.observation).toMatchObject({ outcome: "supported", note: "Terminal reports malfunction" })
    expect(malfunction.assertions).toMatchObject([{ kind: "positive", observed: "\x1b[3n" }])
  })

  test("SGR status-0 then a complete DECSTBM Pt;Pb r frame supports the DECRQSS facility", async () => {
    const script = terminalScript({
      [DECRQSS_SGR_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSTBM_QUERY]: { raw: DECRQSS_DECSTBM_VALID, reason: "reply" },
    })
    const result = await callback("device.decrqss").terminal(script.ctx)
    expect(script.queries).toEqual([DECRQSS_SGR_QUERY, DECRQSS_DECSTBM_QUERY])
    expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
    expect(result.assertions).toMatchObject([{ kind: "positive", observed: DECRQSS_DECSTBM_VALID }])
  })

  // Two selector refusals establish a speaking facility, not a facility-wide negative. The old
  // two-selector case never exercised Vterm's real DECSCL reply or silence after both refusals.
  test.each(
    [
      { name: "valid DECSCL", raw: DECRQSS_DECSCL_VALID, reason: "reply" as const, supported: true },
      { name: "DECSCL silence", raw: DA1, reason: "sentinel" as const, supported: false },
    ].flatMap((third) => (["headless", "terminal"] as const).map((route) => ({ ...third, route }))),
  )("$route: SGR and DECSTBM refusals then $name retains facility evidence", async (third) => {
    const route = third.route
    const script = terminalScript({
      [DECRQSS_SGR_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSTBM_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSCL_QUERY]: {
        raw: third.raw,
        reason: third.reason,
        ...(third.reason === "sentinel" && { sentinel: { atMs: 9, graceMs: 250 } }),
      },
    })
    const probe = callback("device.decrqss")
    const result = route === "headless" ? probe.headless(script.lib) : await probe.terminal(script.ctx)
    expect(result.observation).toMatchObject({
      outcome: third.supported ? "supported" : "inconclusive",
      assertionType: "query_reply",
    })
    expect(result.observation?.note).toMatch(/SGR refused/)
    expect(result.observation?.note).toMatch(/DECSTBM refused/)
    if (third.supported) {
      expect(result.assertions).toMatchObject([{ kind: "positive", observed: DECRQSS_DECSCL_VALID }])
      expect(result.response?.split(DECRQSS_REFUSAL).length).toBe(3)
      expect(result.response).toContain(DECRQSS_DECSCL_VALID)
    } else {
      expect(result.observation?.note).toMatch(/DECSCL/)
      expect(result.assertions).toBeUndefined()
    }
    expect(script.queries).toEqual([DECRQSS_SGR_QUERY, DECRQSS_DECSTBM_QUERY, DECRQSS_DECSCL_QUERY])
  })

  // 32569: tmux refuses SGR, DECSTBM and DECSCL and answers SP q (input.c), so a fourth selector decides it. Four
  // refusals are Unsupported, retaining all four (@cto third-table ruling 2026-11-06). F1 (27832): a refusal after
  // DA1 decides only with the measured order.
  const measured = { atMs: 9, graceMs: 250 }
  test.each(
    [
      { name: "tmux DECSCUSR", raw: DECRQSS_DECSCUSR_TMUX, reason: "reply" as const, outcome: "supported" },
      { name: "xterm DECSCUSR", raw: DECRQSS_DECSCUSR_XTERM, reason: "reply" as const, outcome: "supported" },
      { name: "DECSCUSR refusal", raw: DECRQSS_REFUSAL, reason: "reply" as const, outcome: "unsupported" },
      {
        name: "DECSCUSR refusal after DA1, measured",
        raw: DA1 + DECRQSS_REFUSAL,
        reason: "reply" as const,
        sentinel: measured,
        outcome: "unsupported",
        note: `${DECRQSS_FOUR_REFUSALS}; reply after sentinel`,
      },
      {
        name: "DECSCUSR refusal after DA1, unmeasured",
        raw: DA1 + DECRQSS_REFUSAL,
        reason: "reply" as const,
        outcome: "inconclusive",
      },
      { name: "DECSCUSR silence", raw: DA1, reason: "sentinel" as const, sentinel: measured, outcome: "inconclusive" },
    ].flatMap((fourth) => (["headless", "terminal"] as const).map((route) => ({ ...fourth, route }))),
  )("$route: SGR, DECSTBM and DECSCL refusals then $name", async (fourth) => {
    const script = terminalScript({
      [DECRQSS_SGR_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSTBM_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSCL_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSCUSR_QUERY]: {
        raw: fourth.raw,
        reason: fourth.reason,
        ...(fourth.sentinel && { sentinel: fourth.sentinel }),
      },
    })
    const probe = callback("device.decrqss")
    const result = fourth.route === "headless" ? probe.headless(script.lib) : await probe.terminal(script.ctx)
    expect(script.queries).toEqual([
      DECRQSS_SGR_QUERY,
      DECRQSS_DECSTBM_QUERY,
      DECRQSS_DECSCL_QUERY,
      DECRQSS_DECSCUSR_QUERY,
    ])
    expect(result.observation).toMatchObject({ outcome: fourth.outcome, assertionType: "query_reply" })
    expect(result.observation?.note).toMatch(/^SGR refused; DECSTBM refused; DECSCL refused/)
    if (fourth.outcome === "inconclusive") {
      expect(result.assertions).toBeUndefined()
      return
    }
    expect(result.response).toBe(DECRQSS_REFUSAL.repeat(3) + fourth.raw)
    if (fourth.outcome === "supported") {
      expect(result.assertions).toMatchObject([{ kind: "positive", observed: fourth.raw }])
    } else {
      expect(result.observation?.note).toBe(fourth.note ?? DECRQSS_FOUR_REFUSALS)
      expect(result.assertions).toMatchObject([{ kind: "negative", observed: DECRQSS_REFUSAL }])
    }
  })

  test("SGR status-0 then DECSTBM unanswered (DA1 only) stays inconclusive, not F1 negative", async () => {
    const script = terminalScript({
      [DECRQSS_SGR_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSTBM_QUERY]: {
        raw: DA1,
        reason: "sentinel",
        sentinel: { atMs: 9, graceMs: 250 },
      },
    })
    const result = await callback("device.decrqss").terminal(script.ctx)
    expect(script.queries).toEqual([DECRQSS_SGR_QUERY, DECRQSS_DECSTBM_QUERY])
    expect(result.observation).toMatchObject({
      outcome: "inconclusive",
      reason: "insufficient-evidence",
      assertionType: "query_reply",
    })
    expect(result.assertions).toBeUndefined()

    // Unlike DA1-only, the empty second read retains no reply. The library collector keeps only
    // this callback response, so the first SGR refusal cannot become a synthetic deciding reply.
    const emptyScript = terminalScript({
      [DECRQSS_SGR_QUERY]: { raw: DECRQSS_REFUSAL, reason: "reply" },
      [DECRQSS_DECSTBM_QUERY]: { raw: "", reason: "timeout" },
    })
    const libraryQueries: string[] = []
    const library = {
      queryWithSentinelOutcome(sequence: string, pattern: RegExp): TerminalQueryOutcome {
        libraryQueries.push(sequence)
        const raw = sequence === DECRQSS_SGR_QUERY ? DECRQSS_REFUSAL : ""
        return { match: pattern.exec(raw), reason: raw ? "reply" : "timeout", raw, rawBase64: btoa(raw) }
      },
    } as unknown as LibProbeSource
    for (const empty of [
      await callback("device.decrqss").terminal(emptyScript.ctx),
      callback("device.decrqss").headless(library),
    ]) {
      expect(empty.response).toBe("")
      expect(empty.observation).toBeUndefined()
      expect(empty.assertions).toBeUndefined()
      const recorded = recordExecutedProbe({
        featureId: "device.decrqss",
        attempt: { scope: "probe", startedAt: "2026-10-21T05:00:00.000Z" },
        rawReplyRef: "device.decrqss",
        assertions: [],
        tests: empty.tests,
      })
      expect(recorded.status).toBe("probe-invalid")
      expect(recorded.assertionType).toBeUndefined()
      expect(recorded.reason).toContain("SGR refused; DECSTBM unanswered; DECRQSS facility still speaks")
      expect(recorded.reason).toContain("complete DECRQSS status 1 DECSTBM margins ending r and ST")
    }
    expect(emptyScript.queries).toEqual([DECRQSS_SGR_QUERY, DECRQSS_DECSTBM_QUERY])
    expect(libraryQueries).toEqual([DECRQSS_SGR_QUERY, DECRQSS_DECSTBM_QUERY])
  })

  test("SGR status 1 keeps today's grade and never asks DECSTBM", async () => {
    const script = terminalScript({
      [DECRQSS_SGR_QUERY]: { raw: DECRQSS_SGR_VALID, reason: "reply" },
    })
    const result = await callback("device.decrqss").terminal(script.ctx)
    expect(script.queries).toEqual([DECRQSS_SGR_QUERY])
    expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
    expect(result.assertions).toMatchObject([{ kind: "positive", observed: DECRQSS_SGR_VALID }])
  })

  test("no SGR reply keeps today's F1 negative and never asks DECSTBM", async () => {
    const script = terminalScript({
      [DECRQSS_SGR_QUERY]: {
        raw: DA1,
        reason: "sentinel",
        sentinel: { atMs: 9, graceMs: 250 },
      },
    })
    const result = await callback("device.decrqss").terminal(script.ctx)
    expect(script.queries).toEqual([DECRQSS_SGR_QUERY])
    expect(result.observation).toMatchObject({
      outcome: "inconclusive",
      reason: "fenced-silence",
      assertionType: "query_reply",
      note: expect.stringMatching(/^DA1 answered at \+\d+ms; no reply through the \d+ ms window$/),
    })
  })

  test("the exact requested mode/name and a complete ST matter", () => {
    for (const [id, frame] of [
      ["device.decrpm", "\x1b[?1;1$y"],
      ["device.xtgettcap", "\x1bP1+r5267=78\x1b\\"],
      ["device.decrqss", '\x1bP1$r61;1"p\x1b\\'],
      ["device.xtversion", "\x1bP>|kitty(0.49.1)"],
      ["device.decrqss", '\x1bP0$r61;1"p\x1b\\'],
      ["device.xtgettcap", "\x1bP0+r544e\x1b\\"],
    ] as const) {
      expect(callback(id).headless(headless(frame)).observation).toMatchObject({
        outcome: "inconclusive",
        reason: "invalid-reply",
      })
    }
  })

  test("hexadecimal TN echo is case insensitive in both collectors", async () => {
    const frame = "\x1bP1+r544E=787465726D\x1b\\"
    const probe = callback("device.xtgettcap")
    expect(probe.headless(headless(frame)).observation).toMatchObject({ outcome: "supported" })
    expect((await probe.terminal(terminal(frame))).observation).toMatchObject({ outcome: "supported" })
  })

  test("an inherited TERM_FEATURES value is an unverified hint and is never copied into raw evidence", async () => {
    const prior = process.env.TERM_FEATURES
    try {
      process.env.TERM_FEATURES = "sensitive-arbitrary-environment-value"
      const definition = deviceProbes.find((item) => item.id === "device.term-features")
      if (!definition?.term) throw new Error("missing TERM_FEATURES callback")
      const result = await definition.term(terminal(""))
      expect(result.observation).toBeUndefined()
      expect(
        recordExecutedProbe({
          featureId: definition.id,
          attempt: { scope: "probe", startedAt: "2026-10-21T05:00:00.000Z" },
          assertions: [],
          tests: result.tests,
        }).status,
      ).toBe("probe-invalid")
      expect(JSON.stringify(result)).not.toContain(process.env.TERM_FEATURES)
      expect(result.assertions).toBeUndefined()
    } finally {
      if (prior === undefined) delete process.env.TERM_FEATURES
      else process.env.TERM_FEATURES = prior
    }
  })

  // 32569: inside a mux, absence with this run's marker seen is Unsupported as on a bare App; presence may come from
  // the outer terminal, so it stays PROBE TODO naming the outer and retains no value (@cto ruling 2026-11-06).
  test.each([{ present: false }, { present: true }])(
    "inside screen, TERM_FEATURES present=$present",
    async ({ present }) => {
      const definition = deviceProbes.find((item) => item.id === "device.term-features")
      if (!definition?.term) throw new Error("missing TERM_FEATURES callback")
      const reading = {
        status: "measured" as const,
        present,
        value: present ? "outer-terminal-value" : "",
        runId: "e".repeat(32),
        launchMarker: "e".repeat(32),
        pid: 42,
        tty: "tty_nr=34816;fd=1;rdev=34816",
        mux: "screen" as const,
      }
      const result = await definition.term({ readTermFeatures: async () => reading } as unknown as TermProbeSource)
      if (present) {
        expect(result.observation).toBeUndefined()
        expect(result.notTested?.noObservable).toBe(
          "TERM_FEATURES present inside screen; it may come from the outer terminal, and presence cannot be attributed without an authenticated source",
        )
        expect(JSON.stringify(result)).not.toContain("outer-terminal-value")
      } else {
        expect(result.observation).toMatchObject({ outcome: "unsupported", assertionType: "process_environment" })
        expect(result.assertions).toMatchObject([{ kind: "negative", observed: "absent" }])
      }
    },
  )
})

/**
 * @failure Window operations accepted incomplete replies and later DA1 responsiveness as feature support.
 * @level l0
 * @consumer App and headless window-operation observations.
 * @testonly none
 */
describe("window-operation qualification", () => {
  test("XTWINOPS 14 queries text-area pixels and binds a complete size frame in both collectors", async () => {
    const probe = callback("device.xtwinops-14")
    const frame = "\x1b[4;720;1280t"
    const app = {
      queryWithSentinelOutcome: async (query: string, pattern: RegExp) => {
        expect(query).toBe("\x1b[14t")
        return {
          match: pattern.exec(frame),
          reason: "reply",
          raw: frame,
          rawBase64: Buffer.from(frame).toString("base64"),
        }
      },
    } as unknown as TermProbeSource
    const lib = {
      feedCapture: (query: string) => {
        expect(query).toBe("\x1b[14t")
        return frame
      },
    } as unknown as LibProbeSource
    for (const result of [probe.headless(lib), await probe.terminal(app)]) {
      expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
      expect(result.assertions).toMatchObject([{ kind: "positive", observed: frame }])
      expect(result.response).toBe(frame)
    }
    expect(probe.headless(headless("\x1b[4;720;1280")).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "invalid-reply",
    })
  })

  test("device.xtwinops-20: a complete OSC L answer with the wrong payload is a measured negative", async () => {
    const icon = callback("device.xtwinops-20")
    const headlessIcon = (frame: string): LibProbeSource =>
      ({ feed: () => undefined, feedCapture: () => frame }) as unknown as LibProbeSource
    const app = (frame: string, reason: TerminalQueryOutcome["reason"] = "reply"): TermProbeSource =>
      ({
        write: () => undefined,
        queryWithSentinelOutcome: (sequence: string, pattern: RegExp) =>
          Promise.resolve({
            match: reason === "reply" ? pattern.exec(frame) : null,
            reason,
            raw: frame,
            rawBase64: Buffer.from(frame).toString("base64"),
          }),
      }) as unknown as TermProbeSource
    for (const frame of ["\x1b]L\x1b\\", "\x1b]Lother-icon\x07", "\x1b]Ltest-icon-plus\x1b\\"]) {
      const head = icon.headless(headlessIcon(frame))
      expect(head.observation).toMatchObject({ outcome: "unsupported", assertionType: "query_reply" })
      expect(head.assertions).toMatchObject([{ kind: "negative", observed: frame }])
      const live = await icon.terminal(app(frame))
      expect(live.observation).toMatchObject({ outcome: "unsupported", assertionType: "query_reply" })
      expect(live.assertions).toMatchObject([{ kind: "negative", observed: frame }])
    }
    // A frame with no terminator is still not a complete answer.
    expect(icon.headless(headlessIcon("\x1b]L")).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "invalid-reply",
    })
    // The exact label stays a positive.
    expect(icon.headless(headlessIcon("\x1b]Ltest-icon\x1b\\")).observation).toMatchObject({
      outcome: "supported",
      assertionType: "query_reply",
    })
    // A complete OSC L frame after the DA1 sentinel is late output, not an answer.
    const late = "\x1b[?62;52;c\x1b]Lwrong\x1b\\"
    expect(icon.headless(headlessIcon(late)).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "no-response",
    })
    expect((await icon.terminal(app(late, "sentinel"))).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "no-response",
    })
    // Unrelated OSC answers (colour, clipboard) never satisfy the icon-label query.
    for (const frame of ["\x1b]4;1;rgb:00/00/00\x07", "\x1b]52;c;Zm9v\x07"]) {
      expect(icon.headless(headlessIcon(frame)).observation).toMatchObject({
        outcome: "inconclusive",
        reason: "no-response",
      })
      expect((await icon.terminal(app(frame))).observation).toMatchObject({
        outcome: "inconclusive",
        reason: "no-response",
      })
    }
  })

  test("a different icon label and DA1 fallback cannot prove XTWINOPS", () => {
    const icon = callback("device.xtwinops-20")
    const headlessIcon = {
      feed: () => undefined,
      feedCapture: () => "\x1b]Lother-icon\x07",
    } as unknown as LibProbeSource
    expect(icon.headless(headlessIcon).observation?.outcome).not.toBe("supported")
  })

  // A title setup that reads back wrong decides neither operation: no observation, the headless observable review.
  const UNOBSERVABLE_TITLE_SETUP = {
    note: "Open: this test first sets a window title, then tests whether the command under test changes it. We could not read the first title back",
    notTested: {
      reason: "no-semantic-observable",
      noObservable:
        "Open: this test first sets a window title, then tests whether the command under test changes it. We could not read the first title back",
    },
    criterionBranch: "headless-observable-review",
    tests: [
      {
        id: "review",
        status: "probe-todo",
        reason:
          "Open: this test first sets a window title, then tests whether the command under test changes it. We could not read the first title back, so this run cannot decide it",
      },
    ],
  }

  // #32282 AC1/2: model actual title writes and stack effects, rather than three canned reads.
  // The old fixture passes a stale snapshot as PUSH support and leaves its title behind.
  function titleContext(behavior: "working" | "stale" | "none" | "unobservable") {
    let title = "incoming-title"
    let firstSaved: string | undefined
    const stack: string[] = []
    const ctx = {
      feed: (sequence: string) => {
        const set = /^\x1b\]2;([^\x07]*)\x07$/.exec(sequence)
        if (set && behavior !== "unobservable") title = set[1]!
        if (sequence === "\x1b[22;0t" && behavior !== "none" && behavior !== "unobservable") {
          firstSaved ??= title
          stack.push(behavior === "stale" ? firstSaved : title)
        }
        if (sequence === "\x1b[23;0t" && stack.length) title = stack.pop()!
      },
      getTitle: () => (behavior === "unobservable" ? "" : title),
    } as unknown as LibProbeSource
    return { ctx, title: () => title, depth: () => stack.length }
  }

  test.each(["working", "stale", "none", "unobservable"] as const)(
    "App title stack reads its owned state and restores it: %s",
    async (behavior) => {
      // #32573: the library fixture models title/stack state; the App callback must actually read it.
      // Existing library-only cases cannot catch an App arm that merely receives a cursor reply.
      for (const id of ["device.xtwinops-22", "device.xtwinops-23"]) {
        const fixture = titleContext(behavior)
        const source = {
          write: fixture.ctx.feed,
          readTitle: async () => fixture.ctx.getTitle(),
          queryCursorPosition: async () => ({ row: 1, col: 1 }),
        } as unknown as TermProbeSource
        const result = await callback(id).terminal(source)
        if (behavior === "unobservable") {
          expect(result.observation).toBeUndefined()
          expect(result.tests).toContainEqual(expect.objectContaining({ status: "probe-invalid" }))
        } else {
          expect(result.observation).toMatchObject({
            assertionType: "buffer_state",
            outcome: behavior === "working" ? "supported" : "unsupported",
          })
          expect(fixture.title()).toBe("incoming-title")
        }
        expect(fixture.depth()).toBe(0)
      }
    },
  )

  test.each(["working", "stale", "none", "unobservable"] as const)(
    "title stack measures the controlled joint round trip and cleans up: %s",
    (behavior) => {
      for (const id of ["device.xtwinops-22", "device.xtwinops-23"]) {
        const fixture = titleContext(behavior)
        const result = callback(id).headless(fixture.ctx)
        const observed = JSON.parse(result.response!)
        expect(observed).toMatchObject({ before: behavior === "unobservable" ? "" : "incoming-title" })
        if (behavior !== "unobservable") {
          expect(observed).toMatchObject({
            popFixture: {
              original: "pushed-title",
              changed: "new-title",
              restored: behavior === "none" ? "new-title" : "pushed-title",
            },
            pushFixture: {
              original: "new-title",
              changed: "next-title",
              restored: behavior === "none" ? "next-title" : behavior === "stale" ? "pushed-title" : "new-title",
            },
          })
        }
        if (behavior === "unobservable") expect(result).toMatchObject(UNOBSERVABLE_TITLE_SETUP)
        else {
          const outcome = behavior === "working" ? "supported" : "unsupported"
          expect(result.observation).toMatchObject({ outcome, assertionType: "buffer_state" })
        }
        if (behavior !== "unobservable") expect(fixture.title()).toBe("incoming-title")
        expect(fixture.depth()).toBe(0)
      }
    },
  )

  test("title-stack fixtures restore the incoming title and checkpoint when a read throws", () => {
    for (const id of ["device.xtwinops-22", "device.xtwinops-23"]) {
      const fixture = titleContext("working")
      const read = fixture.ctx.getTitle.bind(fixture.ctx)
      let reads = 0
      const failure = new Error("title read failed after push")
      fixture.ctx.getTitle = () => {
        if (++reads === 3) throw failure
        return read()
      }
      expect(() => callback(id).headless(fixture.ctx)).toThrow(failure)
      expect(fixture.title()).toBe("incoming-title")
      expect(fixture.depth()).toBe(0)
    }
  })

  test("App title-stack fixtures restore their title and checkpoint after a read error", async () => {
    for (const id of ["device.xtwinops-22", "device.xtwinops-23"]) {
      const fixture = titleContext("working")
      let reads = 0
      const source = {
        write: fixture.ctx.feed,
        readTitle: async () => {
          if (++reads === 3) throw new Error("injected App title read error")
          return fixture.ctx.getTitle()
        },
      } as unknown as TermProbeSource
      await expect(callback(id).terminal(source)).rejects.toThrow("injected App title read error")
      expect(fixture.title()).toBe("incoming-title")
      expect(fixture.depth()).toBe(0)
    }
  })

  /**
   * @failure A terminal that shows the icon title (OSC 1) in preference to the OSC 2 title hid every
   *   title control once device.xtwinops-20 left "test-icon" set: both title-stack rows read
   *   "Owned title reader failed the OSC 2 controls" on WezTerm, whatever the push/pop behaviour
   *   (#33035). xtwinops-20 now clears what it set, and the fixture clears any icon title before
   *   its controls, so the controls read and push/pop are decided against them (@cto e9641d54).
   * @level l1
   * @consumer device.xtwinops-20/22/23 App callbacks on an icon-preferring title surface.
   * @testonly none
   */
  test("an icon title never hides the title-stack controls", async () => {
    const surface = () => {
      let title = "incoming-title"
      let icon: string | undefined
      const source = {
        write(bytes: string) {
          for (const [, code, text] of bytes.matchAll(/\x1b\](\d+);([^\x07]*)\x07/g)) {
            if (code === "1") icon = text === "" ? undefined : text
            else if (code === "2") title = text ?? ""
            else if (code === "0") {
              title = text ?? ""
              icon = undefined
            }
          }
          // XTWINOPS 22/23 are ignored: this surface keeps no title stack.
        },
        readTitle: async () => icon ?? title,
        queryWithSentinelOutcome: async () => ({ match: null, reason: "timeout", raw: "", rawBase64: "" }),
      } as unknown as TermProbeSource
      return { source, icon: () => icon, title: () => title }
    }
    // In probe order: xtwinops-20 leaves no icon title behind.
    const ordered = surface()
    await callback("device.xtwinops-20").terminal(ordered.source)
    expect(ordered.icon()).toBeUndefined()
    // Out of order: an icon title left by anything else is cleared by the fixture itself.
    for (const id of ["device.xtwinops-22", "device.xtwinops-23"]) {
      const leaked = surface()
      leaked.source.write("\x1b]1;test-icon\x07")
      const result = await callback(id).terminal(leaked.source)
      expect(result.criterionBranch, id).not.toBe("app-title-control")
      expect(result.observation?.outcome, id).toBe("unsupported")
      expect(leaked.title(), id).toBe("test-icon")
    }
  })

  // #32323: only the controlled round-trip effect decides, independent of any source/artifact identity.
  // Failed restoration is a joint negative; it never identifies which stack primitive is missing.
  test.each([
    [
      "formerly audited WASM artifact",
      {
        kind: "js",
        runtimeFormat: "wasm",
        engineVersion: "0.4.0",
        adapterVersion: "0.4.0",
        termlessRevision: "0".repeat(40),
        resolvedPath: "fixture.js",
        integrity: { kind: "registry", lockIntegrity: "sha512-fixture" },
        loadedBinary: {
          path: "fixture.wasm",
          sha256: "712298aff45c7c53a22dc028b13cb58dae1e984199b520bbbc0475ae64d83159",
        },
      },
    ],
    [
      "formerly audited JS source tree",
      {
        kind: "js",
        runtimeFormat: "js",
        engineVersion: "0.10.1",
        adapterVersion: "0.10.2",
        termlessRevision: "d5e6248bfb080c3065f81b78c45bdfe1b37c06d6",
        resolvedPath: "vendor/vterm/packages/vt100/src/index.ts",
        integrity: {
          kind: "source",
          repository: "git@github.com:beorn/vterm.git",
          revision: "9e99e4d23cdc606fca258b1863aa2be7ae79eed3",
          treeOid: "b941dae48b25ae8825c394750bda5245c9d93dfa",
          cleanTree: true,
        },
      },
    ],
    ["no runtime identity", undefined],
  ] as const)("title-stack on a %s is never graded from source", (_name, runtimeIdentity) => {
    for (const id of ["device.xtwinops-22", "device.xtwinops-23"] as const) {
      const makeCtx = (behavior: Parameters<typeof titleContext>[0]): LibProbeSource => ({
        ...titleContext(behavior).ctx,
        runtimeIdentity,
      })
      const negative = callback(id).headless(makeCtx("none"))
      expect(negative.observation).toMatchObject({ outcome: "unsupported", assertionType: "buffer_state" })
      expect(negative.assertions).toContainEqual(expect.objectContaining({ kind: "negative" }))
      expect(negative.note).toBe("push/pop round trip does not restore")
      expect(JSON.parse(negative.response!)).toMatchObject({
        before: "incoming-title",
        popFixture: { original: "pushed-title", changed: "new-title", restored: "new-title" },
        pushFixture: { original: "new-title", changed: "next-title", restored: "next-title" },
      })

      const positive = callback(id).headless(makeCtx("working"))
      expect(positive.observation).toMatchObject({ outcome: "supported", assertionType: "buffer_state" })

      const unobservable = callback(id).headless(makeCtx("unobservable"))
      expect(unobservable).toMatchObject(UNOBSERVABLE_TITLE_SETUP)
      expect(unobservable.observation).toBeUndefined()
    }
  })
})

/**
 * @failure XTWINOPS 16/21, XTREPORTCOLORS and XTGETXRES had no test binding their own frame, so a wrong or absent reply could have been read as support.
 * @level l0
 * @consumer App and headless device-query observations for the reply-decided feature set.
 * @testonly none
 */
describe("device contracts without prior coverage", () => {
  const app = (raw: string, reason: TerminalQueryOutcome["reason"] = "reply"): TermProbeSource =>
    ({
      write: () => undefined,
      queryWithSentinelOutcome: async (_sequence: string, pattern: RegExp) =>
        Promise.resolve({
          match: reason === "reply" ? pattern.exec(raw) : null,
          reason,
          raw,
          rawBase64: Buffer.from(raw).toString("base64"),
        }),
    }) as unknown as TermProbeSource

  test("XTWINOPS 16 binds a complete cell-pixel frame in both collectors", async () => {
    const probe = callback("device.xtwinops-16")
    const frame = "\x1b[6;16;8t"
    for (const result of [probe.headless(headless(frame)), await probe.terminal(app(frame))]) {
      expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
      expect(result.assertions).toMatchObject([{ kind: "positive", observed: frame }])
      expect(result.response).toBe(frame)
    }
    // A truncated frame is malformed, an unrelated window-op answer is no answer at all.
    expect(probe.headless(headless("\x1b[6;16;8")).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "invalid-reply",
    })
    expect(probe.headless(headless("\x1b[4;720;1280t")).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "no-response",
    })
  })

  test("XTREPORTCOLORS binds a complete palette-stack entry and count frame", async () => {
    const probe = callback("device.xtreportcolors")
    const frame = "\x1b[0;1#Q"
    for (const result of [probe.headless(headless(frame)), await probe.terminal(app(frame))]) {
      expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
      expect(result.assertions).toMatchObject([{ kind: "positive", observed: frame }])
    }
    expect(probe.headless(headless("\x1b[0;1#")).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "invalid-reply",
    })
    expect(probe.headless(headless("\x1b[?62;52;c")).observation).toMatchObject({
      outcome: "inconclusive",
      reason: "no-response",
    })
  })

  test.each(["", "0", ";1", "0;", "0;1;2", "0;x"])(
    "XTREPORTCOLORS keeps malformed palette-stack fields %j inconclusive in both collectors",
    async (fields) => {
      const probe = callback("device.xtreportcolors")
      const raw = `\x1b[${fields}#Q`
      for (const result of [probe.headless(headless(raw)), await probe.terminal(app(raw))]) {
        expect(result.observation).toMatchObject({ outcome: "inconclusive", reason: "invalid-reply" })
        expect(result.assertions).toBeUndefined()
        expect(result.response).toBe(raw)
      }
    },
  )

  test("XTGETXRES binds a status-1 termName value and reads status 0 as a refusal", async () => {
    const probe = callback("device.xtgetxres")
    const frame = "\x1bP1+r7465726d4e616d65=787465726d\x1b\\"
    for (const result of [probe.headless(headless(frame)), await probe.terminal(app(frame))]) {
      expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
      expect(result.assertions).toMatchObject([{ kind: "positive", observed: frame }])
    }
    // The contract asks exactly one name, so a status-0 refusal is this probe's measured negative
    // (27914) — unlike the shared refusal branch, which stays inconclusive for multi-subject probes.
    const refusal = "\x1bP0+r7465726d4e616d65\x1b\\"
    for (const result of [probe.headless(headless(refusal)), await probe.terminal(app(refusal))]) {
      expect(result.observation).toMatchObject({ outcome: "unsupported", assertionType: "query_reply" })
      expect(result.assertions).toMatchObject([{ kind: "negative", observed: refusal }])
    }
    // XTGETXRES encodes two hex digits per character: missing ST, empty and odd-length values are malformed.
    for (const raw of [
      "\x1bP1+r7465726d4e616d65",
      "\x1bP1+r7465726d4e616d65=\x1b\\",
      "\x1bP1+R7465726d4e616d65=7\x1b\\",
      "\x1bP1+r7465726d4e616d65=787\x1b\\",
    ]) {
      for (const result of [probe.headless(headless(raw)), await probe.terminal(app(raw))]) {
        expect(result.observation).toMatchObject({ outcome: "inconclusive", reason: "invalid-reply" })
        expect(result.assertions).toBeUndefined()
      }
    }
  })

  test("XTWINOPS 21 sets its own title and binds the reported title to that exact frame", async () => {
    const probe = callback("device.xtwinops-21")
    const frame = "\x1b]ltest-title\x07"
    const writes: string[] = []
    const context = {
      write: (sequence: string) => {
        writes.push(sequence)
      },
      queryWithSentinelOutcome: async (sequence: string, pattern: RegExp) => {
        writes.push(sequence)
        return {
          match: pattern.exec(frame),
          reason: "reply" as const,
          raw: frame,
          rawBase64: Buffer.from(frame).toString("base64"),
        }
      },
    } as unknown as TermProbeSource
    const result = await probe.terminal(context)
    // The probe owns its setup: it sets the title it then requires.
    expect(writes).toEqual(["\x1b]2;test-title\x07", "\x1b[21t"])
    expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
    expect(result.assertions).toMatchObject([{ kind: "positive", observed: frame }])
    const feeds: string[] = []
    const headlessResult = probe.headless({
      feed: (sequence: string) => {
        feeds.push(sequence)
      },
      feedCapture: () => frame,
    } as unknown as LibProbeSource)
    expect(feeds).toEqual(["\x1b]2;test-title\x07"])
    expect(headlessResult.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
    // A complete answer with a different title contradicts the exact-title criterion.
    const other = probe.headless({
      feed: () => undefined,
      feedCapture: () => "\x1b]lother-title\x07",
    } as unknown as LibProbeSource)
    expect(other.observation).toMatchObject({ outcome: "unsupported", assertionType: "query_reply" })
    expect(other.assertions).toMatchObject([{ kind: "negative", observed: "\x1b]lother-title\x07" }])
  })

  test.each(["app", "lib-query", "lib-capture"] as const)(
    "XTWINOPS 21 %s distinguishes complete title answers from incomplete, unrelated and late output",
    async (route) => {
      const probe = callback("device.xtwinops-21")
      const run = async (raw: string, reason: TerminalQueryOutcome["reason"] = "reply") => {
        const script = terminalScript({ "\x1b[21t": { raw, reason } })
        if (route === "app") {
          return probe.terminal({ ...script.ctx, write: () => undefined })
        }
        if (route === "lib-query") {
          return probe.headless({ ...script.lib, feed: () => undefined })
        }
        return probe.headless({ feed: () => undefined, feedCapture: () => raw } as unknown as LibProbeSource)
      }
      for (const terminator of ["\x07", "\x1b\\"]) {
        for (const payload of ["", "other-title", "test-title-plus"]) {
          const frame = `\x1b]l${payload}${terminator}`
          const result = await run(frame)
          expect(result.observation).toMatchObject({ outcome: "unsupported", assertionType: "query_reply" })
          expect(result.assertions).toMatchObject([{ kind: "negative", observed: frame }])
          expect(result.response).toBe(frame)
        }
        const frame = `\x1b]ltest-title${terminator}`
        const result = await run(frame)
        expect(result.observation).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
        expect(result.assertions).toMatchObject([{ kind: "positive", observed: frame }])
      }
      for (const raw of ["\x1b]l", "\x1b]lother-title", "\x1b]lother-title\x1b]4;1;rgb:00/00/00\x07"]) {
        const result = await run(raw)
        expect(result.observation).toMatchObject({ outcome: "inconclusive", reason: "invalid-reply" })
        expect(result.assertions).toBeUndefined()
      }
      for (const raw of ["\x1b]Lother-icon\x07", "\x1b]52;c;Zm9v\x07"]) {
        const result = await run(raw)
        expect(result.observation).toMatchObject({ outcome: "inconclusive", reason: "no-response" })
        expect(result.assertions).toBeUndefined()
      }
      const late = await run("\x1b[?62;52;c\x1b]lother-title\x07", "sentinel")
      expect(late.observation).toMatchObject({ outcome: "inconclusive", reason: "no-response" })
      expect(late.assertions).toBeUndefined()
    },
  )

  // 27914: xterm's XTREPORTCOLORS reply carries a DEC-private `?` the documented
  // CSI Pm # Q form does not show (measured: CSI ? 0 ; 1 # Q on xterm 411, while
  // kitty answers CSI 0 ; 0 # Q). The reference implementation's frame is support.
  test("XTREPORTCOLORS accepts the reference implementation's DEC-private reply", async () => {
    const probe = callback("device.xtreportcolors")
    const app = (frame: string) =>
      probe.terminal({
        queryOutcome: async (_sequence: string, pattern: RegExp) =>
          Promise.resolve({
            match: pattern.exec(frame),
            reason: "reply",
            raw: frame,
            rawBase64: Buffer.from(frame).toString("base64"),
          }),
        queryWithSentinelOutcome: async (_sequence: string, pattern: RegExp) =>
          Promise.resolve({
            match: pattern.exec(frame),
            reason: "reply",
            raw: frame,
            rawBase64: Buffer.from(frame).toString("base64"),
          }),
      } as unknown as TermProbeSource)
    for (const frame of ["\x1b[?0;1#Q", "\x1b[0;0#Q"]) {
      for (const result of [probe.headless(headless(frame)), await app(frame)]) {
        expect(result.response, frame).toBe(frame)
        expect(result.observation, frame).toMatchObject({ outcome: "supported", assertionType: "query_reply" })
        expect(result.assertions, frame).toMatchObject([{ kind: "positive", observed: frame }])
      }
    }
    const truncated = probe.headless(headless("\x1b[?0;1#"))
    expect(truncated.observation).toMatchObject({ outcome: "inconclusive", reason: "invalid-reply" })
    expect(truncated.assertions).toBeUndefined()
  })
})

// Actual run388fa7b54f74bfe5d9bfbecef7e4d924, vterm source53a9eb9/tree617ae60: no font/window geometry.
// It stays PROBE TODO, never automatic Untestable and never graded from source (#32246).
const geometryRuntime = {
  kind: "js",
  adapterVersion: "0.10.2",
  termlessRevision: "a871f0e580e1b02fb5dbb7ed854f6de623e7858e",
  resolvedPath: "vendor/vterm/packages/vterm/src/index.ts",
  integrity: {
    kind: "source",
    repository: "git@github.com:beorn/vterm.git",
    revision: "67dd3960746766ed47e2bb4b2ced6503a78549cc",
    treeOid: "e9d67d4b4ba7cb4caf0d0824b3b272c10e4b229e",
    cleanTree: true,
  },
  runtimeFormat: "js",
  engineVersion: "0.10.1",
} as const
const geometryReplies = [
  {
    id: "device.xtwinops-14",
    raw: "\u001b[4;0;0t\u001b[?62;4c",
    positive: "\u001b[4;384;640t",
  },
  {
    id: "device.xtwinops-16",
    raw: "\u001b[6;0;0t\u001b[?62;4c",
    positive: "\u001b[6;16;8t",
  },
] as const

// #32246 (operator 2026-11-03): the vterm source-tree geometry audit is gone. A complete zero geometry reply has no
// same-path control in this run, so it is PROBE TODO on every identity; it is never graded from source.
test.each(geometryReplies)(
  "$id keeps a complete zero geometry reply PROBE TODO on any identity",
  ({ id, raw, positive }) => {
    const identities = [
      undefined,
      geometryRuntime,
      { ...geometryRuntime, resolvedPath: "foreign/index.ts" },
      { ...geometryRuntime, runtimeFormat: "wasm" },
      ...[{ cleanTree: false }, { revision: "foreign" }, { treeOid: "f".repeat(40) }, { repository: "foreign" }].map(
        (change) => ({ ...geometryRuntime, integrity: { ...geometryRuntime.integrity, ...change } }),
      ),
    ]
    for (const runtimeIdentity of identities) {
      for (const sentinel of [false, true]) {
        const ctx = {
          feedCapture: () => raw,
          runtimeIdentity,
          ...(sentinel && {
            queryWithSentinelOutcome: () => ({
              raw,
              rawBase64: Buffer.from(raw).toString("base64"),
              reason: "sentinel",
              match: null,
            }),
          }),
        } as unknown as LibProbeSource
        const result = callback(id).headless(ctx)
        expect(result.notTested).toEqual({
          reason: "no-semantic-observable",
          noObservable:
            "Open: no control in this run showed that our test can read this feature, so the observations do not decide the result.",
        })
        expect(result.observation).toBeUndefined()
        expect(result.assertions).toBeUndefined()
        expect(result.tests).toBeUndefined()
        expect(result.criterionBranch).toBeUndefined()
        const state = JSON.parse(result.response!)
        expect(state).toMatchObject({ raw })
        expect(state).not.toHaveProperty("sourceCitation")
        expect(state).not.toHaveProperty("runtimeIdentity")
      }
    }
    // Only the complete zero frame takes this record; a partial or foreign reply keeps its measured reading.
    // Silence is PROBE TODO for lack of a control (@cto batch7 A-F4); a partial or foreign reply keeps its reading.
    const silent = { feedCapture: () => "", runtimeIdentity: geometryRuntime } as unknown as LibProbeSource
    expect(callback(id).headless(silent).notTested?.noObservable).toBe(
      "Open: no control in this run showed that our test can read this feature, so the observations do not decide the result.",
    )
    for (const reply of [raw.slice(0, 4), "foreign", raw + "foreign", "foreign" + raw]) {
      const ctx = { feedCapture: () => reply, runtimeIdentity: geometryRuntime } as unknown as LibProbeSource
      expect(callback(id).headless(ctx).notTested).toBeUndefined()
    }
    const ctx = { feedCapture: () => positive, runtimeIdentity: geometryRuntime } as unknown as LibProbeSource
    expect(callback(id).headless(ctx).observation?.outcome).toBe("supported")
  },
)

// #32476 (NC-R3b): on the audited vterm 0.13.1 engine identity, complete 4;0;0 and 6;0;0 replies with a same-run DA1
// control grade unsupported; without the DA1 control or at a drifted identity they remain PROBE TODO.
test.each(geometryReplies)(
  "$id grades vterm 0.13.1 zero geometry reply with same-run DA1 control unsupported",
  ({ id, raw }) => {
    const vterm0131Runtime = {
      ...geometryRuntime,
      engineVersion: "0.13.1",
      integrity: {
        ...geometryRuntime.integrity,
        revision: "7b39f49e8a6bc03ce695c5ab7c143c2cc7379eb0",
        treeOid: "3d58d29a8265aafd928e0736dde6723e2bac2007",
        cleanTree: true,
      },
    } as const
    for (const sentinel of [false, true]) {
      const ctx = {
        backendName: "vterm",
        feedCapture: () => raw,
        runtimeIdentity: vterm0131Runtime,
        ...(sentinel && {
          queryWithSentinelOutcome: () => ({
            raw,
            rawBase64: Buffer.from(raw).toString("base64"),
            reason: "sentinel",
            match: null,
          }),
        }),
      } as unknown as LibProbeSource
      const result = callback(id).headless(ctx)
      expect(result.pass).toBe(false)
      expect(result.notTested).toBeUndefined()
      expect(result.observation).toMatchObject({ outcome: "unsupported", assertionType: "query_reply" })
      expect(result.assertions).toMatchObject([{ assertionType: "query_reply", kind: "negative", observed: raw }])
    }
    const withoutDa1 = raw.replace(/\x1b\[\?[0-9;]+c$/, "")
    const noControl = callback(id).headless({
      backendName: "vterm",
      feedCapture: () => withoutDa1,
      runtimeIdentity: vterm0131Runtime,
    } as unknown as LibProbeSource)
    expect(noControl.notTested?.reason).toBe("no-semantic-observable")
    expect(noControl.observation).toBeUndefined()
  },
)
