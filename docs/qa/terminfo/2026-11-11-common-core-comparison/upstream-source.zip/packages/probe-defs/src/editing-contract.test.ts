/**
 * @failure An Editing feature is graded without a bound contract row, or a re-grade of a decided
 *   observation moves it - so the Editing group reinvents its own fixture and silently drifts.
 * @level l2
 * @consumer 28018 candidate-2 Editing group (child 28022); the 28453 harness's fourth adopter.
 * @reach fs-walk vendor/terminfo.dev/packages/probe-defs/src/editing-contract.test.ts vendor/terminfo.dev/packages/probe-defs/src/editing-observations.test.ts vendor/terminfo.dev/packages/probe-defs/src/editing-batch2-captures.test.ts vendor/terminfo.dev/packages/probe-defs/src/editing-geometry.test.ts vendor/terminfo.dev/packages/probe-defs/src/testing/group-harness.ts vendor/terminfo.dev/packages/probe-defs/src/testing/semantic-surface.ts
 * @testonly none
 */
import { expect, test } from "vitest"
import { join } from "node:path"
import { editingProbes } from "./editing.ts"
import {
  contractGaps,
  inertLibProbeSource,
  gradedOutcome,
  libProbeSource,
  missingContractTests,
  regradeCommand,
  regradeRow,
  satisfiesContract,
  type GroupContract,
  type GroupContractSpec,
} from "./testing/group-harness.ts"
import { createSemanticSurface } from "./testing/semantic-surface.ts"

/**
 * The 17 Editing features of 28018's Editing row; ids drawn from editing.ts, claims are the
 * contract. `editing.decsace` measures attribute-change extent by differential: DECSACE 2 confines
 * the same DECCARA to its rectangle, DECSACE 0 reaches the rest of the reading-order span.
 */
const EDITING_CONTRACT: GroupContract = [
  { id: "editing.insert-chars", expected: "decided", claim: "ICH inserts a blank at column 3, shifting text right" },
  { id: "editing.delete-chars", expected: "decided", claim: "DCH deletes column 3, shifting text left" },
  { id: "editing.insert-lines", expected: "decided", claim: "IL inserts a blank row 2, shifting rows down" },
  { id: "editing.delete-lines", expected: "decided", claim: "DL removes row 2, shifting rows up" },
  { id: "editing.repeat-char", expected: "decided", claim: "REP repeats the preceding X into three cells" },
  { id: "editing.decfra", expected: "decided", claim: "DECFRA fills the 3x5 measured area with X" },
  { id: "editing.decera", expected: "decided", claim: "DECERA blanks the measured 3x5 cells" },
  { id: "editing.decsera", expected: "decided", claim: "DECSERA clears ABCD but spares the protected P" },
  { id: "editing.deccra", expected: "decided", claim: "DECCRA copies the 2x5 source to row 5 column 10" },
  { id: "editing.deccara", expected: "decided", claim: "DECCARA sets inverse on the measured 3x5 cells" },
  { id: "editing.decrara", expected: "decided", claim: "DECRARA clears inverse on the measured 3x5 cells" },
  {
    id: "editing.decsace",
    expected: "decided",
    claim: "DECSACE rectangle extent confines DECCARA to the 2x2 block, stream extent reaches the rest of the span",
  },
  {
    id: "editing.decrqcra",
    expected: "decided",
    claim:
      "DECRQCRA changes the same rectangle checksum by 1 under the DEC-compatible negated or positive-checksum convention when its last cell changes from E to F",
  },
  { id: "editing.sl", expected: "decided", claim: "SL shifts the measured cells of two rows left by two columns" },
  { id: "editing.sr", expected: "decided", claim: "SR shifts the measured cells of two rows right by two columns" },
  { id: "editing.decic", expected: "decided", claim: "DECIC inserts two blank columns at column 3" },
  { id: "editing.decdc", expected: "decided", claim: "DECDC deletes two columns at column 3" },
]

/** The named set 28454 reviews: Editing's rows plus the focused test files that bind them (no glob). */
const EDITING_CONTRACT_SPEC: GroupContractSpec = {
  group: "editing",
  rows: EDITING_CONTRACT,
  tests: [
    "packages/probe-defs/src/editing-contract.test.ts",
    "packages/probe-defs/src/editing-observations.test.ts",
    "packages/probe-defs/src/editing-batch2-captures.test.ts",
    "packages/probe-defs/src/editing-geometry.test.ts",
  ],
}

test("the Editing contract covers every editing feature and names none unknown", () => {
  const gaps = contractGaps(editingProbes, EDITING_CONTRACT)
  expect(gaps.uncovered).toEqual([])
  expect(gaps.unknown).toEqual([])
  expect(gaps.misdeclared).toEqual([])
  expect(editingProbes).toHaveLength(17)
  expect(EDITING_CONTRACT).toHaveLength(17)
})

test("the Editing contract names its focused tests, and every named file exists", () => {
  const root = join(import.meta.dirname, "../../..")
  expect(missingContractTests(EDITING_CONTRACT_SPEC, root)).toEqual([])
  const command = regradeCommand(EDITING_CONTRACT_SPEC)
  expect(command).toContain("bunx --bun vitest run")
  expect(command).not.toContain("bun test")
  expect(command).not.toMatch(/[*?]/u)
  for (const path of EDITING_CONTRACT_SPEC.tests) expect(command).toContain(path)
})

/**
 * probeStatus derives from these declarations rather than from the catalog. A hand-written row whose
 * arms both measure but declare nothing cannot derive: it inherits a reviewed partial and keeps
 * reading partial after the measurement lands. DECSACE grades exact cells on the parser arm and
 * extent separation on the terminal arm, so both kinds belong here by name.
 */
test("editing.decsace declares the measuring evidence kind of both its arms", () => {
  const probe = editingProbes.find((entry) => entry.id === "editing.decsace")
  expect(probe?.termAssertionType).toBe("screenshot")
  expect(probe?.libAssertionType).toBe("buffer_state")
})

// Determinism only: the surface is fed the same fixture twice, so this proves the harness replays
// without movement, NOT that a decided row is satisfied. The satisfaction binding is the table below.
test("the harness replays every editing feature deterministically", async () => {
  for (const row of EDITING_CONTRACT) {
    const probe = editingProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing editing probe ${row.id}`).toBeDefined()
    if (!probe) continue
    expect(probe.lib !== null || probe.term !== null, `${row.id} has no callback`).toBe(true)
    const first = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    const second = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    expect(second.after, `${row.id} is not deterministic`).toBe(first.after)
    expect(second.satisfies, `${row.id} satisfaction is not deterministic`).toBe(first.satisfies)
    expect(first.satisfies, `${row.id} must route through satisfiesContract`).toBe(satisfiesContract(row, first.after))
  }
})

// The bound satisfaction proof: each decided row reads "supported" against a surface that really
// performs its edit - ICH/DCH, IL/DL, REP, the VT420 rectangle ops (DECFRA/DECERA/DECSERA/DECCRA/
// DECCARA/DECRARA), the DECSACE extent differential, a framed DECRQCRA reply, the screen-wide SL/SR
// shift and the column DECIC/DECDC. A probe whose own expectation disagrees with the terminal cannot
// pass this test.
test("every editing contract row reads its declared outcome against a surface that implements its claim", async () => {
  for (const row of EDITING_CONTRACT) {
    const probe = editingProbes.find((entry) => entry.id === row.id)
    expect(probe, `missing editing probe ${row.id}`).toBeDefined()
    if (!probe) continue
    const graded = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    const expected = row.expected === "decided" ? "supported" : row.expected
    expect(graded.after, `${row.id} reads ${expected} from a surface implementing its claim`).toBe(expected)
    expect(graded.satisfies, `${row.id} satisfies its contract row`).toBe(true)
  }
})

// 29817: the attribute-change extent starts at the DEC power-on default, which is STREAM, not the
// rectangle the early DECCARA/DECRARA rows assumed without selecting it. A row that wants the
// rectangle must say so with DECSACE 2, so a fixture that forgets cannot silently inherit rectangle
// semantics while the reading claims to measure the terminal.
test("an attribute change starts at the stream extent until the row selects rectangle", () => {
  const paint = "\x1b[0m\x1b[2J\x1b[H\x1b[1;1Habcdefgh\x1b[2;1Hijklmnop"
  const change = "\x1b[1;2;2;3;7$r"
  const pattern = (selectExtent: string): string => {
    const ctx = libProbeSource(createSemanticSurface({ cols: 8, rows: 2 }))
    ctx.feed(paint + selectExtent + change)
    return Array.from({ length: 2 }, (_, row) =>
      Array.from({ length: 8 }, (_, col) => (ctx.getCell(row, col).inverse ? "#" : ".")).join(""),
    ).join("|")
  }
  expect(pattern(""), "no DECSACE means the spec's stream default, never the rectangle").toBe(".#######|###.....")
  expect(pattern("\x1b[2*x"), "DECSACE 2 is the rectangle the row asked for").toBe(".##.....|.##.....")
})

// One negative control: the surface stops inserting characters, so the row must read "unsupported". A
// decided row cannot show this through `satisfies` (it accepts either pass or fail), so the observation
// itself is asserted. This is what makes the table above a measurement, not a stamp.
test("an ICH that does not insert reads unsupported", async () => {
  const row = EDITING_CONTRACT.find((entry) => entry.id === "editing.insert-chars")
  const probe = editingProbes.find((entry) => entry.id === "editing.insert-chars")
  expect(row, "the Editing contract names editing.insert-chars").toBeDefined()
  expect(probe, "the Editing contract names a real editing.insert-chars probe").toBeDefined()
  if (!row || !probe) return
  const graded = await regradeRow(probe, row, {
    headless: libProbeSource(createSemanticSurface({ mutations: ["ich-noop"] })),
  })
  expect(graded.after, "editing.insert-chars detects an inert ICH").toBe("unsupported")
})

/**
 * Per-probe two-sided controls across all 17 Editing rows (#32230):
 * each row has a distinct named mutation on `createSemanticSurface()` that suppresses its target
 * editing behavior while preserving its setup/control witness, proving the probe grades `supported`
 * on `createSemanticSurface()`, `unsupported` when its mutation is active, and never `supported` on
 * `inertLibProbeSource()`.
 */
const EDITING_SEMANTIC_SURFACE_CONTROLS: ReadonlyArray<readonly [id: string, mutation: string]> = [
  ["editing.insert-chars", "ich-noop"],
  ["editing.delete-chars", "dch-noop"],
  ["editing.insert-lines", "il-noop"],
  ["editing.delete-lines", "dl-noop"],
  ["editing.repeat-char", "rep-noop"],
  ["editing.decfra", "decfra-noop"],
  ["editing.decera", "decera-noop"],
  ["editing.decsera", "decsera-noop"],
  ["editing.deccra", "deccra-noop"],
  ["editing.deccara", "deccara-noop"],
  ["editing.decrara", "decrara-noop"],
  ["editing.decsace", "decsace-noop"],
  ["editing.decrqcra", "decrqcra-noop"],
  ["editing.sl", "sl-noop"],
  ["editing.sr", "sr-noop"],
  ["editing.decic", "decic-noop"],
  ["editing.decdc", "decdc-noop"],
]

test("EDITING_SEMANTIC_SURFACE_CONTROLS covers all 17 Editing contract rows with distinct mutations", () => {
  expect(EDITING_SEMANTIC_SURFACE_CONTROLS).toHaveLength(17)
  expect(EDITING_SEMANTIC_SURFACE_CONTROLS.map(([id]) => id).sort()).toEqual(
    EDITING_CONTRACT.map((row) => row.id).sort(),
  )
  expect(new Set(EDITING_SEMANTIC_SURFACE_CONTROLS.map(([, mutation]) => mutation)).size).toBe(17)
})

test.each(EDITING_SEMANTIC_SURFACE_CONTROLS)(
  "%s never reads supported on inertLibProbeSource, reads supported on createSemanticSurface, and reads unsupported when %s is active",
  async (id, mutation) => {
    const row = EDITING_CONTRACT.find((entry) => entry.id === id)
    const probe = editingProbes.find((entry) => entry.id === id)
    expect(row, `the Editing contract names ${id}`).toBeDefined()
    expect(probe, `the Editing contract names a real ${id} probe`).toBeDefined()
    if (!row || !probe || !probe.lib) return

    const inertResult = probe.lib(inertLibProbeSource())
    expect(inertResult.pass).toBe(false)
    expect(inertResult.observation?.outcome).not.toBe("supported")
    const inertGraded = await regradeRow(probe, row, { headless: inertLibProbeSource() })
    expect(inertGraded.after).not.toBe("supported")

    const positiveResult = probe.lib(libProbeSource(createSemanticSurface()))
    expect(positiveResult.pass).toBe(true)
    expect(positiveResult.observation?.outcome).toBe("supported")
    expect(positiveResult.assertions ?? []).toContainEqual(expect.objectContaining({ kind: "positive" }))
    const positiveGraded = await regradeRow(probe, row, { headless: libProbeSource(createSemanticSurface()) })
    expect(positiveGraded.after).toBe("supported")
    expect(positiveGraded.satisfies).toBe(true)

    const negativeResult = probe.lib(libProbeSource(createSemanticSurface({ mutations: [mutation] })))
    expect(negativeResult.pass).toBe(false)
    expect(gradedOutcome(negativeResult)).toBe("unsupported")
    expect(negativeResult.assertions ?? []).toContainEqual(expect.objectContaining({ kind: "negative" }))
    const negativeGraded = await regradeRow(probe, row, {
      headless: libProbeSource(createSemanticSurface({ mutations: [mutation] })),
    })
    expect(negativeGraded.after).toBe("unsupported")
    expect(negativeGraded.satisfies).toBe(true)
  },
)
