import type {
  LibProbeSource,
  TermProbeSource,
  ProbeDefinition,
  ProbeCallbackResult,
  TerminalQueryOutcome,
} from "./types.ts"
import { hasAuditedOscInterfaceAbsence } from "./extensions.ts"
import {
  REPLY_AFTER_SENTINEL_NOTE,
  probe,
  replyFailure,
  notTestedResult,
  declaredUntestableResult,
  NO_SAME_PATH_CONTROL,
  replyFrame,
  reviewResult,
  HEADLESS_OBSERVABLE_REVIEW,
  sentinelAnswer,
  sentinelNegativeResult,
  sentinelSilenceResult,
  stackStateResult,
} from "./helpers.ts"

/**
 * A library context has no application child by construction, so TERM_FEATURES is never observable there (@cto
 * 1265b1f4). Declared Untestable for every library (operator Nov 4 16:55).
 */
function termFeaturesLibraryReview(): ProbeCallbackResult {
  return declaredUntestableResult(
    "TERM_FEATURES: a library context spawns no application child to receive the environment export",
    {},
  )
}

/** These patterns match complete answers to the specific query, not arbitrary consumed output. */
interface DeviceReply {
  id: string
  query: string
  valid: RegExp
  malformed: RegExp
  expected: string
  refusal?: RegExp
  /**
   * A refusal of the single setting or name this probe's contract asks is the measured answer,
   * not a partial one. Set only where the contract names exactly one subject (27914: XTGETXRES
   * termName); the default leaves a refusal inconclusive.
   */
  refusalDecisive?: boolean
  /** A complete, well-formed answer to this query whose payload is not the expected one. */
  contradicts?: RegExp
  note?: (frame: string) => string | undefined
  direct?: boolean
}

function deviceReplyResult(
  spec: DeviceReply,
  raw: string,
  matchedFrame: string | null,
  reason: TerminalQueryOutcome["reason"],
  sentinel?: { atMs: number; graceMs: number },
): ProbeCallbackResult {
  // F1 (27832): a frame that lands after the sentinel's DA1 answer is a late reply, graded by the frame
  // and recorded as late. Only when `sentinel` carries the measured ordering is that certain, so a
  // frame arriving after DA1 without the measurement keeps its null.
  const da1At = sentinelAnswer(raw)?.start ?? -1
  if (matchedFrame && da1At !== -1 && raw.indexOf(matchedFrame) > da1At && !sentinel) matchedFrame = null
  const ordered = { ...(sentinel && { note: REPLY_AFTER_SENTINEL_NOTE }) }
  const valid = matchedFrame ? spec.valid.exec(matchedFrame) : null
  if (valid?.[0]) {
    const note = spec.note?.(valid[0])
    const composed = [note, ordered.note].filter((part): part is string => part !== undefined).join("; ")
    return {
      pass: true,
      response: raw,
      ...(composed && { note: composed }),
      observation: { outcome: "supported", assertionType: "query_reply", ...(composed && { note: composed }) },
      assertions: [
        { assertionType: "query_reply" as const, kind: "positive", expected: spec.expected, observed: valid[0] },
      ],
    }
  }
  const refusal = matchedFrame ? spec.refusal?.exec(matchedFrame) : null
  if (refusal?.[0]) {
    if (spec.refusalDecisive) {
      const decisiveNote = ["Requested name refused; the contract asks exactly one name", ordered.note]
        .filter((part): part is string => part !== undefined)
        .join("; ")
      return {
        pass: false,
        response: raw,
        note: decisiveNote,
        observation: { outcome: "unsupported", assertionType: "query_reply", note: decisiveNote },
        assertions: [
          { assertionType: "query_reply" as const, kind: "negative", expected: spec.expected, observed: refusal[0] },
        ],
      }
    }
    const refusalNote = ["Requested setting or name refused; other settings or names unmeasured", ordered.note]
      .filter((part): part is string => part !== undefined)
      .join("; ")
    return {
      pass: false,
      response: raw,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        assertionType: "query_reply",
        note: refusalNote,
      },
    }
  }
  // A complete, surfaced answer whose payload contradicts the expectation is a measured negative.
  // matchedFrame is never a frame that arrived after the DA1 sentinel, so late output cannot be graded.
  const contradiction = matchedFrame ? (spec.contradicts?.exec(matchedFrame) ?? null) : null
  if (contradiction?.[0]) {
    return {
      pass: false,
      response: raw,
      ...(ordered.note && { note: ordered.note }),
      observation: { outcome: "unsupported", assertionType: "query_reply", ...ordered },
      assertions: [
        {
          assertionType: "query_reply" as const,
          kind: "negative",
          expected: spec.expected,
          observed: contradiction[0],
        },
      ],
    }
  }
  const silent = sentinelNegativeResult(raw, sentinel, spec.expected)
  if (silent) return silent
  // Raw bytes remain available for diagnostics.
  const hasCompleteUnmatchedFrame =
    spec.valid.test(raw) || spec.refusal?.test(raw) === true || spec.contradicts?.test(raw) === true
  const missingReason =
    !hasCompleteUnmatchedFrame && spec.malformed.test(raw)
      ? "invalid-reply"
      : reason === "timeout"
        ? "timeout"
        : "no-response"
  if (raw.length === 0) {
    return { ...replyFailure(`${missingReason}; expected ${spec.expected}`), response: raw }
  }
  return {
    pass: false,
    response: raw,
    observation: { outcome: "inconclusive", reason: missingReason, assertionType: "query_reply" },
  }
}

/** Every complete answer shape this query accepts: the expected frame, a refusal, or a contradiction. */
function answerPattern(spec: DeviceReply): RegExp {
  const sources = [spec.valid.source, spec.refusal?.source, spec.contradicts?.source].filter(
    (source): source is string => source !== undefined,
  )
  return new RegExp(sources.join("|"), spec.valid.flags)
}

/**
 * Live's grading of one query outcome. A library probe source on a proven reply path offers the same
 * outcome through `queryWithSentinelOutcome` (#30554), so both arms grade through here; a library
 * probe source without that member keeps its capture-only reading.
 */
function deviceOutcomeResult(spec: DeviceReply, outcome: TerminalQueryOutcome): ProbeCallbackResult {
  return deviceReplyResult(spec, outcome.raw, replyFrame(outcome), outcome.reason, outcome.sentinel)
}

function deviceQuery(spec: DeviceReply): ProbeDefinition {
  const responsePattern = answerPattern(spec)
  const hostPixels = spec.query === "\x1b[14t"
  const definition = probe(
    spec.id,
    (ctx) => {
      // DA1 cannot be its own sentinel, so primary DA1 keeps the capture, as live keeps its direct query.
      const outcome = !spec.direct ? ctx.queryWithSentinelOutcome?.(spec.query, responsePattern) : undefined
      const raw = outcome ? outcome.raw : ctx.feedCapture(spec.query)
      const result = outcome
        ? deviceOutcomeResult(spec, outcome)
        : deviceReplyResult(spec, raw, responsePattern.exec(raw)?.[0] ?? null, "sentinel")
      const zeroGeometry =
        (spec.id === "device.xtwinops-14" && /^\x1b\[4;0;0t(?:\x1b\[\?[0-9]+(?:;[0-9]+)*c)?$/.test(raw)) ||
        (spec.id === "device.xtwinops-16" && /^\x1b\[6;0;0t(?:\x1b\[\?[0-9]+(?:;[0-9]+)*c)?$/.test(raw))
      if (spec.id === "device.xtwinops-14" || spec.id === "device.xtwinops-16") {
        // #32476 (NC-R3b): vterm.js 0.13.1 replies 4;0;0 / 6;0;0 while DA1 answers in the same run.
        if (zeroGeometry && result.observation?.outcome === "inconclusive") {
          if (hasAuditedOscInterfaceAbsence(ctx, "vterm-d2") && sentinelAnswer(raw) !== null) {
            const note =
              spec.id === "device.xtwinops-14"
                ? "vterm.js has no window pixel-size input and replied 4;0;0 while DA1 answered in the same run"
                : "vterm.js has no cell pixel-size input and replied 6;0;0 while DA1 answered in the same run"
            return {
              pass: false,
              response: raw,
              note,
              observation: { outcome: "unsupported", assertionType: "query_reply", note },
              assertions: [
                {
                  assertionType: "query_reply" as const,
                  kind: "negative",
                  expected: spec.expected,
                  observed: raw,
                },
              ],
            }
          }
          return notTestedResult(NO_SAME_PATH_CONTROL, { query: spec.query, raw })
        }
      }
      // #32246: an empty host-owned pixel reply on a native artifact has no same-path control in this run.
      const empty = outcome ? sentinelSilenceResult(outcome, spec.expected) !== null : raw === ""
      if (!hostPixels || !empty || ctx.runtimeIdentity?.kind !== "native") return result
      // The measured cause: this run captured the empty reply while no pixel geometry was supplied.
      return {
        ...notTestedResult(NO_SAME_PATH_CONTROL, { query: spec.query, raw }),
        hostRecipeCauses: [
          { recipe: "text-area-size", cause: { kind: "observed", missing: "pixel-geometry", query: spec.query } },
        ],
      }
    },
    async (ctx) => {
      // Primary DA1 answers its own direct query; all other device queries use DA1 as a sentinel.
      const outcome = spec.direct
        ? await ctx.queryOutcome(spec.query, responsePattern)
        : await ctx.queryWithSentinelOutcome(spec.query, responsePattern)
      return deviceOutcomeResult(spec, outcome)
    },
    "query_reply",
  )
  return {
    ...definition,
    termWrites: "query",
    libAssertionType: "query_reply",
    ...(hostPixels && {
      libHostRecipes: [{ recipe: "text-area-size" as const, query: spec.query, missing: ["pixel-geometry" as const] }],
    }),
  }
}

const DECRQSS_SGR: DeviceReply = {
  id: "device.decrqss",
  query: "\x1bP$qm\x1b\\",
  valid: /\x1bP1\$r[0-9:;]*m\x1b\\/,
  refusal: /\x1bP0\$r\x1b\\/,
  malformed: /\x1bP[01]\$r/,
  expected: "complete DECRQSS status 1 SGR parameters ending m and ST",
}

const DECRQSS_DECSTBM: DeviceReply = {
  id: "device.decrqss",
  query: "\x1bP$qr\x1b\\",
  valid: /\x1bP1\$r[0-9]+;[0-9]+r\x1b\\/,
  refusal: /\x1bP0\$r\x1b\\/,
  malformed: /\x1bP[01]\$r/,
  expected: "complete DECRQSS status 1 DECSTBM margins ending r and ST",
}

const DECRQSS_DECSCL: DeviceReply = {
  id: "device.decrqss",
  query: '\x1bP$q"p\x1b\\',
  valid: /\x1bP1\$r[0-9]+;[0-9]+"p\x1b\\/,
  refusal: /\x1bP0\$r\x1b\\/,
  malformed: /\x1bP[01]\$r/,
  expected: 'complete DECRQSS status 1 DECSCL conformance parameters ending "p and ST',
}

// 32569: tmux refuses SGR, DECSTBM and DECSCL and answers only SP q. Its input.c replies `1$r q%d q`, an extra ` q`
// before the style, so take the status and the ending, not a strict digit form (@cto third-table ruling 2026-11-06).
const DECRQSS_DECSCUSR: DeviceReply = {
  id: "device.decrqss",
  query: "\x1bP$q q\x1b\\",
  valid: /\x1bP1\$r[^\x1b]* q\x1b\\/,
  refusal: /\x1bP0\$r\x1b\\/,
  malformed: /\x1bP[01]\$r/,
  expected: "complete DECRQSS status 1 DECSCUSR reply ending SP q and ST",
}

function titleStackHeadless(ctx: LibProbeSource, expected: string): ProbeCallbackResult {
  const before = ctx.getTitle()
  const saved = before === "pushed-title" ? "other-pushed-title" : "pushed-title"
  const set = (title: string) => ctx.feed(`\x1b]2;${title}\x07`)
  let pushed = false
  try {
    // #32323: both IDs grade the joint round trip; the second fixture excludes a stale saved title.
    const fixture = (originalTitle: string, changedTitle: string) => {
      set(saved)
      set(originalTitle)
      const original = ctx.getTitle()
      ctx.feed("\x1b[22;0t")
      pushed = true
      set(changedTitle)
      const changed = ctx.getTitle()
      pushed = false
      ctx.feed("\x1b[23;0t")
      return { original, changed, restored: ctx.getTitle() }
    }
    const popFixture = fixture(saved, "new-title")
    const pushFixture = fixture("new-title", "next-title")
    const state = { before, popFixture, pushFixture }
    if (
      popFixture.original !== saved ||
      popFixture.changed !== "new-title" ||
      pushFixture.original !== "new-title" ||
      pushFixture.changed !== "next-title"
    ) {
      const note =
        "Open: this test first sets a window title, then tests whether the command under test changes it. We could not read the first title back"
      return reviewResult(HEADLESS_OBSERVABLE_REVIEW, `${note}, so this run cannot decide it`, note, state)
    }
    const pass = popFixture.restored === saved && pushFixture.restored === "new-title"
    return stackStateResult({ pass, ...(!pass && { note: "push/pop round trip does not restore" }) }, expected, state)
  } finally {
    try {
      if (pushed) ctx.feed("\x1b[23;0t")
    } finally {
      set(before)
    }
  }
}

/** OSC 1 with an empty name clears the icon title; the separator is required, or the terminal drops it. */
const CLEAR_ICON_TITLE = "\x1b]1;\x07"

/** Both App IDs measure the same two joint fixtures, through the owned title surface. */
async function titleStackApp(ctx: TermProbeSource): Promise<ProbeCallbackResult> {
  const read = ctx.readTitle
  if (!read) {
    const note = "No owned title reader is installed for this run"
    return {
      ...notTestedResult(note, {}),
      tests: [
        {
          id: "criterion",
          status: "probe-todo",
          reason: ctx.captureGeometryRefusal ? `Pixel capture unavailable: ${ctx.captureGeometryRefusal}` : note,
        },
      ],
    }
  }
  const before = await read()
  const saved = before === "pushed-title" ? "other-pushed-title" : "pushed-title"
  const set = (title: string) => ctx.write(`\x1b]2;${title}\x07`)
  // The fixture sets its own start state instead of depending on probe order: an icon title left by
  // an earlier probe would be shown in place of every OSC 2 control (#33035, @cto e9641d54).
  ctx.write(CLEAR_ICON_TITLE)
  let pushed = false
  const state: Record<string, unknown> = { before }
  let result: ProbeCallbackResult
  try {
    const fixture = async (originalTitle: string, changedTitle: string) => {
      set(saved)
      set(originalTitle)
      const original = await read()
      pushed = true
      ctx.write("\x1b[22;0t")
      set(changedTitle)
      const changed = await read()
      ctx.write("\x1b[23;0t")
      pushed = false
      return { original, changed, restored: await read() }
    }
    const popFixture = await fixture(saved, "new-title")
    state.popFixture = popFixture
    const pushFixture = await fixture("new-title", "next-title")
    state.pushFixture = pushFixture
    const controlled =
      popFixture.original === saved &&
      popFixture.changed === "new-title" &&
      pushFixture.original === "new-title" &&
      pushFixture.changed === "next-title"
    result = controlled
      ? stackStateResult(
          { pass: popFixture.restored === saved && pushFixture.restored === "new-title" },
          "XTWINOPS 22/23 restores both controlled pushed titles",
          state,
        )
      : { ...replyFailure("Owned title reader failed the OSC 2 controls"), response: JSON.stringify(state) }
    if (!controlled) result.criterionBranch = "app-title-control"
  } finally {
    try {
      if (pushed) ctx.write("\x1b[23;0t")
    } finally {
      set(before)
      state.restored = await read()
      if (state.restored !== before) throw new Error(`Owned title restoration mismatch: ${JSON.stringify(state)}`)
    }
  }
  return { ...result, response: JSON.stringify(state) }
}

function refusedFrame(spec: DeviceReply, matchedFrame: string | null): boolean {
  return Boolean(matchedFrame && spec.refusal?.exec(matchedFrame)?.[0])
}

/** An earlier selector refusal proves DECRQSS speaks; later silence is never a facility-wide F1 negative. */
function decrqssAfterRefusal(
  spec: DeviceReply,
  second: TerminalQueryOutcome,
  refused: string,
  retainedRefusals = "",
): ProbeCallbackResult {
  const setting = spec === DECRQSS_DECSTBM ? "DECSTBM" : spec === DECRQSS_DECSCL ? "DECSCL" : "DECSCUSR"
  if (second.raw.length === 0) {
    return {
      ...replyFailure(`${refused}; ${setting} unanswered; DECRQSS facility still speaks; expected ${spec.expected}`),
      response: second.raw,
    }
  }
  const secondFrame = replyFrame(second)
  const graded = deviceReplyResult(spec, second.raw, secondFrame, second.reason, second.sentinel)
  if (graded.observation?.outcome === "supported") {
    const note = [refused, graded.observation.note].filter(Boolean).join("; ")
    return {
      pass: true,
      response: retainedRefusals + second.raw,
      note,
      observation: { ...graded.observation, note },
      assertions: graded.assertions,
    }
  }
  const refusal = secondFrame ? spec.refusal?.exec(secondFrame)?.[0] : undefined
  if (secondFrame && refusal) {
    const da1At = sentinelAnswer(second.raw)?.start ?? -1
    const afterDa1 = da1At !== -1 && second.raw.indexOf(secondFrame) > da1At
    const late = Boolean(second.sentinel) && afterDa1
    const note = [`${refused}; ${setting} refused`, late ? REPLY_AFTER_SENTINEL_NOTE : undefined]
      .filter((part): part is string => part !== undefined)
      .join("; ")
    // 32569: DECSCUSR is the last selector, so four refusals are the facility's own answer: Unsupported, retaining
    // all four. F1 (27832): a frame after DA1 decides only with the measured order.
    if (spec === DECRQSS_DECSCUSR && (late || !afterDa1)) {
      return {
        pass: false,
        response: retainedRefusals + second.raw,
        note,
        observation: { outcome: "unsupported", assertionType: "query_reply", note },
        assertions: [
          { assertionType: "query_reply" as const, kind: "negative", expected: spec.expected, observed: refusal },
        ],
      }
    }
    return {
      pass: false,
      response: second.raw,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        assertionType: "query_reply",
        note,
      },
    }
  }
  const hasCompleteUnmatchedFrame = spec.valid.test(second.raw) || spec.refusal?.test(second.raw) === true
  const reason =
    !hasCompleteUnmatchedFrame && spec.malformed.test(second.raw)
      ? "invalid-reply"
      : second.reason === "timeout"
        ? "timeout"
        : "insufficient-evidence"
  return {
    pass: false,
    response: second.raw,
    observation: {
      outcome: "inconclusive",
      reason,
      assertionType: "query_reply",
      note: `${refused}; ${setting} unanswered; DECRQSS facility still speaks`,
    },
  }
}

function decrqssFacilityProbe(): ProbeDefinition {
  const sgrPattern = answerPattern(DECRQSS_SGR)
  const decstbmPattern = answerPattern(DECRQSS_DECSTBM)
  const decsclPattern = answerPattern(DECRQSS_DECSCL)
  const decscusrPattern = answerPattern(DECRQSS_DECSCUSR)
  const definition = probe(
    "device.decrqss",
    (ctx) => {
      // Sample the facility in order, advancing only after a complete selector refusal.
      const query = (sequence: string, pattern: RegExp): TerminalQueryOutcome => {
        if (ctx.queryWithSentinelOutcome) return ctx.queryWithSentinelOutcome(sequence, pattern)
        const raw = ctx.feedCapture(sequence)
        const match = pattern.exec(raw)
        return { raw, rawBase64: Buffer.from(raw).toString("base64"), match, reason: match ? "reply" : "sentinel" }
      }
      const sgr = query(DECRQSS_SGR.query, sgrPattern)
      if (!refusedFrame(DECRQSS_SGR, replyFrame(sgr))) return deviceOutcomeResult(DECRQSS_SGR, sgr)
      const second = query(DECRQSS_DECSTBM.query, decstbmPattern)
      if (!refusedFrame(DECRQSS_DECSTBM, replyFrame(second))) {
        return decrqssAfterRefusal(DECRQSS_DECSTBM, second, "SGR refused")
      }
      const third = query(DECRQSS_DECSCL.query, decsclPattern)
      if (!refusedFrame(DECRQSS_DECSCL, replyFrame(third))) {
        return decrqssAfterRefusal(DECRQSS_DECSCL, third, "SGR refused; DECSTBM refused", sgr.raw + second.raw)
      }
      return decrqssAfterRefusal(
        DECRQSS_DECSCUSR,
        query(DECRQSS_DECSCUSR.query, decscusrPattern),
        "SGR refused; DECSTBM refused; DECSCL refused",
        sgr.raw + second.raw + third.raw,
      )
    },
    async (ctx) => {
      const sgr = await ctx.queryWithSentinelOutcome(DECRQSS_SGR.query, sgrPattern)
      if (!refusedFrame(DECRQSS_SGR, replyFrame(sgr))) return deviceOutcomeResult(DECRQSS_SGR, sgr)
      const second = await ctx.queryWithSentinelOutcome(DECRQSS_DECSTBM.query, decstbmPattern)
      if (!refusedFrame(DECRQSS_DECSTBM, replyFrame(second))) {
        return decrqssAfterRefusal(DECRQSS_DECSTBM, second, "SGR refused")
      }
      const third = await ctx.queryWithSentinelOutcome(DECRQSS_DECSCL.query, decsclPattern)
      if (!refusedFrame(DECRQSS_DECSCL, replyFrame(third))) {
        return decrqssAfterRefusal(DECRQSS_DECSCL, third, "SGR refused; DECSTBM refused", sgr.raw + second.raw)
      }
      return decrqssAfterRefusal(
        DECRQSS_DECSCUSR,
        await ctx.queryWithSentinelOutcome(DECRQSS_DECSCUSR.query, decscusrPattern),
        "SGR refused; DECSTBM refused; DECSCL refused",
        sgr.raw + second.raw + third.raw,
      )
    },
    "query_reply",
  )
  return { ...definition, termWrites: "query", libAssertionType: "query_reply" }
}

const iconLabelReply: DeviceReply = {
  id: "device.xtwinops-20",
  query: "\x1b[20t",
  valid: /\x1b\]Ltest-icon(?:\x07|\x1b\\)/,
  malformed: /\x1b\]L/,
  // A complete, terminated OSC L frame is a measured negative when its whole payload is not the
  // exact label; the payload class keeps the match on one frame so it cannot span a truncated starter.
  contradicts: /\x1b\]L[^\x07\x1b]*(?:\x07|\x1b\\)/,
  expected: "OSC 1 + CSI 20 t round trip returns the exact icon label",
}

const windowTitleReply: DeviceReply = {
  id: "device.xtwinops-21",
  query: "\x1b[21t",
  valid: /\x1b\]ltest-title(?:\x07|\x1b\\)/,
  malformed: /\x1b\]l/,
  contradicts: /\x1b\]l[^\x07\x1b]*(?:\x07|\x1b\\)/,
  expected: "CSI 21 t returns the exact window title set by OSC 2",
}

export const deviceProbes: ProbeDefinition[] = [
  deviceQuery({
    id: "device.primary-da",
    query: "\x1b[c",
    // Kitty includes a trailing empty parameter: CSI ? 62 ; 52 ; c.
    valid: /\x1b\[\?[0-9]+(?:;[0-9]+)*;?c/,
    malformed: /\x1b\[\?/,
    expected: "complete DA1 CSI ? numeric attributes c",
    direct: true, // DA1 is also the normal sentinel; it must be queried directly.
  }),
  deviceQuery({
    id: "device.status-report",
    query: "\x1b[5n",
    valid: /\x1b\[(?:0|3)n/,
    malformed: /\x1b\[[0-9]*n/,
    expected: "complete DSR 5 status 0 (ready) or 3 (malfunction)",
    note: (frame) => (frame === "\x1b[3n" ? "Terminal reports malfunction" : undefined),
  }),
  deviceQuery({
    id: "device.secondary-da",
    query: "\x1b[>c",
    valid: /\x1b\[>[0-9]+;[0-9]+;[0-9]+c/,
    malformed: /\x1b\[>/,
    expected: "complete DA2 CSI > three numeric fields c",
  }),
  deviceQuery({
    id: "device.tertiary-da",
    query: "\x1b[=c",
    valid: /\x1bP!\|[0-9A-Fa-f]{8}\x1b\\/,
    malformed: /\x1bP!\|/,
    expected: "complete DECRPTUI DCS !| followed by four hexadecimal pairs and ST",
  }),
  decrqssFacilityProbe(),
  deviceQuery({
    id: "device.xtgettcap",
    query: "\x1bP+q544e\x1b\\",
    valid: /\x1bP1\+r544e=(?:[0-9A-Fa-f]{2})+\x1b\\/i,
    refusal: /\x1bP0\+r\x1b\\/,
    malformed: /\x1bP[01]\+r/,
    expected: "complete XTGETTCAP status 1 for TN with even-length hex value and ST",
  }),
  deviceQuery({
    id: "device.decrpm",
    query: "\x1b[?7$p",
    valid: /\x1b\[\?7;[1-4]\$y/,
    refusal: /\x1b\[\?7;0\$y/,
    malformed: /\x1b\[\?[0-9]+;[0-9]*\$y|\x1b\[\?7(?:;|\$)/,
    expected: "complete DECRPM for DECAWM mode 7 with recognized state 1–4",
  }),
  deviceQuery({
    id: "device.xtversion",
    query: "\x1b[>0q",
    valid: /\x1bP>\|[\x20-\x7e]+\x1b\\/,
    malformed: /\x1bP>\|/,
    expected: "complete XTVERSION DCS >| printable name/version ST",
  }),
  probe(
    "device.term-features",
    termFeaturesLibraryReview,
    async (ctx) => {
      if (!ctx.readTermFeatures) return notTestedResult("terminal child environment", {})
      const reading = await ctx.readTermFeatures()
      if (reading.status === "unavailable") return notTestedResult(reading.reason, {})
      if (reading.status === "invalid") {
        return {
          pass: false,
          note: reading.reason,
          tests: [{ id: "terminal-child-environment", status: "probe-invalid", reason: reading.reason }],
        }
      }
      // 32569: inside a mux the value may come from the outer terminal, and presence cannot be attributed without an
      // authenticated source, so it stays PROBE TODO naming the outer; absence with this run's marker seen is
      // Unsupported, as on a bare App (@cto third-table ruling 2026-11-06).
      if (reading.present && reading.mux) {
        return notTestedResult(
          `TERM_FEATURES present inside ${reading.mux}; it may come from the outer terminal, and presence cannot be attributed without an authenticated source`,
          { present: true, mux: reading.mux },
        )
      }
      const supported = reading.present
      const note = supported
        ? "TERM_FEATURES exported by this terminal child"
        : "TERM_FEATURES absent with this terminal child's same-run control"
      return {
        pass: supported,
        note,
        response: JSON.stringify(reading),
        observation: { outcome: supported ? "supported" : "unsupported", assertionType: "process_environment", note },
        assertions: [
          {
            assertionType: "process_environment",
            kind: supported ? "positive" : "negative",
            expected: "TERM_FEATURES exported by the terminal",
            observed: reading.present ? JSON.stringify(reading.value) : "absent",
          },
        ],
      }
    },
    "process_environment",
  ),

  // DSR ?996 — color-scheme query: CSI ? 996 n → CSI ? 997 ; Ps n
  {
    ...probe(
      "device.dsr-996-color-scheme",
      (ctx) => {
        if (ctx.queryWithSentinelOutcome) {
          const silence = sentinelSilenceResult(
            ctx.queryWithSentinelOutcome("\x1b[?996n", /\x1b\[\?997;([12])n/),
            "DSR ?996 yields complete DSR ?997;1n or ?997;2n",
          )
          if (silence) return silence
        }
        const response = ctx.feedCapture("\x1b[?996n")
        const match = /\x1b\[\?997;([12])n/.exec(response)
        if (!match?.[0]) {
          return {
            pass: false,
            note: "No valid DSR ?997 color-scheme response",
            response,
            ...(response.length === 0
              ? replyFailure("no usable DSR ?997 color-scheme reply")
              : {
                  observation: {
                    outcome: "inconclusive",
                    assertionType: "query_reply",
                    reason: response.includes("\x1b[?997;") ? "invalid-reply" : "no-response",
                  },
                }),
          }
        }
        return {
          pass: true,
          note: match[1] === "1" ? "dark" : "light",
          response,
          observation: {
            outcome: "supported",
            assertionType: "query_reply",
            note: "Current scheme queried; unsolicited change events were not tested",
          },
          assertions: [
            {
              assertionType: "query_reply" as const,
              kind: "positive",
              expected: "DSR ?996 yields complete DSR ?997;1n or ?997;2n",
              observed: match[0],
            },
          ],
        }
      },
      async (ctx) => {
        const reply = await ctx.queryWithSentinelOutcome("\x1b[?996n", /\x1b\[\?997;([12])n/)
        const match = reply.match
        if (!match?.[0]) {
          const silent = sentinelNegativeResult(
            reply.raw,
            reply.sentinel,
            "DSR ?996 yields complete DSR ?997;1n or ?997;2n",
          )
          if (silent) return silent
          return {
            pass: false,
            note: "No valid DSR ?997 color-scheme response",
            response: reply.raw,
            ...(reply.raw.length === 0
              ? replyFailure("no usable DSR ?997 color-scheme reply")
              : {
                  observation: {
                    outcome: "inconclusive",
                    assertionType: "query_reply",
                    reason: reply.raw.includes("\x1b[?997;")
                      ? "invalid-reply"
                      : reply.reason === "timeout"
                        ? "timeout"
                        : "no-response",
                  },
                }),
          }
        }
        return {
          pass: true,
          note: match[1] === "1" ? "dark" : "light",
          response: match[0],
          observation: {
            outcome: "supported",
            assertionType: "query_reply",
            note: "Current scheme queried; unsolicited change events were not tested",
          },
          assertions: [
            {
              assertionType: "query_reply" as const,
              kind: "positive",
              expected: "DSR ?996 yields complete DSR ?997;1n or ?997;2n",
              observed: match[0],
            },
          ],
        }
      },
      "query_reply",
    ),
    termWrites: "query",

    libAssertionType: "query_reply",
  },

  // XTWINOPS 14 — report text-area size in pixels: CSI 14 t → CSI 4 ; H ; W t
  deviceQuery({
    id: "device.xtwinops-14",
    query: "\x1b[14t",
    valid: /\x1b\[4;[1-9][0-9]*;[1-9][0-9]*t/,
    malformed: /\x1b\[4;/,
    expected: "CSI 14 t reports text-area pixels as CSI 4;positive-height;positive-width t",
  }),

  // XTWINOPS 16 — report cell size in pixels: CSI 16 t → CSI 6 ; H ; W t
  deviceQuery({
    id: "device.xtwinops-16",
    query: "\x1b[16t",
    valid: /\x1b\[6;[1-9][0-9]*;[1-9][0-9]*t/,
    malformed: /\x1b\[6;/,
    expected: "CSI 16 t returns a complete CSI 6;positive-height;positive-width t frame",
  }),

  // XTWINOPS 18 — report text area size in chars: CSI 18 t → CSI 8 ; rows ; cols t
  deviceQuery({
    id: "device.xtwinops-18",
    query: "\x1b[18t",
    valid: /\x1b\[8;[1-9][0-9]*;[1-9][0-9]*t/,
    malformed: /\x1b\[8;/,
    expected: "CSI 18 t returns a complete CSI 8;positive-rows;positive-columns t frame",
  }),

  // XTWINOPS 20 — report icon label: CSI 20 t → OSC L label ST
  // Set icon label via OSC 1, then query with CSI 20 t and verify response.
  {
    ...probe(
      "device.xtwinops-20",
      (ctx) => {
        ctx.feed("\x1b]1;test-icon\x07")
        if (ctx.queryWithSentinelOutcome) {
          return deviceOutcomeResult(
            iconLabelReply,
            ctx.queryWithSentinelOutcome(iconLabelReply.query, answerPattern(iconLabelReply)),
          )
        }
        const raw = ctx.feedCapture(iconLabelReply.query)
        return deviceReplyResult(iconLabelReply, raw, answerPattern(iconLabelReply).exec(raw)?.[0] ?? null, "sentinel")
      },
      async (ctx) => {
        ctx.write("\x1b]1;test-icon\x07")
        try {
          const reply = await ctx.queryWithSentinelOutcome(iconLabelReply.query, answerPattern(iconLabelReply))
          return deviceOutcomeResult(iconLabelReply, reply)
        } finally {
          // Clear what this probe set, so no later probe starts with an icon title: a terminal that
          // shows the icon title in preference to OSC 2 hid every later title control (#33035).
          ctx.write(CLEAR_ICON_TITLE)
        }
      },
    ),
    libAssertionType: "query_reply",
  },

  // XTWINOPS 21 — report window title: CSI 21 t → OSC l title ST
  // Set a known title via OSC 2, then query to verify it's reported back.
  {
    ...probe(
      "device.xtwinops-21",
      (ctx) => {
        ctx.feed("\x1b]2;test-title\x07")
        if (ctx.queryWithSentinelOutcome) {
          return deviceOutcomeResult(
            windowTitleReply,
            ctx.queryWithSentinelOutcome(windowTitleReply.query, answerPattern(windowTitleReply)),
          )
        }
        const raw = ctx.feedCapture(windowTitleReply.query)
        return deviceReplyResult(
          windowTitleReply,
          raw,
          answerPattern(windowTitleReply).exec(raw)?.[0] ?? null,
          "sentinel",
        )
      },
      async (ctx) => {
        ctx.write("\x1b]2;test-title\x07")
        const reply = await ctx.queryWithSentinelOutcome(windowTitleReply.query, answerPattern(windowTitleReply))
        return deviceOutcomeResult(windowTitleReply, reply)
      },
    ),
    libAssertionType: "query_reply",
  },

  // XTWINOPS 22 — push title/icon stack: CSI 22 ; 0 t
  // A successful push/pop round trip establishes both operations; failure cannot identify either
  // unless the loaded artifact's source is audited to implement neither operation (#31735, @cto 863bef67).
  {
    ...probe(
      "device.xtwinops-22",
      (ctx) => titleStackHeadless(ctx, "XTWINOPS 22/23 restores the pushed title after a controlled title change"),
      titleStackApp,
      "buffer_state",
    ),
    libAssertionType: "buffer_state",
  },

  // XTWINOPS 23 — pop title/icon stack: CSI 23 ; 0 t (no response, partial)
  {
    ...probe(
      "device.xtwinops-23",
      (ctx) => titleStackHeadless(ctx, "XTWINOPS 22/23 restores the pushed title after a controlled title change"),
      titleStackApp,
      "buffer_state",
    ),
    libAssertionType: "buffer_state",
  },

  // XTREPORTCOLORS — report palette-stack current entry and stored palette count.
  deviceQuery({
    id: "device.xtreportcolors",
    query: "\x1b[#R",
    // xterm's own reply carries a DEC-private `?` before the parameters (measured:
    // CSI ? 0 ; 1 # Q on xterm 411); kitty answers without it (CSI 0 ; 0 # Q).
    // The `?` is part of the reference implementation's reply, so the matcher accepts
    // it rather than grading xterm's own extension as an invalid reply.
    valid: /\x1b\[\??[0-9]+;[0-9]+#Q/,
    malformed: /\x1b\[\??[0-9;]*#|#Q/,
    expected: "CSI # R reports palette-stack entry and stored count as CSI [optional ?] entry;count # Q",
  }),

  // XTGETXRES — query xterm resource value: DCS + Q Pt ST → DCS response
  // Added in xterm; documented in patches 401/402 (2025).
  deviceQuery({
    id: "device.xtgetxres",
    // "termName" is encoded as two hex digits per character, per XTGETXRES.
    query: "\x1bP+Q7465726d4e616d65\x1b\\",
    valid: /\x1bP1\+R7465726d4e616d65=(?:[0-9A-Fa-f]{2})+\x1b\\/i,
    refusal: /\x1bP0\+R7465726d4e616d65\x1b\\/i,
    // The contract asks exactly one name, so a status-0 refusal is this probe's measured answer.
    refusalDecisive: true,
    // The name is hex-encoded, so a terminal may echo it in either case; valid and
    // refusal are already case-insensitive, and a case-sensitive malformed pattern
    // graded the same frame no-response instead of invalid-reply.
    malformed: /\x1bP[01]\+R/i,
    expected: "XTGETXRES returns a complete status-1 termName resource value",
  }),
]
