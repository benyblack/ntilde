/**
 * A probe result for tests whose subject is not the graded outcome: an inconclusive, insufficient-evidence
 * observation, so no caller mistakes it for a measurement.
 *
 * @fakes @terminfo/probe-defs
 */
import type { AssertionType, ProbeCallbackResult } from "../types.ts"

export function fakeProbeResult(assertionType: AssertionType = "buffer_state"): ProbeCallbackResult {
  return { pass: false, observation: { outcome: "inconclusive", reason: "insufficient-evidence", assertionType } }
}
