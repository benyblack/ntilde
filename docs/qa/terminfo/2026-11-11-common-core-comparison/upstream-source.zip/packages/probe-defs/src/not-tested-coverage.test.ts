/**
 * @failure A headless probe with no applicable observable reports a measurement, or drops its named coverage.
 * @level l1
 * @consumer Headless collector coverage records for the 165-row not-tested slice.
 * @reach Runs each scheduled headless callback against a minimal context.
 * @testonly none
 */
import { expect, test } from "vitest"
import { NO_SAME_PATH_CONTROL } from "./helpers.ts"
import { ALL_PROBES, SEMANTIC_PROMPT_SOURCE_REVIEW } from "./index.ts"
import type { LibProbeSource } from "./types.ts"

// Remaining headless features whose raw state is measurable but whose claim is not.
// DECRPM mode-state criteria grade the engine's own reply in modes-observations.test.ts.
const notTestedFeatures = ["extensions.osc1-icon", "sgr.overline"]

const context = (): LibProbeSource =>
  ({
    cols: 80,
    rows: 24,
    capabilities: { extensions: new Set<string>() },
    feed: () => {},
    feedCapture: () => "$y",
    getMode: () => false,
    getText: () => "",
    getTitle: () => "original",
    getCell: () => ({ char: "X" }),
    getCursor: () => ({ x: 0, y: 0, visible: true, style: null }),
    reset: () => {},
  }) as unknown as LibProbeSource

// These missing observables previously emitted coverage without the required review attachment.
// Declared capability flags do not establish rendering, delivery, timing or event behaviour.
const headlessObservableFeatures = [
  [
    "extensions.osc7-cwd",
    "Declared OSC 7 capability does not establish working-directory metadata delivery",
    { declared: true },
  ],
  [
    "extensions.notifications",
    "Declared OSC 9 capability does not establish desktop notification delivery",
    { declared: true },
  ],
  [
    "extensions.osc8",
    "Open: our adapter for this library version does not read a link's address back (OSC 8; Adapter (runtime identity unavailable))",
    { chars: [..."ALINKZ"], links: Array.from({ length: 6 }, () => ({ reported: false })) },
  ],
  [
    "reset.soft",
    "The headless getMode readback exposes no application-cursor mode (DECCKM) state",
    { before: null, after: null },
  ],
] as const

// The operator's Nov 4 16:55 declaration (part A): the same missing observable and state, read as Untestable.
const declaredUntestableFeatures = [
  [
    "extensions.kitty-graphics.animation",
    "Declared Kitty graphics capability does not establish timed animation playback",
    { declared: true },
  ],
  [
    "extensions.kitty-graphics.unicode-placeholders",
    "Declared Kitty graphics capability does not establish Unicode placeholder rendering",
    { declared: true },
  ],
  ["extensions.sixel", "Declared Sixel capability does not establish rendered pixels", { declared: true }],
  [
    "extensions.iterm2-images",
    "Declared iTerm2 image capability does not establish rendered image pixels",
    { declared: true },
  ],
  [
    "extensions.font-ligatures",
    "Font ligatures are renderer glyph shaping; the headless parser shapes no glyphs",
    { ligatureSample: "!= -> => <= ==" },
  ],
] as const

test.each(declaredUntestableFeatures)(
  "%s retains its missing observable and state as declared Untestable",
  (id, noObservable, state) => {
    const definition = ALL_PROBES.find((probe) => probe.id === id)
    if (!definition?.lib) throw new Error("missing headless " + id)
    const result = definition.lib({
      ...context(),
      capabilities: { kittyGraphics: true, sixel: true, extensions: new Set(["iterm2Images"]) },
    } as unknown as LibProbeSource)
    expect(result.notTested).toEqual({ reason: "no-semantic-observable", noObservable })
    expect(JSON.parse(result.response!)).toEqual(state)
    expect(result.criterionBranch).toBe("headless-observable-review")
    expect(result.tests).toEqual([{ id: "declared-untestable", status: "untestable", reason: noObservable }])
    expect(result.observation).toBeUndefined()
    expect(result.assertions).toBeUndefined()
  },
)

test.each(headlessObservableFeatures)(
  "%s retains its missing observable and state as PROBE TODO",
  (id, noObservable, state) => {
    const definition = ALL_PROBES.find((probe) => probe.id === id)
    if (!definition?.lib) throw new Error(`missing headless ${id}`)
    const source = {
      ...context(),
      capabilities: {
        kittyGraphics: true,
        sixel: true,
        semanticPrompts: true,
        extensions: new Set(["osc7", "osc9", "iterm2Images"]),
      },
      getMode: (mode: string) => (mode === "applicationCursor" ? null : false),
      getCell: (_row: number, col: number) => ({ char: "ALINKZ"[col] }),
    } as unknown as LibProbeSource
    const result = definition.lib(source)
    expect(result.notTested).toEqual({ reason: "no-semantic-observable", noObservable })
    expect(JSON.parse(result.response!)).toEqual(state)
    expect(result.criterionBranch).toBe("headless-observable-review")
    expect(result.tests).toEqual([
      {
        id: "review",
        status: "probe-todo",
        reason: `${noObservable}, so this run cannot decide it`,
      },
    ])
    expect(result.observation).toBeUndefined()
    expect(result.assertions).toBeUndefined()
  },
)

// S8 requires a missing DECRPM reply to retain its named review and both measured phases.
// The presentation table cannot exercise this protocol arm; positive mode tests supply valid replies.
test("modes.decsclm retains missing DECRPM coverage and measured state as PROBE TODO", () => {
  const definition = ALL_PROBES.find((probe) => probe.id === "modes.decsclm")
  if (!definition?.lib) throw new Error("missing headless modes.decsclm")
  const result = definition.lib(context())
  expect(result.notTested).toEqual({
    reason: "no-semantic-observable",
    noObservable: "DECRPM reply to CSI ? 4 $ p",
  })
  expect(JSON.parse(result.response!)).toEqual({
    setReply: "$y",
    resetReply: "$y",
    setMode: false,
    resetMode: false,
    insertBefore: false,
    insertAfter: false,
  })
  expect(result.criterionBranch).toBe("os-input-review")
  expect(result.tests).toEqual([
    {
      id: "review",
      status: "probe-todo",
      reason:
        "Open: our test received no usable reply to the mode query (DECRPM), and this run has no qualified control for that reply, so it cannot tell whether the mode works.",
    },
  ])
  expect(result.observation).toBeUndefined()
  expect(result.assertions).toBeUndefined()
})

// S8 retains an unchanged non-null DECKPAM pair as criterion TODO, never missing coverage or a grade.
// The generic no-observable table cannot express it; mode tests do not exercise this minimal source.
test("modes.application-keypad retains its unchanged measured state as a named criterion TODO", () => {
  const definition = ALL_PROBES.find((probe) => probe.id === "modes.application-keypad")
  if (!definition?.lib) throw new Error("missing headless modes.application-keypad")
  const result = definition.lib(context())
  expect(result.notTested).toBeUndefined()
  expect(JSON.parse(result.response!)).toEqual({ setMode: false, resetMode: false })
  expect(result.pass).toBe(false)
  expect(result.tests).toEqual([
    { id: "criterion", status: "probe-todo", reason: "DECKPAM state pair: set false, reset false" },
  ])
  expect(result.observation).toEqual({
    outcome: "inconclusive",
    assertionType: "buffer_state",
    reason: "insufficient-evidence",
    note: "DECKPAM state pair: set false, reset false; keypad key encoding unmeasured; mode state measured",
  })
  expect(result.note).toBe(result.observation?.note)
  expect(result.assertions).toBeUndefined()
})

const headlessStateFeatures = [
  [
    "sgr.underline.color",
    ["A", "B", "X"],
    "sgr.underline.color: X has explicit rgb(255,0,128) underline distinct from the reset/default B cell",
    "Open: we set an underline colour (SGR 58), but the screen cell shows none, so we cannot tell whether the library ignored it or does not report it.",
  ],
  [
    "sgr.underline-color-indexed",
    ["A", "X", "B", "Y"],
    "SGR 58 index 5/4 underline colors match the opposite SGR 38 palette controls, not their same-foreground defaults",
    "Open: we set an underline colour (SGR 58), but the screen cell shows none, so we cannot tell whether the library ignored it or does not report it.",
  ],
  // Seedless SGR59/default-color cases are named TODOs, covered by sgr-contract.test.ts.
  [
    "sgr.selective-reset.italic",
    ["C", "X", "Y"],
    "sgr.selective-reset.italic: measured setup attributes clear on Y and unrelated attributes remain set",
    "Open: italic and bold did not show during setup, so our test cannot check the combined reset.",
  ],
  [
    "sgr.fg.standard",
    ["C", "X", "Y"],
    "sgr.fg.standard: the two named colors select distinct exposed fg RGB values",
    "the fg color field in the headless readback (neutral, SGR 31 and SGR 34 cells all read no color)",
  ],
  [
    "sgr.fg.256",
    ["C", "A", "B", "X", "Y"],
    "sgr.fg.256: indices 67 and 173 match two independently observed canonical RGB cube references",
    "direct RGB fg readback matching the fed value (SGR 38;2 reference cells A and B)",
  ],
  [
    "sgr.fg.truecolor",
    ["C", "A", "B", "X", "Y"],
    "sgr.fg.truecolor: two distinct direct-RGB samples are exposed at their exact requested values",
    "independent fg color controls (SGR 31 and 34) distinguishable in the headless readback",
  ],
  [
    "extensions.truecolor",
    ["C", "A", "B", "X", "Y"],
    "Two distinct direct-RGB foreground samples match their requested values",
    "independent foreground color controls (SGR 31 and 34) distinguishable in the headless readback",
  ],
  [
    "erase.el-with-attrs",
    ["X", "X", "X", "X", "X"],
    null, // Unpainted setup cannot establish an erase claim.
    "Test broken: the background colour we painted before the test did not show (expected it on 5 screen cells, read none).",
  ],
  [
    "editing.decsace",
    [..."abcdefghijklmnop"],
    "DECSACE rectangle extent confines DECCARA to the 2x2 block; stream extent reaches the rest of the reading-order span",
    "DECCARA not honoured, extent unobservable",
  ],
  [
    "modes.left-right-margin",
    [..."ABCDEFGH"],
    "Left-right margin mode constrains horizontal operations: ICH at column 3 under DECSLRM 3;6 drops F at column 6 and leaves G and H in columns 7-8",
    "ICH shifting row 1 right from column 3 in the headless readback (control frame not calibrated)",
  ],
] as const

test.each(headlessStateFeatures)(
  "%s distinguishes failed setup from unexposed headless colour/reset/buffer state",
  (id, chars, expected, reason) => {
    const definition = ALL_PROBES.find((probe) => probe.id === id)
    if (!definition?.lib) throw new Error(`missing headless ${id}`)
    const result = definition.lib({
      ...context(),
      getScrollback: () => ({ screenLines: 24, totalLines: 24 }),
      getCell: (row: number, col: number) => ({
        char: (row === 0 ? chars[col] : row === 1 ? chars[8 + col] : undefined) ?? " ",
        fg: null,
        bg: null,
        bold: false,
        dim: null,
        italic: null,
        underline: false,
        underlineColor: null,
        inverse: false,
        strikethrough: false,
        blink: false,
        overline: false,
        hidden: false,
        wide: false,
      }),
    } as unknown as LibProbeSource)
    expect(result.pass).toBe(false)
    if (expected === null) {
      expect(result.notTested).toBeUndefined()
      expect(result.criterionBranch).toBeUndefined()
      expect(result.tests).toEqual([
        { id: "criterion", status: "probe-invalid", reason: expect.stringContaining(reason) },
      ])
      expect(result.observation).toBeUndefined()
      expect(result.assertions).toBeUndefined()
      return
    }
    // Missing underline colour and compound reset retain their named unexposed state. Other painted setups
    // here have no same-path control; none of these coverage records decides a grade or emits a negative.
    const noObservable =
      id === "sgr.selective-reset.italic" || id === "sgr.underline.color" || id === "sgr.underline-color-indexed"
        ? reason
        : NO_SAME_PATH_CONTROL
    expect(result.notTested).toEqual({ reason: "no-semantic-observable", noObservable })
    expect(result.criterionBranch).toBeUndefined()
    expect(result.tests).toBeUndefined()
    expect(result.observation).toBeUndefined()
    expect(result.assertions).toBeUndefined()
    expect((result.response ?? "").length).toBeGreaterThan(0)
  },
)

test("the 2 remaining headless not-tested features emit named coverage from measured state", () => {
  expect(notTestedFeatures).toHaveLength(2)
  for (const id of notTestedFeatures) {
    const definition = ALL_PROBES.find((probe) => probe.id === id)
    if (!definition?.lib) throw new Error(`missing headless ${id}`)
    const result = definition.lib(context())
    expect(result.notTested, id).toEqual({ reason: "no-semantic-observable", noObservable: expect.any(String) })
    expect((result.notTested?.noObservable ?? "").trim().length, id).toBeGreaterThan(0)
    expect((result.response ?? "").length, id).toBeGreaterThan(0)
    expect(result.observation, id).toBeUndefined()
    expect(result.assertions, id).toBeUndefined()
  }
})

const c154SemanticMarkFeatures = [
  ["extensions.osc133-a", "\x1b]133;A\x07"],
  ["extensions.osc133-b", "\x1b]133;B\x07"],
  ["extensions.osc133-c", "\x1b]133;C\x07"],
  ["extensions.osc133-d", "\x1b]133;D;0\x07"],
  ["extensions.osc133-p", "\x1b]133;P\x07"],
  ["extensions.osc633-a", "\x1b]633;A\x07"],
  ["extensions.osc633-b", "\x1b]633;B\x07"],
  ["extensions.osc633-c", "\x1b]633;C\x07"],
  ["extensions.osc633-e", "\x1b]633;E;ls -la;nonce123\x07", "OSC 633;E commandline-with-nonce mark registration"],
] as const

test("the 9 headless C154 semantic-mark features emit named coverage only after recorded home/marker/control writes and qualified cursor reads", () => {
  // osc633-d and osc633-p read their own reader routes (#32247), covered in extensions-contract.test.ts.
  expect(c154SemanticMarkFeatures).toHaveLength(9)
  for (const [id, sequence, noObservable] of c154SemanticMarkFeatures) {
    const definition = ALL_PROBES.find((probe) => probe.id === id)
    if (!definition?.lib) throw new Error(`missing headless ${id}`)
    const fed: string[] = []
    const reads = [
      { x: 0, y: 0, visible: true, style: null },
      { x: 1, y: 0, visible: true, style: null },
      { x: 0, y: 0, visible: true, style: null },
    ]
    let read = 0
    const result = definition.lib({
      ...context(),
      feed: (text: string) => {
        fed.push(text)
      },
      getCursor: () => reads[read++] ?? reads[2]!,
    })
    expect(fed, id).toEqual(["\x1b[1;1H", `${sequence}X`, "\x1b[1;1H"])
    expect(read, id).toBe(3)
    expect(result.notTested, id).toEqual({
      reason: "no-semantic-observable",
      noObservable: noObservable ?? NO_SAME_PATH_CONTROL,
    })
    expect(result.criterionBranch, id).toBe(SEMANTIC_PROMPT_SOURCE_REVIEW)
    expect(result.tests, id).toEqual([
      {
        id: "review",
        status: "probe-todo",
        reason: noObservable
          ? "Open: the library did not print the shell property and command-line marks (OSC 133 P, 633 E) as text, but our test cannot read them back."
          : "Open: the shell's prompt mark (OSC 133 / 633) did not show up on screen as stray text, but our test has no way to read marks back, so we cannot tell whether the library kept it.",
      },
    ])
    expect(JSON.parse(result.response ?? "{}"), id).toEqual({
      home: reads[0],
      target: reads[1],
      control: reads[2],
      cell: "X",
    })
    expect(result.observation, id).toBeUndefined()
    expect(result.assertions, id).toBeUndefined()
  }
})
