/** Collect private v2 headless runs from the same Termless adapters as the diagnostic suite. */
/* oxlint-disable typescript/no-deprecated -- Current Termless resolve() adapters expose TerminalBackend lifecycle; Emulator does not yet replace that loader. */

import { execFileSync } from "node:child_process"
import { randomUUID } from "node:crypto"
import {
  linkSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs"
import { release, tmpdir } from "node:os"
import { basename, dirname, join, resolve } from "node:path"
import { pathToFileURL, fileURLToPath } from "node:url"
import { manifest, type TerminalBackend } from "@termless/core"
import {
  ALL_PROBES,
  initializeRunDraft,
  recordCollectionFailure,
  recordCollectorSelection,
  resolveProbeIds,
  recordCollectorAttempt,
  readCollectorSelection,
  readCollectorAttempt,
  type RunDraft,
  type CapturedRunDraft,
} from "@terminfo/probe-defs"
import { canonicalJson, parseRun, parseSuiteManifest } from "@terminfo/run-parser"
import { derivedSuiteManifest, probeSuiteSnapshot } from "../admin/versions.ts"
import { saveDaemonProbeRun } from "../terminfo.dev/src/capture-writer.ts"
import { unauditedAdapterSourceDiagnostic } from "../probe-defs/src/helpers.ts"
import { collectBatch, errorMessage, finalizeHeadlessAttempt } from "./headless-batch.ts"
import { HEADLESS_TERMINAL, declaredHostInputs } from "./headless-terminal.ts"
import { owningCheckout } from "./termless-root.ts"

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../..")
// One engine's whole suite. Kitty needs about 110-125 s at nice 10 under host load (31693), so 120 s killed it at
// probe ~268 of 273; 600 s still stops a hung worker.
const WORKER_TIMEOUT_MS = 600_000
const WORKER_STOP_GRACE_MS = 2_000

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

/**
 * Strip collecting-host folder prefixes from diagnostics recorded in a run draft while keeping the
 * file or directory name (#30591). Re-thrown errors and stderr files keep the full path for local diagnosis.
 */
function scrubRecordedFailure(diagnostic: string): string {
  return diagnostic.replace(
    /(?:file:\/\/\/[^\s"'`:;,()[\]{}]+|(?<![\w.~/\\-])[A-Za-z]:\\[^\s"'`:;,()[\]{}]+|(?<![\w.~/-])\/[^\s"'\\`:;,()[\]{}]+)/g,
    (match) => {
      if (match.startsWith("//")) return match
      const clean = match.replace(/^file:\/\//, "").replaceAll("\\", "/")
      if (
        !/^[A-Za-z]:\//.test(clean) &&
        !clean.replace(/\/+$/, "").slice(1).includes("/") &&
        !/^\/(?:hh|home|Users|tmp|var|private|opt|root|mnt|Volumes|nix)\/?$/.test(clean)
      ) {
        return match
      }
      return basename(clean) || clean
    },
  )
}

function loadedBackend(value: unknown, specifier: string): TerminalBackend {
  if (
    !record(value) ||
    typeof value.init !== "function" ||
    typeof value.feed !== "function" ||
    typeof value.getCell !== "function" ||
    typeof value.reset !== "function" ||
    typeof value.destroy !== "function"
  ) {
    throw new Error(`${specifier} resolve() did not return a Termless backend`)
  }
  return value as unknown as TerminalBackend
}

export interface HeadlessCollection {
  directory: string
  suiteManifest?: string
  requested: string[]
  runs: string[]
  failures: Array<{ backend: string; package: string; error: string }>
}

/**
 * A headless collection derives its LIVE suite snapshot, never from a stored declaration.
 * It retains that declaration in its private output for later run and probe evidence reads.
 * Admission separately declares manifests alongside accepted runs; retaining private evidence
 * neither admits a run nor makes it an accepted result.
 */
function trustedSuite() {
  const suite = probeSuiteSnapshot()
  const callbackIds = ALL_PROBES.filter((probe) => probe.lib !== null)
    .map((probe) => probe.id)
    .sort()
  if (callbackIds.join("\n") !== [...suite.probes.lib].sort().join("\n")) {
    throw new Error(`Headless callback membership differs from the live suite ${suite.probeHash}`)
  }
  return suite
}

/** The same collector runs in a fresh process for each engine: a native abort cannot hide another engine. */
async function collectOne(name: string, directory: string): Promise<string> {
  const entry = manifest().backends[name]
  if (!entry || entry.type === "os") throw new Error(`Unknown or OS-only headless backend ${name}`)
  const suite = trustedSuite()
  const sourceRevision = execFileSync("git", ["rev-parse", "HEAD"], { cwd: ROOT, encoding: "utf8" }).trim()
  const sourcePaths = new Set([
    ...probeSuiteSnapshot().sourcePaths,
    "packages/run-parser/src",
    "packages/run-parser/package.json",
    "packages/probes/collect-headless.ts",
    "packages/probes/headless-batch.ts",
    "packages/probes/headless-identity.ts",
    "packages/admin/src/termless.ts",
    "packages/admin/versions.ts",
    "packages/admin/suite-manifest.ts",
  ])
  const sourceDirty =
    execFileSync("git", ["status", "--porcelain", "--", ...sourcePaths], { cwd: ROOT, encoding: "utf8" })
      .toString()
      .trim().length > 0
  const draft = initializeRunDraft({
    source: { kind: "live" },
    runId: process.env.TERMINFO_CAPTURE_RUN_ID ?? randomUUID(),
    sourceRevision,
    manifest: derivedSuiteManifest(suite),
    intendedSubject: { kind: "lib", id: name, os: process.platform },
  })
  const draftPath = process.env.TERMINFO_DRAFT_PATH ?? join(directory, `${name}-${draft.runId}.draft.json`)
  const delegated = process.env.TERMINFO_DRAFT_PATH
    ? (JSON.parse(readFileSync(draftPath, "utf8")) as RunDraft)
    : undefined
  const ids = readCollectorSelection(delegated?.rawReplies ?? {})?.ids ?? [...suite.probes.lib]
  const resolved = resolveProbeIds(ids)
  if (resolved.result === "invalid") {
    throw new Error(`Unknown probe: ${resolved.unknownIds[0] ?? resolved.duplicateIds[0]}`)
  }
  recordCollectorSelection(draft, ids)
  const initialBytes = `${JSON.stringify(draft, null, 2)}\n`
  if (process.env.TERMINFO_DRAFT_PATH) {
    if (process.env.TERMINFO_DRAFT_PATH !== draftPath || readFileSync(draftPath, "utf8") !== initialBytes) {
      throw new Error("Delegated headless draft differs from initialized writer handoff")
    }
  } else writeFileSync(draftPath, initialBytes, { flag: "wx" })
  const checkpoint = () => writeFileSync(draftPath, `${JSON.stringify(draft, null, 2)}\n`)
  if (ids.length === 0) {
    recordCollectorAttempt(draft, { ids, result: "empty" })
    checkpoint()
    return draftPath
  }
  let collectionStartedAt: string | undefined
  let backend: TerminalBackend | undefined
  try {
    const { headlessRuntimeIdentity, readAdapterSources, verifyAdapterSources } = await import("./headless-identity.ts")
    if (name === "kitty" && !process.env.KITTY_BINARY) {
      throw new Error("Kitty requires KITTY_BINARY from a pinned Nix shell")
    }
    let adapterPath: string
    try {
      adapterPath = realpathSync(Bun.resolveSync(entry.package, import.meta.path))
    } catch (cause) {
      throw new Error(`${name} requires installed ${entry.package} in the owned source workspace`, { cause })
    }
    // The loaded adapter must belong to the checkout that tracks it; the call refuses otherwise.
    owningCheckout(adapterPath, entry.package)
    const mod: unknown = await import(pathToFileURL(adapterPath).href)
    if (!record(mod) || typeof mod.resolve !== "function") {
      throw new Error(`${entry.package} does not export resolve()`)
    }
    const resolveBackend = mod.resolve as () => Promise<unknown>
    collectionStartedAt = new Date().toISOString()
    recordCollectorAttempt(draft, {
      result: "started",
      startedAt: collectionStartedAt,
      ids,
      hostInputs: declaredHostInputs(),
    })
    checkpoint()
    const loaded = loadedBackend(await resolveBackend(), entry.package)
    backend = loaded
    loaded.init(HEADLESS_TERMINAL)
    loaded.getCell(0, 0)
    // An engine that reports its own clipboard_control (Termless kitty) declares the read permission it runs under.
    const clipboardControl =
      typeof loaded.getClipboardState === "function" ? loaded.getClipboardState().control : undefined
    if (clipboardControl !== undefined) {
      recordCollectorAttempt(draft, {
        result: "started",
        startedAt: collectionStartedAt,
        ids,
        hostInputs: declaredHostInputs(clipboardControl),
      })
      checkpoint()
    }
    const runtimeIdentity = await headlessRuntimeIdentity(name, entry.package, entry.type)
    runtimeIdentity.adapterSources = readAdapterSources(name, loaded)
    verifyAdapterSources(name, {
      identity: runtimeIdentity,
      adapterPath,
      adapterPackage: entry.package,
      adapterType: entry.type,
    })
    const unaudited = unauditedAdapterSourceDiagnostic(name, runtimeIdentity)
    if (unaudited) process.stderr.write(`${unaudited}\n`)
    draft.runtimeIdentity = runtimeIdentity
    checkpoint()
    backend = undefined
    loaded.destroy()
    const batch = await collectBatch(
      async () => loadedBackend(await resolveBackend(), entry.package),
      name,
      resolved.probes,
      draft,
      (progress) => {
        Object.assign(draft, {
          results: progress.results,
          rawReplies: { ...draft.rawReplies, ...progress.rawReplies },
          assertions: progress.assertions,
        })
        checkpoint()
      },
      { identity: runtimeIdentity, adapterPath, adapterPackage: entry.package, adapterType: entry.type },
    )
    const startedAttempt = readCollectorAttempt(draft.rawReplies)
    const completedAttempt = {
      ids,
      startedAt: collectionStartedAt,
      ...(startedAttempt?.hostInputs && { hostInputs: startedAttempt.hostInputs }),
      result: "completed" as const,
    }
    finalizeHeadlessAttempt(draft, completedAttempt, resolved.probes)
    // Batch metadata includes the start checkpoint; retain the completed outcome above.
    const completedBatch = { ...draft, rawReplies: batch.rawReplies }
    finalizeHeadlessAttempt(completedBatch, completedAttempt, resolved.probes)
    batch.rawReplies = completedBatch.rawReplies
    checkpoint()
    const run: CapturedRunDraft = {
      ...draft,
      subject: {
        kind: "lib",
        id: name,
        version: runtimeIdentity.engineVersion,
        os: process.platform,
        osVersion: release(),
        outerTerminal: null,
        mux: null,
        config: "80x24 default Termless backend",
        permissions: null,
      },
      // Every collector decoder requires an unverified collector draft; admission's identityMatch verifies
      // headless identity from runtimeIdentity, so the collector never claims "verified" itself.
      identity: "unverified",
      runtimeIdentity,
      suiteId: suite.probeHash,
      probeHash: suite.probeHash,
      sourceRevision: sourceDirty ? `${sourceRevision}+dirty` : sourceRevision,
      measuredAt: new Date().toISOString(),
      origin: { kind: "collector" },
      rawReplies: { ...draft.rawReplies, ...batch.rawReplies },
      assertions: batch.assertions,
      results: batch.results,
      screenshotRefs: [],
    }
    const path = join(directory, `${name}-${run.runId}.capture.json`)
    const bytes = `${JSON.stringify(run, null, 2)}\n`
    parseRun(path, bytes, suite.catalogIds, new Map([[suite.probeHash, suite]]))
    writeFileSync(path, bytes, { flag: "wx" })
    return path
  } catch (error) {
    const diagnostic = scrubRecordedFailure(errorMessage(error))
    try {
      finalizeHeadlessAttempt(
        draft,
        {
          ...readCollectorAttempt(draft.rawReplies),
          ids,
          ...(collectionStartedAt && { startedAt: collectionStartedAt }),
          result: "failed",
          error: diagnostic,
        },
        resolved.probes,
      )
    } catch (finalizationError) {
      draft.rawReplies["collector.finalizationFailure"] = scrubRecordedFailure(errorMessage(finalizationError))
      process.stderr.write(`Attempt finalization refused after ${diagnostic}: ${errorMessage(finalizationError)}\n`)
    }
    if (collectionStartedAt) recordCollectionFailure(draft, collectionStartedAt, diagnostic, ids)
    else {
      draft.rawReplies["collector.prerequisite"] = diagnostic
      for (const result of draft.results) {
        if (result.status === "probe-todo" && ids.includes(result.featureId)) result.reason = diagnostic
      }
    }
    checkpoint()
    throw error
  } finally {
    backend?.destroy()
  }
}

export async function collectHeadlessRuns(
  selectors: string[] = [],
  outputDirectory?: string,
  initializations?: ReadonlyMap<string, { draft: RunDraft; path: string }>,
  probeIds?: readonly string[],
): Promise<HeadlessCollection> {
  const backends = manifest().backends
  const osOnly = Object.entries(backends)
    .filter(([, value]) => value.type === "os")
    .map(([name]) => name)
  if (osOnly.join(",") !== "peekaboo") {
    throw new Error(`Expected peekaboo as the sole OS automation backend; found ${osOnly.join(", ")}`)
  }
  const headless = Object.keys(backends).filter((name) => backends[name]?.type !== "os")
  if (headless.length !== 11) throw new Error(`Expected 11 headless engines; found ${headless.length}`)
  const requested = selectors.length ? selectors : headless
  if (new Set(requested).size !== requested.length) throw new Error("Duplicate headless backend selector")
  const unknown = requested.filter((name) => !headless.includes(name))
  if (unknown.length) throw new Error(`Unknown headless backend selector(s): ${unknown.join(", ")}`)
  const suite = trustedSuite()
  const ids = probeIds === undefined ? [...suite.probes.lib] : [...probeIds]
  const resolved = resolveProbeIds(ids)
  if (resolved.result === "invalid") {
    throw new Error(`Unknown probe: ${resolved.unknownIds[0] ?? resolved.duplicateIds[0]}`)
  }
  const script = realpathSync(fileURLToPath(import.meta.url))
  if (!script.endsWith("/packages/probes/collect-headless.ts")) {
    throw new Error(`Packaged CLI has no local headless collector source at ${script}; install the source workspaces`)
  }
  const directory = outputDirectory ?? mkdtempSync(join(tmpdir(), "terminfo-headless-v3-"))
  mkdirSync(directory, { recursive: true })
  if (readdirSync(directory).length > 0) throw new Error(`Headless output directory is not empty: ${directory}`)
  const suiteManifest = `suites/${suite.probeHash}.json`
  const suiteManifestPath = join(directory, suiteManifest)
  const manifestBytes = `${canonicalJson(derivedSuiteManifest(suite))}\n`
  const retainedManifest = parseSuiteManifest(suiteManifestPath, manifestBytes)
  if (retainedManifest.probeHash !== suite.probeHash) {
    throw new Error(
      `${suiteManifestPath}: retained suite ${retainedManifest.probeHash} disagrees with producer suite ${suite.probeHash}`,
    )
  }
  mkdirSync(dirname(suiteManifestPath))
  writeFileSync(suiteManifestPath, manifestBytes, { flag: "wx" })
  const runs: string[] = []
  const failures: HeadlessCollection["failures"] = []

  for (const name of requested) {
    const entry = backends[name]
    if (!entry) throw new Error(`Manifest lost expected headless backend ${name}`)
    const stdoutPath = join(directory, `${name}.stdout.txt`)
    const stderrPath = join(directory, `${name}.stderr.txt`)
    const sourceRevision = execFileSync("git", ["rev-parse", "HEAD"], { cwd: ROOT, encoding: "utf8" }).trim()
    const handed = initializations?.get(name)
    const delegated =
      handed?.draft ??
      initializeRunDraft({
        source: { kind: "live" },
        runId: randomUUID(),
        sourceRevision,
        manifest: derivedSuiteManifest(suite),
        intendedSubject: { kind: "lib", id: name, os: process.platform },
      })
    const draftPath = handed?.path ?? join(directory, `${name}-${delegated.runId}.draft.json`)
    if (handed) {
      if (readFileSync(draftPath, "utf8") !== `${JSON.stringify(delegated, null, 2)}\n`) {
        throw new Error(`Headless ${name} initial writer handoff differs`)
      }
    }
    recordCollectorSelection(delegated, ids)
    writeFileSync(draftPath, `${JSON.stringify(delegated, null, 2)}\n`, handed ? undefined : { flag: "wx" })
    if (ids.length === 0) {
      recordCollectorAttempt(delegated, { ids, result: "empty" })
      writeFileSync(draftPath, `${JSON.stringify(delegated, null, 2)}\n`)
      continue
    }
    let workerStartedAt: string | undefined
    const retainFailure = (diagnostic: string, result: "failed" | "cancelled" = "failed") => {
      const scrubbed = scrubRecordedFailure(diagnostic)
      const retained = JSON.parse(readFileSync(draftPath, "utf8")) as RunDraft
      if (
        retained.runId !== delegated.runId ||
        retained.probeHash !== suite.probeHash ||
        retained.sourceRevision !== sourceRevision
      ) {
        throw new Error(`Worker ${name} changed delegated run identity`)
      }
      const previousAttempt = readCollectorAttempt(retained.rawReplies)
      if (previousAttempt?.result === "completed") return
      const primaryDiagnostic = previousAttempt?.error ?? retained.rawReplies["collector.failure"] ?? scrubbed
      const startedAt =
        previousAttempt?.startedAt ?? (retained.rawReplies["collector.prerequisite"] ? undefined : workerStartedAt)
      if (!startedAt && result === "failed" && !retained.rawReplies["collector.prerequisite"]) {
        retained.rawReplies["collector.prerequisite"] = scrubbed
        for (const row of retained.results) {
          if (row.status === "probe-todo" && ids.includes(row.featureId)) row.reason = scrubbed
        }
      }
      try {
        if (previousAttempt?.result !== "failed" && previousAttempt?.result !== "cancelled") {
          finalizeHeadlessAttempt(
            retained,
            {
              ...previousAttempt,
              ids,
              ...(startedAt && { startedAt }),
              result,
              error: primaryDiagnostic,
            },
            resolved.probes,
          )
        }
      } catch (finalizationError) {
        retained.rawReplies["collector.finalizationFailure"] = scrubRecordedFailure(errorMessage(finalizationError))
        process.stderr.write(
          `Attempt finalization refused after ${primaryDiagnostic}: ${errorMessage(finalizationError)}. Coordinator: ${scrubbed}\n`,
        )
      }
      if (result === "failed" && startedAt && !retained.rawReplies["collector.prerequisite"]) {
        recordCollectionFailure(retained, startedAt, primaryDiagnostic, ids)
      } else if (retained.rawReplies["collector.prerequisite"]) {
        retained.rawReplies["collector.prerequisite"] = scrubRecordedFailure(
          retained.rawReplies["collector.prerequisite"],
        )
        for (const result of retained.results) {
          if (result.status === "probe-todo" && result.reason) {
            result.reason = scrubRecordedFailure(result.reason)
          }
        }
      }
      writeFileSync(draftPath, `${JSON.stringify(retained, null, 2)}\n`)
    }
    try {
      const child = Bun.spawn([process.execPath, script, "--one", name, directory], {
        cwd: ROOT,
        env: { ...process.env, TERMINFO_CAPTURE_RUN_ID: delegated.runId, TERMINFO_DRAFT_PATH: draftPath },
        stdout: "pipe",
        stderr: "pipe",
      })
      workerStartedAt = new Date().toISOString()
      let exited = false
      let timedOut = false
      let forceTimer: ReturnType<typeof setTimeout> | undefined
      const exit = child.exited.then((code) => {
        exited = true
        return code
      })
      const deadlineTimer = setTimeout(() => {
        if (exited) return
        timedOut = true
        child.kill("SIGTERM")
        forceTimer = setTimeout(() => {
          if (!exited) child.kill("SIGKILL")
        }, WORKER_STOP_GRACE_MS)
      }, WORKER_TIMEOUT_MS)
      const [stdout, stderr, exitCode] = await Promise.all([
        new Response(child.stdout).text(),
        new Response(child.stderr).text(),
        exit,
      ]).finally(() => {
        clearTimeout(deadlineTimer)
        if (forceTimer) clearTimeout(forceTimer)
      })
      writeFileSync(stdoutPath, stdout, { flag: "wx" })
      writeFileSync(stderrPath, stderr, { flag: "wx" })
      if (timedOut) {
        retainFailure(
          `Worker ${name} exceeded ${WORKER_TIMEOUT_MS}ms and exited ${exitCode}; stdout=${stdoutPath} stderr=${stderrPath}`,
        )
        failures.push({
          backend: name,
          package: entry.package,
          error: `Worker exceeded ${WORKER_TIMEOUT_MS}ms and exited ${exitCode}; stdout=${stdoutPath} stderr=${stderrPath}`,
        })
        continue
      }
      if (exitCode !== 0) {
        const lines = stderr
          .split("\n")
          .map((line) => line.trim())
          .filter(Boolean)
        const detail =
          lines.find((line) => line.includes("panicked at")) ??
          lines.find((line) => /^(?:Error|error):/.test(line)) ??
          lines.find((line) => line.startsWith("ENOENT:")) ??
          lines.at(-1) ??
          "no stderr"
        retainFailure(
          `Worker exited ${exitCode}: ${detail}; stderr=${stderrPath}`,
          exitCode === 130 || exitCode === 143 ? "cancelled" : "failed",
        )
        failures.push({
          backend: name,
          package: entry.package,
          error: `Worker exited ${exitCode}: ${detail}; stderr=${stderrPath}`,
        })
        continue
      }
      const candidates = readdirSync(directory).filter(
        (file) => file.startsWith(`${name}-`) && file.endsWith(".capture.json"),
      )
      const [candidate] = candidates
      if (candidates.length !== 1 || !candidate) {
        throw new Error(
          `Worker exited 0 but wrote ${candidates.length} raw runs; stdout=${stdoutPath} stderr=${stderrPath}`,
        )
      }
      const path = join(directory, candidate)
      const parsed = parseRun(
        path,
        readFileSync(path, "utf8"),
        ALL_PROBES.map((probe) => probe.id),
        new Map([[suite.probeHash, suite]]),
      )
      if (parsed.subject.kind !== "lib" || parsed.subject.id !== name) {
        throw new Error(`Worker wrote a run for ${parsed.subject.id} instead of ${name}: ${path}`)
      }
      if (parsed.runId !== delegated.runId) throw new Error(`Worker ${name} changed runId during capture handoff`)
      const unaudited = unauditedAdapterSourceDiagnostic(name, parsed.runtimeIdentity)
      if (unaudited) process.stderr.write(`${unaudited}\n`)
      const captured = JSON.parse(readFileSync(path, "utf8")) as CapturedRunDraft
      recordCollectorSelection(captured, ids)
      const capturedAttempt = readCollectorAttempt(captured.rawReplies)
      if (capturedAttempt?.result !== "completed") {
        finalizeHeadlessAttempt(
          captured,
          {
            ids,
            startedAt: capturedAttempt?.startedAt ?? workerStartedAt,
            ...(capturedAttempt?.hostInputs && { hostInputs: capturedAttempt.hostInputs }),
            result: "completed",
          },
          resolved.probes,
        )
      }
      const finalPath = saveDaemonProbeRun(captured, directory)
      const finalizedBytes = readFileSync(finalPath, "utf8")
      parseRun(finalPath, finalizedBytes, suite.catalogIds ?? [], new Map([[suite.probeHash, suite]]))
      // One record per engine (32783): when the writer kept the worker's bytes unchanged the capture is a
      // duplicate, so it becomes a hardlink to the canonical draft and the bytes are stored once. When
      // finalization DID change them, the capture is the worker's only evidence of what it produced and
      // stays a separate file. The initialized draft is dead once the worker exited, unless a caller
      // handed us its path.
      if (finalizedBytes === readFileSync(path, "utf8")) {
        const linked = `${path}.linked`
        linkSync(finalPath, linked)
        renameSync(linked, path)
      }
      if (!handed) rmSync(draftPath, { force: true })
      runs.push(finalPath)
    } catch (error) {
      retainFailure(errorMessage(error))
      failures.push({ backend: name, package: entry.package, error: errorMessage(error) })
    }
  }

  const collection: HeadlessCollection = { directory, suiteManifest, requested, runs, failures }
  writeFileSync(join(directory, "collection.json"), `${JSON.stringify(collection, null, 2)}\n`, { flag: "wx" })
  return collection
}

if (import.meta.main) {
  try {
    const [mode, name, directory] = process.argv.slice(2)
    if (mode !== "--one" || !name || !directory || process.argv.length !== 5) {
      throw new Error("Usage: bun packages/probes/collect-headless.ts --one BACKEND OUTPUT_DIRECTORY")
    }
    await collectOne(name, directory)
  } catch (error) {
    console.error(error)
    process.exitCode = 1
  }
}
