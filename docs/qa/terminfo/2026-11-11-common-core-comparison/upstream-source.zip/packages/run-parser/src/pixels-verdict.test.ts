/**
 * @failure A collector run is admitted carrying a pixel probe result that cannot be recomputed from its own frames, or a tampered frame set passes the same rules.
 * @level l2
 * @consumer Every consumer of parseRun: the site matrix, generated analysis, status, admission and the reviewed census.
 * @reach fs-walk vendor/terminfo.dev/content/suites/*.json
 * @reach fs-walk vendor/terminfo.dev/content/probes-apps/*.json vendor/terminfo.dev/content/probes-libs/*.json
 * @reach fs-walk vendor/terminfo.dev/content/probes-mux/*.json
 * @testonly none
 */
import { createHash } from "node:crypto"
import { readFileSync, readdirSync } from "node:fs"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"
import { describe, expect, it } from "vitest"
import {
  recordExecutedProbe,
  initializeRunDraft,
  frameDigests,
  cursorProbes,
  editingProbes,
  extensionsProbes,
  modesProbes,
  type ObservationFrame,
  type ProbeSuiteManifest,
  type ProbeCallbackResult,
  type TermProbeSource,
} from "@terminfo/probe-defs"
import { parseRun, parseSuiteManifest } from "./index.ts"

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..")
const digest = (seed: string) => `sha256:${createHash("sha256").update(seed).digest("hex")}`
const FEATURE = "editing.delete-chars"
const SUITE = "452ac343b55d"
const TARGET = {
  kind: "term",
  id: "kitty",
  version: "0.49.2",
  os: "linux",
  osVersion: null,
  outerTerminal: null,
  mux: null,
  config: null,
  permissions: null,
} as const
const manifest: ProbeSuiteManifest & { schemaVersion: 4 } = {
  schemaVersion: 4,
  catalogIds: [FEATURE],
  probeHash: SUITE,
  adapterVersion: "3.3.1",
  generatedAt: "2026-10-10T22:00:00.000Z",
  probes: { term: [FEATURE], lib: [], mux: [] },
}
const suites = new Map([[SUITE, manifest]])
const catalog = [FEATURE]

const frame = (
  role: ObservationFrame["role"],
  label: string,
  capturedAt: number,
  ref: string,
  regionDigest?: string,
  pixelsDigest?: string,
): Extract<ObservationFrame, { kind?: "pixels" }> => ({
  role,
  label,
  capturedAt,
  ref,
  ...(regionDigest && { regionDigest }),
  ...(pixelsDigest && { pixelsDigest }),
})

const SEED_REGION = digest("kitty:seed-region")

/**
 * The shape kitty linux emitted in the S+1 freeze (collector 452ac343b55d): six frames behind a
 * paint witness, where the target's cell-aligned regionDigest equals the expected frame's — the
 * real run cites sha256:88a04fcc… for both, which is exactly what the assertion binds.
 */
const kittyFrames = (): ObservationFrame[] => [
  frame("control", `${FEATURE}: pre-edit seed — paint witness`, 1, digest("c0"), SEED_REGION, digest("seed-px")),
  frame("control", `${FEATURE}: pre-edit seed`, 2, digest("c0"), digest("seed-measured"), digest("seed-px")),
  frame(
    "control",
    `${FEATURE}: post-sequence target — paint witness`,
    3,
    digest("t"),
    digest("after-witness"),
    digest("after-px"),
  ),
  frame("target", `${FEATURE}: post-sequence target`, 4, digest("t"), digest("after-region"), digest("after-px")),
  frame(
    "control",
    `${FEATURE}: expected frame — paint witness`,
    5,
    digest("e1"),
    digest("expected-witness"),
    digest("expected-px"),
  ),
  frame("control", `${FEATURE}: expected frame`, 6, digest("e2"), digest("after-region"), digest("expected-px")),
]

/**
 * The shape wezterm linux emitted for erase.screen.scrollback: five frames with no region digest
 * at all, and an assertion whose observed JSON cites four of the frames by ref — the equality of
 * capture refs is the entire probe result.
 */
const scrollbackFrames = (): ObservationFrame[] => [
  frame("control", "Bottom of seeded buffer", 1, digest("bottom")),
  frame("control", "After wheel-up before ED3", 2, digest("history")),
  frame("control", "After wheel-down before ED3", 3, digest("bottom")),
  frame("control", "After ED3 at bottom", 4, digest("erased")),
  frame("target", "After ED3 then wheel-up", 5, digest("erased")),
]

const kittyRun = (overrides: Record<string, unknown> = {}) => {
  const frames = kittyFrames()
  const draft = initializeRunDraft({
    runId: "shape-a-kitty",
    sourceRevision: "4".repeat(40),
    manifest,
    source: { kind: "live" },
    intendedSubject: { kind: "term", id: "kitty" },
  })
  draft.subject = TARGET
  draft.identity = "unverified"
  draft.measuredAt = "2026-10-10T22:10:00.000Z"
  draft.origin = { kind: "collector" }
  const attempt = { scope: "probe" as const, startedAt: draft.measuredAt }
  return {
    ...draft,
    subject: TARGET,
    rawReplies: { [FEATURE]: JSON.stringify({ writes: ["\u001b[1;3H"], queries: [], events: [] }) },
    assertions: [
      {
        featureId: FEATURE,
        kind: "positive",
        assertionType: "screenshot",
        rawReplyRef: FEATURE,
        expected: `${FEATURE}: the cell-aligned region equals the same-run expected frame`,
        observed: digest("after-region"),
      },
    ],
    screenshotRefs: [digest("c0"), digest("t"), digest("e1"), digest("e2")],
    results: [
      {
        featureId: FEATURE,
        status: "supported",
        assertionType: "screenshot",
        attempt,
        tests: [{ id: "criterion", status: "supported", attempt, assertionRefs: [0] }],
        screenshotRef: digest("t"),
        rawReplyRef: FEATURE,
        frames,
      },
    ],
    ...overrides,
  }
}

const scrollbackRun = () => ({
  ...kittyRun(),
  runId: "shape-a-wezterm",
  rawReplies: { [FEATURE]: JSON.stringify({ writes: [], queries: [], events: [] }) },
  assertions: [
    {
      featureId: FEATURE,
      kind: "positive",
      assertionType: "screenshot",
      rawReplyRef: FEATURE,
      expected: "the erased buffer is no longer reachable by wheel-up",
      observed: JSON.stringify({
        control: digest("bottom"),
        history: digest("history"),
        restored: digest("bottom"),
        erased: digest("erased"),
      }),
    },
  ],
  screenshotRefs: [digest("bottom"), digest("history"), digest("erased")],
  results: [
    {
      ...kittyRun().results[0],
      featureId: FEATURE,
      status: "supported",
      assertionType: "screenshot",
      screenshotRef: digest("erased"),
      rawReplyRef: FEATURE,
      frames: scrollbackFrames(),
    },
  ],
})

/**
 * The shape a blink run writes at the #33117 schedule: the unstyled control shot and sixteen
 * styled sample shots, each carrying its plain control region as a same-shot second crop,
 * followed by the plain entries cropped from those same shots (same ref and capturedAt, the
 * plain rectangle as their own region, no control fields — the older frame shape inside the
 * same run).
 */
const BLINK_FEATURE = "sgr.blink"
const BLINK_SUITE = "33117abcdef0"
const blinkManifest: ProbeSuiteManifest & { schemaVersion: 4 } = {
  schemaVersion: 4,
  catalogIds: [BLINK_FEATURE],
  probeHash: BLINK_SUITE,
  adapterVersion: "3.3.1",
  generatedAt: "2026-11-10T20:00:00.000Z",
  probes: { term: [BLINK_FEATURE], lib: [], mux: [] },
}
const STYLED_RECT = { x: 16, y: 32, width: 104, height: 16 }
const PLAIN_RECT = { x: 16, y: 0, width: 104, height: 16 }
const BLINK_SAMPLES = 16
const blinkFrames = (): ObservationFrame[] => {
  const start = 1_000_000
  const control: ObservationFrame = {
    ...frame(
      "control",
      "Unstyled text sample",
      start,
      digest("blink-control"),
      digest("blink-unstyled"),
      digest("blink-whole-control"),
    ),
    regionRectangle: STYLED_RECT,
    controlRegionDigest: digest("blink-plain"),
    controlRegionRectangle: PLAIN_RECT,
  }
  const styled: ObservationFrame[] = []
  const plain: ObservationFrame[] = [
    {
      ...frame(
        "control",
        "Plain line, control",
        start,
        digest("blink-control"),
        digest("blink-plain"),
        digest("blink-whole-control"),
      ),
      regionRectangle: PLAIN_RECT,
    },
  ]
  for (let index = 0; index < BLINK_SAMPLES; index++) {
    const capturedAt = start + 1000 + index * 500
    const ref = digest(`blink-sample-${index}`)
    styled.push({
      ...frame(
        "target",
        `sgr.blink styled text, sample requested at +${index * 500} ms`,
        capturedAt,
        ref,
        digest(index % 2 === 0 ? "blink-on" : "blink-off"),
        digest(`blink-whole-${index}`),
      ),
      regionRectangle: STYLED_RECT,
      controlRegionDigest: digest("blink-plain"),
      controlRegionRectangle: PLAIN_RECT,
    })
    plain.push({
      ...frame(
        "control",
        `Plain line, sample requested at +${index * 500} ms`,
        capturedAt,
        ref,
        digest("blink-plain"),
        digest(`blink-whole-${index}`),
      ),
      regionRectangle: PLAIN_RECT,
    })
  }
  return [control, ...styled, ...plain]
}
const blinkRun = () => {
  const frames = blinkFrames()
  const draft = initializeRunDraft({
    runId: "shape-blink",
    sourceRevision: "4".repeat(40),
    manifest: blinkManifest,
    source: { kind: "live" },
    intendedSubject: { kind: "term", id: "kitty" },
  })
  draft.subject = TARGET
  draft.identity = "unverified"
  draft.measuredAt = "2026-11-10T20:10:00.000Z"
  draft.origin = { kind: "collector" }
  const attempt = { scope: "probe" as const, startedAt: draft.measuredAt }
  return {
    ...draft,
    subject: TARGET,
    rawReplies: { [BLINK_FEATURE]: JSON.stringify({ writes: [], queries: [], events: [] }) },
    assertions: [
      {
        featureId: BLINK_FEATURE,
        kind: "positive",
        assertionType: "screenshot",
        rawReplyRef: BLINK_FEATURE,
        expected: "a styled digest comes back after a different one, with every plain digest identical",
        observed: JSON.stringify({ styled: [digest("blink-on"), digest("blink-off")], plain: [digest("blink-plain")] }),
      },
    ],
    screenshotRefs: [
      digest("blink-control"),
      ...Array.from({ length: BLINK_SAMPLES }, (_, index) => digest(`blink-sample-${index}`)),
    ],
    results: [
      {
        featureId: BLINK_FEATURE,
        status: "supported",
        assertionType: "screenshot",
        attempt,
        tests: [{ id: "criterion", status: "supported", attempt, assertionRefs: [0] }],
        screenshotRef: digest("blink-sample-0"),
        rawReplyRef: BLINK_FEATURE,
        frames,
      },
    ],
  }
}
const parseBlink = (run: Record<string, unknown>) =>
  parseRun("pixels-verdict-blink.json", JSON.stringify(run), [BLINK_FEATURE], new Map([[BLINK_SUITE, blinkManifest]]))

const parse = (run: Record<string, unknown>) => parseRun("pixels-verdict.json", JSON.stringify(run), catalog, suites)

function callbackFixture(id: string) {
  const writes: string[] = []
  const queries: string[] = []
  const requests: Array<Parameters<NonNullable<TermProbeSource["capture"]>>[0]> = []
  let captureIndex = 0
  const context: TermProbeSource = {
    kind: "live",
    rows: 24,
    cols: 80,
    write(sequence) {
      writes.push(sequence)
    },
    queryCursorPosition: async () => null,
    measureRenderedWidth: async () => ({ kind: "no-reply", step: "sample" }) as const,
    query: async () => null,
    queryWithSentinel: async () => null,
    queryOutcome: async () => ({ match: null, reason: "timeout", raw: "", rawBase64: "" }),
    queryWithSentinelOutcome: async (sequence) => {
      queries.push(sequence)
      return { match: null, reason: "timeout", raw: "", rawBase64: "" }
    },
    queryMode: async () => null,
    captureGeometry: {
      geometry: { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 384 },
      source: "measured by complete raster calibration",
    },
    capture: async (request) => {
      requests.push(request)
      const { role, label } = request
      captureIndex++
      if (id === "modes.decsscls") {
        // Reference/control bands match; the target band arrives between its two captures.
        const band = request.cells !== undefined && request.cells.top === request.cells.bottom
        const region = band
          ? role === "target" && label.endsWith("t0 band")
            ? "absent-band"
            : "marker-band"
          : role === "control"
            ? "control-witness"
            : `target-witness-${captureIndex}`
        return {
          ...frame(
            role,
            label,
            captureIndex,
            digest(`png-${captureIndex}`),
            digest(region),
            digest(`whole-${captureIndex}`),
          ),
          regionRectangle: { x: 16, y: 16, width: 640, height: band ? 16 : 368 },
        }
      }
      return {
        ...frame(
          role,
          label,
          captureIndex,
          digest(`png-${captureIndex}`),
          digest(
            id === "cursor.hide"
              ? captureIndex === 2
                ? "hidden-cell"
                : "shown-cell"
              : captureIndex <= 2
                ? "seed-cell"
                : `extent-cell-${captureIndex}`,
          ),
          digest(id === "editing.decsace" && captureIndex <= 2 ? "seed-whole" : `whole-${captureIndex}`),
        ),
        regionRectangle: {
          x: 16,
          y: 16,
          width: id === "editing.decsace" ? 64 : 8,
          height: id === "editing.decsace" ? 32 : 16,
        },
      }
    },
  }
  return { context, writes, queries, requests }
}

function parseCallback(id: string, result: ProbeCallbackResult, fixture: ReturnType<typeof callbackFixture>) {
  const frames = result.observation?.frames ?? []
  const assertions = (result.assertions ?? []).map((entry) => ({ ...entry, featureId: id, rawReplyRef: id }))
  const { subject, results: _old, ...metadata } = kittyRun()
  const recorded = recordExecutedProbe({
    featureId: id,
    attempt: { scope: "probe", startedAt: "2026-10-10T22:10:00.000Z" },
    rawReplyRef: id,
    ...(result.observation && { observation: { ...result.observation, featureId: id, rawReplyRef: id } }),
    assertions,
    tests: result.tests,
    criterionBranch: result.criterionBranch,
  })
  const run = {
    ...metadata,
    schemaVersion: 4,
    source: { kind: "live" },
    subject,
    intendedSubject: { kind: "term", id: subject.id },
    rawReplies: { [id]: JSON.stringify({ writes: fixture.writes, queries: fixture.queries, events: [] }) },
    assertions,
    results: [recorded],
    screenshotRefs: [
      ...frames.filter((frame) => frame.kind !== "text-cells").map((frame) => frame.ref),
      ...(result.observation?.screenshotRef ? [result.observation.screenshotRef] : []),
    ],
    textSnapshotRefs: frames.filter((frame) => frame.kind === "text-cells").map((frame) => frame.ref),
  }
  const callbackManifest: ProbeSuiteManifest = {
    ...manifest,
    schemaVersion: 4,
    catalogIds: [id],
    probes: { term: [id], lib: [], mux: [] },
  }
  return parseRun(`${id}.json`, JSON.stringify(run), [id], new Map([[SUITE, callbackManifest]]))
}

describe("in-run pixel probe results", () => {
  it("parses a decided DECSSCLS probe result whose assertion cites the region digests it compared", async () => {
    const id = "modes.decsscls"
    const probe = modesProbes.find((entry) => entry.id === id)
    if (!probe?.term) throw new Error(`Missing ${id} terminal callback`)
    const fixture = callbackFixture(id)
    const result = await probe.term(fixture.context)
    expect(result.observation?.outcome).toBe("supported")
    // Every digest the assertion cites must be a frame's ref or its cell-aligned region digest.
    const loaded = parseCallback(id, result, fixture)
    expect(loaded.results?.[0]?.status).toBe("supported")
    expect(loaded.assertions[0]?.kind).toBe("positive")
  })

  it("refuses that same DECSSCLS probe result when its assertion cites no region digest", async () => {
    const id = "modes.decsscls"
    const probe = modesProbes.find((entry) => entry.id === id)
    if (!probe?.term) throw new Error(`Missing ${id} terminal callback`)
    const fixture = callbackFixture(id)
    const result = await probe.term(fixture.context)
    const assertion = result.assertions?.[0]
    if (!assertion) throw new Error("Missing DECSSCLS assertion")
    assertion.observed = "the target pair moved between two frames of the same rectangle"
    expect(() => parseCallback(id, result, fixture)).toThrow(/must cite the frame digest it decided on/)
  })

  it.each(["cursor.hide", "editing.decsace"])(
    "parses the real %s probe result when PNG, whole-frame and cell digests differ",
    async (id) => {
      const probe = [...cursorProbes, ...editingProbes].find((entry) => entry.id === id)
      if (!probe?.term) throw new Error(`Missing ${id} terminal callback`)
      const fixture = callbackFixture(id)
      const { context } = fixture
      // Native captures carry real SHA256s for all three representations. Placeholder whole-1
      // values never reached the parser's citation scan and hid the Ghostty collector refusal.
      const result = await probe.term(context)
      expect(result.observation?.outcome).toBe("supported")
      const frames = result.observation?.frames ?? []
      const loaded = parseCallback(id, result, fixture)
      expect(loaded.results?.[0]?.status).toBe("supported")
      expect(loaded.results?.[0]?.frames).toHaveLength(3)
      if (id === "editing.decsace") {
        expect(fixture.requests).toHaveLength(4)
        for (const request of fixture.requests) {
          expect(request.cells).toEqual({ top: 1, left: 1, bottom: 2, right: 8 })
          expect(request.pixelGeometry).toEqual(context.captureGeometry?.geometry)
        }
      }
      const assertion = result.assertions?.[0]
      const pixel = frames.find((frame) => frame.kind !== "text-cells")
      if (!assertion || !pixel || !pixel.pixelsDigest) {
        throw new Error("Missing real callback citation control")
      }
      assertion.observed = pixel.pixelsDigest
      expect(() => parseCallback(id, result, fixture)).toThrow(
        `${id}.json: screenshot probe result for ${id} cites only source or whole-frame digests; a probe result must cite a frame's ref or the digest of the cells it compared`,
      )
    },
  )

  it.each([
    ["missing report", "probe-invalid", "CSI 16 t"],
    ["short grid", "probe-todo", "at least 2x8"],
    ["narrow grid", "probe-todo", "at least 2x8"],
    ["text adapter", "probe-todo", "text-cells captures"],
    ["text frame", "probe-invalid", "text-cells"],
    ["missing cells digest", "probe-invalid", "required pixel cells digest"],
    ["missing first digest", "probe-invalid", "required pixel cells digest"],
    ...[1, 2, 3, 4].map((capture) => [`crop ${capture}`, "probe-invalid", "different screen positions"]),
  ])("keeps DECSACE %s inconclusive and parser-valid", async (scenario, status, note) => {
    const id = "editing.decsace"
    const probe = editingProbes.find((entry) => entry.id === id)
    if (!probe?.term) throw new Error("Missing DECSACE callback")
    const fixture = callbackFixture(id)
    const { context } = fixture
    if (scenario === "missing report") delete context.captureGeometry
    if (scenario === "short grid") context.rows = 1
    if (scenario === "narrow grid") context.cols = 7
    if (scenario === "text adapter") context.captureKind = "text-cells"
    const capture = context.capture
    if (!capture) throw new Error("Missing fixture capture")
    let index = 0
    context.capture = async (request) => {
      const frame = await capture(request)
      index++
      if (frame.kind === "text-cells") throw new Error("Fixture must start with pixels")
      if (scenario === "text frame") {
        if (!frame.regionDigest || !frame.pixelsDigest) throw new Error("Missing fixture digests")
        return {
          kind: "text-cells",
          role: frame.role,
          label: frame.label,
          capturedAt: frame.capturedAt,
          ref: digest(`text-${index}`),
          cellDigest: frame.regionDigest,
          frameDigest: frame.pixelsDigest,
          cellRectangle: { top: 1, left: 1, bottom: 2, right: 8 },
        }
      }
      if (scenario === "missing cells digest" || (scenario === "missing first digest" && index === 1)) {
        const { regionDigest: _unused, ...withoutCells } = frame
        return withoutCells
      }
      if (scenario === `crop ${index}` && frame.regionRectangle) {
        return { ...frame, regionRectangle: { ...frame.regionRectangle, x: frame.regionRectangle.x + 1 } }
      }
      return frame
    }
    const result = await probe.term(context)
    expect(result.observation?.note ?? result.tests?.[0]?.reason ?? result.note).toContain(note)
    expect(result.assertions).toBeUndefined()
    if (scenario === "short grid" || scenario === "narrow grid" || scenario === "text adapter") {
      expect(fixture.writes).toEqual([])
      expect(fixture.queries).toEqual([])
      expect(fixture.requests).toEqual([])
    }
    expect(parseCallback(id, result, fixture).results?.[0]?.status).toBe(status)
  })

  it("keeps source provenance distinct from the pixel regions a verdict compared", () => {
    const run = kittyRun()
    const frames = run.results[0]!.frames.map((captured) => ({
      ...captured,
      // Linux XWD source bytes differ from retained PNG and compared-cell digests.
      sourceRef: digest(`source:${captured.ref}`),
    }))
    run.results[0]!.frames = frames
    const loaded = parse(run)
    expect(loaded.results?.[0]?.status).toBe("supported")
    expect(loaded.observations).toEqual([])
    expect(loaded.results?.[0]?.frames).toEqual(frames)
    const assertion = run.assertions[0]!
    const control = frames[0]!
    expect(control.sourceRef).not.toBe(control.ref)
    assertion.observed = control.sourceRef
    expect(() => parse(run)).toThrow(
      `pixels-verdict.json: screenshot probe result for ${FEATURE} cites only source or whole-frame digests; a probe result must cite a frame's ref or the digest of the cells it compared`,
    )
    assertion.observed = JSON.stringify({ ref: control.ref, sourceRef: digest("foreign-source") })
    expect(() => parse(run)).toThrow(/is not the ref or a digest of a frame/)
  })

  it("admits a digest-equality probe result whose assertion cites a frame's regionDigest", () => {
    const loaded = parse(kittyRun())
    const observation = loaded.results![0]!
    expect(observation.status).toBe("supported")
    expect(observation.frames).toHaveLength(6)
    // The digests survive the parse, which is what keeps the probe result recomputable.
    expect(observation.frames?.[3]?.regionDigest).toBe(digest("after-region"))
    expect(observation.frames?.[3]?.pixelsDigest).toBe(digest("after-px"))
  })

  it("admits a frame-ref probe result accompanied by its retained whole-frame digest", () => {
    const run = kittyRun()
    const target = run.results[0]!.frames[3]!
    run.assertions[0]!.observed = JSON.stringify({ ref: target.ref, whole: frameDigests(target).whole })
    expect(parse(run).results![0]?.status).toBe("supported")
  })

  it("carries a frame's crop rectangle through the parse, and refuses one that is not a rectangle", () => {
    const run = kittyRun()
    const observations = run.results as Array<Record<string, unknown>>
    const frames = observations[0]!.frames as Array<Record<string, unknown>>
    frames[3]!.regionRectangle = { x: 10, y: 36, width: 104, height: 24 }
    const loaded = parse(run)
    // The rectangle `regionDigest` was taken over survives with it, so a probe result recomputed from
    // this parsed frame can still tell two screen positions apart (29580).
    expect(loaded.results![0]?.frames?.[3]?.regionRectangle).toEqual({ x: 10, y: 36, width: 104, height: 24 })

    const broken = kittyRun()
    const brokenObservations = broken.results as Array<Record<string, unknown>>
    const brokenFrames = brokenObservations[0]!.frames as Array<Record<string, unknown>>
    brokenFrames[3]!.regionRectangle = { x: 10, y: 36, width: 0, height: 24 }
    expect(() => parse(broken)).toThrow(/invalid frame regionRectangle/)
  })

  it("carries a frame's located answer through the parse, null included, and refuses a malformed one (33000)", () => {
    const run = kittyRun()
    const frames = (run.results as Array<Record<string, unknown>>)[0]!.frames as Array<Record<string, unknown>>
    frames[2]!.located = { box: { x: 17, y: 126, width: 8, height: 16 }, pixels: 128 }
    frames[3]!.located = null
    const loaded = parse(run)
    expect(loaded.results![0]?.frames?.[2]?.located).toEqual({
      box: { x: 17, y: 126, width: 8, height: 16 },
      pixels: 128,
    })
    // null is an answer (the colour is absent), kept distinct from a frame that carries no answer.
    expect(loaded.results![0]?.frames?.[3]?.located).toBeNull()
    expect(loaded.results![0]?.frames?.[1]).not.toHaveProperty("located")

    for (const located of [
      { box: { x: 17, y: 126, width: 8, height: 16 }, pixels: 129 },
      { box: { x: 17, y: 126, width: 8, height: 16 }, pixels: 0 },
      { pixels: 4 },
      "here",
    ]) {
      const broken = kittyRun()
      const brokenFrames = (broken.results as Array<Record<string, unknown>>)[0]!.frames as Array<
        Record<string, unknown>
      >
      brokenFrames[2]!.located = located
      expect(() => parse(broken)).toThrow(/invalid frame located/)
    }
  })

  it("carries a blink run's same-shot control crops through the parse, beside its older-shape plain entries (#33117)", () => {
    const loaded = parseBlink(blinkRun())
    const frames = loaded.results![0]!.frames!
    expect(frames).toHaveLength(1 + BLINK_SAMPLES + 1 + BLINK_SAMPLES)
    const targets = frames.filter((entry) => entry.role === "target")
    expect(targets).toHaveLength(BLINK_SAMPLES)
    for (const target of targets) {
      expect(target.controlRegionDigest).toBe(digest("blink-plain"))
      expect(target.controlRegionRectangle).toEqual(PLAIN_RECT)
      expect(target.regionRectangle).toEqual(STYLED_RECT)
    }
    expect(frames[0]?.controlRegionDigest).toBe(digest("blink-plain"))
    // Additive at the scale the probe writes: the plain entries cropped from those same shots
    // carry no control fields at all and parse unchanged in the same run.
    const plainEntries = frames.filter((entry) => entry.label.startsWith("Plain line,"))
    expect(plainEntries).toHaveLength(BLINK_SAMPLES + 1)
    for (const entry of plainEntries) {
      expect(entry.controlRegionDigest).toBeUndefined()
      expect(entry.controlRegionRectangle).toBeUndefined()
      expect(entry.regionDigest).toBe(digest("blink-plain"))
    }
  })

  it.each([
    { name: "digest without rectangle", control: { controlRegionDigest: digest("plain-region") } },
    {
      name: "rectangle without digest",
      control: { controlRegionRectangle: { x: 10, y: 12, width: 104, height: 24 } },
    },
  ])("refuses a same-shot control crop carrying only one of its two fields: $name (#33117)", ({ control }) => {
    const run = kittyRun()
    const observations = run.results as Array<Record<string, unknown>>
    const frames = observations[0]!.frames as Array<Record<string, unknown>>
    frames[3]!.regionRectangle = { x: 10, y: 36, width: 104, height: 24 }
    Object.assign(frames[3]!, control)
    expect(() => parse(run)).toThrow(/control region 3 .* only one of its digest and rectangle/)
  })

  it("refuses a same-shot control crop that overlaps its target region (#33117)", () => {
    const run = kittyRun()
    const observations = run.results as Array<Record<string, unknown>>
    const frames = observations[0]!.frames as Array<Record<string, unknown>>
    frames[3]!.regionRectangle = { x: 10, y: 36, width: 104, height: 24 }
    frames[3]!.controlRegionDigest = digest("plain-region")
    frames[3]!.controlRegionRectangle = { x: 10, y: 48, width: 104, height: 24 }
    expect(() => parse(run)).toThrow(/control region 3 .* overlaps its target region/)
  })

  it("admits a probe result whose assertion cites the frame refs it compared", () => {
    const loaded = parse(scrollbackRun())
    expect(loaded.results![0]?.status).toBe("supported")
    expect(loaded.results![0]?.frames).toHaveLength(5)
  })

  it("refuses a flipped outcome with no matching assertion", () => {
    const run = kittyRun()
    const observations = run.results as Array<Record<string, unknown>>
    observations[0]!.status = "unsupported"
    const tests = observations[0]!.tests as Array<Record<string, unknown>>
    tests[0]!.status = "unsupported"
    expect(() => parse(run)).toThrow(/lacks bound negative assertion/)
  })

  it("refuses a probe result that cites a digest no frame carries", () => {
    const run = kittyRun()
    const assertions = run.assertions as Array<Record<string, unknown>>
    assertions[0]!.observed = digest("not-in-any-frame")
    // The same check now serves text probe results, whose digests are cell-sized.
    expect(() => parse(run)).toThrow(/is not the ref or a digest of a frame/)
  })

  it("refuses a probe result whose observed cites no digest at all", () => {
    const run = kittyRun()
    const assertions = run.assertions as Array<Record<string, unknown>>
    assertions[0]!.observed = "the two frames looked the same"
    expect(() => parse(run)).toThrow(/must cite the frame digest it decided on/)
  })

  it("refuses a lone screenshotRef with no frame pair", () => {
    const run = kittyRun()
    const observations = run.results as Array<Record<string, unknown>>
    delete observations[0]!.frames
    expect(() => parse(run)).toThrow(/requires control and target frames; a lone screenshotRef stays inconclusive/)
  })

  it("refuses a frame regionDigest that is not a sha256", () => {
    const frames = kittyFrames()
    ;(frames[3] as { regionDigest?: string }).regionDigest = "88a04fcc"
    const run = kittyRun()
    const observations = run.results as Array<Record<string, unknown>>
    observations[0]!.frames = frames
    expect(() => parse(run)).toThrow(/invalid frame regionDigest 3/)
  })

  // Walks the whole committed corpus, which grows with every run; 5 s default was 4 s on CI by Nov 10 (33133).
  it("still parses every committed run", { timeout: 30_000 }, () => {
    const manifests = readdirSync(join(ROOT, "content", "suites"))
      .filter((f) => f.endsWith(".json"))
      .map((f) => parseSuiteManifest(f, readFileSync(join(ROOT, "content", "suites", f), "utf8")))
    const trusted = new Map<string, ProbeSuiteManifest>(manifests.map((m) => [m.probeHash, m]))
    const ids = [...new Set(manifests.flatMap((m) => Object.values(m.probes).flat()))]
    let parsed = 0
    const refused: string[] = []
    for (const dir of ["probes-apps", "probes-libs", "probes-mux"]) {
      for (const name of readdirSync(join(ROOT, "content", dir)).filter((f) => f.endsWith(".json"))) {
        try {
          parseRun(`${dir}/${name}`, readFileSync(join(ROOT, "content", dir, name), "utf8"), ids, trusted)
          parsed++
        } catch (cause) {
          refused.push(`${dir}/${name}: ${(cause as Error).message}`)
        }
      }
    }
    expect(refused).toEqual([])
    // The round is empty between the Friday delete and Saturday's admission (#30764 M4 P1): every
    // committed run must still parse, and zero runs is a legitimate state, not a silent read.
  })
})
