/**
 * @failure A placeholder sha256 — one repeated character — passed the FLAT branch of the app-launch
 *   receipt parser and `parseDerivedSourceTree`, so two macOS documents (runs b6faa688, 2c0558f2) held
 *   receipts nothing measured. The refusal must name the placeholder without refusing a measured
 *   digest, and it must reuse the ONE predicate the container receipt already applies (27874, 28240).
 * @level l1
 * @consumer run-parser app-launch admission; the docs/data current-results projection
 * @reach parses origin.appLaunch of a collector app run, flat and derived-source-tree
 * @testonly none
 */
import { describe, expect, it } from "vitest"
import type { AppLaunchReceipt } from "@terminfo/probe-defs"
import { parseAppLaunchReceipt, transformInvocation } from "./app-launch.ts"

// Retain only the measured receipt verbatim; this parser does not decode a capture run.
const ZEROS = "0".repeat(64)
const LETTERS = "a".repeat(64)
const MEASURED = {
  bundlePath: "/Applications/Alacritty.app",
  cfBundleShortVersionString: "0.17.0",
  cfBundleVersion: "1",
  executablePath: "/Applications/Alacritty.app/Contents/MacOS/alacritty",
  executableSha256: "444055799f1211d6adbe9f18ab2660c57155de4f0e88d42458d6ae4fb539dcda",
  sourceArtifact: {
    path: "/Users/runner/work/_temp/Alacritty.dmg",
    sha256: "ad8d7de35fb38e43184776cac6dfee05ca325caa0b6639a06a55e54e4b026620",
  },
} satisfies AppLaunchReceipt

/**
 * The two documents 28240 retired, carrying their own receipt blocks verbatim (@cto 2026-10-08: the
 * corpus documents are `git rm`-ed, so a test may not read them from disk any more).
 */
const RETIRED: Record<string, Record<string, unknown>> = {
  "alacritty-0.17.0-macos.json (run b6faa688)": {
    bundlePath: "/Applications/Alacritty.app",
    cfBundleShortVersionString: "0.17.0",
    cfBundleVersion: "1",
    executablePath: "/Applications/Alacritty.app/Contents/MacOS/alacritty",
    executableSha256: ZEROS,
    sourceArtifact: { path: "/Applications/Alacritty.app", sha256: ZEROS },
  },
  "terminal-app-2.15-macos.json (run 2c0558f2)": {
    bundlePath: "/System/Applications/Utilities/Terminal.app",
    cfBundleShortVersionString: "2.15",
    cfBundleVersion: "470.2",
    executablePath: "/System/Applications/Utilities/Terminal.app/Contents/MacOS/Terminal",
    executableSha256: ZEROS,
    sourceArtifact: { path: "/System/Applications/Utilities/Terminal.app", sha256: ZEROS },
  },
}

function appLaunchOf(): Record<string, unknown> {
  return structuredClone(MEASURED)
}

function parse(receipt: Record<string, unknown>): unknown {
  return parseAppLaunchReceipt(receipt, "collector", "term", "origin.appLaunch")
}

function withDigest(receipt: Record<string, unknown>, field: string, value: string): Record<string, unknown> {
  if (field === "executableSha256") return { ...receipt, executableSha256: value }
  const sourceArtifact = receipt.sourceArtifact as Record<string, unknown>
  return { ...receipt, sourceArtifact: { ...sourceArtifact, sha256: value } }
}

/** A derived source artifact names its proof; only `sha256` is the flat re-measured tar digest. */
function derived(sha256: string): Record<string, unknown> {
  return {
    kind: "derived-source-tree",
    url: "https://upstream.invalid/alacritty-0.17.0.tar.gz",
    revision: "b".repeat(40),
    narSri: "sha256-+ddMmUe9Jjkun4qqW8XFXVgwVZdVHsGWcQzndgIlBjQ=",
    sha256,
  }
}

function withDerived(receipt: Record<string, unknown>, sha256: string): Record<string, unknown> {
  return { ...receipt, sourceArtifact: derived(sha256) }
}

describe("a placeholder digest is refused by name", () => {
  for (const [label, receipt] of Object.entries(RETIRED)) {
    it("refuses the placeholder receipt carried by " + label, () => {
      expect(() => parse(receipt)).toThrow(/placeholder/)
    })
  }

  it("refuses a placeholder executableSha256 on an otherwise measured receipt", () => {
    expect(() => parse(withDigest(appLaunchOf(), "executableSha256", ZEROS))).toThrow(/placeholder/)
  })

  it("refuses a placeholder flat sourceArtifact.sha256 on an otherwise measured receipt", () => {
    expect(() => parse(withDigest(appLaunchOf(), "sourceArtifact.sha256", ZEROS))).toThrow(/placeholder/)
  })

  it("refuses a placeholder derived-source-tree sha256", () => {
    expect(() => parse(withDerived(appLaunchOf(), ZEROS))).toThrow(/placeholder/)
  })

  it("refuses one repeated character, not only an all-zero digest", () => {
    expect(() => parse(withDigest(appLaunchOf(), "executableSha256", LETTERS))).toThrow(/placeholder/)
    expect(() => parse(withDigest(appLaunchOf(), "sourceArtifact.sha256", LETTERS))).toThrow(/placeholder/)
    expect(() => parse(withDerived(appLaunchOf(), LETTERS))).toThrow(/placeholder/)
  })

  it("still refuses a digest that is not a sha256 at all", () => {
    expect(() => parse(withDigest(appLaunchOf(), "executableSha256", "zz"))).toThrow(/invalid/)
    expect(() => parse(withDigest(appLaunchOf(), "sourceArtifact.sha256", "zz"))).toThrow(/invalid/)
    expect(() => parse(withDerived(appLaunchOf(), "zz"))).toThrow(/invalid/)
  })
})

describe("a measured receipt still parses", () => {
  it("accepts the receipt 28216's re-collection produced", () => {
    const parsed = parse(appLaunchOf()) as { executableSha256: string; sourceArtifact: { sha256: string } }
    expect(parsed.executableSha256).toBe("444055799f1211d6adbe9f18ab2660c57155de4f0e88d42458d6ae4fb539dcda")
    expect(parsed.sourceArtifact.sha256).toMatch(/^[a-f0-9]{64}$/)
    expect(parsed.sourceArtifact.sha256).not.toBe(ZEROS)
  })

  it("accepts a derived-source-tree artifact with a measured sha256", () => {
    const parsed = parse(withDerived(appLaunchOf(), "c3".repeat(32))) as {
      sourceArtifact: { kind: string; sha256: string }
    }
    expect(parsed.sourceArtifact.kind).toBe("derived-source-tree")
    expect(parsed.sourceArtifact.sha256).toBe("c3".repeat(32))
  })
})

// The existing macOS receipt cases cannot catch Windows measurements being mistaken for bundle
// fields. Admission compares the measured version; this parser owns only the strict receipt shape.
describe("a measured Windows launch uses the same parser", () => {
  const windows = {
    platform: "win32",
    executablePath: String.raw`C:\runner\terminal\WindowsTerminal.exe`,
    productVersion: "1.21.2361.0",
    executableSha256: "c3".repeat(32),
    sourceArtifact: { kind: "portable-zip", path: String.raw`C:\runner\wt.zip`, sha256: "d4".repeat(32) },
  } satisfies AppLaunchReceipt
  it("preserves transformed invocation argv in the Windows receipt arm", () => {
    const receipt = {
      ...windows,
      argv: ["C:\\launch\\wt.exe", "--token=[redacted]", "--", "verbatim value"],
    } satisfies AppLaunchReceipt
    // Typecheck must reject non-string elements in this arm, independently of runtime parsing.
    // @ts-expect-error invocation elements are strings
    const invalid: AppLaunchReceipt = { ...windows, argv: [42] }
    void invalid
    expect(parse(receipt)).toEqual(receipt)
  })
  it("preserves the measured Windows executable, version and ZIP without bundle fields", () => {
    expect(parse(windows)).toEqual(windows)
  })
  const alacrittyWindows = {
    platform: "win32",
    executablePath: String.raw`D:\a\_temp\alacritty\alacritty.exe`,
    productVersion: "0.17.0",
    executableSha256: "5ad70ddc5c2a2bfe84084a2c4c73558e9360914f035a902d7a69277be7249f1f",
    sourceArtifact: {
      kind: "portable-exe",
      path: String.raw`D:\a\_temp\measurement-artifacts\Alacritty-v0.17.0-portable.exe`,
      sha256: "5ad70ddc5c2a2bfe84084a2c4c73558e9360914f035a902d7a69277be7249f1f",
    },
    mesaRenderer: {
      upstream: "https://github.com/mmozeiko/build-mesa",
      version: "26.2.5",
      archivePath: String.raw`D:\a\_temp\measurement-artifacts\mesa-llvmpipe-x64-26.2.5.7z`,
      archiveSha256: "d1b713ca2a7fba47a50c058099f13c435ddb76a16a422c334e4d787f9755a31d",
      dlls: [
        {
          name: "opengl32.dll",
          path: String.raw`D:\a\_temp\alacritty\opengl32.dll`,
          sha256: "8ddc061ee752fff06ae682de0ac2e010926d76a93c1aecc4c206adee771856e1",
        },
      ],
    },
  }
  it("preserves a measured Windows portable-exe launch with pinned Mesa3D renderer receipt", () => {
    expect(parse(alacrittyWindows)).toEqual(alacrittyWindows)
  })
  it.each([
    [{ ...windows, platform: "darwin" }, /unknown appLaunch.platform/],
    [{ ...windows, bundlePath: "/Applications/Terminal.app" }, /fields/],
    [
      {
        ...windows,
        sourceArtifact: {
          kind: "developer-id-signed-bundle",
          codeSignature: { identifier: "org.alacritty", cdHash: "12".repeat(20), strictVerified: true },
        },
      },
      /must be portable-zip or portable-exe/,
    ],
    [{ ...windows, productVersion: "" }, /productVersion/],
    [{ ...windows, productVersion: " " }, /productVersion/],
    [{ ...windows, productVersion: " 1.21.240823001" }, /productVersion/],
    [{ ...windows, productVersion: "1.21.240823001 " }, /productVersion/],
    [{ ...windows, productVersion: "1.21.240823001\n" }, /productVersion/],
    [{ ...windows, productVersion: "1.21.\n240823001" }, /productVersion/],
    [{ ...windows, executablePath: "WindowsTerminal.exe" }, /absolute/],
    [{ ...windows, executablePath: String.raw`\terminal\WindowsTerminal.exe` }, /absolute/],
    [{ ...windows, executableSha256: ZEROS }, /placeholder/],
    [{ ...windows, sourceArtifact: { ...windows.sourceArtifact, path: "wt.zip" } }, /absolute/],
    [{ ...windows, sourceArtifact: { ...windows.sourceArtifact, sha256: ZEROS } }, /placeholder/],
    [{ ...windows, sourceArtifact: { ...windows.sourceArtifact, kind: "archive" } }, /portable-zip/],
    [{ ...windows, sourceArtifact: { ...windows.sourceArtifact, bundlePath: "/Applications/Terminal.app" } }, /fields/],
    [
      {
        ...alacrittyWindows,
        sourceArtifact: { ...alacrittyWindows.sourceArtifact, sha256: "e5".repeat(32) },
      },
      /portable-exe appLaunch\.executableSha256 must match sourceArtifact\.sha256/,
    ],
    [
      {
        ...windows,
        mesaRenderer: alacrittyWindows.mesaRenderer,
      },
      /win32 portable-zip appLaunch cannot carry mesaRenderer/,
    ],
    [
      {
        ...alacrittyWindows,
        mesaRenderer: {
          ...alacrittyWindows.mesaRenderer,
          dlls: [
            {
              name: "libgallium_wgl.dll",
              path: String.raw`D:\a\_temp\alacritty\libgallium_wgl.dll`,
              sha256: "e5".repeat(32),
            },
          ],
        },
      },
      /must include opengl32\.dll/,
    ],
    [
      {
        ...alacrittyWindows,
        mesaRenderer: { ...alacrittyWindows.mesaRenderer, archivePath: "mesa.7z" },
      },
      /archivePath must be absolute/,
    ],
    [
      {
        ...alacrittyWindows,
        mesaRenderer: { ...alacrittyWindows.mesaRenderer, archiveSha256: ZEROS },
      },
      /placeholder/,
    ],
  ])("refuses malformed or mixed Windows receipt %#", (receipt, diagnostic) => {
    expect(() => parse(receipt)).toThrow(diagnostic)
  })
  it("refuses Windows fields mixed into the existing absent-platform macOS shape", () => {
    expect(() => parse({ ...appLaunchOf(), productVersion: windows.productVersion })).toThrow(/mixed/)
  })
})

// Reviewed r6 admits one new macOS source alternative; existing flat/derived/Windows
// cases cannot catch a valid signed-bundle receipt being refused as an unknown kind.
// This is parser contract data, not a measured codesign classification or Mac capture.
// The bundle parser previously silently dropped argv; the Windows arm rejected it as an extra field.
it("preserves transformed invocation argv without substituting the measured executable", () => {
  const receipt = {
    ...MEASURED,
    argv: [
      "/invoked/wezterm",
      "--token=[redacted]",
      "--",
      ...Array.from({ length: 128 }, (_, index) => `verbatim value ${index}`),
    ],
  } satisfies AppLaunchReceipt
  // @ts-expect-error invocation elements are strings in the bundle arm too
  const invalid: AppLaunchReceipt = { ...MEASURED, argv: [42] }
  void invalid
  expect(parse(receipt)).toEqual(receipt)
})

describe("Developer ID signed bundle source contract", () => {
  const codeSignature = { identifier: "org.alacritty", cdHash: "12".repeat(20), strictVerified: true }
  const sourceArtifact = { kind: "developer-id-signed-bundle", codeSignature }
  it("preserves the signed source beside the existing measured executable identity", () => {
    const receipt = { ...appLaunchOf(), sourceArtifact }
    expect(parse(receipt)).toEqual(receipt)
  })
  // The new kind's exact signature keys must not tighten the pre-existing sealed receipt parser.
  it("keeps the sealed source key set and legacy signature normalization unchanged", () => {
    const sealedSource = {
      kind: "sealed-macos-system-volume",
      macOSBuild: "25G83",
      snapshotUUID: "C1602FFF-7F1F-48FE-B3AC-3A74675B4416",
      snapshotName: "com.apple.os.update-contract",
      sealed: true,
      codeSignature: { ...codeSignature, legacyExtra: "unchanged parser behavior" },
    }
    const receipt = { ...appLaunchOf(), sourceArtifact: sealedSource }
    expect(parse(receipt)).toEqual({ ...receipt, sourceArtifact: { ...sealedSource, codeSignature } })
    expect(() => parse({ ...receipt, sourceArtifact: { ...sealedSource, unexpected: true } })).toThrow(
      /invalid sealed.*fields/,
    )
  })
  it.each([
    ["extra source field", { ...sourceArtifact, unexpected: true }, /sourceArtifact fields/],
    ["missing signature", { kind: sourceArtifact.kind }, /sourceArtifact fields/],
    ["non-object signature", { ...sourceArtifact, codeSignature: null }, /missing.*codeSignature/],
    [
      "extra signature field",
      { ...sourceArtifact, codeSignature: { ...codeSignature, extra: true } },
      /codeSignature fields/,
    ],
    [
      "struck team identifier",
      { ...sourceArtifact, codeSignature: { ...codeSignature, teamIdentifier: "ABCDEFGHIJ" } },
      /codeSignature fields/,
    ],
    [
      "missing identifier",
      { ...sourceArtifact, codeSignature: { cdHash: codeSignature.cdHash, strictVerified: true } },
      /codeSignature fields/,
    ],
    ["empty identifier", { ...sourceArtifact, codeSignature: { ...codeSignature, identifier: "" } }, /identifier/],
    ["uppercase hash", { ...sourceArtifact, codeSignature: { ...codeSignature, cdHash: "AB".repeat(20) } }, /cdHash/],
    ["short hash", { ...sourceArtifact, codeSignature: { ...codeSignature, cdHash: "1234" } }, /cdHash/],
    [
      "string verification",
      { ...sourceArtifact, codeSignature: { ...codeSignature, strictVerified: "true" } },
      /strictVerified must be true/,
    ],
    [
      "false verification",
      { ...sourceArtifact, codeSignature: { ...codeSignature, strictVerified: false } },
      /strictVerified must be true/,
    ],
  ])("refuses %s by name", (_label, sourceArtifact, diagnostic) => {
    expect(() => parse({ ...appLaunchOf(), sourceArtifact })).toThrow(diagnostic)
  })
})

// The CLI cannot supply the launch owner's explicit sensitivity declarations; this pins that separate caller contract.
it("explicit sensitivity wins after option termination and over otherwise public config paths", () => {
  expect(
    transformInvocation(
      [
        "/app",
        "--config-file",
        "/private/public-marker",
        "--session",
        "run-marker",
        "--",
        "declared secret",
        "public positional",
      ],
      [2, "declared secret"],
    ),
  ).toEqual(["/app", "--config-file", "[redacted]", "--session", "[redacted]", "--", "[redacted]", "public positional"])
})

it.each([[], [""], [123], ["/app", null], "/app", null])(
  "refuses malformed optional invocation arrays by name: %#",
  (argv) => {
    expect(() => parse({ ...appLaunchOf(), argv })).toThrow(/appLaunch.argv/)
  },
)
