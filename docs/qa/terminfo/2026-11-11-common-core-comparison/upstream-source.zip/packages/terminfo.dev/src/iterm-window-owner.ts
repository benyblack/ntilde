/** Native iTerm window custody for the local comparison adapter; never selects a personal window. */
import { execFileSync } from "node:child_process"
import { realpathSync } from "node:fs"
import { descendToOwner, parentOf, processExecutable, tty } from "./owned-process.ts"

export function assertITermWindow(windowId: number, tabTty: string, workerPid: number): number {
  if (!Number.isSafeInteger(windowId) || windowId < 1) throw new Error("Invalid iTerm window id")
  const expectedTty = tty(tabTty)
  const script = `tell application "iTerm"
    set matches to every window whose id is ${windowId}
    if (count of matches) is not 1 then error "owned iTerm window disappeared or is ambiguous"
    set w to item 1 of matches
    if (count of tabs of w) is not 1 then error "owned iTerm window acquired another tab"
    if (count of sessions of tab 1 of w) is not 1 then error "owned iTerm tab acquired another session"
    if (tty of session 1 of tab 1 of w) is not ${JSON.stringify(expectedTty)} then error "owned iTerm TTY changed"
    return true
  end tell`
  execFileSync("/usr/bin/osascript", ["-e", script], { timeout: 15000 })
  const census = String(execFileSync("/usr/bin/osascript", ["-l", "JavaScript", "-e", `ObjC.import("AppKit"); var a=$.NSRunningApplication.runningApplicationsWithBundleIdentifier("com.googlecode.iterm2"); var rows=[]; for(var i=0;i<a.count;i++){var x=a.objectAtIndex(i);rows.push({pid:Number(x.processIdentifier),path:ObjC.unwrap(x.executableURL.path)});} JSON.stringify(rows)`], { timeout: 15000 }))
  const apps = JSON.parse(census)
  if (!Array.isArray(apps) || apps.length !== 1) throw new Error("iTerm process census is ambiguous")
  const app = apps[0]
  const expected = realpathSync("/Applications/iTerm.app/Contents/MacOS/iTerm2")
  if (!Number.isSafeInteger(app.pid) || app.pid < 1 || realpathSync(app.path) !== expected || processExecutable(app.pid, "iTerm") !== expected) throw new Error("iTerm executable does not match the measured bundle")
  const workerTty = tty(String(execFileSync("/bin/ps", ["-p", String(workerPid), "-o", "tty="], { timeout: 5000 })))
  if (workerTty !== expectedTty) throw new Error("iTerm child TTY differs from the owned session")
  descendToOwner(workerPid, app.pid, parentOf, "iTerm")
  return app.pid
}
