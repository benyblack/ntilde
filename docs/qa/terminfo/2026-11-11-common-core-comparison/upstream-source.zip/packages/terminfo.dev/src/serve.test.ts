/**
 * @failure An unrelated local process or web page can make the daemon emit terminal control bytes.
 * @level l3
 * @consumer Real-terminal daemon HTTP clients
 * @testonly none
 * @reach fs-walk <fixture-only: /tmp/terminfo-serve-*>
 */
import { spawn, spawnSync, type ChildProcess } from "node:child_process"
import { mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
import { createHash } from "node:crypto"
import { afterEach, describe, expect, it, vi } from "vitest"

let child: ChildProcess | undefined
let home: string | undefined
const packageRoot = join(import.meta.dirname, "../../..")

// The owner factory has its own live-custody tests. The collector consumes the owner-level proof:
// Darwin has no clipboard adapter, and a second clipboard home could hide a missing owner proof.
it.each(["tmux", "screen", "darwin-screen"])(
  "collects a %s envelope only when its target agrees with the verified attachment",
  (mux) => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-mux-"))
    const result = spawnSync(
      process.execPath,
      [
        "-e",
        String.raw`
    import {mock} from "bun:test"
    import assert from "node:assert/strict"
    import {readFileSync,writeFileSync} from "node:fs"
    import {join} from "node:path"
    const unified=await import("./packages/terminfo.dev/src/probes/unified.ts")
    const tty=await import("./packages/terminfo.dev/src/tty.ts")
    const owned=await import("./packages/terminfo.dev/src/owned-terminal.ts")
    const hash="a".repeat(12),revision="b".repeat(40)
    globalThis.__TERMINFO_BUNDLED_SUITE__={manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash:hash,probes: { term:unified.ALL_PROBES.map(p=>p.id).sort(),mux:unified.ALL_PROBES.map(p=>p.id).sort(),lib:[]}},collectorRevision:revision}
    const darwin=process.env.TERMINFO_TEST_MUX==="darwin-screen"
    const mux=darwin?"screen":process.env.TERMINFO_TEST_MUX, version=mux==="screen"?(darwin?"4.00.03":"4.09.01"):"3.6"
    if(darwin)Object.defineProperty(process,"platform",{value:"darwin"})
    const preflight=darwin?{pid:95,startedAtEpochSeconds:1792678700}:{pid:95,startTicks:"115"}
    const target={kind:"mux",id:mux,version,os:darwin?"macos":"linux",osVersion:"fixture",outerTerminal:"kitty",mux,config:"/out/mux.conf",permissions:null}
    const outerApp={subject:{...target,kind:"term",id:"kitty",version:"0.49.2",outerTerminal:null,mux:null,config:"--config NONE"},
      rawReplies:{"device.primary-da":"\x1b[?62;52;c","device.xtversion":"kitty(0.49.2)","collector.preflightIdentity":JSON.stringify({...preflight,launchRunId:"a".repeat(32)})},
      provenance:{executable:{path:"/fixture/kitty",sha256:"cd".repeat(32),version:"kitty 0.49.2"},
        sourceArtifact:{url:"https://example.invalid/kitty.tar",sha256:"de".repeat(32)},
        runtime:{imageId:"sha256:"+"ef".repeat(32),imageTarSha256:"12".repeat(32),arch:"amd64",nixLockRevision:"c".repeat(40),sourceRevision:revision,cleanTree:true,suiteHash:hash},
        fixture:{definition:"callbacks",config:"--config NONE",font:"fixture",geometry:"80x24",display:"fixture",gl:"fixture"}}}
    const path=join(process.env.HOME,"runtime.json")
    process.env.TERMINFO_RUNTIME_PROVENANCE=path
    let suppliedTarget=target,hasAttachment=true,hasBinary=true,verifierCalls=0,custodyFailure,inBatch=false,collectionAttempt,preflightOnly=false
    const verify=async()=>{if(inBatch){verifierCalls++;if(custodyFailure)throw custodyFailure}}
    const write=()=>writeFileSync(path,JSON.stringify({subject:suppliedTarget,outerApp}))
    write()
    mock.module("./packages/terminfo.dev/src/detect.ts",()=>({detectTerminal:()=>({name:preflightOnly?"kitty":mux,version:preflightOnly?"0.49.2":version,os:target.os,osVersion:"fixture"})}))
    mock.module("./packages/terminfo.dev/src/tty.ts",()=>({...tty,withRawMode:async fn=>fn(),drainStdin:async()=>{},
      queryWithSentinelOutcome:async(sequence,pattern)=>{const raw=sequence.includes("[18t")?"\x1b[8;24;80t":preflightOnly?"\x1bP>|kitty(0.49.2)\x1b\\\x1b[?62;52;c":sequence==="\x1b[>c"?"\x1b[>83;"+(darwin?"40003":"40901")+";0c\x1b[?1;2c":mux==="screen"?"\x1b[?1;2c":"\x1bP>|tmux 3.6\x1b\\\x1b[?1;2;4c";return {raw,rawBase64:Buffer.from(raw).toString("base64"),match:pattern.exec(raw),reason:"reply"}}}))
    mock.module("./packages/terminfo.dev/src/owned-terminal.ts",()=>({...owned,createOwnedTerminal:async options=>{
      if(preflightOnly){
        assert.equal(options.darwinPreflight,true)
        return {geometryAtGrant:{status:"measured",rows:24,cols:80},summary:JSON.stringify({preflightIdentity:{...preflight,launchRunId:"a".repeat(32)}}),readCells:async()=>{throw new Error("No frame requested")},dispose:async()=>{}}
      }
      if(darwin)assert.equal(options.process.asserter,"terminfo-admin")
      else assert.deepEqual(options.linux.executable,{path:"/fixture/kitty",sha256:"cd".repeat(32)})
      const attachment={platform:darwin?"darwin":"linux",mux,captureRunId:options.captureRunId,launchRunId:"a".repeat(32),preflightCollector:preflight,executable:{...(hasBinary?{path:"/fixture/"+mux,sha256:"ab".repeat(32)}:{}),version:darwin?"Screen version 4.00.03 (FAU) 23-Oct-06":version},config:{path:"/out/mux.conf"}}
      return {geometryAtGrant:{status:"measured",rows:24,cols:80},getScrollback:async()=>({totalLines:24}),summary:JSON.stringify({muxAttachment:attachment}),
        ...(hasAttachment?{muxAttachmentProof:attachment}:{}),
        ...(darwin?{textRecipe:"macos-text-cells-v1",readCells:async()=>{throw new Error("This subject-join test does not request a text frame")}}:{}),
        ...(!darwin?{clipboard:{profile:"default",config:"--config NONE",permissions:"fixture",summary:"{}",assertOwned:verify,...(!hasAttachment?{muxAttachmentProof:attachment}:{})}}:{}),dispose:async()=>{}}
    }}))
    mock.module("./packages/terminfo.dev/src/probes/unified.ts",()=>({...unified,runProbeBatch:async options=>{
      assert.equal(options.subject.kind,preflightOnly?"term":"mux");assert.equal(options.subject.id,preflightOnly?"kitty":mux)
      // Native SGR attribution needs these facts during callbacks, before the final run subject exists.
      if(!preflightOnly){assert.equal(options.subject.version,version);assert.equal(options.subject.outerTerminal,"kitty")}
      if(!darwin)assert.equal(options.ownedTerminal.clipboard.assertOwned,verify)
      else assert.equal(options.ownedTerminal.clipboard,undefined)
      inBatch=true
      try{if(!darwin)await options.ownedTerminal.clipboard.assertOwned()}finally{inBatch=false}
      // Batch-only coverage cannot see the producer overwrite its persisted collection custody.
      const readDraft=()=>JSON.parse(readFileSync(join(process.env.TERMINFO_CAPTURE_DIRECTORY||join(process.env.HOME,".terminfo-dev","http-responses"),options.captureRunId+".draft.json"),"utf8"))
      collectionAttempt=readDraft().rawReplies["collector.collectionAttempt"]
      const attempt=JSON.parse(collectionAttempt)
      assert.deepEqual(attempt.ids,["device.xtversion"])
      assert.ok(Number.isFinite(Date.parse(attempt.startedAt)))
      assert.equal(attempt.result,"started")
      const batch={results:options.draft.results,rawReplies:{"fixture.reply":"batch-reply"},observations:[],assertions:[],notTested:[],ungradedDiagnostics:{},suiteComplete:false,screenshotRefs:[],textSnapshotRefs:[]}
      options.onCheckpoint(batch)
      assert.equal(readDraft().rawReplies["collector.collectionAttempt"],collectionAttempt)
      assert.equal(readDraft().rawReplies["fixture.reply"],"batch-reply")
      return batch
    }}))
    const {collectProbeRun}=await import("./packages/terminfo.dev/src/serve.ts")
    if(darwin)process.env.TERMINFO_CAPTURE_DIRECTORY=join(process.env.HOME,"capture")
    const collect=()=>collectProbeRun({ids:["device.xtversion"],...(darwin?{processOwner:{asserter:"terminfo-admin",launchRunId:"a".repeat(32),workerPid:process.pid,provider:"cli-process",ownerPid:123,executablePath:"/fixture/kitty",marker:{flag:"--run",value:"a".repeat(32)},tty:"/dev/ttys000",intendedVersion:"0.49.2"}}:{})})
    const run=await collect()
    const {decodeCollectorDraft}=await import("./packages/run-parser/src/index.ts")
    assert.equal(decodeCollectorDraft("owned-history fixture",JSON.stringify(run),globalThis.__TERMINFO_BUNDLED_SUITE__.manifest,revision).kind,"captured")
    assert.equal(run.identity,"unverified","placement owns verification; binary proof stays in raw replies")
    assert.deepEqual(JSON.parse(run.rawReplies["collector.historyIdentityCheck"]).executable,{path:"/fixture/"+mux,sha256:"ab".repeat(32),version:darwin?"Screen version 4.00.03 (FAU) 23-Oct-06":version})
    assert.deepEqual(JSON.parse(run.rawReplies["collector.collectionAttempt"]),{...JSON.parse(collectionAttempt),result:"completed"})
    assert.equal(run.rawReplies["fixture.reply"],"batch-reply")
    if(!darwin){
    assert.equal(verifierCalls,1)
    custodyFailure=new Error("fixture mux custody revoked at batch")
    await assert.rejects(collect(),error=>error===custodyFailure)
    assert.equal(verifierCalls,2)
    custodyFailure=undefined
    }
    hasBinary=false
    const unverified=await collect()
    assert.equal(unverified.identity,"unverified")
    assert.match(JSON.parse(unverified.rawReplies["collector.historyIdentityCheck"]).reason,/binary path, sha256 and version unavailable/)
    hasBinary=true
    assert.deepEqual(run.subject,target)
    assert.deepEqual(run.outerApp,outerApp)
    assert.equal(run.provenance,undefined)
    assert.equal(JSON.parse(run.rawReplies["collector.terminalOwnership"]).muxAttachment.captureRunId,run.runId)
    suppliedTarget={...target,config:"/foreign.conf"};write()
    await assert.rejects(collect(),/mux.*attachment|attachment.*mux/i)
    suppliedTarget=target;hasAttachment=false;write()
    await assert.rejects(collect(),/mux.*attachment|attachment.*mux/i)
    hasAttachment=true
    suppliedTarget={...target,version:"foreign"};write()
    await assert.rejects(collect(),/mux.*attachment|attachment.*mux/i)
    suppliedTarget=target
    outerApp.rawReplies["collector.preflightIdentity"]=JSON.stringify({...preflight,pid:96,launchRunId:"a".repeat(32)});write()
    await assert.rejects(collect(),/preflight.*attachment/i)
    if(darwin){
      preflightOnly=true;writeFileSync(path,JSON.stringify(outerApp.provenance))
      const outer=await collect()
      assert.deepEqual(JSON.parse(outer.rawReplies["collector.preflightIdentity"]),{...preflight,launchRunId:"a".repeat(32)})
    }
  `,
      ],
      {
        cwd: packageRoot,
        encoding: "utf8",
        timeout: 15000,
        env: {
          ...process.env,
          HOME: home,
          TERMINFO_TEST_MUX: mux,
          TERMINFO_CAPTURE_DIRECTORY: "",
          TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: mux === "darwin-screen" ? "" : "fixture-receipt",
          TERMINFO_DISPOSABLE_RECEIPT: "",
        },
      },
    )
    expect(result.error, result.stderr).toBeUndefined()
    expect(result.status, result.stderr).toBe(0)
  },
)

// AC1/AC3: the existing capture journeys cannot detect an empty request doing TTY work,
// lost intent before a prerequisite refusal, or cancellation being reported as cell failures.
it.each(["empty", "prerequisite", "completed", "cancelled", "failed", "unknown"])(
  "retains native selection and typed %s outcome through its existing draft custody",
  (mode) => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-selection-"))
    const result = spawnSync(
      process.execPath,
      [
        "-e",
        String.raw`
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      import { readFileSync } from "node:fs"
      import { join } from "node:path"
      const mode = process.env.NATIVE_ATTEMPT_FIXTURE
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const actualBatch = unified.runProbeBatch
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      const hash = "a".repeat(12), revision = "b".repeat(40)
      const ids = mode === "empty" ? [] : mode === "unknown" ? ["missing.probe"] : ["device.xtversion"]
      const runId = "selected-" + mode
      let detected = 0, raw = 0, batches = 0, owners = 0, unselectedRows
      const original = new Error("fixture " + mode + " diagnostic")
      if (mode === "cancelled") original.name = "AbortError"
      globalThis.__TERMINFO_BUNDLED_SUITE__ = { manifest: {
        schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd()+"/content")).sort(),
        probeHash: hash, probes: { term: unified.ALL_PROBES.map(probe=>probe.id).sort(), lib: [], mux: [] }
      }, collectorRevision: revision }
      const readDraft = () => JSON.parse(readFileSync(join(process.env.HOME,".terminfo-dev","http-responses",runId+".draft.json"),"utf8"))
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({ detectTerminal: () => {
        detected++
        if (mode !== "empty") assert.equal(readDraft().rawReplies["collector.selection"], JSON.stringify({ ids }))
        unselectedRows = readDraft().results.filter(row=>!ids.includes(row.featureId))
        if (mode === "prerequisite") throw original
        return { name: "kitty", version: "0.49.2", os: "linux", osVersion: "fixture" }
      }}))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
        createOwnedTerminal: async () => { owners++; throw new Error("unexpected owner dispatch") }
      }))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
        withRawMode: async callback => {
          raw++
          if (mode === "cancelled" || mode === "failed") throw original
          return callback()
        }, drainStdin: async () => {}
      }))
      mock.module("./packages/terminfo.dev/src/probes/unified.ts", () => ({ ...unified,
        runProbeBatch: async options => {
          batches++
          assert.deepEqual(options.ids, ids)
          if (mode === "unknown") return actualBatch(options)
          return { results: options.draft.results, rawReplies: { "device.xtversion": "kitty(0.49.2)" },
            observations: [], assertions: [], screenshotRefs: [], ungradedDiagnostics: {}, suiteComplete: false }
        }
      }))
      const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
      if (["prerequisite", "cancelled", "failed"].includes(mode)) {
        await assert.rejects(collectProbeRun({ ids, captureRunId: runId }), error => error === original)
      } else if (mode === "unknown") {
        await assert.rejects(collectProbeRun({ ids, captureRunId: runId }), /Unknown or inapplicable app probe missing.probe/)
      } else {
        const run = await collectProbeRun({ ids, captureRunId: runId })
        if (mode === "empty") {
          assert.equal(detected, 0); assert.equal(raw, 0); assert.equal(batches, 0); assert.equal(owners, 0)
          for (const key of ["subject", "identity", "measuredAt", "origin"]) assert.equal(Object.hasOwn(run,key),false,key)
        }
      }
      const draft = readDraft()
      assert.equal(draft.runId, runId); assert.equal(draft.probeHash, hash); assert.equal(draft.sourceRevision, revision)
      assert.deepEqual(JSON.parse(draft.rawReplies["collector.selection"]), { ids })
      const attempt = JSON.parse(draft.rawReplies["collector.collectionAttempt"])
      const expected = mode === "prerequisite" || mode === "unknown" ? "failed" : mode
      assert.equal(attempt.result, expected); assert.deepEqual(attempt.ids, ids)
      if (mode === "empty" || mode === "prerequisite") assert.equal(Object.hasOwn(attempt,"startedAt"),false)
      else assert.ok(Number.isFinite(Date.parse(attempt.startedAt)))
      if (["prerequisite", "cancelled", "failed"].includes(mode)) assert.equal(attempt.error, original.message)
      assert.equal(draft.results.length, 273)
      for (const row of draft.results.filter(row=>!ids.includes(row.featureId))) {
        assert.equal(row.status,"probe-todo"); assert.equal(row.attempt.scope,"none")

      }
      if (unselectedRows) assert.deepEqual(draft.results.filter(row=>!ids.includes(row.featureId)), unselectedRows)
      if (mode === "empty" || mode === "cancelled" || mode === "prerequisite") {
        assert.ok(draft.results.every(row=>row.attempt.scope==="none"))
      }
    `,
      ],
      {
        cwd: packageRoot,
        encoding: "utf8",
        timeout: 10_000,
        env: {
          ...process.env,
          HOME: home,
          NATIVE_ATTEMPT_FIXTURE: mode,
          TERMINFO_CAPTURE_DIRECTORY: "",
          TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
          TERMINFO_DISPOSABLE_RECEIPT: "",
          TERMINFO_RUNTIME_PROVENANCE: "",
          TERMINFO_TARGET_ID: "",
          TERMINFO_TARGET_VERSION: "",
        },
      },
    )
    expect(result.status, result.stderr).toBe(0)
  },
)

it.each(["absent", "failed to load", "inconclusive", "source-capable"])(
  "retains %s font proof and its named TODO reason in final Linux visual evidence",
  (proofState) => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-linux-origin-"))
    const result = spawnSync(
      process.execPath,
      [
        "-e",
        String.raw`
    import { mock } from "bun:test"
    import assert from "node:assert/strict"
    import { readFileSync, writeFileSync } from "node:fs"
    import { join } from "node:path"
    import { createHash } from "node:crypto"
    Object.defineProperty(process, "platform", { value: "linux" })
    const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
    const tty = await import("./packages/terminfo.dev/src/tty.ts")
    const linux = await import("./packages/terminfo.dev/src/linux-capture.ts")
    const hash = "a".repeat(12), revision = "b".repeat(40)
    const pixelGeometry = { cellWidth: 9, cellHeight: 22, textWidth: 720, textHeight: 528 }
    const measured = { origin: { x: 13, y: 57 }, pixelGeometry, basis: "fixture complete raster" }
    const decoded = { width: 800, height: 600, rgba: Buffer.alloc(800 * 600 * 4) }
    const raw = { frame: { role: "control", ref: "sha256:" + "c".repeat(64), sourceRef: "sha256:" + "d".repeat(64),
      capturedAt: 1, label: "origin witness" }, trace: { captureCommand: "fixture raw capture" } }
    const digest = seed => createHash("sha256").update(seed).digest("hex")
    // Synthetic receipt bytes exercise custody, not a claim about installed fonts or HarfBuzz.
    const proofState = process.env.FONT_CONTROL_PROOF_STATE
    const fontReceipt = proofState === "absent" ? "DejaVu Sans Mono | /fixture/dejavu.ttf" : JSON.stringify({
      fixture: "synthetic font-source receipt", proofState, reason: "synthetic source-control state",
      requestedFamily: "JetBrains Mono", face: "/fixture/JetBrainsMono-Regular.ttf",
      source: { path: "/fixture/JetBrainsMono-Regular.ttf", sha256: digest("fixture font bytes") },
      harfbuzz: { version: "fixture", text: "!= -> => <= ==", featuresOn: "liga=1,calt=1",
        featuresOff: "liga=0,calt=0", on: "fixture substituted clusters", off: "fixture separate clusters" } })
    const fontKey = "collector.fontSource", visualId = "extensions.font-ligatures"
    const provenance = { executable: { path: "/fixture/kitty", sha256: digest("fixture executable"), version: "kitty 0.49.2" },
      sourceArtifact: { url: "https://example.invalid/kitty.tar", sha256: digest("fixture source artifact") },
      runtime: { imageId: "sha256:" + digest("fixture image"), imageTarSha256: digest("fixture image tar"), arch: "amd64",
        nixLockRevision: "2".repeat(40), sourceRevision: revision, cleanTree: true, suiteHash: hash },
      fixture: { definition: "fixture", config: "--config NONE", font: fontReceipt, geometry: "80x24", display: "fixture", gl: "fixture" } }
    writeFileSync(process.env.TERMINFO_RUNTIME_PROVENANCE, JSON.stringify(provenance))
    globalThis.__TERMINFO_BUNDLED_SUITE__ = { manifest: { schemaVersion: 4,
      catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(),
      probeHash: hash, probes: { term: unified.ALL_PROBES.map(probe => probe.id).sort(), mux: [], lib: [] }
    }, collectorRevision: revision }
    let calibrations = 0, rawCaptures = 0, source
    const checkpoints = [
      { featureId: visualId, role: "control", label: "spaced operator control", cells: { top: 1, left: 1, bottom: 1, right: 1 }, pixelGeometry },
      { featureId: visualId, role: "target", label: "contiguous operator target", cells: { top: 24, left: 80, bottom: 24, right: 80 }, pixelGeometry }
    ]
    const capturedCheckpoints = []
    mock.module("./packages/terminfo.dev/src/detect.ts", () => ({ detectTerminal: () => ({
      name: "kitty", version: "0.49.2", os: "linux", osVersion: "fixture"
    }) }))
    mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
      withRawMode: async callback => callback(), drainStdin: async () => {},
      queryWithSentinelOutcome: async (sequence, pattern) => {
        const reply = sequence === "\x1b[16t" ? "\x1b[6;22;9t"
          : sequence === "\x1b[14t" ? "\x1b[4;528;720t"
          : sequence === "\x1b[18t" ? "\x1b[8;24;80t" : "\x1bP>|kitty(0.49.2)\x1b\\"
        return { raw: reply, rawBase64: Buffer.from(reply).toString("base64"), match: pattern.exec(reply), reason: "reply" }
      }
    }))
    let declaredResizeHook
    const declareWindowSize = () => {}
    mock.module("./packages/terminfo.dev/src/linux-input.ts", () => ({ createLinuxInput: async (_executable, options) => {
      declaredResizeHook = options?.onResizeWindow
      return undefined
    } }))
    mock.module("./packages/terminfo.dev/src/linux-capture.ts", () => ({ ...linux, createLinuxCapture: async (directory, executable) => {
      assert.equal(directory, process.env.TERMINFO_CAPTURE_DIRECTORY)
      assert.deepEqual(executable, { path: provenance.executable.path, sha256: provenance.executable.sha256 })
      return {
        declareWindowSize,
        captureRaw: async (checkpoint) => {
          rawCaptures++
          assert.equal(checkpoint.featureId, "collector.captureCalibration")
          assert.equal(checkpoint.role, "control")
          assert.equal(checkpoint.label, "origin witness")
          return { result: raw, decoded }
        },
        capture: async (checkpoint, origin) => {
          assert.equal(calibrations, 1, "graded captures follow the one batch calibration")
          assert.strictEqual(origin, measured, "every graded capture receives the unchanged measured origin")
          assert.strictEqual(origin.pixelGeometry, pixelGeometry)
          capturedCheckpoints.push(checkpoint)
          return { frame: { role: checkpoint.role, label: checkpoint.label, capturedAt: 2,
            ref: "sha256:" + (capturedCheckpoints.length === 1 ? "a" : "b").repeat(64) }, trace: {} }
        }
      }
    } }))
    mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({ calibrateCaptureOrigin: async options => {
      calibrations++
      assert.strictEqual(options.ctx, source)
      assert.equal(capturedCheckpoints.length, 0, "calibration precedes probe captures")
      assert.strictEqual(await options.captureRaw("origin witness", Date.now() + 1000), decoded)
      return measured
    } }))
    mock.module("./packages/terminfo.dev/src/probes/unified.ts", () => ({ ...unified, runProbeBatch: async options => {
      assert.equal(typeof options.prepareCapture, "function", "Linux serve installation must prepare capture before probe callbacks")
      source = { kind: "live", rows: 24, cols: 80 }
      const retained = []
      await assert.rejects(
        () => options.capture(checkpoints[0]),
        { name: "UndeclaredTerminalGeometry", message: "Linux capture calibration refused: no witnessed text-area origin is available" }
      )
      await options.prepareCapture({ source, featureId: "collector.captureCalibration", recordCapture: result => retained.push(result) })
      assert.equal(calibrations, 1)
      assert.strictEqual(source.captureGeometry.geometry, pixelGeometry)
      assert.deepEqual(retained, [raw], "raw calibration evidence reaches batch retention")
      await assert.rejects(
        () => options.capture({ ...checkpoints[0], pixelGeometry: { ...pixelGeometry, textWidth: pixelGeometry.textWidth - pixelGeometry.cellWidth } }),
        { name: "UndeclaredTerminalGeometry", message: "Linux capture calibration refused: terminal pixel geometry changed after origin calibration" }
      )
      const visualFrames = []
      for (const checkpoint of checkpoints) visualFrames.push((await options.capture(checkpoint)).frame)
      assert.deepEqual(capturedCheckpoints, checkpoints)
      assert.equal(calibrations, 1, "later checkpoints must reuse the batch measurement")
      const results = options.draft.results.map(row => row.featureId !== visualId ? row : {
        ...row, status: "probe-todo", assertionType: "screenshot", criterionBranch: "visual-review",
        rawReplyRef: visualId, frames: visualFrames,
        tests: [{ id: "capture", status: "supported", attempt: { scope: "probe", startedAt: new Date().toISOString() } },
          { id: "review", status: "probe-todo", attempt: { scope: "none" }, reason: "Valid fixture control and target capture; required visual review pending" }]
      })
      // The mock supplies visual capture output only. Production must retain provenance.font itself.
      const batch = { results, rawReplies: { [visualId]: JSON.stringify({ captures: visualFrames }), "collector.captureCalibration.trace": JSON.stringify({ captures: retained }) },
        observations: [], assertions: [], screenshotRefs: retained.map(result => result.frame.ref), ungradedDiagnostics: {}, suiteComplete: false }
      options.onCheckpoint(batch)
      const persisted = JSON.parse(readFileSync(join(process.env.TERMINFO_CAPTURE_DIRECTORY, options.captureRunId + ".draft.json"), "utf8"))
      assert.deepEqual(persisted.screenshotRefs, [raw.frame.ref])
      assert.deepEqual(JSON.parse(persisted.rawReplies["collector.captureCalibration.trace"]).captures, [raw])
      return batch
    } }))
    const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
    const run = await collectProbeRun({ ids: [visualId] })
    assert.strictEqual(declaredResizeHook, declareWindowSize, "serve.ts wires Linux capture resize declaration into createLinuxInput")
    assert.equal(calibrations, 1)
    assert.equal(rawCaptures, 1)
    assert.deepEqual(run.screenshotRefs, [raw.frame.ref])
    assert.deepEqual(JSON.parse(run.rawReplies["collector.captureCalibration.trace"]).captures, [raw])
    const persisted = JSON.parse(readFileSync(join(process.env.TERMINFO_CAPTURE_DIRECTORY, run.runId + ".draft.json"), "utf8"))
    assert.deepEqual(persisted.screenshotRefs, [raw.frame.ref])
    assert.deepEqual(JSON.parse(persisted.rawReplies["collector.captureCalibration.trace"]).captures, [raw])
    // The stored criterion reference must resolve to the exact retained font receipt.
    assert.equal(run.rawReplies[fontKey], fontReceipt, "validated font-source receipt retained in final raw evidence")
    assert.equal(persisted.rawReplies[fontKey], fontReceipt, "final checkpoint retains identical receipt bytes")
    for (const captured of [run, persisted]) {
      const row = captured.results.find(row => row.featureId === visualId)
      assert.equal(row.status, "probe-todo", "fixture source receipt does not grade the visual result")
      assert.ok(row.reason.includes("#32062 font control") && row.reason.includes(proofState),
        "cell TODO names its control gap and actual proof state")
      assert.equal(row.tests.find(test => test.id === "review").reason, row.reason,
        "review TODO and cell expose the same source-control state")
      assert.equal(row.rawReplyRef, visualId, "retain the probe's own capture trace")
      assert.equal(row.tests.find(test => test.id === "review").rawReplyRef, fontKey,
        "existing review-test reference explicitly binds font-source receipt")
      assert.equal(captured.rawReplies[row.tests.find(test => test.id === "review").rawReplyRef], fontReceipt,
        "the criterion's retained source reference resolves to the exact measured receipt")
    }
  `,
      ],
      {
        cwd: packageRoot,
        encoding: "utf8",
        timeout: 10_000,
        env: {
          ...process.env,
          FONT_CONTROL_PROOF_STATE: proofState,
          HOME: home,
          TERMINFO_CAPTURE_DIRECTORY: join(home, "captures"),
          TERMINFO_RUNTIME_PROVENANCE: join(home, "runtime.json"),
          TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
          TERMINFO_DISPOSABLE_RECEIPT: "",
          TERMINFO_TARGET_ID: "",
          TERMINFO_TARGET_VERSION: "",
        },
      },
    )
    expect(result.error, result.stderr).toBeUndefined()
    expect(result.status, result.stderr).toBe(0)
  },
)

async function startTestDaemon(
  source = `import { startDaemon } from "./packages/terminfo.dev/src/serve.ts"; await startDaemon()`,
  environment: Record<string, string | undefined> = {},
) {
  home = mkdtempSync(join(tmpdir(), "terminfo-serve-"))
  child = spawn(process.execPath, ["-e", source], {
    cwd: packageRoot,
    env: { ...process.env, HOME: home, TERM: "dumb", TERM_PROGRAM: "", ...environment },
    stdio: ["pipe", "ignore", "pipe"],
  })
  let filename!: string
  let registration!: { port: number; token?: string; runId: string; pid: number }
  await vi.waitFor(
    () => {
      const files = readdirSync(join(home!, ".terminfo-dev/daemons"))
      expect(files).toHaveLength(1)
      filename = join(home!, ".terminfo-dev/daemons", files[0]!)
      registration = JSON.parse(readFileSync(filename, "utf8")) as typeof registration
    },
    { timeout: 2000 },
  )
  return { filename, registration }
}

afterEach(async () => {
  if (child && child.exitCode === null) {
    child.kill()
    await new Promise<void>((resolve) => child!.once("exit", () => resolve()))
  }
  if (home) rmSync(home, { recursive: true, force: true })
  child = undefined
  home = undefined
})

describe("daemon HTTP boundary", () => {
  // A generic helper test misses both serialization and the client's early non-OK rejection.
  // Only the OS command is substituted: the Darwin census, command callback, HTTP handler and
  // client are real. This fixture establishes byte custody, never a native macOS failure cause.
  it("retains a failed census command's stderr through HTTP and client original custody (30412)", async () => {
    const { registration } = await startTestDaemon(
      String.raw`
        import {mock} from "bun:test"
        import assert from "node:assert/strict"
        import {writeFileSync,readFileSync,readdirSync,existsSync} from "node:fs"
        import {join} from "node:path"
        const cp = await import("node:child_process")
        const spawn = cp.spawn
        mock.module("node:child_process", () => ({...cp, spawn: (file, args, options) => {
          assert.equal(file, "/usr/bin/osascript")
          writeFileSync(join(process.env.HOME,"census-invocation.json"), JSON.stringify({file,args}))
          return spawn(process.execPath, ["-e", "process.stderr.write(Buffer.from([100, 0, 255, 10]));process.exit(17)"], options)
        }}))
        const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
        globalThis.__TERMINFO_BUNDLED_SUITE__ = {manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash:"a".repeat(12),probes: { term:unified.ALL_PROBES.map(p=>p.id).sort()}},collectorRevision:"b".repeat(40)}
        const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
        const {createDarwinCapture} = await import("./packages/terminfo.dev/src/darwin-capture.ts")
        mock.module("./packages/terminfo.dev/src/detect.ts", () => ({detectTerminal:()=>({name:"kitty",version:"0.49.1",os:"macos",osVersion:"fixture"})}))
        mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({...owned,createOwnedTerminal:()=>createDarwinCapture(process.env.HOME,{appPid:41,onRetained:()=>{}})}))
        const {startDaemon} = await import("./packages/terminfo.dev/src/serve.ts")
        await startDaemon()
        const directory=join(process.env.HOME,".terminfo-dev","daemons")
        while(!existsSync(directory)||!readdirSync(directory).length) await Bun.sleep(10)
        const registration=JSON.parse(readFileSync(join(directory,readdirSync(directory)[0]),"utf8"))
        const {requestDaemonProbe}=await import("./packages/terminfo.dev/src/daemon-client.ts")
        const processOwner={asserter:"terminfo-admin",launchRunId:registration.runId,workerPid:registration.pid,
          provider:"kitty",ownerPid:900,executablePath:"/Applications/kitty.app/Contents/MacOS/kitty",
          marker:{flag:"--instance-group",value:"terminfo-"+registration.runId},tty:"/dev/ttys004",intendedVersion:"0.49.1"}
        try {await requestDaemonProbe(registration,{process:processOwner})}
        catch(error){writeFileSync(join(process.env.HOME,"client-failure.json"),JSON.stringify({
          message:error.message,status:error.status,path:error.path,sha256:error.sha256}))}
      `,
      {
        TERMINFO_PROBE_HASH: "",
        TERMINFO_SOURCE_REVISION: "",
        TERMINFO_CAPTURE_DIRECTORY: "",
        TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
        TERMINFO_DISPOSABLE_RECEIPT: "",
        TERMINFO_RUNTIME_PROVENANCE: "",
      },
    )
    if (!home || !registration.token) throw new Error("Diagnostic fixture lacks its private home or daemon token")
    const privateHome = home
    {
      let failure: unknown
      await vi.waitFor(
        () => {
          failure = JSON.parse(readFileSync(join(privateHome, "client-failure.json"), "utf8"))
        },
        { timeout: 5000 },
      )
      expect(JSON.parse(readFileSync(join(privateHome, "census-invocation.json"), "utf8"))).toMatchObject({
        file: "/usr/bin/osascript",
        args: ["-l", "JavaScript", "-e", expect.stringContaining("CGWindowListCopyWindowInfo")],
      })
      expect(failure).toMatchObject({ status: 500 })
      const directory = join(privateHome, ".terminfo-dev", "http-responses")
      const files = readdirSync(directory).filter((name) => /^[a-f0-9]{64}$/.test(name))
      expect(files).toHaveLength(1)
      expect(readdirSync(directory).some((name) => name.endsWith(".json"))).toBe(true)
      const path = join(directory, files[0]!)
      const bytes = readFileSync(path)
      const sha256 = createHash("sha256").update(bytes).digest("hex")
      expect(failure).toMatchObject({ path, sha256 })
      expect(failure).toHaveProperty("message", expect.stringContaining("HTTP 500"))
      expect(failure).toHaveProperty("message", expect.stringContaining(path))
      expect(failure).toHaveProperty("message", expect.stringContaining(sha256))
      expect(files[0]).toBe(sha256)
      const body = JSON.parse(bytes.toString())
      expect(body).toHaveProperty("captureCommand", {
        file: "/usr/bin/osascript",
        args: ["-l", "JavaScript", "-e", expect.stringContaining("CGWindowListCopyWindowInfo")],
        stdoutBase64: "",
        stderrBase64: Buffer.from([100, 0, 255, 10]).toString("base64"),
        code: 17,
        signal: null,
        killed: false,
      })
      expect(bytes.toString()).not.toContain(registration.token)
    }
  })

  // Carrier validation precedes source-suite loading. The old endpoint ignored
  // these bodies and tried to probe; authentication coverage did not detect that.
  it("refuses malformed probe requests with original diagnostics before collection", async () => {
    const { registration } = await startTestDaemon()
    const url = `http://127.0.0.1:${registration.port}/probe`
    const owner = {
      asserter: "terminfo-admin",
      launchRunId: registration.runId,
      workerPid: registration.pid,
      windowId: 791,
      tabTty: "/dev/ttys004",
      intendedVersion: "2.15",
    }
    const processOwner = {
      asserter: "terminfo-admin",
      launchRunId: registration.runId,
      workerPid: registration.pid,
      provider: "kitty",
      ownerPid: 900,
      executablePath: "/Applications/kitty.app/Contents/MacOS/kitty",
      marker: { flag: "--instance-group", value: `terminfo-${registration.runId}` },
      tty: "/dev/ttys004",
      intendedVersion: "0.44.0",
    }
    const headers = { Authorization: `Bearer ${registration.token}`, "Content-Type": "application/json" }
    const unauthenticated = await fetch(url, { method: "POST", body: JSON.stringify({ terminalAppOwner: owner }) })
    expect(unauthenticated.status).toBe(403)
    // The new ids carrier must name its own invalid input; owner-only rejection coverage
    // previously allowed every parse failure to be replaced by an owner-assertion message.
    for (const [body, diagnostic] of [
      [JSON.stringify({ ids: null }), "Invalid probe request ids: expected resolved probe ids"],
      [JSON.stringify({ ids: "cursor.hide" }), "Invalid probe request ids: expected resolved probe ids"],
      [JSON.stringify({ ids: ["cursor.hide", 3] }), "Invalid probe request ids: expected resolved probe ids"],
      ["{malformed", /JSON/],
      [JSON.stringify({ terminalAppOwner: null }), "Invalid Terminal.app owner assertion"],
      [
        JSON.stringify({ terminalAppOwner: { ...owner, launchRunId: "f".repeat(32) } }),
        "Terminal.app owner assertion differs from this daemon's launch run or PID",
      ],
      [
        JSON.stringify({ terminalAppOwner: { ...owner, workerPid: registration.pid + 1 } }),
        "Terminal.app owner assertion differs from this daemon's launch run or PID",
      ],
      [
        JSON.stringify({ terminalAppOwner: { ...owner, token: registration.token } }),
        "Invalid Terminal.app owner assertion",
      ],
      [JSON.stringify({ unexpectedOwner: owner }), "Invalid probe request shape"],
      [JSON.stringify({ processOwner: null }), "Invalid process owner assertion"],
      [
        JSON.stringify({ processOwner: { ...processOwner, launchRunId: "f".repeat(32) } }),
        "Process owner assertion differs from this daemon's launch run or PID",
      ],
      [
        JSON.stringify({ processOwner: { ...processOwner, workerPid: registration.pid + 1 } }),
        "Process owner assertion differs from this daemon's launch run or PID",
      ],
      [JSON.stringify({ processOwner: { ...processOwner, windowId: 791 } }), "Invalid process owner assertion"],
      [
        JSON.stringify({ terminalAppOwner: owner, processOwner: { ...owner, provider: "kitty" } }),
        "Invalid probe request shape",
      ],
    ] as const) {
      const response = await fetch(url, { method: "POST", headers, body })
      expect(response.status).toBe(400)
      const payload = await response.json()
      expect(payload).toEqual({
        error: typeof diagnostic === "string" ? diagnostic : expect.stringMatching(diagnostic),
      })
      expect(JSON.stringify(payload)).not.toContain(registration.token)
    }
  })

  it("refuses v2 collection without a declared source suite", async () => {
    const { registration } = await startTestDaemon()
    const response = await fetch(`http://127.0.0.1:${registration.port}/probe`, {
      headers: { Authorization: `Bearer ${registration.token}` },
    })
    expect(response.status).toBe(500)
    const body: unknown = await response.json()
    expect(body).toEqual({
      name: "Error",
      error: "Current collection requires TERMINFO_PROBE_HASH and TERMINFO_SOURCE_REVISION from a source-tree launcher",
    })
  })

  it("requires its private token and refuses cross-origin mutation", async () => {
    const { registration } = await startTestDaemon()
    const url = `http://127.0.0.1:${registration.port}/query`
    const body = JSON.stringify({ commands: [{ write: "test" }] })
    const unauth = await fetch(url, { method: "POST", body })
    expect(unauth.status).toBe(403)
    expect(registration.token).toMatch(/^[0-9a-f]{64}$/)
    const headers = { Authorization: `Bearer ${registration.token}` }
    const crossOrigin = await fetch(url, {
      method: "POST",
      body,
      headers: { ...headers, Origin: "https://evil.example" },
    })
    expect(crossOrigin.status).toBe(403)
    const authorized = await fetch(url, { method: "POST", body, headers })
    expect(authorized.status).toBe(200)
  }, 5000)

  it("names a malformed registration instead of silently omitting it", () => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-"))
    const dir = join(home, ".terminfo-dev/daemons")
    mkdirSync(dir, { recursive: true })
    const badFile = join(dir, "bad.json")
    writeFileSync(badFile, "{broken")
    const result = spawnSync(
      process.execPath,
      ["-e", `import { listDaemons } from "./packages/terminfo.dev/src/serve.ts"; listDaemons()`],
      {
        cwd: packageRoot,
        env: { ...process.env, HOME: home },
        encoding: "utf8",
      },
    )
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain(badFile)
  })

  it("reports failure to remove its own registration on shutdown", async () => {
    const { filename } = await startTestDaemon()
    const stderr: Buffer[] = []
    child!.stderr!.on("data", (chunk: Buffer) => stderr.push(chunk))
    rmSync(filename)
    mkdirSync(filename)
    child!.kill("SIGTERM")
    const exitCode = await new Promise<number | null>((resolve) => child!.once("exit", resolve))
    expect(exitCode).toBe(1)
    expect(Buffer.concat(stderr).toString()).toContain(filename)
  }, 5000)
})

/**
 * Run one inline collector script against the hosted-Darwin capture environment. The capture
 * directory is what makes a run `darwinHosted`, so a script can drop it to collect the same
 * terminal with NO capture adapter at all and compare the two runs row for row.
 */
function runHostedDarwinFixture(script: string, timeoutMs = 10_000) {
  home = mkdtempSync(join(tmpdir(), "terminfo-serve-calibration-"))
  return spawnSync(process.execPath, ["-e", script], {
    cwd: packageRoot,
    env: {
      ...process.env,
      HOME: home,
      TERMINFO_CAPTURE_DIRECTORY: join(home, "captures"),
      TERMINFO_DISPOSABLE_RECEIPT: "hardware-receipt-fixture",
      TERMINFO_RUNTIME_PROVENANCE: "",
      TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
    },
    encoding: "utf8",
    timeout: timeoutMs,
  })
}

/**
 * Collect through the owned-process arm on Darwin with a capture directory. The real collector and
 * batch run; the owner proof, the capture adapter and the calibration are recording fixtures, so the
 * script reports which app PID the adapter was installed for, how often calibration ran, and any
 * refusal. `ownerPid` is the pid the verified owner reports; undefined is an owner with none.
 */
function runDarwinProcessCaptureFixture(ownerPid: number | undefined) {
  home = mkdtempSync(join(tmpdir(), "terminfo-serve-process-capture-"))
  const ownerPidField = ownerPid === undefined ? "" : `appPid: ${ownerPid},`
  const script = `
    import { mock } from "bun:test"
    Object.defineProperty(process, "platform", { value: "darwin" })
    const tty = await import("./packages/terminfo.dev/src/tty.ts")
    const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
    const geometry = { status: "measured", rows: 24, cols: 80 }
    const appPids = []
    let calibrationCalls = 0
    mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
      detectTerminal: () => ({ name: "ghostty", version: "1.3.1", os: "macos", osVersion: "fixture" })
    }))
    mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
      ownedTerminalVerifiedFor: () => true,
      createOwnedTerminal: async () => ({ geometryAtGrant: geometry, geometrySource: "fixture", ${ownerPidField}
        summary: JSON.stringify({preflightIdentity:{pid:process.pid,startedAtEpochSeconds:1792698257,launchRunId:"a".repeat(32)}}), readGeometry: async () => geometry, dispose: async () => {} })
    }))
    mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
      withRawMode: async callback => callback(), drainStdin: async () => {},
      queryWithSentinelOutcome: async (sequence, pattern) => {
        const raw = sequence.includes("[18t") ? "\\x1b[8;24;80t"
          : sequence.includes("[16t") ? "\\x1b[6;17;8t"
          : sequence.includes("[14t") ? "\\x1b[4;408;640t"
          : "\\x1bP>|ghostty 1.3.1\\x1b\\\\"
        return { raw, rawBase64: Buffer.from(raw).toString("base64"), match: pattern.exec(raw), reason: "reply" }
      }
    }))
    mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({
      createDarwinCapture: async (_directory, options) => {
        appPids.push(options.appPid)
        const refuse = async () => { throw new Error("capture must retain the calibration refusal") }
        return { capture: refuse, captureRaw: refuse }
      }
    }))
    mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({
      calibrateCaptureOrigin: async () => {
        calibrationCalls++
        const error = new Error("Capture calibration fixture: refused")
        error.name = "CaptureCalibrationRefused"
        throw error
      }
    }))
    const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
    globalThis.__TERMINFO_BUNDLED_SUITE__ = {
      manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },
      collectorRevision: "b".repeat(40)
    }
    const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
    let refusal
    try {
      await collectProbeRun({ ids: ["extensions.truecolor", "erase.line.all"], processOwner: { provider: "ghostty" } })
    } catch (error) {
      refusal = error.message
    }
    console.log("RESULT " + JSON.stringify({ appPids, calibrationCalls, refusal }))
  `
  const result = spawnSync(process.execPath, ["-e", script], {
    cwd: packageRoot,
    env: {
      ...process.env,
      HOME: home,
      TERMINFO_CAPTURE_DIRECTORY: join(home, "captures"),
      TERMINFO_DISPOSABLE_RECEIPT: "",
      TERMINFO_RUNTIME_PROVENANCE: "",
      TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
    },
    encoding: "utf8",
    timeout: 10_000,
  })
  const line = /RESULT (\{.*\})/.exec(result.stdout)?.[1]
  if (!line) throw new Error(`process capture fixture printed no RESULT line; stderr: ${result.stderr}`)
  return { stderr: result.stderr, observed: JSON.parse(line) as unknown }
}

/**
 * #33013: the clipboard-config check lives in the collector, not in its helper, and a hosted Mac
 * run presents one of two provenance shapes beside a null adapter config: no provenance at all, or
 * a provenance whose fixture config is the launcher string. On 2026-11-10 a fix for this check
 * merged without either shape being driven through `collectProbeRun`, so every hosted Mac run
 * still refused at the check before measuring. These cases drive the caller, not the helper.
 */
it.each([
  ["absent", ""],
  ["a launcher string", "--config NONE"],
])(
  "a hosted Darwin run reaches its batch when the provenance is %s and the adapter config is null",
  (_shape, launcherConfig) => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-clipboard-"))
    const provenancePath = join(home, "runtime.json")
    if (launcherConfig !== "") {
      writeFileSync(
        provenancePath,
        JSON.stringify({
          executable: { path: "/fixture/ghostty", sha256: "cd".repeat(32), version: "ghostty 1.3.1" },
          sourceArtifact: { url: "https://example.invalid/ghostty.tar", sha256: "de".repeat(32) },
          runtime: {
            imageId: "sha256:" + "ef".repeat(32),
            imageTarSha256: "12".repeat(32),
            arch: "arm64",
            nixLockRevision: "c".repeat(40),
            sourceRevision: "b".repeat(40),
            cleanTree: true,
            suiteHash: "a".repeat(12),
          },
          fixture: {
            definition: "callbacks",
            config: launcherConfig,
            font: "fixture",
            geometry: "80x24",
            display: "fixture",
            gl: "fixture",
          },
        }),
      )
    }
    const result = spawnSync(
      process.execPath,
      [
        "-e",
        [
          'import { mock } from "bun:test"',
          'Object.defineProperty(process, "platform", { value: "darwin" })',
          'const tty = await import("./packages/terminfo.dev/src/tty.ts")',
          'const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")',
          'const geometry = { status: "measured", rows: 24, cols: 80 }',
          'mock.module("./packages/terminfo.dev/src/detect.ts", () => ({ detectTerminal: () => ({ name: "ghostty", version: "1.3.1", os: "macos", osVersion: "fixture" }) }))',
          'mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,',
          "  ownedTerminalVerifiedFor: () => true,",
          '  createOwnedTerminal: async () => ({ geometryAtGrant: geometry, geometrySource: "fixture", appPid: process.pid,',
          '    summary: JSON.stringify({ preflightIdentity: { pid: process.pid, startedAtEpochSeconds: 1792698257, launchRunId: "a".repeat(32) } }),',
          "    readGeometry: async () => geometry,",
          '    clipboard: { profile: "default", config: null, summary: "{}", assertOwned: async () => {} },',
          "    dispose: async () => {} })",
          "}))",
          'mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,',
          "  withRawMode: async callback => callback(), drainStdin: async () => {},",
          "  queryWithSentinelOutcome: async (sequence, pattern) => {",
          '    const raw = sequence.includes("[18t") ? "\\u001b[8;24;80t"',
          '      : sequence.includes("[16t") ? "\\u001b[6;17;8t"',
          '      : sequence.includes("[14t") ? "\\u001b[4;408;640t"',
          '      : "\\u001bP>|ghostty 1.3.1\\u001b\\\\"',
          '    return { raw, rawBase64: Buffer.from(raw).toString("base64"), match: pattern.exec(raw), reason: "reply" }',
          "  }",
          "}))",
          'mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({ createDarwinCapture: async () => ({ capture: async () => { throw new Error("this fixture requests no frame") }, captureRaw: async () => { throw new Error("this fixture requests no frame") } }) }))',
          'mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({ calibrateCaptureOrigin: async () => ({ origin: { x: 0, y: 0 }, basis: "fixture", pixelGeometry: { scale: 1, rows: 24, cols: 80, width: 640, height: 408 } }) }))',
          'const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")',
          "globalThis.__TERMINFO_BUNDLED_SUITE__ = {",
          '  manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },',
          '  collectorRevision: "b".repeat(40)',
          "}",
          'const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")',
          "let refusal, reached = false",
          "try {",
          '  await collectProbeRun({ ids: ["device.primary-da"], processOwner: { provider: "ghostty" } })',
          "  reached = true",
          "} catch (error) {",
          "  refusal = error instanceof Error ? error.message : String(error)",
          "}",
          'console.log("RESULT " + JSON.stringify({ reached, refusal }))',
        ].join("\n"),
      ],
      {
        cwd: packageRoot,
        env: {
          ...process.env,
          HOME: home,
          TERMINFO_CAPTURE_DIRECTORY: join(home, "captures"),
          TERMINFO_DISPOSABLE_RECEIPT: "",
          TERMINFO_RUNTIME_PROVENANCE: launcherConfig === "" ? "" : provenancePath,
          TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
        },
        encoding: "utf8",
        timeout: 15_000,
      },
    )
    const line = /RESULT (\{.*\})/.exec(result.stdout)?.[1]
    if (!line) throw new Error(`clipboard fixture printed no RESULT line; stderr: ${result.stderr}`)
    const observed = JSON.parse(line) as { reached: boolean; refusal?: string }
    expect(observed.refusal ?? "").not.toMatch(/differs from runtime provenance/)
    expect(observed.refusal ?? "").not.toMatch(/reading 'config'/)
    expect(observed).toEqual({ reached: true })
  },
)
describe("private finite daemon startup", () => {
  // @cto D5 (#30518): the owned-process arm captures through the SAME Darwin pixel install as the
  // hosted arm, for the pid its owner proof verified, and refuses by name when there is none.
  it("installs the Darwin pixel capture for the owned process arm on its verified owner pid", () => {
    const { stderr, observed } = runDarwinProcessCaptureFixture(4242)
    expect(observed).toEqual({ appPids: [4242], calibrationCalls: 1 })
    expect(stderr).toBe("")
  })

  it("refuses an owned-process capture by name when the verified owner reports no pid", () => {
    const { observed } = runDarwinProcessCaptureFixture(undefined)
    expect(observed).toEqual({
      appPids: [],
      calibrationCalls: 0,
      refusal: "Verified process terminal has no measured app PID for capture",
    })
  })

  it("reports the same named capture refusal for the first and later probes when Darwin calibration fails", () => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-calibration-"))
    const result = spawnSync(
      process.execPath,
      [
        "-e",
        `
        import { mock } from "bun:test"
        import assert from "node:assert/strict"
        Object.defineProperty(process, "platform", { value: "darwin" })
        const tty = await import("./packages/terminfo.dev/src/tty.ts")
        const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
        const receipt = await import("./packages/terminfo.dev/src/disposable-receipt.ts")
        let calibrationCalls = 0, unexpectedCaptures = 0
        const geometry = { status: "measured", rows: 24, cols: 80 }
        mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
          detectTerminal: () => ({ name: "ghostty", version: "1.3.1", os: "macos", osVersion: "fixture" })
        }))
        // Hardware admission is covered by owned-terminal tests; keep the real collector/batch.
        mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
          ownedTerminalVerifiedFor: () => true,
          createOwnedTerminal: async () => ({ geometryAtGrant: geometry, geometrySource: "fixture",
            appPid: 42, hostedAppId: "ghostty", summary: "owned fixture", readGeometry: async () => geometry, dispose: async () => {} })
        }))
        mock.module("./packages/terminfo.dev/src/disposable-receipt.ts", () => ({ ...receipt,
          readDisposableReceipt: () => undefined
        }))
        mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
          withRawMode: async callback => callback(), drainStdin: async () => {},
          queryWithSentinelOutcome: async (sequence, pattern) => {
            const raw = sequence.includes("[18t") ? "\\x1b[8;24;80t"
              : sequence.includes("[16t") ? "\\x1b[6;17;8t"
              : sequence.includes("[14t") ? "\\x1b[4;408;640t"
              : "\\x1bP>|ghostty 1.3.1\\x1b\\\\"
            return { raw, rawBase64: Buffer.from(raw).toString("base64"), match: pattern.exec(raw), reason: "reply" }
          }
        }))
        mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({
          createDarwinCapture: async () => ({
            capture: async () => { unexpectedCaptures++; throw new Error("capture must retain the calibration refusal") },
            captureRaw: async () => { unexpectedCaptures++; throw new Error("capture must retain the calibration refusal") }
          })
        }))
        mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({
          calibrateCaptureOrigin: async () => {
            calibrationCalls++
            const error = new Error("Capture calibration fixture: non-solid difference cannot supply an origin")
            error.name = "CaptureCalibrationRefused"
            throw error
          }
        }))
        const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
        globalThis.__TERMINFO_BUNDLED_SUITE__ = {
          manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },
          collectorRevision: "b".repeat(40)
        }
        const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
        const ids = ["extensions.truecolor", "erase.line.all"]
        const run = await collectProbeRun({ ids })
        const selected = run.results.filter(o => ids.includes(o.featureId))
        assert.deepEqual(selected.map(o => o.featureId).sort(), [...ids].sort())
        assert.ok(selected.every(o => o.status === "probe-todo"))
        assert.ok(selected.every(o => /Capture calibration fixture: non-solid difference/.test(o.reason ?? "")))
        assert.equal("ungradedDiagnostics" in run, false)
        assert.equal(calibrationCalls, 1)
        assert.equal(unexpectedCaptures, 0)
      `,
      ],
      {
        cwd: packageRoot,
        env: {
          ...process.env,
          HOME: home,
          TERMINFO_CAPTURE_DIRECTORY: join(home, "captures"),
          TERMINFO_DISPOSABLE_RECEIPT: "hardware-receipt-fixture",
          TERMINFO_RUNTIME_PROVENANCE: "",
          TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
        },
        encoding: "utf8",
        timeout: 5000,
      },
    )
    expect(result.stderr).toBe("")
    expect(result.status).toBe(0)
  })

  // Terminal.app answered no CSI 16 t on a github-hosted runner and its own text area did not
  // divide into whole pixels (860x120, 467x30), so 51 rows were left ungraded with one refusal
  // message and the whole run was inadmissible as suite-incomplete (28785). A terminal whose cells
  // cannot be mapped is a run WITHOUT a capture adapter: every probe then takes its own no-capture
  // branch, the suite is complete, and the run records why it could not calibrate.
  it("attempts raster calibration when hosted Darwin window replies do not supply cells", () => {
    const result = runHostedDarwinFixture(`
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      Object.defineProperty(process, "platform", { value: "darwin" })
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      const receipt = await import("./packages/terminfo.dev/src/disposable-receipt.ts")
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const geometry = { status: "measured", rows: 30, cols: 120, at: "2026-10-15T00:00:00.000Z", source: "fixture", stdout: "30 120\\n", stderr: "" }
      const silent = { match: null, reason: "timeout", raw: "", rawBase64: "" }
      let frames = 0, calibrations = 0
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
        detectTerminal: () => ({ name: "terminal-app", version: "2.15", os: "macos", osVersion: "26.6.2" })
      }))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
        ownedTerminalVerifiedFor: () => true,
        createOwnedTerminal: async () => ({ geometryAtGrant: geometry, geometrySource: "fixture", appPid: 5705, hostedAppId: "terminal-app",
          summary: "{}", readGeometry: async () => geometry, dispose: async () => {} })
      }))
      mock.module("./packages/terminfo.dev/src/disposable-receipt.ts", () => ({ ...receipt, readDisposableReceipt: () => undefined }))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
        withRawMode: async (cb) => cb(), drainStdin: async () => {},
        query: async () => null, queryWithSentinel: async () => null, queryOutcome: async () => silent,
        queryCursorPosition: async () => null, measureRenderedWidth: async () => ({ kind: "no-reply", step: "sample" } as const),
        measureUtf8Decoding: async () => "silent", queryMode: async () => null, readResponse: async () => null,
        queryWithSentinelOutcome: async (sequence, pattern) => {
          const reply = sequence === "\\x1b[14t" ? "\\x1b[4;467;860t"
            : sequence === "\\x1b[18t" ? "\\x1b[8;30;120t"
            : "\\x1b[?1;2c"
          return { raw: reply, rawBase64: Buffer.from(reply).toString("base64"), match: pattern.exec(reply), reason: pattern.test(reply) ? "reply" : "sentinel" }
        }
      }))
      const installCensus = {
        window: { id: 7, ownerPid: 41, layer: 0, bounds: { x: 0, y: 0, width: 120, height: 30 } },
        observations: { sharingState: null, memoryUsage: null, alpha: 1, onscreen: true },
        ownedWindows: [],
        takenAt: "2026-10-22T20:00:00.000Z",
      }
      mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({ createDarwinCapture: async () => ({
        capture: async () => { frames++; throw new Error("no frame may be requested for a refused calibration") },
        captureRaw: async () => { frames++; throw new Error("no frame may be requested for a refused calibration") },
        installCensus,
      }) }))
      mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({ calibrateCaptureOrigin: async () => {
        calibrations++
        throw Object.assign(new Error("Capture calibration nonuniform columns: native fixture has unequal cell edges"), { name: "CaptureCalibrationRefused" })
      } }))
      globalThis.__TERMINFO_BUNDLED_SUITE__ = { manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12),
        probes: { term: unified.ALL_PROBES.map((p) => p.id).sort() } }, collectorRevision: "b".repeat(40) }
      const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
      const refused = await collectProbeRun({})
      delete process.env.TERMINFO_CAPTURE_DIRECTORY
      const bare = await collectProbeRun({})
      // Row for row, a refused calibration IS a run with no capture adapter: every row that would
      // have asked for a frame takes the branch it would have taken with no capture at all. Only
      // the NOTE differs, and it must, because a refused run says why (@cto, 28785 REVISE must 1).
      // Compare the same retained facts while excluding the intentionally different refusal reason and wall-clock times.
      const withoutNote = (run) => JSON.parse(JSON.stringify(run.results, (key, value) => ["reason", "startedAt", "completedAt"].includes(key) ? undefined : value))
      assert.deepEqual(withoutNote(refused), withoutNote(bare))
      const noAdapter = (run) => run.results.filter((o) => /no owned capture adapter is installed in this run/.test(o.reason ?? ""))
      const named = refused.results.filter((o) => /cell-to-pixel geometry was refused/.test(o.reason ?? ""))
      assert.equal(named.length, noAdapter(bare).length)
      assert.equal(noAdapter(refused).length, 0)
      assert.ok(named.every((o) => /nonuniform columns/.test(o.reason)))
      assert.equal(refused.results.length, globalThis.__TERMINFO_BUNDLED_SUITE__.manifest.catalogIds.length)
      assert.equal(bare.results.length, globalThis.__TERMINFO_BUNDLED_SUITE__.manifest.catalogIds.length)
      assert.equal("ungradedDiagnostics" in refused, false)
      assert.equal("ungradedDiagnostics" in bare, false)
      // No probe ever saw a capture adapter, and no origin was calibrated for one.
      assert.equal(frames, 0)
      assert.equal(calibrations, 1)
      // A run with NO capture adapter records no calibration at all, so a reader can tell that apart
      // from a terminal that refused to be calibrated.
      assert.equal(bare.rawReplies["collector.captureCalibration"], undefined)
      const fact = JSON.parse(refused.rawReplies["collector.captureCalibration"])
      assert.equal(fact.outcome, "refused")
      assert.equal(fact.basis, undefined)
      assert.equal(fact.geometry, undefined)
      assert.deepEqual(fact.queries.map((q) => [q.sequence, q.reason, q.raw]), [
        ["\\x1b[16t", "sentinel", "\\x1b[?1;2c"],
        ["\\x1b[14t", "reply", "\\x1b[4;467;860t"],
        ["\\x1b[18t", "reply", "\\x1b[8;30;120t"]
      ])
      assert.match(fact.refusal, /Capture calibration nonuniform columns/)
      // #30392 C1/C3: a REFUSED calibration records the install census too — that is exactly the run
      // where a reader needs to know which window the app owned before anything was asked.
      assert.deepEqual(fact.installCensus, installCensus)
    `)
    expect(result.stderr).toBe("")
    expect(result.status).toBe(0)
  })

  // alacritty answers no CSI 16 t and reports the same text area twice (798x598 over 133x46), which
  // divides into a 6x13 cell — the derived basis the pre-flight must accept. Its rows must decide
  // exactly as they do when the terminal reports the same cell size itself, and the run records
  // WHICH basis the geometry rests on.
  it("installs the capture on a derived alacritty cell size, deciding the same rows as a 16 t report", () => {
    const result = runHostedDarwinFixture(
      `
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      import { readdirSync, readFileSync } from "node:fs"
      import { join } from "node:path"
      Object.defineProperty(process, "platform", { value: "darwin" })
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      const receipt = await import("./packages/terminfo.dev/src/disposable-receipt.ts")
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const geometry = { status: "measured", rows: 46, cols: 133, at: "2026-10-15T00:00:00.000Z", source: "fixture", stdout: "46 133\\n", stderr: "" }
      const silent = { match: null, reason: "timeout", raw: "", rawBase64: "" }
      let reportedCellSize = null, frames = 0, calibrations = 0, calibrationFailure
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
        detectTerminal: () => ({ name: "alacritty", version: "0.17.0", os: "macos", osVersion: "26.6.2" })
      }))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
        ownedTerminalVerifiedFor: () => true,
        createOwnedTerminal: async () => ({ geometryAtGrant: geometry, geometrySource: "fixture", appPid: 42, hostedAppId: "alacritty",
          summary: "{}", readGeometry: async () => geometry, dispose: async () => {} })
      }))
      mock.module("./packages/terminfo.dev/src/disposable-receipt.ts", () => ({ ...receipt, readDisposableReceipt: () => undefined }))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
        withRawMode: async (cb) => cb(), drainStdin: async () => {},
        query: async () => null, queryWithSentinel: async () => null, queryOutcome: async () => silent,
        queryCursorPosition: async () => null, measureRenderedWidth: async () => ({ kind: "no-reply", step: "sample" } as const),
        measureUtf8Decoding: async () => "silent", queryMode: async () => null, readResponse: async () => null,
        queryWithSentinelOutcome: async (sequence, pattern) => {
          const reply = sequence === "\\x1b[16t" ? (reportedCellSize ?? "\\x1b[?6c")
            : sequence === "\\x1b[14t" ? "\\x1b[4;598;798t"
            : sequence === "\\x1b[18t" ? "\\x1b[8;46;133t"
            : "\\x1bP>|alacritty 0.17.0\\x1b\\\\"
          return { raw: reply, rawBase64: Buffer.from(reply).toString("base64"), match: pattern.exec(reply), reason: pattern.test(reply) ? "reply" : "sentinel" }
        }
      }))
      mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({ createDarwinCapture: async () => ({
        capture: async (checkpoint) => {
          frames++
          // A fixture frame: byte-stable across two reads of one static frame, and painted exactly
          // when the sentinel glyph is asked for, so the oracle's paint witness proves out.
          const painted = checkpoint.label.includes("paint witness")
          return { frame: { role: checkpoint.role, ref: "sha256:" + (painted ? "d" : "a").repeat(64), capturedAt: 1,
            label: checkpoint.label, regionDigest: "sha256:" + (painted ? "e" : "b").repeat(64),
            pixelsDigest: "sha256:" + "c".repeat(64) }, trace: { captureCommand: "fixture" } }
        },
        captureRaw: async (checkpoint) => {
          frames++
          return { result: { frame: { role: checkpoint.role, ref: "sha256:" + "f".repeat(64), capturedAt: 1,
            label: checkpoint.label, regionDigest: "sha256:" + "b".repeat(64), pixelsDigest: "sha256:" + "c".repeat(64) },
            trace: { captureCommand: "fixture" } }, decoded: { width: 1, height: 1, rgba: Buffer.alloc(4) } }
        }
      }) }))
      mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({ calibrateCaptureOrigin: async ({ pixelGeometry, captureRaw, collectorLaunched }) => {
        calibrations++
        assert.equal(collectorLaunched, true)
        // A restore timeout has already taken its screenshots; the failure draft must keep them (30666).
        if (calibrationFailure?.name === "CaptureRestoreFailed") {
          await captureRaw("restore grid paint", Date.now() + 1000)
          await captureRaw("restore grid paint confirmation", Date.now() + 1000)
        }
        if (calibrationFailure) throw calibrationFailure
        assert.deepEqual(pixelGeometry, { cellWidth: 6, cellHeight: 13, textWidth: 798, textHeight: 598 })
        return { origin: { x: 0, y: 0 }, pixelGeometry: { cellWidth: 6, cellHeight: 13, textWidth: 798, textHeight: 598 }, basis: "fixture complete raster" }
      } }))
      globalThis.__TERMINFO_BUNDLED_SUITE__ = { manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12),
        probes: { term: unified.ALL_PROBES.map((p) => p.id).sort() } }, collectorRevision: "b".repeat(40) }
      const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
      const derived = await collectProbeRun({})
      reportedCellSize = "\\x1b[6;13;6t"
      const reported = await collectProbeRun({})
      const originalTimeout = new Error("solid grid paint witness timeout")
      calibrationFailure = Object.assign(new Error("Capture calibration restore failed: Capture calibration restore grid paint: paint witness timeout after capture", { cause: originalTimeout }), { name: "CaptureRestoreFailed" })
      await assert.rejects(collectProbeRun({}), error => error === calibrationFailure)
      const failed = readdirSync(process.env.TERMINFO_CAPTURE_DIRECTORY).filter((name) => name.endsWith(".draft.json"))
        .map((name) => JSON.parse(readFileSync(join(process.env.TERMINFO_CAPTURE_DIRECTORY, name), "utf8")))
        .filter((draft) => draft.rawReplies["collector.failure"] === calibrationFailure.message)
      assert.equal(failed.length, 1)
      assert.deepEqual(JSON.parse(failed[0].rawReplies["collector.captureCalibration.trace"] ?? "{}").captures?.map(({ frame }) => [frame.label, frame.capturedAt, frame.ref]), [
        ["restore grid paint", 1, "sha256:" + "f".repeat(64)],
        ["restore grid paint confirmation", 1, "sha256:" + "f".repeat(64)],
      ])
      calibrationFailure = new Error("Original capture adapter I/O failure", { cause: originalTimeout })
      await assert.rejects(collectProbeRun({}), error => error === calibrationFailure)
      // Actual iTerm2 41555062118: census command killed at the capture deadline,
      // then no baseline available for restoration. Complete with the named gap,
      // preserving both errors and the native command evidence, never a grade.
      const censusFailure = Object.assign(new Error("osascript window census killed"), {
        captureCommand: { file: "/usr/bin/osascript", args: ["-l", "JavaScript"],
          killed: true, signal: "SIGKILL", code: null, stdoutBase64: "", stderrBase64: "" },
      })
      calibrationFailure = Object.assign(new AggregateError([censusFailure, new Error("Secondary restoration unverified: no confirmed baseline image")],
        "osascript window census killed; secondary capture restoration failure: no confirmed baseline image", { cause: censusFailure }), { name: "CaptureRestoreFailed" })
      const unavailable = await collectProbeRun({})
      const unavailableFact = JSON.parse(unavailable.rawReplies["collector.captureCalibration"])
      assert.equal(unavailable.results.length, globalThis.__TERMINFO_BUNDLED_SUITE__.manifest.catalogIds.length)
      assert.equal(unavailableFact.outcome, "refused")
      assert.match(unavailableFact.refusal, /^osascript window census killed; secondary capture restoration failure/)
      assert.deepEqual(unavailableFact.causes[1].captureCommand, censusFailure.captureCommand)
      assert.ok(!unavailable.results.some(o => o.assertionType === "screenshot"))
      assert.ok(unavailable.results.some(o => /cell-to-pixel geometry was refused.*osascript window census killed/.test(o.reason ?? "")))
      calibrationFailure = Object.assign(new Error("Capture calibration paint not observed: solid grid paint witness timeout", { cause: originalTimeout }), { name: "CaptureCalibrationRefused" })
      const unseen = await collectProbeRun({})
      assert.equal(unseen.results.length, globalThis.__TERMINFO_BUNDLED_SUITE__.manifest.catalogIds.length)
      assert.equal("ungradedDiagnostics" in unseen, false)
      assert.equal(JSON.parse(unseen.rawReplies["collector.captureCalibration"]).outcome, "refused")
      assert.match(JSON.parse(unseen.rawReplies["collector.captureCalibration"]).refusal, /paint not observed/)
      assert.deepEqual(JSON.parse(unseen.rawReplies["collector.captureCalibration"]).causes, [
        { name: "CaptureCalibrationRefused", message: calibrationFailure.message },
        { name: "Error", message: originalTimeout.message },
      ])
      assert.ok(!unseen.results.some(o => o.assertionType === "screenshot"))
      calibrationFailure = undefined
      delete process.env.TERMINFO_CAPTURE_DIRECTORY
      reportedCellSize = null
      const bare = await collectProbeRun({})
      const cell = { cellWidth: 6, cellHeight: 13, textWidth: 798, textHeight: 598 }
      const derivedFact = JSON.parse(derived.rawReplies["collector.captureCalibration"])
      assert.equal(derivedFact.outcome, "installed")
      assert.equal(derivedFact.basis, "measured by complete raster calibration")
      assert.equal(derivedFact.rasterBasis, "fixture complete raster")
      assert.deepEqual(derivedFact.geometry, cell)
      const reportedFact = JSON.parse(reported.rawReplies["collector.captureCalibration"])
      assert.equal(reportedFact.basis, "measured by complete raster calibration")
      assert.deepEqual(reportedFact.geometry, cell)
      assert.equal(bare.rawReplies["collector.captureCalibration"], undefined)
      // The derived basis still calibrates, once per run, and its probes reach pixels.
      assert.equal(calibrations, 6)
      assert.ok(frames > 0)
      // Capture labels can include independently allocated image IDs; compare all deciding pixel facts, not those labels.
      const pixels = (run) => JSON.parse(JSON.stringify(run.results.filter((o) => o.assertionType === "screenshot"), (key, value) => ["startedAt", "completedAt", "label"].includes(key) ? undefined : value))
      assert.ok(pixels(derived).length > 0)
      assert.deepEqual(pixels(derived), pixels(reported))
      assert.deepEqual(pixels(bare), [])
      assert.equal(derived.results.length, globalThis.__TERMINFO_BUNDLED_SUITE__.manifest.catalogIds.length)
      assert.equal(reported.results.length, globalThis.__TERMINFO_BUNDLED_SUITE__.manifest.catalogIds.length)
      assert.equal("ungradedDiagnostics" in derived, false)
      assert.equal("ungradedDiagnostics" in reported, false)
    `,
      360_000,
    )
    expect(result.stderr).toBe("")
    expect(result.status).toBe(0)
    // GitHub killed this child at 90s on 875c2bc. A local run then took 129s.
    // Keep the child's limit below the outer test so a wedged child leaves its diagnostic result.
  }, 420_000)

  // @cto, 28785 REVISE round 2 must 2: pin EVERY classification site of queryPixelGeometry with
  // one table. A timeout - nothing answered at all, DA1 included - is the one transient cause, and
  // the run aborts by name carrying the replies it read. A sentinel is DA1 answered and then
  // silence through the grace window: the terminal's own measured negative, which completes as a
  // refusal that names itself in the row note. Both DA1-only shapes complete; both timeout shapes
  // abort. (Sites: region-readback.ts 358, 375, 398, 405, 415, 421.)
  it("classifies every geometry refusal by cause, and aborts only on a timeout", () => {
    const result = runHostedDarwinFixture(`
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      Object.defineProperty(process, "platform", { value: "darwin" })
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      const receipt = await import("./packages/terminfo.dev/src/disposable-receipt.ts")
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const geometry = { status: "measured", rows: 30, cols: 120, at: "2026-10-15T00:00:00.000Z", source: "fixture", stdout: "30 120\\n", stderr: "" }
      const shapes = [
        { name: "358 14 t sentinel after a 16 t reply", six: "reply:\\x1b[6;13;6t", fourteen: "sentinel", eighteen: null,
          expect: "refused", cause: /answered CSI 14 t \\(text area in pixels\\) with sentinel/ },
        { name: "375 a pixel report that did not parse as positive numbers", six: "reply:\\x1b[6;0;6t", fourteen: "reply:\\x1b[4;598;798t", eighteen: null,
          expect: "refused", cause: /did not parse as positive numbers/ },
        { name: "398 DA1 only: 16 t and 14 t both sentinel", six: "sentinel", fourteen: "sentinel", eighteen: null,
          expect: "refused", cause: /CSI 16 t \\(cell size in pixels\\) with sentinel and CSI 14 t \\(text area in pixels\\) with sentinel/ },
        { name: "398 a timeout is the one transient cause", six: "timeout", fourteen: "timeout", eighteen: null,
          expect: "aborts", cause: /with timeout and CSI 14 t \\(text area in pixels\\) with timeout/ },
        { name: "405 DA1 only through the derived path: 18 t sentinel", six: "sentinel", fourteen: "reply:\\x1b[4;467;860t", eighteen: "sentinel",
          expect: "refused", cause: /CSI 18 t \\(text area in characters\\) with sentinel/ },
        { name: "405 the derived path 18 t timeout aborts too", six: "sentinel", fourteen: "reply:\\x1b[4;467;860t", eighteen: "timeout",
          expect: "aborts", cause: /CSI 18 t \\(text area in characters\\) with timeout/ },
        { name: "415 a text area that did not parse as positive numbers", six: "sentinel", fourteen: "reply:\\x1b[4;0;0t", eighteen: "reply:\\x1b[8;30;120t",
          expect: "refused", cause: /text area that did not parse as positive numbers/ },
        { name: "421 the area does not divide into whole pixels (Terminal.app)", six: "sentinel", fourteen: "reply:\\x1b[4;467;860t", eighteen: "reply:\\x1b[8;30;120t",
          expect: "refused", cause: /does not divide into a whole-pixel cell size/ }
      ]
      let mode = shapes[0], frames = 0, calibrations = 0
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
        detectTerminal: () => ({ name: "terminal-app", version: "2.15", os: "macos", osVersion: "26.6.2" })
      }))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
        ownedTerminalVerifiedFor: () => true,
        createOwnedTerminal: async () => ({ geometryAtGrant: geometry, geometrySource: "fixture", appPid: 5705, hostedAppId: "terminal-app",
          summary: "{}", readGeometry: async () => geometry, dispose: async () => {} })
      }))
      mock.module("./packages/terminfo.dev/src/disposable-receipt.ts", () => ({ ...receipt, readDisposableReceipt: () => undefined }))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
        withRawMode: async (cb) => cb(), drainStdin: async () => {},
        query: async () => null, queryWithSentinel: async () => null,
        queryOutcome: async () => ({ match: null, reason: "timeout", raw: "", rawBase64: "" }),
        queryCursorPosition: async () => null, measureRenderedWidth: async () => ({ kind: "no-reply", step: "sample" } as const),
        measureUtf8Decoding: async () => "silent", queryMode: async () => null, readResponse: async () => null,
        queryWithSentinelOutcome: async (sequence, pattern) => {
          // The collector's OWN geometry corroboration asks CSI 18 t before the pre-flight, with a
          // pattern that insists on a non-zero first digit: answer it as the measured grid, always,
          // so it is never confused with the derived geometry path's own 18 t question below.
          if (pattern.source.includes("[1-9][0-9]*")) {
            const raw = "\\x1b[8;30;120t"
            return { match: pattern.exec(raw), reason: "reply", raw, rawBase64: "Z" }
          }
          // XTVERSION (and anything else this fixture does not model) is a separate query: it is
          // answered with DA1's own reply here, which the identity guard reads as "sentinel", never
          // as one of the three geometry replies below.
          if (sequence !== "\\x1b[16t" && sequence !== "\\x1b[14t" && sequence !== "\\x1b[18t") {
            return { match: null, reason: "sentinel", raw: "\\x1b[?1;2c", rawBase64: "Z" }
          }
          const spec = sequence === "\\x1b[16t" ? mode.six : sequence === "\\x1b[14t" ? mode.fourteen : mode.eighteen
          assert.notEqual(spec, null, mode.name + " must never ask " + sequence)
          if (spec === "timeout") return { match: null, reason: "timeout", raw: "", rawBase64: "" }
          if (spec === "sentinel") return { match: null, reason: "sentinel", raw: "\\x1b[?1;2c", rawBase64: "Z" }
          const raw = spec.slice("reply:".length)
          return { match: pattern.exec(raw), reason: "reply", raw, rawBase64: "Z" }
        }
      }))
      mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({ createDarwinCapture: async () => ({
        capture: async () => { frames++; throw new Error("no frame may be requested for a refused geometry") },
        captureRaw: async () => { frames++; throw new Error("no frame may be requested for a refused geometry") }
      }) }))
      mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({ calibrateCaptureOrigin: async () => {
        calibrations++
        throw Object.assign(new Error("Capture calibration nonuniform columns: measured unequal cell edges"), { name: "CaptureCalibrationRefused" })
      } }))
      globalThis.__TERMINFO_BUNDLED_SUITE__ = { manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12),
        probes: { term: unified.ALL_PROBES.map((p) => p.id).sort() } }, collectorRevision: "b".repeat(40) }
      const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
      const measured = []
      for (const shape of shapes) {
        mode = shape
        let thrown = null
        let run = null
        try {
          run = await collectProbeRun({})
        } catch (error) {
          thrown = error
        }
        if (shape.expect === "refused") {
          assert.equal(thrown, null, shape.name + " must complete, not throw: " + String(thrown === null ? "" : thrown.message))
          const fact = JSON.parse(run.rawReplies["collector.captureCalibration"])
          const named = run.results.filter((o) => /cell-to-pixel geometry was refused/.test(o.reason ?? ""))
          measured.push({ name: shape.name, kind: "refused", outcome: fact.outcome, refusal: fact.refusal,
            complete: run.results.length === globalThis.__TERMINFO_BUNDLED_SUITE__.manifest.catalogIds.length, ungraded: Number("ungradedDiagnostics" in run),
            named: named.length, firstNamed: named.length > 0 ? named[0].reason : "" })
        } else {
          measured.push({ name: shape.name, kind: thrown === null ? "completed" : "threw",
            error: thrown === null ? null : thrown.name, message: String(thrown === null ? "" : thrown.message) })
        }
      }
      assert.deepEqual(measured.map((m) => m.name), shapes.map((s) => s.name))
      for (const index of shapes.keys()) {
        const shape = shapes[index]
        const row = measured[index]
        if (shape.expect === "refused") {
          assert.equal(row.kind, "refused", shape.name)
          assert.equal(row.outcome, "refused", shape.name)
          assert.match(row.refusal, /Capture calibration nonuniform columns/, shape.name)
          assert.equal(row.complete, true, shape.name)
          assert.equal(row.ungraded, 0, shape.name)
          assert.ok(row.named > 0, shape.name + " must name the refusal in a row note")
          assert.match(row.firstNamed, /Capture calibration nonuniform columns/, shape.name)
        } else {
          assert.equal(row.kind, "threw", shape.name + " must abort the run")
          assert.equal(row.error, "TerminalGeometryUnmeasurable", shape.name)
          assert.match(row.message, shape.cause, shape.name)
          assert.match(row.message, /REPEAT THE RUN/, shape.name)
          assert.match(row.message, /Replies read: /, shape.name)
        }
      }
      // No geometry was ever installed, in any shape: nothing captured and nothing calibrated.
      assert.equal(frames, 0)
      assert.equal(calibrations, shapes.filter(s => s.expect === "refused").length)
    `)
    expect(result.stderr).toBe("")
    expect(result.status).toBe(0)
  })

  it("measures owned subset identity independently, retains feature replies and disposes on refusal", () => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-identity-"))
    const result = spawnSync(
      process.execPath,
      [
        "-e",
        `
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      import { parseRunProvenance } from "@terminfo/run-parser"
      import { parseAppLaunchReceipt } from "./packages/run-parser/src/app-launch.ts"
      import { createHash } from "node:crypto"
      const digest = seed => createHash("sha256").update(seed).digest("hex")
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      let raw = "\\x1bP>|kitty(0.49.2)\\x1b\\\\\\x1b[?62;52;c", disposed = 0, calls = []
      let launch, expectedBatchVersion
      let terminal={name:"kitty",version:"",os:"linux",osVersion:"fixture"}
      globalThis.__TERMINFO_BUNDLED_SUITE__ = {
        manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },
        collectorRevision: "b".repeat(40)
      }
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({ detectTerminal: () => terminal }))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({...owned, createOwnedTerminal: async () => ({
        geometryAtGrant:{status:"measured",rows:24,cols:80},hostedAppId:terminal.name,summary:"owned fixture",dispose:async()=>{disposed++}
      })}))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({...tty,
        withRawMode:async callback=>callback(),drainStdin:async()=>{},
        queryWithSentinelOutcome:async(sequence,pattern)=>{
          calls.push(sequence)
          const reply=sequence === "\\x1b[18t" ? "\\x1b[8;24;80t" : raw
          return {raw:reply,rawBase64:Buffer.from(reply).toString("base64"),match:pattern.exec(reply),reason:pattern.test(reply)?"reply":"sentinel"}
        }
      }))
      mock.module("./packages/terminfo.dev/src/probes/unified.ts", () => ({...unified,runProbeBatch:async options=>{
        if(expectedBatchVersion!==undefined)assert.equal(options.subject.version,expectedBatchVersion,"measured version must reach the batch before callbacks")
        return {
        results:options.draft.results,rawReplies:{"fixture.selected":JSON.stringify(options.ids),...(options.ids.includes("device.xtversion")?{"device.xtversion":"feature-owned reply"}:{})},
        observations:options.ids.map(featureId=>({featureId})), assertions:[],screenshotRefs:[],ungradedDiagnostics:{},suiteComplete:false,
        ...(launch && { appLaunch: launch })
      }}}))
      const {collectProbeRun}=await import("./packages/terminfo.dev/src/serve.ts")
      const ids=unified.ALL_PROBES.filter(p=>p.id!=="device.xtversion").slice(0,10).map(p=>p.id)
      // 28216: the collector COPIES the apparatus-measured launch block into origin.appLaunch, and a
      // batch that carries none leaves the origin without one.
      launch={bundlePath:"/Applications/iTerm.app",cfBundleShortVersionString:"3.6.11",cfBundleVersion:"3.6.11",
        executablePath:"/Applications/iTerm.app/Contents/MacOS/iTerm2",executableSha256:"a".repeat(64),
        sourceArtifact:{path:"/Library/Caches/Homebrew/downloads/iterm2.zip",sha256:"b".repeat(64)}}
      const run=await collectProbeRun({ids,terminalAppOwner:{}})
      assert.deepEqual(run.origin,{kind:"collector",appLaunch:launch})
      assert.equal(run.subject.version,"0.49.2")
      assert.deepEqual(JSON.parse(run.rawReplies["fixture.selected"]),ids)
      assert.ok(run.results.every(row=>row.status==="probe-todo"))
      assert.equal(run.rawReplies["device.xtversion"],undefined)
      assert.equal(run.rawReplies["collector.xtversion"],raw)
      assert.deepEqual(calls,["\\x1b[18t","\\x1b[>0q"])
      const query=JSON.parse(run.rawReplies["collector.xtversionQuery"])
      assert.equal(query.sequence,"\\x1b[>0q")
      assert.equal(query.outbound,"\\x1b[>0q\\x1b[c")
      assert.equal(query.rawBase64,Buffer.from(raw).toString("base64"))
      const provenance={executable:{path:"/fixture/kitty",sha256:digest("fixture executable"),version:"kitty 0.49.2"},
        sourceArtifact:{url:"https://example.invalid/kitty.txz",sha256:digest("fixture source artifact")},
        runtime:{imageId:"sha256:"+"e".repeat(64),imageTarSha256:digest("fixture image tar"),arch:"amd64",nixLockRevision:"1".repeat(40),sourceRevision:"b".repeat(40),cleanTree:true,suiteHash:"a".repeat(12)},
        fixture:{definition:"fixture",config:"fixture",font:"fixture",geometry:"80x24",display:"fixture",gl:"fixture"}}
      assert.equal(parseRunProvenance(provenance,run.subject,{probeHash:run.probeHash,sourceRevision:run.sourceRevision},"fixture").executable.version,"kitty 0.49.2")
      const feature=await collectProbeRun({ids:["device.xtversion"],terminalAppOwner:{}})
      assert.equal(feature.rawReplies["device.xtversion"],"feature-owned reply")
      assert.equal(feature.rawReplies["collector.xtversion"],raw)
      launch=undefined
      const unlaunched=await collectProbeRun({ids:["device.xtversion"],terminalAppOwner:{}})
      assert.deepEqual(unlaunched.origin,{kind:"collector"})
      // OSC22 routing cannot consume a version that the collector only assigns after the batch.
      // These payloads are the retained original xterm/WezTerm XTVERSION replies; a new version
      // is forwarded too, so the existing exact-tuple batch test can exclude it.
      const originalRaw=raw,originalTerminal=terminal
      for(const [id,version,payload] of [["xterm","411","XTerm(411)"],["wezterm","0-unstable-2026-10-10","WezTerm 0-unstable-2026-10-10"],["xterm","412","XTerm(412)"]]){
        terminal={name:id,version:"",os:"linux",osVersion:"fixture"}
        raw=String.fromCharCode(27)+"P>|"+payload+String.fromCharCode(27)+String.fromCharCode(92)+String.fromCharCode(27)+"[?64;1;2c"
        expectedBatchVersion=version
        const measured=await collectProbeRun({ids:["device.xtversion"],terminalAppOwner:{}})
        assert.equal(measured.subject.version,version)
      }
      raw=originalRaw;terminal=originalTerminal;expectedBatchVersion=undefined
      const disposedBeforeMalformed=disposed
      launch={bundlePath:"/Applications/iTerm.app",cfBundleShortVersionString:"3.6.11",cfBundleVersion:"3.6.11",
        executablePath:"/Applications/iTerm.app/Contents/MacOS/iTerm2",executableSha256:"a".repeat(64),
        sourceArtifact:{path:"/Library/Caches/Homebrew/downloads/iterm2.zip",sha256:"b".repeat(64)}}
      for(const invalid of ["\\x1b[?62;52;c","\\x1bP>|kitty(0.49.2)"]){
        raw=invalid
        await assert.rejects(collectProbeRun({ids,terminalAppOwner:{}}),/identity: XTVERSION preflight/)
      }
      assert.equal(disposed,disposedBeforeMalformed+2)
      calls=[]
      const nonowned=await collectProbeRun({ids})
      assert.equal(nonowned.subject.version,"unknown")
      assert.equal(nonowned.rawReplies["collector.xtversion"],undefined)
      assert.deepEqual(calls,[])
      // Actual run 38303792334 reported stale detection 1.23.20211.0 despite measured executable
      // ProductVersion 1.21.240823001. Earlier macOS/receipt-copy assertions did not cover this.
      terminal={name:"windows-terminal",version:"1.23.20211.0",os:"windows",osVersion:"fixture"}
      for(const productVersion of ["1.21.240823001","1.21.240823001-build42"]){
        launch=parseAppLaunchReceipt({platform:"win32",executablePath:"C:/runner/WindowsTerminal.exe",
          productVersion,executableSha256:"c3".repeat(32),
          sourceArtifact:{kind:"portable-zip",path:"C:/runner/wt.zip",sha256:"d4".repeat(32)}},"collector","term","fixture")
        process.env.TERMINFO_TARGET_VERSION=productVersion.trim()
        const windows=await collectProbeRun({ids:["device.xtversion"]})
        assert.equal(windows.subject.version,productVersion)
        assert.deepEqual(windows.origin.appLaunch,launch)
      }
      terminal={name:"alacritty",version:"",os:"windows",osVersion:"fixture"}
      launch=parseAppLaunchReceipt({platform:"win32",executablePath:"D:/a/_temp/alacritty/alacritty.exe",
        productVersion:"0.17.0",executableSha256:"c3".repeat(32),
        sourceArtifact:{kind:"portable-exe",path:"D:/a/_temp/Alacritty-v0.17.0-portable.exe",sha256:"c3".repeat(32)},
        mesaRenderer:{upstream:"https://github.com/mmozeiko/build-mesa",version:"26.2.5",
          archivePath:"D:/a/_temp/mesa.7z",archiveSha256:"d4".repeat(32),
          dlls:[{name:"opengl32.dll",path:"D:/a/_temp/alacritty/opengl32.dll",sha256:"e5".repeat(32)}]}},"collector","term","fixture")
      process.env.TERMINFO_TARGET_VERSION=""
      const winAlacritty=await collectProbeRun({ids:["device.xtversion"]})
      assert.equal(winAlacritty.subject.version,"0.17.0")
      assert.deepEqual(winAlacritty.origin.appLaunch,launch)
    `,
      ],
      { cwd: packageRoot, env: { ...process.env, HOME: home }, encoding: "utf8", timeout: 5000 },
    )
    expect(result.stderr).toBe("")
    expect(result.status).toBe(0)
  })

  it.each([
    { arm: "windowsHosted", app: "kitty", route: "absent", retained: false, pid: true },
    { arm: "terminalApp", app: "terminal-app", route: "absent", retained: false, pid: true },
    { arm: "darwinHosted", app: "iterm2", route: "absent", retained: false, pid: true },
    { arm: "darwinHosted", app: "kitty", route: "text-cells", retained: true, pid: true },
    { arm: "darwinHosted", app: "iterm2", route: "pixels", retained: true, pid: true },
    { arm: "darwinHosted", app: "terminal-app", route: "pixels", retained: true, pid: true },
    { arm: "terminalApp", app: "terminal-app", route: "text-cells", retained: true, pid: true },
    {
      arm: "terminalApp",
      app: "terminal-app",
      route: "platform-refused",
      retained: true,
      pid: true,
      platform: "linux",
    },
    { arm: "terminalApp", app: "terminal-app", route: "owner-refused", retained: true, pid: true, ownerFails: true },
    { arm: "darwinHosted", app: "iterm2", route: "pixels", retained: true, pid: false },
  ])(
    "handles $arm $app capture route $route (retained=$retained, pid=$pid)",
    ({ arm, app, route, retained, pid, platform, ownerFails }) => {
      home = mkdtempSync(join(tmpdir(), "terminfo-serve-windows-skip-"))
      const result = spawnSync(
        process.execPath,
        [
          "-e",
          `
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      const arm = process.env.FIXTURE_ARM
      const app = process.env.FIXTURE_APP
      const route = process.env.FIXTURE_ROUTE
      const retained = process.env.FIXTURE_RETAINED === "yes"
      Object.defineProperty(process, "platform", { value: process.env.FIXTURE_PLATFORM || (arm === "windowsHosted" ? "win32" : "darwin") })
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      let capture
      let captureKind = "absent"
      let reads = 0, drains = 0
      let pixelFrames = 0, calibrations = 0
      globalThis.__TERMINFO_BUNDLED_SUITE__ = {
        manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },
        collectorRevision: "b".repeat(40)
      }
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
        detectTerminal: () => ({ name: app, version: "", os: arm === "windowsHosted" ? "windows" : "macos", osVersion: "fixture" })
      }))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
        ownedTerminalVerifiedFor: () => true,
        createOwnedTerminal: async options => {
          if (arm === "terminalApp") {
            assert.ok(options.terminalApp, "Terminal text must retain its existing owner proof")
            if (process.env.FIXTURE_OWNER_FAILS === "yes") throw new Error("owned Terminal.app proof failed")
          }
          return {
          geometryAtGrant: { status: "measured", rows: 24, cols: 80 },
          ...(arm !== "terminalApp" && { hostedAppId: app }),
          ...(process.env.FIXTURE_PID === "yes" && { appPid: 5705 }),
          summary: "owned fixture",
          ...(arm !== "windowsHosted" && { textRecipe: "macos-text-cells-v1" }),
          readCells: async () => {
            if (app === "terminal-app") assert.equal(drains, 1, "Terminal qualification must drain before its first cell read")
            reads += 1
            return { status: "refused", reason: "text read refused by route fixture" }
          },
          dispose: async () => {}
        }}
      }))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
        withRawMode: async callback => callback(), drainStdin: async () => { drains++ },
        queryWithSentinelOutcome: async (sequence, pattern) => {
          const raw = sequence === "\\x1b[18t" ? "\\x1b[8;24;80t"
            : sequence === "\\x1b[16t" ? "\\x1b[6;17;8t"
            : sequence === "\\x1b[14t" ? "\\x1b[4;408;640t"
            : app === "iterm2" ? "\\x1bP>|iTerm2 3.6.11\\x1b\\\\"
            : app === "kitty" ? "\\x1bP>|kitty(0.49.2)\\x1b\\\\\\x1b[?62;52;c" : "\\x1b[?1;2c"
          return { raw, rawBase64: Buffer.from(raw).toString("base64"), match: pattern.exec(raw), reason: pattern.test(raw) ? "reply" : "sentinel" }
        }
      }))
      mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({
        createDarwinCapture: async (_directory, options) => {
          assert.equal(options.appPid, 5705)
          return { captureRaw: async () => { pixelFrames++; throw new Error("pixel frame fixture") } }
        }
      }))
      mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({
        calibrateCaptureOrigin: async () => {
          calibrations++
          throw Object.assign(new Error("Capture calibration route fixture"), { name: "CaptureCalibrationRefused" })
        }
      }))
      mock.module("./packages/terminfo.dev/src/probes/unified.ts", () => ({ ...unified,
        runProbeBatch: async options => {
          capture = options.capture
          captureKind = options.captureKind ?? "absent"
          if (route === "pixels") {
            assert.equal(typeof capture, "function", "Mac route must attempt a pixel frame")
            assert.equal(captureKind, "absent", "Mac route must not install text-cells")
            await assert.rejects(options.capture({ role: "witness", label: "route fixture" }), /pixel frame fixture/)
          }
          if (retained) {
            // Only an owner that closes and proves its window qualifies after probes (32670); hosted
            // iTerm2 and Kitty still qualify before probes, and the hosted pixel arm still calibrates first.
            const ownerCloses = app === "terminal-app"
            assert.equal(typeof options.finishCapture, ownerCloses ? "function" : "undefined")
            assert.equal(typeof options.prepareCapture, arm === "terminalApp" ? "undefined" : "function")
            for (const [prepare, featureId] of [
              [options.prepareCapture, "collector.captureCalibration"],
              [options.finishCapture, "collector.textQualification"],
            ]) {
              await prepare?.({
                source: {
                  rows: 4, cols: 12, queryMode: async () => "unknown",
                  queryOutcome: async () => ({ match: null, reason: "timeout", raw: "", rawBase64: "" }),
                  write: () => { throw new Error("Paint before known mode state") }
                },
                featureId,
                recordCapture: () => { throw new Error("Capture before known mode state") }
              })
            }
          }
          return {
            results: options.draft.results, rawReplies: {},
            observations: [],
            assertions: [], screenshotRefs: [], ungradedDiagnostics: {}, suiteComplete: false
          }
        }
      }))
      const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
      const collect = () => arm === "terminalApp"
        ? collectProbeRun({ ids: ["device.xtversion"], terminalAppOwner: {} })
        : collectProbeRun({ ids: ["device.xtversion"] })
      if (route === "platform-refused" || route === "owner-refused") {
        await assert.rejects(collect(), route === "platform-refused"
          ? /Controlled Linux collection requires runtime provenance/
          : /owned Terminal.app proof failed/)
        assert.equal(reads, 0)
        assert.equal(pixelFrames, 0)
        process.exit(0)
      }
      if (retained && process.env.FIXTURE_PID !== "yes") {
        await assert.rejects(collect(), /Verified darwinHosted terminal has no measured app PID for capture/)
        assert.equal(reads, 0)
        assert.equal(pixelFrames, 0)
        process.exit(0)
      }
      const run = await collect()
      if (app === "terminal-app" && retained) {
        assert.match(run.rawReplies["collector.windowDisposal"], arm === "terminalApp" ? /pending launcher/ : /pending the hosted workflow's/)
        assert.equal(run.rawReplies["collector.collectionStatus"], "Collected selected probe results; draft " + run.runId + " awaits final writer")
      } else assert.equal(run.rawReplies["collector.windowDisposal"], undefined)
      assert.equal(typeof capture, retained ? "function" : "undefined")
      assert.equal(captureKind, route === "text-cells" ? "text-cells" : "absent")
      assert.equal(reads, app === "terminal-app" && retained ? 1 : 0)
      assert.equal(drains, 1, "Each completed collection drains once, never after Terminal qualification")
      assert.equal(pixelFrames, route === "pixels" ? 1 : 0)
      assert.equal(calibrations, route === "pixels" ? 1 : 0)
      assert.deepEqual(run.textSnapshotRefs ?? [], [])
      assert.equal(run.results.filter(observation => observation.frames?.some(frame => frame.kind === "text-cells")).length, 0)
      // Hosted pixel runs must retain the same qualification refusals without replacing pixels.
      if (route === "text-cells" || route === "pixels") {
        assert.ok(run.textQualification, "hosted pixel capture skipped text qualification")
        assert.equal(run.textQualification.shapes.length, 5)
        assert.ok(run.textQualification.shapes.every(shape => typeof shape.reason === "string" && !shape.frames))
      } else assert.equal(run.textQualification, undefined)
    `,
        ],
        {
          cwd: packageRoot,
          env: {
            ...process.env,
            HOME: home,
            FIXTURE_ARM: arm,
            FIXTURE_APP: app,
            FIXTURE_ROUTE: route,
            FIXTURE_PID: pid ? "yes" : "no",
            FIXTURE_RETAINED: retained ? "yes" : "no",
            FIXTURE_PLATFORM: platform ?? "",
            FIXTURE_OWNER_FAILS: ownerFails ? "yes" : "no",
            TERMINFO_CAPTURE_DIRECTORY: retained ? join(home, "capture") : "",
            TERMINFO_DISPOSABLE_RECEIPT: arm !== "terminalApp" ? "hardware-receipt-fixture" : "",
            TERMINFO_RUNTIME_PROVENANCE: "",
            TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
          },
          encoding: "utf8",
          timeout: 10_000,
        },
      )
      const lines = result.stderr.split("\n").filter(Boolean)
      expect(result.status, result.stderr).toBe(0)
      expect(lines).toHaveLength(retained ? 0 : 1)
      if (!retained) {
        expect(lines[0]).toMatch(new RegExp(`^${arm}: this arm can read cells from the terminal's own text`, "u"))
        expect(lines[0]).toMatch(/no TERMINFO_CAPTURE_DIRECTORY to retain a snapshot in/u)
        expect(lines[0]).toMatch(/no-capture branch$/u)
      }
    },
  )

  it.each([
    "capture",
    "pending-write",
    "write-error",
    "refusal",
    "timeout",
    "non-windows",
    "final-custody",
    "closure",
    "closure-iterm2",
    "closure-terminal-app",
  ])("a hosted text capture with a retention directory takes the %s branch without Linux provenance", (expectation) => {
    home = mkdtempSync(join(tmpdir(), "terminfo-serve-hosted-capture-"))
    const result = spawnSync(
      process.execPath,
      [
        "-e",
        `
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      import { readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs"
      import { createHash } from "node:crypto"
      import { basename, join } from "node:path"
      import { Writable } from "node:stream"
      const expectation = process.env.FIXTURE_EXPECT
      const closure = expectation.startsWith("closure")
      const pixelApp = closure && expectation !== "closure" ? expectation.slice("closure-".length) : undefined
      // Existing xterm adapter supplies the substituted native screen; collection/retention stay real.
      const screen = closure ? (await import("@termless/xtermjs")).createXtermBackend() : undefined
      screen?.init({ rows: 24, cols: 80 })
      const hosted = expectation !== "refusal"
      let reads = 0
      let queryWrites = 0
      const writes = []
      const darwin = closure || ["pending-write", "write-error", "non-windows", "final-custody"].includes(expectation)
      let text = "stale"
      let finishWrite
      const out = new Writable({
        write(chunk, encoding, done) {
          writes.push(chunk.toString())
          screen?.feed(new TextEncoder().encode(chunk.toString()))
          screen?.getCursor()
          if (chunk.toString() === "queued-clear") {
            finishWrite = error => { if (!error) text = "hello"; done(error) }
          } else {
            done()
            if (chunk.toString() === "\\x1b[6n") {
              queryWrites++
              setImmediate(() => {
                assert.equal(reads, 0, "console cells were read before the cursor acknowledgement arrived")
                process.stdin.emit("data", Buffer.from(expectation === "timeout" ? "partial" : "\\x1b[1;1R"))
              })
            }
          }
        }
      })
      Object.defineProperty(process, "platform", { value: darwin ? "darwin" : "win32" })
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      const actualBatch = unified.runProbeBatch
      const disposable = await import("./packages/terminfo.dev/src/disposable-receipt.ts")
      // Receipt verification has its own owner suite; this case exercises the real probe catch.
      mock.module("./packages/terminfo.dev/src/disposable-receipt.ts", () => ({ ...disposable,
        readDisposableReceipt: () => ({ kind: "github-hosted-runner", runId: "a".repeat(32),
          collectedAt: "2026-10-19T00:00:00Z", sha256: "d".repeat(64) })
      }))
      let capture
      let captureKind = "absent"
      let captured = false
      let retainedFrame
      let calibrations = 0
      if (pixelApp) {
        mock.module("./packages/terminfo.dev/src/darwin-capture.ts", () => ({
          createDarwinCapture: async () => ({ captureRaw: async () => { throw new Error("pixel fixture must calibrate first") } })
        }))
        mock.module("./packages/terminfo.dev/src/capture-calibration.ts", () => ({
          calibrateCaptureOrigin: async () => {
            calibrations++
            throw Object.assign(new Error("Pixel calibration fixture refusal"), { name: "CaptureCalibrationRefused" })
          }
        }))
      }
      globalThis.__TERMINFO_BUNDLED_SUITE__ = {
        manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },
        collectorRevision: "b".repeat(40)
      }
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
        detectTerminal: () => ({ name: pixelApp ?? (darwin ? "kitty" : "windows-terminal"), version: "", os: darwin ? "macos" : "windows", osVersion: "fixture" })
      }))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
        ownedTerminalVerifiedFor: () => true,
        createOwnedTerminal: async () => ({
          geometryAtGrant: { status: "measured", rows: 24, cols: 80 },
          readGeometry: async () => ({ status: "measured", rows: 24, cols: 80 }),
          hostedAppId: pixelApp ?? (darwin ? "kitty" : "windows-terminal"),
          ...(pixelApp && { appPid: 5705 }),
          summary: "owned fixture",
          ...(darwin && { textRecipe: "macos-text-cells-v1" }),
          readCells: async () => { reads += 1;
            if (closure) { return { status: "read", app: pixelApp ?? "kitty", cells: {
              cols: 80, rows: 24, text: Array.from({length: 24}, (_, row) => Array.from({length: 80}, (_, col) => screen.getCell(screen.getScrollback().viewportTop + row, col).char || " ").join("")), paddedRows: [], droppedLines: 0
            } } }
            return ({
            status: "read",
            grid: { cols: 80, rows: 24, text: [text], attributes: [[0, 0, 0, 0, 0]] },
            bufferOwner: { image: "OpenConsole.exe", pid: 1, ppid: 2, executablePath: "C:\\\\Windows\\\\System32\\\\OpenConsole.exe", executableSha256: "sha256:" + "a".repeat(64) },
            standIns: []
          }) },
          dispose: async () => {}
        })
      }))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
        withRawMode: async callback => callback(), drainStdin: async () => {},
        queryMode: closure ? async () => "set" : tty.queryMode,
        queryCursorPosition: closure ? async () => [1, 1] : tty.queryCursorPosition,
        queryWithSentinelOutcome: async (sequence, pattern) => {
          const raw = sequence === "\\x1b[18t" ? "\\x1b[8;24;80t"
            : pixelApp === "iterm2" ? "\\x1bP>|iTerm2 3.6.11\\x1b\\\\"
            : pixelApp === "terminal-app" ? "\\x1b[?1;2c" : "\\x1bP>|kitty(0.49.2)\\x1b\\\\"
          return { raw, rawBase64: Buffer.from(raw).toString("base64"), match: pattern.exec(raw), reason: pattern.test(raw) ? "reply" : "sentinel" }
        }
      }))
      mock.module("./packages/terminfo.dev/src/probes/unified.ts", () => ({ ...unified,
        runProbeBatch: async options => {
          capture = options.capture
          captureKind = options.captureKind ?? "absent"
          if (expectation === "timeout" || closure) {
            return actualBatch(options)
          }
          if (options.capture) {
            if (expectation === "pending-write" || expectation === "write-error") {
              // Real Writable queues the adapter's completion behind this unfinished chunk.
              options.out.write("queued-clear")
              const pending = tty.withTTYOperation(() => options.capture({ role: "witness", label: "fixture" }), options.out)
              pending.catch(() => {}) // The original promise is asserted below, including its error.
              await Promise.resolve()
              assert.equal(reads, 0, "text readback ran before the selected output completed")
              assert.equal(readdirSync(process.env.TERMINFO_CAPTURE_DIRECTORY).filter(name => name.endsWith(".txt")).length, 0)
              if (expectation === "write-error") {
                const failure = new Error("selected output completion failed")
                const errorSeen = new Promise(resolve => out.once("error", resolve))
                finishWrite(failure)
                await assert.rejects(pending, error => error === failure)
                assert.equal(reads, 0)
                assert.equal(readdirSync(process.env.TERMINFO_CAPTURE_DIRECTORY).filter(name => name.endsWith(".txt")).length, 0)
                assert.equal(await errorSeen, failure)
              } else {
                finishWrite()
                await pending
                captured = true
              }
            } else {
              text = "hello"
              options.out.write("probe-paint")
              const retained = await tty.withTTYOperation(() => options.capture({ role: "control", label: "fixture" }), options.out)
              retainedFrame = retained.frame
              captured = true
            }
          }
          return {
            results: options.draft.results, rawReplies: {},
            observations: [],
            assertions: [], screenshotRefs: [],
            ...(expectation === "final-custody" && { textSnapshotRefs: [retainedFrame.ref] }),
            ungradedDiagnostics: {}, suiteComplete: false
          }
        }
      }))
      const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
      if (!hosted) {
        await assert.rejects(
          collectProbeRun({ ids: ["device.xtversion"], out }),
          /Controlled Linux collection requires runtime provenance/u,
        )
      } else {
        const run = await collectProbeRun({ ids: [expectation === "timeout" || closure ? "erase.character" : "device.xtversion"], out })
        if (pixelApp) {
          assert.equal(captureKind, "absent", "qualification replaced the primary pixel adapter")
          assert.equal(calibrations, 1, "text qualification skipped pixel calibration")
          assert.equal(JSON.parse(run.rawReplies["collector.captureCalibration"]).outcome, "refused")
          const { TEXT_QUALIFICATION_RECIPES, TEXT_QUALIFICATION_SPEC, assessTextQualification } = await import("@terminfo/probe-defs")
          assert.ok(run.textQualification, "hosted pixel run omitted retained text qualification")
          assert.deepEqual(run.textQualification.shapes.map(shape => shape.shape), TEXT_QUALIFICATION_RECIPES["macos-text-cells-v1"].shapes)
          const snapshots = new Map()
          for (const shape of run.textQualification.shapes) {
            assert.equal(shape.frames?.length, 2, JSON.stringify(shape))
            for (const frame of shape.frames) {
              assert.equal(frame.kind, "text-cells")
              assert.ok(run.textSnapshotRefs.includes(frame.ref), "qualification text frame omitted from run custody")
              const bytes = readFileSync(join(process.env.TERMINFO_CAPTURE_DIRECTORY, frame.ref.slice(7) + ".txt"))
              assert.equal("sha256:" + createHash("sha256").update(bytes).digest("hex"), frame.ref)
              snapshots.set(frame.ref, bytes)
            }
          }
          const assessment = assessTextQualification({ ...run, textQualificationSpec: TEXT_QUALIFICATION_SPEC }, snapshots)
          assert.equal(assessment.qualified, true, assessment.reason)
          process.exit(0)
        }
        if (expectation === "closure") {
          // Existing retention tests omit nested bindings; this production bundle supplies their positive control.
          const { readProbeCapture } = await import("./packages/probes/erase-capture.ts")
          const { getTrustedSuiteReceipt } = await import("./packages/terminfo.dev/src/serve.ts")
          const root = join(process.env.HOME, "launch")
          const open = (candidate, label) => {
            const path = label + ".json", bytes = Buffer.from(JSON.stringify(candidate))
            writeFileSync(join(root, path), bytes, { flag: "wx" })
            return readProbeCapture(root, {
              kind: "trace", trace: { path, sha256: createHash("sha256").update(bytes).digest("hex") },
              captureRunId: run.runId, captureSuiteId: run.suiteId, captureSourceRevision: run.sourceRevision
            }, { manifest: getTrustedSuiteReceipt().manifest, sourceRevision: run.sourceRevision, subject: run.subject })
          }
          const result = run.results.find(row => row.featureId === "erase.character")
          const qualification = run.textQualification?.shapes.find(shape => shape.frames?.length)
          const native = JSON.parse(run.rawReplies["erase.character"])
          const calibration = JSON.parse(run.rawReplies["collector.captureCalibration.trace"])
          assert.ok(result.frames?.length, JSON.stringify(result))
          assert.ok(qualification?.frames.length, JSON.stringify(run.textQualification))
          assert.ok(native.captures?.length, "native trace has no produced frames")
          assert.ok(calibration.captures?.length, "calibration has no produced frames")
          assert.ok(open(run, "closure-positive").files.length > 1)
          const unlisted = "sha256:" + "e".repeat(64)
          for (const slot of ["result", "qualification", "native", "calibration"]) {
            const candidate = structuredClone(run)
            if (slot === "result") candidate.results.find(row => row.featureId === "erase.character").frames[0].sourceRef = unlisted
            if (slot === "qualification") candidate.textQualification.shapes.find(shape => shape.frames?.length).frames[0].sourceRef = unlisted
            if (slot === "native" || slot === "calibration") {
              const key = slot === "native" ? "erase.character" : "collector.captureCalibration.trace"
              const trace = JSON.parse(candidate.rawReplies[key])
              trace.captures[0].frame.sourceRef = unlisted
              candidate.rawReplies[key] = JSON.stringify(trace)
            }
            assert.throws(() => open(candidate, "closure-negative-" + slot), /unbound blob/, slot)
          }
          process.exit(0)
        }
        if (expectation === "timeout") {
          assert.equal(reads, 0, "an unacknowledged capture must not read console cells")
          assert.equal(queryWrites, 1, JSON.stringify({ results: run.results }))
          const row = run.results.find(row => row.featureId === "erase.character")
          assert.equal(row.status, "probe-invalid")
          assert.equal(row.assertionType, "buffer_state")
          assert.ok(row.tests.some(check => /timeout.*7 bytes/u.test(check.reason ?? "")), "retain the original acknowledgement timeout on its check")
          assert.match(row.reason, /capture stability 1: console read refused: cursor query timeout, 7 bytes/u)
          const trace = JSON.parse(run.rawReplies[row.rawReplyRef])
          assert.ok(trace.queries.some(query => query.sequence === "\\x1b[6n" && query.reason === "timeout" && query.raw === "partial"))
          assert.equal(readdirSync(process.env.TERMINFO_CAPTURE_DIRECTORY).filter(name => name.endsWith(".txt")).length, 0)
          process.exit(0)
        }
        assert.equal(captureKind, "text-cells")
        assert.equal(typeof capture, "function")
        assert.equal(captured, expectation !== "write-error")
        const frames = readdirSync(process.env.TERMINFO_CAPTURE_DIRECTORY).filter(name => name.endsWith(".txt"))
        assert.equal(frames.length, expectation === "write-error" ? 0 : 1)
        if (expectation !== "write-error") {
          assert.equal(reads, 1)
          assert.match(readFileSync(join(process.env.TERMINFO_CAPTURE_DIRECTORY, frames[0]), "utf8"), /hello/u)
        }
        assert.equal(queryWrites, darwin ? 0 : 1)
        if (!darwin) assert.ok(writes.indexOf("probe-paint") < writes.indexOf("\\x1b[6n"))
        if (expectation === "final-custody") {
          // A reader-only manifest fixture misses both producer omission and launch cleanup loss.
          assert.equal(typeof run.rawReplies["collector.traceManifest"], "string", "producer did not seal retained artifact paths")
          const manifestBytes = run.rawReplies["collector.traceManifest"]
          const manifest = JSON.parse(manifestBytes)
          assert.equal(manifest.blobs.length, 1)
          assert.equal(manifest.blobs[0].path, "artifacts/" + frames[0])
          const originalBytes = Buffer.from(JSON.stringify(run))
          const { readRetainedDaemonProbeResponse } = await import("./packages/terminfo.dev/src/daemon-client.ts")
          const { getTrustedSuiteReceipt } = await import("./packages/terminfo.dev/src/serve.ts")
          const original = await readRetainedDaemonProbeResponse(new Response(originalBytes), {
            directory: join(process.env.HOME, "responses"), receipt: getTrustedSuiteReceipt()
          })
          assert.equal(original.kind, "captured")
          const { retainCollectedRun } = await import("./packages/admin/src/collected-run.ts")
          const finalRoot = join(process.env.HOME, "final")
          const final = retainCollectedRun(original.run, original.path, undefined, finalRoot, join(process.env.HOME, "launch"))
          assert.equal(JSON.parse(readFileSync(final, "utf8")).rawReplies["collector.traceManifest"], manifestBytes)
          assert.deepEqual(readFileSync(join(finalRoot, basename(original.path))), originalBytes)
          rmSync(join(process.env.HOME, "launch"), { recursive: true })
          const { readProbeCapture } = await import("./packages/probes/erase-capture.ts")
          const reopened = readProbeCapture(finalRoot, {
            kind: "trace", trace: { path: basename(original.path), sha256: original.sha256 },
            captureRunId: run.runId, captureSuiteId: run.suiteId, captureSourceRevision: run.sourceRevision
          }, { manifest: getTrustedSuiteReceipt().manifest, sourceRevision: run.sourceRevision, subject: run.subject })
          assert.equal(reopened.capture.rawReplies["collector.traceManifest"], manifestBytes)
          assert.ok(reopened.files.includes(join(finalRoot, manifest.blobs[0].path)))
          assert.match(readFileSync(join(finalRoot, manifest.blobs[0].path), "utf8"), /hello/u)
        }
      }
      `,
      ],
      {
        cwd: packageRoot,
        env: {
          ...process.env,
          HOME: home,
          FIXTURE_EXPECT: expectation,
          TERMINFO_CAPTURE_DIRECTORY: join(
            home,
            expectation === "final-custody" || expectation.startsWith("closure") ? "launch/artifacts" : "capture",
          ),
          TERMINFO_DISPOSABLE_RECEIPT: expectation !== "refusal" ? "hardware-receipt-fixture" : "",
          TERMINFO_RUNTIME_PROVENANCE: "",
          TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
        },
        encoding: "utf8",
        timeout: 10_000,
      },
    )
    expect(result.status, result.stderr).toBe(0)
    expect(result.stderr).toBe("")
  })

  // Extend the existing hosted consumer journey: its Windows-only case never exercised
  // Darwin identity agreement or the absent receipt ID that previously skipped comparison.
  it.each([
    { id: "alacritty", platform: "win32", version: "0.17.0" },
    { id: "cursor", platform: "darwin", version: "3.25.9" },
    { id: "com.microsoft.VSCode", platform: "darwin", version: "1.142.0" },
    { id: "cmux", platform: "darwin", version: "0.65.2" },
  ])(
    "hosted $id requires matching receipt identity before collection and retains its existing version source",
    (fixture) => {
      home = mkdtempSync(join(tmpdir(), "terminfo-serve-hosted-identity-"))
      const result = spawnSync(
        process.execPath,
        [
          "-e",
          `
      import { mock } from "bun:test"
      import assert from "node:assert/strict"
      const fixture = ${JSON.stringify(fixture)}
      Object.defineProperty(process, "platform", { value: fixture.platform })
      const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
      const tty = await import("./packages/terminfo.dev/src/tty.ts")
      const owned = await import("./packages/terminfo.dev/src/owned-terminal.ts")
      let detectedName = fixture.id, receiptAppId = fixture.id, batchCalls = 0
      globalThis.__TERMINFO_BUNDLED_SUITE__ = {
        manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },
        collectorRevision: "b".repeat(40)
      }
      mock.module("./packages/terminfo.dev/src/detect.ts", () => ({
        detectTerminal: () => ({ name: detectedName, version: fixture.platform === "win32" ? "" : fixture.version, os: fixture.platform === "win32" ? "windows" : "macos", osVersion: "fixture" })
      }))
      mock.module("./packages/terminfo.dev/src/owned-terminal.ts", () => ({ ...owned,
        ownedTerminalVerifiedFor: () => true,
        createOwnedTerminal: async () => ({
          geometryAtGrant: { status: "measured", rows: 24, cols: 80 },
          hostedAppId: receiptAppId,
          summary: "owned " + fixture.id + " fixture",
          readCells: fixture.platform === "win32" ? async () => ({
            status: "read",
            grid: { cols: 80, rows: 24, text: ["hello"], attributes: [[0, 0, 0, 0, 0]] },
            bufferOwner: { image: "conhost.exe", pid: 7216, ppid: 4684, executablePath: "C:\\\\Windows\\\\System32\\\\conhost.exe", executableSha256: "sha256:" + "b".repeat(64) }
          }) : undefined,
          dispose: async () => {}
        })
      }))
      mock.module("./packages/terminfo.dev/src/tty.ts", () => ({ ...tty,
        withRawMode: async callback => callback(), drainStdin: async () => {},
        queryWithSentinelOutcome: async (sequence, pattern) => {
          const raw = sequence.includes("[18t") ? "\\x1b[8;24;80t" : ""
          return { raw, rawBase64: Buffer.from(raw).toString("base64"), match: pattern.exec(raw), reason: pattern.test(raw) ? "reply" : "sentinel" }
        }
      }))
      mock.module("./packages/terminfo.dev/src/probes/unified.ts", () => ({ ...unified,
        runProbeBatch: async options => { batchCalls++; return ({
          results: options.draft.results, rawReplies: {},
          appLaunch: fixture.platform === "win32" ? {
            platform: "win32",
            executablePath: "D:\\\\a\\\\_temp\\\\alacritty\\\\alacritty.exe",
            productVersion: "0.17.0",
            executableSha256: "5ad70ddc5c2a2bfe84084a2c4c73558e9360914f035a902d7a69277be7249f1f",
            sourceArtifact: {
              kind: "portable-exe",
              path: "D:\\\\a\\\\_temp\\\\measurement-artifacts\\\\Alacritty-v0.17.0-portable.exe",
              sha256: "5ad70ddc5c2a2bfe84084a2c4c73558e9360914f035a902d7a69277be7249f1f"
            }
          } : undefined,
          observations: [],
          assertions: [], screenshotRefs: [], ungradedDiagnostics: {}, suiteComplete: false
        }) }
      }))
      const { collectProbeRun } = await import("./packages/terminfo.dev/src/serve.ts")
      const run = await collectProbeRun({ ids: ["device.xtversion"] })
      assert.equal(run.subject.id, fixture.id)
      assert.equal(run.subject.version, fixture.version)
      detectedName = fixture.id === "cmux" ? "ghostty" : fixture.id === "cursor" ? "com.microsoft.VSCode" : "cursor"
      await assert.rejects(
        collectProbeRun({ ids: ["device.xtversion"] }),
        { message: "Hosted " + (fixture.platform === "win32" ? "Windows" : "Darwin") + " terminal detected " + JSON.stringify(detectedName) + " while the receipt names " + fixture.id },
      )
      detectedName = fixture.id
      receiptAppId = undefined
      await assert.rejects(
        collectProbeRun({ ids: ["device.xtversion"] }),
        error => error.message.includes(JSON.stringify(fixture.id)) && error.message.includes("receipt app ID is missing"),
      )
      assert.equal(batchCalls, 1, "mismatch and missing identity must not enter collection")
      `,
        ],
        {
          cwd: packageRoot,
          env: {
            ...process.env,
            HOME: home,
            TERMINFO_CAPTURE_DIRECTORY: fixture.platform === "win32" ? join(home, "capture") : "",
            TERMINFO_DISPOSABLE_RECEIPT: "hardware-receipt-fixture",
            TERMINFO_RUNTIME_PROVENANCE: "",
            TERMINFO_CLIPBOARD_FIXTURE_RECEIPT: "",
            TERMINFO_TARGET_VERSION: "",
          },
          encoding: "utf8",
          timeout: 10_000,
        },
      )
      expect(result.status, result.stderr).toBe(0)
      expect(result.stderr).toBe("")
    },
  )

  it.each([undefined, "[]", '["cursor.hide","reset.decaln"]'])(
    "forwards startup selection %s once and preserves producer completeness",
    async (selection) => {
      const { registration } = await startTestDaemon(
        `
          import { mock } from "bun:test"
          const unified = await import("./packages/terminfo.dev/src/probes/unified.ts")
          const tty = await import("./packages/terminfo.dev/src/tty.ts")
          globalThis.__TERMINFO_BUNDLED_SUITE__ = {
            manifest: { schemaVersion: 4, catalogIds: Object.keys((await import("@terminfo/catalog")).loadFeatures(process.cwd() + "/content")).sort(), probeHash: "a".repeat(12), probes: { term: unified.ALL_PROBES.map(p => p.id).sort() } },
            collectorRevision: "b".repeat(40)
          }
          mock.module("./packages/terminfo.dev/src/tty.ts", () => ({
            ...tty, withRawMode: async callback => callback(), drainStdin: async () => {}
          }))
          mock.module("./packages/terminfo.dev/src/probes/unified.ts", () => ({
            ...unified, runProbeBatch: async options => ({
              results: options.draft.results, rawReplies: { selected: options.ids ?? null }, observations: (options.ids ?? []).map(featureId => ({ featureId })),
              assertions: [], screenshotRefs: [], ungradedDiagnostics: {}, suiteComplete: false
            })
          }))
          const { startDaemon } = await import("./packages/terminfo.dev/src/serve.ts")
          await startDaemon()
          process.env.TERMINFO_PROBE_IDS = '["not-a-probe"]'
        `,
        { TERMINFO_PROBE_IDS: selection },
      )
      const response = await fetch(`http://127.0.0.1:${registration.port}/probe`, {
        headers: { Authorization: `Bearer ${registration.token}` },
      })
      expect(response.status).toBe(200)
      const run = (await response.json()) as {
        rawReplies: { selected?: string[] | null; "collector.collectionAttempt"?: string }
        results: { featureId: string; status: string }[]
      }
      if (selection === "[]") {
        expect(run.rawReplies.selected).toBeUndefined()
        expect(JSON.parse(run.rawReplies["collector.collectionAttempt"]!)).toEqual({ ids: [], result: "empty" })
        expect(run).not.toHaveProperty("subject")
        expect(run).not.toHaveProperty("measuredAt")
      } else expect(run.rawReplies.selected).toEqual(selection ? JSON.parse(selection) : null)
      expect(run.results).toHaveLength(273)
      expect(new Set(run.results.map((result) => result.featureId)).size).toBe(273)
      expect(run.results.every((result) => result.status === "probe-todo")).toBe(true)
      // AC1: explicit request selection overrides startup selection, including [] rather than full.
      for (const ids of [[], ["cursor.show"]]) {
        const selected = await fetch(`http://127.0.0.1:${registration.port}/probe`, {
          method: "POST",
          headers: { Authorization: `Bearer ${registration.token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ ids }),
        })
        expect(selected.status).toBe(200)
        const result = (await selected.json()) as {
          rawReplies: { selected?: string[]; "collector.collectionAttempt": string }
        }
        expect(result.rawReplies.selected).toEqual(ids.length === 0 ? undefined : ids)
        expect(JSON.parse(result.rawReplies["collector.collectionAttempt"])).toMatchObject({
          ids,
          result: ids.length === 0 ? "empty" : "completed",
        })
      }
    },
  )

  it.each(["", "null", '["cursor.hide","cursor.hide"]', '["not-a-probe"]', '["cursor.hide",3]'])(
    "refuses malformed or inapplicable private IDs %s before listening",
    (value) => {
      home = mkdtempSync(join(tmpdir(), "terminfo-serve-private-"))
      const result = spawnSync(
        process.execPath,
        ["-e", 'import { startDaemon } from "./packages/terminfo.dev/src/serve.ts"; startDaemon()'],
        {
          cwd: packageRoot,
          env: { ...process.env, HOME: home, TERMINFO_PROBE_IDS: value },
          encoding: "utf8",
          timeout: 1500,
        },
      )
      expect(result.status).toBe(1)
      expect(result.stderr).toContain("TERMINFO_PROBE_IDS")
    },
  )
})
