/**
 * @failure Complete XTVERSION frames are rejected or truncated frames are trusted as terminal identity.
 * @level l1
 * @consumer App daemon run identity review
 * @testonly none
 */
import { describe, it, expect } from "vitest"
import {
  declaredAppVersion,
  deriveIdentity,
  resolveMeasuredAppVersion,
  verifyTerminalIdentity,
} from "./identity-guard.ts"
import muxIdentity from "./fixtures/mux-identity.json"

describe("measured multiplexer identity", () => {
  // These are the bytes retained by the detached Linux probes; the fixture records their hashes.
  // Existing app cases cannot catch a mux being accepted from its outer app's replies.
  it.each(muxIdentity.specimens)(
    "resolves and verifies $mux from its own complete replies",
    ({ mux, version, run }) => {
      expect(resolveMeasuredAppVersion(mux, "", run.rawReplies)).toBe(version)
      expect(verifyTerminalIdentity(mux, run.rawReplies)).toEqual({ ok: true, checked: true })
      expect(() => resolveMeasuredAppVersion(mux, "0.0", run.rawReplies)).toThrow(/version mismatch/)
      expect(
        verifyTerminalIdentity(mux, {
          "device.primary-da": "\x1b[?62;52;c",
          "device.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\\x1b[?62;52;c",
        }),
      ).toMatchObject({ ok: false, checked: true })
    },
  )

  // 4.09.01 is the host specimen; 5.0.2 is the declared Kitty image's actual Screen.
  it.each([
    ["40901", "4.09.01"],
    ["50002", "5.0.2"],
  ])("measures Screen %s from preflight DA2 without feature identity probes", (encoded, version) => {
    const replies = { "collector.xtversion": "\x1b[?1;2c", "collector.da2": `\x1b[>83;${encoded};0c\x1b[?1;2c` }
    expect(resolveMeasuredAppVersion("screen", "", replies)).toBe(version)
    expect(resolveMeasuredAppVersion("screen", version, replies)).toBe(version)
    expect(verifyTerminalIdentity("screen", replies)).toEqual({ ok: true, checked: true })
    expect(verifyTerminalIdentity("screen", { ...replies, "device.primary-da": "\x1b[?1;2;4c" }).reason).toMatch(
      /DA1 mismatch/,
    )
  })

  it.each(["", "\x1b[?1;2c", "\x1b[>83;40901;0", "\x1b[>84;40901;0c", "\x1b[>83;40901;0cjunk"])(
    "refuses Screen preflight %j without borrowing a valid feature DA2",
    (da2) => {
      const replies = {
        "collector.xtversion": "\x1b[?1;2c",
        "collector.da2": da2,
        "device.secondary-da": "\x1b[>83;40901;0c\x1b[?1;2c",
      }
      expect(() => resolveMeasuredAppVersion("screen", "", replies)).toThrow(/DA2/)
      expect(verifyTerminalIdentity("screen", replies)).toMatchObject({ ok: false, checked: true })
    },
  )

  it.each(["", "tmux 3.6", "\x1bP>|tmux 3.6", "\x1bP>|tmux anything\x1b\\"])(
    "refuses tmux identity without a complete version-bearing DCS: %j",
    (xtversion) => {
      const replies = { "device.primary-da": "\x1b[?1;2;4c", "device.xtversion": xtversion }
      expect(verifyTerminalIdentity("tmux", replies)).toMatchObject({ ok: false, checked: true })
      expect(() => resolveMeasuredAppVersion("tmux", "", replies)).toThrow(/XTVERSION/)
    },
  )
})

describe("verifyTerminalIdentity", () => {
  it("measures Kitty version and DA1 from collector identity without feature keys", () => {
    const responses = { "collector.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\\x1b[?62;52;c" }
    expect(resolveMeasuredAppVersion("kitty", "", responses)).toBe("0.49.2")
    expect(verifyTerminalIdentity("kitty", responses, { "device.xtversion": false })).toEqual({
      ok: true,
      checked: true,
    })
    expect(verifyTerminalIdentity("kitty", { "collector.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\" }).reason).toContain(
      "DA1 mismatch",
    )
    // Legacy feature frames must not donate their trailing DA1 to identity.
    expect(verifyTerminalIdentity("kitty", { "device.xtversion": responses["collector.xtversion"] }).reason).toContain(
      "DA1 mismatch",
    )
  })

  it.each(["", "malformed", "garbage\x1b[?62;52;c", "\x1b[?1;2c"])(
    "preserves an explicit DA1 %j beside a valid collector suffix",
    (da1) => {
      expect(
        verifyTerminalIdentity("kitty", {
          "collector.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\\x1b[?62;52;c",
          "device.primary-da": da1,
        }).reason,
      ).toMatch(/DA1 (?:mismatch|malformed)/)
    },
  )

  it("measures the WezTerm version from its release-tagged XTVERSION and refuses either half alone", () => {
    const responses = { "collector.xtversion": "\x1bP>|WezTerm 0-unstable-2026-09-17\x1b\\\x1b[?65;4;6;18;22;52c" }
    expect(resolveMeasuredAppVersion("wezterm", "", responses)).toBe("0-unstable-2026-09-17")
    expect(verifyTerminalIdentity("wezterm", responses)).toEqual({ ok: true, checked: true })
    // A date-tagged build keeps resolving rather than being refused.
    expect(
      resolveMeasuredAppVersion("wezterm", "", {
        "collector.xtversion": "\x1bP>|WezTerm 20240203\x1b\\\x1b[?65;4;6;18;22;52c",
      }),
    ).toBe("20240203")
    // WezTerm's DA1 without a WezTerm XTVERSION is not WezTerm.
    expect(
      verifyTerminalIdentity("wezterm", { "collector.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\\x1b[?65;4;6;18;22;52c" }),
    ).toMatchObject({ ok: false, checked: true })
    // A foreign DA1 beside the WezTerm XTVERSION is refused too.
    expect(
      verifyTerminalIdentity("wezterm", { "collector.xtversion": "\x1bP>|WezTerm 20240203\x1b\\\x1b[?62;52;c" }).reason,
    ).toContain("DA1 mismatch")
  })

  it("requires explicit DA1 bytes to agree with the collector witness and judges suffixless frames independently", () => {
    const da1 = "\x1b[?62;52;c"
    const responses = {
      "collector.xtversion": `\x1bP>|kitty(0.49.2)\x1b\\${da1}`,
      "device.primary-da": da1,
    }
    expect(verifyTerminalIdentity("kitty", responses).ok).toBe(true)
    const other = "\x1b[?62;4;c"
    const mismatch = { ...responses, "device.primary-da": other }
    const refused = verifyTerminalIdentity("kitty", mismatch)
    expect(refused.ok).toBe(false)
    expect(refused.reason).toContain("DA1 mismatch")
    expect(refused.reason).toContain("[?62;52;c")
    expect(refused.reason).toContain("[?62;4;c")
    expect(() => resolveMeasuredAppVersion("kitty", "", mismatch)).toThrow(/DA1 mismatch/)
    for (const raw of [da1 + da1, `stray${da1}`]) {
      const malformed = { ...responses, "device.primary-da": raw }
      expect(verifyTerminalIdentity("kitty", malformed).reason).toContain("DA1 malformed")
      expect(() => resolveMeasuredAppVersion("kitty", "", malformed)).toThrow(/DA1 malformed/)
    }
    expect(
      verifyTerminalIdentity("kitty", { ...mismatch, "collector.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\" }).ok,
    ).toBe(true)
  })

  it("uses a collector DA1-only reply for Terminal.app while retaining DA2 and forbidden XTVERSION", () => {
    const responses = {
      "collector.xtversion": "\x1b[?1;2c",
      "device.secondary-da": "\x1b[>1;95;0c",
    }
    expect(verifyTerminalIdentity("terminal-app", responses)).toEqual({ ok: true, checked: true })
    expect(
      verifyTerminalIdentity("terminal-app", { "collector.xtversion": responses["collector.xtversion"] }).reason,
    ).toContain("DA2 mismatch")
    expect(
      verifyTerminalIdentity("terminal-app", {
        ...responses,
        "collector.xtversion": "",
        "device.primary-da": "\x1b[?1;2c",
      }).ok,
    ).toBe(true)
    expect(
      verifyTerminalIdentity("terminal-app", {
        ...responses,
        "collector.xtversion": "\x1bP>|xterm(370)\x1b\\\x1b[?1;2c",
      }).reason,
    ).toContain("does not support XTVERSION")
  })

  it("prefers owned preflight identity without borrowing the feature's outcome", () => {
    const responses = {
      "device.primary-da": "\x1b[?62;52;c",
      "device.xtversion": "\x1bP>|kitty(0.48.0)\x1b\\",
      "collector.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\\x1b[?62;52;c",
    }
    expect(resolveMeasuredAppVersion("kitty", "", responses)).toBe("0.49.2")
    expect(verifyTerminalIdentity("kitty", responses, { "device.xtversion": false }).ok).toBe(true)
    const { "collector.xtversion": _collector, ...fallback } = responses
    expect(resolveMeasuredAppVersion("kitty", "", fallback)).toBe("0.48.0")
    expect(resolveMeasuredAppVersion("vterm", "1.2.3", responses)).toBe("1.2.3")
  })

  it.each(["", "\x1b[?62;52;c", "\x1bP>|kitty(0.49.2)"])(
    "names invalid collector preflight %j without falling back to a feature reply",
    (raw) => {
      const responses = {
        "collector.xtversion": raw,
        "device.xtversion": "\x1bP>|kitty(0.49.2)\x1b\\",
        "device.primary-da": "\x1b[?62;52;c",
      }
      expect(() => resolveMeasuredAppVersion("kitty", "0.49.2", responses)).toThrow(/identity: XTVERSION preflight/)
      expect(verifyTerminalIdentity("kitty", responses).reason).toMatch(/identity: XTVERSION preflight/)
      if (raw.startsWith("\x1bP")) {
        expect(verifyTerminalIdentity("kitty", responses).reason).toContain(Buffer.from(raw).toString("base64"))
      }
    },
  )

  it("accepts complete XTVERSION DCS bytes and refuses a truncated frame", () => {
    const da1 = "\x1b[?62;52;c"
    expect(
      verifyTerminalIdentity("kitty", {
        "device.primary-da": da1,
        "device.xtversion": "\x1bP>|kitty(0.49.1)\x1b\\",
      }).ok,
    ).toBe(true)
    expect(
      verifyTerminalIdentity("kitty", {
        "device.primary-da": da1,
        "device.xtversion": "\x1bP>|kitty(0.49.1)\x1b\\\x1b[?62;4c",
      }).ok,
    ).toBe(true)
    expect(
      verifyTerminalIdentity("kitty", {
        "device.primary-da": da1,
        "device.xtversion": "\x1bP>|kitty(0.49.1)",
      }).ok,
    ).toBe(false)
  })
  it("accepts a valid kitty probe result with XTVERSION and VT220 DA1", () => {
    const responses = {
      "device.primary-da": "\u001b[?62;52;c",
      "device.xtversion": "kitty(0.46.2)",
    }
    const results = {
      "device.xtversion": true,
    }
    const res = verifyTerminalIdentity("kitty", responses, results)
    expect(res.ok).toBe(true)
  })

  it("rejects a fake kitty run that returned VT100 DA1 (?1;2c) and no XTVERSION", () => {
    // This exact pattern was produced by eda4e39
    const responses = {
      "device.primary-da": "\u001b[?1;2c",
      "device.xtversion": "No XTVERSION response",
    }
    const results = {
      "device.xtversion": false,
    }
    const res = verifyTerminalIdentity("kitty", responses, results)
    expect(res.ok).toBe(false)
    expect(res.reason).toContain("requires an XTVERSION response")
  })

  it("rejects a fake kitty run with DA1 ?1;2c even if XTVERSION was somehow set", () => {
    const responses = {
      "device.primary-da": "\u001b[?1;2c",
      "device.xtversion": "kitty(0.46.2)",
    }
    const results = {
      "device.xtversion": true,
    }
    const res = verifyTerminalIdentity("kitty", responses, results)
    expect(res.ok).toBe(false)
    expect(res.reason).toContain("DA1 mismatch")
  })

  it("rejects kitty if XTVERSION matches a different terminal like xterm.js", () => {
    const responses = {
      "device.primary-da": "\u001b[?62;52;c",
      "device.xtversion": "xterm.js(6.1.0)",
    }
    const results = {
      "device.xtversion": true,
    }
    const res = verifyTerminalIdentity("kitty", responses, results)
    expect(res.ok).toBe(false)
    expect(res.reason).toContain("XTVERSION mismatch")
  })

  it("accepts valid ghostty and iterm2 results", () => {
    const ghosttyRes = verifyTerminalIdentity(
      "ghostty",
      { "device.primary-da": "\u001b[?62;22;52c", "device.xtversion": "ghostty 1.3.1" },
      { "device.xtversion": true },
    )
    expect(ghosttyRes.ok).toBe(true)

    const itermRes = verifyTerminalIdentity(
      "iterm2",
      { "device.primary-da": "\u001b[?64;1;2;4;6;17;18;21;22;52c", "device.xtversion": "iTerm2 3.6.9" },
      { "device.xtversion": true },
    )
    expect(itermRes.ok).toBe(true)
  })

  it("rejects iterm2 if DA1 is not VT420 (?64;...)", () => {
    const itermRes = verifyTerminalIdentity(
      "iterm2",
      { "device.primary-da": "\u001b[?62;22;52c", "device.xtversion": "iTerm2 3.6.9" },
      { "device.xtversion": true },
    )
    expect(itermRes.ok).toBe(false)
    expect(itermRes.reason).toContain("DA1 mismatch")
  })

  it("accepts Terminal.app only with its complete DA2 family reply", () => {
    const termRes = verifyTerminalIdentity(
      "terminal-app",
      { "device.primary-da": "\u001b[?1;2c", "device.secondary-da": "\u001b[>1;95;0c" },
      { "device.xtversion": false },
    )
    expect(termRes.ok).toBe(true)
    expect(
      verifyTerminalIdentity("terminal-app", {
        "device.primary-da": "\x1b[?1;2c",
        "device.secondary-da": "\x1b[>1;95;0c",
        "collector.xtversion": "\x1b[?1;2c",
      }).ok,
    ).toBe(true)
    expect(verifyTerminalIdentity("terminal-app", { "device.primary-da": "\u001b[?1;2c" }).ok).toBe(false)
    expect(
      verifyTerminalIdentity("terminal-app", {
        "device.primary-da": "\u001b[?1;2c",
        "device.secondary-da": "\u001b[>0;95;0c",
      }).ok,
    ).toBe(false)
  })

  it("rejects terminal-app if an XTVERSION response is returned", () => {
    const termRes = verifyTerminalIdentity(
      "terminal-app",
      { "device.primary-da": "\u001b[?1;2c", "device.xtversion": "xterm(370)" },
      { "device.xtversion": true },
    )
    expect(termRes.ok).toBe(false)
    expect(termRes.reason).toContain("does not support XTVERSION")
    const completeDcs = verifyTerminalIdentity("terminal-app", {
      "device.primary-da": "\x1b[?1;2c",
      "device.xtversion": "\x1bP>|xterm(370)\x1b\\\x1b[?1;2c",
    })
    expect(completeDcs.reason).toContain("does not support XTVERSION")
    const truncatedDcs = verifyTerminalIdentity("terminal-app", {
      "device.primary-da": "\x1b[?1;2c",
      "device.xtversion": "\x1bP>|xterm(370)",
    })
    expect(truncatedDcs.reason).toContain("incomplete XTVERSION DCS frame")
  })

  it("marks checked: true when an identity rule exists and passes", () => {
    const res = verifyTerminalIdentity(
      "kitty",
      { "device.primary-da": "\u001b[?62;52;c", "device.xtversion": "kitty(0.46.2)" },
      { "device.xtversion": true },
    )
    expect(res.ok).toBe(true)
    expect(res.checked).toBe(true)
  })

  it("marks checked: false when no identity rule is registered", () => {
    const res = verifyTerminalIdentity("unknown-terminal", { "device.primary-da": "\u001b[?1;2c" })
    expect(res.ok).toBe(false)
    expect(res.checked).toBe(false)
    expect(res.reason).toMatch(/no identity profile/)
  })

  it("resolves Kitty's version from the complete captured frame and refuses declared conflict", () => {
    const replies = {
      "device.primary-da": "\x1b[?62;52;c",
      "device.xtversion": "\x1bP>|kitty(0.49.1)\x1b\\\x1b[?62;52;c",
    }
    expect(resolveMeasuredAppVersion("kitty", "", replies)).toBe("0.49.1")
    expect(resolveMeasuredAppVersion("kitty", "0.49.1", replies)).toBe("0.49.1")
    expect(() => resolveMeasuredAppVersion("kitty", "0.48.0", replies)).toThrow(/version mismatch/)
    expect(resolveMeasuredAppVersion("kitty", "", { ...replies, "device.xtversion": "\x1bP>|kitty(0.49.1)" })).toBe(
      "unknown",
    )
    expect(() =>
      resolveMeasuredAppVersion("kitty", "0.49.1", { ...replies, "device.xtversion": "\x1bP>|xterm(0.49.1)\x1b\\" }),
    ).toThrow(/identity mismatch/)
  })

  it("resolves each measured target's version from its own identity rule", () => {
    const xterm = {
      "collector.xtversion": "\x1bP>|XTerm(411)\x1b\\\x1b[?64;1;2;6;9;15;16;17;18;21;22;28;29c",
    }
    expect(resolveMeasuredAppVersion("xterm", "", xterm)).toBe("411")
    expect(resolveMeasuredAppVersion("xterm", "411", xterm)).toBe("411")
    expect(() => resolveMeasuredAppVersion("xterm", "410", xterm)).toThrow(/version mismatch/)
    expect(verifyTerminalIdentity("xterm", xterm)).toEqual({ ok: true, checked: true })
    const ghostty = { "collector.xtversion": "\x1bP>|ghostty 1.3.1\x1b\\\x1b[?62;22;52c" }
    expect(resolveMeasuredAppVersion("ghostty", "", ghostty)).toBe("1.3.1")
    expect(verifyTerminalIdentity("ghostty", ghostty)).toEqual({ ok: true, checked: true })
  })

  it("captures the measured iTerm2 version from the reply the admitted run answers (28216)", () => {
    const iterm = { "collector.xtversion": "\x1bP>|iTerm2 3.6.11\x1b\\\x1b[?64;1;2;6;9;15;16;17;18;21;22;28;29c" }
    expect(resolveMeasuredAppVersion("iterm2", "", iterm)).toBe("3.6.11")
    expect(resolveMeasuredAppVersion("iterm2", "3.6.11", iterm)).toBe("3.6.11")
    expect(() => resolveMeasuredAppVersion("iterm2", "3.6.10", iterm)).toThrow(/version mismatch/)
    expect(verifyTerminalIdentity("iterm2", iterm)).toEqual({ ok: true, checked: true })
    // A bare prefix names the terminal but no version, so the guard refuses it rather than admitting
    // a run whose version nothing measured.
    expect(
      verifyTerminalIdentity("iterm2", {
        "device.primary-da": "\x1b[?64;1;2;4;6;17;18;21;22;52c",
        "device.xtversion": "\x1bP>|iTerm2\x1b\\\x1b[?64;1;2;4;6;17;18;21;22;52c",
      }),
    ).toMatchObject({ ok: false, checked: true })
    // A feature-source reply is not a complete DCS frame, so the detected version stands as before.
    expect(resolveMeasuredAppVersion("iterm2", "3.6.9", { "device.xtversion": "iTerm2 3.6.9" })).toBe("3.6.9")
  })

  it("keeps the detected version for an id whose rule captures none, and invents nothing", () => {
    // warp's rule names its terminal but captures no version, so the detected version stands.
    expect(resolveMeasuredAppVersion("warp", "0.2026.03.18.08.24.03", {})).toBe("0.2026.03.18.08.24.03")
    // wezterm and alacritty have no identity rule at all: named-unavailable, never guessed.
    expect(resolveMeasuredAppVersion("wezterm", "", {})).toBe("unknown")
    expect(resolveMeasuredAppVersion("alacritty", "", {})).toBe("unknown")
  })

  it("takes the apparatus-declared version only where the app reports none", () => {
    // Alacritty answers no XTVERSION and sets no TERM_PROGRAM, so its measured version is unknown
    // and every exact-version App declaration was dropped before the batch (#32889).
    const measured = resolveMeasuredAppVersion("alacritty", "", {})
    expect(declaredAppVersion(measured, "0.17.0")).toBe("0.17.0")
    expect(declaredAppVersion(measured, "  0.17.0  ")).toBe("0.17.0")
    // A detected or measured version always wins over the apparatus declaration.
    expect(declaredAppVersion("0.17.0", "0.17.0")).toBe("0.17.0")
    expect(declaredAppVersion("0.16.1", "0.17.0")).toBe("0.16.1")
    // Silence declares nothing, so a non-apparatus run keeps the measured unknown.
    expect(declaredAppVersion(measured, undefined)).toBe("unknown")
    expect(declaredAppVersion(measured, "   ")).toBe("unknown")
  })

  it("accepts the ConPTY reply order, where the console's DA1 arrives before the XTVERSION DCS", () => {
    // Run 39288137832, wezterm on Windows: OpenConsole answers the DA1 sentinel itself, so the
    // collector reads the console's DA1 first and WezTerm's XTVERSION second. Accepting the order
    // must not turn the console's DA1 into the app's witness: WezTerm's own DA1 is <?65;.
    const conpty = "\x1b[?61;6;7;22;23;24;28;32;42c\x1bP>|WezTerm 20240203-110809-5046fc22\x1b\\"
    expect(deriveIdentity({ "collector.xtversion": conpty })).toMatchObject({
      source: "collector",
      xtversionPayload: "WezTerm 20240203-110809-5046fc22",
      da1: undefined,
    })
    expect(resolveMeasuredAppVersion("wezterm", "", { "collector.xtversion": conpty })).toBe("20240203-110809-5046fc22")
    // The DCS-first order keeps its existing meaning: a trailing DA1 is the app's own witness.
    expect(deriveIdentity({ "collector.xtversion": "\x1bP>|WezTerm 20240203\x1b\\\x1b[?65;4;6;18;22;52c" }).da1).toBe(
      "\x1b[?65;4;6;18;22;52c",
    )
  })
})
