/**
 * @failure A callback's explicit result or exact TTY reply bytes are discarded, or a failed owned restoration is graded as success.
 * @level l1
 * @consumer Real-terminal app, daemon, and inline probe batch
 * @testonly none
 * @reach fs-walk <fixture-only: /tmp/terminfo-disposable-receipts>
 */
import { createHash, randomUUID } from "node:crypto"
import { appendFileSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs"
import * as nodeFs from "node:fs"
import { appSemanticDeclarations, readSessionBus } from "../app-semantic-state.ts"
import { tmpdir } from "node:os"
import { basename, join } from "node:path"
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest"
import { createCallLog, readCallLog, withCallLog } from "viprobe"
import {
  ALL_PROBES,
  initializeRunDraft,
  type ProbeSuiteManifest,
  type ObservationFrame,
  type TextQualification,
  type TermProbeSource,
  type AppSemanticReading,
} from "@terminfo/probe-defs"
import { replyFailure, notTestedResult, declaredUntestableResult } from "../../../probe-defs/src/helpers.ts"
import { parseRun, decodeCollectorDraft } from "@terminfo/run-parser"
import * as terminalOwnership from "../owned-terminal.ts"
import { verifyTerminalIdentity } from "../identity-guard.ts"
import { measureUtf8Decoding } from "../tty.ts"
import { captureAdapterEligible, runProbeBatch } from "./unified.ts"
import { saveDaemonProbeRun } from "../capture-writer.ts"
import { retainCollectedRun } from "../../../admin/src/collected-run.ts"
import { readProbeCapture } from "../../../probes/erase-capture.ts"
import { runEraseReplay } from "../../../probes/erase-run.ts"
import * as headlessIdentity from "../../../probes/headless-identity.ts"
import { derivedSuiteManifest, sourceSuiteEnvironment } from "../../../admin/versions.ts"
import { finishCapture } from "../capture-core.ts"
import { calibrateCaptureOrigin } from "../capture-calibration.ts"
import { collectTextQualification } from "../text-qualification.ts"
import { createClipboardTransaction, type LinuxClipboardAdapter } from "../linux-clipboard.ts"

// Most cases stub only decode-context measurement; its evidence owner below exercises the real
// round trip. Every other tty export stays real, so the batch path under test is unchanged.
vi.mock("../tty.ts", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../tty.ts")>()
  return { ...actual, measureUtf8Decoding: vi.fn(actual.measureUtf8Decoding) }
})

// The prerequisite read needs deterministic permission errors; all other filesystem calls stay real.
vi.mock("node:fs", async (importOriginal) => {
  const actual = await importOriginal<typeof import("node:fs")>()
  return { ...actual, statSync: vi.fn(actual.statSync) }
})

const linuxGeometrySource = "stty size on a /proc/self/fd reopen of the verified output device" as const

// @failure An approved exact-version declaration is dropped by either unresolved callback path.
// Existing native recording cases have no declaration map; both paths are used by prompt callbacks.
// @level l1
// @consumer runProbeBatch -> recordExecutedProbe -> canonical result reader.
it.each(["coverage", "explicit todo"] as const)(
  "records an approved App declaration after unresolved %s",
  async (path) => {
    const id = "extensions.osc133-a"
    const definition = ALL_PROBES.find((probe) => probe.id === id)!
    const original = { term: definition.term, termWrites: definition.termWrites }
    const reason = "Untestable (no way): this exact App version has no prompt-state reader."
    try {
      // The in-memory callback performs no terminal operation; retain the real batch/recorder.
      definition.termWrites = "query"
      definition.term = async () =>
        path === "coverage"
          ? notTestedResult("No prompt-state reading", { source: "fixture" })
          : { pass: false, tests: [{ id: "criterion", status: "probe-todo", reason: "No prompt-state reading" }] }
      const options = { ids: [id], appDeclarations: { [id]: reason } }
      const batch = await runProbeBatch(options)
      expect(batch.results.find((result) => result.featureId === id)).toMatchObject({
        status: "untestable",
        reason,
        tests: [{ id: "declared-untestable", status: "untestable", reason }],
      })
      expect(batch.assertions).toEqual([])
      expect(batch.ungradedDiagnostics).toEqual({})
    } finally {
      definition.term = original.term
      definition.termWrites = original.termWrites
    }
  },
)

// @failure A real App callback that reports coverage without a notTested block drops the audited
// declaration; the stubbed two-path case above cannot see it because both stub shapes carry one.
// @level l1
// @consumer current-child App declarations -> runProbeBatch canonical recorder -> OSC 710 callback.
it("applies the audited Alacritty declaration to the real OSC 710 coverage result", async () => {
  const id = "extensions.osc710-font-normal"
  const subject = { kind: "term" as const, id: "alacritty", version: "0.17.0", os: "linux" as const }
  const declarations = appSemanticDeclarations(subject, {
    observedAt: new Date().toISOString(),
    address: "absent" as const,
    socket: { path: "/fixture/bus", outcome: "absent" as const, code: "ENOENT" },
  })
  expect(declarations[id]).toContain("Untestable (no way)")
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const declared = await runProbeBatch({
    ids: [id],
    subject,
    appDeclarations: declarations,
    ownedTerminal: geometryOwner(noGeometry),
  })
  expect(declared.results.find((result) => result.featureId === id)).toMatchObject({
    status: "untestable",
    reason: declarations[id],
  })
  const undeclared = await runProbeBatch({
    ids: [id],
    subject,
    appDeclarations: {},
    ownedTerminal: geometryOwner(noGeometry),
  })
  expect(undeclared.results.find((result) => result.featureId === id)).toMatchObject({ status: "probe-todo" })
})

// @failure Notification cells select no-setup without this run's missing bus, or remain TODO after observed absence.
// Existing Ghostty cases cover prompt rows, not the fourteen notification positions.
// @level l1
// @consumer current-child App declarations -> runProbeBatch canonical recorder.
it.each([
  { kind: "term", id: "kitty", version: "0.49.2" },
  { kind: "term", id: "ghostty", version: "1.4.0" },
  { kind: "term", id: "wezterm", version: "0-unstable-2026-10-10" },
  { kind: "term", id: "alacritty", version: "0.17.0" },
  { kind: "term", id: "xterm", version: "411" },
  { kind: "mux", id: "screen", version: "5.0.2" },
  { kind: "mux", id: "tmux", version: "3.8" },
] as const)("uses current-run bus absence for both $id notification cells", async (subject) => {
  const ids = ["extensions.notifications", "extensions.osc777-notify"]
  const probes = ids.map((id) => ALL_PROBES.find((probe) => probe.id === id)!)
  const originals = probes.map((probe) => ({ term: probe.term, termWrites: probe.termWrites }))
  try {
    for (const [index, probe] of probes.entries()) {
      probe.termWrites = "query"
      // Keep the actual callback/result producer; model only its TTY operations.
      probe.term = async (ctx) =>
        originals[index]!.term!(
          new Proxy(ctx, {
            get(target, key) {
              if (key === "write") return () => {}
              if (key === "queryCursorPosition") return async () => ({ row: 1, col: 1 })
              return Reflect.get(target, key)
            },
          }),
        )
    }
    const base = {
      observedAt: new Date().toISOString(),
      address: "absent" as const,
      socket: { path: "/fixture/bus", outcome: "absent" as const, code: "ENOENT" },
    }
    for (const bus of [
      undefined,
      { ...base, address: "present" as const },
      { ...base, socket: { ...base.socket, outcome: "present" as const } },
      { ...base, socket: { ...base.socket, outcome: "error" as const, code: "EACCES" } },
      base,
      { ...base, socket: { ...base.socket, code: "ENOTDIR" } },
    ]) {
      const absent = bus?.address === "absent" && bus.socket.outcome === "absent"
      const declarations = appSemanticDeclarations({ ...subject, os: "linux" }, bus)
      const batch = await runProbeBatch({ ids, subject: { ...subject, os: "linux" }, appDeclarations: declarations })
      for (const id of ids) {
        const result = batch.results.find((row) => row.featureId === id)!
        expect(result.status, JSON.stringify({ result, diagnostics: batch.ungradedDiagnostics })).toBe(
          absent ? "untestable" : "probe-todo",
        )
        if (absent) expect(result.reason).toContain("Untestable (no setup)")
        else expect(declarations[id]).toBeUndefined()
      }
    }
  } finally {
    probes.forEach((probe, index) => Object.assign(probe, originals[index]))
  }
})

// Exact-version routing is not covered by the generic map-consumption cases above.
// @failure New versions inherit an audit, or an audited subject loses its declaration.
it.each([
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc7-cwd" },
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "extensions.osc7-cwd" },
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "modes.decsclm" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc633-e" },
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "extensions.osc133-a" },
  { kind: "term", id: "kitty", version: "0.49.2", count: 10, feature: "extensions.osc133-b" },
  { kind: "term", id: "kitty", version: "0.49.2", count: 10, feature: "extensions.osc133-p" },
  { kind: "term", id: "kitty", version: "0.49.2", count: 10, feature: "extensions.osc133-a" },
  { kind: "term", id: "kitty", version: "0.49.2", count: 10, feature: "extensions.semantic-prompts" },
  { kind: "term", id: "kitty", version: "0.49.2", count: 10, feature: "extensions.osc3008-context" },
  { kind: "term", id: "wezterm", version: "0-unstable-2026-10-10", count: 8, feature: "extensions.osc133-d" },
  { kind: "term", id: "wezterm", version: "0-unstable-2026-10-10", count: 8, feature: "extensions.osc133-a" },
  { kind: "term", id: "wezterm", version: "0-unstable-2026-10-10", count: 8, feature: "extensions.osc133-p" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc633-e" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc633-a" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc-633-vscode" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc133-a" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc133-p" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc666-termprop" },
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "extensions.osc666-termprop" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc666-termprop" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc176-app-id" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc440-audio" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc3008-context" },
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "extensions.osc176-app-id" },
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "extensions.osc440-audio" },
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "extensions.osc3008-context" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc176-app-id" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc440-audio" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc3008-context" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc555-flash" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc710-font-normal" },
  // #32601: existing subjects cannot catch a missing Alacritty audit or identity leakage from its one-cell declaration.
  { kind: "term", id: "alacritty", version: "0.17.0", count: 21, feature: "extensions.osc710-font-normal" },
  // #32918: Alacritty implements no OSC 133/633, so its thirteen prompt cells are declarations, not runs.
  { kind: "term", id: "alacritty", version: "0.17.0", count: 21, feature: "extensions.osc133-a" },
  // #32889: Alacritty 0.17.0 and tmux 3.8 drop OSC 176/3008/440/666 (and tmux 710) in their unknown-OSC parser paths.
  { kind: "term", id: "alacritty", version: "0.17.0", count: 21, feature: "extensions.osc176-app-id" },
  { kind: "term", id: "alacritty", version: "0.17.0", count: 21, feature: "extensions.osc3008-context" },
  { kind: "term", id: "alacritty", version: "0.17.0", count: 21, feature: "extensions.osc440-audio" },
  { kind: "term", id: "alacritty", version: "0.17.0", count: 21, feature: "extensions.osc666-termprop" },
  { kind: "mux", id: "tmux", version: "3.8", count: 10, feature: "extensions.osc176-app-id" },
  { kind: "mux", id: "tmux", version: "3.8", count: 10, feature: "extensions.osc3008-context" },
  { kind: "mux", id: "tmux", version: "3.8", count: 10, feature: "extensions.osc440-audio" },
  { kind: "mux", id: "tmux", version: "3.8", count: 10, feature: "extensions.osc666-termprop" },
  { kind: "mux", id: "tmux", version: "3.8", count: 10, feature: "extensions.osc710-font-normal" },
  { kind: "mux", id: "tmux", version: "3.8", count: 10, feature: "extensions.osc633-e" },
  // #32948: Linux App and mux OSC 8 hyperlink declarations. WezTerm's is no longer one: c0651cbe8 (33001)
  // reads its owned OSC 8 link spans, so its declarations drop to 8 and omit extensions.osc8 (33455).
  { kind: "mux", id: "screen", version: "5.0.2", count: 26, feature: "extensions.osc8" },
  { kind: "term", id: "xterm", version: "411", count: 23, feature: "extensions.osc8" },
  { kind: "term", id: "alacritty", version: "0.17.0", count: 21, feature: "extensions.osc8" },
  { kind: "term", id: "ghostty", version: "1.4.0", count: 22, feature: "extensions.osc8" },
  { kind: "term", id: "kitty", version: "0.49.2", count: 10, feature: "extensions.osc8" },
] as const)(
  "routes only the audited $id version through the canonical recorder",
  async ({ kind, id, version, count, feature }) => {
    const subject = { kind, id, version, os: "linux" }
    const bus = {
      observedAt: new Date().toISOString(),
      address: "absent" as const,
      socket: { path: "/fixture/bus", outcome: "absent" as const, code: "ENOENT" },
    }
    const declarations = appSemanticDeclarations(subject, bus)
    expect(declarations).toHaveProperty(feature, expect.stringContaining(version))
    expect(Object.keys(declarations)).toHaveLength(count)
    expect(appSemanticDeclarations({ ...subject, version: version + "-new" }, bus)).toEqual({})
    expect(appSemanticDeclarations({ ...subject, version: "" }, bus)).toEqual({})
    expect(appSemanticDeclarations({ ...subject, version: "unknown" }, bus)).toEqual({})
    expect(appSemanticDeclarations({ ...subject, os: "darwin" }, bus)).toEqual({})
    expect(appSemanticDeclarations({ ...subject, kind: "lib" }, bus)).toEqual({})
    const probe = ALL_PROBES.find((entry) => entry.id === feature)!
    const original = {
      term: probe.term,
      termWrites: probe.termWrites,
      termNeedsDisposable: probe.termNeedsDisposable,
      termNeedsGeometry: probe.termNeedsGeometry,
    }
    try {
      probe.termWrites = "query"
      // This recorder-only fixture replaces the mutating callback with a no-I/O coverage result.
      probe.termNeedsDisposable = undefined
      probe.termNeedsGeometry = undefined
      probe.term = async () => notTestedResult("No prompt reading", {})
      const batch = await runProbeBatch({ ids: [feature], appDeclarations: declarations })
      expect(batch.results.find((row) => row.featureId === feature)).toMatchObject({
        status: "untestable",
        reason: declarations[feature],
      })
      const parsed = parseRun(
        "declaration-roundtrip.json",
        JSON.stringify(asRun(batch)),
        [feature],
        new Map([[manifest.probeHash, manifest]]),
      )
      expect(parsed.results?.find((row) => row.featureId === feature)).toMatchObject({
        featureId: feature,
        status: "untestable",
        reason: declarations[feature],
      })
      const newer = await runProbeBatch({
        ids: [feature],
        appDeclarations: appSemanticDeclarations({ ...subject, version: version + "-new" }, bus),
      })
      expect(newer.results.find((row) => row.featureId === feature)?.status).toBe("probe-todo")
    } finally {
      Object.assign(probe, original)
    }
  },
)

// A native callback has no App identity; the collector must preserve its grade while naming the route.
it.each([
  { kind: "term", id: "alacritty", outerTerminal: null, route: "the alacritty app" },
  { kind: "mux", id: "tmux", outerTerminal: "kitty", route: "the tmux mux route with outer terminal kitty" },
  { kind: "mux", id: "screen", outerTerminal: "kitty", route: "the screen mux route with outer terminal kitty" },
] as const)("names the $id DECSACE no-setup route without assigning a stop point", async (subject) => {
  const probe = ALL_PROBES.find((entry) => entry.id === "editing.decsace")!
  const original = {
    term: probe.term,
    termWrites: probe.termWrites,
    termNeedsDisposable: probe.termNeedsDisposable,
    termNeedsGeometry: probe.termNeedsGeometry,
  }
  try {
    probe.termWrites = "query"
    probe.termNeedsDisposable = undefined
    probe.termNeedsGeometry = undefined
    probe.term = async () =>
      declaredUntestableResult("Untestable (no setup): DECCARA produces no change on this app", { controlled: true })
    const batch = await runProbeBatch({ ids: [probe.id], subject: { ...subject, os: "linux" } })
    const row = batch.results.find((entry) => entry.featureId === probe.id)!
    expect(row.status, JSON.stringify(row)).toBe("untestable")
    expect(row.reason).toContain(subject.route)
    expect(row.tests[0]?.reason).toBe(row.reason)
    if (subject.kind === "mux") expect(row.reason).toContain("either may stop DECCARA")
  } finally {
    Object.assign(probe, original)
  }
})

// @failure An unreadable socket or a present address is mistaken for a missing current-run bus.
it.each(["address present", "socket present", "socket unreadable", "both absent", "not a directory"] as const)(
  "selects Ghostty no-setup only from current-run absence: %s",
  (state) => {
    const stat = vi.mocked(nodeFs.statSync)
    const originalStat = stat.getMockImplementation()!
    stat.mockImplementation(() => {
      if (state === "socket present" || state === "address present") return {} as ReturnType<typeof nodeFs.statSync>
      throw Object.assign(new Error("Fixture stat outcome"), {
        code: state === "socket unreadable" ? "EACCES" : state === "not a directory" ? "ENOTDIR" : "ENOENT",
      })
    })
    try {
      const record = readSessionBus({
        XDG_RUNTIME_DIR: "/fixture/runtime",
        ...(state === "address present" ? { DBUS_SESSION_BUS_ADDRESS: "secret-address-never-retained" } : {}),
      })
      expect(stat).toHaveBeenCalledWith("/fixture/runtime/bus")
      expect(record.socket).toMatchObject({
        path: "/fixture/runtime/bus",
        outcome:
          state === "socket unreadable"
            ? "error"
            : state === "both absent" || state === "not a directory"
              ? "absent"
              : "present",
      })
      expect(JSON.stringify(record)).not.toContain("secret-address-never-retained")
      const selected = appSemanticDeclarations({ kind: "term", id: "ghostty", version: "1.4.0", os: "linux" }, record)
      const absent = state === "both absent" || state === "not a directory"
      expect(Object.keys(selected)).toHaveLength(absent ? 22 : 18)
      if (absent) expect(selected["extensions.osc133-d"]).toContain("This run has no DBUS_SESSION_BUS_ADDRESS")
      else expect(selected["extensions.osc133-d"]).toBeUndefined()
      if (state === "socket unreadable") expect(record.socket.code).toBe("EACCES")
      stat.mockClear()
      readSessionBus({})
      expect(stat).toHaveBeenCalledWith(`/run/user/${process.getuid!()}/bus`)
    } finally {
      stat.mockImplementation(originalStat)
      stat.mockClear()
    }
  },
)

// @failure A declaration overwrites a decided observation or hides invalid callback evidence.
it.each(["supported", "unsupported", "probe-invalid"] as const)(
  "preserves %s ahead of an App declaration",
  async (status) => {
    const id = "extensions.osc133-a",
      probe = ALL_PROBES.find((entry) => entry.id === id)!
    const original = { term: probe.term, termWrites: probe.termWrites }
    try {
      probe.termWrites = "query"
      probe.term = async () =>
        status === "probe-invalid"
          ? { pass: false, tests: [{ id: "criterion", status, reason: "Broken fixture read" }] }
          : {
              pass: status === "supported",
              observation: { outcome: status, assertionType: "query_reply", note: "Own-command fixture reply" },
            }
      const batch = await runProbeBatch({
        ids: [id],
        appDeclarations: { [id]: "Untestable (no way): must not replace evidence" },
      })
      expect(batch.results.find((row) => row.featureId === id)?.status).toBe(status)
    } finally {
      Object.assign(probe, original)
    }
  },
)

// Real query recording supplies nondefault timeout and bytes; the fixture supplies only callback intent.
it.each([false, true])("attaches completed TTY evidence only to marked failure rows (marked: %s)", async (marked) => {
  const probe = ALL_PROBES.find((entry) => entry.id === "device.primary-da")!
  const original = probe.term
  try {
    probe.term = async (ctx) => {
      await ctx.queryOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 37)
      return marked
        ? replyFailure("No probe reply")
        : { pass: false, tests: [{ id: "criterion", status: "probe-invalid", reason: "No probe reply" }] }
    }
    const batch = await runProbeBatch({
      ids: [probe.id],
      out: {
        write() {
          return true
        },
      } as unknown as NodeJS.WriteStream,
    })
    const result = batch.results.find((entry) => entry.featureId === probe.id)!
    expect(result.status).toBe("probe-invalid")
    expect(result.reason).toBe(
      marked ? 'No probe reply; query 1: sent "\\u001b[6n"; received ""; timeout 37 ms' : "No probe reply",
    )
    expect(JSON.parse(batch.rawReplies[probe.id + ".trace"]!)).toMatchObject({
      queries: [{ sequence: "\x1b[6n", timeoutMs: 37, reason: "timeout", raw: "" }],
    })
    expect(JSON.stringify(batch)).not.toContain("replyFailureTestIds")
  } finally {
    probe.term = original
  }
})

const darwinGeometrySource = "stty size on a /dev/fd reopen of the verified output device" as const
const noGeometry = {
  status: "unavailable" as const,
  at: "2026-09-28T00:00:00.000Z",
  source: linuxGeometrySource,
  diagnostic: "No owned size read in fixture",
  stdout: "",
  stderr: "",
}

const probeHash = "f".repeat(12)
/** New canonical recorder artifacts coexist with byte-identical legacy reply values. */
function legacyReplies(replies: Record<string, string>): Record<string, string> {
  return Object.fromEntries(
    Object.entries(replies).filter(([key, bytes]) => {
      if (!key.endsWith(".callLog")) return true
      expect(JSON.stringify(readCallLog(JSON.parse(bytes)))).toBe(bytes)
      return false
    }),
  )
}
// A callback that never returns must still have an actual attempt in the retained checkpoint.
it("checkpoints the native attempt before invoking its callback", async () => {
  const probe = ALL_PROBES.find((entry) => entry.id === "device.decrpm")!
  const original = probe.term
  let active: unknown
  let seen: unknown
  try {
    probe.term = async () => {
      seen = active
      return {
        pass: false,
        tests: [{ id: "criterion", status: "probe-todo", reason: "Fixture callback completed" }],
      }
    }
    await runProbeBatch({
      ids: [probe.id],
      onCheckpoint: (batch) => {
        active = structuredClone(batch.results.find((result) => result.featureId === probe.id))
      },
    })
  } finally {
    probe.term = original
  }
  expect(seen).toMatchObject({
    featureId: probe.id,
    status: "probe-todo",
    attempt: { scope: "probe", startedAt: expect.any(String) },
  })
})
const sourceRevision = "e".repeat(40)
const manifest: ProbeSuiteManifest & { schemaVersion: 4 } = {
  catalogIds: ALL_PROBES.map((probe) => probe.id),
  schemaVersion: 4 as const,
  probeHash,
  sourceRevision,
  generatedAt: "2026-09-28T00:00:00.000Z",
  adapterVersion: "test",
  probes: { term: ALL_PROBES.filter((probe) => probe.term).map((probe) => probe.id), lib: [], mux: [] },
}
// Transport fixtures retain the current collector's actual result and evidence records.
function asRun(batch: Awaited<ReturnType<typeof runProbeBatch>>, ownManifest = manifest) {
  const draft = initializeRunDraft({
    runId: "a".repeat(32),
    sourceRevision,
    manifest: ownManifest,
    source: { kind: "live" },
    intendedSubject: { kind: "term", id: "kitty" },
  })
  draft.subject = {
    kind: "term",
    id: "kitty",
    version: "0.49.1",
    os: "linux",
    osVersion: null,
    outerTerminal: null,
    mux: null,
    config: null,
    permissions: null,
  }
  draft.identity = "unverified"
  draft.measuredAt = "2026-09-28T00:00:00.000Z"
  draft.origin = { kind: "collector" }
  draft.rawReplies = batch.rawReplies
  draft.assertions = batch.assertions
  draft.screenshotRefs = batch.screenshotRefs
  draft.textSnapshotRefs = batch.textSnapshotRefs
  draft.results = draft.results.map(
    (result) => batch.results.find((entry) => entry.featureId === result.featureId) ?? result,
  )
  return draft
}

// @failure Write-only owned App state produces a real assertion with no rawReplyRef and the daemon reader rejects the run.
// Grader unit cases and query-backed native cases never cross this write-only recorder/parser boundary.
// @level l1
// @consumer Registered App semantic callback -> native recorder -> strict daemon capture reader.
it.each([
  { id: "extensions.osc133-a", positive: true, report: false },
  { id: "extensions.osc8", positive: true, report: false },
  { id: "extensions.osc-633-vscode", positive: false, report: false },
  { id: "extensions.osc633-a", positive: false, report: true },
])("binds write-only App state assertions through the strict reader: $id", async ({ id, positive, report }) => {
  verifiedBatchFixture()
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const cycle = id === "extensions.osc-633-vscode"
  const osc8 = id === "extensions.osc8"
  const empty = cycle ? JSON.stringify(["NONE", "NONE", "NONE"]) : osc8 ? "linked after " : "NONE"
  const handled = cycle
    ? JSON.stringify(["START_PROMPT@0", "START_OUTPUT@0", "END_OUTPUT@0:0;status=0"])
    : osc8
      ? "\x1b]8;;https://control.invalid/osc8\x1b\\linked\x1b]8;;\x1b\\ after "
      : "START_OUTPUT@0"
  const expected = cycle
    ? JSON.stringify(["START_PROMPT@0", "START_OUTPUT@0", "END_OUTPUT@0:17;status=17"])
    : osc8
      ? "\x1b]8;id=ex-link-1;https://terminfo.dev/osc8\x1b\\linked\x1b]8;;\x1b\\ after "
      : "START_PROMPT@0"
  const reading: AppSemanticReading = report
    ? {
        status: "measured",
        reader: "report",
        runId: "a".repeat(32),
        unknown: { code: "7654", reports: ["7654"] },
        handled: { applied: true, reports: [] },
        target: { code: "633", reports: ["633"] },
        detail: {},
      }
    : {
        status: "measured",
        reader: "state",
        runId: "a".repeat(32),
        unknown: { before: empty, after: empty },
        handled: { before: empty, after: handled, expected: handled },
        target: { before: empty, after: positive ? expected : empty, expected },
        detail: {},
      }
  const read = vi.fn(async (featureId: string, write: (text: string) => void) => {
    expect(featureId).toBe(id)
    if (report) {
      write("\x1b]7654;fixture\x07")
      write("\x1b]2;fixture\x07")
      write("\x1b]633;A\x07")
    } else if (osc8) {
      write("\x1b]888;id=ex-link-1;https://terminfo.dev/osc8\x07linked\x1b]888;;\x07 after ")
      write("\x1b]8;;https://control.invalid/osc8\x07linked\x1b]8;;\x07 after ")
      write("\x1b]8;id=ex-link-1;https://terminfo.dev/osc8\x07linked\x1b]8;;\x07 after ")
    } else {
      write("\x1b]133;Z\x07")
      write(cycle ? "\x1b]133;A\x07\x1b]133;C\x07\x1b]133;D;0\x07" : "\x1b]133;C\x07")
      write(cycle ? "\x1b]633;A\x07\x1b]633;C\x07\x1b]633;D;17\x07" : "\x1b]133;A\x07")
    }
    return reading
  })
  const batch = await runProbeBatch({
    ids: [id],
    ownedTerminal: { ...geometryOwner(osc8 ? measured(24, 80) : noGeometry), readAppSemanticState: read },
  })
  expect(read).toHaveBeenCalledOnce()
  expect(writes).toHaveLength(3)
  const raw = batch.rawReplies[id]
  if (raw === undefined) throw new Error(`Missing recorded trace for ${id}`)
  expect(JSON.parse(raw)).toHaveProperty("queries", [])
  const expectedStatus = positive ? "supported" : "unsupported"
  expect(batch.results.find((row) => row.featureId === id)?.status).toBe(expectedStatus)
  const decoded = decodeCollectorDraft(
    "owned-app-state.json",
    JSON.stringify(asRun(batch)),
    manifest,
    sourceRevision,
  ).run
  expect(decoded.results.find((row) => row.featureId === id)?.status).toBe(expectedStatus)
  expect(decoded.assertions).toContainEqual(
    expect.objectContaining({ featureId: id, kind: positive ? "positive" : "negative", rawReplyRef: id }),
  )
})

// Callback-returned responses survive current transport without becoming measured evidence.
it.each([
  { label: "sentinel", response: "nonsecret-callback-response" },
  { label: "empty", response: "" },
  { label: "absent", response: undefined },
])(
  "retains the $label explicit callback response and refuses an untyped legacy-shaped result",
  async ({ response }) => {
    const id = "device.decrpm"
    const definition = ALL_PROBES.find((probe) => probe.id === id)!
    expect(definition.termWrites).toBe("query")
    expect(definition.termNeedsGeometry).toBeUndefined()
    const original = definition.term
    const responseFields = response === undefined ? {} : { response }
    const note = "Deterministic callback response retention fixture"
    const trace = JSON.stringify({ writes: [], queries: [], events: [] })
    // The collector records its own disposable-ownership verdict beside the replies.
    const sharedOwnership = { "collector.disposableOwnership": JSON.stringify({ kind: "shared" }) }
    try {
      definition.term = async () => ({
        pass: false,
        ...responseFields,
        tests: [{ id: "criterion", status: "probe-todo", reason: note }],
      })
      const explicit = await runProbeBatch({ ids: [id] })
      definition.term = (async () => ({ pass: false, ...responseFields, note })) as unknown as typeof definition.term
      const legacy = await runProbeBatch({ ids: [id] })
      const decodedExplicit = decodeCollectorDraft(
        "explicit-callback-response.json",
        JSON.stringify(asRun(explicit)),
        manifest,
        sourceRevision,
      ).run
      const decodedLegacy = decodeCollectorDraft(
        "legacy-callback-response.json",
        JSON.stringify(asRun(legacy)),
        manifest,
        sourceRevision,
      ).run
      expect(explicit.observations).toEqual([])
      expect(decodedExplicit.results).toEqual(explicit.results)
      expect(explicit.ungradedDiagnostics).toEqual({})
      expect(decodedExplicit.results.find((result) => result.featureId === id)?.status).toBe("probe-todo")
      expect(explicit.assertions).toEqual([])
      expect(decodedExplicit.assertions).toEqual([])
      expect(explicit.screenshotRefs).toEqual([])
      expect(decodedExplicit.screenshotRefs).toEqual([])
      expect(explicit.suiteComplete).toBe(false)
      expect(decodedExplicit.results.some((result) => result.status === "probe-todo")).toBe(true)
      expect(decodedExplicit.identity).toBe("unverified")
      expect(explicit.rawReplies[id]).toBe(trace)
      expect(decodedExplicit.rawReplies[id]).toBe(trace)

      // The one-path refactor deleted the legacy-callback record. A result that is neither a
      // measurement nor a coverage record is refused loudly instead of silently ungraded.
      const refusal = {
        kind: "collector-error",
        name: "Error",
        message: `Callback for ${id} returned neither an observation nor a not-tested coverage record; its conclusion cannot be graded`,
      }
      expect(legacy.observations).toEqual([])
      expect(decodedLegacy.results).toEqual(legacy.results)
      expect(legacy.ungradedDiagnostics).toEqual({ [id]: refusal })
      expect(decodedLegacy.results.find((result) => result.featureId === id)).toMatchObject({
        status: "probe-invalid",
        reason: refusal.message,
      })
      expect(legacyReplies(legacy.rawReplies)).toEqual({ [id]: trace, ...sharedOwnership })
      expect(legacyReplies(decodedLegacy.rawReplies)).toEqual({ [id]: trace, ...sharedOwnership })
      expect(legacy.assertions).toEqual([])
      expect(decodedLegacy.assertions).toEqual([])
      expect(legacy.screenshotRefs).toEqual([])
      expect(decodedLegacy.screenshotRefs).toEqual([])
      expect(legacy.suiteComplete).toBe(false)
      expect(decodedLegacy.results.some((result) => result.status === "probe-invalid")).toBe(true)
      expect(decodedLegacy.identity).toBe("unverified")

      const expectedReplies = {
        [id]: trace,
        ...sharedOwnership,
        ...(response === undefined ? {} : { [`${id}.callbackResponse`]: response }),
      }
      expect(legacyReplies(explicit.rawReplies)).toEqual(expectedReplies)
      expect(legacyReplies(decodedExplicit.rawReplies)).toEqual(expectedReplies)
    } finally {
      definition.term = original
    }
  },
)

// A result-level note beside an explicit observation must reach the run document, and an
// observation's own note is never replaced by it; the legacy control keeps the result note.
it.each([
  {
    label: "result-note-beside-observation",
    resultNote: "Deterministic result-level note retention fixture",
    observationNote: undefined,
  },
  {
    label: "observation-own-note",
    resultNote: undefined,
    observationNote: "Deterministic observation-level note fixture",
  },
  {
    label: "both-notes",
    resultNote: "Deterministic legacy label",
    observationNote: "Deterministic observation-level note fixture",
  },
])(
  "retains the ProbeCallbackResult note for the $label case and refuses an untyped legacy-shaped result",
  async ({ resultNote, observationNote }) => {
    const id = "device.decrpm"
    const definition = ALL_PROBES.find((probe) => probe.id === id)!
    expect(definition.termWrites).toBe("query")
    expect(definition.termNeedsGeometry).toBeUndefined()
    const original = definition.term
    const resultNoteFields = resultNote === undefined ? {} : { note: resultNote }
    const expectedNote = observationNote ?? resultNote
    const trace = JSON.stringify({ writes: [], queries: [], events: [] })
    // The collector records its own disposable-ownership verdict beside the replies.
    const sharedOwnership = { "collector.disposableOwnership": JSON.stringify({ kind: "shared" }) }
    try {
      definition.term = async () => ({
        pass: false,
        ...resultNoteFields,
        tests: [{ id: "criterion", status: "probe-todo", reason: expectedNote! }],
      })
      const explicit = await runProbeBatch({ ids: [id] })
      definition.term = (async () => ({ pass: false, ...resultNoteFields })) as unknown as typeof definition.term
      const legacy = await runProbeBatch({ ids: [id] })
      const decodedExplicit = decodeCollectorDraft(
        "explicit-callback-note.json",
        JSON.stringify(asRun(explicit)),
        manifest,
        sourceRevision,
      ).run
      const decodedLegacy = decodeCollectorDraft(
        "legacy-callback-note.json",
        JSON.stringify(asRun(legacy)),
        manifest,
        sourceRevision,
      ).run
      expect(explicit.observations).toEqual([])
      expect(decodedExplicit.results).toEqual(explicit.results)
      expect(explicit.ungradedDiagnostics).toEqual({})
      expect(decodedExplicit.results.find((result) => result.featureId === id)?.status).toBe("probe-todo")
      expect(explicit.assertions).toEqual([])
      expect(decodedExplicit.assertions).toEqual([])
      expect(legacyReplies(explicit.rawReplies)).toEqual({ [id]: trace, ...sharedOwnership })
      expect(legacyReplies(decodedExplicit.rawReplies)).toEqual({ [id]: trace, ...sharedOwnership })
      expect(explicit.suiteComplete).toBe(false)
      expect(decodedExplicit.results.some((result) => result.status === "probe-todo")).toBe(true)
      expect(decodedExplicit.identity).toBe("unverified")

      // The one-path refactor deleted the legacy-callback record; the untyped refusal replaces it.
      const refusal = {
        kind: "collector-error",
        name: "Error",
        message: `Callback for ${id} returned neither an observation nor a not-tested coverage record; its conclusion cannot be graded`,
      }
      expect(legacy.observations).toEqual([])
      expect(decodedLegacy.results).toEqual(legacy.results)
      expect(legacy.ungradedDiagnostics).toEqual({ [id]: refusal })
      expect(decodedLegacy.results.find((result) => result.featureId === id)).toMatchObject({
        status: "probe-invalid",
        reason: refusal.message,
      })
      expect(legacyReplies(legacy.rawReplies)).toEqual({ [id]: trace, ...sharedOwnership })
      expect(legacyReplies(decodedLegacy.rawReplies)).toEqual({ [id]: trace, ...sharedOwnership })
      expect(legacy.assertions).toEqual([])
      expect(decodedLegacy.assertions).toEqual([])
      expect(decodedLegacy.results.some((result) => result.status === "probe-invalid")).toBe(true)
      expect(decodedLegacy.identity).toBe("unverified")
    } finally {
      definition.term = original
    }
  },
)

// An unowned inline batch must refuse before a callback can send RIS or paint the user's TTY.
it("refuses an unowned mutating callback without sending terminal bytes", async () => {
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({ ids: ["reset.ris"], captureRunId: "a".repeat(32) })
  expect(writes).toEqual([])
  expect(batch.observations).toEqual([])
  expect(batch.results.find((result) => result.featureId === "reset.ris")).toMatchObject({
    status: "probe-todo",
    attempt: { scope: "none" },
  })
  expect(JSON.parse(batch.rawReplies["reset.ris"]!)).toEqual({ writes: [], queries: [], events: [] })
})

it("records an owned default-profile OSC 52 refusal as unmeasured with an empty bound trace", async () => {
  verifiedBatchFixture()
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({ ids: ["extensions.osc52-write"], captureRunId: "a".repeat(32) })
  expect(writes).toEqual([])
  expect(batch.results.filter((result) => ["extensions.osc52-write"].includes(result.featureId))).toMatchObject([
    { status: "probe-todo", featureId: "extensions.osc52-write", rawReplyRef: "extensions.osc52-write" },
  ])
  expect(batch.assertions).toEqual([])
  expect(JSON.parse(batch.rawReplies["extensions.osc52-write"]!)).toEqual({ writes: [], queries: [], events: [] })
})

// A caller cannot manufacture ownership by satisfying the owner's public TypeScript shape.
it("refuses a structural terminal owner even with the same claimed capture ID", async () => {
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["reset.ris"],
    captureRunId: "a".repeat(32),
    ownedTerminal: geometryOwner(noGeometry),
  })
  expect(writes).toEqual([])
  expect(batch.results.filter((result) => ["reset.ris"].includes(result.featureId))).toMatchObject([
    { status: "probe-todo", featureId: "reset.ris" },
  ])
})

it("allows query-only DECRPM and refuses callbacks requiring disposable ownership", async () => {
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    if (text === "\x1b[?7$p\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?7;2$y"))
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["device.decrpm", "modes.color-scheme-reporting", "cursor.move.absolute", "device.xtwinops-20"],
  })
  expect(writes).toEqual(["\x1b[?7$p\x1b[c"])
  const retained = batch.rawReplies["device.decrpm.callLog"]
  expect(retained).toBeDefined()
  expect(JSON.stringify(readCallLog(JSON.parse(retained!)))).toBe(retained)
  expect(batch.observations.find((item) => item.featureId === "device.decrpm")).toMatchObject({
    outcome: "supported",
    assertionType: "query_reply",
  })
  for (const id of ["modes.color-scheme-reporting", "cursor.move.absolute", "device.xtwinops-20"]) {
    expect(batch.results.find((item) => item.featureId === id)).toMatchObject({ status: "probe-todo" })
    expect(JSON.parse(batch.rawReplies[id]!)).toMatchObject({ writes: [], queries: [], events: [] })
  }
})

// A real Terminal.app run returned DA1 as the XTVERSION query's sentinel; it was not an XTVERSION reply.
// F1 (27832): that sentinel answered alone through the grace window is now a measured negative, not an
// unknown — the terminal was alive and did not answer the query.
it("projects Terminal.app identity replies without mistaking the DA1 sentinel for XTVERSION", async () => {
  const da1 = "\x1b[?1;2c"
  const da2 = "\x1b[>1;95;0c"
  const sent: string[] = []
  process.stdout.write = ((sequence: string) => {
    sent.push(sequence)
    if (sequence === "\x1b[c") process.stdin.emit("data", Buffer.from(da1))
    if (sequence === "\x1b[>c\x1b[c") process.stdin.emit("data", Buffer.from(da2 + da1))
    if (sequence === "\x1b[>0q\x1b[c") process.stdin.emit("data", Buffer.from(da1))
    return true
  }) as typeof process.stdout.write

  const batch = await runProbeBatch({ ids: ["device.primary-da", "device.secondary-da", "device.xtversion"] })
  expect(sent).toEqual(["\x1b[c", "\x1b[>c\x1b[c", "\x1b[>0q\x1b[c"])
  expect(batch.observations).toMatchObject([
    { featureId: "device.primary-da", outcome: "supported" },
    { featureId: "device.secondary-da", outcome: "supported" },
    // #33165: the sentinel helper marks a fenced silence inconclusive and decides nothing; the recorder grades it
    // once from the row's silence rule, and the default rule is Unsupported (asserted on the result row below).
    {
      featureId: "device.xtversion",
      outcome: "inconclusive",
      assertionType: "query_reply",
      note: expect.stringMatching(/^DA1 answered at \+\d+ms; no reply through the \d+ ms window$/),
    },
  ])
  expect(batch.results.find((result) => result.featureId === "device.xtversion")?.status).toBe("unsupported")
  expect(batch.assertions).toContainEqual({
    featureId: "device.xtversion",
    kind: "negative",
    assertionType: "query_reply",
    expected: "complete XTVERSION DCS >| printable name/version ST",
    observed: expect.stringMatching(/DA1 answered at \+\d+ms; no reply through the \d+ ms window/),
    rawReplyRef: "device.xtversion",
  })
  expect(verifyTerminalIdentity("terminal-app", batch.rawReplies)).toMatchObject({ ok: true, checked: true })
  expect(batch.rawReplies["device.secondary-da"]).toBe(da2 + da1)
  expect(JSON.parse(batch.rawReplies["device.secondary-da.trace"]!)).toMatchObject({
    queries: [{ reason: "reply", raw: da2 + da1 }],
  })
  expect(batch.rawReplies["device.xtversion"]).toBe(da1)
  expect(JSON.parse(batch.rawReplies["device.xtversion.trace"]!)).toMatchObject({
    queries: [{ reason: "sentinel", match: null, raw: da1 }],
  })
})

const originalWrite = process.stdout.write

// The shared registry now resolves IDs; native diagnostics remain the existing CLI contract.
it.each([
  { ids: ["not-a-probe"], message: "Unknown or inapplicable app probe not-a-probe" },
  { ids: ["sgr.bold", "sgr.bold"], message: "Duplicate probe ID in app batch" },
])("keeps native selection diagnostic bytes: $message", async ({ ids, message }) => {
  await expect(runProbeBatch({ ids })).rejects.toThrow(new Error(message))
})

afterEach(() => {
  vi.restoreAllMocks()
  process.stdout.write = originalWrite
  process.stdin.removeAllListeners("data")
  for (const path of receiptDirectories.splice(0)) rmSync(path, { recursive: true, force: true })
  if (originalDisposableReceipt === undefined) delete process.env.TERMINFO_DISPOSABLE_RECEIPT
  else process.env.TERMINFO_DISPOSABLE_RECEIPT = originalDisposableReceipt
})

// These callback/capture contract tests exercise the post-authorization batch path;
// unmocked tests above independently prove a forged adapter cannot authorize it.
function verifiedBatchFixture() {
  vi.spyOn(terminalOwnership, "ownedTerminalVerifiedFor").mockReturnValue(true)
}

// @failure The native focus recorder loses an enable-time report before it attaches stdin.
// The mode-only fixtures emit during focusRoundTrip, after the listener is already attached.
// @level l1
// @consumer App native batch -> focus tracking callback -> retained TTY query bytes.
it("retains the focus report emitted while enabling 1004", async () => {
  verifiedBatchFixture()
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const receiptPath = join(directory, "host-measured.json")
  writeFileSync(receiptPath, JSON.stringify(validContainerReceipt()))
  process.env.TERMINFO_DISPOSABLE_RECEIPT = receiptPath
  let enabled = false
  process.stdout.write = ((chunk: string | Uint8Array) => {
    const text = typeof chunk === "string" ? chunk : Buffer.from(chunk).toString("utf8")
    if (text === "\x1b[?1004$p\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?1004;2$y"))
    if (text === "\x1b[?1004h") {
      enabled = true
      process.stdin.emit("data", Buffer.from("\x1b[I"))
    }
    if (text === "\x1b[?1004l") enabled = false
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["modes.focus-tracking"],
    subject: { kind: "term", id: "kitty", os: "linux" },
    ownedTerminal: geometryOwner(noGeometry),
    input: {
      injectClick: async () => {},
      injectKey: async () => {
        process.stdin.emit("data", Buffer.from("a"))
      },
      focusRoundTrip: async () => {
        if (enabled) process.stdin.emit("data", Buffer.from("\x1b[O\x1b[I"))
        return {
          ownedWindowId: "42",
          helperWindowId: "543",
          focusedWindowIds: ["42", "543", "42"] as [string, string, string],
        }
      },
    },
  })
  expect(batch.ungradedDiagnostics).toEqual({})
  const trace = JSON.parse(batch.rawReplies["modes.focus-tracking"]!) as { queries: Array<{ raw: string }> }
  expect(trace.queries.slice(1).map((query) => query.raw)).toEqual(["\x1b[Ia", "\x1b[O\x1b[Ia", "a"])
  expect(batch.results.find((row) => row.featureId === "modes.focus-tracking")?.status).toBe("supported")
  expect(JSON.parse(batch.assertions[0]!.observed)).toMatchObject({
    enableTimeReport: "\x1b[I",
    roundTrip: "\x1b[O\x1b[I",
    focus: {
      enabled: { ownedWindowId: "42", helperWindowId: "543", focusedWindowIds: ["42", "543", "42"] },
      reset: { ownedWindowId: "42", helperWindowId: "543", focusedWindowIds: ["42", "543", "42"] },
    },
  })
})

// @failure A Linux-owned motion fixture is dropped before the OSC22 callback can place its pointer.
// The focus case exercises another optional method, so it cannot detect missing motion forwarding.
// @level l1
// @consumer App native batch -> OSC22 pointer-image callback -> owned XTEST input.
it("forwards owned buttonless motion with its fixture binding", async () => {
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const definition = ALL_PROBES.find((probe) => probe.id === "device.primary-da")!
  const original = definition.term
  const moves: number[][] = []
  const input = {
    injectClick: async () => {},
    injectKey: async () => {},
    async injectMove(x: number, y: number) {
      expect(this).toBe(input)
      moves.push([x, y])
    },
  }
  try {
    definition.term = async (ctx) => {
      if (!ctx.input?.injectMove) throw new Error("Missing owned motion fixture")
      await ctx.input.injectMove(32, 48)
      return notTestedResult("Motion forwarding exercised", {})
    }
    await runProbeBatch({
      ids: [definition.id],
      ownedTerminal: geometryOwner(noGeometry),
      input,
    })
    expect(moves).toEqual([[32, 48]])
  } finally {
    definition.term = original
  }
})

// @failure A probe-scoped window resize loses its declaring featureId or receiver binding when wrapped per probe.
// @level l1
// @consumer App native batch -> resizeWindow probe callback -> Linux collector declared-resize guard (#32791).
it("forwards owned resizeWindow with the declaring probe id and fixture binding", async () => {
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const definition = ALL_PROBES.find((probe) => probe.id === "device.primary-da")!
  const original = definition.term
  const resizes: Array<[number, number, string | undefined]> = []
  const input = {
    injectClick: async () => {},
    injectKey: async () => {},
    async resizeWindow(width: number, height: number, featureId?: string) {
      expect(this).toBe(input)
      resizes.push([width, height, featureId])
      return { width: 800, height: 600 }
    },
  }
  try {
    definition.term = async (ctx) => {
      if (!ctx.input?.resizeWindow) throw new Error("Missing owned resize fixture")
      expect(await ctx.input.resizeWindow(520, 600)).toEqual({ width: 800, height: 600 })
      return notTestedResult("Resize forwarding exercised", {})
    }
    await runProbeBatch({
      ids: [definition.id],
      ownedTerminal: geometryOwner(noGeometry),
      input,
    })
    expect(resizes).toEqual([[520, 600, definition.id]])
  } finally {
    definition.term = original
  }
})

it.each(
  ["extensions.osc2-title", "device.xtwinops-22", "device.xtwinops-23"].flatMap((id) =>
    ["controls", "query"].map((failure) => ({ id, failure })),
  ),
)("names Screen's missing own-title reader after $failure fails: $id", async ({ id, failure }) => {
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: [id],
    subject: { kind: "mux", id: "screen", os: "linux" },
    ownedTerminal: {
      ...geometryOwner(noGeometry),
      readTitle: async () => {
        if (failure === "query") throw new Error("screen -Q title is unavailable")
        return "unchanged Screen title"
      },
    },
  })
  const row = batch.results.find((result) => result.featureId === id)!
  expect(row.status).toBe("probe-todo")
  expect(row.reason).toMatch(/Screen.*screen -Q title/)
  expect(batch.assertions).toEqual([])
  const reads = (JSON.parse(batch.rawReplies[id]!) as { titleReads: unknown[] }).titleReads
  if (failure === "query") expect(reads).toEqual([{ error: "screen -Q title is unavailable" }])
  else expect(reads.length).toBeGreaterThan(1)
})

// #33375: the OSC 7 title reader installs from the owned run, never from a subject name. The first assertion
// is the installation itself: an App that used to fall through now reads its own title. Only Ghostty, whose
// deciding negative is established, reads Unsupported when the title carries no path.
it.each([
  { subject: { kind: "term", id: "alacritty", os: "linux" }, expected: "probe-todo" },
  { subject: { kind: "term", id: "kitty", os: "linux" }, expected: "probe-todo" },
  { subject: { kind: "term", id: "wezterm", os: "linux" }, expected: "probe-todo" },
  { subject: { kind: "term", id: "ghostty", os: "linux" }, expected: "unsupported" },
] as const)("installs the OSC 7 title reader on $subject.id without a name gate", async ({ subject, expected }) => {
  verifiedBatchFixture()
  let title = "incoming App title"
  process.stdout.write = ((bytes: string) => {
    const match = /^\x1b\]2;([^\x07]*)\x07$/.exec(bytes)
    if (match) title = match[1]!
    return true
  }) as typeof process.stdout.write
  const id = "extensions.osc7-cwd"
  const batch = await runProbeBatch({
    ids: [id],
    subject,
    ownedTerminal: { ...geometryOwner(noGeometry), readTitle: async () => title },
  })
  const row = batch.results.find((result) => result.featureId === id)!
  const trace = JSON.parse(batch.rawReplies[id]!) as { titleReads: unknown[] }
  expect(trace.titleReads.length).toBeGreaterThan(1)
  expect({ status: row.status, reason: row.reason }).toMatchObject(
    expected === "probe-todo"
      ? { status: "probe-todo", reason: expect.stringMatching(/carried neither OSC 7 path/) }
      : { status: "unsupported" },
  )
})

// #32573: direct callback cases cannot detect a collector that drops or exposes a foreign title reader.
it.each([false, true])("binds the title reader and its raw readings only to the owned run: %s", async (owned) => {
  vi.spyOn(terminalOwnership, "ownedTerminalVerifiedFor").mockReturnValue(owned)
  let title = "incoming App title"
  const readTitle = vi.fn(async () => title)
  process.stdout.write = ((bytes: string) => {
    const match = /^\x1b\]2;([^\x07]*)\x07$/.exec(bytes)
    if (match) title = match[1]!
    return true
  }) as typeof process.stdout.write
  const id = "extensions.osc2-title"
  const batch = await runProbeBatch({
    ids: [id],
    ownedTerminal: { ...geometryOwner(noGeometry), readTitle },
  })
  expect(batch.results.find((row) => row.featureId === id)?.status).toBe(owned ? "supported" : "probe-todo")
  expect(title).toBe("incoming App title")
  const trace = JSON.parse(batch.rawReplies[id]!) as { titleReads: unknown[] }
  if (owned) {
    expect(readTitle).toHaveBeenCalledTimes(7)
    expect(trace.titleReads).toHaveLength(7)
    expect(trace.titleReads[0]).toEqual({ title: "incoming App title" })
    expect(trace.titleReads.at(-1)).toEqual({ title: "incoming App title" })
  } else {
    expect(readTitle).not.toHaveBeenCalled()
    expect(trace.titleReads).toBeUndefined()
  }
})

// A DECRQSS style result is not a visual observation (#30590). The unrelated screenshot
// assertion exercises the same-run feature binding, not just global screenshot presence.
it.each([
  { id: "sgr.bold", outcome: "supported", evidence: "captured", kind: "term", expected: "supported" },
  { id: "sgr.bold", outcome: "unsupported", evidence: "captured", kind: "mux", expected: "unsupported" },
  { id: "sgr.bold", outcome: "supported", evidence: "assertion", kind: "term", expected: "probe-todo" },
  { id: "sgr.bold", outcome: "supported", evidence: "foreign-captured", kind: "term", expected: "probe-todo" },
  { id: "sgr.fg.truecolor", outcome: "unsupported", evidence: "none", kind: "mux", expected: "probe-todo" },
  { id: "sgr.bold", outcome: "supported", evidence: "none", kind: "lib", expected: "supported" },
] as const)("records $id/$outcome with $evidence visual evidence as $expected", async (testCase) => {
  const { id, outcome, evidence, expected, kind } = testCase
  verifiedBatchFixture()
  const definitions = ["device.primary-da", id].map((featureId) => ALL_PROBES.find((probe) => probe.id === featureId)!)
  const originals = definitions.map(({ term, termWrites, termNeedsGeometry }) => ({
    term,
    termWrites,
    termNeedsGeometry,
  }))
  const foreignRef = `sha256:${"b".repeat(64)}`
  try {
    for (const definition of definitions) {
      definition.termWrites = "query"
      delete definition.termNeedsGeometry
      definition.term = async (ctx) => {
        const measured = outcome === "unsupported" && definition.id === id ? "unsupported" : "supported"
        const captured =
          (definition.id === id && evidence === "captured") || (definition.id !== id && evidence === "foreign-captured")
            ? await ctx.capture!({ role: "target", label: "Measured fixture frame" })
            : undefined
        const assertionType =
          definition.id !== id || evidence === "assertion" || evidence === "captured" ? "screenshot" : "query_reply"
        return {
          pass: measured === "supported",
          response: "0;1",
          observation: {
            outcome: measured,
            assertionType,
            ...(captured ? { screenshotRef: captured.ref } : {}),
            ...(definition.id === id && evidence === "foreign-captured" ? { screenshotRef: foreignRef } : {}),
          },
          assertions: [
            {
              assertionType,
              kind: measured === "supported" ? "positive" : "negative",
              expected: "Measured callback criterion",
              observed: "0;1",
            },
          ],
        }
      }
    }
    const batch = await runProbeBatch({
      ids: definitions.map((probe) => probe.id),
      subject: {
        kind,
        id: "visual-style-fixture",
        os: "linux",
      },
      capture: async ({ role, label }) => ({
        frame: { role, label, capturedAt: Date.now(), ref: foreignRef },
        trace: {},
      }),
    })
    const row = batch.results.find((result) => result.featureId === id)!
    expect(row.status).toBe(expected)
    if (expected === "probe-todo") {
      // #33165 (@cto f2adcbf3): a status reply alone never decides a paint row and says so; a screenshot
      // assertion without this feature's own frame keeps the visual-not-observed reason.
      const statusReplyOnly = evidence === "foreign-captured" || evidence === "none"
      expect(row.reason).toBe(
        statusReplyOnly
          ? "graded from a status reply only; this row is decided by what is painted"
          : "visual effect not observed in this run",
      )
      expect(row.tests).toContainEqual(expect.objectContaining({ status: "probe-todo", reason: row.reason }))
      expect(batch.observations.find((observation) => observation.featureId === id)?.outcome).toBe(outcome)
    }
    expect(batch.results.find((result) => result.featureId === "device.primary-da")?.status).toBe("supported")
  } finally {
    definitions.forEach((definition, index) => Object.assign(definition, originals[index]))
  }
})

// @failure A completed outer-command read is dropped, the full draft subject is lost,
// or command evidence bypasses the existing same-probe screenshot requirement.
// Pixel control decisions belong to sgr-readback.test.ts; this exercises their collector handoff.
it.each([
  { forwarded: true, ownFrame: true, expected: "untestable" },
  { forwarded: false, ownFrame: true, expected: "unsupported" },
  { forwarded: true, ownFrame: false, expected: "probe-todo" },
] as const)("attributes mux pixel negatives at the existing finalise site: $forwarded/$ownFrame", async (scenario) => {
  verifiedBatchFixture()
  vi.spyOn(process.stdout, "write").mockReturnValue(true)
  const id = "sgr.underline.curly"
  const definition = ALL_PROBES.find((probe) => probe.id === id)!
  const original = {
    term: definition.term,
    termWrites: definition.termWrites,
    termNeedsGeometry: definition.termNeedsGeometry,
  }
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const capture = join(directory, "artifacts")
  mkdirSync(capture)
  const logPath = join(directory, "daemon.log")
  writeFileSync(logPath, "")
  const runId = "a".repeat(32)
  const native = readFileSync(new URL("../fixtures/kitty-mux-sgr.txt", import.meta.url), "utf8")
  const writes = JSON.parse(readFileSync(new URL("../fixtures/kitty-mux-sgr.trace.json", import.meta.url), "utf8")) as {
    calls: Array<{ args: [string] }>
  }
  const processIdentity = { pid: process.pid, startTicks: "1", ttyRdev: 1 }
  const subject = {
    kind: "mux" as const,
    id: "tmux",
    version: "3.8",
    os: "linux",
    osVersion: null,
    outerTerminal: "kitty",
    mux: "tmux",
    config: null,
    permissions: null,
  }
  const draft = initializeRunDraft({
    runId,
    sourceRevision,
    manifest,
    source: { kind: "live" },
    intendedSubject: { kind: "mux", id: "tmux" },
  })
  draft.subject = subject
  const frameRef = `sha256:${"a".repeat(64)}`
  try {
    vi.stubEnv("TERMINFO_RUN_ID", runId)
    vi.stubEnv("TERMINFO_MUX_KIND", "tmux")
    vi.stubEnv("TERMINFO_TARGET_ID", "kitty")
    vi.stubEnv("TERMINFO_TARGET_VERSION", "0.49.2")
    vi.stubEnv("TERMINFO_CAPTURE_DIRECTORY", capture)
    definition.termWrites = "query"
    delete definition.termNeedsGeometry
    definition.term = async (ctx) => {
      for (const call of writes.calls) ctx.write(call.args[0])
      appendFileSync(logPath, scenario.forwarded ? native : native.replace("select_graphic_rendition 4:3\n", ""))
      const frames = [
        await ctx.capture!({ role: "control", label: "Prequalified plain sample" }),
        await ctx.capture!({ role: "target", label: "Prequalified pixel negative" }),
      ]
      return {
        pass: false,
        criterionBranch: "sgr-attribute-same-run",
        tests: [{ id: "attribute", status: "unsupported", assertionRefs: [0] }],
        observation: {
          outcome: "unsupported",
          assertionType: "screenshot",
          frames,
          screenshotRef: scenario.ownFrame ? frameRef : `sha256:${"b".repeat(64)}`,
        },
        assertions: [
          {
            assertionType: "screenshot",
            kind: "negative",
            expected: "Same-run SGR pixel controls",
            observed: `Controlled plain and target samples: ${frameRef}`,
          },
        ],
      }
    }
    const batch = await runProbeBatch({
      ids: [id],
      draft,
      subject: { kind: "mux", id: "tmux", os: "linux" },
      ownedTerminal: {
        ...geometryOwner(measured(24, 80)),
        muxAttachmentProof: {
          platform: "linux",
          mux: "tmux",
          launchRunId: runId,
          captureRunId: runId,
          bootId: "fixture",
          receiptSha256: "a".repeat(64),
          preflightCollector: processIdentity,
          outerShell: processIdentity,
          outerTerminal: processIdentity,
          collector: processIdentity,
          attachedClient: processIdentity,
          chain: [],
          executable: { path: "/fixture/tmux", sha256: "a".repeat(64), version: "3.8" },
          config: { path: "/fixture/mux-empty.conf", sha256: "a".repeat(64) },
          socketPath: "/fixture/tmux.sock",
          session: "fixture",
        },
      },
      capture: async ({ role, label }) => ({ frame: { ref: frameRef, role, label, capturedAt: 1 }, trace: {} }),
    })
    const result = batch.results.find((row) => row.featureId === id)!
    expect(result.status).toBe(scenario.expected)
    if (scenario.expected === "untestable") expect(result.reason).toMatch(/passed.*outer terminal kitty/i)
    if (scenario.expected === "unsupported") expect(result.reason).toMatch(/tmux.*did not forward/i)
    if (scenario.expected !== "probe-todo") {
      expect(JSON.parse(batch.rawReplies[`${id}.outerCommands`]!)).toMatchObject({
        status: "measured",
        targetSent: scenario.forwarded,
        detail: { appended: scenario.forwarded ? native : native.replace("select_graphic_rendition 4:3\n", "") },
      })
      const retained = { ...asRun(batch), subject, intendedSubject: { kind: "mux", id: "tmux" } }
      const decoded = decodeCollectorDraft(
        "mux-sgr-command.json",
        JSON.stringify(retained),
        manifest,
        sourceRevision,
      ).run
      expect(decoded.results.find((row) => row.featureId === id)?.status).toBe(scenario.expected)
    }
  } finally {
    Object.assign(definition, original)
    vi.unstubAllEnvs()
  }
})

const receiptDirectories: string[] = []
const originalDisposableReceipt = process.env.TERMINFO_DISPOSABLE_RECEIPT

/** The host-authored half the collector can read: /out/host-measured.json plus the envelope. */
function hostedLaunchReceipt() {
  const sample = (seed: string) => ({
    machineIdSha256: createHash("sha256").update(`${seed}-machine`).digest("hex"),
    productUuidSha256: createHash("sha256").update(`${seed}-uuid`).digest("hex"),
    bootIdSha256: createHash("sha256").update(`${seed}-boot`).digest("hex"),
  })
  return {
    schemaVersion: 1,
    kind: "github-hosted-runner",
    runId: "c".repeat(32),
    collectedAt: "2026-10-08T22:00:00Z",
    job: {
      repository: "beorn/terminfo.dev",
      workflow: "macos-measurement.yml",
      workflowRef: "beorn/terminfo.dev/.github/workflows/macos-measurement.yml@refs/heads/main",
      githubRunId: "1",
      githubRunAttempt: "1",
      job: "measure",
      jobId: "2",
    },
    runner: {
      environment: "github-hosted",
      name: "GitHub Actions 1",
      os: "macOS",
      arch: "ARM64",
      imageOS: "macos26",
      imageVersion: "20261001.1",
      trackingId: "a".repeat(32),
    },
    vm: { identityAtJobStart: sample("job"), identityAtCollection: sample("job") },
    appLaunch: {
      bundlePath: "/Applications/iTerm.app",
      cfBundleShortVersionString: "3.6.11",
      cfBundleVersion: "3.6.11",
      executablePath: "/Applications/iTerm.app/Contents/MacOS/iTerm2",
      executableSha256: createHash("sha256").update("fixture-iterm2-executable").digest("hex"),
      sourceArtifact: {
        path: "/Library/Caches/Homebrew/downloads/iterm2--3.6.11.zip",
        sha256: createHash("sha256").update("fixture-iterm2-installer").digest("hex"),
      },
    },
  }
}

function validContainerReceipt() {
  return {
    schemaVersion: 1,
    kind: "linux-xvfb-container",
    runId: "b".repeat(32),
    collectedAt: "2026-10-06T22:00:00Z",
    runtime: {
      imageId: "sha256:3f263739c9bebf6e015166eb0aa9c62dd37baf47384391d87875158eeae0bc8d",
      imageTarSha256: "22ab7b15460795eb0c774b68f0d8c5f853d87597bacbffdd809e0fcac9130333",
      arch: "amd64",
      nixLockRevision: "f2e16882cd75b5180bf14f77740fcb8643b35c10",
      sourceRevision: "d".repeat(40),
      sourceTreeStatus: "clean",
      rootRevision: "e".repeat(40),
      suiteHash: "f".repeat(12),
    },
    runnerArtifact: {
      frozenRunnerSha256: "d0a6b28177cce4be5dc241fe53adc636cbfba8a60e9362b38e5ccf3c5074d4c6",
      buildReceiptSha256: "63648108c641030f0d0cc0ee7ba92d27cb4627dc1da5ba953f0bd632f4de2044",
    },
    declaredTarget: { kind: "app", id: "kitty", version: "0.49.2", os: "linux" },
    preset: "current",
    clipboardProfile: "default",
  }
}

// 27832 amendment 1: a mutating probe needs a verified disposable-ownership receipt, the collector
// tests it once before the first write, and the run records the kind and the digest.
it("refuses a mutating reset probe with no disposable receipt and writes nothing", async () => {
  verifiedBatchFixture()
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["extensions.osc110-reset-fg"],
    subject: { kind: "term", id: "kitty", os: "linux" },
  })
  expect(writes).toEqual([])
  expect(JSON.parse(batch.rawReplies["collector.disposableOwnership"]!)).toEqual({ kind: "shared" })
  expect(batch.results.filter((result) => ["extensions.osc110-reset-fg"].includes(result.featureId))).toMatchObject([
    { status: "probe-todo", featureId: "extensions.osc110-reset-fg" },
  ])
  expect(batch.assertions).toEqual([])
  expect(JSON.parse(batch.rawReplies["extensions.osc110-reset-fg"]!)).toEqual({ writes: [], queries: [], events: [] })
})

it("a declared receipt that cannot be verified is loud before any byte, never a silent shared default", async () => {
  verifiedBatchFixture()
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const path = join(directory, "host-measured.json")
  writeFileSync(path, JSON.stringify({ ...validContainerReceipt(), kind: "a-person-s-laptop" }))
  process.env.TERMINFO_DISPOSABLE_RECEIPT = path
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  await expect(
    runProbeBatch({ ids: ["extensions.osc110-reset-fg"], subject: { kind: "term", id: "kitty", os: "linux" } }),
  ).rejects.toThrow(/unknown kind/)
  expect(writes).toEqual([])
})

it("a verified disposable receipt runs the reset exchange and records its kind and digest", async () => {
  verifiedBatchFixture()
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const bytes = JSON.stringify(validContainerReceipt())
  const path = join(directory, "host-measured.json")
  writeFileSync(path, bytes)
  process.env.TERMINFO_DISPOSABLE_RECEIPT = path
  // Background reset isolates disposable authority from the foreground pixel fallback's geometry.
  const replies = [
    "\x1b]11;rgb:0000/0000/0000\x07\x1b[?62;c",
    "\x1b]11;rgb:aa/bb/cc\x07\x1b[?62;c",
    "\x1b]11;rgb:0000/0000/0000\x07\x1b[?62;c",
  ]
  let read = 0
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    if (text === "\x1b]11;?\x07\x1b[c") process.stdin.emit("data", Buffer.from(replies[read++] ?? ""))
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["extensions.osc111-reset-bg"],
    subject: { kind: "term", id: "kitty", os: "linux" },
  })
  expect(batch.observations).toMatchObject([
    { featureId: "extensions.osc111-reset-bg", outcome: "supported", assertionType: "query_reply" },
  ])
  expect(writes).toEqual([
    "\x1b]11;?\x07\x1b[c",
    "\x1b]11;rgb:aa/bb/cc\x07",
    "\x1b]11;?\x07\x1b[c",
    "\x1b]111\x07",
    "\x1b]11;?\x07\x1b[c",
  ])
  const recorded = JSON.parse(batch.rawReplies["collector.disposableOwnership"]!) as {
    kind: string
    runId: string
    receiptSha256: string
    declaredTarget: { kind: string; id: string; os: string }
    identity: Record<string, string>
  }
  expect(recorded).toMatchObject({ kind: "linux-xvfb-container", runId: "b".repeat(32) })
  expect(recorded.receiptSha256).toBe(createHash("sha256").update(bytes).digest("hex"))
  // 27874 part 3: the identity the receipt names is recorded with the run, not only a digest of
  // bytes a reader on main cannot open.
  expect(recorded.declaredTarget).toEqual({ kind: "app", id: "kitty", os: "linux" })
  expect(recorded.identity).toEqual({
    imageId: "sha256:3f263739c9bebf6e015166eb0aa9c62dd37baf47384391d87875158eeae0bc8d",
    imageTarSha256: "22ab7b15460795eb0c774b68f0d8c5f853d87597bacbffdd809e0fcac9130333",
    arch: "amd64",
    nixLockRevision: "f2e16882cd75b5180bf14f77740fcb8643b35c10",
    frozenRunnerSha256: "d0a6b28177cce4be5dc241fe53adc636cbfba8a60e9362b38e5ccf3c5074d4c6",
    buildReceiptSha256: "63648108c641030f0d0cc0ee7ba92d27cb4627dc1da5ba953f0bd632f4de2044",
  })
})

// 28216: the apparatus measures the launch receipt and the collector only CARRIES it, so the block
// reaches origin.appLaunch with nothing rebuilt, added or edited on the measured side.
it.each([false, true])(
  "copies the apparatus-measured launch block and names only absent invocation (argv=%s)",
  async (withArgv) => {
    const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
    receiptDirectories.push(directory)
    const receipt = hostedLaunchReceipt()
    receipt.appLaunch = {
      ...receipt.appLaunch,
      ...(withArgv ? { argv: ["/invoked/iterm", "--token=[redacted]"] } : {}),
    }
    const path = join(directory, "host-measured.json")
    writeFileSync(path, JSON.stringify(receipt))
    process.env.TERMINFO_DISPOSABLE_RECEIPT = path
    process.stdout.write = (() => true) as typeof process.stdout.write
    const batch = await runProbeBatch({ ids: [], subject: { kind: "term", id: "iterm2", os: "macos" } })
    expect(batch.appLaunch).toEqual(receipt.appLaunch)
    if (withArgv) expect(batch.rawReplies["collector.appLaunchTrace"]).toBeUndefined()
    else {
      const trace = JSON.parse(batch.rawReplies["collector.appLaunchTrace"]!) as { argvAbsentReason: string }
      expect(trace.argvAbsentReason).toMatch(/iterm2.*wrapper/i)
    }
  },
)

it("names the absent app receipt on a hosted Linux collection", async () => {
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const { appLaunch: omitted, ...receipt } = hostedLaunchReceipt()
  void omitted
  receipt.runner.os = "Linux"
  const path = join(directory, "host-measured.json")
  writeFileSync(path, JSON.stringify(receipt))
  process.env.TERMINFO_DISPOSABLE_RECEIPT = path
  process.stdout.write = (() => true) as typeof process.stdout.write
  const batch = await runProbeBatch({ ids: [], subject: { kind: "term", id: "xterm", os: "linux" } })
  expect(batch.appLaunch).toBeUndefined()
  const trace = JSON.parse(batch.rawReplies["collector.appLaunchTrace"]!) as { argvAbsentReason: string }
  expect(trace.argvAbsentReason).toMatch(/no app launch receipt/)
})

it("refuses a mutating probe when neither owned terminal nor disposable receipt is presented", async () => {
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["extensions.osc110-reset-fg"],
    subject: { kind: "term", id: "kitty", os: "linux" },
  })
  expect(writes).toEqual([])
  expect(JSON.parse(batch.rawReplies["collector.disposableOwnership"]!)).toEqual({ kind: "shared" })
  expect(batch.results.filter((result) => ["extensions.osc110-reset-fg"].includes(result.featureId))).toMatchObject([
    { status: "probe-todo", featureId: "extensions.osc110-reset-fg" },
  ])
  expect(batch.assertions).toEqual([])
})

it("authorizes write probes and records receipt kind and digest when disposable-only receipt is presented", async () => {
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const bytes = JSON.stringify(validContainerReceipt())
  const path = join(directory, "host-measured.json")
  writeFileSync(path, bytes)
  process.env.TERMINFO_DISPOSABLE_RECEIPT = path
  // Background reset isolates disposable authority from the foreground pixel fallback's geometry.
  const replies = [
    "\x1b]11;rgb:0000/0000/0000\x07\x1b[?62;c",
    "\x1b]11;rgb:aa/bb/cc\x07\x1b[?62;c",
    "\x1b]11;rgb:0000/0000/0000\x07\x1b[?62;c",
  ]
  let read = 0
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    if (text === "\x1b]11;?\x07\x1b[c") process.stdin.emit("data", Buffer.from(replies[read++] ?? ""))
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["extensions.osc111-reset-bg"],
    subject: { kind: "term", id: "kitty", os: "linux" },
  })
  expect(batch.observations).toMatchObject([
    { featureId: "extensions.osc111-reset-bg", outcome: "supported", assertionType: "query_reply" },
  ])
  expect(writes).toEqual([
    "\x1b]11;?\x07\x1b[c",
    "\x1b]11;rgb:aa/bb/cc\x07",
    "\x1b]11;?\x07\x1b[c",
    "\x1b]111\x07",
    "\x1b]11;?\x07\x1b[c",
  ])
  const recorded = JSON.parse(batch.rawReplies["collector.disposableOwnership"]!) as {
    kind: string
    runId: string
    receiptSha256: string
    declaredTarget: { kind: string; id: string; os: string }
    identity: Record<string, string>
  }
  expect(recorded).toMatchObject({ kind: "linux-xvfb-container", runId: "b".repeat(32) })
  expect(recorded.receiptSha256).toBe(createHash("sha256").update(bytes).digest("hex"))
  // 27874 part 3: the identity the receipt names is recorded with the run, not only a digest of
  // bytes a reader on main cannot open.
  expect(recorded.declaredTarget).toEqual({ kind: "app", id: "kitty", os: "linux" })
  expect(recorded.identity).toEqual({
    imageId: "sha256:3f263739c9bebf6e015166eb0aa9c62dd37baf47384391d87875158eeae0bc8d",
    imageTarSha256: "22ab7b15460795eb0c774b68f0d8c5f853d87597bacbffdd809e0fcac9130333",
    arch: "amd64",
    nixLockRevision: "f2e16882cd75b5180bf14f77740fcb8643b35c10",
    frozenRunnerSha256: "d0a6b28177cce4be5dc241fe53adc636cbfba8a60e9362b38e5ccf3c5074d4c6",
    buildReceiptSha256: "63648108c641030f0d0cc0ee7ba92d27cb4627dc1da5ba953f0bd632f4de2044",
  })
})

it("gives the named geometry error for a geometry probe on disposable-only terminal", async () => {
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const bytes = JSON.stringify(validContainerReceipt())
  const path = join(directory, "host-measured.json")
  writeFileSync(path, bytes)
  process.env.TERMINFO_DISPOSABLE_RECEIPT = path

  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({ ids: ["cursor.shape"], subject: { kind: "term", id: "kitty", os: "linux" } })
  expect(writes).toEqual([])
  expect(batch.results.filter((result) => ["cursor.shape"].includes(result.featureId))).toMatchObject([
    { status: "probe-todo", featureId: "cursor.shape", reason: "No verified owned terminal for geometry read" },
  ])
})

const measured = (
  rows: number,
  cols: number,
  source: typeof linuxGeometrySource | typeof darwinGeometrySource = linuxGeometrySource,
) => ({
  status: "measured" as const,
  at: "2026-09-28T00:00:00.000Z",
  source,
  rows,
  cols,
  stdout: `${rows} ${cols}\n`,
  stderr: "",
})

function geometryOwner(
  geometryAtGrant: typeof noGeometry | ReturnType<typeof measured>,
  readGeometry: () => Promise<typeof noGeometry | ReturnType<typeof measured>> = async () => geometryAtGrant,
) {
  return {
    geometrySource: geometryAtGrant.source,
    geometryAtGrant,
    summary: "{}",
    readGeometry,
    dispose: async () => {},
  }
}

// Direct viewport fixtures bypass this input adaptation. Static pixels deliberately fail in-run
// wheel displacement calibration: the contract here is native batch input/capture wiring without external wheelPlacement.
it.each([
  { deliverKey: false, replyCursor: true },
  { deliverKey: true, replyCursor: true },
  { deliverKey: true, replyCursor: false },
])(
  "calibrates viewport wheel placement in-run through the native batch (deliverKey: $deliverKey, replyCursor: $replyCursor)",
  async ({ deliverKey, replyCursor }) => {
    verifiedBatchFixture()
    const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
    receiptDirectories.push(directory)
    const receiptPath = join(directory, "host-measured.json")
    writeFileSync(receiptPath, JSON.stringify(validContainerReceipt()))
    process.env.TERMINFO_DISPOSABLE_RECEIPT = receiptPath
    const writes: string[] = []
    process.stdout.write = ((text: string) => {
      writes.push(text)
      if (replyCursor && text.includes("\x1b[6n")) {
        queueMicrotask(() => process.stdin.emit("data", Buffer.from("\x1b[1;1R")))
      }
      return true
    }) as typeof process.stdout.write
    const injectKey = vi.fn(async () => {
      if (deliverKey) process.stdin.emit("data", Buffer.from("a"))
    })
    const injectClick = vi.fn(async () => {})
    const capture = vi.fn(async ({ role, label }: { role: "control" | "target"; label: string }) => ({
      frame: { role, label, capturedAt: 1, ref: `sha256:${"a".repeat(64)}`, pixelsDigest: "unchanged-surface" },
      trace: {},
    }))
    const id = "scrollback.viewport-hold-output"
    const batch = await runProbeBatch({
      ids: [id],
      subject: { kind: "term", id: "kitty", os: "linux" },
      ownedTerminal: geometryOwner(measured(8, 30)),
      input: { injectKey, injectClick },
      capture,
    })
    const row = batch.results.find((result) => result.featureId === id)!
    expect(row).toMatchObject({
      status: "probe-todo",
      reason: !replyCursor
        ? "no cursor-position reply after painting calibration seed"
        : deliverKey
          ? "wheel placement bound not established"
          : "viewport input delivery not observed",
    })
    expect(JSON.parse(batch.rawReplies[`${id}.callbackResponse`]!)).toMatchObject({
      calibration: !replyCursor ? {} : deliverKey ? { boundEstablished: false } : { delivery: null },
    })
    expect(capture).toHaveBeenCalledTimes(!replyCursor ? 0 : deliverKey ? 4 : 1)
    expect(writes.length > 0).toBe(true)
    expect(injectKey).toHaveBeenCalledTimes(!replyCursor ? 0 : 1)
    expect(injectClick).toHaveBeenCalledTimes(!replyCursor ? 0 : deliverKey ? 43 : 0)
    expect(batch.observations).toEqual([])
    expect(batch.assertions).toEqual([])
  },
)

it("declines a declared callback with missing or conflicting owned geometry before any feature bytes", async () => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === "reset.ris")!
  expect(definition.termNeedsGeometry).toBe(true)
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  const missing = await runProbeBatch({
    ids: ["reset.ris"],
    ownedTerminal: geometryOwner(noGeometry, async () => measured(24, 61)),
  })
  expect(missing.results.find((result) => result.featureId === "reset.ris")).toMatchObject({ status: "probe-todo" })
  expect(
    decodeCollectorDraft(
      "missing-geometry.json",
      JSON.stringify(asRun(missing)),
      manifest,
      sourceRevision,
    ).run.results.find((result) => result.featureId === "reset.ris"),
  ).toMatchObject({ status: "probe-todo" })
  expect(JSON.parse(missing.rawReplies["reset.ris"]!)).toEqual({ writes: [], queries: [], events: [] })
  expect(writes).toEqual([])
  const conflict = await runProbeBatch({
    ids: ["reset.ris"],
    ownedTerminal: geometryOwner(measured(24, 61, darwinGeometrySource), async () =>
      measured(24, 61, darwinGeometrySource),
    ),
    geometryCorroboration: {
      status: "conflict",
      rows: 25,
      cols: 61,
      query: {
        sequence: "\x1b[18t",
        outbound: "\x1b[18t\x1b[c",
        reason: "reply",
        raw: "\x1b[8;25;61t",
        rawBase64: Buffer.from("\x1b[8;25;61t").toString("base64"),
      },
    },
  })
  expect(conflict.results.find((result) => result.featureId === "reset.ris")).toMatchObject({ status: "probe-invalid" })
  expect(writes).toEqual([])
  expect(JSON.parse(conflict.rawReplies["collector.geometry"]!)).toMatchObject({
    source: darwinGeometrySource,
    bindingReceiptRef: "collector.terminalOwnership",
    grant: { source: darwinGeometrySource },
    corroboration: {
      query: { sequence: "\x1b[18t", outbound: "\x1b[18t\x1b[c", reason: "reply" },
    },
    checks: [{ featureId: "reset.ris", diagnostic: expect.stringContaining("conflicts") }],
  })
})

type CapturePreparation = NonNullable<NonNullable<Parameters<typeof runProbeBatch>[0]>["prepareCapture"]>

it.each([undefined, "after-probes"] as const)(
  "prepares capture once with the full retained trace (phase: %s)",
  async (phase) => {
    verifiedBatchFixture()
    const ids = ["reset.ris", "reset.decaln"]
    const definitions = ids.map((id) => ALL_PROBES.find((item) => item.id === id)!)
    const originals = definitions.map(({ term, termNeedsGeometry, termWrites }) => ({
      term,
      termNeedsGeometry,
      termWrites,
    }))
    const order: string[] = []
    const writes: string[] = []
    let prepared = false
    const captureRef = `sha256:${"a".repeat(64)}`
    process.stdout.write = ((text: string) => {
      writes.push(text)
      if (text === "\x1b[?25$p\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?25;1$y\x1b[?62c"))
      return true
    }) as typeof process.stdout.write
    try {
      for (const [index, definition] of definitions.entries()) {
        if (index === 0) delete definition.termNeedsGeometry
        else definition.termNeedsGeometry = true
        if (index === 0) definition.termWrites = "query"
        definition.term = async (probeSource) => {
          expect(prepared, `${ids[index]} must observe its selected preparation phase`).toBe(phase === undefined)
          if (phase === undefined) {
            expect(probeSource.captureGeometry).toEqual({
              geometry: { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 384 },
              source: "measured by complete raster calibration",
            })
          } else expect(probeSource.captureGeometry).toBeUndefined()
          order.push(`callback:${ids[index]}`)
          probeSource.write(`fixture:${ids[index]}`)
          return {
            pass: false,
            tests: [
              { id: "criterion", status: "probe-todo", reason: "Lifecycle fixture does not measure terminal support" },
            ],
          }
        }
      }
      const prepare: CapturePreparation = async ({ source: probeSource, featureId, recordCapture }) => {
        expect(featureId).toBe("collector.captureCalibration")
        expect(prepared).toBe(false)
        order.push("prepare")
        expect(await probeSource.queryMode(25)).toBe("set")
        probeSource.write("calibration:paint-witness")
        prepared = true
        Object.assign(probeSource, {
          captureGeometry: {
            geometry: { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 384 },
            source: "measured by complete raster calibration",
          },
        })
        recordCapture({
          frame: { role: "control", ref: captureRef, capturedAt: 1, label: "origin calibration" },
          trace: { captureCommand: "fixture-capture" },
        })
      }
      const batch = await runProbeBatch({
        ids,
        ownedTerminal: geometryOwner(measured(24, 80)),
        ...(phase === undefined ? { prepareCapture: prepare } : { finishCapture: prepare }),
      })
      expect(order).toEqual(
        phase === undefined
          ? ["prepare", "callback:reset.ris", "callback:reset.decaln"]
          : ["callback:reset.ris", "callback:reset.decaln", "prepare"],
      )
      expect(writes).toContain("calibration:paint-witness")
      if (phase === undefined) {
        expect(writes.indexOf("calibration:paint-witness")).toBeLessThan(writes.indexOf("fixture:reset.ris"))
      } else expect(writes.at(-1)).toBe("calibration:paint-witness")
      expect(writes).not.toContain("calibration:paint-witness\n")
      expect(batch.screenshotRefs).toEqual([captureRef])
      expect(JSON.parse(batch.rawReplies["reset.ris"]!)).toMatchObject({
        writes: ["fixture:reset.ris"],
      })
      expect(JSON.parse(batch.rawReplies["reset.ris"]!)).not.toHaveProperty("captures")
      expect(JSON.parse(batch.rawReplies["collector.captureCalibration.trace"]!)).toMatchObject({
        writes: ["calibration:paint-witness"],
        queries: [expect.objectContaining({ sequence: "\x1b[?25$p\x1b[c", raw: "\x1b[?25;1$y\x1b[?62c" })],
        captures: [{ frame: { ref: captureRef }, trace: { captureCommand: "fixture-capture" } }],
      })
      expect(JSON.parse(batch.rawReplies["reset.decaln"]!)).toMatchObject({
        writes: ["fixture:reset.decaln"],
      })
    } finally {
      definitions.forEach((definition, index) => Object.assign(definition, originals[index]))
    }
  },
)

describe("an after-probes finish beside a before-probes preparation (32670)", () => {
  const id = "reset.ris"
  const probeOrder: string[] = []
  let callbackSource: TermProbeSource | undefined
  let restore: () => void = () => {}
  beforeEach(() => {
    verifiedBatchFixture()
    probeOrder.length = 0
    callbackSource = undefined
    const definition = ALL_PROBES.find((item) => item.id === id)!
    const original = {
      term: definition.term,
      termNeedsGeometry: definition.termNeedsGeometry,
      termWrites: definition.termWrites,
    }
    restore = () => Object.assign(definition, original)
    delete definition.termNeedsGeometry
    definition.termWrites = "query"
    definition.term = async (probeSource) => {
      callbackSource = probeSource
      probeOrder.push("callback")
      probeSource.write("fixture:reset.ris")
      return {
        pass: false,
        tests: [
          { id: "criterion", status: "probe-todo", reason: "Lifecycle fixture does not measure terminal support" },
        ],
      }
    }
    process.stdout.write = (() => true) as typeof process.stdout.write
  })
  afterEach(() => restore())

  // CTO26812ffa: phase order alone misses a second preparation rewriting state already handed to rows.
  it.each(["geometry", "refusal", "late-refusal"] as const)(
    "preserves handed %s through the finish and retains its separate trace",
    async (state) => {
      const geometry = {
        geometry: { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 384 },
        source: "measured by complete raster calibration" as const,
      }
      const priorRefusal = "calibration refused before probes"
      const finalRefusal = "qualification refused after probes"
      const checkpointTraces: string[] = []
      const batch = await runProbeBatch({
        ids: [id],
        ownedTerminal: geometryOwner(measured(24, 80)),
        onCheckpoint: (checkpoint) => {
          const trace = checkpoint.rawReplies["collector.textQualification.trace"]
          if (trace) checkpointTraces.push(trace)
        },
        prepareCapture: async ({ source: probeSource, featureId }) => {
          expect(featureId).toBe("collector.captureCalibration")
          probeOrder.push("calibrate")
          probeSource.write("calibration:paint")
          if (state === "refusal") throw Object.assign(new Error(priorRefusal), { name: "CaptureCalibrationRefused" })
          probeSource.captureGeometry = geometry
        },
        finishCapture: async ({ source: probeSource, featureId }) => {
          expect(featureId).toBe("collector.textQualification")
          probeOrder.push("qualify")
          probeSource.write("qualification:paint")
          expect(callbackSource?.captureGeometry).toEqual(state !== "refusal" ? geometry : undefined)
          expect(callbackSource?.captureGeometryRefusal).toBe(state === "refusal" ? priorRefusal : undefined)
          if (state !== "geometry") throw Object.assign(new Error(finalRefusal), { name: "CaptureCalibrationRefused" })
          probeSource.captureGeometry = { ...geometry, geometry: { ...geometry.geometry, cellWidth: 16 } }
        },
      })
      expect(probeOrder).toEqual(["calibrate", "callback", "qualify"])
      expect(callbackSource?.captureGeometry).toEqual(state !== "refusal" ? geometry : undefined)
      expect(callbackSource?.captureGeometryRefusal).toBe(state === "refusal" ? priorRefusal : undefined)
      expect(JSON.parse(batch.rawReplies["collector.captureCalibration.trace"]!)).toMatchObject({
        writes: ["calibration:paint"],
        ...(state === "refusal" ? { refusal: priorRefusal } : {}),
      })
      expect(JSON.parse(batch.rawReplies["collector.textQualification.trace"]!)).toMatchObject({
        writes: ["qualification:paint"],
        ...(state !== "geometry" ? { refusal: finalRefusal } : {}),
      })
      expect(checkpointTraces).toContain(batch.rawReplies["collector.textQualification.trace"])
    },
  )

  it("fails the whole run, returning no batch, when the after-probes qualification fails", async () => {
    await expect(
      runProbeBatch({
        ids: [id],
        ownedTerminal: geometryOwner(measured(24, 80)),
        prepareCapture: async () => {
          probeOrder.push("calibrate")
        },
        finishCapture: async () => {
          throw new Error("qualification fixture failed after probes")
        },
      }),
    ).rejects.toThrow("qualification fixture failed after probes")
    expect(probeOrder).toEqual(["calibrate", "callback"])
  })
})

it("keeps query-only and nongeometry callbacks runnable when owned size is unavailable", async () => {
  verifiedBatchFixture()
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    if (text === "\x1b[?7$p\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?7;2$y"))
    if (text === "\x1b[6n") process.stdin.emit("data", Buffer.from("\x1b[1;2R"))
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["device.decrpm", "reset.decaln"],
    ownedTerminal: geometryOwner(noGeometry),
  })
  expect(batch.observations.find((item) => item.featureId === "device.decrpm")).toMatchObject({
    outcome: "supported",
    assertionType: "query_reply",
  })
  expect(batch.results.find((item) => item.featureId === "reset.decaln")).toMatchObject({ status: "probe-todo" })
  expect(batch.ungradedDiagnostics["reset.decaln"]).toBeUndefined()
  expect(writes).not.toContain("\x1b#8")
  expect(writes).toContain("\x1b[?7$p\x1b[c")
})

// The width-helper trace must describe the actual output and retain every CPR reply, rather than an invented fixture.
it("retains actual width-helper writes and all four CPR query outcomes", async () => {
  verifiedBatchFixture()
  vi.mocked(measureUtf8Decoding).mockResolvedValue("utf8")
  const replies = ["\x1b[2;1R", "\x1b[1;2R", "\x1b[1;2R", "\x1b[1;3R"]
  const pending = [...replies]
  const emitted: string[] = []
  process.stdout.write = ((sequence: string) => {
    emitted.push(sequence)
    if (sequence === "\x1b[6n") process.stdin.emit("data", Buffer.from(pending.shift()!))
    return true
  }) as typeof process.stdout.write
  try {
    const id = "unicode.east-asian-ambiguous"
    const batch = await runProbeBatch({
      ids: [id],
      ownedTerminal: geometryOwner(measured(24, 61), async () => measured(24, 61)),
    })
    const trace = JSON.parse(batch.rawReplies[id]!)
    const writes = emitted.filter((sequence) => sequence !== "\x1b[6n")
    expect(pending).toEqual([])
    expect(writes).toHaveLength(6)
    expect(trace).toMatchObject({
      writes,
      queries: replies.map((raw) => ({
        sequence: "\x1b[6n",
        match: [...raw.match(/\x1b\[(\d+);(\d+)R/)!],
        reason: "reply",
        raw,
        rawBase64: Buffer.from(raw).toString("base64"),
      })),
      events: emitted.map((sequence) => ({ sequence })),
    })
    expect(batch.observations).toMatchObject([{ featureId: id, outcome: "supported", assertionType: "query_reply" }])
  } finally {
    vi.mocked(measureUtf8Decoding).mockRestore()
  }
})

it("keeps actual query evidence but downgrades its explicit result after a measured resize", async () => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const original = definition.termNeedsGeometry
  definition.termNeedsGeometry = true
  let reads = 0
  process.stdout.write = ((text: string) => {
    if (text === "\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?62;4c"))
    return true
  }) as typeof process.stdout.write
  try {
    const batch = await runProbeBatch({
      ids: ["device.primary-da"],
      ownedTerminal: geometryOwner(measured(24, 61), async () => (++reads === 1 ? measured(24, 61) : measured(31, 73))),
    })
    expect(batch.observations).toMatchObject([
      {
        featureId: "device.primary-da",
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        assertionType: "query_reply",
      },
    ])
    expect(batch.assertions).toMatchObject([
      {
        featureId: "device.primary-da",
        kind: "positive",
        observed: "\x1b[?62;4c",
        note: expect.stringContaining("resized"),
      },
    ])
    expect(JSON.parse(batch.rawReplies["device.primary-da.callbackObservation"]!)).toMatchObject({
      outcome: "supported",
      assertionType: "query_reply",
    })
    expect(batch.results.find((result) => result.featureId === "device.primary-da")).toMatchObject({
      status: "probe-invalid",
      criterionBranch: "resized-capture",
      tests: [{ id: "geometry", status: "probe-invalid", assertionRefs: [0] }],
    })
    expect(batch.rawReplies["device.primary-da"]).toBe("\x1b[?62;4c")
    expect(JSON.parse(batch.rawReplies["collector.geometry"]!)).toMatchObject({
      checks: [{ pre: { rows: 24, cols: 61 }, post: { rows: 31, cols: 73 } }],
    })
    const decoded = decodeCollectorDraft("resized.json", JSON.stringify(asRun(batch)), manifest, sourceRevision).run
    expect(decoded.assertions).toEqual(batch.assertions)
    expect(decoded.results).toEqual(batch.results)
    expect(decoded.rawReplies["device.primary-da.callbackObservation"]).toBe(
      batch.rawReplies["device.primary-da.callbackObservation"],
    )
  } finally {
    definition.termNeedsGeometry = original
  }
})

// #33054: a resize re-labels the row resized-capture, so a branch witness on its negative would disagree with the
// row's branch and the parser would refuse the whole run. The collector keeps the assertion and drops the witness.
it("drops a branch witness from a negative whose capture resized, so the run still parses", async () => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const original = { needs: definition.termNeedsGeometry, term: definition.term }
  definition.termNeedsGeometry = true
  const digest = (text: string) => `sha256:${text.repeat(64).slice(0, 64)}`
  // The real callback runs its DA query, so the row keeps its retained raw payload; its result is replaced.
  definition.term = async (...args: Parameters<NonNullable<typeof original.term>>) => {
    await original.term!(...args)
    return {
      pass: false,
      criterionBranch: "colour-no-attribute-witness",
      response: "\x1b[?62;4c",
      tests: [{ id: "criterion", status: "unsupported", assertionRefs: [0] }],
      observation: { outcome: "unsupported", assertionType: "query_reply", note: "painted nothing" },
      assertions: [
        {
          assertionType: "query_reply",
          kind: "negative",
          expected: "paints something other than plain text",
          observed: digest("b"),
          witness: {
            kind: "colour-no-attribute-witness",
            rowId: definition.id,
            encoding: "58;2;255;0;128",
            rectangle: { x: 1, y: 2, width: 3, height: 4 },
            frames: { seed: digest("a"), expected: digest("b"), noAttribute: digest("b") },
          },
        },
      ],
    }
  }
  let reads = 0
  process.stdout.write = ((text: string) => {
    if (text === "\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?62;4c"))
    return true
  }) as typeof process.stdout.write
  try {
    const batch = await runProbeBatch({
      ids: [definition.id],
      ownedTerminal: geometryOwner(measured(24, 61), async () => (++reads === 1 ? measured(24, 61) : measured(31, 73))),
    })
    expect(batch.results.find((result) => result.featureId === definition.id)).toMatchObject({
      criterionBranch: "resized-capture",
    })
    expect(batch.assertions).toHaveLength(1)
    expect(batch.assertions[0]).toMatchObject({ kind: "negative", note: expect.stringContaining("resized") })
    expect(batch.assertions[0]).not.toHaveProperty("witness")
    const decoded = decodeCollectorDraft("resized-witness.json", JSON.stringify(asRun(batch)), manifest, sourceRevision)
    expect(decoded.run.assertions).toEqual(batch.assertions)
  } finally {
    definition.termNeedsGeometry = original.needs
    definition.term = original.term
  }
})

// A dormant boundary the audit family exposed: an app coverage claim must be bound to a NONEMPTY raw
// trace, and the shared parser must accept the record rather than reject the whole run.
it("binds an app named coverage record to its own retained raw trace", async () => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const originalTerm = definition.term
  definition.term = async () => ({
    pass: false,
    response: "\x1b[?62;4c",
    notTested: { reason: "no-semantic-observable", noObservable: "device attributes" },
  })
  try {
    const batch = await runProbeBatch({ ids: [definition.id] })
    expect(batch.notTested).toEqual([
      {
        featureId: definition.id,
        reason: "no-semantic-observable",
        noObservable: "device attributes",
        rawReplyRef: definition.id,
      },
    ])
    expect(batch.rawReplies[`${definition.id}.callbackResponse`]).toBe("\x1b[?62;4c")
    expect(JSON.parse(batch.rawReplies[definition.id]!)).toEqual({ writes: [], queries: [], events: [] })
    const decoded = decodeCollectorDraft(
      "app-named-coverage.json",
      JSON.stringify(asRun(batch)),
      manifest,
      sourceRevision,
    ).run
    expect(decoded.results.find((result) => result.featureId === definition.id)).toMatchObject({
      status: "probe-todo",
      reason: "device attributes",
      rawReplyRef: definition.id,
    })
  } finally {
    definition.term = originalTerm
  }
})

// A mixed app result - named coverage beside its own returned failure - is a loud collector error,
// never coverage, and it cannot complete the suite.
it("refuses app named coverage that arrives beside its returned error observation", async () => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const originalTerm = definition.term
  const originalAssertionType = definition.termAssertionType
  definition.termAssertionType = "query_reply"
  definition.term = (async () => ({
    pass: false,
    response: "\x1b[?62;4c",
    notTested: { reason: "no-semantic-observable", noObservable: "device attributes" },
    observation: {
      outcome: "error",
      reason: "collector-error",
      assertionType: "query_reply",
      note: "TTY write failed",
    },
  })) as unknown as typeof definition.term
  try {
    const batch = await runProbeBatch({ ids: [definition.id] })
    expect(batch.notTested).toEqual([])
    expect(batch.observations.filter((item) => item.featureId === definition.id)).toEqual([])
    expect(batch.ungradedDiagnostics[definition.id]).toMatchObject({
      kind: "collector-error",
      name: "Error",
      message: expect.stringContaining("beside observation(outcome=error, reason=collector-error"),
    })
    expect(batch.rawReplies[`${definition.id}.callbackResponse`]).toBe("\x1b[?62;4c")
    const diagnostic = JSON.stringify(batch.ungradedDiagnostics[definition.id] ?? null)
    expect(diagnostic).toContain("TTY write failed")
    const decoded = decodeCollectorDraft(
      "app-mixed-coverage.json",
      JSON.stringify(asRun(batch)),
      manifest,
      sourceRevision,
    ).run
    expect(decoded.results.find((result) => result.featureId === definition.id)).toMatchObject({
      status: "probe-invalid",
      reason: expect.stringContaining("TTY write failed"),
    })
    expect(batch.suiteComplete).toBe(false)
  } finally {
    definition.term = originalTerm
    definition.termAssertionType = originalAssertionType
  }
})

it("refuses app named coverage that arrives beside supported observation and assertions", async () => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const originalTerm = definition.term
  definition.term = (async () => ({
    pass: true,
    response: "\x1b[?62;4c",
    notTested: { reason: "no-semantic-observable", noObservable: "device attributes" },
    observation: { outcome: "supported", assertionType: "query_reply" },
    assertions: [{ kind: "positive", expected: "\x1b[?62;4c", observed: "\x1b[?62;4c" }],
  })) as unknown as typeof definition.term
  try {
    const batch = await runProbeBatch({ ids: [definition.id] })
    expect(batch.notTested).toEqual([])
    expect(batch.assertions).toEqual([])
    expect(batch.observations.filter((item) => item.featureId === definition.id)).toEqual([])
    expect(batch.ungradedDiagnostics[definition.id]).toMatchObject({
      kind: "collector-error",
      message: expect.stringContaining("assertion(kind=positive"),
    })
    expect(batch.rawReplies[`${definition.id}.callbackResponse`]).toBe("\x1b[?62;4c")
    const diagnostic = JSON.stringify(batch.ungradedDiagnostics[definition.id] ?? null)
    expect(diagnostic).toContain("expected=")
    expect(diagnostic).toContain("observed=")
    const decoded = decodeCollectorDraft(
      "app-mixed-assertions.json",
      JSON.stringify(asRun(batch)),
      manifest,
      sourceRevision,
    ).run
    expect(decoded.results.find((result) => result.featureId === definition.id)).toMatchObject({
      status: "probe-invalid",
      reason: expect.stringContaining("assertion(kind=positive"),
    })
    expect(batch.suiteComplete).toBe(false)
  } finally {
    definition.term = originalTerm
  }
})

it("reports undeclared geometry reads as collector errors without invented evidence", async () => {
  verifiedBatchFixture()
  // Reach the geometry contract after the wrap probe's disposable-process prerequisite.
  vi.spyOn(terminalOwnership, "ownedTerminalProcessBasisFor").mockReturnValue("owned disposable regression process")
  const definition = ALL_PROBES.find((item) => item.id === "text.wrap")!
  const original = definition.termNeedsGeometry
  const originalAssertionType = definition.termAssertionType
  definition.termNeedsGeometry = undefined
  definition.termAssertionType = "query_reply"
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  try {
    const batch = await runProbeBatch({ ids: ["text.wrap"] })
    expect(batch.ungradedDiagnostics["text.wrap"]).toMatchObject({
      kind: "collector-error",
      name: "UndeclaredTerminalGeometry",
      message: expect.stringContaining("text.wrap"),
    })
    expect(batch.observations).toEqual([])
    expect(writes).toEqual([])
  } finally {
    definition.termNeedsGeometry = original
    definition.termAssertionType = originalAssertionType
  }
})

// Plain-number callback fixtures bypass the collector's guarded rows/cols getters. These native
// failures must consume measured geometry, while removing their declaration must still refuse it.
it.each([
  ["extensions.kitty-graphics.animation", "probe-todo"],
  ["extensions.kitty-graphics.unicode-placeholders", "probe-todo"],
  ["input.pixel-mouse", "probe-todo"],
  ["modes.auto-wrap", "probe-invalid"],
] as const)("delivers owned geometry to %s and preserves its declaration guard", async (id, undersizedStatus) => {
  verifiedBatchFixture()
  if (id === "modes.auto-wrap") {
    vi.spyOn(terminalOwnership, "ownedTerminalProcessBasisFor").mockReturnValue("owned disposable regression process")
  }
  const definition = ALL_PROBES.find((item) => item.id === id)!
  const original = definition.termNeedsGeometry
  process.stdout.write = ((sequence: string) => {
    // Qualify image allocation so the Kitty rows reach the geometry contract under test.
    const imageNumber = /\x1b_Ga=t,[^;]*I=(\d+);/.exec(sequence)?.[1]
    if (imageNumber) process.stdin.emit("data", Buffer.from(`\x1b_Gi=41,I=${imageNumber};OK\x1b\\`))
    return true
  }) as typeof process.stdout.write
  const collect = async () => {
    vi.useFakeTimers()
    try {
      const [batch] = await Promise.all([
        runProbeBatch({
          ids: [id],
          ownedTerminal: geometryOwner(measured(1, 1)),
          capture: async () => {
            throw new Error("Undersized geometry must decline before capture")
          },
          input: {
            injectKey: async () => {},
            injectClick: async () => {
              // A genuine delivery-control report outside the measured 1x1 cell reaches the size read.
              process.stdin.emit("data", Buffer.from("\x1b[<0;2;2M"))
            },
          },
        }),
        vi.runAllTimersAsync(),
      ])
      return batch
    } finally {
      vi.useRealTimers()
    }
  }
  try {
    const batch = await collect()
    expect(batch.ungradedDiagnostics[id], id).toBeUndefined()
    expect(JSON.parse(batch.rawReplies["collector.geometry"]!)).toMatchObject({
      checks: [
        {
          featureId: id,
          pre: { status: "measured", rows: 1, cols: 1 },
          post: { status: "measured", rows: 1, cols: 1 },
        },
      ],
    })
    expect(batch.observations, id).toEqual([])
    expect(batch.results.find((result) => result.featureId === id)?.status, id).toBe(undersizedStatus)
    definition.termNeedsGeometry = undefined
    const undeclared = await collect()
    expect(undeclared.ungradedDiagnostics[id], id).toMatchObject({
      kind: "collector-error",
      name: "UndeclaredTerminalGeometry",
      message: expect.stringContaining(id),
    })
    expect(undeclared.observations, id).toEqual([])
  } finally {
    definition.termNeedsGeometry = original
  }
})

it.each([
  "modes.left-right-margin",
  "modes.altscreen-47",
  "modes.altscreen-1047",
  "modes.xtpushsgr",
  "modes.xtpopsgr",
  "modes.xtsave",
  "modes.xtrestore",
  "modes.xtpushcolors",
  "modes.xtpopcolors",
  "extensions.truecolor",
  "extensions.sixel",
  "extensions.iterm2-images",
])("the real collector enforces the geometry declaration for %s", async (id) => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === id)!
  expect(definition.termNeedsGeometry, id).toBe(true)
  const original = definition.termNeedsGeometry
  const originalAssertionType = definition.termAssertionType
  // Clearing the declaration must make the real collector seam refuse the callback's rows/cols read,
  // proving the declaration is load-bearing rather than only satisfied by a fake plain-number probeSource.
  definition.termNeedsGeometry = undefined
  definition.termAssertionType = "screenshot"
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  try {
    const batch = await runProbeBatch({
      ids: [id],
      ownedTerminal: geometryOwner(measured(24, 80)),
      capture: async () => {
        throw new Error("capture checkpoint must not be reached without a geometry declaration")
      },
    })
    expect(batch.ungradedDiagnostics[id], id).toMatchObject({
      kind: "collector-error",
      name: "UndeclaredTerminalGeometry",
      message: expect.stringContaining(id),
    })
    expect(batch.observations, id).toEqual([])
    expect(writes, id).toEqual([])
  } finally {
    definition.termNeedsGeometry = original
    definition.termAssertionType = originalAssertionType
  }
})

/**
 * editing.decsace compares the same measured 2x8 pixel cells across its seed and two extents.
 * The collector must supply owned geometry and retain the cell digests and crop rectangle through
 * canonical parsing, while keeping the completed observation in suiteComplete.
 *
 * The expected set is narrowed to this probe (the pattern the collector-error tests above use) so the
 * assertion is about the real completeness formula, `expected ⊆ observed ∪ notTested AND no
 * diagnostics`, without running every app probe through its real query timeouts.
 */
it("grades editing.decsace on measured pixel cells and keeps suiteComplete", async () => {
  verifiedBatchFixture()
  const others = ALL_PROBES.filter((probe) => probe.id !== "editing.decsace" && probe.term !== null)
  const originals = others.map((probe) => probe.term)
  let reads = 0
  const labels: string[] = []
  const geometry = { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 384 }
  const originalWrite = process.stdout.write
  process.stdout.write = (() => true) as typeof process.stdout.write
  try {
    for (const probe of others) probe.term = null
    const batch = await runProbeBatch({
      ownedTerminal: geometryOwner(measured(24, 80)),
      prepareCapture: async ({ source: probeSource }) => {
        probeSource.captureGeometry = { geometry, source: "measured by complete raster calibration" }
      },
      capture: async ({ role, label, cells, pixelGeometry }) => {
        expect(cells).toEqual({ top: 1, left: 1, bottom: 2, right: 8 })
        expect(pixelGeometry).toEqual(geometry)
        reads += 1
        labels.push(label)
        // The seed pair shares measured cells; encoded refs, whole frames and cells are distinct
        // facts, and only the two DECSACE extents change the compared cells.
        const measured = label.includes("rectangle") ? "b" : label.includes("stream") ? "c" : "a"
        const digest = (kind: string) => `sha256:${createHash("sha256").update(`${kind}:${measured}`).digest("hex")}`
        return {
          frame: {
            role,
            label,
            capturedAt: reads,
            ref: digest(`encoded:${reads}`),
            pixelsDigest: digest("whole"),
            regionDigest: digest("cells"),
            regionRectangle: { x: 0, y: 0, width: 64, height: 32 },
          },
          trace: {},
        }
      },
    })
    expect(batch.ungradedDiagnostics).toEqual({})
    expect(batch.suiteComplete).toBe(true)
    expect(batch.observations).toMatchObject([
      { featureId: "editing.decsace", outcome: "supported", assertionType: "screenshot" },
    ])
    expect(
      decodeCollectorDraft(
        "decsace.json",
        JSON.stringify({ ...asRun(batch), screenshotRefs: batch.screenshotRefs }),
        manifest,
        sourceRevision,
      ).run.results.filter((result) => result.featureId === "editing.decsace"),
    ).toMatchObject([{ featureId: "editing.decsace", status: "supported", assertionType: "screenshot" }])
    expect(labels).toEqual([
      // The seed paint happens first, then the shared stability pair reads the seeded screen: its
      // second read IS the seed frame, so the extent frames follow.
      "editing.decsace: seed stability 1",
      "editing.decsace: seed stability 2",
      "editing.decsace: DECSACE 2 rectangle frame",
      "editing.decsace: DECSACE 0 stream frame",
    ])
  } finally {
    process.stdout.write = originalWrite
    others.forEach((probe, index) => {
      probe.term = originals[index] ?? null
    })
  }
})

// 27863: a feature whose app callback reads the measured grid must declare termNeedsGeometry; a
// missing declaration is a collector error that silently costs the feature every run.
it("grades cursor.shape and cursor.reverse-wrap when each declares its measured-grid read", async () => {
  verifiedBatchFixture()
  const replies = ["\x1b[1;1R", "\x1b[2;2R", "\x1b[1;61R"]
  process.stdout.write = ((text: string) => {
    if (text === "\x1b[6n") {
      const reply = replies.shift()
      if (reply) process.stdin.emit("data", Buffer.from(reply))
    }
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["cursor.shape", "cursor.reverse-wrap"],
    capture: async ({ role, label }) => ({
      frame: { role, label, capturedAt: Date.now(), ref: `sha256:${"a".repeat(64)}` },
      trace: {},
    }),
    ownedTerminal: geometryOwner(measured(24, 61)),
  })
  expect(batch.ungradedDiagnostics).toEqual({})
  expect(batch.notTested.find((item) => item.featureId === "cursor.shape")).toMatchObject({
    noObservable: "Focus needs owned key injection and stdin readback",
  })
  expect(batch.observations.find((item) => item.featureId === "cursor.reverse-wrap")).toMatchObject({
    outcome: "supported",
    assertionType: "query_reply",
  })
})

// A text adapter answers a cell-readback row where pixel geometry was refused, and its ref lands in
// the text list — never in `screenshotRefs`, whose every consumer assumes a PNG.
it("keeps a text frame's ref out of screenshotRefs on the row whose verdict reads cells", async () => {
  verifiedBatchFixture()
  let reads = 0
  const refs: string[] = []
  const written: string[] = []
  process.stdout.write = ((text: string) => {
    written.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["erase.el-with-attrs"],
    captureKind: "text-cells",
    captureGeometryRefusal: "the app answers no cell geometry",
    capture: async ({ role, label }) => {
      reads += 1
      // A fresh screen each read: the paint witness must differ from its baseline, as it does on a
      // terminal that actually painted.
      const ref = `sha256:${String(reads).padStart(64, "0")}`
      refs.push(ref)
      return {
        frame: {
          kind: "text-cells",
          role,
          label,
          capturedAt: reads,
          ref,
          cellDigest: ref,
          frameDigest: ref,
          cellRectangle: { top: 1, left: 1, bottom: 24, right: 80 },
        },
        trace: { kind: "text-cells", retained: "snapshot.txt", source: "the terminal's own text snapshot" },
      }
    },
    ownedTerminal: geometryOwner(measured(24, 80)),
  })
  expect(reads).toBeGreaterThan(0)
  expect(written.length).toBeGreaterThan(0)
  expect(batch.screenshotRefs).toEqual([])
  expect(batch.textSnapshotRefs).toEqual([...new Set(refs)])
})

// 30055 AC4: the host a text capture actually recorded reaches the observation as image, path and
// digest. `pid` and `ppid` stay in the artifact trace, because they name one process instance rather
// than a host a reader can check (@cto ruling 6255e75d conditions 1 and 5).
it("carries the console host a text capture recorded onto the observation, without its pids", async () => {
  verifiedBatchFixture()
  let reads = 0
  process.stdout.write = (() => true) as typeof process.stdout.write
  const owner = {
    image: "OpenConsole.exe",
    pid: 7216,
    ppid: 4684,
    executablePath: "C:\\Windows\\System32\\OpenConsole.exe",
    executableSha256: `sha256:${"c".repeat(64)}`,
  }
  const batch = await runProbeBatch({
    ids: ["erase.el-with-attrs"],
    captureKind: "text-cells",
    captureGeometryRefusal: "the app answers no cell geometry",
    capture: async ({ role, label }) => {
      reads += 1
      const ref = `sha256:${String(reads).padStart(64, "0")}`
      return {
        frame: {
          kind: "text-cells" as const,
          role,
          label,
          capturedAt: reads,
          ref,
          cellDigest: ref,
          frameDigest: ref,
          cellRectangle: { top: 1, left: 1, bottom: 24, right: 80 },
        },
        trace: {
          kind: "text-cells",
          retained: "snapshot.txt",
          source: "the console host's buffer",
          bufferOwner: owner,
        },
      }
    },
    ownedTerminal: geometryOwner(measured(24, 80)),
  })
  const observation = batch.observations.find((item) => item.featureId === "erase.el-with-attrs")
  expect(observation).toMatchObject({ assertionType: "buffer_state" })
  expect(observation?.host).toEqual({
    image: "OpenConsole.exe",
    executablePath: owner.executablePath,
    executableSha256: owner.executableSha256,
  })
  // The artifact still carries the pids; the observation never does.
  expect(batch.rawReplies["erase.el-with-attrs"]).toContain('"pid":7216')
  expect(JSON.stringify(observation)).not.toContain("7216")
})

// Only the region readback can decide a row from cells. Every other consumer reads pixels, so a text
// run hands it no adapter at all and it takes its own named no-capture branch instead of recording a
// pixel claim over a text frame.
it("offers a text run's adapter to cell-readback probes alone and never gates it on pixel geometry", () => {
  const refused = "the app answers no cell geometry"
  expect(captureAdapterEligible({ cellReadback: true }, "text-cells", refused)).toBe(true)
  expect(captureAdapterEligible({ cellReadback: true }, "text-cells", undefined)).toBe(true)
  expect(captureAdapterEligible({}, "text-cells", undefined)).toBe(false)
  expect(captureAdapterEligible({}, "text-cells", refused)).toBe(false)
  expect(captureAdapterEligible({ cellReadback: true }, "pixels", refused)).toBe(false)
  expect(captureAdapterEligible({ cellReadback: true }, "pixels", undefined)).toBe(true)
  expect(captureAdapterEligible({}, undefined, undefined)).toBe(true)
})

// @failure The OSC22 image path replaces Kitty's query reader or reaches an unreviewed App tuple.
// Generic capture eligibility has no subject/version boundary; exercise the actual batch wiring.
// @level l1
// @consumer Exact owned App subject -> unified capture forwarding -> OSC22 callback.
it.each([
  { kind: "term", id: "xterm", version: "411", os: "linux", allowed: true },
  { kind: "term", id: "wezterm", version: "0-unstable-2026-10-10", os: "linux", allowed: true },
  { kind: "term", id: "kitty", version: "0.49.2", os: "linux", allowed: false },
  { kind: "mux", id: "tmux", version: "3.8", os: "linux", allowed: false },
  { kind: "term", id: "xterm", version: "412", os: "linux", allowed: false },
  { kind: "term", id: "xterm", version: "411", os: "darwin", allowed: false },
] as const)("limits OSC22 image forwarding to the reviewed $id/$version/$os tuple", async (entry) => {
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const definitions = ["extensions.osc22-pointer", "device.primary-da"].map((id) =>
    ALL_PROBES.find((p) => p.id === id)!,
  )
  const originals = definitions.map(({ term, termNeedsDisposable }) => ({ term, termNeedsDisposable }))
  const seen: boolean[] = []
  try {
    for (const definition of definitions) {
      // This routing-only callback performs no mutation; ownership itself is covered above.
      delete definition.termNeedsDisposable
      definition.term = async (ctx) => {
        seen.push(typeof ctx.capture === "function")
        return notTestedResult("Capture routing exercised without terminal operations", {})
      }
    }
    await runProbeBatch({
      ids: definitions.map(({ id }) => id),
      subject: { kind: entry.kind, id: entry.id, version: entry.version, os: entry.os },
      draft: {
        results: definitions.map(({ id }) => ({
          featureId: id,
          status: "probe-todo",
          attempt: { scope: "none" },
          tests: [],
        })),
      },
      ownedTerminal: geometryOwner(noGeometry),
      capture: async () => {
        throw new Error("Routing test must not capture")
      },
    })
    expect(seen).toEqual([entry.allowed, true])
  } finally {
    definitions.forEach((definition, index) => Object.assign(definition, originals[index]!))
  }
})

it("hands no adapter to a non-cell-readback probe on a text run", async () => {
  verifiedBatchFixture()
  let reads = 0
  const written: string[] = []
  process.stdout.write = ((text: string) => {
    written.push(text)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["cursor.shape"],
    captureKind: "text-cells",
    captureGeometryRefusal: "the app answers no cell geometry",
    capture: async () => {
      reads += 1
      throw new Error("a non-region probe must not be handed the text adapter")
    },
    ownedTerminal: geometryOwner(measured(24, 80)),
  })
  expect(reads).toBe(0)
  expect(batch.screenshotRefs).toEqual([])
  expect(batch.textSnapshotRefs ?? []).toEqual([])
  expect(batch.results.find((item) => item.featureId === "cursor.shape")).toMatchObject({ status: "probe-invalid" })
  expect(batch.observations.find((item) => item.featureId === "cursor.shape")?.assertionType).not.toBe("pixels")
})

// A callback that fails after its text read is a collector error about cells, not a pixel claim.
it("records a text run's collector throw as text evidence", async () => {
  verifiedBatchFixture()
  let reads = 0
  const batch = await runProbeBatch({
    ids: ["erase.el-with-attrs"],
    captureKind: "text-cells",
    captureGeometryRefusal: "the app answers no cell geometry",
    capture: async ({ role, label }) => {
      reads += 1
      if (reads > 1) throw new Error("the snapshot read failed after a frame")
      const ref = `sha256:${"e".repeat(64)}`
      return {
        frame: {
          kind: "text-cells",
          role,
          label,
          capturedAt: 1,
          ref,
          cellDigest: ref,
          frameDigest: ref,
          cellRectangle: { top: 1, left: 1, bottom: 24, right: 80 },
        },
        trace: { kind: "text-cells", retained: "snapshot.txt", source: "the terminal's own text snapshot" },
      }
    },
    ownedTerminal: geometryOwner(measured(24, 80)),
  })
  expect(batch.results.find((item) => item.featureId === "erase.el-with-attrs")).toMatchObject({
    status: "probe-invalid",
  })
})

// The public inline runner must put both callback writes and nested CPR queries on its selected TTY.
it("uses the injected TTY for callback writes, columns, and nested cursor queries", async () => {
  verifiedBatchFixture()
  // Qualify disposable ownership without changing the selected TTY or its recorded traffic.
  vi.spyOn(terminalOwnership, "ownedTerminalProcessBasisFor").mockReturnValue("owned disposable regression process")
  const definition = ALL_PROBES.find((item) => item.id === "text.wrap")!
  const original = definition.termNeedsGeometry
  definition.termNeedsGeometry = true
  const writes: string[] = []
  const cursorReplies = ["\x1b[1;1R", "\x1b[1;12R", "\x1b[2;2R"]
  const out = {
    columns: 12,
    write(chunk: string) {
      writes.push(chunk)
      if (chunk === "\x1b[?7$p\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?7;1$y\x1b[?62c"))
      if (chunk === "\x1b[6n") {
        const reply = cursorReplies.shift()
        if (reply) process.stdin.emit("data", Buffer.from(reply))
      }
      return true
    },
  } as unknown as NodeJS.WriteStream
  process.stdout.write = (() => {
    throw new Error("probe traffic reached stdout")
  }) as typeof process.stdout.write

  let batch: Awaited<ReturnType<typeof runProbeBatch>>
  try {
    batch = await runProbeBatch({
      ids: ["text.wrap"],
      out,
      geometryCorroboration: {
        status: "silent",
        query: {
          sequence: "\x1b[18t",
          outbound: "\x1b[18t\x1b[c",
          reason: "sentinel",
          raw: "\x1b[?62c",
          rawBase64: Buffer.from("\x1b[?62c").toString("base64"),
        },
      },
      ownedTerminal: geometryOwner(measured(24, 12)),
    })
  } finally {
    definition.termNeedsGeometry = original
  }
  expect(writes).toEqual([
    "\x1b[?7$p\x1b[c",
    "\x1b[1;1H",
    "\x1b[6n",
    "\x1b[1;1H\x1b[2K",
    "W".repeat(11),
    "\x1b[6n",
    "\x1b[1;1H\x1b[2K",
    `${"W".repeat(12)}X`,
    "\x1b[6n",
  ])
  expect(batch.observations.find((item) => item.featureId === "text.wrap")).toMatchObject({
    outcome: "supported",
    assertionType: "query_reply",
  })
  expect(batch.ungradedDiagnostics["text.wrap"]).toBeUndefined()
  expect(JSON.parse(batch.rawReplies["collector.geometry"]!)).toMatchObject({ corroboration: { status: "silent" } })
  const trace = JSON.parse(batch.rawReplies["text.wrap"]!) as { writes: string[]; queries: Array<{ sequence: string }> }
  expect(trace.writes).toEqual([
    "\x1b[1;1H",
    "\x1b[1;1H\x1b[2K",
    "W".repeat(11),
    "\x1b[1;1H\x1b[2K",
    `${"W".repeat(12)}X`,
  ])
  expect(trace.queries).toMatchObject([
    { sequence: "\x1b[?7$p\x1b[c" },
    { sequence: "\x1b[6n" },
    { sequence: "\x1b[6n" },
    { sequence: "\x1b[6n" },
  ])
})

it("binds an explicit DA1 observation to exact outbound and reply bytes", async () => {
  const received = Buffer.from([0xff, ...Buffer.from("\x1b[?62;4c")])
  process.stdout.write = (() => {
    process.stdin.emit("data", received)
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({ ids: ["device.primary-da"] })
  expect(batch.observations).toEqual([
    expect.objectContaining({
      featureId: "device.primary-da",
      outcome: "supported",
      assertionType: "query_reply",
      rawReplyRef: "device.primary-da",
    }),
  ])
  expect(batch.assertions).toEqual([
    expect.objectContaining({ featureId: "device.primary-da", kind: "positive", rawReplyRef: "device.primary-da" }),
  ])
  expect(batch.ungradedDiagnostics["device.primary-da"]).toBeUndefined()
  expect(batch.suiteComplete).toBe(false)
  expect(batch.rawReplies["device.primary-da"]).toBe(received.toString())
  const trace = JSON.parse(batch.rawReplies["device.primary-da.trace"]!) as {
    queries: Array<{ sequence: string; reason: string; rawBase64: string }>
  }
  expect(trace.queries).toMatchObject([{ sequence: "\x1b[c", reason: "reply", rawBase64: received.toString("base64") }])
})

it("keeps the reply trace when stdin emits outside the callback's async context", async () => {
  let wrote: (() => void) | undefined
  const outbound = new Promise<void>((resolve) => {
    wrote = resolve
  })
  process.stdout.write = (() => {
    wrote?.()
    return true
  }) as typeof process.stdout.write
  const pending = runProbeBatch({ ids: ["device.primary-da"] })
  await outbound
  process.stdin.emit("data", Buffer.from("\x1b[?62;4c"))
  const batch = await pending
  const trace = JSON.parse(batch.rawReplies["device.primary-da.trace"]!) as {
    events: Array<{ kind: string; sequence: string }>
  }
  expect(trace.events).toMatchObject([{ kind: "query", sequence: "\x1b[c" }])
})

it("records an opted-in query callback exception as collector error, never support", async () => {
  process.stdout.write = (() => {
    throw new Error("TTY write failed")
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({ ids: ["device.primary-da"] })
  expect(batch.results.filter((result) => ["device.primary-da"].includes(result.featureId))).toMatchObject([
    { status: "probe-invalid", featureId: "device.primary-da", reason: "TTY write failed" },
  ])
  expect(batch.ungradedDiagnostics["device.primary-da"]).toMatchObject({
    kind: "collector-error",
    message: "TTY write failed",
  })
  expect(batch.suiteComplete).toBe(false)
})

it("retains a generated region callback's early write failure as a collector error", async () => {
  verifiedBatchFixture()
  const definition = ALL_PROBES.find((item) => item.id === "editing.insert-chars")!
  process.stdout.write = (() => {
    throw new Error("Region TTY write failed")
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: [definition.id],
    ownedTerminal: geometryOwner(measured(24, 80)),
    capture: async () => {
      throw new Error("A frame cannot precede the failed region write")
    },
  })
  expect(batch.results.filter((result) => [definition.id].includes(result.featureId))).toMatchObject([
    { status: "probe-invalid", featureId: definition.id, reason: "Region TTY write failed" },
  ])
  expect(batch.ungradedDiagnostics[definition.id]).toMatchObject({ kind: "collector-error" })
  expect(batch.suiteComplete).toBe(false)
})

it("does not use a headless-only marker to grade an app callback exception", async () => {
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const originalApp = definition.termAssertionType
  const originalHeadless = definition.libAssertionType
  definition.termAssertionType = undefined
  definition.libAssertionType = "buffer_state"
  process.stdout.write = (() => {
    throw new Error("App TTY write failed")
  }) as typeof process.stdout.write
  try {
    const batch = await runProbeBatch({ ids: [definition.id] })
    expect(batch.observations).toEqual([])
    expect(batch.assertions).toEqual([])
    expect(batch.ungradedDiagnostics).toEqual({
      [definition.id]: { kind: "collector-error", name: "Error", message: "App TTY write failed" },
    })
  } finally {
    definition.termAssertionType = originalApp
    definition.libAssertionType = originalHeadless
  }
})

// A live fixture must bind its independent X11 events to the same feature trace, after pixel checkpoints.
it.each(["start", "read", "write"])(
  "keeps a transient clipboard %s custody refusal and stops the batch",
  async (site) => {
    verifiedBatchFixture()
    const refusal = new Error(`clipboard ${site} custody lost once`)
    let phase = "idle",
      refused = false
    const assertOwned = async () => {
      if (phase === site && !refused) {
        refused = true
        throw refusal
      }
    }
    const probes = ALL_PROBES.filter(
      (probe) => probe.term && probe.termNeedsGeometry && !probe.termNeedsDisposable,
    ).slice(0, 2)
    expect(probes).toHaveLength(2)
    const callbacks = vi.fn()
    const readGeometry = vi.fn(async () => measured(24, 80))
    const originals = probes.map((probe) => ({ probe, term: probe.term }))
    try {
      probes[0]!.term = async (probeSource) => {
        callbacks()
        return probeSource.withClipboardFixture!(async (fixture) => {
          await fixture.readText()
          await fixture.writeText("fixture")
          return { pass: true, observation: { outcome: "supported", assertionType: "query_reply" } }
        })
      }
      probes[1]!.term = async () => {
        callbacks()
        return { pass: true, observation: { outcome: "supported", assertionType: "query_reply" } }
      }
      await expect(
        runProbeBatch({
          ids: probes.map((probe) => probe.id),
          ownedTerminal: {
            ...geometryOwner(measured(24, 80)),
            readGeometry,
            clipboard: {
              profile: "allow",
              config: "fixture",
              permissions: "fixture",
              summary: "{}",
              assertOwned,
              readTitle: async () => {
                throw new Error("This clipboard fixture has no title reader")
              },
              dispose: async () => {},
              async withClipboardFixture(work, _trace, verify) {
                try {
                  phase = "start"
                  await verify()
                  return await work({
                    readText: async () => {
                      phase = "read"
                      await verify()
                      return "fixture"
                    },
                    writeText: async () => {
                      phase = "write"
                      await verify()
                    },
                  })
                } finally {
                  phase = "idle"
                }
              },
            },
          },
        }),
      ).rejects.toBe(refusal)
      expect(callbacks).toHaveBeenCalledTimes(1)
      // The catch must stop before the next probe's geometry callback, not only at the final check.
      expect(readGeometry).toHaveBeenCalledTimes(2)
    } finally {
      originals.forEach(({ probe, term }) => {
        probe.term = term
      })
    }
  },
)

it("stops the batch when modes.deccolm leaves a different stty size", async () => {
  verifiedBatchFixture()
  const deccolm = ALL_PROBES.find((probe) => probe.id === "modes.deccolm")
  const next = ALL_PROBES.find(
    (probe) => probe.term && probe.termNeedsGeometry && !probe.termNeedsDisposable && probe.id !== "modes.deccolm",
  )
  if (!deccolm?.term || !next?.term) throw new Error("missing geometry probes")
  const original = { term: deccolm.term, disposable: deccolm.termNeedsDisposable, next: next.term }
  const calls: string[] = []
  let reads = 0
  const readGeometry = vi.fn(async () => {
    reads += 1
    return reads === 1 ? measured(30, 120) : measured(30, 80)
  })
  try {
    deccolm.termNeedsDisposable = undefined
    deccolm.term = async () => {
      calls.push(deccolm.id)
      return { pass: true, observation: { outcome: "supported", assertionType: "query_reply" } }
    }
    next.term = async () => {
      calls.push(next.id)
      return { pass: true, observation: { outcome: "supported", assertionType: "query_reply" } }
    }
    const batch = await runProbeBatch({
      ids: [deccolm.id, next.id],
      ownedTerminal: geometryOwner(measured(30, 120), readGeometry),
    })
    expect(calls).toEqual(["modes.deccolm"])
    expect(readGeometry).toHaveBeenCalledTimes(2)
    expect(batch.results.find((result) => result.featureId === next.id)).toMatchObject({
      status: "probe-invalid",
      reason: "modes.deccolm left the terminal at 30x80; it started at 30x120",
    })
  } finally {
    deccolm.term = original.term
    deccolm.termNeedsDisposable = original.disposable
    next.term = original.next
  }
})

const defaultClipboardCases: Array<{
  name: string
  featureId?: string
  profile?: LinuxClipboardAdapter["profile"]
  subject?: { kind: "term" | "lib" | "mux"; id: string; os: string }
  targetless?: boolean
  mismatched?: boolean
  unowned?: boolean
  attached?: boolean
  attachedMux?: "tmux" | "screen"
  refuseWrite?: boolean
  nullMode2004?: boolean
  pasteboard?: "darwin"
  /** The receipt owns no PRIMARY baseline, so a PRIMARY route must refuse loudly. */
  noPrimary?: boolean
  eligible: boolean
}> = [
  { name: "direct Kitty default paste", eligible: true },
  {
    name: "direct Alacritty default paste",
    subject: { kind: "term", id: "alacritty", os: "linux" },
    eligible: true,
  },
  {
    name: "direct Ghostty default paste",
    subject: { kind: "term", id: "ghostty", os: "linux" },
    eligible: true,
  },
  {
    name: "direct WezTerm default paste",
    subject: { kind: "term", id: "wezterm", os: "linux" },
    eligible: true,
  },
  {
    name: "direct xterm default paste through owned PRIMARY and Shift+Insert",
    subject: { kind: "term", id: "xterm", os: "linux" },
    eligible: true,
  },
  {
    name: "direct xterm default paste refuses when the receipt owns no PRIMARY",
    subject: { kind: "term", id: "xterm", os: "linux" },
    noPrimary: true,
    eligible: false,
  },
  {
    name: "unreviewed Linux app default paste stays gated",
    subject: { kind: "term", id: "foot", os: "linux" },
    eligible: false,
  },
  {
    name: "verified tmux default paste",
    subject: { kind: "mux", id: "tmux", os: "linux" },
    attachedMux: "tmux",
    eligible: true,
  },
  {
    name: "verified Screen default paste with blind 2004 setup",
    subject: { kind: "mux", id: "screen", os: "linux" },
    attachedMux: "screen",
    nullMode2004: true,
    eligible: true,
  },
  { name: "default OSC52 write", featureId: "extensions.osc52-write", eligible: true },
  {
    name: "default OSC52 write on other Linux app",
    featureId: "extensions.osc52-write",
    subject: { kind: "term", id: "ghostty", os: "linux" },
    eligible: true,
  },
  {
    name: "default OSC52 write on xterm refusing write",
    featureId: "extensions.osc52-write",
    subject: { kind: "term", id: "xterm", os: "linux" },
    refuseWrite: true,
    eligible: true,
  },
  {
    name: "verified tmux default OSC52 write",
    featureId: "extensions.osc52-write",
    subject: { kind: "mux", id: "tmux", os: "linux" },
    attachedMux: "tmux",
    refuseWrite: true,
    eligible: true,
  },
  {
    name: "verified Screen default OSC52 write",
    featureId: "extensions.osc52-write",
    subject: { kind: "mux", id: "screen", os: "linux" },
    attachedMux: "screen",
    refuseWrite: true,
    eligible: true,
  },
  {
    name: "verified tmux default OSC52 read",
    featureId: "extensions.osc52-read",
    subject: { kind: "mux", id: "tmux", os: "linux" },
    attachedMux: "tmux",
    refuseWrite: true,
    eligible: true,
  },
  {
    name: "verified Screen default OSC52 read",
    featureId: "extensions.osc52-read",
    subject: { kind: "mux", id: "screen", os: "linux" },
    attachedMux: "screen",
    refuseWrite: true,
    eligible: true,
  },
  {
    name: "verified tmux default OSC52 roundtrip",
    featureId: "extensions.osc52-clipboard",
    subject: { kind: "mux", id: "tmux", os: "linux" },
    attachedMux: "tmux",
    refuseWrite: true,
    eligible: true,
  },
  {
    name: "verified Screen default OSC52 roundtrip",
    featureId: "extensions.osc52-clipboard",
    subject: { kind: "mux", id: "screen", os: "linux" },
    attachedMux: "screen",
    refuseWrite: true,
    eligible: true,
  },
  ...["kitty", "ghostty", "alacritty", "wezterm", "xterm"].flatMap((id) => [
    {
      name: `default OSC52 read stays gated on ${id}`,
      featureId: "extensions.osc52-read",
      subject: { kind: "term" as const, id, os: "linux" },
      eligible: false,
    },
    {
      name: `default OSC52 roundtrip stays gated on ${id}`,
      featureId: "extensions.osc52-clipboard",
      subject: { kind: "term" as const, id, os: "linux" },
      eligible: false,
    },
  ]),
  {
    name: "unverified mux subject without attachment proof",
    subject: { kind: "mux", id: "tmux", os: "linux" },
    eligible: false,
  },
  {
    name: "default OSC52 write on unverified mux subject",
    featureId: "extensions.osc52-write",
    subject: { kind: "mux", id: "tmux", os: "linux" },
    eligible: false,
  },
  {
    name: "mux subject with mismatched attachment proof",
    subject: { kind: "mux", id: "screen", os: "linux" },
    attachedMux: "tmux",
    eligible: false,
  },
  {
    // #33058 (@cto d0e1a960): Screen answers no 2004 mode report, so the row is decided by the same
    // disposable paste read as clipboard-paste.
    name: "Screen modes.bracketed-paste decides by the disposable paste effect read",
    featureId: "modes.bracketed-paste",
    subject: { kind: "mux", id: "screen", os: "linux" },
    attachedMux: "screen",
    nullMode2004: true,
    eligible: true,
  },
  { name: "library subject", subject: { kind: "lib", id: "kitty", os: "linux" }, eligible: false },
  { name: "other OS", subject: { kind: "term", id: "kitty", os: "darwin" }, eligible: false },
  {
    name: "hosted darwin OSC52 write",
    featureId: "extensions.osc52-write",
    subject: { kind: "term", id: "iterm2", os: "darwin" },
    pasteboard: "darwin" as const,
    eligible: true,
  },
  { name: "targetless receipt", targetless: true, eligible: false },
  {
    name: "default OSC52 write on targetless receipt",
    featureId: "extensions.osc52-write",
    targetless: true,
    eligible: false,
  },
  { name: "mismatched declaration", mismatched: true, eligible: false },
  { name: "unowned output", unowned: true, eligible: false },
  { name: "attached outer Kitty", attached: true, eligible: false },
  {
    name: "default OSC52 write with attached outer Kitty",
    featureId: "extensions.osc52-write",
    attached: true,
    eligible: false,
  },
  { name: "existing allow profile without target", profile: "allow", targetless: true, eligible: true },
  { name: "existing deny-read profile without target", profile: "deny-read", targetless: true, eligible: true },
]

it.each(defaultClipboardCases)("keeps clipboard fixture routing scoped to $name", async (scenario) => {
  verifiedBatchFixture()
  if (scenario.unowned) vi.mocked(terminalOwnership.ownedTerminalVerifiedFor).mockReturnValue(false)
  const subject = scenario.subject ?? { kind: "term" as const, id: "kitty", os: "linux" }
  const receipt = validContainerReceipt()
  receipt.declaredTarget = {
    kind: subject.kind === "term" ? "app" : subject.kind === "lib" ? "headless" : "mux",
    id: scenario.mismatched ? "ghostty" : subject.id,
    version: "0.49.2",
    os: subject.os,
  }
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const receiptPath = join(directory, "host-measured.json")
  writeFileSync(receiptPath, JSON.stringify(scenario.targetless ? hostedLaunchReceipt() : receipt))
  process.env.TERMINFO_DISPOSABLE_RECEIPT = receiptPath
  const writes: string[] = []
  let bracketedPaste = false
  const baseline = "owned clipboard baseline"
  let clipboardText = baseline
  process.stdout.write = ((text: string) => {
    writes.push(text)
    if (text === "\x1b[?2004h") bracketedPaste = true
    if (text === "\x1b[?2004l") bracketedPaste = false
    if (text.includes("\x1b[?2004$p")) {
      const reply = scenario.nullMode2004 ? "\x1b[?1;2c" : `\x1b[?2004;${bracketedPaste ? 1 : 2}$y\x1b[?1;2c`
      queueMicrotask(() => process.stdin.emit("data", Buffer.from(reply)))
    }
    if (text.includes("\x1b]52;c;?\x07") && text.includes("\x1b[c")) {
      queueMicrotask(() => process.stdin.emit("data", Buffer.from("\x1b[?1;2c")))
    } else if (text.startsWith("\x1b]52;c;") && !scenario.refuseWrite) {
      clipboardText = atob(/\x1b\]52;c;([^\x07]+)\x07/.exec(text)?.[1] ?? "")
    }
    if (text === "\x1b[6n") {
      queueMicrotask(() => process.stdin.emit("data", Buffer.from("\x1b[1;1R")))
    }
    return true
  }) as typeof process.stdout.write
  const attachedMux = scenario.attachedMux ?? (scenario.attached ? "tmux" : undefined)
  const baseTransaction = createClipboardTransaction(
    baseline,
    {
      async readText(trace, kind, verify) {
        await verify()
        trace({ kind, at: new Date().toISOString(), length: clipboardText.length })
        return clipboardText
      },
      async writeText(text, trace, kind, verify) {
        await verify()
        clipboardText = text
        trace({ kind, at: new Date().toISOString(), length: text.length })
      },
    },
    { writeDeadlineMs: 25, writePollMs: 5 },
  )
  const isXtermPaste =
    (scenario.featureId ?? "extensions.clipboard-paste") === "extensions.clipboard-paste" &&
    subject.kind === "term" &&
    subject.id === "xterm" &&
    subject.os === "linux"
  const primaryBaseline = "owned primary baseline"
  let primaryText = primaryBaseline
  const primaryTransaction = createClipboardTransaction(primaryBaseline, {
    async readText(trace, kind, verify) {
      await verify()
      trace({ kind, at: new Date().toISOString(), length: primaryText.length })
      return primaryText
    },
    async writeText(text, trace, kind, verify) {
      await verify()
      primaryText = text
      trace({ kind, at: new Date().toISOString(), length: text.length })
    },
  })
  const withPrimaryFixture = vi.fn(primaryTransaction)
  const withClipboardFixture = vi.fn(((work, trace, verify) =>
    baseTransaction(
      (fixture) => work(attachedMux === "tmux" ? { ...fixture, tmuxSetClipboard: "external" } : fixture),
      trace,
      verify,
    )) as LinuxClipboardAdapter["withClipboardFixture"])
  const processIdentity = { pid: 42, startTicks: "1", ttyRdev: 34816 }
  const muxAttachmentProof = attachedMux
    ? {
        platform: "linux" as const,
        mux: attachedMux,
        bootId: "00000000-0000-0000-0000-000000000001",
        receiptSha256: "a".repeat(64),
        launchRunId: "b".repeat(32),
        captureRunId: "a".repeat(32),
        preflightCollector: processIdentity,
        outerShell: processIdentity,
        outerTerminal: processIdentity,
        collector: processIdentity,
        attachedClient: processIdentity,
        chain: [{ ...processIdentity, executablePath: `/fixture/${attachedMux}` }],
        executable: {
          path: `/fixture/${attachedMux}`,
          sha256: "c".repeat(64),
          version: attachedMux === "tmux" ? "3.8" : "5.0.2",
        },
        config: { path: "/fixture/empty.conf", sha256: "d".repeat(64) },
        socketPath: `/fixture/${attachedMux}.sock`,
        session: "fixture",
      }
    : undefined
  const clipboard: LinuxClipboardAdapter = {
    profile: scenario.profile ?? "default",
    config: "fixture",
    permissions: "clipboard: read=ask,write=allow; OSC52: write=run,read=not-run",
    summary: "{}",
    ...(scenario.pasteboard && { pasteboard: scenario.pasteboard }),
    assertOwned: async () => {},
    readTitle: async () => {
      throw new Error("This clipboard fixture has no title reader")
    },
    dispose: async () => {},
    withClipboardFixture,
    ...(!scenario.noPrimary && { withPrimaryFixture }),
    ...(muxAttachmentProof && { muxAttachmentProof }),
  }
  // Each key pastes the selection its real binding reads: Shift+Insert PRIMARY, Ctrl+Shift+V CLIPBOARD.
  const injectKey = vi.fn(async (keys: string) => {
    const pasted = keys === "shift+Insert" ? primaryText : clipboardText
    const text = keys === "a" ? "a" : bracketedPaste ? `\x1b[200~${pasted}\x1b[201~` : pasted
    process.stdin.emit("data", Buffer.from(text))
  })
  const featureId = scenario.featureId ?? "extensions.clipboard-paste"
  const isOsc52 = featureId.startsWith("extensions.osc52-")
  const isOsc52WriteOrRoundtrip = featureId === "extensions.osc52-write" || featureId === "extensions.osc52-clipboard"
  const isOsc52Read = featureId === "extensions.osc52-read"
  const appDeclarations =
    subject.kind === "term" && subject.id === "xterm"
      ? appSemanticDeclarations({ kind: "term", id: "xterm", version: "411", os: "linux" })
      : undefined
  const collected = runProbeBatch({
    ids: [featureId],
    subject,
    captureRunId: "a".repeat(32),
    ownedTerminal: { ...geometryOwner(measured(24, 80)), clipboard, ...(muxAttachmentProof && { muxAttachmentProof }) },
    input: { injectKey, injectClick: async () => {} },
    ...(appDeclarations && { appDeclarations }),
  })
  if (scenario.mismatched) {
    await expect(collected).rejects.toThrow(/disagree/)
  } else if (scenario.noPrimary) {
    const batch = await collected
    expect(JSON.stringify(batch.results.find((result) => result.featureId === featureId))).toContain(
      "Owned PRIMARY selection is absent from this run's clipboard receipt",
    )
  } else {
    const batch = await collected
    const expectedOutcome = scenario.refuseWrite ? "unsupported" : "supported"
    const expectedStatus = scenario.eligible
      ? expectedOutcome
      : featureId === "modes.bracketed-paste"
        ? "probe-invalid"
        : "probe-todo"
    expect(batch.results.find((result) => result.featureId === featureId)?.status).toBe(expectedStatus)
    if (scenario.eligible) {
      const expectedAssertionType = isOsc52Read ? "query_reply" : isOsc52WriteOrRoundtrip ? "clipboard" : "input_bytes"
      expect(batch.observations).toContainEqual(
        expect.objectContaining({
          featureId,
          outcome: expectedOutcome,
          assertionType: expectedAssertionType,
        }),
      )
      if (featureId === "extensions.clipboard-paste") {
        // The row says how it was measured: selection and key are in its evidence (@cto a4ec8fe2 condition 2).
        const route = isXtermPaste
          ? { selection: "primary", key: "shift+Insert" }
          : { selection: "clipboard", key: "ctrl+shift+v" }
        expect(batch.assertions.find((assertion) => assertion.featureId === featureId)).toMatchObject({
          action: `clipboard-paste:${route.selection}:${route.key}`,
        })
        expect(batch.assertions.find((assertion) => assertion.featureId === featureId)?.observed).toContain(
          `"selection":"${route.selection}","key":"${route.key}"`,
        )
      }
      if (scenario.nullMode2004 && featureId === "extensions.clipboard-paste") {
        expect(batch.observations.find((obs) => obs.featureId === featureId)?.note).toContain("set blind")
      }
      if (attachedMux === "tmux" && isOsc52) {
        expect(batch.observations.find((obs) => obs.featureId === featureId)?.note).toContain("set-clipboard=external")
      }
      const trace = JSON.parse(batch.rawReplies[featureId]!) as { clipboard: Array<{ kind: string }> }
      if (isOsc52WriteOrRoundtrip && scenario.refuseWrite) {
        const kinds = trace.clipboard.map((event) => event.kind)
        expect(kinds.slice(0, 3)).toEqual(["clipboard-read", "clipboard-read", "clipboard-read"])
        expect(kinds.slice(-2)).toEqual(["clipboard-restore", "clipboard-verify"])
        expect(kinds.slice(0, -2).every((kind) => kind === "clipboard-read")).toBe(true)
      } else {
        expect(trace.clipboard.map((event) => event.kind)).toEqual(
          isOsc52WriteOrRoundtrip
            ? ["clipboard-read", "clipboard-read", "clipboard-restore", "clipboard-verify"]
            : ["clipboard-read", "clipboard-write", "clipboard-restore", "clipboard-verify"],
        )
      }
      const draft = asRun(batch)
      const decoded = decodeCollectorDraft("owned-clipboard.json", JSON.stringify(draft), manifest, sourceRevision).run
      expect(decoded.results.find((row) => row.featureId === featureId)?.status).toBe(expectedOutcome)
      expect(decoded.assertions).toContainEqual(
        expect.objectContaining({
          featureId,
          assertionType: expectedAssertionType,
          kind: scenario.refuseWrite ? "negative" : "positive",
          rawReplyRef: featureId,
        }),
      )
      const parsed = parseRun(
        "owned-clipboard.json",
        JSON.stringify(draft),
        [featureId],
        new Map([[manifest.probeHash, manifest]]),
      )
      expect(parsed.results?.find((row) => row.featureId === featureId)).toMatchObject({
        featureId,
        status: expectedOutcome,
        assertionType: expectedAssertionType,
        rawReplyRef: featureId,
      })
      expect(parsed.assertions).toContainEqual(
        expect.objectContaining({
          featureId,
          assertionType: expectedAssertionType,
          kind: scenario.refuseWrite ? "negative" : "positive",
          rawReplyRef: featureId,
        }),
      )
    } else {
      expect(batch.assertions).toEqual([])
    }
  }
  expect(withClipboardFixture).toHaveBeenCalledTimes(scenario.eligible && !isXtermPaste ? 1 : 0)
  expect(withPrimaryFixture).toHaveBeenCalledTimes(scenario.eligible && isXtermPaste ? 1 : 0)
  const pasteKey = isXtermPaste ? "shift+Insert" : "ctrl+shift+v"
  expect(injectKey.mock.calls.map(([keys]) => keys)).toEqual(
    scenario.eligible && !isOsc52 ? ["a", pasteKey, pasteKey, pasteKey] : [],
  )
  expect(clipboardText).toBe(baseline)
  expect(primaryText).toBe(primaryBaseline)
  if (scenario.eligible && isOsc52) {
    expect(writes.join("")).toContain("\x1b]52;c;")
  } else {
    expect(writes.join("")).not.toContain("\x1b]52;")
  }
})

it("runs owned OSC 52 after pixels and retains timestamped independent clipboard operations", async () => {
  verifiedBatchFixture()
  const writes: string[] = []
  const order: string[] = []
  const baseline = "owned OSC52 baseline"
  let clipboardText = baseline
  process.stdout.write = ((text: string) => {
    writes.push(text)
    // No SGR readback: answer its DA1 sentinel so this pixel-ordering case does not wait for a timeout.
    if (text === "\x1bP$qm\x1b\\\x1b[c") process.stdin.emit("data", Buffer.from("\x1b[?1;2c"))
    if (text.startsWith("\x1b]52;c;")) {
      order.push("osc52")
      clipboardText = atob(/\x1b\]52;c;([^\x07]+)\x07/.exec(text)?.[1] ?? "")
    }
    if (text === "\x1b[6n") process.stdin.emit("data", Buffer.from("\x1b[1;1R"))
    return true
  }) as typeof process.stdout.write
  // sgr.blink samples on a real 7500 ms schedule; fake timers keep that wall out of this test.
  vi.useFakeTimers()
  const batch = await (async () => {
    try {
      const [collected] = await Promise.all([
        runProbeBatch({
          ids: ["extensions.osc52-write", "sgr.blink"],
          capture: async ({ role, label }) => {
            order.push(`capture-${role}`)
            return { frame: { role, label, capturedAt: Date.now(), ref: `sha256:${"a".repeat(64)}` }, trace: {} }
          },
          ownedTerminal: {
            ...geometryOwner(measured(24, 80)),
            clipboard: {
              profile: "allow",
              config: "fixture",
              permissions: "fixture",
              summary: "{}",
              assertOwned: async () => {},
              readTitle: async () => {
                throw new Error("This clipboard fixture has no title reader")
              },
              dispose: async () => {},
              withClipboardFixture: createClipboardTransaction(baseline, {
                async readText(trace, kind, verify) {
                  await verify()
                  trace({
                    kind,
                    at: new Date().toISOString(),
                    sha256: createHash("sha256").update(clipboardText).digest("hex"),
                    length: clipboardText.length,
                  })
                  return clipboardText
                },
                async writeText(text, trace, kind, verify) {
                  await verify()
                  clipboardText = text
                  trace({
                    kind,
                    at: new Date().toISOString(),
                    sha256: createHash("sha256").update(text).digest("hex"),
                    length: text.length,
                  })
                },
              }),
            },
          },
        }),
        vi.runAllTimersAsync(),
      ])
      return collected
    } finally {
      vi.useRealTimers()
    }
  })()
  expect(order).toEqual(["capture-control", ...Array.from({ length: 16 }, () => "capture-target"), "osc52"])
  expect(batch.observations.find((item) => item.featureId === "extensions.osc52-write")).toMatchObject({
    outcome: "supported",
    rawReplyRef: "extensions.osc52-write",
  })
  const trace = JSON.parse(batch.rawReplies["extensions.osc52-write"]!) as {
    clipboard: Array<{ kind: string; at: string }>
  }
  expect(trace.clipboard.map((event) => event.kind)).toEqual([
    "clipboard-read",
    "clipboard-read",
    "clipboard-restore",
    "clipboard-verify",
  ])
  expect(clipboardText).toBe(baseline)
  expect(trace.clipboard.every((event) => !Number.isNaN(Date.parse(event.at)))).toBe(true)
})

it("records failed clipboard restoration as collector error rather than retaining callback success", async () => {
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["extensions.osc52-write"],
    ownedTerminal: {
      ...geometryOwner(noGeometry),
      clipboard: {
        profile: "allow",
        config: "fixture",
        permissions: "fixture",
        summary: "{}",
        assertOwned: async () => {},
        readTitle: async () => {
          throw new Error("This clipboard fixture has no title reader")
        },
        dispose: async () => {},
        async withClipboardFixture(_work, trace) {
          trace({ kind: "clipboard-restore", at: new Date().toISOString(), sha256: "b".repeat(64), length: 8 })
          throw new Error("Owned clipboard restoration failed")
        },
      },
    },
  })
  expect(batch.results.filter((result) => ["extensions.osc52-write"].includes(result.featureId))).toMatchObject([
    { status: "probe-invalid", featureId: "extensions.osc52-write", rawReplyRef: "extensions.osc52-write" },
  ])
  expect(batch.suiteComplete).toBe(false)
})

// #30932 AC3: a TTY-only log loses the source's optional capture method. The saved-rendition
// reference now needs pixel geometry before capture; replay must retain that same source shape
// and named refusal rather than taking a different no-capture path.
it("retains SGR capture source shape and pixel-geometry refusal for strict offline replay", async (context) => {
  verifiedBatchFixture()
  const writes: string[] = []
  let sgrState = "0"
  process.stdout.write = ((value: string) => {
    writes.push(value)
    if (value === "\x1b[0m") sgrState = "0"
    if (value === "\x1b[1;3;4m") sgrState = "1;3;4"
    if (value.includes("\x1bP$qm")) {
      process.stdin.emit("data", Buffer.from(`\x1bP1$r${sgrState}m\x1b\\\x1b[?1;2c`))
    }
    return true
  }) as typeof process.stdout.write
  const capture = vi.fn(async () => {
    throw new Error("Missing pixel geometry must not invoke capture")
  })
  vi.useFakeTimers()
  const batch = await (async () => {
    try {
      const [collected] = await Promise.all([
        runProbeBatch({
          ids: ["sgr.reset"],
          subject: { kind: "term", id: "kitty", os: "linux" },
          ownedTerminal: geometryOwner(measured(24, 80)),
          capture,
        }),
        vi.runAllTimersAsync(),
      ])
      return collected
    } finally {
      vi.useRealTimers()
    }
  })()
  expect(batch.results.find(({ featureId }) => featureId === "sgr.reset")).toMatchObject({
    status: "probe-invalid",
    reason: expect.stringContaining("no cell size can be mapped"),
  })
  // The persistence boundary must accept a terminal query-reply capture without
  // inventing an erase buffer/geometry manifest or a headless runtime identity.
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const draft = asRun(batch)
  if (!draft.subject || !draft.identity || !draft.measuredAt || !draft.origin) throw new Error("Incomplete fixture")
  const path = saveDaemonProbeRun(
    { ...draft, subject: draft.subject, identity: draft.identity, measuredAt: draft.measuredAt, origin: draft.origin },
    directory,
  )
  const bytes = readFileSync(path)
  const source = {
    kind: "trace" as const,
    trace: { path: basename(path), sha256: createHash("sha256").update(bytes).digest("hex") },
    captureRunId: draft.runId,
    captureSuiteId: draft.suiteId,
    captureSourceRevision: draft.sourceRevision,
  }
  const expected = { manifest, sourceRevision, subject: draft.subject }
  const { capture: validated } = readProbeCapture(directory, source, expected)
  const log = readCallLog(JSON.parse(validated.rawReplies["sgr.reset.callLog"]!))
  for (const invalid of [
    { ...source, captureRunId: "other-capture" },
    { ...source, captureSuiteId: "other-suite" },
    { ...source, captureSourceRevision: "other-source" },
    { ...source, trace: { ...source.trace, sha256: "0".repeat(64) } },
    { ...source, trace: { ...source.trace, path: "../outside.json" } },
  ]) {
    expect(() => readProbeCapture(directory, invalid, expected)).toThrow()
  }
  expect(() =>
    readProbeCapture(directory, source, { ...expected, subject: { ...expected.subject, version: "other" } }),
  ).toThrow()
  expect(() => readProbeCapture(directory, source, { ...expected, sourceRevision: "other-source" })).toThrow(
    /binding differs/,
  )
  const replay = withCallLog<TermProbeSource>(null, { mode: "replay", log })
  expect(typeof replay.context.capture).toBe("function")
  const callback = ALL_PROBES.find(({ id }) => id === "sgr.reset")?.term
  if (!callback) throw new Error("Missing SGR reset callback")
  const beforeReplay = writes.length
  const result = await callback(replay.context)
  replay.finish()
  expect(result.observation).toBeUndefined()
  expect(result.notTested).toBeUndefined()
  expect(result.tests).toMatchObject([
    { id: "criterion", status: "probe-invalid", reason: expect.stringContaining("no cell size can be mapped") },
  ])
  expect(writes).toHaveLength(beforeReplay)
  expect(capture).not.toHaveBeenCalled()
  const nativeIdentity = vi.spyOn(headlessIdentity, "headlessRuntimeIdentity").mockImplementation(async () => {
    throw new Error("Offline SGR assertion attempted native runtime discovery")
  })
  try {
    const record = await runEraseReplay(context, { directory, source, expected, featureId: "sgr.reset" })
    expect(record.assertions).toHaveLength(2)
    expect(new Set(record.assertions.map(({ runId }) => runId)).size).toBe(2)
    const executingManifest = derivedSuiteManifest()
    const executingSourceRevision = sourceSuiteEnvironment().TERMINFO_SOURCE_REVISION
    for (const assertion of record.assertions) {
      expect(assertion.runId).not.toBe(draft.runId)
      expect(assertion.source).toEqual(source)
      expect(assertion.subject).toEqual(draft.subject)
      const replayed = assertion.results.find(({ featureId }) => featureId === "sgr.reset")
      expect(replayed).toMatchObject({
        status: "probe-invalid",
        reason: expect.stringContaining("no cell size can be mapped"),
      })
      // An unavailable pixel mapping records the failure, without a deciding observation type.
      expect(replayed?.assertionType).toBeUndefined()
      expect(replayed?.rawReplyRef).toBeUndefined()
      expect(replayed?.tests.map(({ rawReplyRef }) => rawReplyRef)).toEqual([undefined])
      const assertionPath = record.files.find((file) => file.endsWith(assertion.runId + ".assertion.draft.json"))
      if (!assertionPath) throw new Error("Missing persisted assertion")
      expect(assertion.suiteId).toBe(executingManifest.probeHash)
      expect(assertion.sourceRevision).toBe(executingSourceRevision)
      expect(assertion.sourceRevision).not.toBe(draft.sourceRevision)
      expect(
        parseRun(
          assertionPath,
          readFileSync(assertionPath, "utf8"),
          executingManifest.catalogIds!,
          new Map([[executingManifest.probeHash, executingManifest]]),
        ).source,
      ).toEqual(source)
    }
    // A syntactically valid recording can still be incomplete for this callback.
    // These reach the persisted runner, which the core recorder tests cannot cover.
    for (const fault of [
      "missing-log",
      "tty-root",
      "missing-call",
      "unconsumed-call",
      "missing-dependency",
      "resized",
      "non-live",
    ] as const) {
      const rawReplies = { ...draft.rawReplies }
      const stored = JSON.parse(rawReplies["sgr.reset.callLog"]!) as {
        root: { entries: Array<[string, unknown]> }
        calls: Array<Record<string, unknown>>
      }
      if (fault === "missing-log") delete rawReplies["sgr.reset.callLog"]
      else {
        if (fault === "tty-root") stored.root.entries = stored.root.entries.filter(([key]) => key !== "kind")
        if (fault === "missing-call") stored.calls.pop()
        if (fault === "unconsumed-call") {
          const last = stored.calls.at(-1)
          if (!last) throw new Error("Fixture has no ordered calls")
          stored.calls.push({ ...last, id: stored.calls.length })
        }
        rawReplies["sgr.reset.callLog"] = JSON.stringify(stored)
      }
      if (fault === "resized") {
        const geometry = JSON.parse(rawReplies["collector.geometry"]!) as { checks: [{ post: { cols: number } }] }
        geometry.checks[0].post.cols = 79
        rawReplies["collector.geometry"] = JSON.stringify(geometry)
      }
      const invalid = {
        ...draft,
        subject: draft.subject,
        identity: draft.identity,
        measuredAt: draft.measuredAt,
        origin: draft.origin,
        runId: randomUUID(),
        rawReplies,
        screenshotRefs: fault === "missing-dependency" ? [`sha256:${"d".repeat(64)}`] : [],
      }
      const invalidPath = saveDaemonProbeRun(invalid, directory)
      if (fault === "non-live") {
        const nonLive = JSON.parse(readFileSync(invalidPath, "utf8")) as { source: typeof source }
        nonLive.source = source
        writeFileSync(invalidPath, JSON.stringify(nonLive))
      }
      const invalidSource = {
        ...source,
        captureRunId: invalid.runId,
        trace: {
          path: basename(invalidPath),
          sha256: createHash("sha256").update(readFileSync(invalidPath)).digest("hex"),
        },
      }
      await expect(
        runEraseReplay(context, { directory, source: invalidSource, expected, featureId: "sgr.reset" }),
        fault,
      ).rejects.toThrow(fault === "tty-root" ? /SGR source shape does not match its live capture/ : /SGR replay:/)
      expect(context.task.meta.terminfoErase?.failureResults, fault).toMatchObject([
        { featureId: "sgr.reset", status: "probe-invalid" },
      ])
    }
    await expect(
      runEraseReplay(context, { directory, source, expected, featureId: "extensions.osc52-write" }),
    ).rejects.toThrow(/SGR replay:.*Missing selected SGR/)
    await expect(
      runEraseReplay(context, {
        directory,
        source: { ...source, trace: { ...source.trace, path: "missing-trace.json" } },
        expected,
        featureId: "sgr.reset",
      }),
    ).rejects.toThrow(/SGR replay:.*ENOENT/)
    // A batch may retain another probe's blob beside this query-only log. Its
    // existing manifest binds the bytes; no pixel observation is fabricated here.
    const blob = Buffer.from("unrelated retained capture dependency")
    const digest = createHash("sha256").update(blob).digest("hex")
    const blobRef = `sha256:${digest}`
    writeFileSync(join(directory, blobRef), blob)
    const bound = {
      ...draft,
      subject: draft.subject,
      identity: draft.identity,
      measuredAt: draft.measuredAt,
      origin: draft.origin,
      runId: randomUUID(),
      screenshotRefs: [blobRef],
      rawReplies: {
        ...draft.rawReplies,
        "collector.traceManifest": JSON.stringify({
          captureKind: "buffer_state",
          geometry: { rows: 24, cols: 80 },
          blobs: [{ path: blobRef, sha256: digest }],
        }),
      },
    }
    const boundPath = saveDaemonProbeRun(bound, directory)
    const boundSource = {
      ...source,
      captureRunId: bound.runId,
      trace: { path: basename(boundPath), sha256: createHash("sha256").update(readFileSync(boundPath)).digest("hex") },
    }
    // A bound blob must exist; a digest/path in the manifest alone is not retained evidence.
    const missingBlobRef = `sha256:${"e".repeat(64)}`
    const missingBlob = {
      ...bound,
      runId: randomUUID(),
      screenshotRefs: [missingBlobRef],
      rawReplies: {
        ...bound.rawReplies,
        "collector.traceManifest": JSON.stringify({ blobs: [{ path: missingBlobRef, sha256: digest }] }),
      },
    }
    const missingBlobPath = saveDaemonProbeRun(missingBlob, directory)
    await expect(
      runEraseReplay(context, {
        directory,
        source: {
          ...source,
          captureRunId: missingBlob.runId,
          trace: {
            path: basename(missingBlobPath),
            sha256: createHash("sha256").update(readFileSync(missingBlobPath)).digest("hex"),
          },
        },
        expected,
        featureId: "sgr.reset",
      }),
    ).rejects.toThrow(/SGR replay:.*ENOENT/)
    const boundRecord = await runEraseReplay(context, {
      directory,
      source: boundSource,
      expected,
      featureId: "sgr.reset",
    })
    expect(boundRecord.files).toContain(join(directory, blobRef))
    expect(
      boundRecord.assertions.map(({ results }) => results.find(({ featureId }) => featureId === "sgr.reset")?.status),
    ).toEqual(["probe-invalid", "probe-invalid"])
    expect(nativeIdentity).not.toHaveBeenCalled()
    expect(writes).toHaveLength(beforeReplay)
    expect(capture).not.toHaveBeenCalled()
  } finally {
    nativeIdentity.mockRestore()
  }
  expect(readFileSync(path)).toEqual(bytes)
})

// AC1/AC3: retain the unchanged blink capture/replay path; the attribute kind has its own deciding tests.
// Images belong to the callback's run before it is sealed. Existing
// transport tests only observe replies and cannot detect a detached screenshot.
it("retains same-callback control and target frames without declaring visual support", async (context) => {
  verifiedBatchFixture()
  // sgr.blink samples on a real 7500 ms schedule in the live callback and both replays below;
  // fake timers drive those waits so this retention contract costs no wall time per pass.
  const withFakeTimers = async <T>(operation: () => Promise<T>): Promise<T> => {
    vi.useFakeTimers()
    try {
      const [value] = await Promise.all([operation(), vi.runAllTimersAsync()])
      return value
    } finally {
      vi.useRealTimers()
    }
  }
  const writes: string[] = []
  process.stdout.write = ((value: string) => {
    writes.push(value)
    if (value.includes("\x1b[6n")) process.stdin.emit("data", Buffer.from("\x1b[1;2R"))
    return true
  }) as typeof process.stdout.write
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const artifacts = join(directory, "artifacts")
  mkdirSync(artifacts)
  const blobs = new Map<string, { path: string; sha256: string }>()
  const frames: ObservationFrame[] = []
  const checkpoints: Array<{ featureId: string; role: string; writes: string }> = []
  const batch = await withFakeTimers(() =>
    runProbeBatch({
      ids: ["sgr.blink"],
      ownedTerminal: geometryOwner(measured(24, 80)),
      capture: async ({ featureId, role, label }) => {
        checkpoints.push({ featureId, role, writes: writes.join("") })
        const png = Buffer.from(
          "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==",
          "base64",
        )
        const captured = await finishCapture({
          directory: artifacts,
          onRetained: ({ path, sha256 }) => blobs.set(path, { path: "artifacts/" + basename(path), sha256 }),
          checkpoint: { featureId, role, label },
          source: { format: "png", bytes: png, width: 1, height: 1, capturedAt: checkpoints.length },
          png,
          decoded: { width: 1, height: 1, rgba: new Uint8Array([255, 0, 0, 255]) },
          origin: { origin: { x: 0, y: 0 }, basis: "whole-frame fixture" },
          trace: {},
        })
        frames.push(captured.frame)
        return captured
      },
    }),
  )
  expect(checkpoints.map(({ featureId, role }) => ({ featureId, role }))).toEqual([
    { featureId: "sgr.blink", role: "control" },
    ...Array.from({ length: 16 }, () => ({ featureId: "sgr.blink", role: "target" })),
  ])
  // The DECRQSS readback attempt writes the styled sequence to set the state it queries, so assert
  // on the rendered sample: the control frame renders it unstyled, the target frame styled.
  const styledSample = "\x1b[5mAaBb 0123456789 - terminal text"
  expect(checkpoints[0]?.writes).not.toContain(styledSample)
  expect(checkpoints[1]?.writes).toContain(styledSample)
  expect(batch.screenshotRefs).toEqual([...new Set(frames.map(({ ref }) => ref))])
  expect(batch.observations).toEqual([
    expect.objectContaining({
      featureId: "sgr.blink",
      outcome: "inconclusive",
      assertionType: "screenshot",
      reason: "insufficient-evidence",
      screenshotRef: frames[1]?.ref,
      frames,
      rawReplyRef: "sgr.blink",
    }),
  ])
  const trace = JSON.parse(batch.rawReplies["sgr.blink"]!) as { captures: unknown[] }
  expect(trace.captures).toHaveLength(17)
  // The capture writer clones the batch before persistence; recorder proxies must not escape.
  expect(structuredClone(batch)).toEqual(batch)
  expect(JSON.parse(batch.rawReplies["collector.geometry"]!)).toMatchObject({
    checks: [{ featureId: "sgr.blink", pre: { rows: 24, cols: 80 }, post: { rows: 24, cols: 80 } }],
  })
  expect(batch.suiteComplete).toBe(false)
  batch.rawReplies["collector.traceManifest"] = JSON.stringify({ blobs: [...blobs.values()] })
  const draft = asRun(batch)
  const open = (candidate: typeof draft, label: string) => {
    const bytes = Buffer.from(JSON.stringify(candidate)),
      path = label + ".json"
    writeFileSync(join(directory, path), bytes, { flag: "wx" })
    return readProbeCapture(
      directory,
      {
        kind: "trace",
        trace: { path, sha256: createHash("sha256").update(bytes).digest("hex") },
        captureRunId: draft.runId,
        captureSuiteId: draft.suiteId,
        captureSourceRevision: draft.sourceRevision,
      },
      { manifest, sourceRevision, subject: draft.subject! },
    )
  }
  expect(open(draft, "source-log-positive").files.length).toBeGreaterThan(1)
  const log = readCallLog(JSON.parse(batch.rawReplies["sgr.blink.callLog"]!))
  const replay = withCallLog<TermProbeSource>(null, { mode: "replay", log })
  const negativeLog = createCallLog()
  const changedSource = Object.defineProperties(
    {},
    Object.fromEntries(
      Object.entries(Object.getOwnPropertyDescriptors(replay.context)).map(([key, descriptor]) => [
        key,
        descriptor.get
          ? { enumerable: true, configurable: true, get: () => Reflect.get(replay.context, key) }
          : { enumerable: true, configurable: true, writable: true, value: Reflect.get(replay.context, key) },
      ]),
    ),
  ) as TermProbeSource
  changedSource.capture = async (checkpoint) => ({
    ...(await replay.context.capture!(checkpoint)),
    sourceRef: "sha256:" + "e".repeat(64),
  })
  const recording = withCallLog(changedSource, { mode: "record", log: negativeLog })
  const callback = ALL_PROBES.find(({ id }) => id === "sgr.blink")?.term
  if (!callback) throw new Error("Missing retained SGR callback")
  await withFakeTimers(() => callback(recording.context))
  recording.finish()
  replay.finish()
  const negative = structuredClone(draft)
  negative.rawReplies["sgr.blink.callLog"] = JSON.stringify(negativeLog)
  expect(() => open(negative, "source-log-negative")).toThrow(/unbound blob/)

  // The same producer-made SGR bundle must survive launch cleanup and reach the
  // existing callback/finalizer twice offline. Reader-only checks miss that handoff.
  if (!draft.subject || !draft.identity || !draft.measuredAt || !draft.origin) {
    throw new Error("Incomplete retained SGR fixture")
  }
  const originalBytes = Buffer.from(JSON.stringify(draft))
  const original = join(directory, "response.json")
  writeFileSync(original, originalBytes)
  const finalRoot = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(finalRoot)
  const persistenceLog = vi.spyOn(console, "log").mockImplementation(() => {})
  const saved = retainCollectedRun(
    {
      ...draft,
      subject: draft.subject,
      identity: draft.identity,
      measuredAt: draft.measuredAt,
      origin: draft.origin,
    },
    original,
    undefined,
    finalRoot,
    directory,
  )
  expect(persistenceLog).toHaveBeenCalledWith(`  Retained private collected run ${saved}`)
  persistenceLog.mockRestore()
  expect(readFileSync(join(finalRoot, "response.json"))).toEqual(originalBytes)
  const savedRun = JSON.parse(readFileSync(saved, "utf8")) as { rawReplies: Record<string, string> }
  expect(savedRun.rawReplies["collector.traceManifest"]).toBe(batch.rawReplies["collector.traceManifest"])
  rmSync(directory, { recursive: true })
  const source = {
    kind: "trace" as const,
    trace: { path: "response.json", sha256: createHash("sha256").update(originalBytes).digest("hex") },
    captureRunId: draft.runId,
    captureSuiteId: draft.suiteId,
    captureSourceRevision: draft.sourceRevision,
  }
  const expected = { manifest, sourceRevision, subject: draft.subject }
  expect(readProbeCapture(finalRoot, source, expected).files.length).toBeGreaterThan(1)
  const beforeOffline = writes.length
  const replayed = await withFakeTimers(() =>
    runEraseReplay(context, {
      directory: finalRoot,
      source,
      expected,
      featureId: "sgr.blink",
    }),
  )
  expect(replayed.assertions).toHaveLength(2)
  expect(structuredClone(replayed)).toEqual(replayed)
  const live = batch.results.find(({ featureId }) => featureId === "sgr.blink")!
  for (const assertion of replayed.assertions) {
    const result = assertion.results.find(({ featureId }) => featureId === live.featureId)
    expect(result).toMatchObject({
      status: live.status,
      reason: live.reason,
      assertionType: live.assertionType,
      frames: live.frames,
      rawReplyRef: live.featureId,
    })
    expect(result?.tests).toContainEqual(expect.objectContaining({ rawReplyRef: live.featureId }))
    expect(typeof assertion.rawReplies[live.featureId]).toBe("string")
  }
  expect(writes).toHaveLength(beforeOffline)
}, 30_000)

// 27875: a controlled-Linux run with no capture directory cannot make a frame. A probe that needs
// one must say so by name, in its own result, and must not claim pixels that do not exist.
it("records a FrameUnavailable capture as a named collector error, never invented pixels", async () => {
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["sgr.blink"],
    ownedTerminal: geometryOwner(measured(24, 80)),
    captureRunId: "a".repeat(32),
    capture: async () => {
      const error = new Error("This run has no capture directory, so no frame is available for a probe that needs one")
      error.name = "FrameUnavailable"
      throw error
    },
  })
  expect(batch.ungradedDiagnostics["sgr.blink"]).toMatchObject({
    kind: "collector-error",
    name: "FrameUnavailable",
    message: expect.stringContaining("no capture directory"),
  })
  expect(batch.results.find((result) => result.featureId === "sgr.blink")).toMatchObject({
    status: "probe-todo",
    reason: "This run has no capture directory, so no frame is available for a probe that needs one",
    tests: [
      expect.objectContaining({
        id: "criterion",
        status: "probe-todo",
        reason: "This run has no capture directory, so no frame is available for a probe that needs one",
      }),
    ],
  })
  expect(batch.observations).toEqual([])
})

// The stub is installed only on a controlled-Linux run with no capture directory. Everywhere else
// no capture callback exists at all, and the row stays a graceful absence — but its label is the
// honest one: the DECSCUSR set and the DECRQSS query are written before the probe gives up, so the
// silence is query/no-response, never none (8753a5e2, implementing @cto 05101f84; supersedes 27875).
it("keeps today's graceful absence row when no capture callback is installed", async () => {
  verifiedBatchFixture()
  process.stdout.write = (() => true) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["cursor.shape"],
    ownedTerminal: geometryOwner(measured(24, 80)),
    captureRunId: "a".repeat(32),
  })
  expect(batch.results.filter((result) => ["cursor.shape"].includes(result.featureId))).toMatchObject([
    {
      status: "probe-invalid",
      featureId: "cursor.shape",
      reason: expect.stringMatching(/no usable DECRQSS cursor-style reply;.*no pixel readback for shape/),
    },
  ])
  expect(batch.ungradedDiagnostics).toEqual({})
})

it("records an installed capture adapter failure as an error rather than quietly dropping pixels", async () => {
  verifiedBatchFixture()
  process.stdout.write = ((value: string) => {
    if (value.includes("\x1b[6n")) process.stdin.emit("data", Buffer.from("\x1b[1;2R"))
    return true
  }) as typeof process.stdout.write
  const batch = await runProbeBatch({
    ids: ["sgr.blink"],
    ownedTerminal: geometryOwner(measured(24, 80)),
    capture: () => Promise.reject(new Error("Owned window disappeared")),
  })
  expect(batch.results.filter((result) => ["sgr.blink"].includes(result.featureId))).toMatchObject([
    { status: "probe-invalid", featureId: "sgr.blink", reason: "Owned window disappeared" },
  ])
  expect(batch.screenshotRefs).toEqual([])
  expect(batch.ungradedDiagnostics).toEqual({})
})

// 27874 part 2: a receipt is bound to the run's own target BEFORE the first write. Checking it after
// the batch would mean a mismatched receipt had already authorized mutate+readback against the
// wrong app, so the refusal has to happen with nothing written.
it("refuses a receipt for another target before writing any byte", async () => {
  verifiedBatchFixture()
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const path = join(directory, "host-measured.json")
  writeFileSync(path, JSON.stringify(validContainerReceipt()))
  process.env.TERMINFO_DISPOSABLE_RECEIPT = path
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  await expect(
    runProbeBatch({
      ids: ["extensions.osc110-reset-fg"],
      subject: { kind: "term", id: "wezterm", os: "linux" },
    }),
  ).rejects.toThrow(/receipt declares target .*kitty.* but this run is .*wezterm/)
  expect(writes).toEqual([])
})

// A receipt that names a target cannot be bound to nothing: the caller must supply the run's own
// target, so a caller that forgot is loud rather than silently unbound.
it("refuses a receipt that names a target when the caller supplied no run target", async () => {
  verifiedBatchFixture()
  const directory = mkdtempSync(join(tmpdir(), "terminfo-disposable-receipts-"))
  receiptDirectories.push(directory)
  const path = join(directory, "host-measured.json")
  writeFileSync(path, JSON.stringify(validContainerReceipt()))
  process.env.TERMINFO_DISPOSABLE_RECEIPT = path
  const writes: string[] = []
  process.stdout.write = ((text: string) => {
    writes.push(text)
    return true
  }) as typeof process.stdout.write
  await expect(runProbeBatch({ ids: ["extensions.osc110-reset-fg"] })).rejects.toThrow(
    /no run target was supplied to bind it to/,
  )
  expect(writes).toEqual([])
})

// 28752: the run measures how its terminal decodes plain-written UTF-8 ONCE, records the fact
// beside the other collector facts, and hands every row the same answer — the context a
// plain-written oracle assumes is measured, never inherited from whatever locale launched it.
it("measures the decode context once per run and records it beside the other collector facts", async () => {
  verifiedBatchFixture()
  const actual = await vi.importActual<typeof import("../tty.ts")>("../tty.ts")
  vi.mocked(measureUtf8Decoding).mockImplementation(actual.measureUtf8Decoding)
  const replies = ["\x1b[2;1R", "\x1b[2;3R"]
  const pending = [...replies]
  const emitted: string[] = []
  process.stdout.write = ((sequence: string) => {
    emitted.push(sequence)
    if (sequence === "\x1b[6n") process.stdin.emit("data", Buffer.from(pending.shift()!))
    return true
  }) as typeof process.stdout.write
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const originalTerm = definition.term
  const seen: Array<string | null> = []
  definition.term = async (ctx) => {
    if (!ctx.utf8Decoding) throw new Error("collector did not install the measured decode context")
    seen.push(await ctx.utf8Decoding())
    seen.push(await ctx.utf8Decoding())
    return {
      pass: false,
      observation: { outcome: "inconclusive", reason: "insufficient-evidence", assertionType: "query_reply" },
    }
  }
  try {
    const batch = await runProbeBatch({ ids: [definition.id] })
    expect(seen).toEqual(["8-bit", "8-bit"])
    expect(vi.mocked(measureUtf8Decoding)).toHaveBeenCalledTimes(1)
    expect(pending).toEqual([])
    const writes = emitted.filter((sequence) => sequence !== "\x1b[6n")
    expect(writes).toEqual(["\x1b7", "\x1b[2;1H", "\x1b[0më", "\x1b[2;1H\x1b[2X", "\x1b8"])
    expect(JSON.parse(batch.rawReplies["collector.utf8Decoding"]!)).toMatchObject({
      decoding: "8-bit",
      writes,
      queries: replies.map((raw) => ({
        sequence: "\x1b[6n",
        match: [...raw.match(/\x1b\[(\d+);(\d+)R/)!],
        reason: "reply",
        raw,
        rawBase64: Buffer.from(raw).toString("base64"),
      })),
      events: emitted.map((sequence) => ({ sequence })),
    })
    expect(batch.rawReplies[definition.id]).toBe("")
  } finally {
    definition.term = originalTerm
    vi.mocked(measureUtf8Decoding).mockRestore()
  }
})

// @dev/review2: the memo has to hold the ATTEMPT, not its fulfilled value. A row that asks again
// while the first round trip is still in flight must join it, not start a second one.
it("joins the in-flight attempt, so a row asking before it returns measures nothing twice", async () => {
  verifiedBatchFixture()
  const measured = vi.mocked(measureUtf8Decoding)
  const original = measured.getMockImplementation()
  let attempts = 0
  let release: (reading: "8-bit") => void = () => {}
  measured.mockImplementation(() => {
    attempts += 1
    return new Promise<"8-bit">((resolve) => {
      release = resolve
    })
  })
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const originalTerm = definition.term
  definition.term = async (ctx) => {
    if (!ctx.utf8Decoding) throw new Error("collector did not install the measured decode context")
    const first = ctx.utf8Decoding()
    const second = ctx.utf8Decoding()
    release("8-bit")
    const seen = await Promise.all([first, second])
    expect(seen).toEqual(["8-bit", "8-bit"])
    return {
      pass: false,
      observation: { outcome: "inconclusive", reason: "insufficient-evidence", assertionType: "query_reply" },
    }
  }
  try {
    const batch = await runProbeBatch({ ids: [definition.id] })
    expect(attempts).toBe(1)
    expect(JSON.parse(batch.rawReplies["collector.utf8Decoding"]!)).toEqual({
      decoding: "8-bit",
      writes: [],
      queries: [],
      events: [],
    })
  } finally {
    definition.term = originalTerm
    if (original) measured.mockImplementation(original)
    else measured.mockReset()
  }
})

// @dev/review2: a failed attempt must stay failed for the batch. Retrying it per row would hide the
// failure behind a later, differently-contexted measurement and re-open the round trip every row.
it("keeps a failed attempt failed for the batch, so no later row re-measures the same context", async () => {
  verifiedBatchFixture()
  const actual = await vi.importActual<typeof import("../tty.ts")>("../tty.ts")
  const raw = "\x1b[2;1R"
  process.stdout.write = ((sequence: string) => {
    if (sequence === "\x1b[6n") process.stdin.emit("data", Buffer.from(raw))
    if (sequence === "\x1b[0më") throw new Error("the decode round trip failed")
    return true
  }) as typeof process.stdout.write
  const measured = vi.mocked(measureUtf8Decoding)
  const original = measured.getMockImplementation()
  let attempts = 0
  measured.mockImplementation(() => {
    attempts += 1
    return actual.measureUtf8Decoding()
  })
  const definition = ALL_PROBES.find((item) => item.id === "device.primary-da")!
  const originalTerm = definition.term
  const seen: string[] = []
  definition.term = async (ctx) => {
    if (!ctx.utf8Decoding) throw new Error("collector did not install the measured decode context")
    for (let ask = 0; ask < 2; ask += 1) {
      seen.push(await ctx.utf8Decoding().catch((error: Error) => `failed: ${error.message}`))
    }
    return {
      pass: false,
      observation: { outcome: "inconclusive", reason: "insufficient-evidence", assertionType: "query_reply" },
    }
  }
  try {
    const batch = await runProbeBatch({ ids: [definition.id] })
    expect(attempts).toBe(1)
    expect(seen).toEqual(["failed: the decode round trip failed", "failed: the decode round trip failed"])
    const retained = batch.rawReplies["collector.utf8Decoding"]
    expect(retained).toBeTruthy()
    expect(JSON.parse(retained!)).not.toHaveProperty("decoding")
    expect(JSON.parse(retained!)).toMatchObject({
      writes: ["\x1b7", "\x1b[2;1H", "\x1b[0më", "\x1b8"],
      queries: [
        {
          sequence: "\x1b[6n",
          reason: "reply",
          match: [raw, "2", "1"],
          raw,
          rawBase64: Buffer.from(raw).toString("base64"),
        },
      ],
    })
  } finally {
    definition.term = originalTerm
    if (original) measured.mockImplementation(original)
    else measured.mockReset()
  }
})

it.each(["CaptureRestoreFailed", "QueryTimeout", "QueryIOError", "CapturePermissionError", "OwnershipError"])(
  "a calibration %s aborts the batch before any callback",
  async (name) => {
    verifiedBatchFixture()
    const id = "device.decrpm"
    const definition = ALL_PROBES.find((probe) => probe.id === id)
    if (!definition) throw new Error("Missing existing DECRPM facility probe")
    const original = definition.term
    let callbacks = 0
    definition.term = async () => {
      callbacks++
      return {
        pass: false,
        tests: [{ id: "criterion", status: "probe-todo", reason: "insufficient-evidence" }],
      }
    }
    const failure = Object.assign(new Error("Witnessed restore did not match the pre-paint frame"), {
      name,
    })
    try {
      await expect(
        runProbeBatch({
          ids: [id],
          ownedTerminal: geometryOwner(measured(24, 80)),
          prepareCapture: async () => {
            throw failure
          },
        }),
      ).rejects.toBe(failure)
      expect(callbacks).toBe(0)
    } finally {
      definition.term = original
    }
  },
)

it("capture preparation refuses unavailable counts instead of using output defaults", async () => {
  verifiedBatchFixture()
  let painted = false
  await expect(
    runProbeBatch({
      ids: ["device.decrpm"],
      ownedTerminal: geometryOwner(noGeometry),
      prepareCapture: async () => {
        painted = true
      },
    }),
  ).rejects.toThrow(/verified.*grid|grid.*unavailable/)
  expect(painted).toBe(false)
})

it("capture preparation refuses a changed owned grid before a query callback can paint a stale subset", async () => {
  verifiedBatchFixture()
  vi.spyOn(process.stdout, "write").mockReturnValue(true)
  let painted = false
  await expect(
    runProbeBatch({
      ids: ["device.decrpm"],
      ownedTerminal: geometryOwner(measured(24, 80), async () => measured(30, 120)),
      prepareCapture: async () => {
        painted = true
      },
    }),
  ).rejects.toThrow(/grid.*changed|grid.*disagree/)
  expect(painted).toBe(false)
})

it("a retained terminal grid reply supplies preparation counts when declared size is unavailable", async () => {
  verifiedBatchFixture()
  vi.spyOn(process.stdout, "write").mockReturnValue(true)
  let seen: number[] | undefined
  const raw = "\x1b[8;30;120t"
  await runProbeBatch({
    ids: ["device.decrpm"],
    ownedTerminal: geometryOwner(noGeometry),
    geometryCorroboration: {
      status: "uncorroborated",
      rows: 30,
      cols: 120,
      query: {
        sequence: "\x1b[18t",
        outbound: "\x1b[18t\x1b[c",
        reason: "reply",
        raw,
        rawBase64: Buffer.from(raw).toString("base64"),
      },
    },
    prepareCapture: async ({ source: probeSource }) => {
      seen = [probeSource.rows, probeSource.cols]
    },
  })
  expect(seen).toEqual([30, 120])
})

it.each(["conflict", "malformed", "live mismatch"] as const)(
  "capture refuses %s without painting and retains the 18t evidence",
  async (fault) => {
    verifiedBatchFixture()
    vi.spyOn(process.stdout, "write").mockReturnValue(true)
    let painted = false
    const raw = "\x1b[8;30;120t"
    const batch = await runProbeBatch({
      ids: ["device.decrpm"],
      ownedTerminal: geometryOwner(measured(24, 80)),
      geometryCorroboration: {
        status: fault === "live mismatch" ? "agree" : fault,
        rows: 30,
        cols: 120,
        query: {
          sequence: "\x1b[18t",
          outbound: "\x1b[18t\x1b[c",
          reason: "reply",
          raw,
          rawBase64: Buffer.from(raw).toString("base64"),
        },
      },
      prepareCapture: async () => {
        painted = true
      },
    })
    expect(painted).toBe(false)
    expect(batch.rawReplies["collector.captureCalibration.trace"]).toContain(raw.replaceAll("\x1b", "\\u001b"))
    expect(JSON.parse(batch.rawReplies["collector.captureCalibration.trace"]!)).toMatchObject({
      refusal: expect.stringMatching(/grid.*disagree|grid.*malformed/),
    })
  },
)

it("an 18t timeout aborts capture preparation instead of recording a terminal refusal", async () => {
  verifiedBatchFixture()
  vi.spyOn(process.stdout, "write").mockReturnValue(true)
  let painted = false
  await expect(
    runProbeBatch({
      ids: ["device.decrpm"],
      ownedTerminal: geometryOwner(measured(24, 80)),
      geometryCorroboration: {
        status: "silent",
        query: {
          sequence: "\x1b[18t",
          outbound: "\x1b[18t\x1b[c",
          reason: "timeout",
          raw: "",
          rawBase64: "",
        },
      },
      prepareCapture: async () => {
        painted = true
      },
    }),
  ).rejects.toThrow(/18t.*timed out/)
  expect(painted).toBe(false)
})

// The unit owns mode classification; this boundary owns trace retention and gap
// propagation to real protocol and region callbacks after preparation refuses.
it.each(["unknown reply", "sentinel diagnostic reply", "sentinel diagnostic timeout"])(
  "a cursor-mode %s retains bytes and continues without pixel capture",
  async (fault) => {
    verifiedBatchFixture()
    vi.useFakeTimers()
    const da1 = "\x1b[?62;4c"
    const raw = fault === "unknown reply" ? `\x1b[?25;0$y${da1}` : da1
    const diagnostic = fault === "sentinel diagnostic reply" ? "\x1b[?25;1$y" : ""
    vi.spyOn(process.stdout, "write").mockImplementation(((text: string) => {
      if (text === "\x1b[?25$p\x1b[c") process.stdin.emit("data", Buffer.from(raw))
      if (text === "\x1b[?25$p" && diagnostic) process.stdin.emit("data", Buffer.from(diagnostic))
      if (text === "\x1b[c") process.stdin.emit("data", Buffer.from(da1))
      return true
    }) as typeof process.stdout.write)
    const capture = vi.fn()
    const captureRaw = vi.fn()
    const pending = runProbeBatch({
      ids: ["device.primary-da", "erase.line.all"],
      ownedTerminal: geometryOwner(measured(24, 80)),
      capture,
      prepareCapture: async ({ source: probeSource }) => {
        await calibrateCaptureOrigin({ ctx: probeSource, timeoutMs: 100, captureRaw })
      },
    })
    const [batch] = await Promise.all([pending, vi.runAllTimersAsync()])
    vi.useRealTimers()
    expect(batch.observations).toContainEqual(
      expect.objectContaining({ featureId: "device.primary-da", outcome: "supported", assertionType: "query_reply" }),
    )
    expect(batch.results.find((result) => result.featureId === "erase.line.all")).toMatchObject({
      status: "probe-todo",
      reason: expect.stringMatching(/cursor visibility/),
    })
    const trace = JSON.parse(batch.rawReplies["collector.captureCalibration.trace"]!)
    expect(trace).toMatchObject({
      writes: [],
      captures: [],
      refusal: expect.stringMatching(/cursor visibility/),
      queries: [
        expect.objectContaining({
          raw,
          rawBase64: Buffer.from(raw).toString("base64"),
          reason: fault === "unknown reply" ? "reply" : "sentinel",
        }),
        ...(fault === "unknown reply"
          ? []
          : [
              expect.objectContaining({
                sequence: "\x1b[?25$p",
                raw: diagnostic,
                rawBase64: Buffer.from(diagnostic).toString("base64"),
                reason: diagnostic ? "reply" : "timeout",
              }),
            ]),
      ],
    })
    expect(captureRaw).not.toHaveBeenCalled()
    expect(capture).not.toHaveBeenCalled()
    expect(batch.ungradedDiagnostics).toEqual({})
  },
)

// 30035: unknown prior modes must retain the plain diagnostic outcomes through the actual
// preparation owner, without painting or promoting their replies into qualification state.
// Existing raw-outcome tests do not exercise this callback or its run-owned retained trace.
it.each([25, 7].flatMap((missing) => ["reply", "malformed", "timeout"].map((diagnostic) => ({ missing, diagnostic }))))(
  "text preparation retains $diagnostic diagnostics when prior mode $missing is unavailable",
  async ({ missing, diagnostic }) => {
    verifiedBatchFixture()
    vi.useFakeTimers()
    const da1 = "\x1b[?62;4c"
    const plain = ["\x1b[?25$p", "\x1b[?7$p"]
    const raw =
      diagnostic === "reply"
        ? ["\x1b[?25;4$y", "\x1b[?7;0$y"]
        : diagnostic === "malformed"
          ? ["\x1b[?25;5$y", "\x1b[?70;1$y"]
          : ["", ""]
    const sentAt = new Map<string, number>()
    vi.spyOn(process.stdout, "write").mockImplementation(((text: string) => {
      sentAt.set(text, Date.now())
      for (const mode of [25, 7]) {
        if (text === `\x1b[?${mode}$p\x1b[c`) {
          const prior = mode === missing ? (mode === 25 ? "" : `\x1b[?${mode};0$y`) : `\x1b[?${mode};1$y`
          process.stdin.emit("data", Buffer.from(prior + da1))
        }
      }
      const index = plain.indexOf(text)
      if (index >= 0 && raw[index]) process.stdin.emit("data", Buffer.from(raw[index]!))
      if (text === "\x1b[c") process.stdin.emit("data", Buffer.from(da1))
      return true
    }) as typeof process.stdout.write)
    const capture = vi.fn(async () => {
      throw new Error("unavailable prior modes must not capture")
    })
    let qualification: TextQualification | undefined
    let preparedAt: number | undefined
    try {
      const pending = runProbeBatch({
        ids: ["device.primary-da"],
        ownedTerminal: geometryOwner(measured(24, 80)),
        prepareCapture: async ({ source: probeSource }) => {
          qualification = await collectTextQualification({ ctx: probeSource, recipe: "macos-text-cells-v1", capture })
          preparedAt = Date.now()
        },
      })
      const [batch] = await Promise.all([pending, vi.runAllTimersAsync()])
      const trace = JSON.parse(batch.rawReplies["collector.captureCalibration.trace"]!)
      expect(trace).toMatchObject({
        writes: [],
        captures: [],
        queries: [
          { sequence: "\x1b[?25$p\x1b[c" },
          { sequence: "\x1b[?7$p\x1b[c" },
          ...plain.map((sequence, index) => ({
            sequence,
            raw: raw[index],
            rawBase64: Buffer.from(raw[index]!).toString("base64"),
            reason: diagnostic === "reply" ? "reply" : "timeout",
          })),
        ],
      })
      if (diagnostic !== "reply") {
        expect(sentAt.get(plain[1]!)! - sentAt.get(plain[0]!)!).toBe(5000)
        expect(preparedAt! - sentAt.get(plain[1]!)!).toBe(5000)
      }
      expect(qualification?.shapes).toEqual(
        ["mid-line-gap", "trailing-gap", "soft-wrap", "prior-scrollback", "empty-last-row"].map((shape) => ({
          shape,
          reason: `Prior cursor visibility or autowrap state is unavailable (DECTCEM=${missing === 25 ? "null" : "set"}, DECAWM=${missing === 7 ? "unknown" : "set"})`,
        })),
      )
      expect(capture).not.toHaveBeenCalled()
      expect(batch.observations).toContainEqual(
        expect.objectContaining({ featureId: "device.primary-da", outcome: "supported", assertionType: "query_reply" }),
      )
    } finally {
      vi.useRealTimers()
    }
  },
)

// 32670: disposal must leave the five fixture reads intact even when prior modes are unavailable,
// then end with the unchanged shared normalization. The diagnostic-only cases above never paint,
// so cannot catch accidental measured-mode restoration or the default ending changing with this arm.
it.each([
  { disposal: false, priorAvailable: true },
  { disposal: false, priorAvailable: false },
  { disposal: true, priorAvailable: true },
  { disposal: true, priorAvailable: false },
])(
  "text qualification ending disposal=$disposal priorAvailable=$priorAvailable",
  async ({ disposal, priorAvailable }) => {
    verifiedBatchFixture()
    vi.useFakeTimers()
    const writes: string[] = []
    const da1 = "\x1b[?62;4c"
    vi.spyOn(process.stdout, "write").mockImplementation(((text: string) => {
      writes.push(text)
      for (const mode of [25, 7]) {
        if (text === `\x1b[?${mode}$p\x1b[c`) {
          process.stdin.emit("data", Buffer.from(`\x1b[?${mode};${priorAvailable ? 2 : 0}$y${da1}`))
        }
        if (text === `\x1b[?${mode}$p`) process.stdin.emit("data", Buffer.from(`\x1b[?${mode};0$y`))
      }
      if (text === "\x1b[c") process.stdin.emit("data", Buffer.from(da1))
      return true
    }) as typeof process.stdout.write)
    const blank = `sha256:${createHash("sha256")
      .update(Array.from({ length: 24 }, () => " ".repeat(80)).join("\n"))
      .digest("hex")}`
    const capture = vi.fn(
      async ({ role, label }: { role: ObservationFrame["role"]; label: string }): Promise<ObservationFrame> => ({
        kind: "text-cells",
        role,
        label,
        capturedAt: 1,
        ref: blank,
        frameDigest: blank,
        cellDigest: blank,
        cellRectangle: { top: 1, left: 1, bottom: 24, right: 80 },
      }),
    )
    let qualification: TextQualification | undefined
    let endingWrites: string[] = []
    try {
      const pending = runProbeBatch({
        ids: ["device.primary-da"],
        ownedTerminal: geometryOwner(measured(24, 80)),
        prepareCapture: async ({ source: probeSource }) => {
          qualification = await collectTextQualification({
            ctx: probeSource,
            recipe: "macos-text-cells-v1",
            capture,
            ...(disposal && { ending: "owned-window-disposal" as const }),
          })
          endingWrites = [...writes]
        },
      })
      const [batch] = await Promise.all([pending, vi.runAllTimersAsync()])
      const trace = JSON.parse(batch.rawReplies["collector.captureCalibration.trace"]!) as {
        queries: unknown[]
        writes: string[]
      }
      expect(qualification?.shapes).toHaveLength(5)
      expect(capture).toHaveBeenCalledTimes(disposal ? 11 : priorAvailable ? 12 : 0)
      expect(trace.queries).toHaveLength(priorAvailable ? (disposal ? 2 : 4) : 4)
      if (disposal) {
        expect(endingWrites.slice(-2)).toEqual(["\x1b[?25h", "\x1b[0m\x1b[2J\x1b[H"])
        expect(capture.mock.calls.map(([checkpoint]) => checkpoint.label)).not.toContain(
          "text qualification restored blank grid",
        )
      } else if (!priorAvailable) {
        expect(trace.writes).toEqual([])
        expect(qualification?.shapes.every((shape) => "reason" in shape)).toBe(true)
      } else {
        expect(endingWrites.slice(-6)).toEqual([
          "\x1b[?7l",
          "\x1b[?25h",
          "\x1b[0m\x1b[2J\x1b[H",
          "\x1b[?25l",
          "\x1b[?25$p\x1b[c",
          "\x1b[?7$p\x1b[c",
        ])
      }
    } finally {
      vi.useRealTimers()
    }
  },
)

// The new execution contract requires the direct native batch to record status at its real
// callback attempt. Existing observation/coverage assertions cannot prove frozen-catalog TODOs.
it("records actual native callback failure and leaves an unscheduled frozen capability TODO", async () => {
  const { initializeRunDraft } = await import("@terminfo/probe-defs")
  const id = "device.decrpm"
  const definition = ALL_PROBES.find((probe) => probe.id === id)!
  const original = definition.term
  const draft = initializeRunDraft({
    source: { kind: "live" },
    runId: "native-status-attempt",
    sourceRevision,
    manifest: { ...manifest, schemaVersion: 4, catalogIds: [id, "unimplemented.capability"] },
    intendedSubject: { kind: "term", id: "kitty" },
  })
  try {
    definition.term = async () => {
      throw new Error("deterministic callback failure")
    }
    const batch = await runProbeBatch({ ids: [id], draft })
    expect(batch.results.find((result) => result.featureId === id)).toMatchObject({
      status: "probe-invalid",
      attempt: { scope: "probe" },
    })
    expect(batch.results.find((result) => result.featureId === "unimplemented.capability")).toMatchObject({
      status: "probe-todo",
      attempt: { scope: "none" },
      tests: [],
    })
  } finally {
    definition.term = original
  }
})

// Existing native tests retained framed observations but never distinguished an attempted broken
// comparison from a still-unattempted required review at the callback-to-writer handoff.
it("forwards explicit callback tests through the actual native batch attempt without inferring review from frames", async () => {
  const { sgrCaptureFrames } = await import("../../../probe-defs/src/helpers.ts")
  const { cropPositionRefusal } = await import("../../../probe-defs/src/region-readback.ts")
  const id = "device.decrpm"
  const definition = ALL_PROBES.find((probe) => probe.id === id)!
  const original = definition.term
  const frames = [
    {
      role: "control" as const,
      label: "control",
      ref: `sha256:${"a".repeat(64)}`,
      capturedAt: 1,
      regionRectangle: { x: 0, y: 0, width: 10, height: 20 },
    },
    {
      role: "target" as const,
      label: "target",
      ref: `sha256:${"b".repeat(64)}`,
      capturedAt: 2,
      regionRectangle: { x: 0, y: 26, width: 10, height: 20 },
    },
  ]
  try {
    definition.term = async () =>
      cropPositionRefusal({
        id,
        compared: frames.map((frame) => ({ role: frame.role, rectangle: frame.regionRectangle })),
        response: "unequal crop positions",
        frames,
        screenshotRef: frames[1]!.ref,
      })!
    const failed = await runProbeBatch({ ids: [id] })
    expect(failed.results.find((result) => result.featureId === id)).toMatchObject({
      status: "probe-invalid",
      criterionBranch: "same-crop-comparison",
      tests: [{ id: "comparison", status: "probe-invalid", attempt: { scope: "probe" } }],
    })
    let next = 0
    definition.term = async () =>
      sgrCaptureFrames(
        {
          write() {},
          capture: async () => frames[next++]!,
        } as unknown as import("@terminfo/probe-defs").TermProbeSource,
        "control",
        "target",
        "visual target",
      )
    const pending = await runProbeBatch({ ids: [id] })
    const recorded = pending.results.find((result) => result.featureId === id)!
    expect(recorded.status).toBe("probe-todo")
    expect(recorded.criterionBranch).toBe("visual-review")
    expect(recorded.tests.find((check) => check.id === "review")).toMatchObject({
      status: "probe-todo",
      attempt: { scope: "none" },
    })
    expect(pending.assertions.find((assertion) => assertion.featureId === id)?.expected).toContain("visual target")
  } finally {
    definition.term = original
  }
})

// AC1–AC3 (#31677): the forwarding test above replaces the callback with a valid helper.
// These actual producers previously retained frames but defaulted to FAILURE with no review.
// Frames and decisions here are explicit collector fixtures, never terminal qualification evidence.
it.each([
  ["modes.xtpushsgr", 2, /bold.*not italic/i],
  ["modes.xtpopsgr", 2, /bold.*not italic/i],
  ["modes.xtsave", 2, /row 2/],
  ["modes.xtrestore", 2, /row 2/],
  ["modes.xtpushcolors", 2, /blue/],
  ["modes.xtpopcolors", 2, /blue/],
  ["modes.alt-screen.exit", 3, /PRIMARY.*ALTONLY/],
  ["modes.altscreen-47", 3, /MAIN47.*ALT47/],
  ["modes.altscreen-1047", 3, /second entry/i],
  ["modes.left-right-margin", 2, /column 6/],
  ["modes.insert-replace", 2, /XABCD/],
  ["cursor.shape", 2, /cursor cell/i],
] as const)("retains actual %s capture through its criterion and the canonical reader", async (id, count, expected) => {
  verifiedBatchFixture()
  vi.useFakeTimers()
  const ownManifest = {
    ...manifest,
    schemaVersion: 4 as const,
    catalogIds: [id],
    probes: { term: [id], lib: [], mux: [] },
  } satisfies ProbeSuiteManifest
  const draft = initializeRunDraft({
    runId: `native-visual-${id}`,
    sourceRevision,
    source: { kind: "live" },
    manifest: ownManifest,
    intendedSubject: { kind: "term", id: "kitty", version: "0.49.1" },
  })
  draft.subject = {
    kind: "term",
    id: "kitty",
    version: "0.49.1",
    os: "linux",
    osVersion: null,
    outerTerminal: null,
    mux: null,
    config: null,
    permissions: "fixture capture",
  }
  draft.identity = "verified"
  draft.measuredAt = "2026-10-29T15:00:00.000Z"
  draft.origin = { kind: "collector" }
  let captures = 0
  let witness = "blank"
  const pixelGeometry = { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 384 }
  const digest = (value: string) => `sha256:${createHash("sha256").update(value).digest("hex")}`
  const makeCapture =
    (unchangingPixels = false) =>
    async ({
      role,
      label,
      cells,
    }: {
      role: "control" | "target"
      label: string
      cells?: { top: number; left: number; bottom: number; right: number }
    }) => {
      const capturedAt = ++captures
      const lowerLabel = label.toLowerCase()
      // Constructed fixture planes prove that the collector maps each requested crop to pixels
      // and carries the witness through the new reader. The distinct third target stays unknown
      // to the comparison; it is never evidence of terminal qualification.
      const phase =
        id === "cursor.shape"
          ? lowerLabel.includes("stability") || lowerLabel.includes("made-up")
            ? "stable"
            : lowerLabel
          : unchangingPixels
            ? "unchanged"
            : lowerLabel.includes("stability")
              ? "stable"
              : lowerLabel.includes("paint witness") || lowerLabel.includes("baseline")
                ? witness
                : lowerLabel.includes("pre-edit seed")
                  ? "seed"
                  : lowerLabel.includes("post-sequence target")
                    ? id === "modes.alt-screen.exit"
                      ? "expected"
                      : "third"
                    : lowerLabel.includes("expected frame")
                      ? "expected"
                      : lowerLabel.includes("ignored-attribute")
                        ? "ignored"
                        : lowerLabel.includes("setup reference")
                          ? "seed"
                          : "fixture"
      const regionRectangle = cells
        ? {
            x: (cells.left - 1) * pixelGeometry.cellWidth,
            y: (cells.top - 1) * pixelGeometry.cellHeight,
            width: (cells.right - cells.left + 1) * pixelGeometry.cellWidth,
            height: (cells.bottom - cells.top + 1) * pixelGeometry.cellHeight,
          }
        : undefined
      return {
        frame: {
          role,
          label,
          capturedAt,
          ref: `sha256:${createHash("sha256").update(`fixture frame ${capturedAt}`).digest("hex")}`,
          ...(cells && regionRectangle
            ? {
                pixelsDigest: digest(`whole:${phase}`),
                regionDigest: digest(`crop:${cells.top},${cells.left},${cells.bottom},${cells.right}:${phase}`),
                regionRectangle,
              }
            : {}),
        },
        trace: {},
      }
    }
  let cursorReply = "\x1b[2;3R"
  process.stdout.write = ((chunk: string | Uint8Array) => {
    const bytes = typeof chunk === "string" ? chunk : Buffer.from(chunk).toString("utf8")
    if (bytes.includes("\x1b[2;3H")) cursorReply = "\x1b[2;3R"
    else if (bytes.includes("\x1b[3;2H")) cursorReply = "\x1b[3;2R"
    else if (id === "modes.alt-screen.exit" && bytes === "\x1b[?1049l") cursorReply = "\x1b[2;3R"
    if ((id === "cursor.shape" || id === "modes.alt-screen.exit") && bytes === "\x1b[6n") {
      process.stdin.emit("data", Buffer.from(cursorReply))
    }
    if (/^\x1b\[\d+;\d+H.$/.test(bytes)) witness = bytes.slice(-1)
    return true
  }) as typeof process.stdout.write
  try {
    const pending = runProbeBatch({
      ids: [id],
      draft,
      ownedTerminal: geometryOwner(measured(24, 80)),
      prepareCapture: async ({ source }) => {
        source.captureGeometry = { geometry: pixelGeometry, source: "measured by complete raster calibration" }
      },
      capture: makeCapture(),
      ...(id === "cursor.shape" && {
        input: {
          injectKey: async () => {
            process.stdin.emit("data", Buffer.from("a"))
          },
          injectClick: async () => {},
        },
      }),
    })
    const [batch] = await Promise.all([pending, vi.runAllTimersAsync()])
    expect(batch.ungradedDiagnostics).toEqual({})
    const result = batch.results.find((entry) => entry.featureId === id)!
    if (id === "modes.alt-screen.exit" || id === "cursor.shape") {
      // A real successful alternate-marker control cites the initial stability pair in its response.
      // Those cleared-canvas digests differ from every later primary/alternate/witness capture.
      if (id === "cursor.shape") {
        expect(result).toMatchObject({
          status: "supported",
          criterionBranch: "cursor-shape-same-run",
          assertionType: "screenshot",
        })
        expect(result.tests).toMatchObject([
          { id: "capture", status: "supported" },
          { id: "review", status: "supported" },
        ])
        expect(result.frames).toHaveLength(6)
      } else {
        expect(result.tests).toMatchObject([
          { id: "primary-marker-restored", status: "supported", assertionRefs: [0] },
          { id: "alternate-marker-control", status: "supported", assertionRefs: [1] },
          { id: "saved-cursor-restored", status: "supported", assertionRefs: [2] },
        ])
      }
      expect(batch.assertions).toHaveLength(id === "cursor.shape" ? 2 : 3)
      Object.assign(draft.rawReplies, batch.rawReplies)
      draft.results = batch.results
      draft.assertions = batch.assertions
      draft.screenshotRefs = batch.screenshotRefs
      const read = parseRun(
        "native-visual-stability-fixture.json",
        JSON.stringify(draft),
        [id],
        new Map([[probeHash, ownManifest]]),
      )
      expect(read.results?.[0]).toMatchObject({
        status: "supported",
        frames: result.frames,
      })
      if (id !== "cursor.shape") {
        expect(read.results?.[0]?.frames?.filter((frame) => frame.label.includes("capture stability"))).toHaveLength(2)
      }
      expect(read.assertions).toHaveLength(id === "cursor.shape" ? 2 : 3)
      return
    }
    if (batch.assertions.length === 0) {
      expect(result).toMatchObject({ status: "probe-todo" })
      expect(result.tests.some((check) => check.status === "probe-todo")).toBe(true)
      expect(result.frames!.length).toBeGreaterThanOrEqual(8)
      expect(
        result.frames!.every((frame) => Boolean(frame.regionDigest && frame.pixelsDigest && frame.regionRectangle)),
      ).toBe(true)
      Object.assign(draft.rawReplies, batch.rawReplies)
      draft.results = batch.results
      draft.assertions = batch.assertions
      draft.screenshotRefs = batch.screenshotRefs
      if (!result.tests.some((check) => check.id === "review")) {
        expect(
          result.tests.every(
            (check) => check.status === "probe-todo" && check.reason?.includes("a third distinct frame"),
          ),
        ).toBe(true)
        const decoded = decodeCollectorDraft(
          "native-visual-collector-fixture.json",
          JSON.stringify({ ...asRun(batch), screenshotRefs: batch.screenshotRefs }),
          manifest,
          sourceRevision,
        ).run
        expect(decoded.results.find((result) => result.featureId === id)?.frames).toEqual(result.frames)
        return
      }
      const read = parseRun(
        "native-visual-fixture.json",
        JSON.stringify(draft),
        [id],
        new Map([[probeHash, ownManifest]]),
      )
      expect(read.results?.[0]).toMatchObject({ status: "probe-todo", frames: result.frames })
      expect(read.assertions).toEqual([])
      if (id === "modes.insert-replace") {
        const noFreshDraft = initializeRunDraft({
          runId: `native-visual-no-freshness-${id}`,
          sourceRevision,
          source: { kind: "live" },
          manifest: ownManifest,
          intendedSubject: { kind: "term", id: "kitty", version: "0.49.1" },
        })
        noFreshDraft.subject = structuredClone(draft.subject)
        noFreshDraft.identity = "verified"
        noFreshDraft.measuredAt = "2026-10-29T15:02:00.000Z"
        noFreshDraft.origin = { kind: "collector" }
        const unchangedPending = runProbeBatch({
          ids: [id],
          draft: noFreshDraft,
          ownedTerminal: geometryOwner(measured(24, 80)),
          prepareCapture: async ({ source }) => {
            source.captureGeometry = { geometry: pixelGeometry, source: "measured by complete raster calibration" }
          },
          capture: makeCapture(true),
        })
        const [unchanged] = await Promise.all([unchangedPending, vi.runAllTimersAsync()])
        expect(unchanged.ungradedDiagnostics).toEqual({})
        const noFreshDecoded = decodeCollectorDraft(
          "native-visual-no-freshness.json",
          JSON.stringify(asRun(unchanged, ownManifest)),
          ownManifest,
          sourceRevision,
        ).run
        expect(unchanged.observations).toEqual([])
        expect(noFreshDecoded.results.find((entry) => entry.featureId === id)).toEqual(
          unchanged.results.find((entry) => entry.featureId === id),
        )
        expect(unchanged.results.find((entry) => entry.featureId === id)).toMatchObject({
          status: "probe-todo",
          tests: [
            expect.objectContaining({
              id: "review",
              status: "probe-todo",
              reason: expect.stringContaining("no freshness witness"),
            }),
          ],
        })
      }
      return
    }
    expect(result).toMatchObject({
      status: "probe-todo",
      criterionBranch: "visual-review",
      tests: [
        { id: "capture", status: "supported", assertionRefs: [0] },
        { id: "review", status: "probe-todo", attempt: { scope: "none" } },
      ],
    })
    expect(result.frames).toHaveLength(count)
    expect(batch.observations[0]).toMatchObject({ outcome: "inconclusive", assertionType: "screenshot" })
    expect(batch.assertions).toHaveLength(1)
    expect(batch.assertions[0]).toMatchObject({
      featureId: id,
      assertionType: "screenshot",
      expected: expect.stringMatching(expected),
    })
    const retained = JSON.parse(batch.assertions[0]!.observed)
    expect(retained).toEqual(
      count === 3
        ? { control: result.frames![0], alternate: result.frames![1], restored: result.frames![2] }
        : { control: result.frames![0], target: result.frames![1] },
    )
    Object.assign(draft.rawReplies, batch.rawReplies)
    draft.assertions = batch.assertions
    draft.screenshotRefs = batch.screenshotRefs
    const before = structuredClone(result.frames)
    draft.results = batch.results
    const read = parseRun(
      "native-visual-fixture.json",
      JSON.stringify(draft),
      [id],
      new Map([[probeHash, ownManifest]]),
    )
    expect(read.results?.[0]).toMatchObject({ status: "probe-todo", frames: before })
    expect(read.assertions[0]?.expected).toMatch(expected)
  } finally {
    vi.useRealTimers()
  }
})

// @failure D160: a multiplexer subject runs the font-ligature pixel arm, or a native subject is diverted into coverage.
// @level l1
// @consumer runProbeBatch -> recordExecutedProbe coverage (the sgr-attribute precedent at unified.ts:1085-1098).
it("records mux coverage for extensions.font-ligatures and leaves a native subject on its own path", async () => {
  const id = "extensions.font-ligatures"
  const definition = ALL_PROBES.find((probe) => probe.id === id)!
  const original = {
    term: definition.term,
    termWrites: definition.termWrites,
    termNeedsDisposable: definition.termNeedsDisposable,
    termNeedsGeometry: definition.termNeedsGeometry,
  }
  const frame = { role: "control" as const, ref: `sha256:${"b".repeat(64)}`, capturedAt: 1, label: "ligature sample" }
  const response = "fixture pixel arm"
  try {
    // The grant stubs are what a real run presents. Without them runProbeBatch refuses before the
    // callback (unified.ts:578-602), and every expectation below would hold over an empty batch.
    definition.termWrites = "query"
    definition.termNeedsDisposable = undefined
    definition.termNeedsGeometry = undefined
    definition.term = async () => notTestedResult("Font ligatures need rendered pixels in this fixture", {})
    const mux = await runProbeBatch({
      ids: [id],
      subject: { kind: "mux", id: "screen", version: "5.0.2", os: "linux" },
    })
    expect(mux.notTested?.find((item) => item.featureId === id)).toMatchObject({
      reason: "no-semantic-observable",
      noObservable: "ligature shaping is done by the host terminal; the multiplexer only emits text cells",
      rawReplyRef: id,
    })
    expect(mux.results.find((result) => result.featureId === id)).toMatchObject({
      status: "untestable",
      criterionBranch: "headless-observable-review",
      tests: [
        expect.objectContaining({
          id: "declared-untestable",
          status: "untestable",
          reason: "ligature shaping is done by the host terminal; the multiplexer only emits text cells",
        }),
      ],
    })

    // A pixel-capable mux run leaves a screenshot observation and assertion behind BEFORE coverage is
    // decided; coverage is the only claim kept, so neither list may still name this feature and the
    // result may not carry the arm's frames or branch.
    definition.term = async () => ({
      pass: true,
      note: "fixture pixel arm matched",
      response,
      criterionBranch: "font-ligatures-same-cell",
      tests: [{ id: "ligatures", status: "supported" as const, assertionRefs: [0] }],
      observation: {
        outcome: "supported" as const,
        assertionType: "screenshot" as const,
        frames: [frame],
        screenshotRef: frame.ref,
        note: "fixture pixel arm matched",
      },
      assertions: [
        { assertionType: "screenshot" as const, kind: "positive" as const, expected: "same cell", observed: response },
      ],
    })
    const pixel = await runProbeBatch({
      ids: [id],
      subject: { kind: "mux", id: "screen", version: "5.0.2", os: "linux" },
    })
    expect(pixel.notTested?.find((item) => item.featureId === id)?.reason).toBe("no-semantic-observable")
    expect(pixel.observations.filter((entry) => entry.featureId === id)).toEqual([])
    expect(pixel.assertions.filter((entry) => entry.featureId === id)).toEqual([])
    const covered = pixel.results.find((result) => result.featureId === id)!
    expect(covered).toMatchObject({
      status: "untestable",
      criterionBranch: "headless-observable-review",
    })
    expect(covered.frames).toBeUndefined()
    expect(covered.screenshotRef).toBeUndefined()
    expect(covered.assertionType).toBeUndefined()

    definition.term = async () => notTestedResult("Font ligatures need rendered pixels in this fixture", {})
    const native = await runProbeBatch({
      ids: [id],
      subject: { kind: "term", id: "kitty", version: "0.49.2", os: "linux" },
    })
    // The native subject is NOT diverted: it keeps the callback's own refusal, not the mux sentence.
    expect(native.notTested?.find((item) => item.featureId === id)?.noObservable).toMatch(/rendered pixels/i)
  } finally {
    Object.assign(definition, original)
  }
})

/**
 * @failure A callback that outlives its wall keeps its TTY lease, so its late write reaches the terminal
 *   while the next probe runs; the timed-out row also loses the wall's own reason, the post-callback
 *   geometry read, and the trace of what it wrote before the hang (#33431).
 * @level l1
 * @consumer runProbeBatch wall timeout -> abandoned callback, recorded row, geometry post, retained trace
 * @testonly none
 */
it("a callback that outlives its wall cannot write while the next probe runs and keeps its wall evidence", async () => {
  verifiedBatchFixture()
  const slow = ALL_PROBES.find((probe) => probe.id === "reset.ris")!
  const next = ALL_PROBES.find((probe) => probe.id === "reset.soft")!
  const originalSlow = {
    term: slow.term,
    termWrites: slow.termWrites,
    wallMs: slow.wallMs,
    termNeedsDisposable: slow.termNeedsDisposable,
  }
  const originalNext = {
    term: next.term,
    termWrites: next.termWrites,
    wallMs: next.wallMs,
    termNeedsDisposable: next.termNeedsDisposable,
  }
  const ttyWrites: string[] = []
  const order: string[] = []
  let releaseTheWall!: () => void
  const afterTheWall = new Promise<void>((resolve) => {
    releaseTheWall = resolve
  })
  try {
    slow.termWrites = "query"
    slow.wallMs = 80
    slow.term = async (source) => {
      source.write("\x1b[c")
      order.push("slow:before-hang")
      await afterTheWall
      order.push("slow:late-write")
      source.write("\x1b[?1049h")
      return { pass: false, tests: [{ id: "criterion", status: "probe-todo", reason: "late" }] }
    }
    next.termWrites = "query"
    delete next.termNeedsDisposable
    next.wallMs = 20_000
    next.term = async (source) => {
      order.push("next:started")
      source.write("\x1b[5n")
      return { pass: false, tests: [{ id: "criterion", status: "probe-todo", reason: "next ran after the wall" }] }
    }
    const batch = await runProbeBatch({
      ids: [slow.id, next.id],
      subject: { kind: "term", id: "xterm", version: "411", os: "linux" },
      out: { write: (text: string) => ttyWrites.push(text) } as unknown as NodeJS.WriteStream,
      ownedTerminal: geometryOwner(measured(30, 100)),
    })
    const row = batch.results.find((result) => result.featureId === slow.id)!
    const nextRow = batch.results.find((result) => result.featureId === next.id)!
    expect.soft(nextRow.status).toBe("probe-todo")
    const geometryReplies = JSON.parse(batch.rawReplies["collector.geometry"] ?? "{}") as {
      checks?: Array<{ featureId: string; post?: unknown }>
    }
    const geometry = geometryReplies.checks?.find((check) => check.featureId === slow.id)
    expect.soft(row.status).toBe("probe-todo")
    expect.soft(row.reason).toBe("Probe exceeded 80ms")
    expect
      .soft(row.tests)
      .toEqual([expect.objectContaining({ id: "criterion", status: "probe-todo", reason: "Probe exceeded 80ms" })])
    expect.soft(geometry?.post).toBeDefined()
    const trace = JSON.parse(batch.rawReplies[slow.id] ?? "{}") as { writes?: string[] }
    expect.soft(trace.writes).toContain("\x1b[c")
    releaseTheWall()
    await new Promise((resolve) => setTimeout(resolve, 20))
    expect.soft(order).toContain("next:started")
    expect.soft(ttyWrites).not.toContain("\x1b[?1049h")
  } finally {
    Object.assign(slow, originalSlow)
    Object.assign(next, originalNext)
  }
})

/**
 * @failure A callback that hangs inside its own query at the wall leaves the trace snapshot
 *   unreadable, so the wall branch throws before it releases the TTY queue and the probe loses the
 *   writes it settled before the hang (#33431).
 * @level l1
 * @consumer runProbeBatch wall timeout -> traceScope.abandon -> snapshot with a pending host call
 * @testonly none
 */
it("keeps the wall's trace when the callback hangs inside its own pending query", async () => {
  verifiedBatchFixture()
  const slow = ALL_PROBES.find((probe) => probe.id === "reset.ris")!
  const next = ALL_PROBES.find((probe) => probe.id === "reset.soft")!
  const originalSlow = {
    term: slow.term,
    termWrites: slow.termWrites,
    wallMs: slow.wallMs,
    termNeedsDisposable: slow.termNeedsDisposable,
  }
  const originalNext = {
    term: next.term,
    termWrites: next.termWrites,
    wallMs: next.wallMs,
    termNeedsDisposable: next.termNeedsDisposable,
  }
  try {
    slow.termWrites = "query"
    slow.wallMs = 80
    slow.term = async (source) => {
      source.write("\x1b[c")
      // The host records matchResponse, then the write its own callback makes, and only then hangs.
      await source.query("\x1b[5n", /\x1b\[0n/, 400)
      return { pass: false, tests: [{ id: "criterion", status: "probe-todo", reason: "query answered late" }] }
    }
    next.termWrites = "query"
    delete next.termNeedsDisposable
    next.wallMs = 20_000
    next.term = async () => ({
      pass: false,
      tests: [{ id: "criterion", status: "probe-todo", reason: "next ran after the wall" }],
    })
    const batch = await runProbeBatch({
      ids: [slow.id, next.id],
      subject: { kind: "term", id: "xterm", version: "411", os: "linux" },
      out: { write: () => {} } as unknown as NodeJS.WriteStream,
      ownedTerminal: geometryOwner(measured(30, 100)),
    })
    const row = batch.results.find((result) => result.featureId === slow.id)!
    const nextRow = batch.results.find((result) => result.featureId === next.id)!
    expect.soft(nextRow.status).toBe("probe-todo")
    expect.soft(row.status).toBe("probe-todo")
    expect.soft(row.reason).toBe("Probe exceeded 80ms")
    // An abandon that threw would leave this row with a collector error and the queue behind the hang.
    expect.soft(batch.ungradedDiagnostics[slow.id]).toBeUndefined()
    const trace = JSON.parse(batch.rawReplies[slow.id] ?? "{}") as { writes?: string[] }
    // A query's own write is projected as its query event, and an unsettled query has no event; the
    // command write before the hang is what the trace can still measure.
    expect.soft(trace.writes).toContain("\x1b[c")
  } finally {
    Object.assign(slow, originalSlow)
    Object.assign(next, originalNext)
  }
})
