/**
 * @failure Capture blocks the daemon, changes its selected window, or retains a frame after losing the window owner.
 * @level l2
 * @consumer Linux Kitty daemon capture and concurrent HTTP clients
 * @reach fs-walk <fixture-only: inspect only the owned temporary capture output directory>
 * @testonly none
 */
import {
  chmodSync,
  existsSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  rmSync,
  writeFileSync,
} from "node:fs"
import { createHash } from "node:crypto"
import { spawnSync } from "node:child_process"
import { tmpdir } from "node:os"
import { join } from "node:path"
import { afterEach, expect, test, vi } from "vitest"
import { createLinuxCapture, PNG_CONVERSION_ARGS, screenPixels, windowPixels } from "./linux-capture.ts"

import { capturePixels, cellRectangle, command, finishCapture } from "./capture-core.ts"

const temporary: string[] = []
const originalPath = process.env.PATH
const originalDisplay = process.env.DISPLAY

test("capture apparatus runs in a separate process group and session without a controlling tty", async () => {
  const caller = spawnSync("/bin/ps", ["-o", "pgid=,sess=,tty=", "-p", String(process.pid)], {
    encoding: "utf8",
    timeout: 5000,
  })
  expect(caller.error).toBeUndefined()
  expect(caller.status).toBe(0)
  const [callerGroup, callerSession] = caller.stdout.trim().split(/\s+/)
  expect(callerGroup).toBeTruthy()
  expect(callerSession).toBeTruthy()
  const input = Buffer.from([0, 17, 255, 10])
  const output = await command(
    process.execPath,
    [
      "-e",
      "const { execFileSync } = require('node:child_process'); const { readFileSync } = require('node:fs'); const identity = execFileSync('/bin/ps', ['-o', 'pgid=,sess=,tty=', '-p', String(process.pid)], { encoding: 'utf8', timeout: 1000 }).trim().split(/\\s+/); process.stdout.write(JSON.stringify({ pid: process.pid, identity, input: readFileSync(0).toString('base64') }))",
    ],
    input,
    Date.now() + 5000,
  )
  const child = JSON.parse(output.toString()) as { pid: number; identity: string[]; input: string }
  const [childGroup, childSession, childTty] = child.identity
  expect(childGroup).not.toBe(callerGroup)
  expect(childSession).not.toBe(callerSession)
  expect(childGroup).toBe(String(child.pid))
  expect(childTty).toMatch(/^\?{1,2}$/)
  expect(child.input).toBe(input.toString("base64"))
})

// A decoded Error.message cannot preserve binary callback output on a failed census (30412).
// Exercise the real subprocess boundary, without an optional stderr observer to fill the gap.
test("capture command retains failed callback bytes with its native exit details", async () => {
  const args = [
    "-e",
    "process.stdout.write(Buffer.from([17, 0, 23])); process.stderr.write(Buffer.from([100, 0, 255, 10])); process.exit(17)",
  ]
  await expect(command(process.execPath, args)).rejects.toMatchObject({
    code: 17,
    killed: false,
    signal: null,
    captureCommand: {
      file: process.execPath,
      args,
      stdoutBase64: Buffer.from([17, 0, 23]).toString("base64"),
      stderrBase64: Buffer.from([100, 0, 255, 10]).toString("base64"),
      code: 17,
      signal: null,
      killed: false,
    },
  })
})

// A successful screenshot command can still explain a missing PNG only on stderr.
test("capture command preserves zero-exit stderr before resolving unchanged stdout bytes", async () => {
  const observed: Buffer[] = []
  const stdout = await command(
    process.execPath,
    ["-e", "process.stdout.write(Buffer.from([17, 0, 23])); process.stderr.write(Buffer.from([0, 255, 10]))"],
    undefined,
    undefined,
    (stderr) => observed.push(stderr),
  )
  expect(stdout).toEqual(Buffer.from([17, 0, 23]))
  expect(observed).toEqual([Buffer.from([0, 255, 10])])
})

// Calibration's oracle deadline bounds the running child, not just the next polling iteration.
test("capture command terminates a real child at its supplied deadline and never starts after expiry", async () => {
  const { directory } = fixture()
  const completed = join(directory, "deadline-completed")
  const childPidPath = join(directory, "deadline-child-pid")
  const descendantPidPath = join(directory, "deadline-descendant-pid")
  const descendantCompleted = join(directory, "deadline-descendant-completed")
  const descendantSource =
    "const fs=require('node:fs'); fs.writeFileSync(process.argv[1],String(process.pid)); setTimeout(()=>{fs.writeFileSync(process.argv[2],'orphan continued'); process.exit(0)},2200)"
  try {
    await expect(
      command(
        process.execPath,
        [
          "-e",
          `const fs=require('node:fs'); fs.writeFileSync(process.argv[2],String(process.pid)); require('node:child_process').spawn(process.execPath,['-e',${JSON.stringify(descendantSource)},process.argv[3],process.argv[4]],{stdio:'inherit'}); process.on('SIGTERM',()=>{}); setTimeout(()=>fs.writeFileSync(process.argv[1],'completed'),4000)`,
          completed,
          childPidPath,
          descendantPidPath,
          descendantCompleted,
        ],
        undefined,
        Date.now() + 1500,
      ),
    ).rejects.toMatchObject({ killed: true, signal: "SIGKILL" })
    expect(existsSync(completed)).toBe(false)
    const childPid = Number(readFileSync(childPidPath, "utf8"))
    const descendantPid = Number(readFileSync(descendantPidPath, "utf8"))
    expect(Number.isSafeInteger(childPid) && childPid > 1).toBe(true)
    expect(Number.isSafeInteger(descendantPid) && descendantPid > 1).toBe(true)
    expect(() => process.kill(childPid, 0)).toThrow(expect.objectContaining({ code: "ESRCH" }))
    await vi.waitFor(
      () => {
        expect(() => process.kill(descendantPid, 0)).toThrow(expect.objectContaining({ code: "ESRCH" }))
      },
      { timeout: 1000, interval: 20 },
    )
    expect(existsSync(descendantCompleted)).toBe(false)
  } finally {
    if (existsSync(childPidPath)) {
      const childPid = Number(readFileSync(childPidPath, "utf8"))
      if (!Number.isSafeInteger(childPid) || childPid <= 1) throw new Error("Invalid owned capture fixture PID")
      try {
        process.kill(-childPid, "SIGKILL")
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ESRCH") throw error
      }
    }
  }
  const invoked = join(directory, "expired-invoked")
  await expect(
    command(
      process.execPath,
      ["-e", "require('node:fs').writeFileSync(process.argv[1], 'invoked')", invoked],
      undefined,
      Date.now() - 1,
    ),
  ).rejects.toThrow(/capture command.*deadline expired/i)
  expect(existsSync(invoked)).toBe(false)
})

function executable(path: string, source: string): void {
  writeFileSync(path, `#!/bin/sh\nset -eu\n${source}\n`)
  chmodSync(path, 0o700)
}

function fixture() {
  const directory = mkdtempSync(join(tmpdir(), "terminfo-linux-capture-"))
  temporary.push(directory)
  const started = join(directory, "started")
  const finished = join(directory, "finished")
  const release = join(directory, "release")
  const stdin = join(directory, "stdin")
  const png = join(directory, "sample.png")
  writeFileSync(png, Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 0]))
  executable(
    join(directory, "xdotool"),
    `case "$1" in
  search)
    if [ "$3" = --pid ]; then printf '%s\\n' "$TEST_CAPTURE_WINDOWS"
    else printf '%s\\n' "$TEST_CAPTURE_VISIBLE_WINDOWS"; fi
    ;;
  getwindowpid)
    if [ "${"$"}TEST_CAPTURE_FAIL" = owner ]; then printf 'owner lookup failed\\n' >&2; exit 17; fi
    if [ -n "\${TEST_CAPTURE_HELPER_WINDOW:-}" ] && [ "$2" = "$TEST_CAPTURE_HELPER_WINDOW" ]; then
      printf '%s\\n' "\${TEST_CAPTURE_HELPER_OWNER_PID:-$TEST_CAPTURE_OWNER_PID}"
    else
      printf '%s\\n' "$TEST_CAPTURE_OWNER_PID"
    fi
    ;;
  getwindowgeometry)
    if [ -n "\${TEST_CAPTURE_HELPER_WINDOW:-}" ] && [ "$3" = "$TEST_CAPTURE_HELPER_WINDOW" ]; then
      printf 'X=%s\\nY=%s\\nWIDTH=%s\\nHEIGHT=%s\\n' \\
        "\${TEST_CAPTURE_HELPER_X:-1400}" "\${TEST_CAPTURE_HELPER_Y:-800}" \\
        "\${TEST_CAPTURE_HELPER_WIDTH:-160}" "\${TEST_CAPTURE_HELPER_HEIGHT:-40}"
    elif [ "\${TEST_CAPTURE_GEOMETRY_SHELL:-0}" = 1 ]; then
      printf 'WINDOW=%s\\nX=%s\\nY=%s\\nWIDTH=%s\\nHEIGHT=%s\\nSCREEN=%s\\n' \\
        "\${TEST_CAPTURE_GEOMETRY_WINDOW:-42}" "\${TEST_CAPTURE_X:-0}" "\${TEST_CAPTURE_Y:-0}" \\
        "\${TEST_CAPTURE_WIDTH:-640}" "\${TEST_CAPTURE_HEIGHT:-480}" "\${TEST_CAPTURE_SCREEN:-0}"
    else
      printf 'X=%s\\nY=%s\\nWIDTH=%s\\nHEIGHT=%s\\n' \\
        "\${TEST_CAPTURE_X:-0}" "\${TEST_CAPTURE_Y:-0}" \\
        "\${TEST_CAPTURE_WIDTH:-640}" "\${TEST_CAPTURE_HEIGHT:-480}"
    fi
    ;;
  *) exit 18 ;;
esac`,
  )
  executable(
    join(directory, "xwd"),
    `printf started > "$TEST_CAPTURE_STARTED"
while [ ! -e "$TEST_CAPTURE_RELEASE" ]; do sleep 0.01; done
printf finished > "$TEST_CAPTURE_FINISHED"
id=
nobdrs=0
prev=
for arg; do
  if [ "\$prev" = -id ]; then id=\$arg; fi
  if [ "\$arg" = -nobdrs ]; then nobdrs=1; fi
  prev=\$arg
done
w=\${TEST_CAPTURE_WIDTH:-640}
h=\${TEST_CAPTURE_HEIGHT:-480}
if [ "\$nobdrs" != 1 ]; then
  w=\$((w + 2))
  h=\$((h + 2))
fi
printf '%sx%s' "\$w" "\$h" > "$TEST_CAPTURE_XWD_SIZE"
printf 'xwd-window-%s' "\$id"`,
  )
  executable(
    join(directory, "scrot"),
    [
      'printf "%s\\n" "$@" > "$TEST_CAPTURE_PNG.scrot-args"',
      'printf started > "$TEST_CAPTURE_STARTED"',
      'while [ ! -e "$TEST_CAPTURE_RELEASE" ]; do sleep 0.01; done',
      'printf finished > "$TEST_CAPTURE_FINISHED"',
      // scrot opens its output filename; "-" reopens /dev/stdout rather than writing fd 1.
      // A plain cat-to-stdout fixture hides ENXIO under the real spawn pipe transport.
      "output=",
      "previous=",
      'for arg; do if [ "$previous" = --file ]; then output=$arg; fi; previous=$arg; done',
      'if [ "$output" = - ]; then output=/dev/stdout; fi',
      'cat "$TEST_CAPTURE_PNG" > "$output"',
      'if [ "$TEST_CAPTURE_FAIL" = scrot ]; then printf "scrot output failed\\n" >&2; exit 23; fi',
    ].join("\n"),
  )
  executable(
    join(directory, "xdpyinfo"),
    `printf 'root window id: 0x21f\\n  dimensions:    %sx%s pixels\\n' "\${TEST_CAPTURE_SCREEN_WIDTH:-1920}" "\${TEST_CAPTURE_SCREEN_HEIGHT:-1080}"`,
  )
  executable(
    join(directory, "magick"),
    `if [ "$1" = -version ]; then printf 'ImageMagick test\\n'; exit 0; fi
if [ -n "\${TEST_CAPTURE_MAGICK_ARGS:-}" ]; then printf '%s\\n' "$@" >> "$TEST_CAPTURE_MAGICK_ARGS"; fi
cat > "$TEST_CAPTURE_STDIN"
if [ "${"$"}TEST_CAPTURE_FAIL" = conversion ]; then printf 'conversion failed\\n' >&2; exit 19; fi
rgba=
crop=
identify=
for arg; do
  [ "\$arg" = "rgba:-" ] && rgba=1
  [ "\$arg" = "info:" ] && identify=1
  case "\$arg" in
    *x*+*) crop=\$arg ;;
  esac
done
size=\${TEST_CAPTURE_FORCE_CAPTURE:-}
if [ -z "\$size" ] && [ -f "$TEST_CAPTURE_XWD_SIZE" ]; then
  size=\$(cat "$TEST_CAPTURE_XWD_SIZE")
fi
if [ -z "\$size" ]; then
  size="\${TEST_CAPTURE_WIDTH:-640}x\${TEST_CAPTURE_HEIGHT:-480}"
fi
if [ -n "\$identify" ]; then
  printf '%s' "\$size"
  exit 0
fi
if [ -n "\$rgba" ]; then
  if [ -n "\$crop" ]; then
    w=\${crop%%x*}
    rest=\${crop#*x}
    h=\${rest%%+*}
    head -c "\$((w * h * 4))" /dev/zero
  else
    w=\${size%%x*}
    h=\${size#*x}
    chrome=\${TEST_CAPTURE_CHROME_ROWS:-0}
    if [ "\$chrome" -gt 0 ]; then
      head -c "\$((w * chrome * 4))" /dev/zero | tr '\\0' '\\1'
      head -c "\$((w * (h - chrome) * 4))" /dev/zero
    else
      head -c "\$((w * h * 4))" /dev/zero
    fi
  fi
  exit 0
fi
cat "$TEST_CAPTURE_PNG"`,
  )
  process.env.PATH = `${directory}:${originalPath ?? ""}`
  process.env.DISPLAY = ":test"
  process.env.TEST_CAPTURE_OWNER_PID = String(process.pid)
  process.env.TEST_CAPTURE_WINDOWS = "42"
  process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42"
  process.env.TEST_CAPTURE_STARTED = started
  process.env.TEST_CAPTURE_FINISHED = finished
  process.env.TEST_CAPTURE_RELEASE = release
  process.env.TEST_CAPTURE_STDIN = stdin
  process.env.TEST_CAPTURE_PNG = png
  process.env.TEST_CAPTURE_FAIL = ""
  process.env.TEST_CAPTURE_XWD_SIZE = join(directory, "xwd-size")
  process.env.TEST_CAPTURE_MAGICK_ARGS = ""
  return { directory, started, finished, release, stdin, png }
}

function liveExecutable(sha256?: string) {
  const path = realpathSync(`/proc/${process.pid}/exe`)
  return { path, sha256: sha256 ?? createHash("sha256").update(readFileSync(path)).digest("hex") }
}

afterEach(() => {
  for (const directory of temporary.splice(0)) rmSync(directory, { recursive: true, force: true })
  if (originalPath === undefined) delete process.env.PATH
  else process.env.PATH = originalPath
  if (originalDisplay === undefined) delete process.env.DISPLAY
  else process.env.DISPLAY = originalDisplay
  for (const key of [
    "TEST_CAPTURE_OWNER_PID",
    "TEST_CAPTURE_WINDOWS",
    "TEST_CAPTURE_VISIBLE_WINDOWS",
    "TEST_CAPTURE_STARTED",
    "TEST_CAPTURE_FINISHED",
    "TEST_CAPTURE_RELEASE",
    "TEST_CAPTURE_STDIN",
    "TEST_CAPTURE_PNG",
    "TEST_CAPTURE_FAIL",
    "TEST_CAPTURE_WIDTH",
    "TEST_CAPTURE_HEIGHT",
    "TEST_CAPTURE_X",
    "TEST_CAPTURE_Y",
    "TEST_CAPTURE_SCREEN",
    "TEST_CAPTURE_GEOMETRY_SHELL",
    "TEST_CAPTURE_GEOMETRY_WINDOW",
    "TEST_CAPTURE_HELPER_WINDOW",
    "TEST_CAPTURE_HELPER_OWNER_PID",
    "TEST_CAPTURE_HELPER_X",
    "TEST_CAPTURE_HELPER_Y",
    "TEST_CAPTURE_HELPER_WIDTH",
    "TEST_CAPTURE_HELPER_HEIGHT",
    "TERMINFO_FOCUS_HELPER_WINDOW",
    "TERMINFO_FOCUS_HELPER_PID",
    "TEST_CAPTURE_SCREEN_WIDTH",
    "TEST_CAPTURE_SCREEN_HEIGHT",
    "TEST_CAPTURE_FORCE_CAPTURE",
    "TEST_CAPTURE_XWD_SIZE",
    "TEST_CAPTURE_CHROME_ROWS",
    "TEST_CAPTURE_MAGICK_ARGS",
  ]) {
    delete process.env[key]
  }
})

test.runIf(process.platform === "linux")(
  "a delayed capture keeps the original window and leaves the daemon event loop available",
  async () => {
    const { directory, started, finished, release, stdin } = fixture()
    const { captureRaw } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
    // A new search would now select a different window; capture must keep its original target.
    process.env.TEST_CAPTURE_WINDOWS = "99"
    const pending = captureRaw({ featureId: "fixture", role: "control", label: "fixture frame" })
    for (let n = 0; n < 100 && !existsSync(started); n++) await new Promise((resolve) => setTimeout(resolve, 10))
    expect(existsSync(started)).toBe(true)
    let eventLoopTicked = false
    setTimeout(() => {
      eventLoopTicked = true
    }, 0)
    await new Promise((resolve) => setTimeout(resolve, 20))
    expect(eventLoopTicked).toBe(true)
    expect(existsSync(finished)).toBe(false)

    writeFileSync(release, "continue")
    const { result } = await pending
    expect(result.frame.ref).toMatch(/^sha256:[a-f0-9]{64}$/)
    expect(readFileSync(stdin, "utf8")).toBe("xwd-window-42")
  },
)

// The installed Linux arm, not a fake: its raw path carries the locate request to the finalizer (33000).
test.runIf(process.platform === "linux")(
  "the Linux capture installer answers a locate request from its decoded frame",
  async () => {
    const { directory, release } = fixture()
    writeFileSync(release, "continue")
    // The stub converter paints the top chrome rows RGB 1,1,1 and the rest black.
    process.env.TEST_CAPTURE_CHROME_ROWS = "3"
    const { captureRaw } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
    const checkpoint = { featureId: "fixture", role: "control" as const, label: "layout check" }
    const found = await captureRaw({ ...checkpoint, locate: { rgb: [1, 1, 1] } })
    const width = found.decoded.width
    expect(found.result.frame.located).toEqual({ box: { x: 0, y: 0, width, height: 3 }, pixels: width * 3 })
    const absent = await captureRaw({ ...checkpoint, locate: { rgb: [9, 9, 9] } })
    expect(absent.result.frame.located).toBeNull()
    const plain = await captureRaw(checkpoint)
    expect(plain.result.frame).not.toHaveProperty("located")
    expect(plain.result.trace).not.toHaveProperty("locate")
  },
)

// The existing XWD fixtures cannot prove that an OSC22 frame contains the X pointer.
test.runIf(process.platform === "linux")("OSC22 captures pointer PNG through the same owned window", async () => {
  const { directory, release, stdin, png } = fixture()
  writeFileSync(release, "continue")
  const { captureRaw } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
  const { result } = await captureRaw({
    featureId: "extensions.osc22-pointer",
    role: "control",
    label: "pointer baseline",
  })
  const args = readFileSync(`${png}.scrot-args`, "utf8").trim().split("\n")
  expect(args.slice(0, -1)).toEqual(["--pointer", "--window", "42", "--silent", "--format", "png", "--file"])
  expect(args.at(-1)).toMatch(/\/frames\/\.osc22-[^/]+\/pointer\.png$/)
  expect(existsSync(args.at(-1)!)).toBe(false)
  expect(readdirSync(join(directory, "frames")).some((name) => name.startsWith(".osc22-"))).toBe(false)
  expect(readFileSync(stdin)).toEqual(readFileSync(png))
  expect(result.frame.sourceRef).toBe(`sha256:${createHash("sha256").update(readFileSync(png)).digest("hex")}`)
  expect(readdirSync(join(directory, "frames")).some((name) => name.endsWith(".xwd"))).toBe(false)
})

// A failed producer can leave partial PNG bytes; they must never survive as capture evidence.
test.runIf(process.platform === "linux").each(["failure", "deadline"] as const)(
  "OSC22 %s removes temporary output and preserves the command error",
  async (mode) => {
    const { directory, release } = fixture()
    if (mode === "failure") {
      writeFileSync(release, "continue")
      process.env.TEST_CAPTURE_FAIL = "scrot"
    }
    const frames = join(directory, "frames")
    const { captureRaw } = await createLinuxCapture(frames, liveExecutable(), () => {})
    await expect(
      captureRaw(
        { featureId: "extensions.osc22-pointer", role: "target", label: "failed pointer" },
        mode === "deadline" ? Date.now() + 1500 : undefined,
      ),
    ).rejects.toMatchObject(
      mode === "failure"
        ? { code: 23, message: expect.stringContaining("scrot output failed") }
        : { killed: true, signal: "SIGKILL" },
    )
    expect(readdirSync(frames)).toEqual([])
  },
)

test.runIf(process.platform === "linux")(
  "OSC22 pointer capture rejects ownership lost during acquisition",
  async () => {
    const { directory, started, release } = fixture()
    const frames = join(directory, "frames")
    const { captureRaw } = await createLinuxCapture(frames, liveExecutable(), () => {})
    const pending = captureRaw({ featureId: "extensions.osc22-pointer", role: "target", label: "pointer target" })
    const rejected = expect(pending).rejects.toThrow("no longer belongs to Kitty")
    for (let n = 0; n < 100 && !existsSync(started); n++) await new Promise((resolve) => setTimeout(resolve, 10))
    expect(existsSync(started)).toBe(true)
    process.env.TEST_CAPTURE_OWNER_PID = "1"
    writeFileSync(release, "continue")
    await rejected
    expect(readdirSync(frames)).toEqual([])
  },
)

test.runIf(process.platform === "linux").each(["before", "during"] as const)(
  "owner loss %s capture rejects the frame without retaining image artifacts",
  async (when) => {
    const { directory, started, release } = fixture()
    const frames = join(directory, "frames")
    const { captureRaw } = await createLinuxCapture(frames, liveExecutable(), () => {})
    if (when === "before") process.env.TEST_CAPTURE_OWNER_PID = "1"
    const pending = captureRaw({ featureId: "fixture", role: "target", label: "owned frame" })
    const rejected = expect(pending).rejects.toThrow("no longer belongs to Kitty")
    if (when === "during") {
      for (let n = 0; n < 500 && !existsSync(started); n++) await new Promise((resolve) => setTimeout(resolve, 10))
      expect(existsSync(started)).toBe(true)
      process.env.TEST_CAPTURE_OWNER_PID = "1"
      writeFileSync(release, "continue")
    }
    await rejected
    expect(existsSync(started)).toBe(when === "during")
    expect(readdirSync(frames)).toEqual([])
  },
)

test.runIf(process.platform === "linux").each(["before", "during"] as const)(
  "another visible top-level window %s capture rejects without retaining image artifacts",
  async (when) => {
    const { directory, started, release } = fixture()
    const frames = join(directory, "frames")
    if (when === "before") process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42 99"
    const create = createLinuxCapture(frames, liveExecutable(), () => {})
    if (when === "before") {
      await expect(create).rejects.toThrow("visible top-level")
    } else {
      const { captureRaw } = await create
      const pending = captureRaw({ featureId: "fixture", role: "target", label: "owned frame" })
      const rejected = expect(pending).rejects.toThrow("visible top-level")
      for (let n = 0; n < 500 && !existsSync(started); n++) await new Promise((resolve) => setTimeout(resolve, 10))
      expect(existsSync(started)).toBe(true)
      process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42 99"
      writeFileSync(release, "continue")
      await rejected
    }
    expect(existsSync(frames) ? readdirSync(frames) : []).toEqual([])
  },
)

function recordFocusHelper(windowId: string, pid: string = String(process.pid)): void {
  process.env.TERMINFO_FOCUS_HELPER_WINDOW = windowId
  process.env.TERMINFO_FOCUS_HELPER_PID = pid
  process.env.TEST_CAPTURE_HELPER_WINDOW = windowId
  process.env.TEST_CAPTURE_HELPER_OWNER_PID = pid
}

// #33305: the run's focus witness is a second visible top-level window, so capture must exclude the
// exact helper it recorded while every other extra window stays the refusal it always was.
test.runIf(process.platform === "linux")(
  "a recorded focus helper beside the owned window is excluded from the capture census",
  async () => {
    const { directory, release } = fixture()
    writeFileSync(release, "continue")
    process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42 99"
    recordFocusHelper("99")
    const { captureRaw } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
    const { result } = await captureRaw({ featureId: "fixture", role: "target", label: "helper frame" })
    expect(result.trace.windowId).toBe("42")
  },
)

test.runIf(process.platform === "linux")(
  "a recorded focus helper overlapping the owned window refuses the capture with both rectangles",
  async () => {
    const { directory, release } = fixture()
    writeFileSync(release, "continue")
    process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42 99"
    process.env.TEST_CAPTURE_HELPER_X = "10"
    process.env.TEST_CAPTURE_HELPER_Y = "10"
    recordFocusHelper("99")
    const frames = join(directory, "frames")
    const { captureRaw } = await createLinuxCapture(frames, liveExecutable(), () => {})
    await expect(captureRaw({ featureId: "fixture", role: "target", label: "overlapped frame" })).rejects.toThrow(
      /focus helper window 99 \(160x40 at 10,10\) intersects .*42 \(640x480 at 0,0\)/,
    )
    expect(readdirSync(frames)).toEqual([])
  },
)

test.runIf(process.platform === "linux")(
  "a recorded focus helper that is not in the census refuses the capture and names it",
  async () => {
    const { directory } = fixture()
    recordFocusHelper("99")
    await expect(createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})).rejects.toThrow(
      /focus helper window 99 is not a visible top-level window during capture; found 42/,
    )
  },
)

test.runIf(process.platform === "linux")(
  "a focus helper whose owner differs from the receipt's PID cannot be excluded from the census",
  async () => {
    const { directory } = fixture()
    process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42 99"
    recordFocusHelper("99")
    process.env.TERMINFO_FOCUS_HELPER_PID = String(process.pid + 1)
    await expect(createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})).rejects.toThrow(
      /focus helper window 99 belongs to PID \d+, not the recorded PID \d+/,
    )
  },
)

test.runIf(process.platform === "linux")(
  "a recorded helper does not excuse an unrelated third visible top-level window",
  async () => {
    const { directory } = fixture()
    process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42 99 100"
    recordFocusHelper("99")
    await expect(createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})).rejects.toThrow(
      /Capture requires only its owned visible top-level window; found 42, 99, 100$/,
    )
  },
)

test.runIf(process.platform === "linux")(
  "without a recorded helper id a second visible window still refuses even when a helper PID is set",
  async () => {
    const { directory } = fixture()
    process.env.TEST_CAPTURE_VISIBLE_WINDOWS = "543 42 99"
    process.env.TERMINFO_FOCUS_HELPER_PID = String(process.pid)
    await expect(createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})).rejects.toThrow(
      /Capture requires only its owned visible top-level window; found 42, 99$/,
    )
  },
)

test.runIf(process.platform === "linux")(
  "a helper window id without the PID its receipt records refuses instead of excluding any window",
  async () => {
    const { directory } = fixture()
    process.env.TERMINFO_FOCUS_HELPER_WINDOW = "99"
    await expect(createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})).rejects.toThrow(
      /TERMINFO_FOCUS_HELPER_PID must/,
    )
  },
)

test.runIf(process.platform === "linux")(
  "a failed real capture command rejects with its stderr and exit status",
  async () => {
    const { directory } = fixture()
    process.env.TEST_CAPTURE_FAIL = "owner"
    await expect(createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})).rejects.toMatchObject({
      code: 17,
      message: expect.stringContaining("owner lookup failed"),
    })
  },
)

test.runIf(process.platform === "linux")(
  "a matching process path with the wrong executable digest cannot authorize capture",
  async () => {
    const { directory } = fixture()
    await expect(
      createLinuxCapture(join(directory, "frames"), liveExecutable("0".repeat(64)), () => {}),
    ).rejects.toThrow("executable digest mismatch")
  },
)

test.runIf(process.platform === "linux")(
  "the capture conversion excludes the PNG date and time chunks (#30764)",
  async () => {
    const { directory, release } = fixture()
    const argsPath = join(directory, "magick-args")
    process.env.TEST_CAPTURE_MAGICK_ARGS = argsPath
    // The fixture xwd waits for this file before it hands over the frame, as a real capture does.
    writeFileSync(release, "continue")
    const { captureRaw } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
    await captureRaw({ featureId: "fixture", role: "control", label: "fixture frame" })
    // Later magick calls decode the frame for pixels; the conversion is the first one.
    // The literal pin, not the constant: a dropped flag has to fail here even where magick is absent.
    expect(readFileSync(argsPath, "utf8").trim().split("\n").slice(0, PNG_CONVERSION_ARGS.length)).toEqual([
      "xwd:-",
      "-define",
      "png:exclude-chunks=date,time",
      "-set",
      "comment",
      "",
      "png:-",
    ])
  },
)

/**
 * Two runs of an unchanged screen must mint one evidence hash, whatever window name the XWD carries.
 * ImageMagick is only on the capture hosts (flakes runtimeTools, not the plain shell PATH), so the
 * proof runs where it exists; the test's own NAME carries that reason, because a skipIf reports only
 * that it skipped.
 */
const realMagick = (() => {
  const probe = spawnSync("magick", ["-version"], { encoding: "utf8" })
  return probe.status === 0 ? "magick" : undefined
})()

/** The XWD's window-name field, rewritten to a different name of the caller's choosing. */
function renamedXwd(screen: Buffer, name: string): Buffer {
  const headerSize = screen.readUInt32BE(0)
  if (headerSize < 100 || headerSize > screen.length) throw new Error(`Unusable XWD header size ${headerSize}`)
  const header = Buffer.alloc(100 + name.length + 1)
  screen.copy(header, 0, 0, 100)
  header.write(name, 100, "latin1")
  header.writeUInt32BE(100 + name.length + 1, 0)
  return Buffer.concat([header, screen.subarray(headerSize)])
}

/** Every chunk of a PNG as `TYPE` or `TYPE:key` for the text chunks, in file order. */
function pngChunks(png: Buffer): string[] {
  if (png.subarray(0, 8).toString("latin1") !== "\x89PNG\r\n\x1a\n") throw new Error("Not a PNG")
  const keys: string[] = []
  let at = 8
  while (at < png.length) {
    const length = png.readUInt32BE(at)
    const type = png.subarray(at + 4, at + 8).toString("latin1")
    if (type === "tEXt" || type === "iTXt" || type === "zTXt") {
      const body = png.subarray(at + 8, at + 8 + length)
      keys.push(`${type}:${body.subarray(0, body.indexOf(0)).toString("latin1")}`)
    } else keys.push(type)
    at += 12 + length
    if (type === "IEND") break
  }
  return keys
}

/** One text chunk's value, or undefined when the chunk is absent. */
function pngTextValue(png: Buffer, key: string): string | undefined {
  let at = 8
  while (at < png.length) {
    const length = png.readUInt32BE(at)
    const type = png.subarray(at + 4, at + 8).toString("latin1")
    const body = png.subarray(at + 8, at + 8 + length)
    const split = body.indexOf(0)
    if (type === "tEXt" && split >= 0 && body.subarray(0, split).toString("latin1") === key) {
      return body.subarray(split + 1).toString("latin1")
    }
    at += 12 + length
    if (type === "IEND") break
  }
  return undefined
}

test.skipIf(realMagick === undefined)(
  "no tIME, no date text and no window name reach the PNG, so one screen keeps one sha256 (#30764; skipped where magick is not on PATH)",
  () => {
    const screen = spawnSync("magick", ["-size", "40x20", "xc:red", "xwd:-"]).stdout
    expect(screen.length).toBeGreaterThan(0)
    const convert = (input: Buffer, args: readonly string[]) =>
      spawnSync("magick", [...args], { input, env: { ...process.env, SOURCE_DATE_EPOCH: "" } }).stdout
    const fixed = convert(renamedXwd(screen, "first-window"), PNG_CONVERSION_ARGS)
    const renamed = convert(renamedXwd(screen, "second-window"), PNG_CONVERSION_ARGS)

    expect(pngChunks(fixed)).not.toContain("tIME")
    expect(pngChunks(fixed).filter((key) => /^(tEXt|iTXt|zTXt):date:/.test(key))).toEqual([])
    // The comment chunk stays, but the window name inside it does not.
    expect(pngTextValue(fixed, "comment")).toBe("")
    // The whole point: identical pixels under a different window name are the same evidence.
    expect(createHash("sha256").update(renamed).digest("hex")).toBe(createHash("sha256").update(fixed).digest("hex"))

    // Control: without the exclusion the same input is unstable, and that is what the tIME assert sees.
    const plain = pngChunks(convert(renamedXwd(screen, "first-window"), ["xwd:-", "png:-"]))
    expect(plain).toContain("tIME")
    expect(plain).toContain("tEXt:comment")
    expect(pngTextValue(convert(renamedXwd(screen, "first-window"), ["xwd:-", "png:-"]), "comment")).toBe(
      "first-window",
    )
  },
  60_000,
)

const GHOSTTY_GEOMETRY = { cellWidth: 13, cellHeight: 24, textWidth: 780, textHeight: 528 }

test("cells map to window pixels from the text area's own measured origin", () => {
  expect(
    cellRectangle({
      cells: { top: 2, left: 3, bottom: 2, right: 4 },
      pixelGeometry: { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 256 },
      textOrigin: { x: 80, y: 172 },
      windowWidth: 800,
      windowHeight: 600,
    }),
  ).toEqual({ x: 96, y: 188, width: 16, height: 16 })
})

test("a rectangle that leaves the window is loud, never clipped", () => {
  expect(() =>
    cellRectangle({
      cells: { top: 1, left: 1, bottom: 1, right: 100 },
      pixelGeometry: { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 256 },
      textOrigin: { x: 80, y: 172 },
      windowWidth: 800,
      windowHeight: 600,
    }),
  ).toThrow(/leaves the measured 800x600 window/)
  expect(() =>
    cellRectangle({
      cells: { top: 1, left: 1, bottom: 1, right: 2 },
      pixelGeometry: { cellWidth: 0, cellHeight: 16, textWidth: 640, textHeight: 256 },
      textOrigin: { x: 80, y: 172 },
      windowWidth: 800,
      windowHeight: 600,
    }),
  ).toThrow(/empty or negative region/)
})

test("a clipped text area crops its visible last row instead of the padding beyond it", () => {
  const geometry = { cellWidth: 6, cellHeight: 13, textWidth: 798, textHeight: 598 }
  expect(
    cellRectangle({
      cells: { top: 46, left: 1, bottom: 46, right: 133 },
      pixelGeometry: geometry,
      textOrigin: { x: 0, y: 29 },
      windowWidth: 800,
      windowHeight: 628,
      visible: { width: 798, height: 597 },
    }),
  ).toEqual({ x: 0, y: 614, width: 798, height: 12 })
  expect(
    cellRectangle({
      cells: { top: 1, left: 1, bottom: 45, right: 133 },
      pixelGeometry: geometry,
      textOrigin: { x: 0, y: 29 },
      windowWidth: 800,
      windowHeight: 628,
      visible: { width: 798, height: 597 },
    }),
  ).toEqual({ x: 0, y: 29, width: 798, height: 585 })
})

test("a cell beyond the clipped text area is loud, not silently clamped", () => {
  expect(() =>
    cellRectangle({
      cells: { top: 47, left: 1, bottom: 47, right: 1 },
      pixelGeometry: { cellWidth: 6, cellHeight: 13, textWidth: 798, textHeight: 598 },
      textOrigin: { x: 0, y: 29 },
      windowWidth: 800,
      windowHeight: 628,
      visible: { width: 798, height: 597 },
    }),
  ).toThrow(/leave the 133x46 text area/)
})

test("the window's own pixel size comes from the measured geometry, and a missing one is loud", () => {
  expect(windowPixels("WINDOW=4194317\nX=0\nY=0\nWIDTH=800\nHEIGHT=600\nSCREEN=0\n")).toEqual({
    width: 800,
    height: 600,
  })
  expect(() => windowPixels("WINDOW=4194317\nX=0\nY=0\nSCREEN=0\n")).toThrow(/pixel size/)
})

test("the screen's pixel size comes from xdpyinfo, and a missing one is loud", () => {
  expect(screenPixels("screen #0:\n  dimensions:    1920x1080 pixels (508x285 millimeters)\n")).toEqual({
    width: 1920,
    height: 1080,
  })
  expect(() => screenPixels("root window id: 0x21f\n")).toThrow(/screen/)
})

test("the capture's pixel size comes from magick identify, and a missing one is loud", () => {
  expect(capturePixels("1306x816")).toEqual({ width: 1306, height: 816 })
  expect(capturePixels("1306x816\n")).toEqual({ width: 1306, height: 816 })
  expect(() => capturePixels("xwd:- XWD 8-bit\n")).toThrow(/capture/)
})

test.runIf(process.platform === "linux")(
  "a 1304x814 window yields a whole-window pixelsDigest of 4245824 rgba bytes (#28580)",
  async () => {
    // xterm 411 measured 1304x814; 3145728 is 1024x768x4 (the old Xvfb screen), not a 3 MiB
    // execFile cap. command() already admits 32 MiB, so the collector must hash the full frame.
    // The fixture xwd adds a 1px border unless -nobdrs is passed (#28590); this row is that
    // contract: capture dimensions match the xdotool client area.
    const { directory, release } = fixture()
    process.env.TEST_CAPTURE_WIDTH = "1304"
    process.env.TEST_CAPTURE_HEIGHT = "814"
    writeFileSync(release, "continue")
    const { captureRaw } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
    const { result } = await captureRaw({
      featureId: "editing.delete-chars",
      role: "target",
      label: "xterm window",
      cells: { top: 1, left: 1, bottom: 1, right: 1 },
      pixelGeometry: { cellWidth: 8, cellHeight: 16, textWidth: 800, textHeight: 480 },
    })
    expect(result.frame.pixelsDigest).toMatch(/^sha256:[a-f0-9]{64}$/)
    const expected = Buffer.alloc(1304 * 814 * 4)
    expect(result.frame.pixelsDigest).toBe(`sha256:${createHash("sha256").update(expected).digest("hex")}`)
  },
)

test.runIf(process.platform === "linux")("window 1304x814 on a 1024x768 screen names the clip (#28590)", async () => {
  // 3145728 was 1024x768x4. Naming the screen vs the window is what stops the next
  // diagnosis from chasing execFile maxBuffer.
  const { directory } = fixture()
  process.env.TEST_CAPTURE_WIDTH = "1304"
  process.env.TEST_CAPTURE_HEIGHT = "814"
  process.env.TEST_CAPTURE_SCREEN_WIDTH = "1024"
  process.env.TEST_CAPTURE_SCREEN_HEIGHT = "768"
  await expect(createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})).rejects.toThrow(
    "window 1304x814 exceeds the 1024x768 screen",
  )
})

// #33117: a checkpoint naming a same-shot control region still acquires exactly once (one xwd
// invocation); both region digests are crops of that one acquired image.
test.runIf(process.platform === "linux")(
  "Linux capture crops target and same-shot control from one acquired image",
  async () => {
    const { directory, release } = fixture()
    const acquisitions = join(directory, "xwd-count")
    const xwd = join(directory, "xwd")
    const xwdReal = join(directory, "xwd-real")
    writeFileSync(xwdReal, readFileSync(xwd))
    chmodSync(xwdReal, 0o700)
    executable(xwd, `printf x >> "$TEST_CAPTURE_XWD_COUNT"\nexec "${xwdReal}" "$@"`)
    process.env.TEST_CAPTURE_XWD_COUNT = acquisitions
    process.env.TEST_CAPTURE_WIDTH = "800"
    process.env.TEST_CAPTURE_HEIGHT = "600"
    writeFileSync(release, "continue")
    try {
      const { capture } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
      writeFileSync(acquisitions, "")
      const result = await capture(
        {
          featureId: "sgr.blink",
          role: "target",
          label: "styled row beside plain row",
          cells: { top: 3, left: 1, bottom: 3, right: 3 },
          controlCells: { top: 1, left: 1, bottom: 1, right: 3 },
          pixelGeometry: GHOSTTY_GEOMETRY,
        },
        { origin: { x: 0, y: 0 }, basis: "collector complete witnessed raster" },
      )
      expect(readFileSync(acquisitions, "utf8")).toBe("x")
      expect(result.frame.regionRectangle).toEqual({ x: 0, y: 48, width: 39, height: 24 })
      expect(result.frame.controlRegionRectangle).toEqual({ x: 0, y: 0, width: 39, height: 24 })
      expect(result.frame.regionDigest).toMatch(/^sha256:/)
      expect(result.frame.controlRegionDigest).toMatch(/^sha256:/)
    } finally {
      delete process.env.TEST_CAPTURE_XWD_COUNT
    }
  },
)

test.runIf(process.platform === "linux")(
  "a title bar inside the client area places the compared region below it (#28756)",
  async () => {
    // The fixture paints the first 56 rows in another colour, the way ghostty 1.3.1 draws its own
    // title bar inside the client area. The terminal's surface is then rows 56..599, and the
    // reported text area belongs to THAT box: a window-centred region would read the title bar.
    const { directory, release } = fixture()
    process.env.TEST_CAPTURE_WIDTH = "800"
    process.env.TEST_CAPTURE_HEIGHT = "600"
    process.env.TEST_CAPTURE_CHROME_ROWS = "56"
    process.env.TEST_CAPTURE_HEIGHT = "595"
    writeFileSync(release, "continue")
    const { capture } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
    const registration = { origin: { x: 10, y: 56 }, basis: "collector complete witnessed raster" }
    const result = await capture(
      {
        featureId: "fixture.title-bar",
        role: "target",
        label: "fixture window",
        cells: { top: 1, left: 1, bottom: 1, right: 3 },
        pixelGeometry: GHOSTTY_GEOMETRY,
      },
      registration,
    )
    process.env.TEST_CAPTURE_CHROME_ROWS = "59"
    const changed = await capture(
      {
        featureId: "fixture.title-bar",
        role: "target",
        label: "changed dominant colour",
        cells: { top: 1, left: 1, bottom: 1, right: 3 },
        pixelGeometry: GHOSTTY_GEOMETRY,
      },
      registration,
    )
    expect([result.trace.textArea, changed.trace.textArea]).toMatchObject([
      { origin: { x: 10, y: 56 } },
      { origin: { x: 10, y: 56 } },
    ])
    expect(changed.frame.pixelsDigest).not.toBe(result.frame.pixelsDigest)
    expect(changed.frame.regionRectangle).toEqual(result.frame.regionRectangle)
    expect(result.trace.rectangle).toEqual({ x: 10, y: 56, width: 39, height: 24 })
    // The frame carries the same rectangle as the trace, beside the digest cut from it, so a
    // row oracle can tell two frames' crops apart (29580).
    expect(result.frame.regionRectangle).toEqual(result.trace.rectangle)
    expect(result.trace.cropCommand).toEqual([
      "magick",
      "xwd:-",
      "-crop",
      "39x24+10+56",
      "+repage",
      "-depth",
      "8",
      "rgba:-",
    ])
  },
)

test.runIf(process.platform === "linux")("capture 1306x816 vs window 1304x814 names both sizes (#28590)", async () => {
  // xterm 411 after the Xvfb grow: xwd included a 1px border, 4262784 vs 4245824.
  const { directory, release } = fixture()
  process.env.TEST_CAPTURE_WIDTH = "1304"
  process.env.TEST_CAPTURE_HEIGHT = "814"
  process.env.TEST_CAPTURE_FORCE_CAPTURE = "1306x816"
  writeFileSync(release, "continue")
  const { captureRaw } = await createLinuxCapture(join(directory, "frames"), liveExecutable(), () => {})
  await expect(
    captureRaw({
      featureId: "editing.delete-chars",
      role: "target",
      label: "xterm window",
      cells: { top: 1, left: 1, bottom: 1, right: 1 },
      pixelGeometry: { cellWidth: 8, cellHeight: 16, textWidth: 800, textHeight: 480 },
    }),
  ).rejects.toThrow("capture 1306x816 differs from window 1304x814 (border included?)")
})

// C's PNG adapter must use its calibrated named origin, never Linux colour centring.
test.each(["xwd", "png"] as const)("shared %s capture digests decoded pixels at the named origin", async (format) => {
  const { directory, png } = fixture()
  const source = {
    bytes: format === "png" ? readFileSync(png) : Buffer.from("fixture-xwd"),
    format,
    width: 640,
    height: 480,
    capturedAt: 123,
  }
  const checkpoint = {
    featureId: "fixture.shared",
    role: "target" as const,
    label: "shared",
    cells: { top: 2, left: 3, bottom: 2, right: 4 },
    pixelGeometry: { cellWidth: 8, cellHeight: 16, textWidth: 640, textHeight: 480 },
  }
  const result = await finishCapture({
    onRetained: () => {},
    directory,
    checkpoint,
    source,
    png: readFileSync(png),
    origin: { origin: { x: 2, y: 34 }, basis: "solid-cell calibration" },
    trace: { converter: "fixture" },
  })
  expect(result.frame.pixelsDigest).toBe(
    `sha256:${createHash("sha256")
      .update(Buffer.alloc(640 * 480 * 4))
      .digest("hex")}`,
  )
  expect(result.frame.regionDigest).toBe(
    `sha256:${createHash("sha256")
      .update(Buffer.alloc(16 * 16 * 4))
      .digest("hex")}`,
  )
  expect(result.trace.textArea).toEqual({ origin: { x: 2, y: 34 }, basis: "solid-cell calibration" })
  expect(result.trace.rectangle).toEqual({ x: 18, y: 50, width: 16, height: 16 })
  const retained = result.trace.retained as Record<string, string>
  expect(readFileSync(join(directory, retained[format]!))).toEqual(source.bytes)
  await expect(
    finishCapture({
      onRetained: () => {},
      directory,
      checkpoint,
      source,
      png: readFileSync(png),
      origin: { origin: { x: 2, y: 34 }, basis: "" },
      trace: {},
    }),
  ).rejects.toThrow(/named text-area origin/)
  await expect(
    finishCapture({
      onRetained: () => {},
      directory,
      checkpoint,
      source,
      png: readFileSync(png),
      origin: { origin: { x: 2.5, y: 34 }, basis: "calibration" },
      trace: {},
    }),
  ).rejects.toThrow(/integers/)
  const unpaired = { ...checkpoint, pixelGeometry: undefined }
  await expect(
    finishCapture({
      onRetained: () => {},
      directory,
      checkpoint: unpaired,
      source,
      png: readFileSync(png),
      origin: { origin: { x: 2, y: 34 }, basis: "calibration" },
      trace: {},
    }),
  ).rejects.toThrow(/without both cells/)
  process.env.TEST_CAPTURE_FORCE_CAPTURE = "639x480"
  await expect(
    finishCapture({
      onRetained: () => {},
      directory,
      checkpoint,
      source,
      png: readFileSync(png),
      origin: { origin: { x: 2, y: 34 }, basis: "calibration" },
      trace: {},
    }),
  ).rejects.toThrow("capture 639x480 differs from window 640x480")
  // A plain frame carries the whole-window digest and resolves no text-area origin (30092): the
  // decode now runs for every pixel frame, so a conversion failure is no longer survivable here.
  delete process.env.TEST_CAPTURE_FORCE_CAPTURE
  const plain = await finishCapture({
    onRetained: () => {},
    directory,
    checkpoint: { featureId: "fixture.plain", role: "control", label: "plain" },
    source,
    png: readFileSync(png),
    origin: () => {
      throw new Error("origin resolver must not run")
    },
    trace: { fixture: "plain" },
  })
  expect(plain.frame).toEqual({
    kind: "pixels",
    role: "control",
    label: "plain",
    capturedAt: 123,
    ref: result.frame.ref,
    sourceRef: result.frame.sourceRef,
    pixelsDigest: `sha256:${createHash("sha256")
      .update(Buffer.alloc(640 * 480 * 4))
      .digest("hex")}`,
  })
  expect(plain.trace).toEqual({ fixture: "plain" })
  process.env.TEST_CAPTURE_FAIL = "conversion"
  await expect(
    finishCapture({
      onRetained: () => {},
      directory,
      checkpoint: { featureId: "fixture.plain", role: "control", label: "plain" },
      source,
      png: readFileSync(png),
      origin: { origin: { x: 2, y: 34 }, basis: "calibration" },
      trace: {},
    }),
  ).rejects.toThrow("conversion failed")
})

// 30092: a whole-frame scrollback capture names no cells, so the old path computed no
// pixelsDigest at all and sameFrame could only compare the encoded container's ref.
test.each(["xwd", "png"] as const)(
  "a whole-frame capture carries a pixels digest and needs no text-area origin (30092)",
  async (format) => {
    const { directory, png } = fixture()
    const source = {
      bytes: format === "png" ? readFileSync(png) : Buffer.from("fixture-xwd"),
      format,
      width: 640,
      height: 480,
      capturedAt: 123,
    }
    const result = await finishCapture({
      onRetained: () => {},
      directory,
      checkpoint: {
        featureId: "erase.screen.scrollback",
        role: "control",
        label: "Bottom of seeded buffer",
      },
      source,
      png: readFileSync(png),
      origin: () => {
        throw new Error("a whole-frame digest names no text area, so no origin may be resolved")
      },
      trace: {},
    })
    expect(result.frame.pixelsDigest).toBe(
      `sha256:${createHash("sha256")
        .update(Buffer.alloc(640 * 480 * 4))
        .digest("hex")}`,
    )
    expect(result.frame.regionDigest).toBeUndefined()
    expect(result.frame.regionRectangle).toBeUndefined()
  },
)

test.runIf(process.platform === "linux")(
  "declared window resize updates expected geometry, crops inside visible startup-clipped origin, refuses past narrowed edge, and restores startup bytes (#32791)",
  async () => {
    const { directory, release } = fixture()
    process.env.TEST_CAPTURE_GEOMETRY_SHELL = "1"
    process.env.TEST_CAPTURE_WIDTH = "800"
    process.env.TEST_CAPTURE_HEIGHT = "600"
    process.env.TEST_CAPTURE_CHROME_ROWS = "56"
    writeFileSync(release, "continue")
    const frames = join(directory, "frames")
    const { capture, captureRaw, declareWindowSize } = await createLinuxCapture(frames, liveExecutable(), () => {})
    expect(declareWindowSize).toBeTypeOf("function")

    // Standalone closure call (C3: needs no `this` receiver) updates expected geometry for extensions.reflow.
    declareWindowSize(520, 600, "extensions.reflow")
    process.env.TEST_CAPTURE_WIDTH = "520"

    const narrowedRaw = await captureRaw({
      featureId: "extensions.reflow",
      role: "control",
      label: "main-shrink raw",
    })
    expect(narrowedRaw.decoded.width).toBe(520)
    expect(narrowedRaw.decoded.height).toBe(600)
    expect(narrowedRaw.decoded.rgba.byteLength).toBe(520 * 600 * 4)
    expect(narrowedRaw.result.trace.geometry).toBe("WINDOW=42\nX=0\nY=0\nWIDTH=520\nHEIGHT=600\nSCREEN=0\n")

    // C2: startup-clipped origin (`visible` set from 800x600 calibration) crops inside 520x600 and refuses past right edge.
    const clippedStartupOrigin = {
      origin: { x: 10, y: 56 },
      visible: { width: 778, height: 528 },
      basis: "collector complete witnessed raster",
    }
    const insideNarrowed = await capture(
      {
        featureId: "extensions.reflow",
        role: "target",
        label: "main-shrink settle 1",
        cells: { top: 1, left: 1, bottom: 1, right: 39 },
        pixelGeometry: GHOSTTY_GEOMETRY,
      },
      clippedStartupOrigin,
    )
    expect(insideNarrowed.frame.regionRectangle).toEqual({ x: 10, y: 56, width: 507, height: 24 })
    expect(insideNarrowed.frame.regionDigest).toBe(
      `sha256:${createHash("sha256")
        .update(Buffer.alloc(507 * 24 * 4))
        .digest("hex")}`,
    )
    expect(insideNarrowed.trace.geometry).toBe("WINDOW=42\nX=0\nY=0\nWIDTH=520\nHEIGHT=600\nSCREEN=0\n")

    await expect(
      capture(
        {
          featureId: "extensions.reflow",
          role: "target",
          label: "past narrowed right edge",
          cells: { top: 1, left: 1, bottom: 1, right: 40 },
          pixelGeometry: GHOSTTY_GEOMETRY,
        },
        clippedStartupOrigin,
      ),
    ).rejects.toThrow(/leaves the measured 520x600 window/)

    // Restoring startup dimensions reproduces the exact startup geometry string and clears probe ownership.
    declareWindowSize(800, 600, "extensions.reflow")
    process.env.TEST_CAPTURE_WIDTH = "800"
    const restoredRaw = await captureRaw({
      featureId: "scrollback.viewport-hold-output",
      role: "control",
      label: "post-restore next probe",
    })
    expect(restoredRaw.decoded.width).toBe(800)
    expect(restoredRaw.decoded.height).toBe(600)
    expect(restoredRaw.result.trace.geometry).toBe("WINDOW=42\nX=0\nY=0\nWIDTH=800\nHEIGHT=600\nSCREEN=0\n")
  },
)

test.runIf(process.platform === "linux")(
  "undeclared window resize, client size snap, or position move is refused naming declared and observed geometry without retaining artifacts (#32791)",
  async () => {
    const { directory, release } = fixture()
    process.env.TEST_CAPTURE_GEOMETRY_SHELL = "1"
    process.env.TEST_CAPTURE_WIDTH = "800"
    process.env.TEST_CAPTURE_HEIGHT = "600"
    writeFileSync(release, "continue")
    const frames = join(directory, "frames")
    const { captureRaw, declareWindowSize } = await createLinuxCapture(frames, liveExecutable(), () => {})

    // Unresized run: undeclared external shrink refuses against frozen startup geometry.
    process.env.TEST_CAPTURE_WIDTH = "520"
    await expect(
      captureRaw({ featureId: "extensions.reflow", role: "target", label: "undeclared shrink" }),
    ).rejects.toThrow(
      "Capture window 42 geometry changed during extensions.reflow: declared 800x600 at 0,0, observed 520x600 at 0,0",
    )
    expect(readdirSync(frames)).toEqual([])

    // Declared resize where client snaps its own width after windowsize (520 -> 518) names both sizes.
    declareWindowSize(520, 600, "extensions.reflow")
    process.env.TEST_CAPTURE_WIDTH = "518"
    await expect(captureRaw({ featureId: "extensions.reflow", role: "target", label: "snapped size" })).rejects.toThrow(
      "Capture window 42 geometry changed during extensions.reflow: declared 520x600 at 0,0, observed 518x600 at 0,0",
    )
    expect(readdirSync(frames)).toEqual([])

    // Declared resize where X,Y moves despite matching WIDTHxHEIGHT is also refused with coordinates.
    process.env.TEST_CAPTURE_WIDTH = "520"
    process.env.TEST_CAPTURE_X = "4"
    process.env.TEST_CAPTURE_Y = "2"
    await expect(captureRaw({ featureId: "extensions.reflow", role: "target", label: "moved window" })).rejects.toThrow(
      "Capture window 42 geometry changed during extensions.reflow: declared 520x600 at 0,0, observed 520x600 at 4,2",
    )
    expect(readdirSync(frames)).toEqual([])
  },
)

test.runIf(process.platform === "linux")(
  "window geometry change during capture after a declared resize is refused without retaining image artifacts (#32791)",
  async () => {
    const { directory, started, release } = fixture()
    process.env.TEST_CAPTURE_GEOMETRY_SHELL = "1"
    process.env.TEST_CAPTURE_WIDTH = "800"
    process.env.TEST_CAPTURE_HEIGHT = "600"
    const frames = join(directory, "frames")
    const { captureRaw, declareWindowSize } = await createLinuxCapture(frames, liveExecutable(), () => {})

    declareWindowSize(520, 600, "extensions.reflow")
    process.env.TEST_CAPTURE_WIDTH = "520"
    const pending = captureRaw({ featureId: "extensions.reflow", role: "target", label: "mid-capture resize" })
    const rejected = expect(pending).rejects.toThrow(
      "Capture window 42 geometry changed during extensions.reflow: declared 520x600 at 0,0, observed 500x600 at 0,0",
    )
    for (let n = 0; n < 500 && !existsSync(started); n++) await new Promise((resolve) => setTimeout(resolve, 10))
    expect(existsSync(started)).toBe(true)
    process.env.TEST_CAPTURE_WIDTH = "500"
    writeFileSync(release, "continue")
    await rejected
    expect(readdirSync(frames)).toEqual([])
  },
)

test.runIf(process.platform === "linux")(
  "declared resize is scoped to its owning probe: an unrestored resize by probe A refuses probe B (#32791)",
  async () => {
    const { directory, release } = fixture()
    process.env.TEST_CAPTURE_GEOMETRY_SHELL = "1"
    process.env.TEST_CAPTURE_WIDTH = "800"
    process.env.TEST_CAPTURE_HEIGHT = "600"
    writeFileSync(release, "continue")
    const frames = join(directory, "frames")
    const { captureRaw, declareWindowSize } = await createLinuxCapture(frames, liveExecutable(), () => {})

    declareWindowSize(520, 600, "extensions.reflow")
    process.env.TEST_CAPTURE_WIDTH = "520"
    await expect(
      captureRaw({ featureId: "scrollback.viewport-hold-output", role: "target", label: "leaked narrow window" }),
    ).rejects.toThrow("Capture window 42 left resized by extensions.reflow")
    expect(() => declareWindowSize(600, 600, "input.utf8-mouse-1005")).toThrow(
      "Capture window 42 left resized by extensions.reflow",
    )
    expect(readdirSync(frames)).toEqual([])
  },
)

test.runIf(process.platform === "linux")(
  "declareWindowSize enforces DISPLAY screen bounds without mutating declared geometry (#32791)",
  async () => {
    const { directory, release } = fixture()
    process.env.TEST_CAPTURE_GEOMETRY_SHELL = "1"
    process.env.TEST_CAPTURE_WIDTH = "800"
    process.env.TEST_CAPTURE_HEIGHT = "600"
    process.env.TEST_CAPTURE_SCREEN_WIDTH = "1920"
    process.env.TEST_CAPTURE_SCREEN_HEIGHT = "1080"
    writeFileSync(release, "continue")
    const { captureRaw, declareWindowSize } = await createLinuxCapture(
      join(directory, "frames"),
      liveExecutable(),
      () => {},
    )

    expect(() => declareWindowSize(1921, 600, "extensions.reflow")).toThrow(
      "window 1921x600 exceeds the 1920x1080 screen",
    )
    const unchanged = await captureRaw({
      featureId: "scrollback.viewport-hold-output",
      role: "control",
      label: "unchanged after rejected declaration",
    })
    expect(unchanged.decoded.width).toBe(800)
    expect(unchanged.decoded.height).toBe(600)
  },
)
