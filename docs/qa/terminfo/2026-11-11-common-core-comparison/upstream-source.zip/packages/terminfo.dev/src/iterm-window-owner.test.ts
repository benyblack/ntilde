import { describe, expect, it } from "vitest"
import { parseTerminalAppOwner } from "./owned-terminal.ts"
import { measuredDarwinBackingScale } from "./darwin-capture.ts"

const claim = { asserter: "terminfo-admin", application: "iterm2", launchRunId: "a".repeat(32), workerPid: 123, windowId: 456, tabTty: "/dev/ttys100", intendedVersion: "3.7.7" }
describe("local native-window comparison adapter", () => {
  it("retains only complete, isotropic native 1x/2x window frames", () => {
    const window = { bounds: { x: 0, y: 0, width: 80, height: 63 } } as any
    expect(measuredDarwinBackingScale(window, { width: 80, height: 63 })).toBe(1)
    expect(measuredDarwinBackingScale(window, { width: 160, height: 126 })).toBe(2)
    for (const pixels of [{ width: 160, height: 125 }, { width: 80, height: 126 }, { width: 240, height: 189 }, { width: 0, height: 0 }]) {
      expect(() => measuredDarwinBackingScale(window, pixels)).toThrow()
    }
  })
  it("retains the explicit iTerm identity instead of reinterpreting it as Terminal.app", () => {
    expect(parseTerminalAppOwner(claim).application).toBe("iterm2")
    const { application: _, ...terminal } = claim
    expect(parseTerminalAppOwner(terminal).application).toBeUndefined()
  })
  it("refuses other application declarations and extra owner fields", () => {
    expect(() => parseTerminalAppOwner({ ...claim, application: "ghostty" })).toThrow()
    expect(() => parseTerminalAppOwner({ ...claim, trusted: true })).toThrow()
  })
  it("does not relax the window, worker, TTY or launch identity requirements", () => {
    for (const change of [{ windowId: 0 }, { workerPid: -1 }, { tabTty: "not a tty" }, { launchRunId: "other" }]) {
      expect(() => parseTerminalAppOwner({ ...claim, ...change })).toThrow()
    }
  })
})
