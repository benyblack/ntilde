/**
 * @failure TTY replies can be lost before listening or attributed to the wrong query.
 * @level l2
 * @consumer Real-terminal probe runner
 * @testonly none
 */
import { afterEach, describe, expect, it, vi } from "vitest"
import {
  drainStdin,
  measureRenderedWidth,
  UTF8_DECODE_SAMPLE,
  measureUtf8Decoding,
  query,
  queryMode,
  queryOutcome,
  queryWithSentinel,
  queryWithSentinelOutcome,
  readInjectedOutcome,
  readResponse,
  withRawMode,
  withTTYOperation,
  withTTYQueryTrace,
  writeTTY,
  type TTYTraceEvent,
  type TTYQueryTrace,
} from "./tty.ts"
import { extensionsProbes, sentinelGraceMs, type TermProbeSource } from "@terminfo/probe-defs"
import { IncompleteReplay, readCallLog, type CallLog } from "viprobe"
import { sentinelNegativeResult } from "../../probe-defs/src/helpers.ts"

const originalWrite = process.stdout.write

afterEach(() => {
  process.stdout.write = originalWrite
  process.stdin.removeAllListeners("data")
  vi.restoreAllMocks()
})

function reply(bytes: string) {
  process.stdin.emit("data", Buffer.from(bytes))
}

describe("TTY transaction replies", () => {
  // Direct callback fixtures do not wrap the matched RGB reply in the real recorder.
  it.each([
    { id: "extensions.osc117-reset-highlight-bg", setCode: 17 },
    { id: "extensions.osc119-reset-highlight-fg", setCode: 19 },
  ])("retains the controlled $id callback through TTY recording", async ({ id, setCode }) => {
    const callback = extensionsProbes.find((probe) => probe.id === id)?.term
    if (!callback) throw new Error(`Missing terminal callback for ${id}`)
    const queries: TTYQueryTrace[] = []
    const events: TTYTraceEvent[] = []
    const writes: string[] = []
    const colours = ["1111/2222/3333", "3030/6060/9090", "1111/2222/3333"]
    const querySequence = `\x1b]${setCode};?\x07`
    let queryIndex = 0
    const result = await withTTYOperation(
      () =>
        withTTYQueryTrace(queries, events, () =>
          callback({ queryWithSentinelOutcome, write: writeTTY } as TermProbeSource),
        ),
      {
        write(sequence: string) {
          writes.push(sequence)
          if (sequence.startsWith(querySequence)) {
            const colour = colours[queryIndex++]
            if (!colour) throw new Error(`Unexpected highlight query ${queryIndex}`)
            reply(`\x1b]${setCode};rgb:${colour}\x07\x1b[?1;2c`)
          }
          return true
        },
      } as unknown as NodeJS.WriteStream,
      // Retain a decisive error without asking Vitest to print recursive recorder causes.
    ).catch((error: Error) => ({ error: error.message }))
    expect(result).toMatchObject({ pass: true, observation: { outcome: "supported", assertionType: "query_reply" } })
    expect(queries).toHaveLength(3)
    expect(queries.every((entry) => entry.reason === "reply")).toBe(true)
    expect(events.filter((entry) => entry.kind === "query")).toHaveLength(3)
    expect(writes.at(-1)).toBe(`\x1b]${setCode};rgb:1111/2222/3333\x07`)
  })

  // A silent configured writer must retain the actual query timeout, not a guessed default.
  // Existing byte/order replay assertions did not notice when projection discarded this argument.
  it("retains the actual silent-query timeout and sent bytes through recording and replay", async () => {
    const queries: TTYQueryTrace[] = []
    const events: TTYTraceEvent[] = []
    let captured: CallLog | undefined
    const body = () => queryOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 37)
    const measured = await withTTYOperation(
      () =>
        withTTYQueryTrace(queries, events, body, {
          onLog(log) {
            captured = log
          },
        }),
      {
        write() {
          return true
        },
      } as unknown as NodeJS.WriteStream,
    )
    expect(measured.reason).toBe("timeout")
    expect(queries).toEqual([
      expect.objectContaining({ sequence: "\x1b[6n", timeoutMs: 37, reason: "timeout", raw: "" }),
    ])
    const argumentsSeen: unknown[][] = []
    readCallLog(JSON.parse(JSON.stringify(captured)), {
      onOperation(operation) {
        if (operation.path === "context.matchResponse") argumentsSeen.push([...operation.args])
      },
    })
    expect(argumentsSeen).toHaveLength(1)
    expect(argumentsSeen[0]?.[1]).toBe(37)
    expect(argumentsSeen[0]?.[4]).toBe("\x1b[6n")
    const replayQueries: TTYQueryTrace[] = []
    const replayed = await withTTYOperation(
      () =>
        withTTYQueryTrace(replayQueries, [], body, {
          mode: "replay",
          log: readCallLog(JSON.parse(JSON.stringify(captured))),
        }),
      {
        write() {
          throw new Error("Silent-query replay attempted native I/O")
        },
      } as unknown as NodeJS.WriteStream,
    )
    expect(replayed).toEqual(measured)
    expect(replayQueries).toEqual(queries)
  })

  it.each([false, true])(
    "refuses a completed TTY artifact after failed injection (reply settled: %s)",
    async (settled) => {
      const queries: TTYQueryTrace[] = []
      const events: TTYTraceEvent[] = []
      let published = false
      const listeners = process.stdin.listenerCount("data")
      const failure = new Error("Input injection lost custody")
      const attempt = withTTYQueryTrace(
        queries,
        events,
        () =>
          readResponse(/^a/, 50, async () => {
            if (settled) {
              reply("a")
              for (let index = 0; index < 10; index++) await Promise.resolve()
            }
            throw failure
          }),
        {
          onLog() {
            published = true
          },
        },
      )
      if (settled) {
        await expect(attempt).rejects.toBe(failure)
      } else {
        await expect(attempt).rejects.toBeInstanceOf(IncompleteReplay)
        await expect(attempt).rejects.toMatchObject({ cause: failure })
      }
      await expect(attempt).rejects.toThrow(/Input injection lost custody/)
      expect(published).toBe(false)
      if (settled) {
        expect(queries).toEqual([
          { sequence: "", timeoutMs: 50, reason: "reply", raw: "a", rawBase64: "YQ==", match: ["a"] },
        ])
        expect(events).toEqual([{ kind: "query", ...queries[0] }])
      } else {
        expect(queries).toEqual([])
        expect(events).toEqual([])
      }
      expect(process.stdin.listenerCount("data")).toBe(listeners)
    },
  )

  // Recorder identity and distinct injection causes miss their same-error TTY join.
  it("keeps a sticky recorder failure fatal without making it its own cause", async () => {
    const queries: TTYQueryTrace[] = []
    const events: TTYTraceEvent[] = []
    const listeners = process.stdin.listenerCount("data")
    let bodyError: Error | undefined
    let finalError: Error | undefined
    let published = false
    try {
      await withTTYOperation(
        () =>
          withTTYQueryTrace(
            queries,
            events,
            async () => {
              const result = await queryOutcome(
                "\x1b]17;?\x07",
                /\x1b\]17;rgb:([0-9a-f]+)\/([0-9a-f]+)\/([0-9a-f]+)\x07/,
                50,
              )
              try {
                if (!result.match) throw new Error("Fixture did not return a matched colour")
                const [, red] = result.match
                return red
              } catch (error) {
                if (!(error instanceof Error)) throw error
                bodyError = error
                throw error
              }
            },
            {
              onLog() {
                published = true
              },
            },
          ),
        {
          write() {
            reply("\x1b]17;rgb:1111/2222/3333\x07")
            return true
          },
        } as unknown as NodeJS.WriteStream,
      )
    } catch (error) {
      if (!(error instanceof Error)) throw error
      finalError = error
    }
    // Scalar assertions keep a broken cause graph away from the failure reporter.
    expect(finalError instanceof IncompleteReplay).toBe(true)
    expect(finalError === bodyError).toBe(true)
    expect(finalError?.cause === undefined).toBe(true)
    expect(finalError?.message).toBe("Incomplete: call log cannot encode prototype [object Array Iterator]")
    expect(published).toBe(false)
    expect(queries).toEqual([])
    expect(events).toEqual([])
    expect(process.stdin.listenerCount("data")).toBe(listeners)
  })

  it("retains sentinel ordering facts through offline TTY replay", async () => {
    const queries: TTYQueryTrace[] = []
    const events: TTYTraceEvent[] = []
    let captured: CallLog | undefined
    const sentinel = "\x1b[?1;2c"
    const response = "\x1b[8;24;80t"
    const out = {
      write() {
        reply(sentinel)
        setTimeout(() => reply(response), 1)
        return true
      },
    } as unknown as NodeJS.WriteStream
    const body = () => queryWithSentinelOutcome("\x1b[18t", /\x1b\[8;(\d+);(\d+)t/, 100, 20)
    const measured = await withTTYOperation(
      () =>
        withTTYQueryTrace(queries, events, body, {
          onLog(log) {
            captured = log
          },
        }),
      out,
    )
    expect(measured.sentinel).toEqual({ atMs: expect.any(Number), graceMs: 20 })
    expect(queries).toEqual([
      {
        sequence: "\x1b[18t\x1b[c",
        timeoutMs: 100,
        reason: "reply",
        raw: sentinel + response,
        rawBase64: Buffer.from(sentinel + response).toString("base64"),
        match: [response, "24", "80"],
        sentinel: measured.sentinel,
      },
    ])
    expect(events).toEqual([{ kind: "query", ...queries[0] }])
    const replayQueries: TTYQueryTrace[] = []
    const replayEvents: TTYTraceEvent[] = []
    const offline = {
      write() {
        throw new Error("Offline sentinel replay attempted native I/O")
      },
    } as unknown as NodeJS.WriteStream
    const replayed = await withTTYOperation(
      () =>
        withTTYQueryTrace(replayQueries, replayEvents, body, {
          mode: "replay",
          log: readCallLog(JSON.parse(JSON.stringify(captured))),
        }),
      offline,
    )
    expect(replayed).toEqual(measured)
    expect(replayQueries).toEqual(queries)
    expect(replayEvents).toEqual(events)
  })

  // The generic recorder replacement must retain this legacy projection, including the
  // response that arrives between two synchronous injection writes, before Promise settlement.
  it("retains legacy write/query fields in observed response order", async () => {
    const queries: TTYQueryTrace[] = []
    const events: TTYTraceEvent[] = []
    const written: string[] = []
    let captured: CallLog | undefined
    const out = {
      write(sequence: string) {
        written.push(sequence)
        return true
      },
    } as unknown as NodeJS.WriteStream
    const body = async () => {
      writeTTY("before")
      expect(
        await readResponse(/^a/, 50, async () => {
          writeTTY("inject")
          reply("a")
          writeTTY("after-reply")
        }),
      ).toEqual(["a"])
    }
    await withTTYOperation(
      () =>
        withTTYQueryTrace(queries, events, body, {
          onLog(log) {
            captured = log
          },
        }),
      out,
    )
    const query = { sequence: "", timeoutMs: 50, reason: "reply" as const, raw: "a", rawBase64: "YQ==", match: ["a"] }
    expect(written).toEqual(["before", "inject", "after-reply"])
    expect(queries).toEqual([query])
    expect(events).toEqual([
      { kind: "write", sequence: "before" },
      { kind: "write", sequence: "inject" },
      { kind: "query", ...query },
      { kind: "write", sequence: "after-reply" },
    ])
    expect(captured).toBeDefined()
    const replayQueries: TTYQueryTrace[] = []
    const replayEvents: TTYTraceEvent[] = []
    const offline = {
      write() {
        throw new Error("Offline TTY replay attempted a live write")
      },
    } as unknown as NodeJS.WriteStream
    await withTTYOperation(
      () =>
        withTTYQueryTrace(replayQueries, replayEvents, body, {
          mode: "replay",
          log: readCallLog(JSON.parse(JSON.stringify(captured))),
        }),
      offline,
    )
    expect(replayQueries).toEqual(queries)
    expect(replayEvents).toEqual(events)
  })

  it("checks a scoped owner before nested queries and releases it with the operation", async () => {
    const failure = new Error("attachment continuity lost")
    const writes: string[] = []
    let revoked = false
    const verify = vi.fn(async () => {
      if (revoked) throw failure
    })
    const out = {
      write(sequence: string) {
        writes.push(sequence)
        reply("\x1b[1;1R")
        return true
      },
    } as unknown as NodeJS.WriteStream
    await withTTYOperation(
      async () => {
        expect(await query("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).not.toBeNull()
        revoked = true
        await expect(query("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).rejects.toBe(failure)
      },
      out,
      verify,
    )
    expect(verify).toHaveBeenCalledTimes(3)
    expect(writes).toEqual(["\x1b[6n"])
    expect(await withTTYOperation(() => query("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20), out)).not.toBeNull()
    expect(verify).toHaveBeenCalledTimes(3)
  })
  it("restores an untouched input stream after draining, including errors and nested leases", async () => {
    const stdin = process.stdin
    const originalTTY = Object.getOwnPropertyDescriptor(stdin, "isTTY")
    const originalFlowing = Object.getOwnPropertyDescriptor(stdin, "readableFlowing")
    const originalRawMode = Object.getOwnPropertyDescriptor(stdin, "setRawMode")
    let flowing: boolean | null = null
    Object.defineProperty(stdin, "isTTY", { configurable: true, value: true })
    Object.defineProperty(stdin, "readableFlowing", { configurable: true, get: () => flowing })
    Object.defineProperty(stdin, "setRawMode", { configurable: true, value: vi.fn() })
    const resume = vi.spyOn(stdin, "resume").mockImplementation(() => {
      flowing = true
      return stdin
    })
    const pause = vi.spyOn(stdin, "pause").mockImplementation(() => {
      flowing = false
      return stdin
    })
    const isPaused = vi.spyOn(stdin, "isPaused").mockReturnValue(false)
    try {
      await withRawMode(async () => {
        await drainStdin(1)
        expect(flowing).toBe(true)
      })
      expect(flowing).toBe(false)
      expect(pause).toHaveBeenCalledOnce()

      flowing = true
      pause.mockClear()
      await withRawMode(async () => {
        await drainStdin(1)
      })
      expect(flowing).toBe(true)
      expect(pause).not.toHaveBeenCalled()

      flowing = false
      await expect(
        withRawMode(async () => {
          throw new Error("probe failed")
        }),
      ).rejects.toThrow("probe failed")
      expect(flowing).toBe(false)
      expect(pause).toHaveBeenCalledOnce()

      flowing = null
      pause.mockClear()
      await withRawMode(async () => {
        await withRawMode(async () => {
          expect(flowing).toBe(true)
        })
        expect(flowing).toBe(true)
      })
      expect(flowing).toBe(false)
      expect(pause).toHaveBeenCalledOnce()
    } finally {
      resume.mockRestore()
      pause.mockRestore()
      isPaused.mockRestore()
      for (const [name, original] of [
        ["isTTY", originalTTY],
        ["readableFlowing", originalFlowing],
        ["setRawMode", originalRawMode],
      ] as const) {
        if (original) Object.defineProperty(stdin, name, original)
        else Reflect.deleteProperty(stdin, name)
      }
    }
  })

  it("has its listener ready before a synchronous terminal reply", async () => {
    process.stdout.write = (() => {
      reply("\x1b[12;34R")
      return true
    }) as typeof process.stdout.write
    expect(await query("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).toMatchObject(["\x1b[12;34R", "12", "34"])
  })

  it("captures stdin emitted during inject, which inject-then-listen would drop", async () => {
    expect(await readResponse(/^a/, 50, async () => reply("a"))).toEqual(["a"])
  })

  // queryOutcome returns before a later inject, so a click during that gap is already gone.
  // rawBase64 is the contract: a text match decodes legacy byte 0x85 as a replacement character.
  it("keeps non-UTF8 bytes that arrive during inject", async () => {
    const outcome = await readInjectedOutcome(/^[\s\S]*a$/, 50, async () => {
      process.stdin.emit("data", Buffer.from([0x85]))
      reply("a")
    })
    expect(outcome.reason).toBe("reply")
    expect(outcome.rawBase64).toBe(Buffer.from([0x85, 0x61]).toString("base64"))
  })

  it("starts the input reply budget after nested custody verification and releases a refused listener", async () => {
    const listeners = process.stdin.listenerCount("data")
    vi.useFakeTimers()
    try {
      const verify = async () => {
        await vi.advanceTimersByTimeAsync(75)
      }
      const received = await withTTYOperation(
        () =>
          readResponse(/^a/, 50, () =>
            withTTYOperation(
              async () => {
                expect(process.stdin.listenerCount("data")).toBe(listeners + 1)
                expect(vi.getTimerCount()).toBe(1)
                reply("a")
              },
              undefined,
              verify,
            ),
          ),
        undefined,
        verify,
      )
      expect(received).toEqual(["a"])
      expect(process.stdin.listenerCount("data")).toBe(listeners)
      const failure = new Error("input custody changed")
      let injected = false
      await expect(
        readResponse(/^a/, 50, () =>
          withTTYOperation(
            async () => {
              injected = true
            },
            undefined,
            async () => {
              throw failure
            },
          ),
        ),
      ).rejects.toBe(failure)
      expect(injected).toBe(false)
      expect(process.stdin.listenerCount("data")).toBe(listeners)
    } finally {
      vi.useRealTimers()
    }
  })

  it("retains exact synchronous reply bytes across UTF-8 chunk boundaries", async () => {
    const chunks = [Buffer.from([0xff, 0xc3]), Buffer.from([0xa9, ...Buffer.from("\x1b[12;34R")])]
    process.stdout.write = (() => {
      for (const chunk of chunks) process.stdin.emit("data", chunk)
      return true
    }) as typeof process.stdout.write
    const outcome = await queryOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)
    expect(outcome).toEqual({
      match: ["\x1b[12;34R", "12", "34"],
      reason: "reply",
      raw: "\uFFFDé\x1b[12;34R",
      rawBase64: Buffer.concat(chunks).toString("base64"),
    })
  })

  it("distinguishes a synchronous sentinel-only reply from a true timeout with retained bytes", async () => {
    const sentinelBytes = Buffer.from([0xff, ...Buffer.from("\x1b[?1;2c")])
    process.stdout.write = (() => {
      process.stdin.emit("data", sentinelBytes)
      return true
    }) as typeof process.stdout.write
    const sentinel = await queryWithSentinelOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)
    expect(sentinel).toMatchObject({
      match: null,
      reason: "sentinel",
      raw: "\uFFFD\x1b[?1;2c",
      rawBase64: sentinelBytes.toString("base64"),
    })
    // @cto 30625 b050f6b9: the 20 ms deadline ends this read long before the configured 250 ms grace,
    // so the observed silence is a partial window and carries NO certificate. The read stays a
    // sentinel outcome with its bytes, and the callback records an inconclusive observation.
    expect(sentinel.sentinel).toBeUndefined()

    const timeoutBytes = Buffer.from("\x1b]unrelated")
    process.stdout.write = (() => {
      process.stdin.emit("data", timeoutBytes)
      return true
    }) as typeof process.stdout.write
    expect(await queryWithSentinelOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).toEqual({
      match: null,
      reason: "timeout",
      raw: "\x1b]unrelated",
      rawBase64: timeoutBytes.toString("base64"),
    })
  })

  it("removes the listener after a write error and admits the next query", async () => {
    const listenersBefore = process.stdin.listenerCount("data")
    process.stdout.write = (() => {
      throw new Error("write failed")
    }) as typeof process.stdout.write
    await expect(queryOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).rejects.toThrow("write failed")
    expect(process.stdin.listenerCount("data")).toBe(listenersBefore)
    process.stdout.write = (() => {
      reply("\x1b[1;1R")
      return true
    }) as typeof process.stdout.write
    expect((await queryOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).reason).toBe("reply")
  })

  it("ignores a late reply for another mode and retains permanent mode states", async () => {
    process.stdout.write = (() => {
      reply("\x1b[?7;1$y\x1b[?2026;3$y\x1b[?1;4$y\x1b[?1;2c")
      return true
    }) as typeof process.stdout.write
    expect(await queryMode(2026)).toBe("set")
  })

  it("grades a reply that arrives after the DA1 sentinel by the reply, and marks it late", async () => {
    const bytes = "\x1b[?1;2c\x1b[12;34R"
    process.stdout.write = (() => {
      reply(bytes)
      return true
    }) as typeof process.stdout.write
    const outcome = await queryWithSentinelOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)
    expect(outcome).toMatchObject({
      match: ["\x1b[12;34R", "12", "34"],
      reason: "reply",
      raw: bytes,
      rawBase64: Buffer.from(bytes).toString("base64"),
    })
    expect(outcome.sentinel?.graceMs).toBe(250)
    expect(await queryWithSentinel("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).toMatchObject(["\x1b[12;34R", "12", "34"])
  })

  it("keeps reading through the grace window after the sentinel and grades a reply that lands in it", async () => {
    process.stdout.write = (() => {
      reply("\x1b[?1;2c")
      setTimeout(() => reply("\x1b[12;34R"), 30)
      return true
    }) as typeof process.stdout.write
    expect(await queryWithSentinelOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 1000, 200)).toMatchObject({
      match: ["\x1b[12;34R", "12", "34"],
      reason: "reply",
      sentinel: { graceMs: 200 },
    })
  })

  it("calls a sentinel-only read silent only after the grace window, and stops reading there", async () => {
    const listenersBefore = process.stdin.listenerCount("data")
    process.stdout.write = (() => {
      reply("\x1b[?1;2c")
      return true
    }) as typeof process.stdout.write
    const started = Date.now()
    expect(await queryWithSentinelOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 1000, 60)).toMatchObject({
      match: null,
      reason: "sentinel",
      raw: "\x1b[?1;2c",
      sentinel: { graceMs: 60 },
    })
    expect(Date.now() - started).toBeGreaterThanOrEqual(50)
    expect(process.stdin.listenerCount("data")).toBe(listenersBefore)
  })

  it("ends a sentinel read at the absolute deadline however often the terminal keeps writing", async () => {
    const listenersBefore = process.stdin.listenerCount("data")
    const started = Date.now()
    let lastReplyAt = 0
    const ticks = setInterval(() => {
      lastReplyAt = Date.now() - started
      reply("\x1b[?1;2c")
      if (Date.now() - started >= 320) clearInterval(ticks)
    }, 50)
    process.stdout.write = (() => {
      reply("\x1b[?1;2c")
      return true
    }) as typeof process.stdout.write
    const outcome = await queryWithSentinelOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 300, 100)
    const elapsed = Date.now() - started
    clearInterval(ticks)
    // The deadline cuts the final grace window short, so the read is not silent for the configured
    // 100 ms and must carry no silence certificate (@cto 30625 partial-grace ruling, including the
    // deadline-clamped grace timer: same eligibility rule, decided by the observed interval, not by
    // which timer fired). The deadline/cleanup proof below is retained unchanged.
    expect(outcome).toMatchObject({ match: null, reason: "sentinel" })
    expect(outcome.sentinel).toBeUndefined()
    expect(lastReplyAt).toBeLessThanOrEqual(400)
    expect(elapsed).toBeLessThan(300 + 100)
    expect(process.stdin.listenerCount("data")).toBe(listenersBefore)
  })

  // #30625 @dev/12 review (2026-10-23): a deadline that cuts the grace window short must not justify a negative observation.
  // One DA1 near the deadline, then silence, is a partial window: an inconclusive observation, not
  // "silent for the whole grace window". The repeated-DA1 regression above misses this because its
  // earlier DA1 bytes already rule out a negative observation.
  it("never grades a sentinel negative when the deadline cuts the grace window short", async () => {
    const listenersBefore = process.stdin.listenerCount("data")
    const started = Date.now()
    let sentinelAt = 0
    process.stdout.write = (() => {
      setTimeout(() => {
        sentinelAt = Date.now() - started
        reply("\x1b[?1;2c")
      }, 250)
      return true
    }) as typeof process.stdout.write
    const outcome = await queryWithSentinelOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 300, 250)
    const observedAfterSentinel = Date.now() - started - sentinelAt
    expect(sentinelAt).toBeGreaterThanOrEqual(240)
    expect(observedAfterSentinel).toBeLessThan(250)
    // The existing shape for an incomplete, unmatched read (@cto 30625 partial-grace ruling): the DA1
    // answer is kept as the reason and its bytes are retained, and NO silence certificate is emitted.
    // Without the facts, device.ts's existing callback records an inconclusive/no-response observation, never a negative observation
    // (device-observations.test.ts "without the measured ordering a frame after DA1 stays unreadable").
    expect(outcome.match).toBe(null)
    expect(outcome.reason).toBe("sentinel")
    expect(outcome.sentinel).toBeUndefined()
    expect(outcome.raw).toBe("\x1b[?1;2c")
    expect(outcome.rawBase64).toBe(Buffer.from("\x1b[?1;2c").toString("base64"))
    expect(sentinelNegativeResult(outcome.raw, outcome.sentinel, "cursor position response")).toBe(null)
    expect(process.stdin.listenerCount("data")).toBe(listenersBefore)
  })

  it("can query DA1 itself without mistaking its answer for the sentinel", async () => {
    process.stdout.write = (() => {
      reply("\x1b[?62;4c")
      return true
    }) as typeof process.stdout.write
    expect(await queryWithSentinel("\x1b[c", /\x1b\[\?([0-9;]+)c/, 20)).toMatchObject(["\x1b[?62;4c", "62;4"])
  })

  // #30559 (@cto 86260f80 rule 1): the sentinel's answer is the LAST DA1-shaped answer, decided on the whole read.
  it("reads a DA1-shaped reply ahead of the DA1 answer as the query's reply, with no sentinel facts", async () => {
    const bytes = "\x1b[?62;4c\x1b[?1;2c"
    let answer: ReturnType<typeof setTimeout> | undefined
    process.stdout.write = (() => {
      reply("\x1b[?62;4c")
      answer = setTimeout(() => reply("\x1b[?1;2c"), 30)
      return true
    }) as typeof process.stdout.write
    const outcome = await queryWithSentinelOutcome("\x1bZ", /\x1b\[\?([0-9;]+)c/, 1000, 200)
    // A read that ended before the DA1 answer must not leave that answer to land in the next test's query.
    clearTimeout(answer)
    expect(outcome).toStrictEqual({
      match: ["\x1b[?62;4c", "62;4"],
      reason: "reply",
      raw: bytes,
      rawBase64: Buffer.from(bytes).toString("base64"),
    })
  })

  // #30559 (@cto 86260f80 rule 2): bytes ahead of the DA1 answer that match nothing end as the sentinel outcome, with
  // its facts, after the grace window; the callback then refuses a negative observation over those bytes.
  it.each([
    { name: "unmatched bytes", bytes: "\x1b]11;rgb:0000/0000/0000\x1b\\\x1b[?1;2c" },
    { name: "a DA1-shaped reply", bytes: "\x1b[?1;2c\x1b[?1;2c" },
  ])("ends $name ahead of the DA1 answer as the sentinel outcome after the grace window", async ({ bytes }) => {
    process.stdout.write = (() => {
      reply(bytes)
      return true
    }) as typeof process.stdout.write
    const started = Date.now()
    expect(await queryWithSentinelOutcome("\x1b[=c", /\x1bP!\|([0-9A-Fa-f]{8})\x1b\\/, 1000, 60)).toMatchObject({
      match: null,
      reason: "sentinel",
      raw: bytes,
      sentinel: { graceMs: 60 },
    })
    expect(Date.now() - started).toBeGreaterThanOrEqual(50)
  })

  // #30559 (@cto a40ae9b7): the facts time the sentinel's own answer, the LAST DA1-shaped one, never an earlier
  // DA1-shaped reply in a chunk of its own, as Terminal.app sends for DA3.
  it("times the sentinel facts by the last DA1-shaped answer when the two arrive in separate chunks", async () => {
    let answer: ReturnType<typeof setTimeout> | undefined
    process.stdout.write = (() => {
      reply("\x1b[?1;2c")
      answer = setTimeout(() => reply("\x1b[?1;2c"), 40)
      return true
    }) as typeof process.stdout.write
    const outcome = await queryWithSentinelOutcome("\x1b[=c", /\x1bP!\|([0-9A-Fa-f]{8})\x1b\\/, 1000, 100)
    clearTimeout(answer)
    expect(outcome).toMatchObject({
      match: null,
      reason: "sentinel",
      raw: "\x1b[?1;2c\x1b[?1;2c",
      sentinel: { graceMs: 100 },
    })
    expect(outcome.sentinel?.atMs).toBeGreaterThanOrEqual(35)
  })

  it("releases the TTY queue when an operation throws", async () => {
    await expect(
      withRawMode(async () => {
        throw new Error("probe failed")
      }),
    ).rejects.toThrow("probe failed")
    await expect(withRawMode(async () => "next probe")).resolves.toBe("next probe")
  })

  it("serializes whole operations without letting nested queries deadlock", async () => {
    const writes: string[] = []
    process.stdout.write = ((chunk: string) => {
      writes.push(chunk)
      if (chunk === "\x1b[6n") reply("\x1b[1;1R")
      return true
    }) as typeof process.stdout.write
    let releaseFirst!: () => void
    const hold = new Promise<void>((resolve) => {
      releaseFirst = resolve
    })
    const first = withRawMode(async () => {
      writes.push("first-start")
      await hold
      expect(await query("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).toBeTruthy()
      writes.push("first-end")
    })
    const second = withRawMode(async () => {
      writes.push("second")
    })
    await Promise.resolve()
    releaseFirst()
    await Promise.all([first, second])
    expect(writes).toEqual(["first-start", "\x1b[6n", "first-end", "second"])
  })

  it("queues a delayed child query after its original operation has ended", async () => {
    const writes: string[] = []
    process.stdout.write = ((chunk: string) => {
      writes.push(chunk)
      if (chunk === "\x1b[6n") reply("\x1b[1;1R")
      return true
    }) as typeof process.stdout.write
    let timerFired!: () => void
    const started = new Promise<void>((resolve) => {
      timerFired = resolve
    })
    let queryFinished!: (match: string[] | null) => void
    const delayed = new Promise<string[] | null>((resolve) => {
      queryFinished = resolve
    })
    await withRawMode(async () => {
      setTimeout(() => {
        timerFired()
        void query("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20).then(queryFinished)
      }, 0)
    })
    let releaseHold!: () => void
    const hold = new Promise<void>((resolve) => {
      releaseHold = resolve
    })
    const second = withRawMode(async () => {
      writes.push("hold-start")
      await hold
      writes.push("hold-end")
    })
    await started
    expect(writes).toEqual(["hold-start"])
    releaseHold()
    await second
    expect(await delayed).toBeTruthy()
    expect(writes).toEqual(["hold-start", "hold-end", "\x1b[6n"])
  })

  it("routes nested query, sentinel, and width traffic through one injected TTY", async () => {
    const writes: string[] = []
    const cursorReplies = ["\x1b[1;3R", "\x1b[2;1R", "\x1b[1;2R", "\x1b[1;3R", "\x1b[1;4R"]
    const out = {
      columns: 12,
      write(chunk: string) {
        writes.push(chunk)
        if (chunk === "\x1b[6n") reply(cursorReplies.shift() ?? "")
        if (chunk === "\x1b[?2026$p\x1b[c") reply("\x1b[?2026;1$y\x1b[?62;4c")
        return true
      },
    } as unknown as NodeJS.WriteStream
    process.stdout.write = (() => {
      throw new Error("controls reached stdout")
    }) as typeof process.stdout.write

    await withTTYOperation(async () => {
      expect((await queryOutcome("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).reason).toBe("reply")
      expect((await queryWithSentinelOutcome("\x1b[?2026$p", /\x1b\[\?2026;([0-4])\$y/, 20)).reason).toBe("reply")
      expect(await measureRenderedWidth("界")).toBe(2)
    }, out)
    expect(cursorReplies).toEqual([])
    expect(writes).toEqual([
      "\x1b[6n",
      "\x1b[?2026$p\x1b[c",
      "\x1b7",
      "\x1b[2;1H",
      "\x1b[6n",
      "\x1b[1;1HA",
      "\x1b[6n",
      "\x1b[1;1H界",
      "\x1b[6n",
      "A",
      "\x1b[6n",
      "\x1b8",
    ])
  })

  it("declines a wrapped sample even when its final column resembles a valid width", async () => {
    const writes: string[] = []
    let lastControl = ""
    const out = {
      columns: 12,
      write(chunk: string) {
        writes.push(chunk)
        if (chunk !== "\x1b[6n") lastControl = chunk
        else if (lastControl === "\x1b[2;1H") reply("\x1b[2;1R")
        else if (lastControl === "\x1b[1;1HA") reply("\x1b[1;2R")
        else reply("\x1b[2;3R")
        return true
      },
    } as unknown as NodeJS.WriteStream
    expect(await withTTYOperation(() => measureRenderedWidth("界"), out)).toEqual({
      kind: "wrapped",
      observed: { row: 2, col: 3 },
    })
    expect(writes.at(-1)).toBe("\x1b8")
  })

  it("declines a sample at the last column when its pending wrap mimics a narrower width", async () => {
    const writes: string[] = []
    let lastControl = ""
    const out = {
      columns: 3,
      write(chunk: string) {
        writes.push(chunk)
        if (chunk !== "\x1b[6n") lastControl = chunk
        else if (lastControl === "\x1b[2;1H") reply("\x1b[2;1R")
        else if (lastControl === "\x1b[1;1HA") reply("\x1b[1;2R")
        else if (lastControl === "A") reply("\x1b[2;2R")
        else reply("\x1b[1;3R")
        return true
      },
    } as unknown as NodeJS.WriteStream
    expect(await withTTYOperation(() => measureRenderedWidth("界"), out)).toEqual({
      kind: "wrapped",
      observed: { row: 2, col: 2 },
    })
    expect(writes.at(-1)).toBe("\x1b8")
  })

  it("restores cursor and declines a width when the setup grid cannot be verified", async () => {
    const writes: string[] = []
    const out = {
      write(chunk: string) {
        writes.push(chunk)
        if (chunk === "\x1b[6n") reply("\x1b[1;1R")
        return true
      },
    } as unknown as NodeJS.WriteStream
    expect(await withTTYOperation(() => measureRenderedWidth("界"), out)).toEqual({
      kind: "control-mismatch",
      step: "origin",
      observed: { row: 1, col: 1 },
    })
    expect(writes).toEqual(["\x1b7", "\x1b[2;1H", "\x1b[6n", "\x1b8"])
  })

  it("releases an injected stream after an error so a later default query uses stdout", async () => {
    const injectedWrites: string[] = []
    const out = {
      columns: 12,
      write(chunk: string) {
        injectedWrites.push(chunk)
        return true
      },
    } as unknown as NodeJS.WriteStream
    await expect(
      withTTYOperation(async () => {
        throw new Error("probe failed")
      }, out),
    ).rejects.toThrow("probe failed")
    const defaultWrites: string[] = []
    process.stdout.write = ((chunk: string) => {
      defaultWrites.push(chunk)
      reply("\x1b[2;4R")
      return true
    }) as typeof process.stdout.write
    expect(await query("\x1b[6n", /\x1b\[(\d+);(\d+)R/, 20)).toMatchObject(["\x1b[2;4R", "2", "4"])
    expect(injectedWrites).toEqual([])
    expect(defaultWrites).toEqual(["\x1b[6n"])
  })
})

/**
 * The window is a measured value, so widening it is explicit; a typo falls back to the documented
 * floor with a named warning instead of refusing the sizing run (28385, 30255).
 */
describe("sentinel grace override", () => {
  it("keeps the floor when unset or empty and honours a whole count, silently", () => {
    const warn = vi.fn()
    expect(sentinelGraceMs(undefined, warn)).toBe(250)
    expect(sentinelGraceMs("", warn)).toBe(250)
    expect(sentinelGraceMs("1000", warn)).toBe(1000)
    expect(warn).not.toHaveBeenCalled()
  })

  it.each([
    ["1s", "not a whole number"],
    ["-5", "negative"],
    ["0", "zero"],
    ["1.5", "a fraction"],
    ["9007199254740993", "past the safe-integer range"],
  ])("falls back to the floor and warns for %s (%s)", (raw) => {
    const warn = vi.fn()
    expect(sentinelGraceMs(raw, warn)).toBe(250)
    expect(warn).toHaveBeenCalledTimes(1)
    const [line] = warn.mock.calls[0] ?? []
    expect(line).toContain("TERMINFO_SENTINEL_GRACE_MS")
    expect(line).toContain(JSON.stringify(raw))
    expect(line).toContain("250")
  })

  it("writes the warning to stderr when no warn seam is passed", () => {
    const writes: string[] = []
    vi.spyOn(process.stderr, "write").mockImplementation(((chunk: unknown) => {
      writes.push(String(chunk))
      return true
    }) as typeof process.stderr.write)
    expect(sentinelGraceMs("1s")).toBe(250)
    expect(writes).toHaveLength(1)
    expect(writes[0]).toContain("TERMINFO_SENTINEL_GRACE_MS")
  })
})

/**
 * The decode-context measurement is the decision every UTF-8-dependent row now rests on, so each
 * branch gets a row of its own: one cell, two cells, a widened byte, an unverified origin, an
 * unexpected column, and each of the two ways a measurement can fail. The writes are asserted whole,
 * because the cursor save/restore and the erase of the glyph it painted into the calling row's
 * screen are part of the contract (#28752, @cto).
 *
 * The first row is the one @dev/review2 asked for: it is the CJK counterexample itself. The sample
 * must be immune to a width policy, because the previous sample é is East Asian Ambiguous and
 * xterm's cjkWidth legitimately advances it two cells in genuine UTF-8 — which the row would have
 * read as an 8-bit decoding. The sample's own bytes are Neutral, so neither hypothesis can be forged:
 * one cell reads utf8, two cells reads 8-bit, and any advance beyond two cells is evidence outside
 * both hypotheses and reads unusable, never a diagnosis (@dev/review2 2026-10-14).
 */
describe("UTF-8 decode context measurement", () => {
  function harness(replies: Array<string | null>) {
    const writes: string[] = []
    let asked = 0
    const out = {
      columns: 12,
      write(chunk: string) {
        writes.push(chunk)
        if (chunk === "\x1b[6n") {
          const next = replies[asked++]
          if (next) reply(next)
        }
        return true
      },
    } as unknown as NodeJS.WriteStream
    return { out, writes }
  }

  it("takes a sample no width policy can move: U+00EB is Neutral, and so are both ISO-8859-1 bytes it splits into", () => {
    // é (U+00E9) is "00E8..00EA ; A" and legitimately two cells under cjkWidth; ë (U+00EB) is
    // "00EB ; N" alone, and its bytes are U+00C3 'Ã' ("00C0..00C5 ; N") and U+00AB '«' ("00AB ; N").
    // So one cell is UTF-8 and two cells is 8-bit however the run treats Ambiguous characters. Each
    // citation is EastAsianWidth-18.0.0.txt quoted exactly, by line number.
    expect(UTF8_DECODE_SAMPLE).toBe("\u00eb")
    expect([...new TextEncoder().encode(UTF8_DECODE_SAMPLE)]).toEqual([0xc3, 0xab])
  })

  it("reads a sample that advanced one cell as utf8, erasing it before the cursor is restored", async () => {
    const { out, writes } = harness(["\x1b[2;1R", "\x1b[2;2R"])
    expect(await withTTYOperation(() => measureUtf8Decoding(), out)).toBe("utf8")
    expect(writes).toEqual(["\x1b7", "\x1b[2;1H", "\x1b[6n", "\x1b[0m\u00eb", "\x1b[6n", "\x1b[2;1H\x1b[2X", "\x1b8"])
  })

  it("reads the same sample advancing the two cells of a byte-by-byte decode as 8-bit", async () => {
    const { out, writes } = harness(["\x1b[2;1R", "\x1b[2;3R"])
    expect(await withTTYOperation(() => measureUtf8Decoding(), out)).toBe("8-bit")
    expect(writes).toContain("\x1b[0m\u00eb")
    expect(writes).toContain("\x1b[2;1H\x1b[2X")
    expect(writes.at(-1)).toBe("\x1b8")
  })

  it("names an advance beyond both hypotheses unusable, so a cursor the decode cannot explain is never a diagnosis", async () => {
    const { out } = harness(["\x1b[2;1R", "\x1b[2;4R"])
    expect(await withTTYOperation(() => measureUtf8Decoding(), out)).toBe("unusable")
  })

  it("names a wildly unrelated advance (998 cells) unusable too", async () => {
    const { out } = harness(["\x1b[2;1R", "\x1b[2;999R"])
    expect(await withTTYOperation(() => measureUtf8Decoding(), out)).toBe("unusable")
  })

  it("names an answered coordinate it cannot read unusable, before painting anything at a foreign origin", async () => {
    const { out, writes } = harness(["\x1b[1;1R"])
    expect(await withTTYOperation(() => measureUtf8Decoding(), out)).toBe("unusable")
    expect(writes).toEqual(["\x1b7", "\x1b[2;1H", "\x1b[6n", "\x1b8"])
  })

  it("names a cursor report that never arrived silent, without painting anything", async () => {
    const { out, writes } = harness([])
    expect(await withTTYOperation(() => measureUtf8Decoding(), out)).toBe("silent")
    expect(writes).toEqual(["\x1b7", "\x1b[2;1H", "\x1b[6n", "\x1b8"])
  })

  it("names a sample that never advanced unusable, erasing what it painted", async () => {
    const zero = harness(["\x1b[2;1R", "\x1b[2;1R"])
    expect(await withTTYOperation(() => measureUtf8Decoding(), zero.out)).toBe("unusable")
    expect(zero.writes).toContain("\x1b[2;1H\x1b[2X")
    expect(zero.writes.at(-1)).toBe("\x1b8")
  })

  it("names a terminal that goes silent after the glyph is painted silent, erasing the glyph it did paint", async () => {
    const { out, writes } = harness(["\x1b[2;1R"])
    expect(await withTTYOperation(() => measureUtf8Decoding(), out)).toBe("silent")
    expect(writes).toContain("\x1b[0m\u00eb")
    expect(writes).toContain("\x1b[2;1H\x1b[2X")
    expect(writes.at(-1)).toBe("\x1b8")
  })
})
