/**
 * Generate analysis.json — computed stats and template-based commentary
 * for every page type on terminfo.dev.
 *
 * Reads measured probe results + curated editorial content,
 * cross-validates everything, computes stats, generates analysis text,
 * and writes derived content/analysis.json (gitignored; bun run build writes it).
 *
 * Usage:
 *   bun scripts/generate-analysis.ts              # Generate analysis.json
 *   bun scripts/generate-analysis.ts --dry-run    # Print what would be generated
 *   bun scripts/generate-analysis.ts --validate   # Validate existing against data
 */
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { isDeepStrictEqual } from "node:util"
import { parseJsonStrict } from "@terminfo/run-parser"
import { isEnvironmentGroup, type FeatureResultStatus } from "@terminfo/probe-defs"
import { aggregateCurrentResults, type CurrentAggregate } from "../docs/data/release-scope.ts"
import { compatibilitySubjects, loadCurrentResults } from "../docs/data/current-results.ts"
import { originalRunFor } from "../docs/data/selected-results.ts"
import { loadCategories, type CategoryMeta } from "../docs/data/categories.ts"
import {
  loadFeatures as loadFeatureCatalog,
  loadTerminals as loadTerminalCatalog,
  subjectLabel,
} from "@terminfo/catalog"
import { siteAnalysisPath } from "./site-out.ts"

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, "..")
const contentDir = join(root, "content")

// --- Types ---

interface FeatureMeta {
  name: string
  slug?: string
  url?: string
  tags?: string[]
  group?: string
  body?: string
  probe?: string
  baseline?: string
}

interface TerminalMeta {
  label: string
  slug: string
  /** The catalog loader guarantees a string here, not the narrower union the readers used to assume. */
  kind?: string
  url?: string
  description?: string
  body?: string
  headlessBackends?: string[]
  manifestBackend?: string
  platforms?: string[]
  historical?: boolean
  year?: number
  manufacturer?: string
  cpu?: string
  significance?: string
  repo?: string
}

interface StandardMeta {
  label: string
  url: string
  description: string
}

interface BaselineMeta {
  label: string
  emoji: string
  color: string
  order: number
  tagline: string
  description: string
  forDevelopers: string
  forTerminalAuthors: string
}

type AnalysisSource = { runId: string; sha256: string; measuredAt: string; suiteId: string; version: string }

interface TerminalStats {
  name: string
  slug: string
  total: number
  yes: number
  no: number
  pct: number
  results: Record<string, FeatureResultStatus>
  baselineCompliance: Record<string, { total: number; yes: number; pct: number; complete: boolean }>
  uniquelySupported: string[]
  uniquelyMissing: string[]
  missingFeatures: string[]
  versions: string[]
  type: "term" | "lib" | "mux"
  sources: AnalysisSource[]
}

export interface AnalysisEntry {
  analysis: string
  date?: string
  probeCount?: number
  changes: string | null
  sources?: AnalysisSource[]
  versions?: string[]
  score?: { supported: number; all: number }
  counts?: Record<FeatureResultStatus, number>
  complete?: boolean
}

// --- Assertions ---

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(`Assertion failed: ${message}`)
}

// --- Data Loading ---

function loadJson<T>(path: string, description: string): T {
  assert(existsSync(path), `Missing required file: ${path} (${description})`)
  try {
    const parsed = parseJsonStrict(path, readFileSync(path, "utf-8"))
    assert(parsed !== null && typeof parsed === "object" && !Array.isArray(parsed), `Expected metadata object: ${path}`)
    return parsed as T
  } catch (e) {
    throw new Error(`Failed to parse ${path} (${description}): ${String(e)}`)
  }
}

function loadFeatures(): Record<string, FeatureMeta> {
  return loadFeatureCatalog(contentDir)
}

function loadTerminals(): Record<string, TerminalMeta> {
  return loadTerminalCatalog(contentDir)
}

function loadStandards(): Record<string, StandardMeta> {
  return loadJson<Record<string, StandardMeta>>(join(contentDir, "standards.json"), "standard metadata")
}

function loadBaselines(): Record<string, BaselineMeta> {
  return loadJson<Record<string, BaselineMeta>>(join(contentDir, "baselines.json"), "baseline metadata")
}

interface GlossaryEntry {
  expansion: string
  description: string
  link?: string
}

function loadGlossary(): Record<string, GlossaryEntry> {
  const path = join(contentDir, "glossary.json")
  if (!existsSync(path)) return {}
  return loadJson<Record<string, GlossaryEntry>>(path, "glossary")
}

interface FrameworkMeta {
  label: string
  url: string
  repo: string
  language: string
  runtime: string
  description: string
  baseline: string
  body: string
}

function loadFrameworks(): Record<string, FrameworkMeta> {
  const path = join(contentDir, "frameworks.json")
  if (!existsSync(path)) return {}
  return loadJson<Record<string, FrameworkMeta>>(path, "framework metadata")
}

function loadAnnotations(): Record<string, { note: string; url?: string }> {
  const path = join(contentDir, "annotations.json")
  if (!existsSync(path)) return {}
  return loadJson<Record<string, { note: string; url?: string }>>(path, "annotations")
}

interface SelectedAnalysisInput {
  recordedResults: Array<{ featureId: string; status: FeatureResultStatus }>
  catalogIds: string[]
  aggregate: CurrentAggregate
  sourceId: string
  results: Record<string, FeatureResultStatus>
  versions: string[]
  type: "term" | "lib" | "mux"
  sources: AnalysisSource[]
}

function buildTerminalResultMap(): Map<string, SelectedAnalysisInput> {
  const { projection } = loadCurrentResults(contentDir)
  const selected = compatibilitySubjects(projection, contentDir)
  const resultMap = new Map<string, SelectedAnalysisInput>()
  for (const [key, { contextKey, selected: version }] of selected) {
    if (!version.subject) throw new Error(`Analysis context ${key} has no physical subject`)
    if (resultMap.has(key)) throw new Error(`Ambiguous analysis terminal ${key}: multiple selected targets`)
    const recordedResults = Object.values(version.cells).map((cell) => {
      const { featureId, status } = cell.result
      if (isEnvironmentGroup(featureId)) {
        return { featureId, status }
      }
      if (!cell.featureResult) {
        throw new Error(`Analysis context ${contextKey}/${featureId} lacks its computed feature result`)
      }
      return { featureId, status: cell.featureResult.status }
    })
    const statuses = Object.fromEntries(recordedResults.map(({ featureId, status }) => [featureId, status]))
    const sources = version.contributingRunIds.map((runId): AnalysisSource => {
      const original = originalRunFor(projection, contextKey, runId)
      return {
        runId,
        sha256: original.sha256,
        measuredAt: original.measuredAt,
        suiteId: original.suiteId,
        version: original.subject.version,
      }
    })
    resultMap.set(key, {
      sourceId: version.subject.id,
      results: Object.fromEntries(version.catalogIds.map((id) => [id, statuses[id] ?? "probe-todo"])),
      recordedResults,
      catalogIds: version.catalogIds,
      aggregate: aggregateCurrentResults(recordedResults, version.catalogIds),
      versions: [...new Set(sources.map((source) => source.version))],
      type: version.subject.kind,
      sources,
    })
  }
  return resultMap
}

// --- Cross-validation ---

function crossValidate(
  features: Record<string, FeatureMeta>,
  terminals: Record<string, TerminalMeta>,
  resultMap: Map<string, SelectedAnalysisInput>,
): void {
  // Features in results should be in features.json — warn for missing
  // (probes may include features not yet documented in features.json)
  const undocumented = new Set<string>()
  for (const data of resultMap.values()) {
    for (const featureId of Object.keys(data.results)) {
      if (!features[featureId]) {
        undocumented.add(featureId)
      }
    }
  }
  if (undocumented.size > 0) {
    console.warn(
      `Warning: ${undocumented.size} feature(s) in probe results not in features.json: ${[...undocumented].join(", ")}`,
    )
  }

  // Warn (but don't throw) for catalog terminals without a stored current result.
  for (const [termId, meta] of Object.entries(terminals)) {
    if (meta.historical) continue
    if (![...resultMap.values()].some((data) => data.sourceId === termId && data.type === meta.kind)) {
      console.warn(`Warning: Terminal '${termId}' has no stored current runs`)
    }
  }
}

// --- Stats Computation ---

function computeTerminalStats(
  termId: string,
  termMeta: TerminalMeta,
  data: SelectedAnalysisInput,
  features: Record<string, FeatureMeta>,
  baselineFeatures: Record<string, string[]>,
  allTerminalResults: Map<string, { results: Record<string, FeatureResultStatus> }>,
): TerminalStats {
  const results = data.results
  const total = data.aggregate.denominator
  const yes = data.aggregate.counts.supported
  const no = data.aggregate.counts.unsupported
  const pct = total > 0 ? Math.round((yes / total) * 100) : 0

  // Per-baseline compliance
  const baselineCompliance: TerminalStats["baselineCompliance"] = {}
  for (const [baselineName, featureIds] of Object.entries(baselineFeatures)) {
    const wanted = new Set(featureIds)
    const frozenIds = data.catalogIds.filter((id) => wanted.has(id))
    const aggregate = frozenIds.length
      ? aggregateCurrentResults(
          data.recordedResults.filter((result) => wanted.has(result.featureId)),
          frozenIds,
        )
      : undefined
    const baselineYes = aggregate?.supported ?? 0
    const baselineTotal = aggregate?.denominator ?? 0
    baselineCompliance[baselineName] = {
      total: baselineTotal,
      yes: baselineYes,
      pct: baselineTotal > 0 ? Math.round((baselineYes / baselineTotal) * 100) : 0,
      complete: aggregate?.complete ?? false,
    }
  }

  // Features uniquely supported (this terminal supports, no other does)
  const uniquelySupported: string[] = []
  // Features uniquely missing (every other terminal passes, this one doesn't)
  const uniquelyMissing: string[] = []
  const missingFeatures: string[] = []

  const otherTerminals = [...allTerminalResults.entries()].filter(([id]) => id !== termId)

  for (const [featureId, supported] of Object.entries(results)) {
    if (supported === "unsupported") {
      missingFeatures.push(featureId)
      // Check if every other terminal passes this
      const allOthersPass = otherTerminals.every(([, other]) => other.results[featureId] === "supported")
      if (allOthersPass && otherTerminals.length > 0) {
        uniquelyMissing.push(featureId)
      }
    } else if (supported === "supported") {
      // Check if no other terminal supports this
      const noOtherSupports = otherTerminals.every(([, other]) => other.results[featureId] === "unsupported")
      if (noOtherSupports && otherTerminals.length > 0) {
        uniquelySupported.push(featureId)
      }
    }
  }

  return {
    name: termMeta.label,
    slug: termMeta.slug,
    total,
    yes,
    no,
    pct,
    results,
    baselineCompliance,
    uniquelySupported,
    uniquelyMissing,
    missingFeatures,
    versions: data.versions,
    type: data.type,
    sources: data.sources,
  }
}

function buildBaselineFeatureMap(features: Record<string, FeatureMeta>): Record<string, string[]> {
  const map: Record<string, string[]> = {}
  for (const [id, feat] of Object.entries(features)) {
    if (feat.baseline) {
      const group = map[feat.baseline] ?? (map[feat.baseline] = [])
      group.push(id)
    }
  }
  return map
}

// --- Ranking ---

function rankTerminals(stats: Map<string, TerminalStats>): Map<string, number> {
  const sorted = [...stats.entries()].sort((a, b) => b[1].pct - a[1].pct || b[1].yes - a[1].yes)
  const ranks = new Map<string, number>()
  for (const [index, [id]] of sorted.entries()) {
    ranks.set(id, index + 1)
  }
  return ranks
}

// --- Analysis Generation (Template-based) ---

function featureName(features: Record<string, FeatureMeta>, id: string): string {
  return features[id]?.name ?? id
}

function generateTerminalAnalysis(
  termId: string,
  stats: TerminalStats,
  rank: number,
  totalTerminals: number,
  comparable: boolean,
  features: Record<string, FeatureMeta>,
  baselines: Record<string, BaselineMeta>,
): AnalysisEntry {
  const parts: string[] = []

  // Baseline compliance
  const failedBaselines = Object.entries(stats.baselineCompliance)
    .filter(([, bl]) => bl.total > 0 && bl.pct < 100)
    .map(([name]) => baselines[name]?.label ?? name)
  const passedBaselines = Object.entries(stats.baselineCompliance)
    .filter(([, bl]) => bl.complete && bl.pct === 100)
    .map(([name]) => baselines[name]?.label ?? name)

  // Score summary + baseline in one sentence
  if (failedBaselines.length === 0 && passedBaselines.length > 0) {
    parts.push(
      `${stats.name} has <strong>${stats.pct}%</strong> support (${stats.yes}/${stats.total}) across all recorded catalog positions, with complete support for the measured baselines (${passedBaselines.join(", ")})`,
    )
  } else if (failedBaselines.length > 0) {
    parts.push(
      `${stats.name} has <strong>${stats.pct}%</strong> support (${stats.yes}/${stats.total}) across all recorded catalog positions, with less than full recorded support in the ${failedBaselines.join(", ")} baseline${failedBaselines.length > 1 ? "s" : ""}`,
    )
  } else {
    parts.push(
      `${stats.name} has <strong>${stats.pct}%</strong> support (${stats.yes}/${stats.total}) across all recorded catalog positions`,
    )
  }

  // Ranking
  if (comparable) {
    parts.push(
      `Ranks <strong>#${rank}</strong> of ${totalTerminals} targets with the same recorded catalog feature set`,
    )
  }

  // Only include documented features (in features.json) in human-readable lists
  const documented = (ids: string[]) => ids.filter((id) => features[id])

  // Unique strengths
  const docUniqueSupported = documented(stats.uniquelySupported)
  if (docUniqueSupported.length > 0) {
    const names = docUniqueSupported.slice(0, 5).map((id) => featureName(features, id))
    parts.push(`Uniquely supports: ${names.join(", ")}`)
  }

  // Unique gaps
  const docUniqueMissing = documented(stats.uniquelyMissing)
  if (docUniqueMissing.length > 0 && docUniqueMissing.length <= 5) {
    const names = docUniqueMissing.map((id) => featureName(features, id))
    parts.push(`Uniquely missing (all other terminals pass): ${names.join(", ")}`)
  }

  // Missing features (if few)
  const docMissing = documented(stats.missingFeatures)
  if (docMissing.length > 0 && docMissing.length <= 8) {
    const names = docMissing.map((id) => featureName(features, id))
    parts.push(`Observed unsupported: ${names.join(", ")}`)
  } else if (docMissing.length > 8) {
    parts.push(`<strong>${docMissing.length}</strong> observed unsupported features`)
  }

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    probeCount: stats.total,
    changes: null,
    sources: stats.sources,
    versions: stats.versions,
    score: { supported: stats.yes, all: stats.total },
  }
}

function generateHistoricalAnalysis(termId: string, meta: TerminalMeta): AnalysisEntry {
  const parts: string[] = []

  parts.push(`<strong>${meta.label}</strong> (${meta.year}) was manufactured by ${meta.manufacturer ?? "unknown"}`)

  if (meta.significance) {
    parts.push(meta.significance)
  }

  parts.push("This is a historical reference entry — no automated probe data is available for this terminal")

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    probeCount: 0,
    changes: null,
  }
}

function generateBaselineAnalysis(
  baselineName: string,
  baselineMeta: BaselineMeta,
  allStats: Map<string, TerminalStats>,
  features: Record<string, FeatureMeta>,
): AnalysisEntry {
  const parts: string[] = []
  const terminals = [...allStats.values()]

  const perfect = terminals.filter(
    (s) => s.baselineCompliance[baselineName]?.complete && s.baselineCompliance[baselineName]?.pct === 100,
  )
  const imperfect = terminals
    .filter(
      (s) =>
        (s.baselineCompliance[baselineName]?.total ?? 0) > 0 && (s.baselineCompliance[baselineName]?.pct ?? 0) < 100,
    )
    .sort((a, b) => (a.baselineCompliance[baselineName]?.pct ?? 0) - (b.baselineCompliance[baselineName]?.pct ?? 0))

  if (terminals.some((s) => (s.baselineCompliance[baselineName]?.total ?? 0) > 0)) {
    parts.push(
      `<strong>${perfect.length}</strong> of ${terminals.length} selected targets have recorded support for every ${baselineMeta.label} feature`,
    )
  } else {
    parts.push(`Analysis awaiting verified measurements for the ${baselineMeta.label} baseline`)
  }

  if (imperfect.length > 0) {
    const laggards = imperfect.slice(0, 3).map((s) => {
      const baseline = s.baselineCompliance[baselineName]
      return `${s.name} (${baseline?.yes ?? 0}/${baseline?.total ?? 0} recorded baseline positions supported)`
    })
    parts.push(`Less than full recorded support: ${laggards.join(", ")}`)

    // Find what features the laggards are missing
    const missingCounts = new Map<string, number>()
    for (const s of imperfect) {
      const bl = s.baselineCompliance[baselineName]
      if (!bl) continue
      for (const [fid, supported] of Object.entries(s.results)) {
        if (supported === "unsupported" && features[fid]?.baseline === baselineName) {
          missingCounts.set(fid, (missingCounts.get(fid) ?? 0) + 1)
        }
      }
    }
    const commonMissing = [...missingCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([id]) => featureName(features, id))
    if (commonMissing.length > 0) {
      parts.push(`Most commonly unsupported: ${commonMissing.join(", ")}`)
    }
  }

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    changes: null,
  }
}

function generateCategoryAnalysis(
  catId: string,
  catMeta: CategoryMeta,
  allStats: Map<string, TerminalStats>,
  features: Record<string, FeatureMeta>,
): AnalysisEntry {
  const parts: string[] = []
  const categoryFeatures = Object.entries(features)
    .filter(([id, feature]) => id.startsWith(catId + ".") || feature.tags?.includes(catId))
    .map(([id]) => id)

  parts.push(`The <strong>${catMeta.label}</strong> category covers ${categoryFeatures.length} features`)

  // Find best and worst terminals for this category
  const catScores: { name: string; yes: number; total: number; pct: number; complete: boolean }[] = []
  for (const [, stats] of allStats) {
    const relevant = categoryFeatures.filter((id) => id in stats.results)
    const yes = relevant.filter((id) => stats.results[id] === "supported").length
    const total = relevant.length
    if (total > 0) {
      catScores.push({
        name: stats.name,
        yes,
        total,
        pct: Math.round((yes / total) * 100),
        complete: total === categoryFeatures.length,
      })
    }
  }
  catScores.sort((a, b) => b.pct - a.pct || b.yes - a.yes)

  if (catScores.length === 0) parts.push("Analysis awaiting verified measurements for this category")

  const perfect = catScores.filter((s) => s.complete && s.pct === 100)
  if (perfect.length > 0) {
    const names = perfect.map((s) => s.name)
    if (perfect.length === catScores.length) {
      parts.push(`All ${catScores.length} measured targets have support for every category check (100%)`)
    } else {
      parts.push(
        `Targets with support for every category check (100%): ${names.slice(0, 5).join(", ")}${names.length > 5 ? ` and ${names.length - 5} more` : ""}`,
      )
    }
  }

  // Common gaps
  const gapCounts = new Map<string, number>()
  for (const [, stats] of allStats) {
    for (const fid of categoryFeatures) {
      if (stats.results[fid] === "unsupported") {
        gapCounts.set(fid, (gapCounts.get(fid) ?? 0) + 1)
      }
    }
  }
  const commonGaps = [...gapCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3)
  if (commonGaps.length > 0) {
    const gapNames = commonGaps.map(
      ([id, count]) => `${featureName(features, id)} (${count} terminal${count === 1 ? " fails" : "s fail"})`,
    )
    parts.push(`Common gaps: ${gapNames.join(", ")}`)
  }

  parts.push(
    "App and headless tests establish different evidence scopes; open individual results for their method and evidence",
  )

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    changes: null,
  }
}

function generateStandardAnalysis(
  stdId: string,
  stdMeta: StandardMeta,
  allStats: Map<string, TerminalStats>,
  features: Record<string, FeatureMeta>,
): AnalysisEntry {
  const parts: string[] = []
  const taggedFeatures = Object.entries(features)
    .filter(([, f]) => f.tags?.includes(stdId))
    .map(([id]) => id)

  parts.push(
    `<strong>${stdMeta.label}</strong> defines ${taggedFeatures.length} feature${taggedFeatures.length === 1 ? "" : "s"} in the terminfo.dev matrix`,
  )

  // Adoption: how many terminals support all features in this standard?
  const stdScores: { name: string; yes: number; total: number; pct: number; complete: boolean }[] = []
  for (const [, stats] of allStats) {
    const relevant = taggedFeatures.filter((id) => id in stats.results)
    const yes = relevant.filter((id) => stats.results[id] === "supported").length
    const total = relevant.length
    if (total > 0) {
      stdScores.push({
        name: stats.name,
        yes,
        total,
        pct: Math.round((yes / total) * 100),
        complete: total === taggedFeatures.length,
      })
    }
  }
  stdScores.sort((a, b) => b.pct - a.pct || b.yes - a.yes)

  if (stdScores.length === 0) parts.push("Analysis awaiting verified measurements for this standard")

  if (stdScores.length > 0) {
    const avgPct = Math.round(stdScores.reduce((sum, s) => sum + s.pct, 0) / stdScores.length)
    parts.push(`Average support among recorded tagged-feature results: <strong>${avgPct}%</strong>`)
  }

  const perfect = stdScores.filter((s) => s.complete && s.pct === 100)
  if (perfect.length > 0) {
    const names = perfect.map((s) => s.name)
    parts.push(
      `Full compliance (100%): ${names.slice(0, 5).join(", ")}${names.length > 5 ? ` and ${names.length - 5} more` : ""}`,
    )
  }

  const worst = stdScores.at(-1)
  if (worst && worst.pct < 100) {
    parts.push(`Lowest: ${worst.name} at ${worst.pct}% (${worst.yes}/${worst.total})`)
  }

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    changes: null,
  }
}

// --- Feature analysis ---

function generateFeatureAnalysis(
  featureId: string,
  feature: FeatureMeta,
  allStats: Map<string, TerminalStats>,
  baselines: Record<string, BaselineMeta>,
): AnalysisEntry {
  const parts: string[] = []

  // Count support across terminals that have this feature
  let supported = 0
  let unsupported = 0
  let total = 0
  const unsupportedNames: string[] = []

  for (const stats of allStats.values()) {
    if (!(featureId in stats.results)) continue
    total++
    if (stats.results[featureId] === "supported") supported++
    if (stats.results[featureId] === "unsupported") {
      unsupported++
      unsupportedNames.push(stats.name)
    }
  }
  if (total === 0) {
    return {
      analysis: "<p>Analysis awaiting verified measurements for this feature. No stored current result covers it.</p>",
      date: "",
      changes: null,
    }
  }

  const pct = Math.round((supported / total) * 100)

  // Support summary
  if (supported === total) {
    parts.push(
      `Recorded tests report support in <strong>all ${total}</strong> stored current context runs for this feature`,
    )
  } else if (supported === 0) {
    parts.push(`No recorded support among <strong>${total}</strong> measured targets`)
  } else {
    parts.push(
      `Recorded tests report support for <strong>${supported}</strong> of <strong>${total}</strong> stored current targets (${pct}%)`,
    )
  }

  // Who doesn't support it
  if (unsupportedNames.length > 0 && unsupportedNames.length <= 5) {
    parts.push(`Not supported by: ${unsupportedNames.join(", ")}`)
  }

  // Baseline context
  if (feature.baseline) {
    const baseline = baselines[feature.baseline]
    if (!baseline) throw new Error(`Feature ${featureId} references unknown baseline ${feature.baseline}`)
    parts.push(`Part of the <strong>${baseline.label}</strong> baseline`)
  }

  parts.push("These summaries describe the recorded tests; open individual results for their method and evidence")

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    changes: null,
  }
}

// --- Framework analysis ---

function generateFrameworkAnalysis(
  fwId: string,
  fw: FrameworkMeta,
  allStats: Map<string, TerminalStats>,
  features: Record<string, FeatureMeta>,
  baselines: Record<string, BaselineMeta>,
  allFrameworks: Record<string, FrameworkMeta>,
): AnalysisEntry {
  const parts: string[] = []
  const terminals = [...allStats.values()]

  const baselineName = fw.baseline
  const baselineMeta = baselines[baselineName]
  const baselineLabel = baselineMeta?.label ?? baselineName

  // Count terminals that meet the required baseline (100% compliance)
  const compatible = terminals.filter(
    (s) => s.baselineCompliance[baselineName]?.complete && s.baselineCompliance[baselineName]?.pct === 100,
  )
  const incompatible = terminals.filter(
    (s) => (s.baselineCompliance[baselineName]?.total ?? 0) > 0 && (s.baselineCompliance[baselineName]?.pct ?? 0) < 100,
  )

  if (terminals.some((s) => (s.baselineCompliance[baselineName]?.total ?? 0) > 0)) {
    parts.push(
      `${fw.label} requires the ${baselineLabel} baseline — <strong>${compatible.length}</strong> of ${terminals.length} selected targets have recorded support for every required feature`,
    )
  } else {
    parts.push(`${fw.label} requires the ${baselineLabel} baseline — support analysis awaiting verified measurements`)
  }

  if (compatible.length > 0 && compatible.length <= 8) {
    const names = compatible.map((s) => s.name)
    parts.push(`Verified against the listed baseline features: ${names.join(", ")}`)
  }

  if (incompatible.length > 0 && incompatible.length <= 5) {
    const laggards = incompatible.map((s) => {
      const baseline = s.baselineCompliance[baselineName]
      return `${s.name} (${baseline?.yes ?? 0}/${baseline?.total ?? 0} recorded baseline positions supported)`
    })
    parts.push(`Less than full recorded support: ${laggards.join(", ")}`)
  }

  // Compare with other frameworks in the same baseline tier
  const sameTier = Object.entries(allFrameworks).filter(([id, f]) => id !== fwId && f.baseline === baselineName)
  if (sameTier.length > 0) {
    const names = sameTier.map(([, f]) => f.label)
    parts.push(`Same baseline tier (${baselineLabel}) as ${names.join(", ")}`)
  }

  // Mention frameworks with different baselines for context
  const otherTiers = Object.entries(allFrameworks).filter(([id, f]) => id !== fwId && f.baseline !== baselineName)
  if (otherTiers.length > 0) {
    const grouped = new Map<string, string[]>()
    for (const [, f] of otherTiers) {
      const bl = baselines[f.baseline]?.label ?? f.baseline
      const group = grouped.get(bl) ?? []
      group.push(f.label)
      grouped.set(bl, group)
    }
    const descriptions = [...grouped.entries()].map(([bl, names]) => `${names.join(", ")} (${bl})`)
    parts.push(`Other frameworks target: ${descriptions.join("; ")}`)
  }

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    changes: null,
  }
}

// --- Validation of generated HTML ---

function validateHtml(html: string, key: string): void {
  // Check for unclosed strong tags
  const openStrong = (html.match(/<strong>/g) ?? []).length
  const closeStrong = (html.match(/<\/strong>/g) ?? []).length
  assert(openStrong === closeStrong, `${key}: Unclosed <strong> tags (${openStrong} open, ${closeStrong} close)`)

  // Check for unclosed p tags
  const openP = (html.match(/<p>/g) ?? []).length
  const closeP = (html.match(/<\/p>/g) ?? []).length
  assert(openP === closeP, `${key}: Unclosed <p> tags (${openP} open, ${closeP} close)`)
}

function validateNumbersInAnalysis(key: string, analysis: string, stats: TerminalStats | null): void {
  if (!stats) return

  // Extract percentage from analysis
  const pctMatch = analysis.match(/has <strong>(\d+)%<\/strong>/)
  if (pctMatch) {
    const pctInText = Number.parseInt(pctMatch[1] ?? "", 10)
    assert(pctInText === stats.pct, `${key}: Percentage in text (${pctInText}%) doesn't match computed (${stats.pct}%)`)
  }

  // Extract yes/total counts
  const countMatch = analysis.match(/\((\d+)\/(\d+)\)/)
  if (countMatch) {
    const yesInText = Number.parseInt(countMatch[1] ?? "", 10)
    const totalInText = Number.parseInt(countMatch[2] ?? "", 10)
    assert(yesInText === stats.yes, `${key}: Pass count in text (${yesInText}) doesn't match computed (${stats.yes})`)
    assert(
      totalInText === stats.total,
      `${key}: Total count in text (${totalInText}) doesn't match computed (${stats.total})`,
    )
  }
}

// --- Index page analyses ---

function generateStandardsIndexAnalysis(
  standards: Record<string, StandardMeta>,
  allStats: Map<string, TerminalStats>,
  features: Record<string, FeatureMeta>,
): AnalysisEntry {
  const parts: string[] = []
  const terminals = [...allStats.values()]

  // Count total standards and features
  const standardIds = Object.keys(standards)
  parts.push(
    `Terminfo.dev tracks <strong>${standardIds.length}</strong> terminal standards and protocol families, including ECMA-48 and Kitty extensions.`,
  )

  // Find which standard has best/worst adoption
  const stdAdoption: { id: string; label: string; avgPct: number }[] = []
  for (const [stdId, stdMeta] of Object.entries(standards)) {
    const taggedFeatures = Object.entries(features)
      .filter(([, f]) => f.tags?.includes(stdId))
      .map(([id]) => id)
    if (taggedFeatures.length === 0) continue

    let totalPct = 0
    let count = 0
    for (const stats of terminals) {
      const relevant = taggedFeatures.filter((id) => id in stats.results)
      if (relevant.length === 0) continue
      const yes = relevant.filter((id) => stats.results[id] === "supported").length
      totalPct += Math.round((yes / relevant.length) * 100)
      count++
    }
    if (count > 0) {
      stdAdoption.push({ id: stdId, label: stdMeta.label, avgPct: Math.round(totalPct / count) })
    }
  }

  stdAdoption.sort((a, b) => b.avgPct - a.avgPct)

  const best = stdAdoption[0]
  const worst = stdAdoption.at(-1)
  if (best && worst && best !== worst) {
    parts.push(
      `Highest average support among recorded tagged-feature tests: <strong>${best.label}</strong> at ${best.avgPct}%. Lowest: <strong>${worst.label}</strong> at ${worst.avgPct}%`,
    )
  }

  // Count terminals with 100% on foundational standards
  const foundational = ["ecma-48", "vt100"]
  for (const stdId of foundational) {
    const taggedFeatures = Object.entries(features)
      .filter(([, f]) => f.tags?.includes(stdId))
      .map(([id]) => id)
    if (taggedFeatures.length === 0) continue
    const perfect = terminals.filter((stats) => {
      const relevant = taggedFeatures.filter((id) => id in stats.results)
      const yes = relevant.filter((id) => stats.results[id] === "supported").length
      return relevant.length === taggedFeatures.length && relevant.length > 0 && yes === relevant.length
    })
    if (perfect.length > 0) {
      parts.push(
        `<strong>${perfect.length}</strong> of ${terminals.length} terminals achieve 100% ${standards[stdId]?.label ?? stdId} compliance`,
      )
    }
  }

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    changes: null,
  }
}

function generateFeaturesIndexAnalysis(
  categories: Record<string, CategoryMeta>,
  allStats: Map<string, TerminalStats>,
  features: Record<string, FeatureMeta>,
): AnalysisEntry {
  const parts: string[] = []
  const terminals = [...allStats.values()]

  // Total feature count
  const totalFeatures = Object.keys(features).length
  const totalCategories = Object.keys(categories).length
  parts.push(
    `The terminfo.dev matrix covers <strong>${totalFeatures}</strong> features across <strong>${totalCategories}</strong> categories`,
  )

  // Find best category (highest avg adoption) and worst
  const catAdoption: { id: string; label: string; avgPct: number }[] = []
  for (const [catId, catMeta] of Object.entries(categories)) {
    const catFeatures = Object.entries(features)
      .filter(([id]) => id.startsWith(catId + "."))
      .map(([id]) => id)
    if (catFeatures.length === 0) continue

    let totalPct = 0
    let count = 0
    for (const stats of terminals) {
      const relevant = catFeatures.filter((id) => id in stats.results)
      if (relevant.length === 0) continue
      const yes = relevant.filter((id) => stats.results[id] === "supported").length
      totalPct += Math.round((yes / relevant.length) * 100)
      count++
    }
    if (count > 0) {
      catAdoption.push({ id: catId, label: catMeta.label, avgPct: Math.round(totalPct / count) })
    }
  }

  catAdoption.sort((a, b) => b.avgPct - a.avgPct)

  const best = catAdoption[0]
  const worst = catAdoption.at(-1)
  if (best && worst && best !== worst) {
    parts.push(
      `Highest observed average support among recorded category tests: <strong>${best.label}</strong> (${best.avgPct}%). Lowest observed average: <strong>${worst.label}</strong> (${worst.avgPct}%)`,
    )
  }

  // Count universally supported features
  const universalCount =
    terminals.length === 0
      ? 0
      : Object.keys(features).filter((fid) => terminals.every((stats) => stats.results[fid] === "supported")).length

  if (universalCount > 0) {
    parts.push(
      `<strong>${universalCount}</strong> feature${universalCount === 1 ? "" : "s"} ${universalCount === 1 ? "has" : "have"} recorded support in every selected target`,
    )
  }

  // Count features with zero support
  const zeroSupport = Object.keys(features).filter((fid) => {
    const tested = terminals.filter((stats) => fid in stats.results)
    if (tested.length === 0) return false
    return tested.every((stats) => stats.results[fid] !== "supported")
  }).length

  if (zeroSupport > 0) {
    parts.push(
      `<strong>${zeroSupport}</strong> feature${zeroSupport === 1 ? " has" : "s have"} no recorded support among selected catalog positions; unfinished tests do not establish unsupported behavior`,
    )
  }

  return {
    analysis: `<p>${parts.join(". ")}.</p>`,
    date: new Date().toISOString().slice(0, 10),
    changes: null,
  }
}

// --- Auto-linking ---

/**
 * Post-process analysis HTML to auto-link mentions of terminals, features,
 * baselines, categories, standards, and glossary acronyms. Uses hover-link
 * styling (inherit color, brand on hover). Adds title tooltips for glossary
 * acronyms. Skips text already inside <a> tags or <strong> tags.
 */
function linkify(
  html: string,
  terminals: Record<string, TerminalMeta>,
  features: Record<string, FeatureMeta>,
  categories: Record<string, CategoryMeta>,
  standards: Record<string, StandardMeta>,
  baselines: Record<string, BaselineMeta>,
  glossary: Record<string, GlossaryEntry> = {},
): string {
  // Build lookup: display name → { href, original, title? } sorted longest-first to avoid partial matches
  const entities: Array<{ pattern: RegExp; href: string; title?: string }> = []

  // Terminals (by label)
  for (const [, t] of Object.entries(terminals)) {
    if (!t.label || !t.slug) continue
    entities.push({
      pattern: new RegExp(`\\b${escapeRegex(t.label)}\\b`, "g"),
      href: `/terminals/${t.slug}`,
    })
  }

  // Baselines (by label + " baseline" or just label when preceded by baseline context)
  for (const [id, b] of Object.entries(baselines)) {
    entities.push({
      pattern: new RegExp(`\\b${escapeRegex(b.label)}\\s+[Bb]aseline\\b`, "g"),
      href: `/baseline/${id}`,
    })
  }

  // Categories (by label)
  for (const [id, c] of Object.entries(categories)) {
    if (!c.label) continue
    entities.push({
      pattern: new RegExp(`\\b${escapeRegex(c.label)}\\b`, "g"),
      href: `/${id}`,
    })
  }

  // Standards (by label)
  for (const [id, s] of Object.entries(standards)) {
    if (!s.label) continue
    entities.push({
      pattern: new RegExp(`\\b${escapeRegex(s.label)}\\b`, "g"),
      href: `/${id}`,
    })
  }

  // Features (by name — only features with unique enough names)
  for (const [id, f] of Object.entries(features)) {
    if (!f.name || !f.slug) continue
    const category = id.split(".")[0]
    // Skip very short/generic names that would cause false positives
    if (f.name.length < 8) continue
    // Use (?!\w) instead of \b at end — feature names like "Mode Reporting (DECRPM)"
    // end with ) which is non-word, so \b wouldn't match after it
    entities.push({
      pattern: new RegExp(`\\b${escapeRegex(f.name)}(?!\\w)`, "g"),
      href: `/${category}/${f.slug}`,
    })
  }

  // External TUI frameworks mentioned in analysis
  const externalLinks = [
    { name: "Ink", href: "https://github.com/vadimdemedes/ink" },
    { name: "Textual", href: "https://textual.textualize.io" },
    { name: "Bubbletea", href: "https://github.com/charmbracelet/bubbletea" },
  ]
  for (const { name, href } of externalLinks) {
    entities.push({
      pattern: new RegExp(`\\b${escapeRegex(name)}\\b`, "g"),
      href,
    })
  }

  // Build glossary title lookup — maps matched text to expansion tooltip
  const glossaryTitles = new Map<string, string>()
  for (const [acronym, entry] of Object.entries(glossary)) {
    glossaryTitles.set(acronym, entry.expansion)
  }

  // Add title tooltips to existing entities when they match a glossary term
  for (const entity of entities) {
    if (entity.title) continue // already has a title
    // Extract the literal text from the regex source (strip \b and other anchors)
    const literal = entity.pattern.source.replace(/\\b|\\s\+.*|\(\?!\\w\)/g, "").replace(/\\\\/g, "\\")
    const title = glossaryTitles.get(literal)
    if (title) entity.title = title
  }

  // Add glossary-only acronyms that aren't already covered by other entities
  // (skip very short acronyms < 4 chars to avoid false positives like ED, EL, ICH)
  const coveredPatterns = new Set(entities.map((e) => e.pattern.source))
  for (const [acronym, entry] of Object.entries(glossary)) {
    if (!entry.link || acronym.length < 4) continue
    const source = `\\b${escapeRegex(acronym)}\\b`
    if (coveredPatterns.has(source)) continue
    entities.push({
      pattern: new RegExp(source, "g"),
      href: entry.link,
      title: entry.expansion,
    })
  }

  // Sort by pattern length descending (longer matches first)
  entities.sort((a, b) => b.pattern.source.length - a.pattern.source.length)

  // Process: split HTML into inside-tag and outside-tag segments
  // Only linkify text outside existing tags
  let result = ""
  let i = 0
  while (i < html.length) {
    if (html[i] === "<") {
      // Inside a tag — copy verbatim until closing >
      const end = html.indexOf(">", i)
      if (end === -1) {
        result += html.slice(i)
        break
      }
      result += html.slice(i, end + 1)

      // If this is an <a> tag, skip to </a>
      const tagContent = html.slice(i, end + 1)
      if (tagContent.startsWith("<a ") || tagContent === "<a>") {
        const closeA = html.indexOf("</a>", end)
        if (closeA !== -1) {
          result += html.slice(end + 1, closeA + 4)
          i = closeA + 4
          continue
        }
      }

      i = end + 1
    } else {
      // Text node — find next tag
      const nextTag = html.indexOf("<", i)
      const text = nextTag === -1 ? html.slice(i) : html.slice(i, nextTag)

      // Collect all non-overlapping matches in a single pass, then apply.
      // This avoids sequential .replace() re-processing its own HTML output
      // (which would corrupt title attributes by matching words inside them).
      const matches: Array<{ start: number; end: number; href: string; title?: string; text: string }> = []
      for (const entity of entities) {
        entity.pattern.lastIndex = 0
        let m: RegExpExecArray | null
        while ((m = entity.pattern.exec(text)) !== null) {
          const start = m.index
          const end = start + m[0].length
          // Skip if overlapping with an already-collected match
          if (matches.some((prev) => start < prev.end && end > prev.start)) continue
          matches.push({ start, end, href: entity.href, title: entity.title, text: m[0] })
        }
      }
      // Sort by position and build result
      matches.sort((a, b) => a.start - b.start)
      let linked = ""
      let pos = 0
      for (const m of matches) {
        linked += text.slice(pos, m.start)
        const titleAttr = m.title ? ` title="${escapeHtmlAttr(m.title)}"` : ""
        linked += `<a href="${m.href}" class="hover-link"${titleAttr}>${m.text}</a>`
        pos = m.end
      }
      linked += text.slice(pos)

      result += linked
      i = nextTag === -1 ? html.length : nextTag
    }
  }

  return result
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}

function escapeHtmlAttr(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
}

// --- Main ---

function loadAllData() {
  const features = loadFeatures()
  const terminals = loadTerminals()
  const categories = loadCategories(contentDir)
  const standards = loadStandards()
  const baselines = loadBaselines()
  const annotations = loadAnnotations()
  const frameworks = loadFrameworks()
  const glossary = loadGlossary()

  const resultMap = buildTerminalResultMap()

  // Cross-validate
  crossValidate(features, terminals, resultMap)

  return { features, terminals, categories, standards, baselines, annotations, frameworks, glossary, resultMap }
}

export function generateAnalysis(): Record<string, AnalysisEntry> {
  const { features, terminals, categories, standards, baselines, frameworks, glossary, resultMap } = loadAllData()
  const baselineFeatures = buildBaselineFeatureMap(features)
  const output: Record<string, AnalysisEntry> = {}

  // Compute stats for all terminals that have results
  const allStats = new Map<string, TerminalStats>()
  for (const [termId, data] of resultMap) {
    const related = Object.values(terminals).filter((terminal) => terminal.headlessBackends?.includes(data.sourceId))
    const source = terminals[data.sourceId] ?? (related.length === 1 ? related[0] : undefined)
    if (!source) throw new Error(`Missing catalog terminal ${data.sourceId} for analysis ${termId}`)
    const meta =
      termId === data.sourceId && terminals[data.sourceId]
        ? source
        : { ...source, slug: termId, label: subjectLabel(terminals, data.sourceId, data.type, source.label) }
    const stats = computeTerminalStats(termId, meta, data, features, baselineFeatures, resultMap)
    allStats.set(termId, stats)
  }

  const ranks = rankTerminals(allStats)
  const totalTerminals = allStats.size
  const scopes = [...allStats.values()].map((stats) => Object.keys(stats.results).sort().join("\u0000"))
  const comparable = scopes.length > 1 && scopes.every((scope) => scope === scopes[0])

  // Deduplicate terminals by slug (e.g., multiple cursor entries)
  const slugSeen = new Set<string>()

  // 1. Terminal pages
  for (const [termId, stats] of allStats) {
    const slug = stats.slug
    if (slugSeen.has(slug)) continue
    slugSeen.add(slug)

    const key = `terminals/${slug}`
    const rank = ranks.get(termId) ?? totalTerminals
    const entry = generateTerminalAnalysis(termId, stats, rank, totalTerminals, comparable, features, baselines)

    // Validate
    validateHtml(entry.analysis, key)
    validateNumbersInAnalysis(key, entry.analysis, stats)

    output[key] = entry
  }

  // 1b. Historical terminal pages (no probe data)
  for (const [termId, meta] of Object.entries(terminals)) {
    if (!meta.historical) continue
    const slug = meta.slug
    if (slugSeen.has(slug)) continue
    slugSeen.add(slug)

    const key = `terminals/${slug}`
    const entry = generateHistoricalAnalysis(termId, meta)
    validateHtml(entry.analysis, key)
    output[key] = entry
  }

  // 2. Baseline pages
  for (const [baselineId, baselineMeta] of Object.entries(baselines)) {
    const key = `baseline/${baselineId}`
    const entry = generateBaselineAnalysis(baselineId, baselineMeta, allStats, features)
    validateHtml(entry.analysis, key)
    output[key] = entry
  }

  // 3. Category pages
  for (const [catId, catMeta] of Object.entries(categories)) {
    const key = catId
    const entry = generateCategoryAnalysis(catId, catMeta, allStats, features)
    validateHtml(entry.analysis, key)
    output[key] = entry
  }

  // 4. Standard pages
  for (const [stdId, stdMeta] of Object.entries(standards)) {
    if (categories[stdId]) continue // The merged category page owns overlapping category/tag analysis.
    const key = stdId
    const entry = generateStandardAnalysis(stdId, stdMeta, allStats, features)
    validateHtml(entry.analysis, key)
    output[key] = entry
  }

  // 5. Feature pages
  for (const [featureId, featureMeta] of Object.entries(features)) {
    const category = featureId.split(".")[0]
    const slug = featureMeta.slug ?? featureId.replaceAll(".", "-")
    const key = `${category}/${slug}`
    const entry = generateFeatureAnalysis(featureId, featureMeta, allStats, baselines)
    if (entry.analysis) {
      validateHtml(entry.analysis, key)
      output[key] = entry
    }
  }

  // 6. Framework pages
  for (const [fwId, fw] of Object.entries(frameworks)) {
    const key = `framework/${fwId}`
    const entry = generateFrameworkAnalysis(fwId, fw, allStats, features, baselines, frameworks)
    if (entry.analysis) {
      validateHtml(entry.analysis, key)
      output[key] = entry
    }
  }

  // 8. Standards index page
  {
    const entry = generateStandardsIndexAnalysis(standards, allStats, features)
    validateHtml(entry.analysis, "standards-index")
    output["standards-index"] = entry
  }

  // 9. Features index page
  {
    const entry = generateFeaturesIndexAnalysis(categories, allStats, features)
    validateHtml(entry.analysis, "features-index")
    output["features-index"] = entry
  }

  // Post-process: auto-link entity mentions in all analysis text
  for (const [, meta] of Object.entries(terminals)) {
    if (meta.historical || slugSeen.has(meta.slug)) continue
    output[`terminals/${meta.slug}`] = {
      analysis:
        "<p>Analysis awaiting verified measurements. No stored current runs; historical results remain available.</p>",
      date: "",
      changes: null,
    }
  }
  if (allStats.size === 0) {
    for (const [key, entry] of Object.entries(output)) {
      if (key.startsWith("terminals/") && entry.probeCount === 0) continue // historical reference
      if (key.startsWith("terminals/")) continue // specific unmeasured message above
      output[key] = {
        analysis:
          "<p>Analysis awaiting verified measurements. No stored current runs; historical results remain available.</p>",
        date: "",
        changes: null,
      }
    }
  }
  for (const entry of Object.values(output)) {
    entry.analysis = linkify(entry.analysis, terminals, features, categories, standards, baselines, glossary)
  }

  return output
}

// --- CLI ---

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2)
  const isDryRun = args.includes("--dry-run")
  const isValidate = args.includes("--validate")

  try {
    const analysis = generateAnalysis()
    const result = analysis

    const outputPath = siteAnalysisPath(root)
    const entryCount = Object.keys(analysis).length
    const terminalCount = Object.keys(analysis).filter((k) => k.startsWith("terminals/")).length
    const baselineCount = Object.keys(analysis).filter((k) => k.startsWith("baseline/")).length
    const compareCount = Object.keys(analysis).filter((k) => k.startsWith("compare/")).length
    const frameworkCount = Object.keys(analysis).filter((k) => k.startsWith("framework/")).length
    const categoryCount = Object.keys(analysis).filter(
      (k) =>
        !k.startsWith("terminals/") &&
        !k.startsWith("baseline/") &&
        !k.startsWith("compare/") &&
        !k.startsWith("framework/") &&
        !k.includes("/"),
    ).length

    if (isValidate) {
      // Validate existing analysis.json against current data
      if (!existsSync(outputPath)) {
        console.error("No existing analysis.json to validate")
        process.exit(1)
      }
      const existing = loadJson<Record<string, unknown>>(outputPath, "analysis snapshot")
      const existingKeys = Object.keys(existing).filter((k) => k !== "$generated")
      const newKeys = Object.keys(analysis)
      const historicalKeys = new Set(
        Object.values(loadTerminals())
          .filter((meta) => meta.historical)
          .map((meta) => `terminals/${meta.slug}`),
      )
      let failures = 0
      for (const key of existingKeys) {
        if (!Object.hasOwn(analysis, key)) {
          console.error(`${outputPath}: ${key}: unexpected entry`)
          failures++
        }
      }
      for (const [key, canonical] of Object.entries(analysis)) {
        const mode = historicalKeys.has(key) ? "historical-schema" : "current-value"
        if (!Object.hasOwn(existing, key)) {
          console.error(`${outputPath}: ${key}: ${mode} failed: missing entry`)
          failures++
          continue
        }
        const entry = existing[key]
        const historicalShape =
          entry !== null &&
          typeof entry === "object" &&
          !Array.isArray(entry) &&
          Object.keys(entry).length === Object.keys(canonical).length &&
          Object.keys(canonical).every((field) => Object.hasOwn(entry, field)) &&
          typeof (entry as AnalysisEntry).analysis === "string" &&
          typeof (entry as AnalysisEntry).date === "string" &&
          ((entry as AnalysisEntry).changes === null || typeof (entry as AnalysisEntry).changes === "string") &&
          (entry as AnalysisEntry).probeCount === 0
        const valid = mode === "historical-schema" ? historicalShape : isDeepStrictEqual(entry, canonical)
        if (!valid) {
          console.error(
            `${outputPath}: ${key}: ${mode} failed: ${mode === "historical-schema" ? "invalid entry shape" : "differs from regenerated canonical values (including date); regenerate analysis"}`,
          )
          failures++
        } else {
          console.log(`${key}: ${mode} passed`)
        }
      }
      console.log(
        `Validation: ${existingKeys.length} existing entries, ${newKeys.length} expected; ${failures} failures`,
      )
      if (failures > 0) process.exit(1)
      console.log("Validation passed")
      process.exit(0)
    }

    if (isDryRun) {
      console.log(`Would generate ${entryCount} entries:`)
      console.log(`  ${terminalCount} terminal pages`)
      console.log(`  ${baselineCount} baseline pages`)
      console.log(`  ${compareCount} comparison pages`)
      console.log(`  ${frameworkCount} framework pages`)
      console.log(`  ${categoryCount} category/standard pages`)
      console.log()
      for (const [key, entry] of Object.entries(analysis)) {
        // Strip HTML for preview
        const plain = entry.analysis.replace(/<[^>]+>/g, "")
        console.log(`  ${key}: ${plain.slice(0, 120)}...`)
      }
      process.exit(0)
    }

    // Write output
    mkdirSync(dirname(outputPath), { recursive: true })
    writeFileSync(outputPath, JSON.stringify(result, null, 2) + "\n")
    console.log(`Generated ${outputPath}`)
    console.log(
      `  ${entryCount} entries (${terminalCount} terminals, ${baselineCount} baselines, ${compareCount} comparisons, ${frameworkCount} frameworks, ${categoryCount} categories/standards)`,
    )
  } catch (error) {
    console.error(error instanceof Error ? error.message : error)
    process.exit(1)
  }
}
