/**
 * @failure Consumers disagree about collected runs, unscoped annotations leak into commentary, or malformed metadata silently omits analysis sections.
 * @level l2
 * @consumer Site matrix, terminal paths, v3 API, frozen v1 bytes and generated analysis.
 * @reach fs-walk vendor/terminfo.dev/content/probes-apps/*.json vendor/terminfo.dev/content/probes-libs/*.json vendor/terminfo.dev/content/probes-mux/*.json
 * @testonly none
 */
import { scoredFeatureIds } from "@terminfo/probe-defs"
import type { ProbeResult, ProbeStatus } from "@terminfo/probe-defs"
import { afterAll, describe, expect, it, vi } from "vitest"
import {
  mkdtempSync,
  readFileSync,
  rmSync,
  existsSync,
  mkdirSync,
  writeFileSync,
  cpSync,
  symlinkSync,
  readdirSync,
  statSync,
} from "node:fs"
import { spawnSync } from "node:child_process"
import { createHash } from "node:crypto"
import { tmpdir } from "node:os"
import { join } from "node:path"
import type {
  CurrentSelectedVersion,
  SelectedCell,
  SelectedProjection,
  SelectedVersion,
  SelectedContextSummary,
} from "../docs/data/selected-results.ts"
import type { LoadedRun } from "@terminfo/run-parser"
import { aggregateCurrentResults } from "../docs/data/release-scope.ts"
import * as selectedResults from "../docs/data/selected-results.ts"
import { publicResults } from "../docs/data/public-results.ts"
import type { PublicContextSummary, PublicVersion } from "../docs/data/public-results.ts"

const fixture = vi.hoisted(() => {
  const runSha256 = "a".repeat(64)
  const measuredAt = "2026-09-28T12:34:56.000Z"
  const subject = {
    kind: "term",
    id: "kitty",
    version: "0.46.2",
    os: "macos",
    osVersion: "25.4.0",
    outerTerminal: null,
    mux: null,
    config: null,
    permissions: null,
  }
  const cells = {
    "sgr.bold": {
      featureId: "sgr.bold",
      outcome: "supported",
      assertionType: "query_reply",
      conclusive: true,
      note: "unchecked collector note /home/fixture/private",
      record: {
        rawReply: "\u001b[1;2R",
        assertions: [
          { featureId: "sgr.bold", kind: "positive", expected: "STORED_ASSERTION_EXPECTED", observed: "\u001b[1;2R" },
        ],
      },
      chain: {
        origin: { kind: "collector", appLaunch: { bundlePath: "/private/fixture/app" } },
        method: "query",
        runId: "kitty-reviewed",
        runSha256,
      },
    },
    "extensions.sixel": {
      featureId: "extensions.sixel",
      outcome: "unsupported",
      assertionType: "query_reply",
      conclusive: true,
      record: {
        assertions: [
          { featureId: "extensions.sixel", kind: "negative", expected: "sixel image", observed: "no image" },
        ],
      },
      chain: { origin: { kind: "collector" }, method: "behavior", runId: "kitty-reviewed", runSha256 },
    },
  }
  const selected = {
    schemaVersion: 2,
    runId: "kitty-reviewed",
    subject,
    measuredAt,
    suiteId: "suite-v2",
    probeHash: "current",
    suiteFreshness: "tree suite current",
    sourceRevision: "rev",
    sha256: runSha256,
    identity: "verified",
    suite: { observed: 2, expected: 2, complete: true },
    cells,
    v1: { "sgr.bold": true, "extensions.sixel": false },
    counts: { catalog: 270, tested: 2, notTested: 268, conclusive: 2, supported: 1, unsupported: 1 },
    ungradedDiagnostics: {
      evidence: "legacy",
      label: "old callback result, unverified",
      results: { "sgr.bold": { kind: "collector-error", name: "PRIVATE_DIAGNOSTIC" } },
    },
    reviews: [
      { id: "kitty-review", reviewer: "reviewer", reason: "exact-run identity checked", sources: ["review://kitty"] },
    ],
  }
  const mux = {
    ...selected,
    runId: "tmux-reviewed",
    sha256: "b".repeat(64),
    suite: { observed: 1, expected: 1, complete: true },
    subject: { ...subject, kind: "mux", id: "tmux", outerTerminal: "kitty", mux: "tmux" },
    reviews: [
      { id: "tmux-review", reviewer: "reviewer", reason: "exact-run identity checked", sources: ["review://tmux"] },
    ],
    cells: {},
    v1: { "sgr.bold": true },
    counts: { catalog: 270, tested: 1, notTested: 269, conclusive: 1, supported: 1, unsupported: 0 },
  }
  const screen = {
    ...mux,
    runId: "screen-reviewed",
    sha256: "d".repeat(64),
    measuredAt: "2026-09-29T12:34:56.000Z",
    subject: { ...mux.subject, id: "screen", mux: "screen", version: "5.0" },
    cells: {
      "sgr.bold": {
        ...cells["sgr.bold"],
        outcome: "inconclusive",
        conclusive: false,
        chain: { origin: { kind: "collector" }, method: "query", runId: "screen-reviewed", runSha256: "d".repeat(64) },
      },
    },
    v1: {},
    counts: { catalog: 270, tested: 1, notTested: 269, conclusive: 0, supported: 0, unsupported: 0 },
  }
  const olderScreen = {
    ...selected,
    runId: "screen-older-reviewed",
    sha256: "c".repeat(64),
    probeHash: "older-suite",
    suiteId: "older-suite",
    suiteFreshness: "older suite older-suite",
    subject: { ...screen.subject, version: "4.9" },
    cells: Object.fromEntries(
      Object.entries(cells).map(([id, cell]) => [
        id,
        {
          ...cell,
          chain: { ...cell.chain, runId: "screen-older-reviewed", runSha256: "c".repeat(64) },
        },
      ]),
    ),
  }
  const alternateKitty = {
    ...selected,
    runId: "kitty-clipboard-reviewed",
    sha256: "e".repeat(64),
    subject: { ...subject, permissions: "clipboard: read=deny,write=allow" },
    cells: {},
    v1: {},
    counts: { catalog: 270, tested: 0, notTested: 270, conclusive: 0, supported: 0, unsupported: 0 },
  }
  return {
    runSha256,
    measuredAt,
    selected: selected as unknown as SelectedVersion,
    mux: mux as unknown as SelectedVersion,
    screen: screen as unknown as SelectedVersion,
    projection: {
      seeds: { "term:kitty": selected, "mux:tmux": mux, "mux:screen": screen },
      versions: {
        "term:kitty": [selected],
        "term:kitty:clipboard": [alternateKitty],
        "mux:tmux": [mux],
        "mux:screen": [screen, olderScreen],
      },
      history: { "term:kitty": [selected], "mux:tmux": [mux], "mux:screen": [screen] },
      exclusions: [],
    } as unknown as {
      seeds: Record<string, SelectedVersion>
      versions: Record<string, SelectedVersion[]>
      history: Record<string, SelectedVersion[]>
      exclusions: SelectedProjection["exclusions"]
    },
  }
})

vi.mock("../docs/data/current-results.ts", async () => {
  const { loadFeatures } = await import("@terminfo/catalog")
  const { projectResults } = await import("../docs/data/selected-results.ts")
  const actual = await vi.importActual<typeof import("../docs/data/current-results.ts")>(
    "../docs/data/current-results.ts",
  )
  const content = join(import.meta.dirname, "..", "content")
  const catalogIds = Object.keys(loadFeatures(content))
  const fixtureContent = mkdtempSync(join(tmpdir(), "terminfo-parity-policy-"))
  symlinkSync(join(content, "terminals.json"), join(fixtureContent, "terminals.json"))
  afterAll(() => rmSync(fixtureContent, { recursive: true, force: true }))
  const sealedFixture = (run: SelectedVersion): LoadedRun => {
    const ids = [...new Set([...catalogIds, ...Object.keys(run.cells)])]
    // A real selected collection leaves exactly one older original cell visible.
    const selectedIds = run.runId === "screen-reviewed" ? ids.filter((id) => id !== "extensions.sixel") : null
    const results = ids.map((featureId): ProbeResult => {
      const cell = run.cells[featureId]
      const status: ProbeStatus =
        cell?.outcome === "supported"
          ? "supported"
          : cell?.outcome === "unsupported"
            ? "unsupported"
            : cell?.outcome === "error"
              ? "probe-invalid"
              : "probe-todo"
      return {
        featureId,
        status,
        attempt: (selectedIds ? selectedIds.includes(featureId) : status !== "probe-todo")
          ? { scope: "probe", startedAt: run.measuredAt }
          : { scope: "none" },
        tests: [],
        assertionType: cell?.assertionType,
        reason: cell?.note,
      }
    })
    return {
      schemaVersion: 4,
      source: { kind: "live" },
      runId: run.runId + "-sealed-" + run.sha256.slice(0, 8),
      path: "/fixture/" + run.runId + ".json",
      subject: run.subject,
      measuredAt: run.measuredAt,
      suiteId: run.suiteId,
      probeHash: run.probeHash ?? "current",
      sourceRevision: "a".repeat(40),
      sha256: run.sha256,
      identity: run.identity,
      catalogIds: ids,
      results,
      suiteComplete: true,
      suiteProbeCount: ids.length,
      rawReplies: selectedIds
        ? {
            "collector.selection": JSON.stringify({ ids: selectedIds }),
            "collector.collectionAttempt": JSON.stringify({
              ids: selectedIds,
              startedAt: run.measuredAt,
              result: "completed",
            }),
          }
        : {},
      assertions: [],
      observations: [],
      origin: { kind: "collector" },
      screenshotRefs: [],
      textSnapshotRefs: [],
      notTested: [],
      ungradedDiagnostics: {},
      legacy: false,
    }
  }
  const build = () => {
    const originals = new Map<string, LoadedRun>()
    for (const run of [
      ...Object.values(fixture.projection.seeds),
      ...Object.values(fixture.projection.versions).flat(),
      ...Object.values(fixture.projection.history).flat(),
    ]) {
      const sealed = sealedFixture(run)
      originals.set(sealed.runId, sealed)
    }
    return projectResults([...originals.values()], catalogIds, { currentProbeHash: "current" }, [])
  }
  return {
    ...actual,
    loadCurrentResults: () => ({ projection: build() }),
    compatibilitySubjects: (projection: SelectedProjection) => actual.compatibilitySubjects(projection, fixtureContent),
  }
})

function requiredContext(projection: SelectedProjection, kind: string, id: string): SelectedContextSummary {
  const context = Object.values(projection.contexts).find(
    (entry) => entry.subject?.kind === kind && entry.subject.id === id,
  )
  if (!context) throw new Error(`Missing fixture context ${kind}:${id}`)
  return context
}

function originalRun(
  projection: SelectedProjection,
  context: SelectedContextSummary,
  featureId = "sgr.bold",
): CurrentSelectedVersion {
  const runId = context.cells[featureId]?.origin.runId
  if (!runId) throw new Error(`Missing original fixture source for ${featureId}`)
  return selectedResults.originalRunFor(projection, context.contextKey, runId)
}

// Re-enter the production composer after a fixture changes an original subject/run.
function recompose(projection: SelectedProjection, extra: readonly LoadedRun[] = []): SelectedProjection {
  const runs = new Map(
    Object.values(projection.contexts).flatMap((context) =>
      Object.values(context.cells).map((cell) => [cell.run.runId, cell.run] as const),
    ),
  )
  // Rejected original history still affects physical context keys and remains readable in history.
  for (const version of Object.values(projection.history).flat()) {
    if (runs.has(version.runId)) continue
    runs.set(version.runId, {
      ...version,
      schemaVersion: 4,
      source: { kind: "live" },
      path: "/fixture/" + version.runId + ".json",
      suiteComplete: true,
      suiteProbeCount: version.catalogIds.length,
      assertions: [],
      observations: [],
      screenshotRefs: [],
      textSnapshotRefs: [],
      notTested: [],
      ungradedDiagnostics: {},
      legacy: false,
    })
  }
  for (const run of extra) runs.set(run.runId, run)
  return selectedResults.projectResults(
    [...runs.values()],
    Object.values(projection.contexts)[0]?.catalogIds ?? [],
    { currentProbeHash: "current" },
    [],
  )
}

function addFixtureSubject(
  projection: SelectedProjection,
  kind: CurrentSelectedVersion["subject"]["kind"],
  id: string,
) {
  const base = Object.values(projection.contexts).flatMap((context) => Object.values(context.cells))[0]?.run
  if (!base) throw new Error("Missing original run for subject fixture")
  const run = structuredClone(base)
  run.subject = { ...run.subject, kind, id }
  run.runId = `${base.runId}-${kind}-${id}`
  run.sha256 = createHash("sha256").update(run.runId).digest("hex")
  Object.assign(projection, recompose(projection, [run]))
  const selected = requiredContext(projection, kind, id)
  return { contextKey: selected.contextKey, selected }
}

function analysisSources(context: SelectedContextSummary) {
  const runs = new Map(Object.values(context.cells).map((cell) => [cell.run.runId, cell.run]))
  return [...runs.values()].map((run) => ({
    runId: run.runId,
    sha256: run.sha256,
    measuredAt: run.measuredAt,
    suiteId: run.suiteId,
    version: run.subject.version,
  }))
}

import probesLoader from "../docs/data/probes.data.ts"
import { loadProbes } from "../docs/data/load-probes.ts"
import * as probeData from "../docs/data/load-probes.ts"
import { loadFullProbes } from "../docs/data/probes.data.ts"
import * as currentResults from "../docs/data/current-results.ts"
import terminalPaths from "../docs/terminals/[id].paths.ts"
import comparePaths from "../docs/compare/[id].paths.ts"
import baselinePaths from "../docs/baseline/[id].paths.ts"
import categoryPaths from "../docs/[id].paths.ts"
import featurePaths from "../docs/[category]/[id].paths.ts"
import { generateApi, assertDeploymentLimits } from "./generate-api.ts"
import { generateAnalysis } from "./generate-analysis.ts"
import { loadFullProjectData } from "../docs/data/full-project.data.ts"
import { probeHash } from "../packages/admin/versions.ts"

it("keeps the retained corpus consistent across unmocked site, API and analysis consumers", () => {
  // Fixtures above replace selection. Only real retained inputs expose default-context drift.
  // A separate process uses the existing consumers without inheriting this module's vi.mock registry.
  const root = join(import.meta.dirname, "..")
  const out = mkdtempSync(join(tmpdir(), "terminfo-retained-parity-"))
  const entry = (path: string) => JSON.stringify(join(root, path))
  try {
    const result = spawnSync(
      process.execPath,
      [
        "--eval",
        `
      import assert from "node:assert/strict";
      import { createHash } from "node:crypto";
      import { readFileSync, readdirSync } from "node:fs";
      import { join } from "node:path";
      import { loadCurrentResults, compatibilitySubjects } from ${entry("docs/data/current-results.ts")};
      import { loadFullProbes } from ${entry("docs/data/probes.data.ts")};
      import probesLoader from ${entry("docs/data/probes.data.ts")};
      import terminalPaths from ${entry("docs/terminals/[id].paths.ts")};
      import { generateApi } from ${entry("scripts/generate-api.ts")};
      import { generateAnalysis } from ${entry("scripts/generate-analysis.ts")};
      import { scoredFeatureIds } from ${entry("packages/probe-defs/src/index.ts")};
      const started = performance.now();
      const content = ${JSON.stringify(join(root, "content"))};
      const out = ${JSON.stringify(out)};
      const frozenV1Dir = ${JSON.stringify(join(root, "docs/public/api/v1"))};
      // Each real loader retains the whole corpus; reclaim prior temporary parse objects between consumers.
      const { projection } = loadCurrentResults(content);
      Bun.gc(true);
      const compatibility = compatibilitySubjects(projection, content);
      const site = loadFullProbes();
      const matrix = probesLoader.load();
      const pages = terminalPaths.paths();
      const analyses = generateAnalysis();
      generateApi(out);
      const v3 = JSON.parse(readFileSync(join(out, "api/v3/data.json"), "utf8"));
      const keys = value => Object.keys(value).sort();
      const digest = bytes => createHash("sha256").update(bytes).digest("hex");
      const raw = new Set();
      for (const dir of ["probes-apps", "probes-libs", "probes-mux"])
        for (const file of readdirSync(join(content, dir)).filter(name => name.endsWith(".json")))
          raw.add(digest(readFileSync(join(content, dir, file))));
      assert.deepEqual(keys(site.selected.contexts), keys(projection.contexts));
      assert.deepEqual(keys(v3.contexts), keys(projection.contexts));
      assert.equal(v3.contextCount, keys(projection.contexts).length);
      assert.deepEqual(matrix.stats, site.stats);
      assert.deepEqual(keys(site.selectedByBackend), [...compatibility.keys()].sort());
      const referenced = new Set();
      for (const [api, published] of [[v3,site.selected]]) {
        assert.deepEqual(keys(api.contexts), keys(published.contexts));
        for (const [key, context] of Object.entries(published.contexts)) {
          const {sources, ...summary} = api.contexts[key];
          assert.deepEqual(summary, (({sources, ...rest}) => rest)(context));
          assert.deepEqual(keys(sources), keys(context.sources));
          for (const [id, cell] of Object.entries(context.featureResults)) {
            assert.ok(sources[cell.origin.runId], key + "/" + id + " has original source");
            assert.equal(cell.measuredAt, sources[cell.origin.runId].measuredAt);
            assert.equal(cell.suiteId, sources[cell.origin.runId].suiteId);
          }
        }
        for (const group of ["versions","history"]) {
          assert.deepEqual(keys(api[group]),keys(published[group]));
          for (const [key,versions] of Object.entries(published[group])) {
            const refs=api[group][key];
            for (const [i,version] of versions.entries()) {
              const bytes=readFileSync(join(out,refs[i].url.slice(1)));
              assert.equal(digest(bytes),refs[i].documentSha256);
              assert.deepEqual(JSON.parse(bytes.toString()),version);
              assert.ok(raw.has(version.sha256));
              referenced.add(version.sha256);
            }
          }
        }
        for (const context of Object.values(api.contexts)) for (const source of Object.values(context.sources)) {
          const bytes=readFileSync(join(out,source.url.slice(1)));
          assert.equal(digest(bytes),source.documentSha256);
          const original=JSON.parse(bytes.toString());
          assert.equal(original.runId,source.runId);
          assert.equal(original.sha256,source.sha256);
          const {results, ...metadata} = original;
          const {url, documentSha256, ...receipt} = source;
          assert.deepEqual(metadata, receipt);
          assert.ok(raw.has(source.sha256));
          referenced.add(source.sha256);
        }
      }
      // #30764 deleted every old run and #30759 AC3 removed the historical reader, so a corpus can
      // legitimately reference nothing. Every consumer must then publish nothing rather than invent.
      if (referenced.size===0) {
        assert.deepEqual(Object.keys(site.selected.contexts),[]);
        assert.deepEqual(Object.keys(site.selected.versions),[]);
        assert.deepEqual(Object.keys(site.selected.history),[]);
        // The row claims site, API and analysis consistency, so the empty case has to prove all
        // three rather than the site alone: the API publishes no group either, and analysis
        // publishes no current run.
        assert.deepEqual(keys(v3.contexts),[]);
        assert.deepEqual(keys(v3.versions),[]);
        assert.deepEqual(keys(v3.history),[]);
        assert.ok(Object.values(analyses).every(entry=>!entry.sources?.length));
      }
      for (const [key,{selected}] of compatibility) {
        assert.deepEqual(matrix.stats[key].score,selected.score);
        // D132 B (#30917): the published denominator is the GRADED catalogue, so a site, API and
        // analysis row agree on 264 while the run still records all 273 positions.
        assert.equal(selected.score.all,scoredFeatureIds(selected.catalogIds).length);
        const page=pages.find(page=>page.params.backendId===key);
        assert.equal(page.params.total,String(selected.score.all));
        assert.equal(page.params.yes,String(selected.score.supported));
      }
      if (!v3.contextCount) {
        assert.deepEqual(site.stats,{});
        assert.deepEqual(v3.contexts,{});
        assert.match(v3.message,/No current/);
        // #30764 deleted every old run and #30759 AC3 ships an empty archive, so a corpus with no
        // current run has nothing historical to show: no page may claim a historical run, and
        // inventing one here is the failure this row exists to catch.
        assert.ok(pages.every(page=>JSON.parse(page.params.historicalRuns||"[]").length===0));
      }
      for (const entry of Object.values(analyses))
        for(const source of entry.sources ?? []) assert.ok(Object.values(projection.history).flat().some(run=>run.runId===source.runId && run.sha256===source.sha256 && run.measuredAt===source.measuredAt));
      // @cto f71ed475: v1 is frozen bytes on disk, never a generator output.
      const frozenV1 = JSON.parse(readFileSync(join(frozenV1Dir, "data.json"), "utf8"));
      assert.equal(frozenV1.version,1);
      assert.ok(Object.keys(frozenV1.terminals).length>0,"frozen v1 bytes remain readable");
      // #30759 R1 (@cto f1504b5c): the freeze is a byte freeze, so every published file is pinned.
      const frozenV1Expected = {
        'badges/alacritty.svg': '45f894484ac9a1192ee3985e52e3c82490fdcdec4882886385b9e585c4814cea',
        'badges/cmux.svg': '2a961bc8af1fb81c8dde897b79572a9afc50e3ca7f4d5a405195e582be416869',
        'badges/cursor.svg': 'a628a0322a51ce584c930fa854872789d5af12644328f5c0acf7da01bfd91c36',
        'badges/ghostty.svg': '0e98926e37fd0c6a7cb2c24b1c4cc4d035d6f629995868edf9492f98b3a42300',
        'badges/iterm2-app.svg': 'd08a49f10a6f89bc8068d8931884437ebe968fa73d199fe281edee7376ccf269',
        'badges/iterm2.svg': '41f90de165e0d9e5dfb513cb8e549ba2a62434e016f0b6926167a87e446bcd6f',
        'badges/kitty-app.svg': '919e8dad562d8f769bacc7b1a16fa10379e4c1dce6cbf83e50a76a540558e793',
        'badges/kitty.svg': 'f230e15729a199c11246513c3ee36ae898219ddd3c9958968b2495c754588423',
        'badges/terminal-app.svg': 'b52c490086640d834e1d43046d418f10b3f6d1041b7efb1abbdd8520ec47ed45',
        'badges/vs-code.svg': '3e0c3e3a1bf16c126a362d1ede6965b65ed2355d5e368703f49e9dfc32f7c493',
        'badges/vt100.svg': 'b93d0fe8ddcf8acd0f5649e0a6642117e8d7221540ac46d7a3948aa6e195383a',
        'badges/vterm.svg': '71f3b79d4bea0a227a8825cc492236194a6938ac4b1343e8865534151441333b',
        'badges/warp.svg': '6c02ecae2d6187296e3713c2d52ff671b5d2de3e9bb86f31bec453df5c2bee48',
        'badges/wezterm.svg': '34ca63fe52d619803a46bea8513835d8acf35778f80a5b5f23ac97fd9e098a6c',
        'data.json': '188ad4c77469de4c9fde6a7a8525f8b6ee31447e3ba03dc1c105e51cbc3fca2e',
      };
      const frozenV1Actual = {};
      const walkFrozen = (relative) => {
        for (const entry of readdirSync(join(frozenV1Dir, relative), { withFileTypes: true })) {
          const child = relative === "" ? entry.name : relative + "/" + entry.name;
          if (entry.isDirectory()) walkFrozen(child);
          else frozenV1Actual[child] = digest(readFileSync(join(frozenV1Dir, child)));
        }
      };
      walkFrozen("");
      assert.deepEqual(frozenV1Actual, frozenV1Expected);
      let sealedRunFiles = 0;
      for (const dir of ["probes-apps", "probes-libs", "probes-mux"])
        for (const file of readdirSync(join(content, dir)).filter(name => name.endsWith(".json")))
          if ([3,4].includes(JSON.parse(readFileSync(join(content, dir, file), "utf8")).schemaVersion)) sealedRunFiles += 1;
      console.log(JSON.stringify({exactContexts:keys(projection.contexts).length,sealedRunFiles,referencedRuns:referenced.size,milliseconds:performance.now()-started}));
    `,
      ],
      { cwd: root, encoding: "utf8", timeout: 60_000, maxBuffer: 2 * 1024 * 1024 },
    )
    expect(result.error).toBeUndefined()
    expect(result.status, result.stderr).toBe(0)
    // Missing conclusive measurements are expected and remain open, including real tmux/screen proof.
    expect(
      result.stderr
        .split("\n")
        .filter(Boolean)
        .every((line) => /^Warning: Terminal '.+' has no stored current runs$/.test(line)),
    ).toBe(true)
    const receipt = JSON.parse(result.stdout) as {
      exactContexts: number
      sealedRunFiles: number
      compatibilitySubjects: number
      referencedRuns: number
    }
    // Current contexts come from sealed run files and from nothing else: none without a file, at
    // least one once a file exists, never more contexts than files. Schema 3 and schema 4 are both
    // current — docs/data/selected-results.ts selects `schemaVersion === 3 || === 4` — so this counts
    // both rather than assuming the batch that landed the first admitted capture never arrives.
    expect(receipt.exactContexts > 0).toBe(receipt.sealedRunFiles > 0)
    expect(receipt.exactContexts).toBeLessThanOrEqual(receipt.sealedRunFiles)
    expect(receipt.compatibilitySubjects).toBeUndefined()
    // A corpus with current contexts must reference at least one run; the post-#30764 corpus has none
    // to reference, and referencing nothing is correct. Symmetric on purpose: the collector refills
    // this corpus, so this is not a permanent zero-total rule.
    expect(receipt.referencedRuns > 0).toBe(receipt.exactContexts > 0)
  } finally {
    rmSync(out, { recursive: true, force: true })
  }
}, 65_000)

it("analysis rejects malformed required catalogs before replacing its output", () => {
  const out = mkdtempSync(join(tmpdir(), "terminfo-analysis-metadata-"))
  try {
    const sourceRoot = join(import.meta.dirname, "..")
    mkdirSync(join(out, "scripts"))
    mkdirSync(join(out, "content"))
    for (const dir of ["probes-apps", "probes-mux", "probes-libs"]) mkdirSync(join(out, "content", dir))
    for (const dir of ["docs", "node_modules"]) symlinkSync(join(sourceRoot, dir), join(out, dir), "dir")
    const script = join(out, "scripts", "generate-analysis.ts")
    cpSync(join(import.meta.dirname, "generate-analysis.ts"), script)
    cpSync(join(import.meta.dirname, "site-out.ts"), join(out, "scripts", "site-out.ts"))
    for (const name of [
      "features",
      "terminals",
      "categories",
      "standards",
      "baselines",
      "frameworks",
      "glossary",
      "annotations",
    ]) {
      cpSync(join(sourceRoot, "content", `${name}.json`), join(out, "content", `${name}.json`))
    }
    cpSync(join(sourceRoot, "content", "suites"), join(out, "content", "suites"), { recursive: true })
    cpSync(join(sourceRoot, "content", "archived-exclusions.json"), join(out, "content", "archived-exclusions.json"))
    const control = spawnSync(process.execPath, [script, "--dry-run"], { cwd: out, encoding: "utf8", timeout: 10_000 })
    expect(control.error).toBeUndefined()
    expect(control.status, control.stderr).toBe(0)
    expect(control.stdout).toContain("Would generate")
    const outputPath = join(out, "content", "analysis.json")
    writeFileSync(outputPath, "PRESERVE_PREVIOUS_ANALYSIS")
    for (const [name, invalid] of [
      ["features", "[]"],
      ["terminals", "[]"],
      ["categories", "[]"],
      ["standards", "[]"],
      ["baselines", "[]"],
      ["features", "null"],
    ] as const) {
      const path = join(out, "content", `${name}.json`)
      const original = readFileSync(path, "utf8")
      writeFileSync(path, invalid)
      const result = spawnSync(process.execPath, [script], { cwd: out, encoding: "utf8", timeout: 10_000 })
      expect(result.error).toBeUndefined()
      expect(result.status, `${name}: ${result.stderr}`).toBe(1)
      expect(result.stderr).toContain(path)
      expect(result.stdout).not.toContain("Generated ")
      expect(readFileSync(outputPath, "utf8")).toBe("PRESERVE_PREVIOUS_ANALYSIS")
      writeFileSync(path, original)
    }
  } finally {
    rmSync(out, { recursive: true, force: true })
  }
})

it("analysis validation refuses stale live values and key drift but labels historical schema tests", () => {
  // --validate must prove current values, not merely presence; existing catalog-refusal coverage cannot detect this.
  const out = mkdtempSync(join(tmpdir(), "terminfo-analysis-validation-"))
  try {
    const sourceRoot = join(import.meta.dirname, "..")
    mkdirSync(join(out, "scripts"))
    mkdirSync(join(out, "content"))
    for (const dir of ["probes-apps", "probes-mux", "probes-libs"]) mkdirSync(join(out, "content", dir))
    for (const dir of ["docs", "node_modules"]) symlinkSync(join(sourceRoot, dir), join(out, dir), "dir")
    const script = join(out, "scripts", "generate-analysis.ts")
    cpSync(join(import.meta.dirname, "generate-analysis.ts"), script)
    cpSync(join(import.meta.dirname, "site-out.ts"), join(out, "scripts", "site-out.ts"))
    for (const name of [
      "features",
      "terminals",
      "categories",
      "standards",
      "baselines",
      "frameworks",
      "glossary",
      "annotations",
    ]) {
      cpSync(join(sourceRoot, "content", `${name}.json`), join(out, "content", `${name}.json`))
    }
    cpSync(join(sourceRoot, "content", "suites"), join(out, "content", "suites"), { recursive: true })
    cpSync(join(sourceRoot, "content", "archived-exclusions.json"), join(out, "content", "archived-exclusions.json"))
    const run = (args: string[]) =>
      spawnSync(process.execPath, [script, ...args], { cwd: out, encoding: "utf8", timeout: 10_000 })
    const generated = run([])
    expect(generated.status, generated.stderr).toBe(0)
    const outputPath = join(out, "content", "analysis.json")
    const original = readFileSync(outputPath, "utf8")
    // AC4: a wall-clock $generated stamp made two runs of the same inputs differ.
    const generatedAgain = run([])
    expect(generatedAgain.status, generatedAgain.stderr).toBe(0)
    expect(readFileSync(outputPath, "utf8")).toBe(original)
    expect(JSON.parse(original)).not.toHaveProperty("$generated")
    const isFixtureObject = (value: unknown): value is Record<string, unknown> =>
      value !== null && typeof value === "object" && !Array.isArray(value)
    const parseFixture = (): Record<string, unknown> => {
      const data: unknown = JSON.parse(original)
      if (!isFixtureObject(data)) throw new Error("Expected generated analysis fixture object")
      return data
    }
    const entry = (data: Record<string, unknown>, key: string): Record<string, unknown> => {
      const value = data[key]
      if (!isFixtureObject(value)) throw new Error(`Expected generated analysis fixture entry: ${key}`)
      return value
    }
    const control = parseFixture()
    const liveKey = "terminals/kitty"
    const historicalKey = "terminals/vt100-historical"
    const valid = run(["--validate"])
    expect(valid.status, valid.stderr).toBe(0)
    const cases: Array<[string, (data: typeof control) => void]> = [
      [
        liveKey,
        (data) => {
          entry(data, liveKey).analysis = "<p>Stale claimed support.</p>"
        },
      ],
      [
        liveKey,
        (data) => {
          entry(data, liveKey).date = "2000-01-01"
        },
      ],
      [
        liveKey,
        (data) => {
          entry(data, liveKey).probeCount = 123
        },
      ],
      [
        liveKey,
        (data) => {
          delete data[liveKey]
        },
      ],
      [
        "stale-extra",
        (data) => {
          data["stale-extra"] = data[liveKey]
        },
      ],
      [
        historicalKey,
        (data) => {
          entry(data, historicalKey).analysis = 42
        },
      ],
      [
        historicalKey,
        (data) => {
          entry(data, historicalKey).probeCount = 123
        },
      ],
    ]
    for (const [key, mutate] of cases) {
      const data = parseFixture()
      mutate(data)
      const bytes = JSON.stringify(data)
      writeFileSync(outputPath, bytes)
      const result = run(["--validate"])
      expect(result.status, `${key}: ${result.stderr}`).toBe(1)
      expect(result.stderr).toContain(key)
      expect(result.stdout).not.toContain("Validation passed")
      expect(readFileSync(outputPath, "utf8")).toBe(bytes)
    }
    expect(valid.stdout).toContain(`${liveKey}: current-value passed`)
    expect(valid.stdout).toContain(`${historicalKey}: historical-schema passed`)
    entry(control, historicalKey).analysis = "<p>Older historical reference.</p>"
    entry(control, historicalKey).date = "2000-01-01"
    writeFileSync(outputPath, JSON.stringify(control))
    const historical = run(["--validate"])
    expect(historical.status, historical.stderr).toBe(0)
    expect(historical.stdout).toContain(`${historicalKey}: historical-schema passed`)
  } finally {
    rmSync(out, { recursive: true, force: true })
  }
}, 30_000)

describe("selected-run consumer parity", () => {
  // Representative raw probes cannot answer a composed conflict; existing parity fixtures have no disagreement.
  it.each(["supported", "unsupported"] as const)(
    "keeps a composed conflict out of analysis support and gap claims when its raw probe is %s",
    (rawStatus) => {
      const projection = currentResults.loadCurrentResults("").projection
      const selected = requiredContext(projection, "term", "kitty")
      const entry = { contextKey: selected.contextKey, selected }
      for (const [id, cell] of Object.entries(selected.cells)) {
        cell.result.status = "supported"
        if (cell.featureResult) {
          Object.assign(cell.featureResult, { status: "supported" })
        }
        if (id === "sgr.bold") {
          if (!cell.featureResult) {
            throw new Error("Missing computed bold fixture result")
          }
          cell.result.status = rawStatus
          Object.assign(cell.featureResult, {
            status: "probe-conflict",
            strength: null,
            probeId: null,
            conflictingProbes: ["sgr.bold:output", "sgr.bold:visual"],
          })
        }
      }
      const selection = vi.spyOn(currentResults, "loadCurrentResults").mockReturnValue({ projection })
      const targets = vi.spyOn(currentResults, "compatibilitySubjects").mockReturnValue(new Map([["kitty", entry]]))
      const warning = vi.spyOn(console, "warn").mockImplementation(() => {})
      const stored = JSON.stringify(Object.values(selected.cells).map((cell) => cell.result))
      try {
        const analyses = generateAnalysis()
        const terminal = analyses["terminals/kitty"]
        const feature = analyses["sgr/1-bold"]
        const all = scoredFeatureIds(selected.catalogIds).length
        expect(terminal?.score).toEqual({ supported: all - 1, all })
        expect(terminal?.analysis).toContain("less than full recorded support")
        expect(terminal?.analysis).not.toContain("Observed unsupported")
        expect(feature?.analysis).toContain("No recorded support")
        expect(feature?.analysis).not.toContain("Not supported by")
        expect(JSON.stringify(Object.values(selected.cells).map((cell) => cell.result))).toBe(stored)
      } finally {
        warning.mockRestore()
        targets.mockRestore()
        selection.mockRestore()
      }
    },
  )
  it("publishes v3 run references that resolve to digest-verified full run documents", () => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-run-documents-"))
    try {
      generateApi(out)
      type RunReference = {
        runId: string
        subject: Record<string, unknown>
        measuredAt: string
        suiteId: string
        probeHash: string
        suiteFreshness: string
        sourceRevision: string
        sha256: string
        counts: Record<string, unknown>
        url: string
        documentSha256: string
      }
      const v3 = JSON.parse(readFileSync(join(out, "api", "v3", "data.json"), "utf8")) as {
        contexts: Record<string, { sources: Record<string, RunReference> }>
        versions: Record<string, RunReference[]>
        history: Record<string, RunReference[]>
      }
      const refs = [
        ...Object.values(v3.contexts).flatMap((context) => Object.values(context.sources)),
        ...Object.values(v3.versions).flat(),
        ...Object.values(v3.history).flat(),
      ]
      expect(refs.length).toBeGreaterThan(0)
      for (const ref of refs) {
        expect(ref).toMatchObject({
          runId: expect.any(String),
          subject: expect.any(Object),
          measuredAt: expect.any(String),
          suiteId: expect.any(String),
          probeHash: expect.any(String),
          suiteFreshness: expect.any(String),
          sourceRevision: expect.any(String),
          sha256: expect.any(String),
          counts: expect.any(Object),
          url: expect.stringMatching(/^\/api\/v3\/runs\/[a-f0-9]{64}\.json$/),
          documentSha256: expect.stringMatching(/^[a-f0-9]{64}$/),
        })
        const documentBytes = readFileSync(join(out, ref.url))
        expect(createHash("sha256").update(documentBytes).digest("hex")).toBe(ref.documentSha256)
        const document = JSON.parse(documentBytes.toString("utf8")) as Record<string, unknown>
        expect(document).toMatchObject({ runId: ref.runId, sha256: ref.sha256, subject: ref.subject })
        expect(document.results).toBeDefined()
      }
    } finally {
      rmSync(out, { recursive: true, force: true })
    }
  })

  // 30565: a displayed run's trace is a lazy file beside its run document; a summary never holds one.
  it("writes each displayed run's trace beside its run document and reports trace bytes and files", () => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-run-traces-"))
    try {
      generateApi(out)
      const listed = (dir: string) =>
        existsSync(join(out, dir)) ? readdirSync(join(out, dir)).map((name) => `/${dir}/${name}`) : []
      const read = (url: string) => readFileSync(join(out, url), "utf8")
      // Every published API version the build writes, so the check follows the build, not a fixed prefix.
      const versions = readdirSync(join(out, "api")).filter((name) => /^v\d+$/.test(name))
      const receipts: string[] = []
      for (const version of versions) {
        for (const url of listed(`api/${version}/runs`)) {
          const run = JSON.parse(read(url)) as { sha256: string; trace?: { url: string; sha256: string } }
          if (!run.trace) continue
          const bytes = readFileSync(join(out, run.trace.url))
          expect(createHash("sha256").update(bytes).digest("hex")).toBe(run.trace.sha256)
          expect(JSON.parse(bytes.toString("utf8"))).toMatchObject({ version: 1, runSha256: run.sha256 })
          receipts.push(run.trace.url)
        }
      }
      // Every trace file is exactly one run document's receipt.
      const traces = versions.flatMap((version) => listed(`api/${version}/traces`))
      expect(traces.sort()).toEqual(receipts.sort())
      const cellsOf = (url: string) =>
        (JSON.parse(read(url)) as { featureResults: Record<string, unknown> }).featureResults
      const cell = (url: string, featureId: string) => cellsOf(url)[featureId]
      expect(cell(`/api/v3/traces/${fixture.selected.sha256}.json`, "sgr.bold")).toMatchObject({ status: "supported" })
      const report = assertDeploymentLimits(out)
      expect(report.traceFiles).toBe(traces.length)
      expect(report.traceBytes).toBe(traces.reduce((total, url) => total + statSync(join(out, url)).size, 0))
      const summaries = Object.keys(report.dataJsonBytes)
      expect(summaries).toContain("api/v3/data.json")
      for (const path of summaries) {
        const summary = read(path)
        expect(report.dataJsonBytes[path]).toBe(Buffer.byteLength(summary))
        // A summary may carry a run's receipt; it never carries the trace's records.
        for (const url of traces) expect(summary).not.toContain(JSON.stringify(cellsOf(url)))
      }
    } finally {
      rmSync(out, { recursive: true, force: true })
    }
  })

  it("ships current cells without the build-time selection payload", () => {
    const site = probesLoader.load()
    expect(Object.hasOwn(site, "selected")).toBe(false)
    // #30759 AC3: the projection no longer carries a historical reader at all, so there is no
    // second, legacy selection payload that could ride along with the site's current rows.
    expect(Object.hasOwn(currentResults.loadCurrentResults("").projection, "historical")).toBe(false)
  })

  it("keeps raw evidence and unchecked collector notes out of generated site and API summaries", () => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-presentation-"))
    let selection: ReturnType<typeof vi.spyOn> | undefined
    try {
      const site = probesLoader.load()
      generateApi(out)
      const v3 = readFileSync(join(out, "api", "v3", "data.json"), "utf8")
      for (const serialized of [JSON.stringify(site), v3]) {
        for (const marker of [
          "STORED_ASSERTION_EXPECTED",
          "PRIVATE_DIAGNOSTIC",
          "/home/fixture/private",
          "/private/fixture/app",
        ]) {
          expect(serialized).not.toContain(marker)
        }
      }
      expect(site.results.kitty?.["sgr.bold"]).toBe("supported")
      // Current v3 must preserve exact sealed status while publication independently controls bytes.
      const projection = currentResults.loadCurrentResults("").projection
      const context = requiredContext(projection, "term", "kitty")
      const current = originalRun(projection, context)
      if (!current) throw new Error("Missing sealed privacy fixture")
      const result = current.results.find((result) => result.featureId === "sgr.bold")
      if (!result) throw new Error("Missing sealed privacy result")
      result.rawReplyRef = "bold-reply"
      const screenshot = Buffer.from(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=",
        "base64",
      )
      const screenshotSha256 = createHash("sha256").update(screenshot).digest("hex")
      result.screenshotRef = `sha256:${screenshotSha256}`
      result.reason = "UNAPPROVED_CURRENT_REASON /home/fixture/private"
      current.suiteId = probeHash()
      for (const cell of Object.values(context.cells)) cell.run.suiteId = current.suiteId
      selection = vi.spyOn(currentResults, "loadCurrentResults").mockReturnValue({ projection })
      current.rawReplies = { "bold-reply": "RETAINED_CURRENT_REPLY" }
      current.assertions = [
        { featureId: "sgr.bold", kind: "positive", expected: "expected criterion", observed: "actual response" },
      ]
      const targets = new Map([["kitty", { contextKey: context.contextKey, selected: context }]])
      const unpublished = publicResults(projection, targets)
      expect(JSON.stringify(unpublished.projection.contexts)).not.toContain("RETAINED_CURRENT_REPLY")
      // 30565: the displayed run's trace publishes the unreviewed result's allowlisted record only.
      const receipt = unpublished.projection.contexts[context.contextKey]?.sources[current.runId]?.trace
      if (!receipt) throw new Error("Missing trace receipt for the displayed current run")
      expect(receipt.url).toBe(`/api/v3/traces/${current.sha256}.json`)
      const trace = unpublished.documents.get(receipt.url)
      if (!trace) throw new Error(`Missing trace document ${receipt.url}`)
      expect(createHash("sha256").update(trace.bytes).digest("hex")).toBe(receipt.sha256)
      const { featureResults: cells } = JSON.parse(trace.bytes) as { featureResults: Record<string, unknown> }
      expect(cells["sgr.bold"]).toEqual({
        status: "supported",
        ...(result.assertionType && { assertionType: result.assertionType }),
        replyWithheld: true,
        assertions: [{ kind: "positive", expected: "expected criterion", observed: "actual response" }],
      })
      for (const marker of [
        "RETAINED_CURRENT_REPLY",
        "UNAPPROVED_CURRENT_REASON",
        "/home/fixture/private",
        screenshotSha256,
      ]) {
        expect(trace.bytes).not.toContain(marker)
      }
      const privateFullProject = loadFullProjectData()
      expect(privateFullProject.collected).toBe(1)
      expect(JSON.stringify(privateFullProject).includes("UNAPPROVED_CURRENT_REASON")).toBe(false)
      expect([...unpublished.documents.keys()].some((url) => url.includes("/evidence/"))).toBe(false)
    } finally {
      selection?.mockRestore()
      rmSync(out, { recursive: true, force: true })
    }
  })

  it("fails by path if copied static evidence was never owned by the generator", () => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-unapproved-artifact-"))
    const path = join(out, "artifacts", `${"f".repeat(64)}.png`)
    try {
      mkdirSync(join(out, "artifacts"))
      writeFileSync(path, "UNAPPROVED_STATIC_IMAGE")
      expect(() => generateApi(out)).toThrow(path)
      expect(readFileSync(path, "utf8")).toBe("UNAPPROVED_STATIC_IMAGE")
    } finally {
      rmSync(out, { recursive: true, force: true })
    }
  })

  it("withdraws an owned run document after its last public projection reference is removed", () => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-stale-run-"))
    // #30759 Slice A: v2 is gone, so the withdrawal rule is exercised on the v3 run documents.
    const runPath = join(out, "api", "v3", "runs", `${fixture.runSha256}.json`)
    const current = fixture.projection.seeds["term:kitty"]
    const versions = fixture.projection.versions["term:kitty"]
    const history = fixture.projection.history["term:kitty"]
    const alternate = fixture.projection.versions["term:kitty:clipboard"]
    try {
      generateApi(out)
      expect(existsSync(runPath)).toBe(true)
      Reflect.deleteProperty(fixture.projection.seeds, "term:kitty")
      fixture.projection.versions["term:kitty"] = []
      fixture.projection.history["term:kitty"] = []
      fixture.projection.versions["term:kitty:clipboard"] = []
      generateApi(out)
      expect(existsSync(runPath)).toBe(false)
    } finally {
      if (current) fixture.projection.seeds["term:kitty"] = current
      fixture.projection.versions["term:kitty"] = versions ?? []
      fixture.projection.history["term:kitty"] = history ?? []
      fixture.projection.versions["term:kitty:clipboard"] = alternate ?? []
      rmSync(out, { recursive: true, force: true })
    }
  })

  it("reports the real output path when the conservative file-count cap is exceeded", () => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-api-file-count-"))
    try {
      for (let index = 0; index < 20_000; index++) {
        writeFileSync(join(out, `ordinary-${index}.txt`), "x")
      }
      let failure: unknown
      try {
        generateApi(out)
      } catch (error) {
        failure = error
      }
      expect(failure).toBeInstanceOf(Error)
      expect((failure as Error).message).toContain(out)
      expect((failure as Error).message).toMatch(/files exceeds the 20000-file Cloudflare Pages Free-plan limit/)
    } finally {
      rmSync(out, { recursive: true, force: true })
    }
  }, 30_000)

  // #30759 Slice A: the oversized-asset case was a v1/v2 reviewed-note projection. With both
  // generators deleted there is no API document built from a note, so the cap is covered by the
  // site-asset rejection below and by assertDeploymentLimits' own tests.
  // An empty deployment directory is a wrong build subject, not evidence of spare capacity.
  it("refuses an empty deployment tree instead of certifying the wrong directory", () => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-empty-deploy-"))
    try {
      expect(() => assertDeploymentLimits(out)).toThrow(`${out}: deployment output contains no files`)
    } finally {
      rmSync(out, { recursive: true, force: true })
    }
  })

  // The renderer writes files outside the API writer; its final deployment check must cover them too.
  it.each(["oversized", "symlink"])("rejects %s site assets at the final deployment boundary", (kind) => {
    const out = mkdtempSync(join(tmpdir(), "terminfo-site-asset-limit-"))
    const path = join(out, "page.html")
    try {
      if (kind === "oversized") writeFileSync(path, Buffer.alloc(25 * 1024 * 1024 + 1))
      else symlinkSync("missing-page.html", path)
      let failure: unknown
      try {
        assertDeploymentLimits(out)
      } catch (error) {
        failure = error
      }
      expect(failure).toBeInstanceOf(Error)
      expect((failure as Error).message).toContain(path)
      expect((failure as Error).message).toContain(kind === "oversized" ? "26214401 bytes" : "symlink")
    } finally {
      rmSync(out, { recursive: true, force: true })
    }
  })

  it("keeps the same run, conclusive counts and measurement time in every consumer", () => {
    const warnings: string[] = []
    const warning = vi.spyOn(console, "warn").mockImplementation((message: unknown) => warnings.push(String(message)))
    const out = mkdtempSync(join(tmpdir(), "terminfo-api-parity-"))
    try {
      const site = probesLoader.load()
      const terminal = terminalPaths.paths().find((page) => page.params.id === "kitty")
      const analyses = generateAnalysis()
      const analysis = analyses["terminals/kitty"]
      generateApi(out)
      // #30759 Slice A: v3 is the only generated consumer; v1 is frozen bytes and v2 is deleted.
      const v3 = JSON.parse(readFileSync(join(out, "api", "v3", "data.json"), "utf8")) as {
        contexts: Record<string, PublicContextSummary>
      }
      expect(site.stats.kitty).toMatchObject({
        // D132 B (#30917): the nine environment positions are recorded but never graded.
        score: { all: 264, supported: 1 },
        counts: { supported: 1, unsupported: 1, "probe-todo": 262 },
        complete: false,
      })
      expect(terminal?.params).toMatchObject({ total: "264", yes: "1", no: "1" })
      // Raw history names declared physical subjects without entering these reviewed counts.
      expect(JSON.parse(terminal?.params.historySubjects ?? "[]")).toEqual([
        { engine: "kitty", kind: "term" },
        { engine: "kitty", kind: "lib" },
      ])
      expect(terminal?.params.runSha256).toBeUndefined()
      expect(terminal?.params.generated).toBeUndefined()
      expect(terminal?.params.analysisDate).toContain(fixture.measuredAt)
      const alternatives = JSON.parse(terminal!.params.otherRuns!) as PublicVersion[]
      expect(alternatives.map((run) => run.runId).sort()).toEqual([
        "kitty-clipboard-reviewed-sealed-eeeeeeee",
        "kitty-reviewed-sealed-aaaaaaaa",
      ])
      expect(alternatives.find((run) => run.subject.permissions)?.subject.permissions).toBe(
        "clipboard: read=deny,write=allow",
      )
      const screenPage = terminalPaths.paths().find((page) => page.params.backendId === "screen")!
      const olderRuns = JSON.parse(screenPage.params.otherRuns!) as PublicVersion[]
      expect(olderRuns.map((run) => run.subject.version).sort()).toEqual(["4.9", "5.0"])
      expect(terminal?.params.terminalType).toBe("term")
      const kitty = Object.values(v3.contexts).find((context) => context.subject?.id === "kitty")
      const tmux = Object.values(v3.contexts).find((context) => context.subject?.id === "tmux")
      expect(Object.values(kitty?.sources ?? {}).map((run) => run.sha256)).toContain(fixture.runSha256)
      expect(Object.values(tmux?.sources ?? {}).map((run) => run.sha256)).toContain(fixture.mux.sha256)
      expect(analysis).toMatchObject({
        sources: [expect.objectContaining({ sha256: fixture.runSha256, measuredAt: fixture.measuredAt })],
        versions: [fixture.selected.subject.version],
        score: { supported: 1, all: 264 },
      })
      expect(analyses["features-index"]?.analysis).toContain("recorded support")
      expect(analyses["baseline/core"]?.analysis).toContain("<strong>0</strong> of 3")
      expect(analyses["framework/ink"]?.analysis).toContain("<strong>0</strong> of 3")
      expect(analyses["framework/ink"]?.analysis).not.toContain("Known unsupported baseline results")
      expect(analyses["framework/ink"]?.analysis).toContain("Less than full recorded support")
      expect(analyses["sgr/38-2-truecolor-fg"]?.analysis).toContain("recorded support")
      expect(analyses.cursor?.analysis).toContain("covers 22 features")
      expect(analyses.vt220?.analysis).toBeDefined()
      expect(analyses["baseline/modern"]?.analysis).toContain("0</strong>")
      expect(warnings.some((message) => message.includes("historical analysis snapshot is not current evidence"))).toBe(
        false,
      )
      expect(warnings.every((message) => message.includes("no stored current runs"))).toBe(true)
    } finally {
      warning.mockRestore()
      rmSync(out, { recursive: true, force: true })
    }
  })

  it("names the canonical Legacy baseline for a measured legacy feature", () => {
    // Core-only fixtures would miss the generator's former fallback of every other baseline to Unicode.
    const warnings: string[] = []
    const warning = vi.spyOn(console, "warn").mockImplementation((message: unknown) => warnings.push(String(message)))
    const featureId = "modes.decsclm"
    const cells = fixture.selected.cells
    const results = fixture.selected.v1
    const bold = cells["sgr.bold"]
    if (!bold) throw new Error("Missing selected bold fixture cell")
    try {
      Object.assign(cells, {
        [featureId]: {
          ...bold,
          featureId,
          outcome: "unsupported",
          assertionType: "query_reply",
          conclusive: true,
          record: { assertions: [{ featureId, kind: "negative", expected: "smooth scroll", observed: "jump scroll" }] },
          chain: { ...bold.chain, method: "behavior" },
        },
      })
      Object.assign(results, { [featureId]: false })
      const analysis = generateAnalysis()["modes/decsclm-smooth-scroll"]?.analysis
      expect(analysis).toContain("Legacy")
      expect(analysis).not.toContain("Unicode")
      expect(warnings.every((message) => message.includes("no stored current runs"))).toBe(true)
    } finally {
      warning.mockRestore()
      Reflect.deleteProperty(cells, featureId)
      Reflect.deleteProperty(results, featureId)
    }
  })

  it("uses the merged category/tag feature scope for analysis and unsupported gaps", () => {
    // Unicode's category-only tab-stop feature used to disappear when tag prose overwrote the merged page.
    const id = "unicode.tab-stops"
    const cells = fixture.selected.cells
    const results = fixture.selected.v1
    const bold = cells["sgr.bold"]
    const warning = vi.spyOn(console, "warn").mockImplementation(() => {})
    try {
      Object.assign(cells, { [id]: { ...bold, featureId: id, outcome: "unsupported", conclusive: true } })
      Object.assign(results, { [id]: false })
      const page = categoryPaths.paths().find((entry) => entry.params.id === "unicode")!
      const rows = JSON.parse(page.params.features!) as Array<{ id: string }>
      expect(rows.map((row) => row.id)).toContain(id)
      const prose = generateAnalysis().unicode!.analysis
      expect(prose).toContain(`covers ${page.params.featureCount} features`)
      expect(prose).toContain("Tab Stops")
      expect(prose).not.toContain("awaiting verified measurements")
    } finally {
      Reflect.deleteProperty(cells, id)
      Reflect.deleteProperty(results, id)
      warning.mockRestore()
    }
  })

  it("keeps a mixed-suite subject visible with one retained original cell", () => {
    const site = probesLoader.load()
    const terminal = terminalPaths.paths().find((page) => page.params.id === "gnu-screen")
    expect(site.backends.map((backend) => backend.name)).toContain("screen")
    expect(site.stats.screen).toMatchObject({
      score: { all: 264, supported: 0 },
      counts: { supported: 0, unsupported: 1, untestable: 0, "probe-todo": 263, "probe-invalid": 0 },
      complete: false,
    })
    expect(site.stats.screen?.pct).toBe(0)
    expect(terminal?.params).toMatchObject({
      pct: "0",
    })
    expect(JSON.parse(terminal?.params.versions ?? "[]")).toEqual([
      expect.objectContaining({
        version: fixture.screen.subject.version,
        pct: 0,
        suiteFreshness: "tree suite current",
      }),
      expect.objectContaining({ version: "4.9", pct: 0, suiteFreshness: "older suite older-suite" }),
    ])
    const screen = loadProbes().selectedByBackend.screen!.selected
    const olderRunId = "screen-older-reviewed-sealed-cccccccc"
    const currentRunId = "screen-reviewed-sealed-dddddddd"
    expect(screen.contributingRunIds).toEqual([olderRunId, currentRunId])
    expect(Object.values(screen.featureResults).filter((cell) => cell.origin.runId === olderRunId)).toHaveLength(1)
    expect(Object.values(screen.featureResults).filter((cell) => cell.origin.runId === currentRunId)).toHaveLength(272)
    expect(screen.featureResults["extensions.sixel"]).toMatchObject({
      status: "unsupported",
      origin: { runId: olderRunId, resultId: "extensions.sixel" },
      suiteId: "older-suite",
      suiteRelation: "older",
      measuredAt: fixture.measuredAt,
    })
    expect(screen.featureResults["sgr.bold"]).toMatchObject({
      status: "probe-todo",
      origin: { runId: currentRunId, resultId: "sgr.bold" },
      suiteRelation: "tree",
      measuredAt: fixture.screen.measuredAt,
    })
    expect(screen.sources[olderRunId]).toMatchObject({
      suiteFreshness: "older suite older-suite",
      suiteRelation: "older",
      sha256: "c".repeat(64),
      measuredAt: fixture.measuredAt,
    })
    expect(screen.sources[currentRunId]).toMatchObject({
      suiteFreshness: "tree suite current",
      suiteRelation: "tree",
      sha256: "d".repeat(64),
      measuredAt: fixture.screen.measuredAt,
    })
    expect(site.releaseStale.screen).toBeNull()
    const comparison = comparePaths
      .paths()
      .find(
        (page) =>
          [page.params.termAId, page.params.termBId].includes("screen") &&
          [page.params.termAId, page.params.termBId].includes("kitty"),
      )
    expect(comparison?.params[comparison.params.termAId === "screen" ? "termATotal" : "termBTotal"]).toBe("264")
    expect(comparison?.params.comparableScope).toBe("false")
    const core = baselinePaths.paths().find((page) => page.params.id === "core")
    expect(JSON.parse(core?.params.scores ?? "[]")).toContainEqual(
      expect.objectContaining({ name: "screen", score: { all: 79, supported: 0 }, pct: 0 }),
    )
    const bold = featurePaths.paths().find((page) => page.params.featureId === "sgr.bold")
    expect(bold?.params).toMatchObject({ yesCount: "1", totalCount: "3" })
  })

  it("limits comparison claims to the same recorded scope and jointly conclusive evidence method", () => {
    const data = loadProbes()
    const kittyEntry = data.selectedByBackend.kitty
    const screenEntry = data.selectedByBackend.screen
    const tmuxEntry = data.selectedByBackend.tmux
    const kitty = kittyEntry?.selected
    const screen = screenEntry?.selected
    const tmux = tmuxEntry?.selected
    const bold = kitty?.featureResults["sgr.bold"]
    if (!screen?.subject || !tmux?.subject || !bold || !screenEntry || !tmuxEntry) {
      throw new Error("Missing comparison fixtures")
    }
    function requiredResult(run: PublicContextSummary, id: string) {
      const result = run.featureResults[id]
      if (!result) throw new Error(`Missing fixture result ${id}`)
      return result
    }
    function refresh(entry: NonNullable<ReturnType<typeof loadProbes>["selectedByBackend"][string]>) {
      entry.states = Object.fromEntries(
        Object.values(entry.selected.featureResults).map((result) => [result.featureId, result.status]),
      )
      const aggregate = aggregateCurrentResults(Object.values(entry.selected.featureResults), entry.selected.catalogIds)
      entry.selected.complete = aggregate.complete
      entry.selected.counts = aggregate.counts
      entry.selected.score = { supported: aggregate.supported, all: aggregate.denominator }
    }
    const mixed = comparePaths
      .paths()
      .find(
        (page) =>
          [page.params.termAId, page.params.termBId].includes("screen") &&
          [page.params.termAId, page.params.termBId].includes("kitty"),
      )
    expect(mixed?.params.comparableScope).toBe("false")
    expect(mixed?.params.differ).toBe("")
    expect(mixed?.params.termAKind).toBeDefined()
    expect(mixed?.params.termBKind).toBeDefined()

    const originalScreen = structuredClone(screen)
    const originalTmux = structuredClone(tmux)
    try {
      screen.subject.mux = tmux.subject.mux
      for (const result of [...Object.values(screen.featureResults), ...Object.values(tmux.featureResults)]) {
        Object.assign(result, { status: "unsupported" })
      }
      Object.assign(requiredResult(screen, "sgr.bold"), { assertionType: bold.assertionType, status: "unsupported" })
      Object.assign(requiredResult(tmux, "sgr.bold"), { assertionType: bold.assertionType, status: "supported" })
      Object.assign(requiredResult(screen, "extensions.sixel"), {
        status: "unsupported",
        assertionType: "buffer_state",
      })
      Object.assign(requiredResult(tmux, "extensions.sixel"), { status: "supported", assertionType: "query_reply" })
      refresh(screenEntry)
      refresh(tmuxEntry)
      const pair = comparePaths
        .paths()
        .find(
          (page) =>
            [page.params.termAId, page.params.termBId].includes("screen") &&
            [page.params.termAId, page.params.termBId].includes("tmux"),
        )
      expect(pair?.params.comparableScope).toBe("true")
      expect(pair?.params.jointConclusive).toBe("1")
      expect(pair?.params.differ).toBe("1")
      const rows = JSON.parse(pair?.params.categories ?? "[]") as Array<{
        features: Array<{ id: string; comparable: boolean }>
      }>
      const cells = rows.flatMap((category) => category.features)
      expect(cells.find((cell) => cell.id === "sgr.bold")?.comparable).toBe(true)
      expect(cells.find((cell) => cell.id === "extensions.sixel")?.comparable).toBe(false)

      screen.subject.os = null
      const unknownOsPair = comparePaths
        .paths()
        .find(
          (page) =>
            [page.params.termAId, page.params.termBId].includes("screen") &&
            [page.params.termAId, page.params.termBId].includes("tmux"),
        )
      expect(unknownOsPair?.params.comparableScope).toBe("false")
    } finally {
      Object.assign(screen, originalScreen)
      Object.assign(tmux, originalTmux)
      refresh(screenEntry)
      refresh(tmuxEntry)
    }
  })

  it("scores baseline support over the full catalog and exposes test failures", () => {
    const site = probesLoader.load()
    const catalog = site.baselines.core?.length ?? 0
    expect(catalog).toBeGreaterThan(1)
    // The core baseline holds 80 catalogue positions, one of them an ungraded environment group.
    const graded = scoredFeatureIds(site.baselines.core ?? []).length
    expect(graded).toBe(catalog - 1)
    expect(site.baselineStats.kitty?.core).toMatchObject({
      score: { all: graded, supported: 1 },
      pct: Math.round(100 / graded),
      counts: { supported: 1, unsupported: 0, untestable: 0, "probe-invalid": 0, "probe-todo": graded - 1 },
    })
    expect(site.baselineStats.screen?.core).toMatchObject({
      score: { all: graded, supported: 0 },
      pct: 0,
      counts: { supported: 0, unsupported: 0, untestable: 0, "probe-invalid": 0, "probe-todo": graded },
    })
    const core = baselinePaths.paths().find((page) => page.params.id === "core")
    const scores = JSON.parse(core?.params.scores || "[]") as Array<Record<string, unknown>>
    expect(scores.find((score) => score.name === "kitty")).toMatchObject({
      version: fixture.selected.subject.version,
      score: { all: graded, supported: 1 },
      pct: Math.round(100 / graded),
    })
    const screenBold = fixture.screen.cells["sgr.bold"] as SelectedCell
    if (!screenBold) throw new Error("Missing screen error-count fixture cell")
    const originalScreenBold = structuredClone(screenBold)
    try {
      screenBold.outcome = "error"
      screenBold.reason = "collector-error"
      expect(probesLoader.load().baselineStats.screen?.core).toMatchObject({
        counts: { "probe-invalid": 1, "probe-todo": graded - 1 },
        score: { all: graded, supported: 0 },
      })
    } finally {
      Object.assign(screenBold, originalScreenBold)
      if (originalScreenBold.reason === undefined) delete screenBold.reason
    }
  })

  it("keeps unscoped annotations out of feature analysis while retaining reviewed selected notes", () => {
    const warnings: string[] = []
    const warning = vi.spyOn(console, "warn").mockImplementation((message: unknown) => warnings.push(String(message)))
    const annotations = JSON.parse(
      readFileSync(join(import.meta.dirname, "..", "content", "annotations.json"), "utf8"),
    ) as Record<string, { note: string }>
    const unscoped = annotations["kitty:extensions.sixel"]?.note
    if (!unscoped) throw new Error("Missing Kitty sixel annotation fixture")
    const cell = fixture.selected.cells["extensions.sixel"] as SelectedCell
    const original = structuredClone(cell)
    const annotationId = "extensions.osc1337-cellsize"
    const previousAnnotated = fixture.selected.cells[annotationId]
    try {
      const unreviewed = generateAnalysis()["extensions/sixel-graphics"]?.analysis
      expect(unreviewed).not.toContain(unscoped)
      expect(unreviewed).toContain("No recorded support among")
      expect(unreviewed).toContain("Not supported by:")
      cell.note = "Reviewed Kitty sixel observation note"
      const reviewed = generateAnalysis()["extensions/sixel-graphics"]?.analysis
      expect(reviewed).not.toContain(unscoped)
      expect(reviewed).not.toContain("Reviewed Kitty sixel observation note")
      // Plain notes cannot veto stored grades or become evidence. Existing negative-result
      // cases miss the old build refusal triggered by a note saying "not supported".
      fixture.selected.cells[annotationId] = {
        ...structuredClone(original),
        featureId: annotationId,
        outcome: "supported",
      }
      const generated = JSON.stringify(generateAnalysis())
      expect(generated).not.toContain(annotations[`kitty:${annotationId}`]!.note)
      expect(warnings.every((message) => message.includes("no stored current runs"))).toBe(true)
    } finally {
      warning.mockRestore()
      Object.assign(cell, original)
      if (original.note === undefined) delete cell.note
      if (previousAnnotated) fixture.selected.cells[annotationId] = previousAnnotated
      else Reflect.deleteProperty(fixture.selected.cells, annotationId)
    }
  })

  it("uses selected public notes across routes without promoting unscoped annotations", () => {
    const data = loadProbes()
    const reviewed = data.selectedByBackend.kitty?.selected.featureResults["sgr.bold"]
    const inconclusive = data.selectedByBackend.screen?.selected.featureResults["sgr.bold"]
    if (!reviewed || !inconclusive) throw new Error("Missing selected bold cells in parity fixture")
    const originalNote = reviewed.reason
    const originalInconclusiveNote = inconclusive.reason
    const originalBoldAnnotation = data.annotations["kitty:sgr.bold"]
    const originalSixelAnnotation = data.annotations["kitty:extensions.sixel"]
    const originalScreenAnnotation = data.annotations["screen:sgr.bold"]
    const originalNotes = structuredClone(data.notes)
    reviewed.reason = "Reviewed Kitty bold note"
    data.notes.kitty = { ...data.notes.kitty, "sgr.bold": "Reviewed Kitty bold note" }
    data.notes.screen = { ...data.notes.screen, "sgr.bold": "Reviewed screen inconclusive note" }
    inconclusive.reason = "Reviewed screen inconclusive note"
    data.annotations["kitty:sgr.bold"] = {
      note: "Unscoped conflicting bold annotation",
      url: "https://example.org/unscoped-implementation",
    }
    data.annotations["kitty:extensions.sixel"] = { note: "Unreviewed sixel annotation" }
    data.annotations["screen:sgr.bold"] = { note: "Unscoped screen annotation" }

    const rowNote = (rows: string, featureId: string, backendName: string): string | undefined =>
      (JSON.parse(rows) as Array<{ id: string; results: Record<string, { note: string }> }>).find(
        (row) => row.id === featureId,
      )?.results[backendName]?.note

    try {
      const categories = categoryPaths.paths()
      const baselines = baselinePaths.paths()
      const terminals = terminalPaths.paths()
      const features = featurePaths.paths()
      const comparison = comparePaths
        .paths()
        .find(
          (entry) =>
            [entry.params.termAId, entry.params.termBId].includes("kitty") &&
            [entry.params.termAId, entry.params.termBId].includes("screen"),
        )
      const comparisonRows = JSON.parse(comparison?.params.categories ?? "[]") as Array<{
        features: Array<{ id: string; noteA: string; noteB: string }>
      }>
      const terminalNote = (backendName: string, featureId: string): string | undefined => {
        const page = terminals.find((entry) => entry.params.backendId === backendName)
        const groups = JSON.parse(page?.params.categories ?? "[]") as Array<{
          features: Array<{ id: string; note: string }>
        }>
        return groups.flatMap((group) => group.features).find((row) => row.id === featureId)?.note
      }
      for (const [backendName, featureId, categoryId, tagId, baselineId, expected] of [
        ["kitty", "sgr.bold", "sgr", "ecma-48", "core", "Reviewed Kitty bold note"],
        ["kitty", "extensions.sixel", "extensions", "sixel", "rich", ""],
        ["screen", "sgr.bold", "sgr", "ecma-48", "core", "Reviewed screen inconclusive note"],
      ] as const) {
        const category = categories.find((page) => page.params.id === categoryId)
        const tag = categories.find((page) => page.params.id === tagId)
        const baseline = baselines.find((page) => page.params.id === baselineId)
        const feature = features.find((page) => page.params.featureId === featureId)
        const featureRows = JSON.parse(feature?.params.backendResults ?? "[]") as Array<{ name: string; note: string }>
        const comparisonRow = comparisonRows.flatMap((group) => group.features).find((row) => row.id === featureId)
        expect(rowNote(category?.params.features ?? "[]", featureId, backendName)).toBe(expected)
        expect(rowNote(tag?.params.features ?? "[]", featureId, backendName)).toBe(expected)
        expect(rowNote(baseline?.params.features ?? "[]", featureId, backendName)).toBe(expected)
        expect(featureRows.find((row) => row.name === backendName)?.note).toBe(expected)
        expect(comparison?.params.termAId === backendName ? comparisonRow?.noteA : comparisonRow?.noteB).toBe(expected)
        expect(terminalNote(backendName, featureId)).toBe(expected)
      }
      expect(data.results.screen?.["sgr.bold"]).toBe("probe-todo")
      const bold = features.find((page) => page.params.featureId === "sgr.bold")
      const boldResults = JSON.parse(bold?.params.backendResults ?? "[]") as Array<Record<string, unknown>>
      expect(boldResults.find((row) => row.name === "kitty")).not.toHaveProperty("url")
      expect(data.annotations["kitty:sgr.bold"]?.note).toBe("Unscoped conflicting bold annotation")
      expect(data.annotations["kitty:sgr.bold"]?.url).toBe("https://example.org/unscoped-implementation")
      expect(data.annotations["kitty:extensions.sixel"]?.note).toBe("Unreviewed sixel annotation")
      expect(data.annotations["screen:sgr.bold"]?.note).toBe("Unscoped screen annotation")
    } finally {
      data.notes = originalNotes
      if (originalNote === undefined) delete reviewed.reason
      else reviewed.reason = originalNote
      if (originalInconclusiveNote === undefined) delete inconclusive.reason
      else inconclusive.reason = originalInconclusiveNote
      if (originalBoldAnnotation === undefined) delete data.annotations["kitty:sgr.bold"]
      else data.annotations["kitty:sgr.bold"] = originalBoldAnnotation
      if (originalSixelAnnotation === undefined) delete data.annotations["kitty:extensions.sixel"]
      else data.annotations["kitty:extensions.sixel"] = originalSixelAnnotation
      if (originalScreenAnnotation === undefined) delete data.annotations["screen:sgr.bold"]
      else data.annotations["screen:sgr.bold"] = originalScreenAnnotation
    }
  })
})

it("labels the headless Ghostty cores libghostty-vt and keeps Ghostty for the app", () => {
  // Operator 2026-10-21 (30608): a headless Ghostty core is the library, never the app that embeds it.
  // The WASM core is measured under the app entry, so its label comes from that entry's headlessLabels.
  const projection = currentResults.loadCurrentResults("").projection
  const as = (_contextKey: string, kind: CurrentSelectedVersion["subject"]["kind"], id: string) =>
    addFixtureSubject(projection, kind, id)
  const selection = vi.spyOn(currentResults, "loadCurrentResults").mockReturnValue({ projection })
  const targets = vi.spyOn(currentResults, "compatibilitySubjects").mockReturnValue(
    new Map([
      ["ghostty", as("app:ghostty", "term", "ghostty")],
      ["headless-ghostty", as("headless:ghostty", "lib", "ghostty")],
      ["ghostty-native", as("headless:ghostty-native", "lib", "ghostty-native")],
    ]),
  )
  try {
    const { meta } = loadFullProbes()
    expect(meta["headless-ghostty"]?.label).toBe("libghostty-vt (WASM)")
    expect(meta["ghostty-native"]?.label).toBe("libghostty-vt (native)")
    expect(meta.ghostty?.label).toBe("Ghostty")
  } finally {
    targets.mockRestore()
    selection.mockRestore()
  }
})

it("does not name a subject with no current run on the site", () => {
  // A subject absent from the selected projection gets no row or run data. The paired positive
  // control proves that a retained current run for the same named subject is named.
  const projection = structuredClone(currentResults.loadCurrentResults("").projection)
  const selection = vi.spyOn(currentResults, "loadCurrentResults").mockReturnValue({ projection })
  const warning = vi.spyOn(console, "warn").mockImplementation(() => {})
  let probes: ReturnType<typeof vi.spyOn> | undefined
  let analysis: ReturnType<typeof vi.spyOn> | undefined
  try {
    const data = loadFullProbes()
    const { backends, selectedByBackend } = data
    probes = vi.spyOn(probeData, "loadProbes").mockReturnValue(data)
    analysis = vi.spyOn(probeData, "loadAnalysis").mockReturnValue(generateAnalysis())
    // No row and no subject: the site's row set is resolved from current runs only.
    for (const id of ["ghostty", "headless-ghostty", "ghostty-native"]) {
      expect(selectedByBackend[id]).toBeUndefined()
      expect(data.results[id]).toBeUndefined()
      expect(data.stats[id]).toBeUndefined()
    }
    const rows = backends.map((backend) => backend.name)
    expect(rows).not.toContain("ghostty")
    expect(rows).not.toContain("headless-ghostty")
    expect(rows).not.toContain("ghostty-native")
    // No page is manufactured from the historical input: no page carries its cells, and the pages
    // that do name these targets are the catalog's metadata-only pages.
    const pages = terminalPaths.paths()
    for (const [backendId, slug] of [
      ["ghostty", "ghostty"],
      ["ghostty-native", "headless-ghostty-native"],
    ]) {
      const page = pages.find((entry) => entry.params.backendId === backendId)
      expect(page?.params.id).toBe(slug)
      expect(page?.params.total).toBe("")
      expect(page?.params.runSha256).toBeUndefined()
      expect(JSON.parse(page?.params.historySubjects ?? "[]")).toContainEqual({
        engine: "ghostty-native",
        kind: "lib",
      })
      if (backendId === "ghostty") {
        expect(JSON.parse(page?.params.historySubjects ?? "[]")).toContainEqual({ engine: "ghostty", kind: "term" })
      }
    }
    // Non-vacuity control: when the same named subject IS current, the site does name it. Without
    // this, "absent" could mean the fixture never reaches the resolver at all.
    const promoted = structuredClone(projection)
    addFixtureSubject(promoted, "lib", "ghostty-native")
    selection.mockReturnValue({ projection: promoted })
    const controlData = loadFullProbes()
    expect(controlData.selectedByBackend["ghostty-native"]).toBeDefined()
    expect(controlData.backends.map((backend) => backend.name)).toContain("ghostty-native")
  } finally {
    probes?.mockRestore()
    analysis?.mockRestore()
    selection.mockRestore()
    warning.mockRestore()
  }
})

it("terminalPaths.paths() refuses loudly when two pages mint one id", () => {
  // Guard 28047, rebuilt on the same current-row fixture the other parity tests use: two current
  // targets whose catalog names map to one slug must fail the build loudly, naming both rows.
  // The loader memoizes on globalThis, so the rows below are written into a clone and cannot outlive
  // mockRestore into a later test.
  const projection = structuredClone(currentResults.loadCurrentResults("").projection)
  const as = (_contextKey: string, kind: CurrentSelectedVersion["subject"]["kind"], id: string) =>
    addFixtureSubject(projection, kind, id)
  const selection = vi.spyOn(currentResults, "loadCurrentResults").mockReturnValue({ projection })
  const app = as("app:ghostty", "term", "ghostty")
  const native = as("headless:ghostty-native", "lib", "ghostty-native")
  const targets = vi.spyOn(currentResults, "compatibilitySubjects").mockReturnValue(
    new Map([
      ["ghostty", app],
      ["ghostty-native", native],
    ]),
  )
  const warning = vi.spyOn(console, "warn").mockImplementation(() => {})
  let probes: ReturnType<typeof vi.spyOn> | undefined
  let analysis: ReturnType<typeof vi.spyOn> | undefined
  try {
    const data = loadFullProbes()
    probes = vi.spyOn(probeData, "loadProbes").mockReturnValue({
      ...data,
      // The two rows share one published slug, which is what mints one page id twice.
      meta: {
        ...data.meta,
        ghostty: { label: "Ghostty", slug: "ghostty" },
        "ghostty-native": { label: "libghostty-vt (native)", slug: "ghostty" },
      },
    })
    // One explicit entry per minted context — the builder matches original contributors, and a
    // catch-all would also answer a lookup that should have failed.
    analysis = vi.spyOn(probeData, "loadAnalysis").mockReturnValue({
      ...generateAnalysis(),
      "terminals/ghostty": {
        analysis: "<p>app</p>",
        date: "2026-09-28",
        changes: null,
        sources: analysisSources(app.selected),
      },
      "terminals/ghostty-native": {
        analysis: "<p>parser</p>",
        date: "2026-09-28",
        changes: null,
        sources: analysisSources(native.selected),
      },
    } as unknown as ReturnType<typeof probeData.loadAnalysis>)
    let message = ""
    try {
      terminalPaths.paths()
    } catch (cause) {
      message = cause instanceof Error ? cause.message : String(cause)
    }
    expect(message).toContain("mint the id 'ghostty'")
    expect(message).toContain("'ghostty-native'")
    expect(message).not.toBe("")
  } finally {
    probes?.mockRestore()
    analysis?.mockRestore()
    warning.mockRestore()
    targets.mockRestore()
    selection.mockRestore()
  }
})
