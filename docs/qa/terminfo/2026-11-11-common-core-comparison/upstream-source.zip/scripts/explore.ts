#!/usr/bin/env bun
/**
 * Open-ended ecosystem discovery for terminfo.dev.
 *
 * Runs deep research queries against GPT-5.4 to find new terminal standards,
 * emulators, protocols, and extensions that aren't yet tracked. Writes findings
 * to content/radar.jsonl as append-only evidence records with citations and dates.
 *
 * Usage:
 *   bun scripts/explore.ts                    # Run all queries
 *   bun scripts/explore.ts --query 1          # Run one specific query
 *   bun scripts/explore.ts --list             # List query templates
 *   bun scripts/explore.ts --dry-run          # Show queries without running
 *
 * Each finding requires:
 *   - citations with URL + published date + accessed date
 *   - a direct quote or paraphrase from the source
 *   - a suggested_action for human review
 *
 * Cost: ~$0.03 per query (GPT-5.4 with web search). 6 queries = ~$0.20.
 * Run weekly or monthly.
 */

import { readFileSync, existsSync, appendFileSync, mkdirSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { spawn } from "node:child_process"
import { createHash } from "node:crypto"

const __dirname = dirname(fileURLToPath(import.meta.url))
const rootDir = join(__dirname, "..")
const contentDir = join(rootDir, "content")
const radarPath = join(contentDir, "radar.jsonl")

interface Finding {
  id: string // hash of title + first citation URL
  type: "new-terminal" | "new-protocol" | "new-version" | "ecosystem-signal" | "deprecation" | "spec-change"
  title: string
  description: string
  citations: {
    url: string
    title: string
    published: string // ISO date or "unknown"
    accessed: string // ISO date (run date)
    snippet: string
  }[]
  relevance_score: number // 0-10
  suggested_action: "add-to-sources" | "add-feature" | "investigate" | "track-release" | "ignore"
  discovered: string // ISO date
  discoverer: string // script@version
  query_id: string // which query template found it
}

const QUERY_TEMPLATES: { id: string; prompt: string; description: string }[] = [
  {
    id: "active-terminals",
    description: "Survey active terminal emulators and their recent releases",
    prompt: `Survey all active terminal emulator projects as of 2026. For each:
- Name, URL, maintainer
- Latest release version and date (must cite)
- Any unique features beyond xterm (cite the docs)
- Whether it supports modern protocols: Kitty keyboard, Kitty graphics, Sixel, OSC 8, OSC 133

Focus on terminals that had releases in the last 6 months. Include less-known projects
like: mlterm, terminology, cool-retro-term, upterm, Rio, Mosh, Hyper, Warp, Tabby,
Blink, Termius, iSH, a-shell, Zellij (multiplexer), Edex-UI, anything new.

For each finding, provide:
1. At least one citation URL
2. The publication date of each citation (or "unknown" if not visible)
3. A direct quote or paraphrase from the source

If you cannot cite a source, DO NOT include the finding. Do not generate findings
from memory — only from search results.

Output as structured findings suitable for a reference site's discovery pipeline.`,
  },
  {
    id: "new-protocols-2026",
    description: "New escape sequences, OSC numbers, and protocols proposed/implemented in 2025-2026",
    prompt: `What new terminal escape sequences, OSC numbers, or control protocols have been
proposed or implemented in 2025 or 2026? Search GitHub issues, blog posts, RFCs,
spec drafts, terminal release notes, and discussions on Lobste.rs / Hacker News.

Specifically look for:
- New OSC numbers (anything beyond what xterm ctlseqs patch 401 documents)
- New DEC private modes (beyond the ~2000-2100 range we already track)
- New CSI sequences
- New shell integration variants beyond OSC 133/633
- New notification protocols beyond OSC 9 / 99 / 777
- New image protocols
- Keyboard protocol extensions

For each finding:
- URL of primary source
- Publication date
- Direct quote or paraphrase
- Whether it's proposal-only, implemented, or adopted by multiple terminals

Only include findings with verifiable citations. If you cannot find a source,
exclude the finding.`,
  },
  {
    id: "xterm-recent-changes",
    description: "Changes to xterm ctlseqs and xterm releases",
    prompt: `What has changed in xterm ctlseqs (https://invisible-island.net/xterm/ctlseqs/ctlseqs.html)
between patch 400 and the latest patch? What new patches have been released
in 2025-2026? What features were added or changed?

Also check xterm's release announcements and ChangeLog for any new escape
sequences, modes, or resources.

Provide:
- Patch numbers and dates
- Specific changes (quote the ctlseqs document where possible)
- URL to the changelog or patch announcement

Only include verifiable findings with citations.`,
  },
  {
    id: "spec-bodies",
    description: "Active proposals in terminal standards bodies",
    prompt: `Are there any active proposals, drafts, or discussions in terminal-related
standards bodies? Check:
- freedesktop.org terminal-wg (https://gitlab.freedesktop.org/terminal-wg/specifications)
- UAPI Group (https://uapi-group.org/specifications/)
- ECMA / ISO / ANSI (any updates to ECMA-48?)
- Unicode Consortium (terminal-related annexes)
- IETF RFCs mentioning terminal sequences
- W3C (any browser-terminal intersection)

For each finding:
- Organization and URL
- Current status (proposal/draft/active/abandoned)
- Date of last activity
- Direct quote from the spec/discussion

Include abandoned or stalled proposals too — they're still part of the landscape.`,
  },
  {
    id: "ecosystem-articles",
    description: "Terminal-related articles and discussions from influential sources",
    prompt: `What terminal-related articles, blog posts, or discussions have appeared
in 2025-2026 from influential sources? Check:
- Julia Evans (https://jvns.ca) - terminal articles
- Dan Luu (https://danluu.com)
- LWN.net terminal coverage
- Hacker News front-page terminal discussions
- Lobste.rs terminal stories
- Phoronix terminal benchmarks or news
- Mozilla / GNOME / KDE blog posts about terminals

Focus on articles that:
- Describe features terminfo.dev should track
- Compare terminals on specific features
- Propose new protocols or best practices
- Discuss deprecations or compatibility issues

For each: URL, author, publication date, key quote.`,
  },
  {
    id: "vendor-changelogs",
    description: "Changelogs of tracked terminals in the last 6 months",
    prompt: `Check the changelogs of these terminals for changes in the last 6 months
(2025-10 through 2026-04):

- Kitty (https://sw.kovidgoyal.net/kitty/changelog/)
- Ghostty (https://github.com/ghostty-org/ghostty/releases)
- WezTerm (https://wezfurlong.org/wezterm/changelog.html)
- foot (https://codeberg.org/dnkl/foot/releases)
- Alacritty (https://github.com/alacritty/alacritty/releases)
- iTerm2 (https://iterm2.com/downloads.html)
- Windows Terminal (https://github.com/microsoft/terminal/releases)
- mintty (https://github.com/mintty/mintty/releases)
- Contour (https://github.com/contour-terminal/contour/releases)

For each terminal, list:
- Version number and release date
- New escape sequences or protocols added
- Protocols deprecated or behavior changes
- Direct quotes from the changelog

Only report what you can cite with a URL.`,
  },
]

function hashFinding(title: string, firstCitation: string): string {
  return createHash("sha256").update(`${title}|${firstCitation}`).digest("hex").slice(0, 12)
}

function loadExistingIds(): Set<string> {
  if (!existsSync(radarPath)) return new Set()
  const ids = new Set<string>()
  const lines = readFileSync(radarPath, "utf-8").split("\n")
  for (const [index, line] of lines.entries()) {
    if (!line.trim()) continue
    let value: unknown
    try {
      value = JSON.parse(line)
    } catch (error) {
      throw new Error(
        `${radarPath}:${index + 1}: invalid JSON: ${error instanceof Error ? error.message : String(error)}`,
      )
    }
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw new Error(`${radarPath}:${index + 1}: expected radar record with a nonempty string id`)
    }
    const id = (value as Record<string, unknown>).id
    if (typeof id !== "string" || !id) {
      throw new Error(`${radarPath}:${index + 1}: expected radar record with a nonempty string id`)
    }
    ids.add(id)
  }
  return ids
}

async function runDeepQuery(queryPrompt: string): Promise<string> {
  const kmRoot = "/Users/beorn/Code/pim/km"
  return new Promise((resolve, reject) => {
    // Note: don't pass --model — it overrides --deep's web search routing.
    // Deep research picks its own model (GPT-5.4 with web search tool).
    const proc = spawn("bun", ["llm", "--deep", "-y", "--no-recover", queryPrompt], {
      cwd: kmRoot,
      stdio: ["pipe", "pipe", "inherit"],
    })
    let stdout = ""
    proc.stdout?.on("data", (chunk: Buffer) => (stdout += chunk.toString("utf8")))
    proc.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`llm exited with code ${code}`))
        return
      }
      // llm writes content to a temp file and outputs JSON metadata to stdout:
      // {"query":"...", "chars": N, "model":"...", "file": "/tmp/llm-*.txt"}
      // Read the actual content from the output file.
      try {
        const metadataLine = stdout.trim().split("\n").pop()
        if (!metadataLine) {
          reject(new Error("llm did not return output metadata"))
          return
        }
        const result: unknown = JSON.parse(metadataLine)
        const file =
          result && typeof result === "object" && !Array.isArray(result)
            ? (result as Record<string, unknown>).file
            : undefined
        if (typeof file !== "string" || !file) {
          reject(new Error("llm did not return output file path"))
          return
        }
        const content = readFileSync(file, "utf-8")
        // Strip the metadata comment header (lines starting with //)
        const bodyStart = content.indexOf("\n\n")
        resolve(bodyStart > 0 ? content.slice(bodyStart + 2) : content)
      } catch (err) {
        reject(new Error(`Failed to read llm output: ${err instanceof Error ? err.message : String(err)}`))
      }
    })
    proc.on("error", reject)
  })
}

function extractFindings(rawOutput: string, queryId: string): Finding[] {
  // The LLM output is free-form research prose with markdown headings and
  // markdown/plain URLs. We extract findings at any heading level (##, ###, ####)
  // that contains at least one URL in its section body.
  const now = new Date().toISOString().slice(0, 10)
  const findings: Finding[] = []

  // Split at any heading level 2-4 (## or ### or ####)
  // The "## " lookahead preserves the heading for each section
  const sections = rawOutput.split(/\n(?=#{2,4}\s)/)
  for (const section of sections) {
    const titleMatch = section.match(/^#{2,4}\s+(.+?)$/m)
    const matchedTitle = titleMatch?.[1]
    if (!matchedTitle || !titleMatch) continue
    const title = matchedTitle.trim().replace(/[*_`]/g, "") // strip markdown
    if (title.length < 5) continue
    // Skip generic section headers that aren't findings
    if (
      /^(?:overview|summary|key details|verifiable|relevant|baseline|conclusion|references|sources?|notes?|what changed)\b/i.test(
        title,
      )
    ) {
      continue
    }

    // Extract URLs (strip trailing punctuation that commonly appears at end of markdown links)
    const urls = [...section.matchAll(/https?:\/\/[^\s)\]<>"`,]+/g)]
      .map((m) => m[0].replace(/[.,;:!?)]+$/, ""))
      .filter((u) => !/^https?:\/\/(?:example\.com|localhost)/.test(u))
    if (urls.length === 0) continue

    // Dedupe URLs
    const uniqueUrls = [...new Set(urls)]

    // Extract snippets (first 2-3 sentences from non-heading body)
    const body = section
      .slice(titleMatch[0].length)
      .split("\n")
      .filter((l) => !l.match(/^#{2,4}\s/))
      .join(" ")
      .trim()
    const snippet = body
      .split(/(?<=[.!?])\s+/)
      .slice(0, 3)
      .join(" ")
      .slice(0, 400)
      .replace(/\s+/g, " ")

    // Try to find a date in the section (YYYY/MM/DD, YYYY-MM-DD, Month YYYY, etc.)
    const dateMatch = section.match(
      /\b(20\d\d[-/]\d\d[-/]\d\d|(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+20\d\d|20\d\d)\b/,
    )
    const published = dateMatch ? normalizeDate(dateMatch[0]) : "unknown"

    // Heuristic classification
    let type: Finding["type"] = "ecosystem-signal"
    if (/\bpatch\s*#?\d+/i.test(title) || /xterm\s+patch/i.test(title)) type = "spec-change"
    else if (/\b(?:version|release)\b/i.test(title)) type = "new-version"
    else if (/\bOSC\b|\bCSI\b|\bDCS\b|\bSGR\b|protocol|escape|XT[A-Z]/i.test(title)) type = "new-protocol"
    else if (/terminal\s+(?:emulator|app)|ghostty|kitty|wezterm|alacritty|foot|mintty|iterm/i.test(title)) {
      type = "new-terminal"
    } else if (/deprecat|removed|obsolet/i.test(title)) type = "deprecation"

    const firstCitation = uniqueUrls[0]
    if (!firstCitation) continue
    findings.push({
      id: hashFinding(title, firstCitation),
      type,
      title,
      description: snippet,
      citations: uniqueUrls.slice(0, 5).map((url) => ({
        url,
        title: "",
        published,
        accessed: now,
        snippet: snippet.slice(0, 200),
      })),
      relevance_score: 5,
      suggested_action: "investigate",
      discovered: now,
      discoverer: "explore.ts@v1",
      query_id: queryId,
    })
  }

  return findings
}

function normalizeDate(raw: string): string {
  // ISO date passes through
  if (/^20\d\d-\d\d-\d\d$/.test(raw)) return raw
  // Year only
  if (/^20\d\d$/.test(raw)) return `${raw}-01-01`
  // Month YYYY
  const monthMatch = raw.match(/^(\w+)\s+(20\d\d)$/)
  const monthName = monthMatch?.[1]
  const year = monthMatch?.[2]
  if (monthName && year) {
    const months: Record<string, string> = {
      january: "01",
      february: "02",
      march: "03",
      april: "04",
      may: "05",
      june: "06",
      july: "07",
      august: "08",
      september: "09",
      october: "10",
      november: "11",
      december: "12",
    }
    const mo = months[monthName.toLowerCase()]
    if (mo) return `${year}-${mo}-01`
  }
  return "unknown"
}

function appendFindings(findings: Finding[], existing: Set<string>): number {
  let added = 0
  if (!existsSync(contentDir)) mkdirSync(contentDir, { recursive: true })
  for (const f of findings) {
    if (existing.has(f.id)) continue
    appendFileSync(radarPath, JSON.stringify(f) + "\n", "utf-8")
    existing.add(f.id)
    added++
  }
  return added
}

async function main() {
  const args = process.argv.slice(2)
  const dryRun = args.includes("--dry-run")
  const list = args.includes("--list")
  const queryArg = args.findIndex((a) => a === "--query")
  const singleQueryId = queryArg >= 0 ? args[queryArg + 1] : null

  if (list) {
    console.log("Available queries:\n")
    for (const q of QUERY_TEMPLATES) {
      console.log(`  ${q.id}`)
      console.log(`    ${q.description}`)
      console.log()
    }
    return
  }

  const queriesToRun = singleQueryId ? QUERY_TEMPLATES.filter((q) => q.id === singleQueryId) : QUERY_TEMPLATES

  if (queriesToRun.length === 0) {
    console.error(`Unknown query id: ${singleQueryId}`)
    console.error(`Run 'bun scripts/explore.ts --list' to see available queries.`)
    process.exit(1)
  }

  console.log(`\n🔭 Terminfo.dev Ecosystem Explorer`)
  console.log(`Running ${queriesToRun.length} ${queriesToRun.length === 1 ? "query" : "queries"}`)
  console.log(`Radar log: ${radarPath}`)
  console.log(`Cost estimate: ~$${(queriesToRun.length * 0.03).toFixed(2)}\n`)

  if (dryRun) {
    console.log("DRY RUN — queries that would be sent:\n")
    for (const q of queriesToRun) {
      console.log(`=== ${q.id} ===`)
      console.log(q.prompt)
      console.log()
    }
    return
  }

  const existing = loadExistingIds()
  console.log(`Existing findings in radar: ${existing.size}\n`)

  let totalAdded = 0
  let failedQueries = 0
  for (const q of queriesToRun) {
    console.log(`\n📡 Running query: ${q.id}`)
    console.log(`   ${q.description}`)
    const start = Date.now()
    try {
      const output = await runDeepQuery(q.prompt)
      const findings = extractFindings(output, q.id)
      const added = appendFindings(findings, existing)
      totalAdded += added
      const elapsed = Math.round((Date.now() - start) / 1000)
      console.log(`   ✓ ${findings.length} findings extracted, ${added} new (${elapsed}s)`)
    } catch (err) {
      failedQueries++
      console.error(`   ✗ Query failed: ${err instanceof Error ? err.message : String(err)}`)
    }
  }

  console.log(`\n✨ Done. Added ${totalAdded} new findings to ${radarPath}`)
  console.log(`Review with: bun run radar list`)
  if (failedQueries > 0) {
    console.error(`${failedQueries} requested quer${failedQueries === 1 ? "y" : "ies"} failed`)
    process.exitCode = 1
  }
}

main().catch((err) => {
  console.error("Error:", err)
  process.exit(1)
})
