#!/usr/bin/env bash
set -euo pipefail

# Declared probe-batch budget (seconds). Curl /probe and host `docker start --attach`
# share this value for every linux group. @dev/3 ruling 51326e54 (2026-10-11):
# 120s curl was the artefact (ghostty 140.6s, xterm 157.9s completed under 600);
# 180s attach SIGTERM'd wezterm at 177s before classify. Do not split these.
# A full WezTerm batch was still progressing when the shared 600s limit sent SIGTERM
# on 2026-11-04 (OOMKilled=false) and when the 1200s limit sent SIGTERM at 1196.9s
# (exit 143) on 2026-11-09 (#32889). Keep both consumers on the same shared batch budget.
PROBE_BATCH_TIMEOUT_SECONDS=1800

# Calibrate the source face independently of the terminal. A missing proof is a named tool gap,
# never an engine grade. The private fontconfig pins the regular face and its style companions,
# so attribute fixtures can render bold/italic without opening unrelated font fallback.
prepare_font_control() {
  local output=$1 family=$2
  shift 2
  local font='' font_sha='' matched='' pin='' config='' version='' reason='' status=probe-todo proof_state=absent
  local sample='!= -> => <= ==' args style styled_font
  mkdir -p "$output/font-source"
  : > "$output/font-on.json"
  : > "$output/font-off.json"
  : > "$output/font-control.stderr"
  : > "$output/fontconfig.xml"
  args=$(jq -cn --args '$ARGS.positional' -- "$@")
  if ! font=$(fc-match -f '%{file}\n' "$family:style=Regular" 2>> "$output/font-control.stderr"); then
    proof_state='failed to load'
    reason="Font control #32062: fc-match failed for $family"
  elif [[ ! -r "$font" ]]; then
    reason="Font control #32062: selected font file is missing: $font"
  else
    font=$(readlink -f "$font")
    font_sha=$(sha256sum "$font" | cut -d ' ' -f 1)
    pin="$output/font-source/face.ttf"
    ln -s "$font" "$pin"
    # Keep the calibrated regular face, but do not flatten every styled cell to it (#31742).
    # Resolve companions before exporting the private config, while the declared family is visible.
    for style in Bold Italic 'Bold Italic'; do
      styled_font=$(fc-match -f '%{file}\n' "$family:style=$style" 2>> "$output/font-control.stderr")
      ln -s "$(readlink -f "$styled_font")" "$output/font-source/${style// /-}.ttf"
    done
    config="$output/fontconfig.xml"
    printf '<fontconfig><dir>%s</dir><cachedir>%s</cachedir></fontconfig>\n' \
      "$output/font-source" "$output/font-cache" > "$config"
    export FONTCONFIG_FILE="$config"
    if ! matched=$(fc-match -f '%{file}\n' "$family:style=Regular" 2>> "$output/font-control.stderr"); then
      proof_state='failed to load'
      reason='Font control #32062: private fontconfig lookup failed'
    elif [[ "$(readlink -f "$matched")" != "$font" ]]; then
      proof_state=inconclusive
      reason='Font control #32062: private fontconfig did not resolve the exact pinned file'
    elif ! command -v hb-shape > /dev/null; then
      reason='Font control #32062: missing declared hb-shape utility'
    elif ! version=$(hb-shape --version 2>> "$output/font-control.stderr"); then
      proof_state='failed to load'
      reason='Font control #32062: HarfBuzz version lookup failed'
    elif ! hb-shape --output-format=json --no-glyph-names --features=liga=1,calt=1 \
        "$font" "$sample" > "$output/font-on.json" 2>> "$output/font-control.stderr" ||
      ! hb-shape --output-format=json --no-glyph-names --features=liga=0,calt=0 \
        "$font" "$sample" > "$output/font-off.json" 2>> "$output/font-control.stderr"; then
      proof_state='failed to load'
      reason='Font control #32062: HarfBuzz shaping failed; retained stdout and stderr'
    elif ! jq -e -s 'length == 2
        and all(.[]; type == "array" and length > 0 and all(.[]; (.g | type) == "number"))
        and ((.[0] | map(.g)) != (.[1] | map(.g)))' \
        "$output/font-on.json" "$output/font-off.json" > /dev/null 2>> "$output/font-control.stderr"; then
      proof_state=inconclusive
      reason='Font control #32062: no proven ligature glyph-sequence difference with liga/calt on versus off'
    else
      status=source-capable
      proof_state=source-capable
    fi
  fi
  if [[ -n "$reason" ]]; then printf '%s; font remains PROBE TODO, no typed review\n' "$reason" >&2; fi
  jq -n --arg status "$status" --arg reason "$reason" --arg proofState "$proof_state" --arg family "$family" --arg sample "$sample" \
    --arg path "$font" --arg sha "$font_sha" --arg pin "$pin" --arg config "$config" --arg matched "$matched" \
    --argjson args "$args" --rawfile configBytes "$output/fontconfig.xml" \
    --arg version "$version" --rawfile on "$output/font-on.json" \
    --rawfile off "$output/font-off.json" --rawfile stderr "$output/font-control.stderr" '
    {control:"font control #32062",status:$status,reason:$reason,proofState:$proofState,
      requestedFamily:$family,face:$path,sample:$sample,source:{path:$path,sha256:$sha},
      launch:{args:$args,path:$pin,fontconfig:$config,fontconfigBytes:$configBytes,matched:$matched},
      harfbuzz:{version:$version,featuresOn:"liga=1,calt=1",featuresOff:"liga=0,calt=0",on:$on,off:$off,stderr:$stderr}}
    ' > "$output/font.txt"
}

# The same file is copied into the content-addressed runner input and serves
# as the container entry point. This is execution tooling, not a probe engine.
compose_receipt() {
  local host=$1 container=$2 output=$3 final_run=${4:-}
  [[ -r "$host" ]] || { echo "Missing host-measured receipt: $host" >&2; return 2; }
  [[ -r "$container" ]] || { echo "Missing container receipt: $container" >&2; return 2; }
  [[ ! -e "$output" ]] || { echo "Refusing to replace existing run receipt: $output" >&2; return 2; }
  local host_sha container_sha final_run_json=null
  if [[ -n "$final_run" ]]; then
    [[ -r "$final_run" ]] || { echo "Missing final run bytes: $final_run" >&2; return 2; }
    final_run_json=$(jq -e --arg sha "$(sha256sum "$final_run" | cut -d ' ' -f 1)" --arg path "$(basename "$final_run")" '
      if .schemaVersion == 4 and (.runId | type == "string") then {path:$path,runId:.runId,sha256:$sha}
      else error("completion receipt requires a schema-4 run with runId") end' "$final_run") || return 2
  fi
  host_sha=$(sha256sum "$host" | cut -d ' ' -f 1)
  container_sha=$(sha256sum "$container" | cut -d ' ' -f 1)
  jq -e -n --slurpfile host "$host" --slurpfile container "$container" \
    --arg hostSha "$host_sha" --arg containerSha "$container_sha" --argjson finalRun "$final_run_json" '
    ($host[0]) as $h | ($container[0]) as $c |
    if ($h.runId | type) != "string" or ($c.runId | type) != "string" then
      error("missing runId in host or container receipt")
    elif $h.runId != $c.runId then
      error("runId mismatch between host and container receipts")
    elif ($h.runtime.imageId | type) != "string" or ($h.runtime.imageTarSha256 | type) != "string" then
      error("host image identity is missing")
    elif ($c.executable.path | type) != "string" or ($c.executable.sha256 | type) != "string" or
         ($c.invocation.path | type) != "string" or ($c.invocation.sha256 | type) != "string" or
         ($c.sourceArtifact.sha256 | type) != "string" then
      error("container executable or archive identity is missing")
    elif ($h.runnerArtifact.frozenRunnerSha256 | type) != "string" or
         ($h.runnerArtifact.buildReceiptSha256 | type) != "string" or
         $c.collector.frozenRunnerSha256 != $h.runnerArtifact.frozenRunnerSha256 or
         $c.collector.buildReceiptSha256 != $h.runnerArtifact.buildReceiptSha256 then
      error("container collector bytes disagree with host runner receipt")
    elif ($c.probeRun.runId | type) != "string" or ($c.probeRun.sha256 | type) != "string" then
      error("container schema-4 capture identity is missing")
    elif $finalRun != null and $finalRun.runId != $c.probeRun.runId then
      error("final runId differs from original captured runId")
    elif ($h.selectedIDs // null) != ($c.selectedIDs // null) then
      error("host/container probe selection mismatch")
    elif ($c.display.glxinfo | type) != "string" or ($c.display.geometry | type) != "string" then
      error("container display receipt is missing")
    elif ($c.display | has("focusHelper") | not) then
      error("container display receipt does not name the owned focus helper window (#33305)")
    elif ($c.display.focusHelper.pid | type) != "number" or ($c.display.focusHelper.window | type) != "string" or
         ($c.display.focusHelper.window | length) == 0 or ($c.display.focusHelper.geometry | type) != "string" then
      error("container display receipt focus helper is not named by pid, window id and geometry")
    elif $c.clipboardFixture.runId != $h.runId or $c.clipboardFixture.profile != $h.clipboardProfile or
         ($c.clipboardFixture.sha256 | type) != "string" then
      error("container clipboard fixture disagrees with host run or profile")
    else
      $h + {
        executable:$c.executable,
        invocation:$c.invocation,
        sourceArtifact:(($h.sourceArtifact + $c.sourceArtifact)
          | if (.kind // null) == "derived-source-tree" then del(.sri) else . end),
        collector:$c.collector,
        probeRun:(if $finalRun == null then $c.probeRun else $finalRun end),
        display:$c.display,
        clipboardFixture:$c.clipboardFixture,
        sessionBus:$c.sessionBus,
        capture:$c.capture,
        receiptInputs:{hostSha256:$hostSha,containerSha256:$containerSha}
      }
    end
  ' > "$output.partial" || {
    echo "Receipt composition failed; partial output retained at $output.partial" >&2
    return 2
  }
  mv "$output.partial" "$output"
}

# Write the host-measured facts once, before the container is created. Inputs below
# are the image/build metadata measured by the host portion of this launcher.
write_host_receipt() {
  jq -n \
    --argjson ids "$probe_ids" --arg run "$run_id" --arg image "$image_id" --arg tar "$image_tar_sha" \
    --arg arch "$image_arch" --arg nix "$nix_lock_revision" --arg source "$source_revision" \
    --arg root "$root_revision" --arg suite "$suite_hash" --arg bundle "$bundle_tar_sha" \
    --arg bundleNar "$bundle_sha" --arg lock "$root_lock_sha" \
    --arg runnerSha "$frozen_runner_sha" --arg receiptSha "$build_receipt_sha" \
    --arg sourceStatus "$source_status" --slurpfile build "$cli_receipt" \
    --arg collectedAt "$(date -u +%FT%TZ)" \
    --arg grace "${TERMINFO_SENTINEL_GRACE_MS:-250}" \
    --arg preset "$preset" --arg profile "$clipboard_profile" --arg version "$target_version" \
    --arg target "$target_id" --arg mux "$mux_kind" \
    --arg url "$source_url" --arg sri "$source_sri" \
    --arg kind "$proof_kind" --arg narSri "$proof_nar_sri" --arg revision "$proof_revision" \
    '{kind:"app",id:$target,version:$version,os:"linux"} as $app |
    {schemaVersion:1,kind:"linux-xvfb-container",collectedAt:$collectedAt,runId:$run,preset:$preset,clipboardProfile:$profile,sentinelGraceMs:($grace|tonumber),
      declaredTarget:(if $mux == "" then $app else {kind:"mux",id:$mux,os:"linux"} end),
      sourceArtifact:({url:$url,sri:$sri}
        + (if $mux == "" then {} else {target:$app} end)
        + (if $kind == "derived-source-tree"
           then {kind:$kind,narSri:$narSri,revision:$revision} else {} end)),
      runnerArtifact:{sha256:$bundle,narSha256:$bundleNar,
        frozenRunnerSha256:$runnerSha,buildReceiptSha256:$receiptSha,
        build:$build[0],rootBunLockSha256:$lock},
      runtime:{imageId:$image,imageTarSha256:$tar,arch:$arch,nixLockRevision:$nix,
        sourceRevision:$source,sourceTreeStatus:$sourceStatus,rootRevision:$root,suiteHash:$suite},
      status:"raw-unreviewed-history"} + (if $ids == null then {} else {selectedIDs:$ids} end)' > "$1"
}

# Check the unchanged host receipt against the container's declared image metadata.
validate_host_metadata() {
  jq -e --arg preset "$target_preset" --arg profile "$TERMINFO_CLIPBOARD_PROFILE" \
    --arg version "$target_version" --arg url "$target_source_url" \
    --arg target "$target_id" --arg mux "${TERMINFO_MUX_KIND:-}" \
    '.preset == $preset and .clipboardProfile == $profile and
     (if $mux == "" then .declaredTarget.version == $version
      else .declaredTarget == {kind:"mux",id:$mux,os:"linux"} and
        .sourceArtifact.target == {kind:"app",id:$target,version:$version,os:"linux"} end) and
     .sourceArtifact.url == $url' \
    "$1" >/dev/null || {
      echo "Container preset, profile, or target metadata disagrees with host receipt" >&2
      return 2
    }
}

# SIGTERM, then SIGKILL after TERMINFO_STOP_GRACE_SEC (default 2). Unbounded `wait` after kill
# is what kept a completed kitty batch inside the 180 s attach budget (#28552): one owned
# process ignored TERM (kitten __atexit__ / collector) and attach died 143 with receipts on
# disk. Never raise the attach budget to paper over a hang.
stop_owned_processes() {
  local grace=${TERMINFO_STOP_GRACE_SEC:-2}
  local pid still tenths=0 limit
  limit=$((grace * 10))
  for pid in "$@"; do
    [[ -n "${pid:-}" ]] || continue
    kill -0 "$pid" 2>/dev/null || continue
    kill "$pid" 2>/dev/null || true
  done
  while ((tenths < limit)); do
    still=0
    for pid in "$@"; do
      [[ -n "${pid:-}" ]] || continue
      if kill -0 "$pid" 2>/dev/null; then
        still=1
        break
      fi
    done
    ((still == 0)) && return 0
    sleep 0.1
    tenths=$((tenths + 1))
  done
  for pid in "$@"; do
    [[ -n "${pid:-}" ]] || continue
    kill -0 "$pid" 2>/dev/null || continue
    kill -KILL "$pid" 2>/dev/null || true
  done
  for pid in "$@"; do
    [[ -n "${pid:-}" ]] || continue
    wait "$pid" 2>/dev/null || true
  done
  return 0
}

# Host attach is `timeout "$PROBE_BATCH_TIMEOUT_SECONDS" docker start --attach`. 143 is SIGTERM of that budget. A completed
# batch already wrote observed.json + container-receipt.json + v3-capture.json; refusing those is
# how #28552 discarded a 7.5 s kitty run. Other non-zero exits still fail.
completed_batch_survives_attach_timeout() {
  local exit_code=$1 raw=$2
  [[ "$exit_code" == 143 && -f "$raw/observed.json" && -f "$raw/container-receipt.json" && -f "$raw/v3-capture.json" ]]
}

# A producer receipt is read by the host before any container starts. When the CLI launcher is
# available alongside the receipt, the launcher records the suite hash the bundle reports via
# `terminfo.mjs --version` and refuses if the receipt disagrees, so the two cannot diverge.
require_cli_producer_receipt() {
  local receipt=$1 cli_bin=${2:-}
  [[ -r "$receipt" ]] || { echo "Missing CLI producer receipt: $receipt" >&2; return 2; }
  jq -e '
    .schemaVersion == 1 and (.probeHash | type == "string" and test("^[0-9a-f]{12}$")) and
    (.collectorRevision | type == "string" and test("^[0-9a-f]{40}$")) and
    (.bundleSha256 | type == "string" and test("^[0-9a-f]{64}$"))' \
    "$receipt" >/dev/null || { echo "Invalid CLI producer receipt" >&2; return 2; }
  local receipt_probe_hash
  receipt_probe_hash=$(jq -er .probeHash "$receipt")
  if [[ -z "$cli_bin" && -f "$(dirname "$receipt")/../bin/terminfo.mjs" && -f "$(dirname "$receipt")/terminfo.bundle.mjs" ]]; then
    cli_bin="$(dirname "$receipt")/../bin/terminfo.mjs"
  fi
  if [[ -n "$cli_bin" ]]; then
    local version_line bundle_probe_hash
    version_line=$(node "$cli_bin" --version) || return 2
    if [[ "$version_line" =~ \(([0-9a-f]{12})\)$ ]]; then
      bundle_probe_hash=${BASH_REMATCH[1]}
    else
      echo "CLI --version did not report a 12-hex suite hash: $version_line" >&2
      return 2
    fi
    if [[ "$bundle_probe_hash" != "$receipt_probe_hash" ]]; then
      echo "CLI bundle suite $bundle_probe_hash differs from producer receipt $receipt_probe_hash" >&2
      return 2
    fi
    printf '%s\n' "$bundle_probe_hash"
    return 0
  fi
  printf '%s\n' "$receipt_probe_hash"
  return 0
}

# The in-image source proof is ONE comparison for both proof kinds (@cto 2026-10-06, 27892): the
# archive the image carries - a flat upstream archive, or a tar DERIVED from the upstream tree - must
# hash to exactly the flat sha256 the image declared in TERMINFO_TARGET_SOURCE_SRI. A derived kind
# adds no second mechanism; it feeds this same check, so a wrong pin is refused here by name.
verify_source_archive_hash() { # $1 measured sha256 hex, $2 declared sri, $3 label for the message
  local measured=$1 declared=$2 label=${3:-source} expected
  [[ "$declared" == sha256-* ]] || {
    echo "$label has no declared flat sha256: ${declared:-<empty>}" >&2
    return 2
  }
  expected=$(printf '%s' "${declared#sha256-}" | base64 -d | od -An -tx1 -v | tr -d ' \n')
  [[ -n "$expected" && "$measured" == "$expected" ]] || {
    echo "$label archive differs from declared fixed hash" >&2
    return 2
  }
}

# The producer records process identities, never grants authority. The existing live owner
# independently checks the resulting receipt before every capture-side mutation/readback.
process_identity() {
  local pid=$1 value fields
  [[ "$pid" =~ ^[0-9]+$ && -r "/proc/$pid/stat" ]] || {
    echo "Receipt process $pid is not live" >&2; return 2;
  }
  value=$(cat "/proc/$pid/stat")
  read -ra fields <<< "${value##*) }"
  [[ "${fields[19]:-}" =~ ^[0-9]+$ && "${fields[4]:-}" =~ ^-?[0-9]+$ ]] || {
    echo "Receipt process $pid has invalid start ticks or tty" >&2; return 2;
  }
  jq -n --argjson pid "$pid" --arg ticks "${fields[19]}" --argjson tty "$((fields[4] & 4294967295))" \
    '{pid:$pid,startTicks:$ticks,ttyRdev:$tty}'
}

mux_receipt_target() {
  local preflight=$1 shell_pid=$2 terminal_pid=$3 collector_pid=$4 mux=$5 executable=$6 version=$7 config=$8 socket=$9 session=${10}
  local shell_identity terminal_identity collector_identity executable_sha config_sha boot_id
  shell_identity=$(process_identity "$shell_pid") || return 2
  terminal_identity=$(process_identity "$terminal_pid") || return 2
  collector_identity=$(process_identity "$collector_pid") || return 2
  executable=$(readlink -f "$executable")
  executable_sha=$(sha256sum "$executable" | cut -d ' ' -f 1)
  config_sha=$(sha256sum "$config" | cut -d ' ' -f 1)
  read -r boot_id < /proc/sys/kernel/random/boot_id
  jq -n --slurpfile preflight "$preflight" --argjson shell "$shell_identity" \
    --argjson terminal "$terminal_identity" --argjson collector "$collector_identity" \
    --arg mux "$mux" --arg boot "$boot_id" --arg executable "$executable" --arg executableSha "$executable_sha" \
    --arg version "$version" --arg config "$config" --arg configSha "$config_sha" --arg socket "$socket" --arg session "$session" \
    '{kind:"mux",mux:$mux,bootId:$boot,preflightCollector:($preflight[0]|{pid,startTicks}),outerShell:$shell,
      outerTerminal:($terminal|{pid,startTicks}),collector:($collector|{pid,startTicks}),
      executable:{path:$executable,sha256:$executableSha,version:$version},
      config:{path:$config,sha256:$configSha},socketPath:$socket,session:$session}'
}

await_owned_daemon() {
  local daemon_dir=$1 app_pid=$2 previous_pid=${3:-0} socket_receipt=${4:-} files candidate mux_socket mux_state=
  for _ in $(seq 1 150); do
    files=("$daemon_dir"/*.json)
    if [[ "${#files[@]}" == 1 && -f "${files[0]}" ]]; then
      candidate=$(jq -er '.pid' "${files[0]}") || return 2
      if [[ "$candidate" != "$previous_pid" ]]; then
        jq -e --arg run "$TERMINFO_RUN_ID" '.runId == $run and (.port | type == "number") and (.token | type == "string")' \
          "${files[0]}" >/dev/null || { echo "Daemon registration has wrong run ID or invalid fields" >&2; return 2; }
        if [[ -n "$socket_receipt" ]]; then
          [[ -r "$socket_receipt" ]] && IFS= read -r mux_socket < "$socket_receipt" && [[ -n "$mux_socket" ]] || {
            echo "Owned tmux socket receipt cannot supply a socket path: $socket_receipt" >&2; return 2;
          }
          mux_state=$(tmux -S "$mux_socket" display-message -p -t "terminfo-$TERMINFO_RUN_ID" \
            '#{window_name}|#{pane_current_command}') || {
            echo "Owned tmux metadata query failed on $mux_socket for terminfo-$TERMINFO_RUN_ID" >&2; return 2;
          }
        fi
        if [[ -z "$socket_receipt" || "$mux_state" == 'bun|bun' ]]; then
          printf '%s\n' "${files[0]}"
          return 0
        fi
      fi
    fi
    kill -0 "$app_pid" 2>/dev/null || { echo "Owned terminal exited before collector registration" >&2; return 2; }
    sleep 0.1
  done
  if [[ -n "$socket_receipt" && -n "$mux_state" ]]; then
    echo "Owned tmux on $mux_socket did not reach bun|bun in collector readiness: $mux_state" >&2
  else
    echo "Expected exactly one live owned collector registration, different from $previous_pid" >&2
  fi
  return 2
}

# A mux profile is a documented user option of the multiplexer, measured as a context supplement (#33151, @cto
# 918fccd1 rule 2). Prints the subject.config the run records for MUX and PROFILE: the default is the empty-config
# path every default mux run records; Screen truecolor names exactly what its config file says. Any other pair is
# refused by name. docs/data/context-supplements.ts holds the same two values; the launcher test keeps them equal.
mux_profile_config() {
  local mux=$1 profile=$2
  case "$profile" in
    default) printf '%s\n' /out/mux-empty.conf ;;
    truecolor)
      if [[ "$mux" != screen ]]; then
        echo "mux profile $profile has no declared option on mux ${mux:-(none)}" >&2
        return 2
      fi
      printf '%s\n' 'screen: defscrollback 1000; truecolor on'
      ;;
    *) echo "Unknown mux profile $profile on mux ${mux:-(none)}" >&2; return 2 ;;
  esac
}

# The exact bytes Screen starts with for PROFILE: the unchanged default line, then truecolor's documented option
# (#33151). The mux receipt hashes this file, and the placement check (MUX_PROFILE_CONFIG_FILES in
# disposable-receipt.ts) accepts a profile's recorded config only when that hash matches these bytes; the launcher
# test keeps the two equal.
screen_config_content() {
  printf 'defscrollback 1000\n'
  if [[ "$1" == truecolor ]]; then printf 'truecolor on\n'; fi
}

# xterm's default paste is Shift+Insert from PRIMARY (charproc.c:15024, #32164). A translations,
# selectToClipboard or insert-selection resource anywhere on its command line could rebind it, so the
# launcher refuses one. Prints the first such argument and succeeds; fails when there is none.
xterm_paste_rebinding_arg() {
  local arg
  for arg in "$@"; do
    if [[ "$arg" =~ [Tt]ranslations|selectToClipboard|insert-selection ]]; then
      printf '%s\n' "$arg"
      return 0
    fi
  done
  return 1
}

# The launcher uses this same function after Docker exits. Shell-level checks
# can source it with owned temporary receipts without starting an image.
if [[ "${BASH_SOURCE[0]}" != "$0" ]]; then
  return 0
fi

if [[ "${1:-}" == "--mux-inner" ]]; then
  unset TERM_PROGRAM TERM_PROGRAM_VERSION
  exec bun "$TERMINFO_RUNNER" test --serve
fi

if [[ "${1:-}" == "--mux-shell" ]]; then
  mux_output=$2
  printf '%s\n' "$$" > "$mux_output/outer-shell.pid"
  bun "$TERMINFO_RUNNER" test --serve <&0 2>"$mux_output/preflight-collector.stderr" &
  preflight_pid=$!
  preflight_status=0
  wait "$preflight_pid" || preflight_status=$?
  [[ "$preflight_status" == 0 || "$preflight_status" == 143 ]] || {
    echo "Outer preflight collector failed: $preflight_status" >&2; exit "$preflight_status";
  }
  mux_session="terminfo-$TERMINFO_RUN_ID"
  mux_config="$mux_output/mux-empty.conf"
  : > "$mux_config"
  chmod 600 "$mux_config"
  case "$TERMINFO_MUX_KIND" in
    tmux)
      unset TERM_PROGRAM TERM_PROGRAM_VERSION
      mux_socket="$HOME/$mux_session.sock"
      printf '%s\n' "$mux_socket" > "$mux_output/mux-socket.txt"
      tmux -D -S "$mux_socket" -f "$mux_config" </dev/null >"$mux_output/mux-server.log" 2>&1 &
      mux_server=$!
      for _ in $(seq 1 100); do
        [[ -S "$mux_socket" ]] && break
        kill -0 "$mux_server" || { echo "Owned tmux server exited" >&2; exit 2; }
        sleep 0.05
      done
      [[ -S "$mux_socket" ]] || { echo "Owned tmux socket was not created" >&2; exit 2; }
      # Start the final collector command before tmux names the window for raster calibration.
      tmux -S "$mux_socket" new-session -s "$mux_session" bun "$TERMINFO_RUNNER" test --serve
      tmux -S "$mux_socket" kill-server
      wait "$mux_server"
      ;;
    screen)
      screen_config_content "${TERMINFO_MUX_PROFILE:-default}" > "$mux_config"
      export SCREENDIR="$HOME/.screen"
      mkdir -m 700 "$SCREENDIR"
      screen -S "$mux_session" -c "$mux_config" bash "$0" --mux-inner
      ;;
    *) echo "Unknown owned multiplexer: $TERMINFO_MUX_KIND" >&2; exit 2 ;;
  esac
  exit 0
fi

if [[ "${1:-}" == "--inside" ]]; then
  shift
  [[ -n "${TERMINFO_RUN_ID:-}" && -n "${TERMINFO_RUNNER:-}" && -n "${TERMINFO_TARGET_ID:-}" &&
     -n "${TERMINFO_TARGET_BINARY:-}" && -n "${TERMINFO_TARGET_VERSION:-}" &&
     -n "${TERMINFO_TARGET_PRESET:-}" && -n "${TERMINFO_CLIPBOARD_PROFILE:-}" ]] || {
    echo "Missing run, runner, target, preset, or clipboard profile metadata" >&2
    exit 2
  }
  [[ "$(id -u)" != 0 ]] || { echo "Refusing root container user" >&2; exit 2; }
  [[ -r /out/host-measured.json && -w /out ]] || { echo "Missing writable single-run output mount" >&2; exit 2; }
  [[ "$TERMINFO_RUN_ID" == "$(jq -er .runId /out/host-measured.json)" ]] || {
    echo "Container run ID disagrees with host receipt" >&2
    exit 2
  }
  [[ "${TERMINFO_IMAGE_ID:-}" == "$(jq -er .runtime.imageId /out/host-measured.json)" ]] || {
    echo "Loaded image ID disagrees with host receipt" >&2
    exit 2
  }

  # Per-target descriptor (27874 launcher-target-family, @cto 1100603): ONE launcher mechanism, with
  # each app's command shape, version probe and XTVERSION answer named here by the image's own id.
  # The host passes these uniformly; the image's labels are the same values.
  target_id=$TERMINFO_TARGET_ID
  target_binary=$TERMINFO_TARGET_BINARY
  target_version=$TERMINFO_TARGET_VERSION
  target_preset=$TERMINFO_TARGET_PRESET
  target_source_url=${TERMINFO_TARGET_SOURCE_URL:-}
  target_source_sri=${TERMINFO_TARGET_SOURCE_SRI:-}
  target_source_archive=${TERMINFO_TARGET_SOURCE_ARCHIVE:-}
  target_source_kind=${TERMINFO_TARGET_SOURCE_KIND:-}
  target_source_nar_sri=${TERMINFO_TARGET_SOURCE_NAR_SRI:-}
  target_source_revision=${TERMINFO_TARGET_SOURCE_REVISION:-}
  target_launch_args=()
  target_command_lead=()
  target_clipboard_args=()
  # The rendering pin this target launches under, recorded in observed.json beside the locale and the
  # decoding (28752) so a run's context STATES it and an old run is told apart from a new one. Empty
  # means the terminal renders as it ships. (#28829)
  target_render_pin=
  target_xtversion_mode=
  target_xtversion_expect=
  # Pure bash: the image's runtime tools are a measured set and an unlisted dependency is a
  # missing tool, not an assumption to make (@cto 1100603 named no new tool).
  parse_version() {
    local line
    IFS= read -r line
    printf '%s\n' "${line##* }"
  }
  case "$target_id" in
    kitty)
      target_launch_args=(--config NONE --class "terminfo-$target_id-container-daemon"
        -o remember_window_size=no -o initial_window_width=800 -o initial_window_height=600
        -o 'font_family=JetBrains Mono' -o font_size=16
        -o allow_remote_control=socket-only --listen-on "unix:/out/kitty-${TERMINFO_RUN_ID}.sock")
      # Retain commands received by the outer Kitty in the existing daemon.log.
      if [[ -n "${TERMINFO_MUX_KIND:-}" ]]; then
        target_launch_args+=(--dump-commands)
      fi
      # kitty --version prints one line, "kitty 0.49.2 created by Kovid Goyal": the version is the
      # SECOND word, so the default last-word parse would read "Goyal" and refuse the run (27929 D1).
      parse_version() {
        local line
        IFS= read -r line
        line=${line#kitty }
        printf '%s\n' "${line%% *}"
      }
      target_xtversion_mode=require
      target_xtversion_expect="kitty($target_version)"
      ;;
    xterm)
      # `-u8` is this terminal's declared UTF-8 mode (it implies wide characters), and it cannot stand
      # in for a locale: MEASURED on xterm 411 (2026-10-13), `-u8` under LC_ALL=C still advanced the
      # cursor TWO cells for a two-byte character (ISO-8859-1), while under LC_ALL=C.UTF-8 it advanced
      # ONE. The LOCALE is the load-bearing pin; the flag is the declaration beside it. Without that
      # locale the plain-written expected frame of a charsets row painted a DIFFERENT string from the
      # claim ("q" + U+2500 + "q" became "q" + U+00E2 + "q"), so the row could never match (#28752),
      # and a run now MEASURES the decoding it got (collector.utf8Decoding) instead of assuming the
      # pin took.
      # Rendering is PINNED so that a repaint is byte-exact (#28829). With Xft antialiasing on, a
      # plainly painted frame carries one extra partial-coverage edge pixel relative to the same
      # frame reached by an edit sequence, so the exact-digest oracle reads a one-pixel residual
      # and cannot classify the row (xterm/linux editing.decdc, editing.decic, editing.sl). Turning
      # antialiasing off makes the target frame byte-identical to the expected frame — measured
      # locally on xterm 411 + DejaVu Sans Mono 16 at window 1304x814: AA on 1 px differing at
      # (28,76), AA off 0 px. Exact equality only: no tolerance, no similarity (CTO ruling #28752).
      target_launch_args=(-name "terminfo-$target_id-container-daemon" -u8 -fa 'DejaVu Sans Mono'
        -fs 16 -geometry 100x30 -xrm 'Xft.antialias: false')
      target_command_lead=(-e)
      target_render_pin=xft-antialias-off
      parse_version() {
        local line
        IFS= read -r line
        line=${line#XTerm(}
        printf '%s\n' "${line%)}"
      }
      # Measured 2026-10-07 in xterm-visual-default-image: XTVERSION "XTerm(411)", DA1 "?64;...".
      target_xtversion_mode=require
      target_xtversion_expect="XTerm($target_version)"
      ;;
    ghostty)
      # A forced --title ignores application title sequences, including OSC 7's title fallback.
      # The existing PID/window ownership receipt identifies the window without overriding its title.
      target_launch_args=(--font-family='JetBrains Mono' --font-size=16 --window-decoration=none)
      target_command_lead=(-e)
      # Measured 2026-10-07 in ghostty-visual-default-image: XTVERSION "ghostty 1.3.1", DA1 "?62;...".
      target_xtversion_mode=require
      target_xtversion_expect="ghostty $target_version"
      ;;
    wezterm)
      # --config-file is a Lua chunk: /dev/null returns nil, which wezterm reports as a
      # "Configuration Error" and renders as a second owned window. One empty table is a valid
      # config with nothing in it. Measured 2026-10-07 in wezterm-visual-default-image:
      # --config-file /dev/null -> 2 visible owned windows, `return {}` -> exactly 1. (27892)
      printf 'return {}\n' > "$HOME/wezterm-config.lua"
      target_launch_args=(--config-file "$HOME/wezterm-config.lua" --config log_unknown_escape_sequences=true)
      target_command_lead=(start --)
      # Measured 2026-10-07: with libglvnd on LD_LIBRARY_PATH and __EGL_VENDOR_LIBRARY_DIRS pointing
      # at mesa's egl_vendor.d the image opens exactly one owned window under software EGL, so the
      # raw XTVERSION answer is recorded and named; promoted to require/forbid once its exact
      # expected answer is measured through the apparatus. (27874)
      target_xtversion_mode=record
      ;;
    alacritty)
      target_launch_args=(--option 'font.normal.family="JetBrains Mono"')
      target_command_lead=(-e)
      # Measured 2026-10-07: alacritty resolves the run user from USER/HOME/SHELL before its passwd
      # fallback, and refuses with `pw not found` only when that lookup fails. No passwd entry for
      # the run uid exists in the image - the image's own baked entry is gone - so the LAUNCHER
      # generates one and mounts it read-only (see the run-user block below). The raw XTVERSION
      # answer is recorded and named; promoted to require/forbid once its exact expected answer is
      # measured through the apparatus. (27874)
      target_xtversion_mode=record
      ;;
    *) echo "Unknown target id: $target_id" >&2; exit 2 ;;
  esac

  case "$TERMINFO_CLIPBOARD_PROFILE" in
    default)
      clipboard_permissions='clipboard: read=ask,write=allow; OSC52: write=run,read=not-run'
      ;;
    allow)
      # Each terminal's own read-allowed setting, read from its pinned version (issue 33119, @cto 53ee5175). The same
      # args are CLIPBOARD_ALLOW_ARGS in packages/terminfo.dev/src/linux-clipboard.ts, which re-reads the live argv;
      # clipboard-allow-args.test.ts keeps the two equal. WezTerm has no such setting: it runs as it is, with the
      # fixture, and its result is measured, never declared.
      case "$target_id" in
        kitty) target_clipboard_args=(-o 'clipboard_control=write-clipboard read-clipboard') ;;
        ghostty) target_clipboard_args=('--clipboard-read=allow') ;;
        alacritty) target_clipboard_args=(-o 'terminal.osc52="CopyPaste"') ;;
        xterm) target_clipboard_args=(-xrm '*disallowedWindowOps: GetChecksum,GetIconTitle,GetWinTitle,SetXprop') ;;
        wezterm) target_clipboard_args=() ;;
        *)
          echo "$target_id: clipboard profile allow has no declared control on this target" >&2
          exit 2
          ;;
      esac
      if [[ "$target_id" == wezterm ]]; then
        clipboard_permissions='clipboard: read=no-setting,write=allow'
      else
        clipboard_permissions='clipboard: read=allow,write=allow'
      fi
      ;;
    deny-read)
      if [[ "$target_id" != kitty ]]; then
        echo "$target_id: clipboard profile $TERMINFO_CLIPBOARD_PROFILE has no declared control on this target" >&2
        exit 2
      fi
      target_clipboard_args=(-o 'clipboard_control=write-clipboard')
      clipboard_permissions='clipboard: read=deny,write=allow'
      ;;
    *) echo "Unknown clipboard profile: $TERMINFO_CLIPBOARD_PROFILE" >&2; exit 2 ;;
  esac

  validate_host_metadata /out/host-measured.json
  [[ -d "$HOME" && -w "$HOME" ]] || { echo "HOME is not a writable private tmpfs" >&2; exit 2; }

  bun "$TERMINFO_RUNNER" --help >/out/import-smoke.txt 2>/out/import-smoke.err || {
    echo "Frozen runner import smoke failed" >&2
    cat /out/import-smoke.err >&2
    exit 2
  }
  selected_ids=${TERMINFO_PROBE_IDS-null}
  jq -e --argjson ids "$selected_ids" '(.selectedIDs // null) == $ids' /out/host-measured.json >/dev/null || {
    echo "Container probe selection disagrees with host receipt" >&2; exit 2;
  }
  runner_dir=$(dirname "$TERMINFO_RUNNER")
  build_receipt="$runner_dir/terminfo.bundle.receipt.json"
  [[ -r "$build_receipt" ]] || { echo "Frozen CLI build receipt is missing" >&2; exit 2; }
  runner_sha=$(sha256sum "$TERMINFO_RUNNER" | cut -d ' ' -f 1)
  receipt_sha=$(sha256sum "$build_receipt" | cut -d ' ' -f 1)
  jq -e --arg runner "$runner_sha" --arg receipt "$receipt_sha" \
    '.runnerArtifact.frozenRunnerSha256 == $runner and .runnerArtifact.buildReceiptSha256 == $receipt and
     .runnerArtifact.build.probeHash == .runtime.suiteHash and
     .runnerArtifact.build.collectorRevision == .runtime.sourceRevision' \
    /out/host-measured.json >/dev/null || {
    echo "Frozen collector differs from host build receipt" >&2; exit 2;
  }
  # This is the declared invocation. Nixpkgs may wrap it and exec another ELF.
  sha256sum "$target_binary" | tee /out/invocation.sha256
  case "$target_source_archive" in
    "")
      echo "$target_id: no source archive; source proof unavailable" >&2
      exit 2
      ;;
  esac
  # The proof is NAMED by its kind (@cto 2026-10-06, 27892): absent means the flat upstream archive at
  # url; "derived-source-tree" means a tar built from the upstream tree, which must also carry the tree
  # hash nix pinned and the revision it came from. An unknown kind, or a derived tree without them, is
  # refused by name rather than described with a plausible source.
  case "$target_source_kind" in
    ""|derived-source-tree) ;;
    *) echo "$target_id: unknown source proof kind $target_source_kind" >&2; exit 2 ;;
  esac
  if [[ "$target_source_kind" == derived-source-tree ]]; then
    [[ "$target_source_nar_sri" == sha256-* && -n "$target_source_revision" ]] || {
      echo "$target_id: derived source tree lacks a pinned revision or tree hash; source proof unavailable" >&2
      exit 2
    }
  fi
  sha256sum "$target_source_archive" | tee /out/source-archive.sha256
  read -r source_sha source_path < /out/source-archive.sha256
  verify_source_archive_hash "$source_sha" "$target_source_sri" "Loaded $target_id source" || exit 2
  case "$target_id" in
    xterm) "$target_binary" -version ;;
    *) "$target_binary" --version ;;
  esac 2>/dev/null | tee /out/executable-version.txt
  actual_version=$(parse_version < /out/executable-version.txt)
  [[ "$actual_version" == "$target_version" ]] || {
    echo "Loaded $target_id version $actual_version is not declared $target_version" >&2
    exit 2
  }
  # The receipts record the version the executable REPORTS, never a whole build report: ghostty
  # answers --version with a multi-line report naming its Zig, GTK and libadwaita versions, and the
  # run parser admits exactly ONE version token equal to target.version, so a report carrying
  # several numbers is refused by name. The line kept is the one parse_version reads, and the full
  # report stays in /out/executable-version.txt and in the app's own daemon log.
  executable_version=$(head -n 1 /out/executable-version.txt)
  case "$target_id" in
    kitty|ghostty|alacritty) prepare_font_control /out 'JetBrains Mono' "${target_launch_args[@]}" ;;
    *) fc-match -f '%{family} | %{file}\n' 'DejaVu Sans Mono' > /out/font.txt ;;
  esac

  xvfb_pid=
  focus_helper_pid=
  helper_pid=
  session_bus_pid=
  notify_recorder_pid=
  primary_helper_pid=
  daemon_pid=
  collector_pid=
  cleanup() {
    local status=$?
    trap - EXIT
    stop_owned_processes "$daemon_pid" "$focus_helper_pid" "$helper_pid" "$primary_helper_pid" "$notify_recorder_pid" "$xvfb_pid" "$collector_pid"
    # The bus stops after its recorder, so a recorder stopped by SIGTERM never reads a closed bus as fatal.
    stop_owned_processes "$session_bus_pid"
    exit "$status"
  }
  trap cleanup EXIT

  # xterm 411 -fs 16 -geometry 100x30 measures 1304x814. 1024x768 clips xwd to
  # 1024x768x4 = 3145728 bytes, which 28580 read as a 3 MiB capture buffer.
  Xvfb -displayfd 3 -screen 0 1920x1080x24 +extension GLX +extension XTEST +render -noreset -nolisten tcp \
    3>"$HOME/display-number" >/out/xvfb.log 2>&1 &
  xvfb_pid=$!
  for _ in $(seq 1 100); do
    [[ -s "$HOME/display-number" ]] && break
    kill -0 "$xvfb_pid" 2>/dev/null || { cat /out/xvfb.log >&2; exit 2; }
    sleep 0.1
  done
  [[ -s "$HOME/display-number" ]] || { echo "Xvfb display allocation timed out" >&2; exit 2; }
  chmod 600 "$HOME/display-number"
  read -r display_number <"$HOME/display-number"
  export DISPLAY=":$display_number"
  export XDG_CACHE_HOME="$HOME/.cache"
  xdpyinfo > /out/xdpyinfo.txt
  grep -Eiq '(^|[[:space:]])XTEST([[:space:]]|$)' /out/xdpyinfo.txt || {
    echo "DISPLAY lacks the XTEST extension; start Xvfb with +extension XTEST" >&2
    exit 2
  }
  glxinfo -B > /out/glxinfo.txt
  grep -Eiq 'llvmpipe' /out/glxinfo.txt || {
    echo "GL renderer is not llvmpipe; run invalid" >&2
    exit 2
  }

  # The focus witness needs a second window (#33305): a GTK terminal reports no focus change when
  # focus moves to the display root, so the arm moves focus to this owned helper and back. It is
  # mapped here, before the app under test, in the bottom-right corner of the screen, and it dies
  # with the display. Its pid and window id are in the receipt, and the input adapter refuses the
  # run if its rectangle ever intersects the owned window's.
  focus_helper_pid=
  focus_helper_window=
  focus_helper_geometry=
  xterm -geometry 20x3-0-0 -e sleep 36000 > /out/focus-helper.log 2>&1 &
  focus_helper_pid=$!
  for _ in $(seq 1 100); do
    kill -0 "$focus_helper_pid" 2>/dev/null || {
      echo "Owned focus helper exited before it mapped" >&2
      cat /out/focus-helper.log >&2
      exit 2
    }
    # `xdotool search` exits 1 until the window exists; under `set -e` a bare assignment from that
    # pipeline killed the run on its first attempt (33305 App run 2026-11-11T05-48Z, exit 1 with an
    # empty helper log). The loop is the wait: swallow "not mapped yet" and let it retry.
    focus_helper_window=$(xdotool search --onlyvisible --pid "$focus_helper_pid" 2>/dev/null | tail -n 1 || true)
    [[ -n "$focus_helper_window" ]] && break
    sleep 0.1
  done
  if [[ -z "$focus_helper_window" ]]; then
    echo "Owned focus helper window never mapped; the focus witness has no second window" >&2
    cat /out/focus-helper.log >&2
    exit 2
  fi
  focus_helper_geometry=$(xdotool getwindowgeometry "$focus_helper_window" | tr '\n' ' ')
  chmod 600 /out/focus-helper.log
  export TERMINFO_FOCUS_HELPER_WINDOW="$focus_helper_window"
  export TERMINFO_FOCUS_HELPER_PID="$focus_helper_pid"

  baseline_path="$HOME/clipboard-baseline.txt"
  printf 'terminfo-owned-clipboard-%s' "$TERMINFO_RUN_ID" > "$baseline_path"
  chmod 600 "$baseline_path"
  baseline_sha=$(sha256sum "$baseline_path" | cut -d ' ' -f 1)
  xclip_binary=$(readlink -f "$(command -v xclip)")
  xclip_sha=$(sha256sum "$xclip_binary" | cut -d ' ' -f 1)
  xclip -quiet -selection clipboard -in "$baseline_path" </dev/null >/out/xclip-owner.log 2>&1 &
  helper_pid=$!
  for _ in $(seq 1 100); do
    kill -0 "$helper_pid" 2>/dev/null || { cat /out/xclip-owner.log >&2; exit 2; }
    if timeout 1 xclip -selection clipboard -out > "$HOME/clipboard-initial-read.txt" 2>/out/xclip-initial-read.err &&
       cmp -s "$baseline_path" "$HOME/clipboard-initial-read.txt"; then
      break
    fi
    sleep 0.1
  done
  [[ -r "$HOME/clipboard-initial-read.txt" &&
     "$(sha256sum "$HOME/clipboard-initial-read.txt" | cut -d ' ' -f 1)" == "$baseline_sha" ]] || {
    echo "Owned xclip baseline did not survive independent clipboard read" >&2
    cat /out/xclip-owner.log /out/xclip-initial-read.err >&2
    exit 2
  }
  initial_read_sha=$(sha256sum "$HOME/clipboard-initial-read.txt" | cut -d ' ' -f 1)

  # One private session bus per run (#33053, @cto c6ba9dbb + 7b8360fe): this run starts and stops it as a child,
  # and the Notify recorder holds org.freedesktop.Notifications and writes its receipt BEFORE the terminal starts.
  # The config is named explicitly from the loaded dbus package: Nixpkgs' `dbus-daemon --session` reads the compiled
  # path /etc/dbus-1/session.conf, outside the package. The terminal inherits DBUS_SESSION_BUS_ADDRESS, which the collector records as
  # collector.sessionBus (readSessionBus, app-semantic-state.ts).
  session_bus_socket=/tmp/terminfo-session-bus
  session_bus_binary=$(readlink -f "$(command -v dbus-daemon)")
  session_bus_config="${session_bus_binary%/bin/dbus-daemon}/share/dbus-1/session.conf"
  [[ -r "$session_bus_config" ]] || {
    echo "dbus-daemon $session_bus_binary has no session config at $session_bus_config" >&2; exit 2;
  }
  [[ ! -e "$session_bus_socket" ]] || {
    echo "Session bus socket $session_bus_socket already exists; this run did not start it" >&2; exit 2;
  }
  "$session_bus_binary" --config-file="$session_bus_config" --nofork --address="unix:path=$session_bus_socket" \
    --print-address=3 3>"$HOME/session-bus-address" </dev/null >/out/dbus-daemon.log 2>&1 &
  session_bus_pid=$!
  for _ in $(seq 1 100); do
    [[ -s "$HOME/session-bus-address" && -z "$(tail -c 1 "$HOME/session-bus-address")" ]] && break
    kill -0 "$session_bus_pid" 2>/dev/null || {
      echo "dbus-daemon exited before printing its address" >&2; cat /out/dbus-daemon.log >&2; exit 2;
    }
    sleep 0.1
  done
  [[ -s "$HOME/session-bus-address" && -z "$(tail -c 1 "$HOME/session-bus-address")" ]] || {
    echo "dbus-daemon did not print its address within 10s" >&2; cat /out/dbus-daemon.log >&2; exit 2;
  }
  read -r session_bus_address <"$HOME/session-bus-address"
  [[ "$session_bus_address" == "unix:path=$session_bus_socket,"* ]] || {
    echo "dbus-daemon printed $session_bus_address, not the requested unix:path=$session_bus_socket" >&2; exit 2;
  }
  notify_recorder="$runner_dir/linux-notify-recorder.ts"
  [[ -r "$notify_recorder" ]] || { echo "Frozen runner lacks the Notify recorder $notify_recorder" >&2; exit 2; }
  notification_record=/out/notifications.jsonl
  export TERMINFO_NOTIFICATION_FIXTURE_RECEIPT=/out/notification-fixture.json
  [[ ! -e "$notification_record" && ! -e "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" ]] || {
    echo "Notify record or receipt already exists before this run's recorder started" >&2; exit 2;
  }
  bun --no-env-file "$notify_recorder" --address "$session_bus_address" --record "$notification_record" \
    --receipt "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" </dev/null >/out/notify-recorder.log 2>&1 &
  notify_recorder_pid=$!
  for _ in $(seq 1 100); do
    [[ -s "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" ]] && break
    kill -0 "$notify_recorder_pid" 2>/dev/null || {
      echo "Notify recorder exited before holding org.freedesktop.Notifications" >&2
      cat /out/notify-recorder.log >&2
      exit 2
    }
    sleep 0.1
  done
  [[ -s "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" ]] || {
    echo "Notify recorder wrote no receipt within 10s; the terminal is not started" >&2
    cat /out/notify-recorder.log >&2
    exit 2
  }
  jq -e --arg address "$session_bus_address" --argjson pid "$notify_recorder_pid" --arg record "$notification_record" \
    '.schema == "terminfo-notify-recorder-receipt/1" and .owned == true and
     .name == "org.freedesktop.Notifications" and .address == $address and .pid == $pid and .recordPath == $record' \
    "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" >/dev/null || {
    echo "Notify recorder receipt does not name this run's bus, recorder PID and record" >&2
    cat "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" >&2
    exit 2
  }
  export DBUS_SESSION_BUS_ADDRESS="$session_bus_address"
  # Written here, before the terminal launch below: the name is held and the receipt verified, so the record says so.
  jq -n --arg run "$TERMINFO_RUN_ID" --arg address "$session_bus_address" --arg verifiedAt "$(date -u +%FT%T.%3NZ)" \
    --argjson daemonPid "$session_bus_pid" --arg daemonPath "$session_bus_binary" \
    --arg daemonSha "$(sha256sum "$session_bus_binary" | cut -d ' ' -f 1)" \
    --arg configPath "$session_bus_config" --arg configSha "$(sha256sum "$session_bus_config" | cut -d ' ' -f 1)" \
    --argjson recorderPid "$notify_recorder_pid" --arg recorderPath "$notify_recorder" \
    --arg recorderSha "$(sha256sum "$notify_recorder" | cut -d ' ' -f 1)" \
    --arg receiptPath "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" \
    --arg receiptSha "$(sha256sum "$TERMINFO_NOTIFICATION_FIXTURE_RECEIPT" | cut -d ' ' -f 1)" \
    --arg record "$notification_record" \
    '{schemaVersion:1,runId:$run,address:$address,
      daemon:{pid:$daemonPid,executable:{path:$daemonPath,sha256:$daemonSha},config:{path:$configPath,sha256:$configSha}},
      recorder:{pid:$recorderPid,script:{path:$recorderPath,sha256:$recorderSha},
        receipt:{path:$receiptPath,sha256:$receiptSha},record:$record},
      nameHeldBeforeTerminal:true,verifiedAt:$verifiedAt}' > /out/session-bus.json
  chmod 600 /out/session-bus.json

  # xterm's default paste (Shift+Insert) reads X11 PRIMARY, not CLIPBOARD (#32164, @cto a4ec8fe2), so an
  # xterm run also owns a PRIMARY baseline; every other target owns CLIPBOARD alone. The route is believed
  # only while nothing rebinds it: the launch must carry no translation or selectToClipboard resource, and
  # the display, environment and private HOME no resource database. Refused, never recorded and continued.
  primary_receipt=null
  if [[ "$target_id" == xterm ]]; then
    # Every argument xterm is launched with: its own and the clipboard profile's (33119's read-allowed -xrm).
    if rebinding=$(xterm_paste_rebinding_arg "${target_launch_args[@]}" "${target_clipboard_args[@]}"); then
      echo "xterm launch argument rebinds paste: $rebinding" >&2
      exit 2
    fi
    resource_manager=$(xprop -root RESOURCE_MANAGER 2>&1)
    [[ "$resource_manager" == "RESOURCE_MANAGER:  not found." ]] || {
      echo "Owned display carries a resource database: $resource_manager" >&2
      exit 2
    }
    for name in XENVIRONMENT XAPPLRESDIR XUSERFILESEARCHPATH XFILESEARCHPATH; do
      [[ -z "${!name:-}" ]] || { echo "xterm resource search variable is set: $name" >&2; exit 2; }
    done
    for file in "$HOME/.Xdefaults" "$HOME/.Xresources" "$HOME/.Xdefaults-$(uname -n)"; do
      [[ ! -e "$file" ]] || { echo "Private HOME carries an X resource file: $file" >&2; exit 2; }
    done
    primary_path="$HOME/primary-baseline.txt"
    printf 'terminfo-owned-primary-%s' "$TERMINFO_RUN_ID" > "$primary_path"
    chmod 600 "$primary_path"
    primary_sha=$(sha256sum "$primary_path" | cut -d ' ' -f 1)
    xclip -quiet -selection primary -in "$primary_path" </dev/null >/out/xclip-primary-owner.log 2>&1 &
    primary_helper_pid=$!
    for _ in $(seq 1 100); do
      kill -0 "$primary_helper_pid" 2>/dev/null || { cat /out/xclip-primary-owner.log >&2; exit 2; }
      if timeout 1 xclip -selection primary -out > "$HOME/primary-initial-read.txt" 2>/out/xclip-primary-read.err &&
         cmp -s "$primary_path" "$HOME/primary-initial-read.txt"; then
        break
      fi
      sleep 0.1
    done
    [[ -r "$HOME/primary-initial-read.txt" &&
       "$(sha256sum "$HOME/primary-initial-read.txt" | cut -d ' ' -f 1)" == "$primary_sha" ]] || {
      echo "Owned xclip PRIMARY baseline did not survive independent selection read" >&2
      cat /out/xclip-primary-owner.log /out/xclip-primary-read.err >&2
      exit 2
    }
    primary_receipt=$(jq -n --argjson helperPid "$primary_helper_pid" --arg baselinePath "$primary_path" \
      --arg baselineSha "$primary_sha" \
      --arg initialSha "$(sha256sum "$HOME/primary-initial-read.txt" | cut -d ' ' -f 1)" \
      '{helperPid:$helperPid,baselinePath:$baselinePath,baselineSha256:$baselineSha,initialReadSha256:$initialSha}')
  fi

  export TERMINFO_CAPTURE_DIRECTORY=/out/artifacts
  export TERMINFO_RUNTIME_PROVENANCE=/out/runtime-provenance.json
  export TERMINFO_CLIPBOARD_FIXTURE_RECEIPT=/out/clipboard-fixture.json
  collector_command=(bun --no-env-file "$TERMINFO_RUNNER" test --serve)
  if [[ -n "${TERMINFO_MUX_KIND:-}" ]]; then
    [[ "$target_id" == kitty ]] || { echo "Owned Linux mux outer must be Kitty" >&2; exit 2; }
    case "$TERMINFO_MUX_KIND" in tmux|screen) ;; *) echo "Unknown owned multiplexer: $TERMINFO_MUX_KIND" >&2; exit 2 ;; esac
    export TERMINFO_OUTER_COLOUR_RECORD=/out/outer-colour-record.json
    collector_command=(bash "$runner_dir/linux-container-run.sh" --mux-shell /out)
  fi
  # The declared invocation: what the descriptor table launches, exactly and uniformly.
  printf -v target_config '%q ' nice -n 10 "$target_binary" "${target_launch_args[@]}" \
    "${target_clipboard_args[@]}" "${target_command_lead[@]}" "${collector_command[@]}"
  if [[ "$target_id" == wezterm ]]; then
    printf '%s\n' "$target_config" > /out/target-config.txt
    # A missing measurement invalidates the report rows through their existing reader,
    # rather than introducing another run-level launch refusal.
    if ! sha256sum "${target_binary%/*}/wezterm-gui" > /out/owner-executable.sha256 2> /out/owner-executable.stderr; then
      echo "WezTerm prelaunch owner digest unavailable; report rows remain invalid" >&2
    fi
  fi
  unset TERM_FEATURES
  export TERMINFO_TERM_FEATURES_LAUNCH="$TERMINFO_RUN_ID"
  nice -n 10 "$target_binary" "${target_launch_args[@]}" "${target_clipboard_args[@]}" "${target_command_lead[@]}" \
    "${collector_command[@]}" >/out/daemon.log 2>&1 &
  daemon_pid=$!
  daemon_dir="$HOME/.terminfo-dev/daemons"
  daemon_file=$(await_owned_daemon "$daemon_dir" "$daemon_pid") || { cat /out/daemon.log >&2; exit 2; }
  jq 'del(.token)' "$daemon_file" > /out/daemon-registration.json
  port=$(jq -er .port /out/daemon-registration.json)
  token=$(jq -er .token "$daemon_file")
  curl --fail-with-body --silent --show-error "http://127.0.0.1:$port/info" > /out/info.json
  jq -e --arg run "$TERMINFO_RUN_ID" '.runId == $run' /out/info.json >/dev/null || {
    echo "Daemon info has wrong run ID" >&2; exit 2;
  }
  jq -n --arg write "$(printf '\033[c')" --arg read '\x1b\[\?[0-9;]*c' \
    '{commands:[{write:$write,read:$read,timeout:2000}]}' >"$HOME/query.json"
  curl --fail-with-body --silent --show-error -H "Authorization: Bearer $token" \
    -H 'Content-Type: application/json' --data-binary @"$HOME/query.json" \
    "http://127.0.0.1:$port/query" > /out/da1-observation.json
  jq -e '.results[0].response | type == "string" and length > 0' /out/da1-observation.json >/dev/null || {
    echo "DA1 query did not return a reply; run invalid" >&2; exit 2;
  }
  jq -n --arg write "$(printf '\033[>q')" --arg read '\x1bP>\|[^\x1b]*\x1b\\' \
    '{commands:[{write:$write,read:$read,timeout:2000}]}' >"$HOME/version-query.json"
  curl --fail-with-body --silent --show-error -H "Authorization: Bearer $token" \
    -H 'Content-Type: application/json' --data-binary @"$HOME/version-query.json" \
    "http://127.0.0.1:$port/query" > /out/xtversion-observation.json
  case "$target_xtversion_mode" in
    require)
      jq -e --arg expect "$target_xtversion_expect" \
        '.results[0].response | type == "string" and contains($expect)' \
        /out/xtversion-observation.json >/dev/null || {
        echo "XTVERSION did not return the measured $target_id answer $target_xtversion_expect; run invalid" >&2
        exit 2
      }
      ;;
    record)
      # The answer (or its absence) is written down and named; this target is not yet measured through
      # the apparatus, so the raw reply is evidence, not a silent skip. (27874 launcher-target-family)
      echo "$target_id: XTVERSION not yet measured; recorded reply $(jq -c '.results[0].response // null' /out/xtversion-observation.json)" >&2
      ;;
    *) echo "No XTVERSION expectation declared for $target_id" >&2; exit 2 ;;
  esac
  timeout 10 xdotool search --sync --onlyvisible --pid "$daemon_pid" > /out/windows.txt
  [[ "$(wc -l < /out/windows.txt)" == 1 ]] || { echo "Ambiguous owned probe window" >&2; exit 2; }
  read -r window_id </out/windows.txt
  [[ "$(xdotool getwindowpid "$window_id")" == "$daemon_pid" ]] || {
    echo "Probe window does not belong to the launched $target_id" >&2; exit 2;
  }
  collector_pid=$(jq -er .pid /out/daemon-registration.json)
  [[ "$collector_pid" =~ ^[0-9]+$ && -r "/proc/$collector_pid/status" ]] || {
    echo "Collector daemon registration does not identify a live process" >&2; exit 2;
  }
  window_pid=$(xdotool getwindowpid "$window_id")
  live_executable=$(readlink -f "/proc/$daemon_pid/exe")
  [[ -f "$live_executable" && -x "$live_executable" ]] || {
    echo "Owned $target_id PID has no live executable" >&2; exit 2;
  }
  live_executable_sha=$(sha256sum "/proc/$daemon_pid/exe" | cut -d ' ' -f 1)
  printf '%s  %s\n' "$live_executable_sha" "$live_executable" > /out/live-executable.sha256
  fixture_target='{"kind":"app"}'
  if [[ -n "${TERMINFO_MUX_KIND:-}" ]]; then
    # No capture-authority receipt has been issued to this preflight collector.
    process_identity "$collector_pid" | jq --arg run "$TERMINFO_RUN_ID" \
      '{pid,startTicks,launchRunId:$run}' > /out/preflight-identity.json
    preflight_pid=$collector_pid
    read -r outer_shell_pid < /out/outer-shell.pid
    kill "$preflight_pid"
    mux_socket_receipt=
    [[ "$TERMINFO_MUX_KIND" != tmux ]] || mux_socket_receipt=/out/mux-socket.txt
    daemon_file=$(await_owned_daemon "$daemon_dir" "$daemon_pid" "$preflight_pid" "$mux_socket_receipt") || {
      cat /out/daemon.log >&2; exit 2;
    }
    jq 'del(.token)' "$daemon_file" > /out/mux-daemon-registration.json
    collector_pid=$(jq -er .pid /out/mux-daemon-registration.json)
    port=$(jq -er .port /out/mux-daemon-registration.json)
    token=$(jq -er .token "$daemon_file")
    curl --fail-with-body --silent --show-error "http://127.0.0.1:$port/info" > /out/mux-info.json
    jq -e --arg run "$TERMINFO_RUN_ID" --argjson pid "$collector_pid" \
      '.runId == $run and .pid == $pid' /out/mux-info.json >/dev/null || {
      echo "Inner collector info differs from its launch registration" >&2; exit 2;
    }
    mux_executable=$(readlink -f "$(command -v "$TERMINFO_MUX_KIND")")
    mux_session="terminfo-$TERMINFO_RUN_ID"
    case "$TERMINFO_MUX_KIND" in
      tmux)
        read -r mux_socket < /out/mux-socket.txt
        "$mux_executable" -V > /out/mux-version.txt
        mux_version=$(sed -nE 's/^tmux ([0-9]+\.[0-9]+[a-z]?)$/\1/p' /out/mux-version.txt)
        ;;
      screen)
        mux_sockets=("$HOME/.screen/"*."$mux_session")
        [[ "${#mux_sockets[@]}" == 1 && -S "${mux_sockets[0]}" ]] || {
          echo "Expected one owned Screen socket" >&2; exit 2;
        }
        mux_socket=${mux_sockets[0]}
        "$mux_executable" --version > /out/mux-version.txt
        mux_version=$(sed -nE 's/^Screen version ([0-9]+\.[0-9]+\.[0-9]+).*/\1/p' /out/mux-version.txt)
        ;;
    esac
    [[ -n "$mux_version" ]] || { echo "Owned mux executable did not report its version" >&2; exit 2; }
    fixture_target=$(mux_receipt_target /out/preflight-identity.json "$outer_shell_pid" "$daemon_pid" "$collector_pid" \
      "$TERMINFO_MUX_KIND" "$mux_executable" "$mux_version" /out/mux-empty.conf "$mux_socket" "$mux_session")
  fi
  jq -n --arg run "$TERMINFO_RUN_ID" --arg profile "$TERMINFO_CLIPBOARD_PROFILE" \
    --arg display "$DISPLAY" --argjson number "$display_number" \
    --arg displayFdPath "$HOME/display-number" --argjson xvfbPid "$xvfb_pid" \
    --argjson terminalPid "$daemon_pid" --argjson collectorPid "$collector_pid" \
    --arg windowId "$window_id" --argjson windowPid "$window_pid" \
    --argjson helperPid "$helper_pid" --arg helperPath "$xclip_binary" --arg helperSha "$xclip_sha" \
    --arg baselinePath "$baseline_path" --arg baselineSha "$baseline_sha" --arg initialSha "$initial_read_sha" \
    --argjson primary "$primary_receipt" \
    --arg config "$target_config" --arg permissions "$clipboard_permissions" --argjson target "$fixture_target" \
    '{schemaVersion:1,runId:$run,profile:$profile,target:$target,
      display:{name:$display,number:$number,displayFdPath:$displayFdPath,xvfbPid:$xvfbPid},
      terminal:{pid:$terminalPid,collectorPid:$collectorPid,windowId:$windowId,windowPid:$windowPid},
      selection:{helperPid:$helperPid,helperExecutable:{path:$helperPath,sha256:$helperSha},
        baselinePath:$baselinePath,baselineSha256:$baselineSha,initialReadSha256:$initialSha}
        + (if $primary == null then {} else {primary:$primary} end),
      config:$config,permissions:$permissions}' > "$TERMINFO_CLIPBOARD_FIXTURE_RECEIPT"
  chmod 600 "$TERMINFO_CLIPBOARD_FIXTURE_RECEIPT"
  clipboard_fixture_sha=$(sha256sum "$TERMINFO_CLIPBOARD_FIXTURE_RECEIPT" | cut -d ' ' -f 1)
  xdotool getwindowgeometry --shell "$window_id" > /out/geometry.txt
  read -r source_sha source_path < /out/source-archive.sha256
  jq -n --slurpfile host /out/host-measured.json \
    --arg path "$live_executable" --arg sha "$live_executable_sha" \
    --arg version "$executable_version" --arg sourceSha "$source_sha" \
    --arg config "$target_config" \
    --rawfile font /out/font.txt --rawfile geometry /out/geometry.txt \
    --rawfile display /out/xdpyinfo.txt --rawfile gl /out/glxinfo.txt '
    $host[0] as $h | {
      executable:{path:$path,sha256:$sha,version:$version},
      sourceArtifact:({url:$h.sourceArtifact.url,sha256:$sourceSha}
        + (if ($h.sourceArtifact.kind // null) == "derived-source-tree"
           then {kind:$h.sourceArtifact.kind,narSri:$h.sourceArtifact.narSri,revision:$h.sourceArtifact.revision}
           else {} end)),
      runtime:{imageId:$h.runtime.imageId,imageTarSha256:$h.runtime.imageTarSha256,
        arch:$h.runtime.arch,nixLockRevision:$h.runtime.nixLockRevision,
        sourceRevision:$h.runtime.sourceRevision,cleanTree:($h.runtime.sourceTreeStatus == "clean"),
        suiteHash:$h.runtime.suiteHash},
      fixture:{definition:"Shared ProbeDefinition callbacks; capture checkpoints retained in each raw trace",
        config:$config,font:$font,geometry:$geometry,display:$display,gl:$gl}
    }' > "$TERMINFO_RUNTIME_PROVENANCE"
  if [[ -n "${TERMINFO_MUX_KIND:-}" ]]; then
    jq -n --slurpfile provenance "$TERMINFO_RUNTIME_PROVENANCE" --slurpfile info /out/info.json \
      --slurpfile da1 /out/da1-observation.json --slurpfile xtversion /out/xtversion-observation.json \
      --slurpfile preflight /out/preflight-identity.json --arg app "$target_id" --arg appVersion "$target_version" \
      --arg mux "$TERMINFO_MUX_KIND" --arg muxVersion "$mux_version" \
      --arg muxConfig "$(mux_profile_config "$TERMINFO_MUX_KIND" "${TERMINFO_MUX_PROFILE:-default}")" \
      --arg profile "$TERMINFO_CLIPBOARD_PROFILE" --arg permissions "$clipboard_permissions" '
      (if $profile == "default" then null else $permissions end) as $permissions |
      {subject:{kind:"mux",id:$mux,version:$muxVersion,os:$info[0].os,osVersion:$info[0].osVersion,
        outerTerminal:$app,mux:$mux,config:$muxConfig,permissions:$permissions},
       outerApp:{subject:{kind:"term",id:$app,version:$appVersion,os:$info[0].os,osVersion:$info[0].osVersion,
         outerTerminal:null,mux:null,config:$provenance[0].fixture.config,permissions:$permissions},
         rawReplies:{"device.primary-da":$da1[0].results[0].response,"collector.xtversion":$xtversion[0].results[0].response,
           "collector.preflightIdentity":($preflight[0]|tojson)},provenance:$provenance[0]}}' \
      > "$TERMINFO_RUNTIME_PROVENANCE.partial"
    mv "$TERMINFO_RUNTIME_PROVENANCE.partial" "$TERMINFO_RUNTIME_PROVENANCE"
  fi
  cat "/proc/$daemon_pid/stat" > /out/target-process-stat.txt
  date -u +%FT%TZ > /out/batch-wall-start.txt
  batch_status=0
  curl --fail-with-body --silent --show-error --max-time "$PROBE_BATCH_TIMEOUT_SECONDS" --output /out/v3-capture.json \
    --write-out '%{time_total}\n' \
    -H "Authorization: Bearer $token" "http://127.0.0.1:$port/probe" > /out/batch-elapsed-seconds.txt || batch_status=$?
  date -u +%FT%TZ > /out/batch-wall-end.txt
  [[ "$batch_status" == 0 ]] || { echo "Probe batch HTTP request failed: $batch_status" >&2; exit "$batch_status"; }
  if [[ "$selected_ids" != null ]]; then
    jq -e --argjson ids "$selected_ids" '
      (.rawReplies["collector.selection"] | fromjson | .ids | sort) == ($ids | sort)' /out/v3-capture.json >/dev/null || {
      echo "Actual native selection differs from requested IDs; original capture retained" >&2
      exit 2
    }
  fi
  jq -e --slurpfile build "$build_receipt" '
    .schemaVersion == 4 and (.runId | type == "string" and test("^[0-9a-f]{32}$")) and
    .identity == "unverified" and .origin.kind == "collector" and
    .probeHash == $build[0].probeHash and .suiteId == $build[0].probeHash and
    .sourceRevision == $build[0].collectorRevision and
    (.rawReplies | type == "object") and (.assertions | type == "array") and
    (.results | type == "array") and (has("observations") | not)' /out/v3-capture.json >/dev/null || {
    echo "Daemon returned an invalid schema-4 capture: schema, identity, origin, suite, source or collection fields disagree; raw response retained" >&2
    exit 2
  }
  jq -e --arg executablePath "$live_executable" --arg executableSha "$live_executable_sha" \
    --arg target "$target_id" --arg mux "${TERMINFO_MUX_KIND:-}" '
    if $mux == "" then .subject.kind == "term" and .subject.id == $target and
       .provenance.executable.path == $executablePath and .provenance.executable.sha256 == $executableSha
     else .subject.kind == "mux" and .subject.id == $mux and .outerApp.subject.id == $target and
       .outerApp.provenance.executable.path == $executablePath and .outerApp.provenance.executable.sha256 == $executableSha end' \
    /out/v3-capture.json >/dev/null || {
    echo "Daemon named a target other than $target_id or a different executable ($(jq -c '.subject // null' /out/v3-capture.json)); raw response retained" >&2
    exit 2
  }
  probe_run_id=$(jq -er .runId /out/v3-capture.json)
  probe_run_sha=$(sha256sum /out/v3-capture.json | cut -d ' ' -f 1)

  # The shared callbacks captured this daemon's own window during collection of the
  # run. Keep the original owned geometry in its receipt; a later window search
  # or geometry sample cannot replace the measurement recorded in provenance.
  #
  # A frame exists only when a selected probe called ctx.capture. A selection of pure queries
  # carries none, and that is a fact about the run, not a failure of it (27875): record
  # "no frame captured" and carry the run, instead of refusing it on a bare `jq -er` exit 2 that
  # named nothing. A probe that wanted a frame still fails by name in its own result, so the run's
  # results list exactly the frame-needing ids that were selected.
  capture_frame=$(jq -c '[.results[].frames[]? | select(.role == "target")][0] // null' /out/v3-capture.json)
  if [[ "$capture_frame" == null ]]; then
    echo "no frame captured: no selected probe called ctx.capture" >&2
    capture_receipt=null
  else
    # The frame is checked against the source its capture route wrote, never assumed to be an xwd
    # (33334): the shared window grab keeps an xwd source, the OSC 22 pointer-composited capture a
    # png one, and a selection of only extensions.osc22-pointer has no xwd-sourced frame at all.
    png_sha=$(jq -er '.ref | select(test("^sha256:[a-f0-9]{64}$")) | sub("^sha256:"; "")' <<<"$capture_frame")
    source_sha=$(jq -er '.sourceRef | select(test("^sha256:[a-f0-9]{64}$")) | sub("^sha256:"; "")' <<<"$capture_frame")
    if [[ -r "/out/artifacts/$source_sha.xwd" ]]; then source_kind=xwd
    elif [[ -r "/out/artifacts/$source_sha.png" ]]; then source_kind=png
    else source_kind=""; fi
    [[ -r "/out/artifacts/$png_sha.png" && -n "$source_kind" ]] || {
      echo "Callback capture artifacts are missing: frame artifacts/$png_sha.png, source artifacts/$source_sha.xwd or .png" >&2
      exit 2
    }
    source_file="artifacts/$source_sha.$source_kind"
    [[ "$(sha256sum "/out/artifacts/$png_sha.png" | cut -d ' ' -f 1)" == "$png_sha" &&
       "$(sha256sum "/out/$source_file" | cut -d ' ' -f 1)" == "$source_sha" ]] || {
      echo "Callback capture digest mismatch" >&2; exit 2;
    }
    magick identify "/out/artifacts/$png_sha.png" > /out/image-info.txt
    capture_receipt=$(jq -n --arg kind "$source_kind" --arg source "$source_file" --arg sourceSha "$source_sha" \
      --arg png "artifacts/$png_sha.png" --arg pngSha "$png_sha" \
      '(if $kind == "xwd" then {xwd:$source,xwdSha256:$sourceSha} else {sourcePng:$source,sourcePngSha256:$sourceSha} end)
        + {png:$png,pngSha256:$pngSha}')
  fi
  if compgen -G "/out/artifacts/*" >/dev/null; then
    sha256sum /out/artifacts/* > /out/capture-hashes.txt
  else
    : > /out/capture-hashes.txt
  fi
  # The decode context is a MEASURED fact, never the pin's promise (28752): the probe run records it
  # beside the other collector facts, and it is copied into the run's context here. A selection that
  # ran no plain-written row measured nothing, and a terminal that answered no cursor report is
  # silent: each state is named, rather than implying a decoding; a value that is present and
  # unparsable aborts the run instead of silently reporting the default.
  decoding=$(jq -r '(.rawReplies["collector.utf8Decoding"] // "{}") | fromjson |
    if has("decoding") then (.decoding // "silent") else "not-measured" end' /out/v3-capture.json)
  jq -n --arg run "$TERMINFO_RUN_ID" --arg probe "$probe_run_id" --argjson capture "$capture_receipt" \
    --arg decoding "$decoding" \
    --arg render "${target_render_pin:-terminal-default}" \
    '{status:"raw-unreviewed-history",runId:$run,probeRunId:$probe,capture:$capture,context:"linux-x86_64-xvfb-llvmpipe",locale:"C.UTF-8",decoding:$decoding,render:$render}' \
    > /out/observed.json
  read -r invocation_sha invocation_path < /out/invocation.sha256
  read -r source_sha source_path < /out/source-archive.sha256
  jq -n --argjson ids "$selected_ids" --arg run "$TERMINFO_RUN_ID" \
    --arg executablePath "$live_executable" --arg executableSha "$live_executable_sha" \
    --arg invocationPath "$invocation_path" --arg invocationSha "$invocation_sha" \
    --arg executableVersion "$executable_version" \
    --arg sourcePath "$source_path" --arg sourceSha "$source_sha" \
    --arg runnerSha "$runner_sha" --arg receiptSha "$receipt_sha" \
    --arg probeRun "$probe_run_id" --arg probeSha "$probe_run_sha" --argjson capture "$capture_receipt" \
    --arg profile "$TERMINFO_CLIPBOARD_PROFILE" --arg clipboardSha "$clipboard_fixture_sha" \
    --arg sessionBusSha "$(sha256sum /out/session-bus.json | cut -d ' ' -f 1)" \
    --rawfile glxinfo /out/glxinfo.txt --rawfile xdpyinfo /out/xdpyinfo.txt \
    --rawfile font /out/font.txt --rawfile geometry /out/geometry.txt \
    --argjson focusHelperPid "$focus_helper_pid" --arg focusHelperWindow "$focus_helper_window" \
    --arg focusHelperGeometry "$focus_helper_geometry" \
    '{runId:$run,
      executable:{path:$executablePath,version:$executableVersion,sha256:$executableSha},
      invocation:{path:$invocationPath,sha256:$invocationSha},
      sourceArtifact:{path:$sourcePath,sha256:$sourceSha},
      collector:{frozenRunnerSha256:$runnerSha,buildReceiptSha256:$receiptSha},
      probeRun:{path:"v3-capture.json",runId:$probeRun,sha256:$probeSha},
      display:{glxinfo:$glxinfo,xdpyinfo:$xdpyinfo,font:$font,geometry:$geometry,
        focusHelper:{pid:$focusHelperPid,window:$focusHelperWindow,geometry:$focusHelperGeometry}},
      clipboardFixture:{path:"clipboard-fixture.json",runId:$run,profile:$profile,sha256:$clipboardSha},
      sessionBus:{path:"session-bus.json",sha256:$sessionBusSha},
      capture:$capture} + (if $ids == null then {} else {selectedIDs:$ids} end)' \
    > /out/container-receipt.json
  exit 0
fi

usage() {
  echo "Usage: $0 --target kitty|xterm|ghostty|wezterm|alacritty [--preset baseline|current|default] --clipboard-profile default|allow|deny-read [--mux tmux|screen] [--mux-profile default|truecolor] [--ids ID,ID] OUTPUT_DIRECTORY" >&2
  echo "A source-tree collector also needs TERMINFO_PROBE_HASH and TERMINFO_SOURCE_REVISION" >&2
  echo "  from sourceSuiteEnvironment() in packages/admin/versions.ts, or serve.ts refuses the run." >&2
  echo "Retains raw/v3-capture.json, then finalizes a private sibling." >&2
  echo "That sibling and its completion receipt retain private collection custody." >&2
  echo "This launcher has no capture-only mode; do not use it for a raw-only authorization." >&2
  exit 2
}
target_id=
preset=default
clipboard_profile=
probe_ids=null
mux_kind=
mux_profile=default
output_parent=
while [[ "$#" -gt 0 ]]; do
  case "$1" in
    --mux)
      [[ "$#" -ge 2 && -z "$mux_kind" ]] || usage
      mux_kind=$2
      case "$mux_kind" in tmux|screen) ;; *) echo "Unknown multiplexer: $mux_kind" >&2; exit 2 ;; esac
      shift 2
      ;;
    --mux-profile)
      [[ "$#" -ge 2 && -n "${2:-}" && "${2:-}" != --* ]] || usage
      mux_profile=$2
      shift 2
      ;;
    --target)
      [[ "$#" -ge 2 && -n "${2:-}" && "${2:-}" != --* ]] || usage
      target_id=$2
      shift 2
      ;;
    --preset)
      [[ "$#" -ge 2 && -n "${2:-}" && "${2:-}" != --* ]] || usage
      preset=$2
      shift 2
      ;;
    --clipboard-profile)
      [[ "$#" -ge 2 && -n "${2:-}" && "${2:-}" != --* ]] || usage
      clipboard_profile=$2
      shift 2
      ;;
    --ids)
      [[ "$#" -ge 3 && "${2:-}" != --* ]] || { echo "Missing --ids value" >&2; usage; }
      [[ "$probe_ids" == null ]] || { echo "Repeated --ids" >&2; usage; }
      probe_ids=$(jq -cen --arg list "$2" '$list | split(",") | if length > 0 and all(.[]; test("^[a-z0-9][a-z0-9.-]*$")) and (unique | length) == length then . else error("Invalid probe IDs") end') || { echo "Invalid probe IDs" >&2; exit 2; }
      shift 2
      ;;
    -*)
      echo "Unknown flag or unexpected launch argument: $1" >&2
      usage
      ;;
    *)
      [[ -z "$output_parent" ]] || { echo "Unknown flag or unexpected launch argument: $1" >&2; usage; }
      output_parent=$1
      shift
      ;;
  esac
done
[[ -n "$target_id" && -n "$clipboard_profile" && -n "$output_parent" ]] || usage
[[ -z "$mux_kind" || "$target_id" == kitty ]] || { echo "Owned Linux mux outer must be Kitty" >&2; exit 2; }
mux_profile_config "$mux_kind" "$mux_profile" >/dev/null || exit 2
case "$target_id" in
  kitty|xterm|ghostty|wezterm|alacritty) ;;
  *) echo "Unknown target: $target_id" >&2; exit 2 ;;
esac
case "$clipboard_profile" in
  default|allow|deny-read) ;;
  *) echo "Unknown clipboard profile: $clipboard_profile" >&2; exit 2 ;;
esac
if [[ "$target_id" == kitty ]]; then
  case "$preset" in
    baseline|current) ;;
    *) echo "Kitty takes --preset baseline|current" >&2; exit 2 ;;
  esac
elif [[ "$preset" != default ]]; then
  echo "$target_id has only the default preset" >&2
  exit 2
fi
script_dir=$(cd "$(dirname "$0")" && pwd -P)
vendor_root=$(cd "$script_dir/.." && pwd -P)
code_root=$(cd "$vendor_root/../.." && pwd -P)
[[ -f "$code_root/flake.nix" && -f "$code_root/bun.lock" ]] || {
  echo "Expected owned CODE root with flake.nix and bun.lock" >&2; exit 2;
}
mkdir -p "$output_parent"
output_parent=$(cd "$output_parent" && pwd -P)
run_id=$(od -An -tx1 -N16 /dev/urandom | tr -d ' \n')
run_dir="$output_parent/$run_id"
mkdir "$run_dir"
mkdir -p "$run_dir/prep/receipt" "$run_dir/raw"
prep="$run_dir/prep"
raw="$run_dir/raw"

# Resolve the declared workspace, then freeze the single CLI producer's output
# with its public package imports into the content-addressed image input.
(
  cd "$code_root" &&
  @in -- bun install --frozen-lockfile --ignore-scripts &&
  @in -- bun vendor/terminfo.dev/scripts/build-cli.ts &&
  mkdir -p "$prep/bundle" &&
  @in -- bun build \
    vendor/terminfo.dev/packages/terminfo.dev/dist/terminfo.bundle.mjs \
    --target=bun --outdir "$prep/bundle" &&
  mv "$prep/bundle/terminfo.bundle.js" "$prep/bundle/index.js"
) > "$prep/bundle-build.log" 2>&1 || {
  cat "$prep/bundle-build.log" >&2
  echo "Offline frozen runner build failed; preserved at $run_dir" >&2
  exit 2
}
cli_bundle="$vendor_root/packages/terminfo.dev/dist/terminfo.bundle.mjs"
cli_receipt="$vendor_root/packages/terminfo.dev/dist/terminfo.bundle.receipt.json"
[[ -s "$cli_bundle" && -s "$cli_receipt" && -s "$prep/bundle/index.js" ]] || {
  echo "CLI producer or frozen runner output is missing; preserved at $run_dir" >&2; exit 2;
}
suite_hash=$(require_cli_producer_receipt "$cli_receipt" "$vendor_root/packages/terminfo.dev/bin/terminfo.mjs") || exit 2
source_revision=$(jq -er .collectorRevision "$cli_receipt")
cli_bundle_sha=$(sha256sum "$cli_bundle" | cut -d ' ' -f 1)
[[ "$cli_bundle_sha" == "$(jq -er .bundleSha256 "$cli_receipt")" &&
   "$source_revision" == "$(git -C "$vendor_root" rev-parse HEAD)" ]] || {
  echo "CLI bytes or source revision differ from producer receipt" >&2; exit 2;
}
cp "$cli_receipt" "$prep/bundle/terminfo.bundle.receipt.json"
frozen_runner_sha=$(sha256sum "$prep/bundle/index.js" | cut -d ' ' -f 1)
build_receipt_sha=$(sha256sum "$prep/bundle/terminfo.bundle.receipt.json" | cut -d ' ' -f 1)
cp "$script_dir/linux-container-run.sh" "$prep/bundle/linux-container-run.sh"
# The Notify recorder runs under the image's Bun beside the runner (#33053). It imports only node builtins, so its
# committed source is the frozen input; the bundle NAR and tar hashes in the host receipt cover its bytes.
notify_recorder_source="$vendor_root/packages/terminfo.dev/src/linux-notify-recorder.ts"
[[ -s "$notify_recorder_source" ]] || {
  echo "Notify recorder source is missing: $notify_recorder_source; preserved at $run_dir" >&2; exit 2;
}
cp "$notify_recorder_source" "$prep/bundle/linux-notify-recorder.ts"
(
  cd "$prep"
  tar --sort=name --mtime='@0' --owner=0 --group=0 --numeric-owner -cf runner-bundle.tar -C bundle .
)
bundle_sha=$(nix hash path --type sha256 --sri "$prep/bundle")
bundle_tar_sha=$(sha256sum "$prep/runner-bundle.tar" | cut -d ' ' -f 1)
source_status=clean
[[ -z "$(git -C "$vendor_root" status --porcelain)" ]] || source_status=dirty
root_revision=$(git -C "$code_root" rev-parse HEAD)
nix_lock_revision=$(jq -er '.nodes.nixpkgs.locked.rev' "$code_root/flake.lock")
root_lock_sha=$(sha256sum "$code_root/bun.lock" | cut -d ' ' -f 1)
(
  cd "$code_root"
  TERMINFO_LINUX_RUNNER_DIR="$prep/bundle" TERMINFO_LINUX_RUNNER_SHA256="$bundle_sha" \
    nix build --impure ".#${target_id}-visual-${preset}-image" --out-link "$prep/image.tar" \
      --option max-jobs 2 --option cores 2 -L
) > "$prep/nix-build.log" 2>&1 || {
  tail -100 "$prep/nix-build.log" >&2
  echo "Nix image build failed; preserved at $run_dir" >&2
  exit 2
}
image_tar_sha=$(sha256sum "$prep/image.tar" | cut -d ' ' -f 1)
image_reference=$(
  cd "$code_root"
  TERMINFO_LINUX_RUNNER_DIR="$prep/bundle" TERMINFO_LINUX_RUNNER_SHA256="$bundle_sha" \
    nix eval --impure --raw ".#${target_id}-visual-${preset}-image" \
      --apply '(image: image.imageName + ":" + image.imageTag)'
)
docker load --input "$prep/image.tar" >"$prep/docker-load.txt"
image_id=$(docker image inspect "$image_reference" --format '{{.Id}}')
docker image inspect "$image_id" > "$prep/image-inspect.json"
image_arch=$(docker image inspect "$image_id" --format '{{.Architecture}}')
[[ "$image_arch" == amd64 ]] || { echo "Loaded image architecture is $image_arch, expected amd64" >&2; exit 2; }
# The image's own labels are the identity: the launcher reads them and passes them on, so the
# declared target, version and source describe the bytes the image actually carries (@cto 1100603).
label_prefix="org.hallohuman.terminfo.${target_id}."
jq -e --arg label "${label_prefix}preset" --arg preset "$preset" \
  --arg versionLabel "${label_prefix}version" '
  .[0].Config.Labels[$label] == $preset and
  (.[0].Config.Labels[$versionLabel] | type == "string" and length > 0)' \
  "$prep/image-inspect.json" >/dev/null || {
  echo "Loaded image lacks declared $target_id preset metadata" >&2; exit 2;
}
target_version=$(jq -er --arg label "${label_prefix}version" '.[0].Config.Labels[$label]' "$prep/image-inspect.json")
source_url=$(jq -er --arg label "${label_prefix}source-url" '.[0].Config.Labels[$label] // ""' "$prep/image-inspect.json")
source_sri=$(jq -er --arg label "${label_prefix}source-sri" '.[0].Config.Labels[$label] // ""' "$prep/image-inspect.json")
# `source_revision` above is the COLLECTOR revision; the proof's upstream revision must not shadow it.
proof_kind=$(jq -er --arg label "${label_prefix}source-kind" '.[0].Config.Labels[$label] // ""' "$prep/image-inspect.json")
proof_nar_sri=$(jq -er --arg label "${label_prefix}source-nar-sri" '.[0].Config.Labels[$label] // ""' "$prep/image-inspect.json")
proof_revision=$(jq -er --arg label "${label_prefix}source-revision" '.[0].Config.Labels[$label] // ""' "$prep/image-inspect.json")
# Kitty's image predates the uniform TERMINFO_TARGET_* names; map its env either way, and check the
# image really declares what the labels and the receipt are about to claim.
case "$target_id" in
  kitty)
    binary_env=KITTY_BINARY
    version_env=KITTY_EXPECTED_VERSION
    url_env=KITTY_SOURCE_URL
    sri_env=KITTY_SOURCE_SRI
    archive_env=KITTY_SOURCE_ARCHIVE
    preset_env=TERMINFO_KITTY_PRESET
    ;;
  *)
    binary_env=TERMINFO_TARGET_BINARY
    version_env=TERMINFO_TARGET_VERSION
    url_env=TERMINFO_TARGET_SOURCE_URL
    sri_env=TERMINFO_TARGET_SOURCE_SRI
    archive_env=TERMINFO_TARGET_SOURCE_ARCHIVE
    preset_env=TERMINFO_TARGET_PRESET
    ;;
esac
for declared_env in "$preset_env=$preset" "$version_env=$target_version" \
  "$url_env=$source_url" "$sri_env=$source_sri"; do
  jq -e --arg entry "$declared_env" '.[0].Config.Env | index($entry) != null' \
    "$prep/image-inspect.json" >/dev/null || {
    echo "Loaded image environment disagrees with declared $target_id metadata: $declared_env" >&2
    exit 2
  }
done
# The uniform source-proof metadata is declared by every mkVisualImage target; kitty's own image
# predates it and its target never derives a tree, so its absence is not a disagreement.
if [[ "$target_id" != kitty ]]; then
  for declared_env in "TERMINFO_TARGET_SOURCE_KIND=$proof_kind" \
    "TERMINFO_TARGET_SOURCE_NAR_SRI=$proof_nar_sri" \
    "TERMINFO_TARGET_SOURCE_REVISION=$proof_revision"; do
    jq -e --arg entry "$declared_env" '.[0].Config.Env | index($entry) != null' \
      "$prep/image-inspect.json" >/dev/null || {
      echo "Loaded image environment disagrees with declared $target_id metadata: $declared_env" >&2
      exit 2
    }
  done
fi
target_binary=$(jq -er --arg name "$binary_env" '.[0].Config.Env | map(select(startswith($name + "="))) | .[0] | sub("^[^=]*="; "")' "$prep/image-inspect.json")
target_source_archive=$(jq -er --arg name "$archive_env" '.[0].Config.Env | map(select(startswith($name + "="))) | .[0] | sub("^[^=]*="; "")' "$prep/image-inspect.json")
[[ -n "$target_source_archive" ]] || {
  echo "$target_id: no source archive; source proof unavailable" >&2
  exit 2
}
case "$proof_kind" in
  ""|derived-source-tree) ;;
  *) echo "$target_id: unknown source proof kind $proof_kind" >&2; exit 2 ;;
esac
if [[ "$proof_kind" == derived-source-tree ]]; then
  [[ "$proof_nar_sri" == sha256-* && -n "$proof_revision" ]] || {
    echo "$target_id: derived source tree lacks a pinned revision or tree hash; source proof unavailable" >&2
    exit 2
  }
fi
write_host_receipt "$raw/host-measured.json"

# The collector reads its ownership receipt from a read-only copy: the container being measured
# must not be able to rewrite the receipt that authorizes writing to the terminal it drives.
cp "$raw/host-measured.json" "$prep/receipt/host-measured.json"

# A mux colour negative needs the outer terminal's own placed record at this exact version (#33041).
# The container cannot read content/, so the newest matching record's facts are copied into the run;
# with none placed, the file says so and the colour rows stay open with that reason.
if [[ -n "$mux_kind" ]]; then
  outer_records=()
  for record in "$vendor_root/content/probes-apps/$target_id-$target_version-linux-"*.json; do
    [[ -e "$record" ]] && outer_records+=("$record")
  done
  if (( ${#outer_records[@]} )); then
    jq -n --arg root "$vendor_root/" '[inputs | . + {recordPath: (input_filename | ltrimstr($root))}]
      | max_by(.measuredAt)
      | {id: .subject.id, version: .subject.version, os: .subject.os, recordPath, recordRunId: .runId,
         statuses: ([.results[] | {key: .featureId, value: .status}] | from_entries)}' \
      "${outer_records[@]}" > "$raw/outer-colour-record.json"
  else
    jq -n --arg glob "content/probes-apps/$target_id-$target_version-linux-*.json" \
      '{missing: "no placed outer-terminal record matches \($glob)"}' > "$raw/outer-colour-record.json"
  fi
fi

# The run user is the INVOKING user, never the image's declared User: docker create overrides it with
# --user (below) so the bind-mounted /out is writable by this process, and a program that then
# resolves the user by uid finds no passwd entry at all - alacritty refuses `pw not found` before it
# can open a window, and ghostty cannot detect a default shell. Generate the two files the image
# cannot carry for a uid it does not know, and mount them read-only. ONE binding (@cto 2026-10-06,
# 27892): this uid/gid feeds --user, the private /home/runner tmpfs and both files, and the shell is
# the image's own entrypoint rather than a guessed path.
run_uid=$(id -u)
run_gid=$(id -g)
[[ "$run_uid" != 0 ]] || { echo "Refusing root run user" >&2; exit 2; }
container_shell=$(jq -er '.[0].Config.Entrypoint[0]' "$prep/image-inspect.json") || {
  echo "Loaded image declares no entrypoint, so the run user has no shell" >&2; exit 2;
}
[[ "$container_shell" == /* ]] || {
  echo "Loaded image entrypoint is not an absolute shell path: $container_shell" >&2; exit 2;
}
printf 'runner:x:%s:%s:terminfo run user:/home/runner:%s\n' "$run_uid" "$run_gid" "$container_shell" > "$prep/passwd"
printf 'runner:x:%s:\n' "$run_gid" > "$prep/group"
chmod 0644 "$prep/passwd" "$prep/group"

selection_env=()
[[ "$probe_ids" == null ]] || selection_env=(--env "TERMINFO_PROBE_IDS=$probe_ids")
# The one-time sentinel-grace sizing pass widens the post-DA1 read; forward it only when the host
# asked for it, so an ordinary collection keeps the measured floor.
grace_env=()
[[ -z "${TERMINFO_SENTINEL_GRACE_MS:-}" ]] || grace_env=(--env "TERMINFO_SENTINEL_GRACE_MS=$TERMINFO_SENTINEL_GRACE_MS")
# The declared locale every collector-owned terminal launch runs under (28752): the container's
# shell, the terminal and the collector all inherit ONE value, so a run's decode context is pinned
# rather than whatever the launching shell happened to carry. Recorded in observed.json below.
container_id=$(docker create --user "$run_uid:$run_gid" --network none --read-only \
  --cap-drop ALL --security-opt no-new-privileges --pids-limit 128 --memory 2g --cpus 2 \
  --tmpfs "/tmp:rw,nosuid,nodev,mode=1777" \
  --tmpfs "/home/runner:rw,nosuid,nodev,uid=$run_uid,gid=$run_gid,mode=0700" \
  --mount "type=bind,src=$raw,dst=/out" \
  --mount "type=bind,src=$prep/receipt,dst=/receipt,readonly" \
  --mount "type=bind,src=$prep/passwd,dst=/etc/passwd,readonly" \
  --mount "type=bind,src=$prep/group,dst=/etc/group,readonly" \
  --env "LC_ALL=C.UTF-8" \
  --env "TERMINFO_RUN_ID=$run_id" --env "TERMINFO_CAPTURE_RUN_ID=${TERMINFO_CAPTURE_RUN_ID:-}" --env "TERMINFO_IMAGE_ID=$image_id" \
  --env "TERMINFO_CLIPBOARD_PROFILE=$clipboard_profile" "${selection_env[@]}" \
  --env "TERMINFO_MUX_KIND=$mux_kind" --env "TERMINFO_MUX_PROFILE=$mux_profile" \
  --env "TERMINFO_TARGET_ID=$target_id" --env "TERMINFO_TARGET_PRESET=$preset" \
  --env "TERMINFO_TARGET_BINARY=$target_binary" --env "TERMINFO_TARGET_VERSION=$target_version" \
  --env "TERMINFO_TARGET_SOURCE_URL=$source_url" --env "TERMINFO_TARGET_SOURCE_SRI=$source_sri" \
  --env "TERMINFO_TARGET_SOURCE_ARCHIVE=$target_source_archive" \
  --env "TERMINFO_TARGET_SOURCE_KIND=$proof_kind" \
  --env "TERMINFO_TARGET_SOURCE_NAR_SRI=$proof_nar_sri" \
  --env "TERMINFO_TARGET_SOURCE_REVISION=$proof_revision" \
  "${grace_env[@]}" \
  --env "TERMINFO_DISPOSABLE_RECEIPT=/receipt/host-measured.json" \
  "$image_id")
echo "$container_id" > "$prep/container-id.txt"
if ! timeout "$PROBE_BATCH_TIMEOUT_SECONDS" docker start --attach "$container_id" > "$prep/container-stdout.log" 2>"$prep/container-stderr.log"; then
  if [[ "$(docker inspect "$container_id" --format '{{.State.Running}}')" == true ]]; then
    if ! docker stop --time 5 "$container_id" > "$prep/stop.txt" 2>&1; then
      echo "Could not stop owned container $container_id; see $prep/stop.txt" >&2
    fi
  fi
fi
docker inspect "$container_id" > "$prep/container-inspect.json"
exit_code=$(jq -er '.[0].State.ExitCode' "$prep/container-inspect.json")
logs_status=0
docker logs "$container_id" > "$prep/docker-stdout.log" 2>"$prep/docker-stderr.log" || logs_status=$?
docker rm "$container_id" > "$prep/docker-rm.txt"
[[ "$logs_status" == 0 ]] || {
  echo "Could not preserve Docker logs for $container_id (status $logs_status)" >&2
  exit 2
}
# The collector was judged by the read-only copy; if the container rewrote the writable one the
# run's authorization is not the host's, so the receipt and the run are both refused.
cmp -s "$raw/host-measured.json" "$prep/receipt/host-measured.json" || {
  echo "Container rewrote the host-measured receipt; run invalid" >&2; exit 2;
}
if [[ "$exit_code" != 0 || ! -f "$raw/observed.json" ]]; then
  if completed_batch_survives_attach_timeout "$exit_code" "$raw"; then
    echo "Container attach budget ended (exit 143) after a completed batch; judging from retained receipts at $run_dir" >&2
  else
    echo "Container failed (exit $exit_code); raw artifacts preserved at $run_dir" >&2
    cat "$prep/container-stderr.log" >&2
    exit 2
  fi
fi
[[ -r "$raw/container-receipt.json" ]] || {
  echo "Container exited without its runtime receipt; run invalid" >&2; exit 2;
}
jq -e --arg run "$run_id" '.runId == $run' "$raw/observed.json" >/dev/null || {
  echo "Raw observation run ID differs from host run ID" >&2; exit 2;
}
probe_sha=$(sha256sum "$raw/v3-capture.json" | cut -d ' ' -f 1)
jq -e --arg run "$(jq -er .probeRunId "$raw/observed.json")" --arg sha "$probe_sha" \
  '.probeRun.runId == $run and .probeRun.sha256 == $sha' "$raw/container-receipt.json" >/dev/null || {
  echo "Raw schema-4 capture differs from container receipt" >&2; exit 2;
}
jq -e --slurpfile run "$raw/v3-capture.json" \
  '($run[0] | if .subject.kind == "mux" then .outerApp.provenance.executable
              else .provenance.executable end) as $executable |
   .executable.path == $executable.path and
   .executable.sha256 == $executable.sha256' \
  "$raw/container-receipt.json" >/dev/null || {
  echo "Retained schema-4 capture executable differs from measured container ELF" >&2; exit 2;
}
source_sha=$(jq -er .sourceArtifact.sha256 "$raw/container-receipt.json")
source_sri=$(nix hash convert --hash-algo sha256 --to sri "$source_sha")
[[ "$source_sri" == "$(jq -er .sourceArtifact.sri "$raw/host-measured.json")" ]] || {
  echo "Runtime $target_id source archive differs from the declared source proof: $source_sri" >&2
  exit 2
}
clipboard_sha=$(sha256sum "$raw/clipboard-fixture.json" | cut -d ' ' -f 1)
jq -e --arg run "$run_id" --arg profile "$clipboard_profile" \
  '.runId == $run and .profile == $profile' "$raw/clipboard-fixture.json" >/dev/null || {
  echo "Retained clipboard fixture has wrong run ID or profile" >&2; exit 2;
}
jq -e --arg run "$run_id" --arg profile "$clipboard_profile" --arg sha "$clipboard_sha" \
  '.clipboardFixture.runId == $run and .clipboardFixture.profile == $profile and
   .clipboardFixture.sha256 == $sha' "$raw/container-receipt.json" >/dev/null || {
  echo "Container clipboard fixture differs from exact retained receipt" >&2; exit 2;
}
TERMINFO_PROBE_HASH="$suite_hash" TERMINFO_SOURCE_REVISION="$source_revision" \
TERMINFO_CAPTURE_RAW="$raw/v3-capture.json" TERMINFO_CAPTURE_OUTPUT="$raw" bun --cwd "$vendor_root" -e '
  import {readFileSync,writeFileSync} from "node:fs";
  import {join} from "node:path";
  import {readRetainedDaemonProbeResponse,finalizeCollectedDraft} from "./packages/terminfo.dev/src/daemon-client.ts";
  import {getTrustedSuiteReceipt} from "./packages/terminfo.dev/src/serve.ts";
  const directory=process.env.TERMINFO_CAPTURE_OUTPUT;
  const retained=await readRetainedDaemonProbeResponse(new Response(readFileSync(process.env.TERMINFO_CAPTURE_RAW)),{directory:join(directory,"http-responses"),get receipt(){return getTrustedSuiteReceipt();}});
  if(retained.kind==="empty-selection") throw new Error("Empty selection where a capture was required");
  const run=finalizeCollectedDraft(retained.run);
  const path=join(directory,"v3-run.draft.json");
  writeFileSync(path,JSON.stringify(run,null,2)+"\n",{flag:"wx",mode:0o600});
  console.error("Collected current schema-4 run");
'
compose_receipt "$raw/host-measured.json" "$raw/container-receipt.json" "$raw/run-receipt.json" "$raw/v3-run.draft.json"
echo "$run_dir"
