/**
 * @failure A missing or mismatched container receipt is accepted as a host image's completed run.
 * @level l1 — invokes the real shell receipt composer on owned temporary files.
 * @consumer scripts/linux-container-run.sh host-side run receipt and prerequisite handling.
 * @reach fs-walk <fixture-only: readdir enumerates the owned temporary run output only>
 * @reach fs-walk vendor/terminfo.dev/scripts/**
 * @testonly none
 */

import { spawnSync } from "node:child_process"
import { createHash } from "node:crypto"
import {
  chmodSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from "node:fs"
import { tmpdir } from "node:os"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"
import { afterEach, beforeEach, describe, expect, it } from "vitest"
import { initializeRunDraft } from "@terminfo/probe-defs"
import { derivedSuiteManifest, probeSuiteSnapshot } from "../packages/admin/versions.ts"
import { OWNED_LAYOUT } from "../packages/probes/fixtures/owned-layout.fixture.ts"
import type { LinuxMuxAttachmentProof, CapturedRunDraft } from "@terminfo/probe-defs"
import { bindReceiptToRun, parseDisposableReceipt } from "../packages/terminfo.dev/src/disposable-receipt.ts"
import { MUX_DEFAULT_CONFIG, SCREEN_TRUECOLOR_CONFIG, TRUECOLOR_ON } from "../docs/data/context-supplements.ts"
import { MUX_PROFILE_CONFIG_FILES } from "../packages/terminfo.dev/src/disposable-receipt.ts"

const launcher = fileURLToPath(new URL("./linux-container-run.sh", import.meta.url))
let dir: string

function launchArgs(app: string): string[] {
  const source = readFileSync(launcher, "utf8")
  const marker = `\n    ${app})`
  const start = source.indexOf(marker)
  const end = source.indexOf("\n      ;;", start)
  if (start < 0 || end < 0) throw new Error(`${app} launch descriptor is missing`)
  const body = source.slice(start + marker.length, end)
  const result = spawnSync(
    "bash",
    [
      "-c",
      [
        "set -euo pipefail",
        `target_id=${app}`,
        "target_version=1.4.0",
        body,
        'printf "%s\\0" "${target_launch_args[@]}"',
      ].join("\n"),
    ],
    { encoding: "utf8", env: { ...process.env, HOME: dir } },
  )
  expect(result.status, result.stderr).toBe(0)
  return result.stdout.split("\0").filter(Boolean)
}

// @failure Ghostty's forced --title silently disables OSC 2 and its OSC 7 public-title fallback.
// Execute the production descriptor's argument construction; no terminal or container starts here.
it.each(["ghostty", "wezterm"])(
  "records %s's production launch settings without suppressing application titles",
  (app) => {
    const args = launchArgs(app)
    expect(args.length).toBeGreaterThan(0)
    expect(args.some((arg) => arg === "--title" || arg.startsWith("--title="))).toBe(false)
    if (app === "wezterm") expect(args.slice(-2)).toEqual(["--config", "log_unknown_escape_sequences=true"])
  },
)

/** The owned focus helper window the display receipt must name (#33305). */
const DEFAULT_FOCUS_HELPER = {
  pid: 4321,
  window: "6291468",
  geometry: "Window 6291468 Position: 1600,900 Geometry: 160x60",
}

function compose(
  containerRunId = "a".repeat(32),
  writeContainer = true,
  containerRunnerSha = "runner-hash",
  containerProfile = "default",
  capture: unknown = { xwdSha256: "xwd-hash", pngSha256: "png-hash" },
  focusHelper: { container?: unknown; omitContainerDisplay?: boolean } = { container: DEFAULT_FOCUS_HELPER },
) {
  const host = join(dir, "host.json")
  const container = join(dir, "container.json")
  const output = join(dir, "run-receipt.json")
  writeFileSync(
    host,
    JSON.stringify({
      runId: "a".repeat(32),
      clipboardProfile: "default",
      sourceArtifact: { url: "https://example.invalid/kitty.txz" },
      runnerArtifact: { frozenRunnerSha256: "runner-hash", buildReceiptSha256: "receipt-hash" },
      runtime: { imageId: "sha256:image", imageTarSha256: "tar-hash" },
    }),
  )
  if (writeContainer) {
    writeFileSync(
      container,
      JSON.stringify({
        runId: containerRunId,
        invocation: { path: "/nix/store/kitty/bin/kitty", sha256: "wrapper-hash" },
        executable: { path: "/nix/store/kitty/bin/.kitty-wrapped", version: "kitty 0.49.1", sha256: "elf-hash" },
        sourceArtifact: { path: "/kitty-source/kitty.txz", sha256: "archive-hash" },
        collector: { frozenRunnerSha256: containerRunnerSha, buildReceiptSha256: "receipt-hash" },
        probeRun: { path: "v3-capture.json", runId: "b".repeat(32), sha256: "probe-hash" },
        display: {
          glxinfo: "llvmpipe",
          geometry: "WIDTH=800",
          ...(focusHelper.omitContainerDisplay === true ? {} : { focusHelper: focusHelper.container ?? null }),
        },
        clipboardFixture: { runId: containerRunId, profile: containerProfile, sha256: "fixture-hash" },
        sessionBus: { path: "session-bus.json", sha256: "session-bus-hash" },
        capture,
      }),
    )
  }
  const result = spawnSync(
    "bash",
    ["-c", 'source "$1"; compose_receipt "$2" "$3" "$4"', "_", launcher, host, container, output],
    {
      encoding: "utf8",
    },
  )
  return { result, output }
}

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), "terminfo-container-receipt-"))
})

afterEach(() => {
  rmSync(dir, { recursive: true, force: true })
})

// #32062: argument-only coverage misses an unexecuted or incorrectly calibrated font receipt.
// Owned tool doubles test producer mechanics, without claiming actual font shaping support.
type FontControlReceipt = {
  status: string
  reason: string
  proofState: string
  requestedFamily: string
  face: string
  sample: string
  source: { path: string; sha256: string }
  launch: { args: string[]; path: string; fontconfig: string; fontconfigBytes: string }
  harfbuzz: { version: string; on: string; off: string; stderr: string }
}
const fontGlyphIds = (raw: string) => (JSON.parse(raw) as { g: number }[]).map((glyph) => glyph.g)

function fontControl(scenario: "capable" | "positions-only" | "missing" | "failed", app = "kitty") {
  const root = join(dir, scenario),
    bin = join(root, "bin"),
    output = join(root, "out")
  mkdirSync(bin, { recursive: true })
  mkdirSync(output)
  for (const tool of ["jq", "sha256sum", "cut", "readlink", "mkdir", "ln"]) {
    const found = spawnSync("bash", ["-c", 'command -v "$1"', "_", tool], { encoding: "utf8" })
    if (found.status !== 0) throw new Error(`Missing declared test utility ${tool}: ${found.stderr}`)
    symlinkSync(found.stdout.trim(), join(bin, tool))
  }
  const font = join(root, "JetBrainsMono-Regular.ttf"),
    log = join(root, "hb-args.txt")
  writeFileSync(font, "synthetic exact font bytes; not a font-capability claim")
  const styledFonts = ["Bold", "Italic", "BoldItalic"].map((style) => {
    const path = join(root, `JetBrainsMono-${style}.ttf`)
    writeFileSync(path, `synthetic ${style} font bytes; not a font-capability claim`)
    return path
  })
  const executable = (name: string, body: string) => {
    const path = join(bin, name)
    writeFileSync(path, `#!/usr/bin/bash\n${body}\n`)
    chmodSync(path, 0o755)
  }
  executable(
    "fc-match",
    String.raw`
case "$*" in
  *':style=Bold Italic'*) printf '%s\n' "$FIXTURE_FONT_BOLD_ITALIC"; exit 0;;
  *':style=Bold'*) printf '%s\n' "$FIXTURE_FONT_BOLD"; exit 0;;
  *':style=Italic'*) printf '%s\n' "$FIXTURE_FONT_ITALIC"; exit 0;;
esac
for arg in "$@"; do
  case "$arg" in
    *'%{family}'*'%{file}'*) printf 'JetBrains Mono | %s\n' "$FIXTURE_FONT"; exit 0;;
    *'%{file}'*) printf '%s\n' "$FIXTURE_FONT"; exit 0;;
    *'%{family}'*) printf 'JetBrains Mono\n'; exit 0;;
  esac
done
exit 2`,
  )
  executable("fc-cache", "exit 0")
  if (scenario !== "missing") {
    executable(
      "hb-shape",
      String.raw`
if [[ "$*" == *--version* ]]; then printf 'hb-shape fixture-version\n'; exit 0; fi
printf '%s\n' "$*" >> "$FIXTURE_HB_LOG"
if [[ "$FIXTURE_SCENARIO" == failed ]]; then echo 'fixture HB failure 41' >&2; exit 41; fi
if [[ "$*" == *liga=1,calt=1* ]]; then
  if [[ "$FIXTURE_SCENARIO" == capable ]]; then printf '[{"g":501,"cl":0,"ax":20}]\n'
  else printf '[{"g":17,"cl":0,"ax":999,"dx":4}]\n'; fi
else printf '[{"g":17,"cl":0,"ax":10,"dx":0}]\n'; fi`,
    )
  }
  const args = app === "alacritty" ? launchArgs(app) : ["--config", "NONE", "--override", "font_family=JetBrains Mono"]
  const source = readFileSync(launcher, "utf8")
  const call = source.indexOf(") prepare_font_control /out ")
  const start = source.lastIndexOf('  case "$target_id" in', call)
  const end = source.indexOf("\n  esac", call)
  if (call < 0 || start < 0 || end < 0) throw new Error("Production font selection is missing")
  const selection = source.slice(start, end + "\n  esac".length).replaceAll("/out", '"$output"')
  const result = spawnSync(
    "/usr/bin/bash",
    [
      "-c",
      String.raw`
source "$1"
shift
output=$1
shift
target_id=${app}
target_launch_args=("$@")
${app === "alacritty" ? selection : 'prepare_font_control "$output" "JetBrains Mono" "$@"'}
printf '%s' "$FONTCONFIG_FILE" > "$output/exported-fontconfig.txt"
`,
      "_",
      launcher,
      output,
      ...args,
    ],
    {
      encoding: "utf8",
      env: {
        ...process.env,
        PATH: bin,
        FIXTURE_FONT: font,
        FIXTURE_FONT_BOLD: styledFonts[0],
        FIXTURE_FONT_ITALIC: styledFonts[1],
        FIXTURE_FONT_BOLD_ITALIC: styledFonts[2],
        FIXTURE_HB_LOG: log,
        FIXTURE_SCENARIO: scenario,
      },
    },
  )
  return { result, output, font, styledFonts, args, log }
}

it.each(["kitty", "alacritty"])(
  "%s font control retains capable glyph IDs, exact font hash and the actual private launch pin",
  (app) => {
    const fixture = fontControl("capable", app)
    expect(fixture.result.status, fixture.result.stderr).toBe(0)
    const receipt = JSON.parse(readFileSync(join(fixture.output, "font.txt"), "utf8")) as FontControlReceipt
    expect(receipt.status).toBe("source-capable")
    expect(receipt.proofState).toBe("source-capable")
    expect(receipt.requestedFamily).toBe("JetBrains Mono")
    expect(receipt.face).toBe(realpathSync(fixture.font))
    expect(receipt.source).toMatchObject({
      path: realpathSync(fixture.font),
      sha256: createHash("sha256").update(readFileSync(fixture.font)).digest("hex"),
    })
    expect(receipt.sample).toBe("!= -> => <= ==")
    expect(receipt.launch.args).toEqual(fixture.args)
    if (app === "alacritty") {
      const option = fixture.args.indexOf("--option")
      expect(option).toBeGreaterThanOrEqual(0)
      expect(Bun.TOML.parse(fixture.args[option + 1]!)).toEqual({ font: { normal: { family: "JetBrains Mono" } } })
    }
    expect(realpathSync(receipt.launch.path)).toBe(realpathSync(fixture.font))
    expect(readFileSync(join(fixture.output, "exported-fontconfig.txt"), "utf8")).toBe(receipt.launch.fontconfig)
    const xml = readFileSync(receipt.launch.fontconfig, "utf8")
    expect(receipt.launch.fontconfigBytes).toBe(xml)
    expect(xml).not.toContain("<include")
    const fontDirs = [...xml.matchAll(/<dir(?:\s[^>]*)?>([^<]+)<\/dir>/g)].map((match) => match[1]!)
    expect(fontDirs).toHaveLength(1)
    // Native #31742: a Regular-only directory made bold/italic controls paint as plain.
    // Preserve the calibrated Regular face while exposing its same-family style companions.
    const pinnedFaces = readdirSync(fontDirs[0]!).map((name) => realpathSync(join(fontDirs[0]!, name)))
    expect(new Set(pinnedFaces)).toEqual(
      new Set([fixture.font, ...fixture.styledFonts].map((path) => realpathSync(path))),
    )
    expect(receipt.harfbuzz.version).toContain("fixture-version")
    expect(fontGlyphIds(receipt.harfbuzz.on)).toEqual([501])
    expect(fontGlyphIds(receipt.harfbuzz.off)).toEqual([17])
    const calls = readFileSync(fixture.log, "utf8")
    for (const argument of [
      fixture.font,
      "--output-format=json",
      "--no-glyph-names",
      "--features=liga=1,calt=1",
      "--features=liga=0,calt=0",
      receipt.sample,
    ]) {
      expect(calls).toContain(argument)
    }
  },
)

it("font control keeps different positions with unchanged glyph IDs PROBE TODO", () => {
  const fixture = fontControl("positions-only")
  expect(fixture.result.status, fixture.result.stderr).toBe(0)
  const receipt = JSON.parse(readFileSync(join(fixture.output, "font.txt"), "utf8")) as FontControlReceipt
  expect(receipt.status).toBe("probe-todo")
  expect(receipt.proofState).toBe("inconclusive")
  expect(receipt.reason).toContain("control #32062")
  expect(receipt.reason).toMatch(/glyph|substitut|ligatur/i)
  expect(receipt.harfbuzz.on).not.toBe(receipt.harfbuzz.off)
  expect(fontGlyphIds(receipt.harfbuzz.on)).toEqual(fontGlyphIds(receipt.harfbuzz.off))
})

it("missing or failed HarfBuzz retains a named PROBE TODO receipt instead of aborting or grading an engine", () => {
  for (const scenario of ["missing", "failed"] as const) {
    const fixture = fontControl(scenario)
    expect(fixture.result.status, fixture.result.stderr).toBe(0)
    const receipt = JSON.parse(readFileSync(join(fixture.output, "font.txt"), "utf8")) as FontControlReceipt
    expect(receipt.status).toBe("probe-todo")
    expect(receipt.proofState).toBe(scenario === "missing" ? "absent" : "failed to load")
    expect(receipt.reason).toContain("control #32062")
    expect(receipt.reason).toMatch(/hb-shape|HarfBuzz|missing|failed/i)
    if (scenario === "failed") expect(receipt.harfbuzz.stderr).toContain("fixture HB failure 41")
    expect(receipt).not.toHaveProperty("observation")
    expect(receipt).not.toHaveProperty("assertions")
  }
})

// The producer must bind disposable authority to the mux without relabeling Kitty's
// archive/version. Existing composition tests supply host JSON and missed this join.
it.each(["", "tmux", "screen"])("host writer binds %s while retaining the outer source facts", (mux) => {
  const host = join(dir, "produced-host.json")
  const build = join(dir, "build.json")
  writeFileSync(build, "{}")
  const digest = createHash("sha256").update("measured-image").digest("hex")
  const result = spawnSync(
    "bash",
    [
      "-c",
      String.raw`
source "$1"
mux_kind=$2
probe_ids=null run_id=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa image_id=sha256:$3 image_tar_sha=$3
image_arch=amd64 nix_lock_revision=abcdef123456 source_revision=abcdef root_revision=abcdef suite_hash=abcdef
bundle_tar_sha=$3 bundle_sha=sha256-source root_lock_sha=$3 frozen_runner_sha=$3 build_receipt_sha=$3
source_status=clean cli_receipt=$4 preset=current clipboard_profile=default target_version=0.49.1 target_id=kitty
source_url=https://example.invalid/kitty.txz source_sri=sha256-kitty proof_kind='' proof_nar_sri='' proof_revision=''
prep=$5
write_host_receipt "$6"
TERMINFO_MUX_KIND=$mux_kind TERMINFO_CLIPBOARD_PROFILE=$clipboard_profile target_preset=$preset target_source_url=$source_url
validate_host_metadata "$6"
target_version=wrong-outer-version
if validate_host_metadata "$6" 2>"$5/version-mismatch.stderr"; then
  echo "Container accepted a different outer version" >&2
  exit 1
fi
`,
      "_",
      launcher,
      mux,
      digest,
      build,
      dir,
      host,
    ],
    { encoding: "utf8" },
  )
  expect(result.status, result.stderr).toBe(0)
  const bytes = readFileSync(host, "utf8")
  const parsed = parseDisposableReceipt(bytes)
  const target = { kind: mux ? "mux" : "app", id: mux || "kitty", os: "linux" }
  expect(() => bindReceiptToRun(parsed, target, "host writer test")).not.toThrow()
  expect(() => bindReceiptToRun(parsed, { ...target, id: "wrong-target" }, "host writer test")).toThrow(/disagree/)
  const raw = JSON.parse(bytes) as {
    declaredTarget: { kind: string; id: string; os: string; version?: string }
    sourceArtifact: { url: string; sri: string; target?: { kind: string; id: string; version: string; os: string } }
  }
  expect(raw.sourceArtifact.url).toBe("https://example.invalid/kitty.txz")
  expect(raw.sourceArtifact.sri).toBe("sha256-kitty")
  // The receipt is committed to the public repo: the runner bundle is named by its digests,
  // never by the folder the host prepared it in (30568).
  expect(bytes).not.toContain(dir)
  const outer = { kind: "app", id: "kitty", version: "0.49.1", os: "linux" }
  if (mux) {
    expect(raw.declaredTarget).toEqual(target)
    expect(raw.sourceArtifact.target).toEqual(outer)
    expect(() => bindReceiptToRun(parsed, outer, "host writer test")).toThrow(/disagree/)
  } else {
    expect(raw.declaredTarget).toEqual(outer)
    expect(raw.sourceArtifact).not.toHaveProperty("target")
  }

  // Compose the producer's bytes with the existing measured-container fixture.
  // The host receipt must remain unchanged, and its artifact subject must survive.
  const fixture = compose()
  expect(fixture.result.status, fixture.result.stderr).toBe(0)
  const container = join(dir, "container.json")
  const containerFacts = JSON.parse(readFileSync(container, "utf8")) as {
    collector: { frozenRunnerSha256: string; buildReceiptSha256: string }
    executable: { path: string; sha256: string }
  }
  containerFacts.collector = { frozenRunnerSha256: digest, buildReceiptSha256: digest }
  writeFileSync(container, JSON.stringify(containerFacts))
  const composed = join(dir, "produced-run-receipt.json")
  const joined = spawnSync(
    "bash",
    ["-c", 'source "$1"; compose_receipt "$2" "$3" "$4"', "_", launcher, host, container, composed],
    { encoding: "utf8" },
  )
  expect(joined.status, joined.stderr).toBe(0)
  expect(readFileSync(host, "utf8")).toBe(bytes)
  const combined = JSON.parse(readFileSync(composed, "utf8")) as {
    declaredTarget: unknown
    sourceArtifact: unknown
    receiptInputs: { hostSha256: string }
    clipboardFixture: { sha256: string }
  }
  expect(combined.declaredTarget).toEqual(raw.declaredTarget)
  expect(combined.sourceArtifact).toMatchObject(raw.sourceArtifact)
  expect(combined.receiptInputs.hostSha256).toBe(parsed.sha256)
  expect(combined.clipboardFixture.sha256).not.toBe(parsed.sha256)

  // The launcher's post-batch check must bind the measured ELF to this run's
  // outer app. Mux runs deliberately have no top-level app provenance.
  const source = readFileSync(launcher, "utf8")
  const match = source.match(/jq -e --slurpfile run "\$raw\/v3-capture\.json" \\\n\s*'([^']*)'/)
  if (!match) throw new Error("Retained executable comparison not found in scripts/linux-container-run.sh")
  const executable = containerFacts.executable
  const runPath = join(dir, "v3-capture.json")
  const selectedKey = mux ? "outerApp" : "provenance"
  for (const mismatch of ["none", "path", "sha256", "missing"] as const) {
    const measured = { ...executable }
    if (mismatch === "path") measured.path = "/wrong/executable"
    if (mismatch === "sha256") measured.sha256 = "wrong-hash"
    const selected = mux ? { provenance: { executable: measured } } : { executable: measured }
    const run = {
      subject: { ...target, kind: mux ? "mux" : "term" },
      [selectedKey]: selected,
      // A matching wrong-location decoy must never rescue missing provenance.
      ...(mismatch === "missing"
        ? mux
          ? { outerApp: {}, provenance: { executable } }
          : { provenance: {}, outerApp: { provenance: { executable } } }
        : {}),
    }
    writeFileSync(runPath, JSON.stringify(run))
    const checked = spawnSync("jq", ["-e", "--slurpfile", "run", runPath, match[1]!, container], {
      encoding: "utf8",
    })
    expect(checked.status, `${mux || "app"}: ${mismatch}: ${checked.stderr}`).toBe(mismatch === "none" ? 0 : 1)
  }
})

// Receipt issuance must identify the newly live collector, while preserving the preflight
// identity. Existing compose tests only join already-produced host/container receipts.
it.runIf(process.platform === "linux")(
  "mux receipt producer measures the inner collector separately from preflight",
  () => {
    const config = join(dir, "empty.conf")
    const preflight = join(dir, "preflight.json")
    writeFileSync(config, "", { mode: 0o600 })
    writeFileSync(preflight, JSON.stringify({ pid: 95, startTicks: "203389044" }))
    const result = spawnSync(
      "bash",
      [
        "-c",
        String.raw`
source "$1"
TERMINFO_RUN_ID=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
mux_receipt_target "$2" "$$" "$PPID" "$$" tmux "$BASH" 3.7c "$3" "$4" "terminfo-$TERMINFO_RUN_ID"
`,
        "_",
        launcher,
        preflight,
        config,
        join(dir, "terminfo-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.sock"),
      ],
      { encoding: "utf8" },
    )
    expect(result.status, result.stderr).toBe(0)
    const target = JSON.parse(result.stdout) as Pick<
      LinuxMuxAttachmentProof,
      | "preflightCollector"
      | "collector"
      | "outerShell"
      | "outerTerminal"
      | "config"
      | "executable"
      | "bootId"
      | "mux"
      | "socketPath"
      | "session"
    > & { kind: "mux" }
    const stat = readFileSync("/proc/self/stat", "utf8")
    const parentFields = stat
      .slice(stat.lastIndexOf(")") + 2)
      .trim()
      .split(/\s+/)
    const shell = realpathSync(Bun.which("bash")!)
    expect(target.kind).toBe("mux")
    expect(target.mux).toBe("tmux")
    expect(target.preflightCollector).toEqual({ pid: 95, startTicks: "203389044" })
    expect(target.collector.pid).toBe(result.pid)
    expect(target.collector.startTicks).toMatch(/^\d+$/)
    expect(target.outerShell).toEqual({
      pid: result.pid,
      startTicks: target.collector.startTicks,
      ttyRdev: Number(parentFields[4]),
    })
    expect(target.outerTerminal).toEqual({ pid: process.pid, startTicks: parentFields[19] })
    expect(target.config).toEqual({ path: config, sha256: createHash("sha256").update("").digest("hex") })
    expect(target.executable).toEqual({
      path: shell,
      sha256: createHash("sha256").update(readFileSync(shell)).digest("hex"),
      version: "3.7c",
    })
    expect(target.bootId).toBe(readFileSync("/proc/sys/kernel/random/boot_id", "utf8").trim())
    expect(target.socketPath).toBe(join(dir, "terminfo-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.sock"))
    expect(target.session).toBe("terminfo-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
  },
)

// Registration can precede tmux's status rename (#32226). The existing receipt tests do
// not exercise readiness; use the real poll with only the metadata provider doubled.
it.each(["settles", "never-settles", "missing-receipt"])("owned tmux readiness: %s", (mode) => {
  const daemons = join(dir, "daemons")
  mkdirSync(daemons)
  const runId = "a".repeat(32)
  writeFileSync(join(daemons, "collector.json"), JSON.stringify({ pid: 96, runId, port: 1234, token: "fixture" }))
  const socket = join(dir, "owned.sock")
  if (mode !== "missing-receipt") writeFileSync(join(dir, "mux-socket.txt"), socket + "\n")
  writeFileSync(join(dir, "count"), "0")
  writeFileSync(join(dir, "queries"), "")
  const result = spawnSync(
    "bash",
    [
      "-c",
      [
        'source "$1"',
        "TERMINFO_RUN_ID=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "root=$2 mode=$3",
        "sleep() { :; }",
        "tmux() {",
        '  printf "%s\\n" "$*" >> "$root/queries"',
        '  local count; count=$(cat "$root/count"); count=$((count + 1))',
        '  printf "%s" "$count" > "$root/count"',
        '  if [[ "$mode" == settles && "$count" -ge 3 ]]; then printf "bun|bun\\n"',
        '  elif [[ "$mode" == settles && "$count" == 2 ]]; then printf "bun|bash\\n"',
        '  else printf "tmux|bun\\n"; fi',
        "}",
        'await_owned_daemon "$root/daemons" "$$" 95 "$root/mux-socket.txt"',
      ].join("\n"),
      "_",
      launcher,
      dir,
      mode,
    ],
    { encoding: "utf8" },
  )
  expect(result.status, result.stderr).toBe(mode === "settles" ? 0 : 2)
  const queries = readFileSync(join(dir, "queries"), "utf8").trim().split("\n").filter(Boolean)
  expect(queries).toHaveLength(mode === "settles" ? 3 : mode === "never-settles" ? 150 : 0)
  expect(
    queries.every(
      (query) =>
        query ===
        "-S " + socket + " display-message -p -t terminfo-" + runId + " #{window_name}|#{pane_current_command}",
    ),
  ).toBe(true)
  if (mode === "settles") expect(result.stdout.trim()).toBe(join(daemons, "collector.json"))
  else expect(result.stderr).toContain(mode === "missing-receipt" ? "socket receipt" : "bun|bun")
})

describe("container run receipt composition", () => {
  it("combines host image identity with the matching container measurements", () => {
    const { result, output } = compose()
    expect(result.status).toBe(0)
    const receipt = JSON.parse(readFileSync(output, "utf8")) as {
      runtime: { imageId: string }
      executable: { sha256: string }
      invocation: { path: string; sha256: string }
      receiptInputs: { hostSha256: string; containerSha256: string }
      sourceArtifact: { url: string; path: string; sha256: string }
      collector: { frozenRunnerSha256: string }
      probeRun: { runId: string; sha256: string }
      clipboardFixture: { profile: string; sha256: string }
      sessionBus: { path: string; sha256: string }
    }
    expect(receipt.runtime.imageId).toBe("sha256:image")
    expect(receipt.executable.sha256).toBe("elf-hash")
    expect(receipt.invocation).toEqual({ path: "/nix/store/kitty/bin/kitty", sha256: "wrapper-hash" })
    expect(receipt.receiptInputs.hostSha256).toMatch(/^[0-9a-f]{64}$/)
    expect(receipt.receiptInputs.containerSha256).toMatch(/^[0-9a-f]{64}$/)
    expect(receipt.sourceArtifact).toEqual({
      url: "https://example.invalid/kitty.txz",
      path: "/kitty-source/kitty.txz",
      sha256: "archive-hash",
    })
    expect(receipt.collector.frozenRunnerSha256).toBe("runner-hash")
    expect(receipt.probeRun).toEqual({ path: "v3-capture.json", runId: "b".repeat(32), sha256: "probe-hash" })
    expect(receipt.clipboardFixture).toEqual({ runId: "a".repeat(32), profile: "default", sha256: "fixture-hash" })
    expect(receipt.sessionBus).toEqual({ path: "session-bus.json", sha256: "session-bus-hash" })
  })

  // Accepted: a completed capture binds the final bytes and original container receipt.
  // The old test required sealing and missed completed captures without that marker.
  it("binds final collected bytes while retaining original container input and logical runId", () => {
    const { result } = compose()
    const output = join(dir, "final-receipt.json")
    expect(result.status).toBe(0)
    const containerBytes = readFileSync(join(dir, "container.json"))
    const final = join(dir, "reviewed-final.json")
    const run = {
      source: { kind: "live" },
      schemaVersion: 4,
      runId: "b".repeat(32),
      rawReplies: { "device.primary-da": "exact captured reply" },
    }
    const invoke = (receiptPath = output) =>
      spawnSync(
        "bash",
        [
          "-c",
          'source "$1"; compose_receipt "$2" "$3" "$4" "$5"',
          "_",
          launcher,
          join(dir, "host.json"),
          join(dir, "container.json"),
          receiptPath,
          final,
        ],
        { encoding: "utf8" },
      )
    writeFileSync(final, JSON.stringify(run))
    expect(invoke().status).toBe(0)
    const receipt = JSON.parse(readFileSync(output, "utf8")) as {
      probeRun: { path: string; runId: string; sha256: string }
      receiptInputs: { containerSha256: string }
    }
    expect(receipt.probeRun).toEqual({
      path: "reviewed-final.json",
      runId: run.runId,
      sha256: createHash("sha256").update(readFileSync(final)).digest("hex"),
    })
    expect(receipt.receiptInputs.containerSha256).toBe(createHash("sha256").update(containerBytes).digest("hex"))
    expect(readFileSync(join(dir, "container.json"))).toEqual(containerBytes)
    writeFileSync(final, JSON.stringify({ ...run, runId: "foreign-run" }))
    const foreign = invoke(join(dir, "foreign-receipt.json"))
    expect(foreign.status).toBe(2)
    expect(foreign.stderr).toContain("final runId differs from original captured runId")
  })

  it("refuses a filtered host/container selection mismatch", () => {
    const { result } = compose()
    expect(result.status).toBe(0)
    const host = JSON.parse(readFileSync(join(dir, "host.json"), "utf8")) as { selectedIDs?: string[] }
    const container = JSON.parse(readFileSync(join(dir, "container.json"), "utf8")) as { selectedIDs?: string[] }
    host.selectedIDs = ["cursor.hide"]
    container.selectedIDs = ["reset.decaln"]
    writeFileSync(join(dir, "host.json"), JSON.stringify(host))
    writeFileSync(join(dir, "container.json"), JSON.stringify(container))
    const again = spawnSync(
      "bash",
      [
        "-c",
        'source "$1"; compose_receipt "$2" "$3" "$4"',
        "_",
        launcher,
        join(dir, "host.json"),
        join(dir, "container.json"),
        join(dir, "mismatched.json"),
      ],
      { encoding: "utf8" },
    )
    expect(again.status).toBe(2)
    expect(again.stderr).toContain("selection")
    expect(existsSync(join(dir, "mismatched.json"))).toBe(false)
  })

  it("refuses a missing container half before writing a run receipt", () => {
    const { result, output } = compose("a".repeat(32), false)
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain("Missing container receipt")
    expect(existsSync(output)).toBe(false)
  })

  it("refuses mismatched run IDs before writing a run receipt", () => {
    const { result, output } = compose("b".repeat(32))
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain("runId mismatch")
    expect(existsSync(output)).toBe(false)
  })

  it("refuses collector bytes that differ from the host-measured image input", () => {
    const { result, output } = compose("a".repeat(32), true, "different-runner")
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain("container collector bytes disagree")
    expect(existsSync(output)).toBe(false)
  })

  it("refuses a clipboard profile that differs between host and container", () => {
    const { result, output } = compose("a".repeat(32), true, "runner-hash", "allow")
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain("container clipboard fixture disagrees")
    expect(existsSync(output)).toBe(false)
  })

  // #33305: the focus witness needs a second window, so the receipt must name the owned helper by
  // pid, window id and geometry - a run whose receipt omits it cannot be read as a focused run.
  it("records the owned focus helper window and its geometry", () => {
    const { result, output } = compose("a".repeat(32), true, "runner-hash", "default", undefined, {
      container: DEFAULT_FOCUS_HELPER,
    })
    expect(result.status, result.stderr).toBe(0)
    const receipt = JSON.parse(readFileSync(output, "utf8")) as {
      display: { focusHelper: { pid: number; window: string; geometry: string } }
    }
    expect(receipt.display.focusHelper).toEqual(DEFAULT_FOCUS_HELPER)
  })

  it("refuses a display receipt that never names the owned focus helper window", () => {
    const { result, output } = compose("a".repeat(32), true, "runner-hash", "default", undefined, {
      omitContainerDisplay: true,
    })
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain("focus helper")
    expect(existsSync(output)).toBe(false)
  })

  it("refuses a focus helper named without the window id it was mapped as", () => {
    const { result, output } = compose("a".repeat(32), true, "runner-hash", "default", undefined, {
      container: { pid: 4321, geometry: "Window 6291468 Position: 1600,900 Geometry: 160x60" },
    })
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain("focus helper")
    expect(existsSync(output)).toBe(false)
  })
})

/** The receipt authorizes writing to a terminal, so the container judged by it must not be able
 * to rewrite the copy it is judged against, and the host must be able to prove that afterwards. */
describe("disposable ownership receipt mount", () => {
  it("hands the collector a read-only copy outside the writable output mount and re-tests it after removal", () => {
    const source = readFileSync(launcher, "utf8")
    expect(source).toMatch(/--mount "type=bind,src=\$prep\/receipt,dst=\/receipt,readonly"/)
    expect(source).toMatch(/--env "TERMINFO_DISPOSABLE_RECEIPT=\/receipt\/host-measured\.json"/)
    expect(source).toMatch(/cmp -s "\$raw\/host-measured\.json" "\$prep\/receipt\/host-measured\.json" \|\|/)
  })
})

/** A run whose selection called no capture callback carries no frame. That is a fact about the
 * run, not a failure of it (27875): the launcher records "no frame captured" and carries the run,
 * instead of aborting on a bare `jq -er` exit 2 that named nothing. */
describe("frame-less container run", () => {
  const expression = (() => {
    const source = readFileSync(launcher, "utf8")
    const match = source.match(/capture_frame=\$\(jq -c '([^']*)' \/out\/v3-capture\.json\)/)
    if (!match) throw new Error("frame selection expression not found in scripts/linux-container-run.sh")
    return match[1]!
  })()

  function select(run: unknown) {
    return spawnSync("jq", ["-c", expression], { input: JSON.stringify(run), encoding: "utf8" })
  }

  it("selects null for a run that captured no frame, without failing", () => {
    const result = select({ results: [{ featureId: "device.primary-da" }, { featureId: "reset.ris" }] })
    expect(result.status).toBe(0)
    expect(result.stdout.trim()).toBe("null")
  })

  it("selects the target frame when a probe captured one", () => {
    const frame = { role: "target", ref: `sha256:${"a".repeat(64)}`, sourceRef: `sha256:${"b".repeat(64)}` }
    const result = select({ results: [{ featureId: "cursor.shape", frames: [frame] }] })
    expect(result.status).toBe(0)
    expect(JSON.parse(result.stdout)).toEqual(frame)
  })

  it("records the absence by name and no longer refuses on the bare jq -er", () => {
    const source = readFileSync(launcher, "utf8")
    expect(source).toMatch(/no frame captured: no selected probe called ctx\.capture/)
    expect(source).toMatch(/capture_receipt=null/)
    expect(source).not.toMatch(/png_sha=\$\(jq -er '\[\.observations\[\]\.frames/)
  })

  const selectionExpression = (() => {
    const source = readFileSync(launcher, "utf8")
    const match = source.match(/jq -e --argjson ids "\$selected_ids" '([^']*)' \/out\/v3-capture\.json/)
    if (!match) throw new Error("--ids selection expression not found in scripts/linux-container-run.sh")
    return match[1]!
  })()
  const selected = (requested: string[], actual: string[], statuses: string[]) =>
    spawnSync("jq", ["-e", "--argjson", "ids", JSON.stringify(requested), selectionExpression], {
      input: JSON.stringify({
        rawReplies: { "collector.selection": JSON.stringify({ ids: actual }) },
        results: actual.map((featureId, index) => ({ featureId, status: statuses[index] })),
      }),
      encoding: "utf8",
    })
  // Selection custody must not rewrite an actual capability FAILURE or missing prerequisite TODO.
  // The old diagnostic-based transport refusal discarded that execution-owned status distinction.
  it("retains requested selection when capability results include TODO and FAILURE", () => {
    expect(
      selected(
        ["device.primary-da", "cursor.shape"],
        ["cursor.shape", "device.primary-da"],
        ["probe-todo", "probe-invalid"],
      ).status,
    ).toBe(0)
  })
  it("refuses a changed selection without deriving feature status from it", () => {
    expect(selected(["device.primary-da", "cursor.shape"], ["device.primary-da"], ["supported"]).status).not.toBe(0)
  })

  // 33334: the receipt block ran against the run's first target frame as if its source were always an
  // xwd, so a launch selecting only extensions.osc22-pointer (png-sourced, pointer-composited frames)
  // exited 2 after its probe result was written. Runs the launcher's own block on an owned /out copy.
  function receiptFor(frame: { sourceKind: "xwd" | "png" | "none" }) {
    const source = readFileSync(launcher, "utf8")
    const start = source.indexOf("  capture_frame=$(jq -c")
    const end = source.indexOf("\n  fi\n", start)
    if (start < 0 || end < 0) throw new Error("capture receipt block not found in scripts/linux-container-run.sh")
    const out = join(dir, "out")
    mkdirSync(join(out, "artifacts"), { recursive: true })
    const write = (bytes: string, ext: string) => {
      const sha = createHash("sha256").update(bytes).digest("hex")
      writeFileSync(join(out, "artifacts", `${sha}.${ext}`), bytes)
      return sha
    }
    const pngSha = write("frame png", "png")
    const sourceSha =
      frame.sourceKind === "none"
        ? createHash("sha256").update("absent").digest("hex")
        : write(`source ${frame.sourceKind}`, frame.sourceKind)
    writeFileSync(
      join(out, "v3-capture.json"),
      JSON.stringify({
        results: [
          { featureId: "extensions.osc22-pointer", frames: [{ role: "control", ref: "sha256:x" }] },
          {
            featureId: "extensions.osc22-pointer",
            frames: [{ role: "target", ref: `sha256:${pngSha}`, sourceRef: `sha256:${sourceSha}` }],
          },
        ],
      }),
    )
    const bin = join(dir, "bin")
    mkdirSync(bin, { recursive: true })
    writeFileSync(join(bin, "magick"), "#!/bin/sh\necho stub-identify\n")
    chmodSync(join(bin, "magick"), 0o755)
    const block = source.slice(start, end + "\n  fi\n".length).replaceAll("/out/", `${out}/`)
    const result = spawnSync("bash", ["-c", `set -euo pipefail\n${block}\nprintf '%s' "$capture_receipt"`], {
      encoding: "utf8",
      env: { ...process.env, PATH: `${bin}:${process.env.PATH}` },
    })
    return { result, pngSha, sourceSha }
  }

  it("carries an OSC 22 pointer-only run whose target frame has a png source (33334)", () => {
    const { result, pngSha, sourceSha } = receiptFor({ sourceKind: "png" })
    expect(result.status, result.stderr).toBe(0)
    expect(JSON.parse(result.stdout)).toEqual({
      sourcePng: `artifacts/${sourceSha}.png`,
      sourcePngSha256: sourceSha,
      png: `artifacts/${pngSha}.png`,
      pngSha256: pngSha,
    })
  })

  it("keeps the xwd receipt shape for an xwd-sourced target frame", () => {
    const { result, pngSha, sourceSha } = receiptFor({ sourceKind: "xwd" })
    expect(result.status, result.stderr).toBe(0)
    const receipt = JSON.parse(result.stdout) as Record<string, string>
    expect(Object.entries(receipt)).toEqual([
      ["xwd", `artifacts/${sourceSha}.xwd`],
      ["xwdSha256", sourceSha],
      ["png", `artifacts/${pngSha}.png`],
      ["pngSha256", pngSha],
    ])
  })

  it("refuses by name when the target frame's source artifact is missing", () => {
    const { result, sourceSha } = receiptFor({ sourceKind: "none" })
    expect(result.status).toBe(2)
    expect(result.stderr).toContain(`Callback capture artifacts are missing`)
    expect(result.stderr).toContain(`artifacts/${sourceSha}.xwd or .png`)
  })

  it("composes a frame-less run, whose container receipt carries no capture", () => {
    const { result, output } = compose("a".repeat(32), true, "runner-hash", "default", null)
    expect(result.status).toBe(0)
    const receipt = JSON.parse(readFileSync(output, "utf8")) as { capture: unknown }
    expect(receipt.capture).toBeNull()
  })
})

it.each(["absent", "stale"])("host readback imports from CODE root with %s caller exports", (caller) => {
  const command = readFileSync(launcher, "utf8").match(/^(?:TERMINFO_[A-Z_]+="[^\n]*\n?)+bun [^\n]*-e '[\s\S]*?^'/m)
  if (!command) throw new Error("Host Bun readback command not found in Linux launcher")
  const env = { ...process.env }
  delete env.TERMINFO_PROBE_HASH
  delete env.TERMINFO_SOURCE_REVISION
  if (caller === "stale") {
    env.TERMINFO_PROBE_HASH = "c".repeat(12)
    env.TERMINFO_SOURCE_REVISION = "d".repeat(40)
  }
  // Execute the real finalizer through capture validation; the old environment-only
  // echo hid its relative import failure when the launcher was called from CODE.
  writeFileSync(join(dir, "v3-capture.json"), "{}")
  const result = spawnSync(
    "bash",
    [
      "-c",
      `suite_hash=$1 source_revision=$2 raw=$3 vendor_root=$4
bun() { command bun -e 'console.log(JSON.stringify({probeHash:process.env.TERMINFO_PROBE_HASH,sourceRevision:process.env.TERMINFO_SOURCE_REVISION,raw:process.env.TERMINFO_CAPTURE_RAW,output:process.env.TERMINFO_CAPTURE_OUTPUT}))'; command bun "$@"; }
${command[0]}`,
      "_",
      "a".repeat(12),
      "b".repeat(40),
      dir,
      fileURLToPath(new URL("../", import.meta.url)),
    ],
    { encoding: "utf8", env, cwd: fileURLToPath(new URL("../../../", import.meta.url)) },
  )
  expect(result.status).not.toBe(0)
  expect(result.stderr).toContain("Invalid collector capture; retained original response")
  expect(JSON.parse(result.stdout)).toEqual({
    probeHash: "a".repeat(12),
    sourceRevision: "b".repeat(40),
    raw: join(dir, "v3-capture.json"),
    output: dir,
  })
})

describe("explicit Linux image selection", () => {
  // Different frozen bytes must never share a target/preset image reference.
  // Existing receipt tests do not evaluate either real image producer.
  it.runIf(OWNED_LAYOUT).each(["alacritty-visual-default-image", "kitty-visual-current-image"])(
    "%s gives different frozen bundles different image tags",
    (attribute) => {
      const codeRoot = fileURLToPath(new URL("../../../", import.meta.url))
      const nixEnv = { ...process.env, XDG_CACHE_HOME: join(dir, "nix-cache") }
      const tags = ["first", "second"].map((bytes) => {
        const bundle = join(dir, bytes)
        mkdirSync(bundle)
        writeFileSync(join(bundle, "index.js"), `console.log(${JSON.stringify(bytes)})\n`)
        const hash = spawnSync("nix", ["hash", "path", "--type", "sha256", "--sri", bundle], {
          encoding: "utf8",
          env: nixEnv,
        })
        expect(hash.status, hash.stderr).toBe(0)
        const evaluated = spawnSync(
          "nix",
          ["eval", "--impure", "--raw", `.#packages.x86_64-linux.${attribute}.imageTag`],
          {
            cwd: codeRoot,
            encoding: "utf8",
            env: {
              ...nixEnv,
              TERMINFO_LINUX_RUNNER_DIR: bundle,
              TERMINFO_LINUX_RUNNER_SHA256: hash.stdout.trim(),
            },
            timeout: 60_000,
          },
        )
        expect(evaluated.status, evaluated.stderr).toBe(0)
        expect(evaluated.stdout.trim()).not.toBe("")
        return evaluated.stdout.trim()
      })
      expect(tags[0]).not.toBe(tags[1])
    },
    130_000,
  )

  // A stale preset alias can remain resolvable after load. Only the producer's
  // reference may choose the immutable ID used by the host receipt and create.
  it("selects the frozen producer image when the old preset alias also resolves", () => {
    const root = join(dir, "code")
    const scripts = join(root, "vendor/terminfo.dev/scripts")
    const dist = join(root, "vendor/terminfo.dev/packages/terminfo.dev/dist")
    const cliBin = join(root, "vendor/terminfo.dev/packages/terminfo.dev/bin")
    const source = join(root, "vendor/terminfo.dev/packages/terminfo.dev/src")
    const bins = join(dir, "bin")
    const output = join(dir, "runs")
    const calls = join(dir, "calls.log")
    for (const path of [scripts, dist, cliBin, source, bins]) mkdirSync(path, { recursive: true })
    writeFileSync(join(root, "flake.nix"), "{}")
    writeFileSync(join(root, "bun.lock"), "{}")
    // The image input must carry the Notify recorder the --inside run starts (#33053); the nix double compares it.
    writeFileSync(join(source, "linux-notify-recorder.ts"), "// notify recorder fixture bytes\n")
    writeFileSync(
      join(root, "flake.lock"),
      JSON.stringify({ nodes: { nixpkgs: { locked: { rev: "fixture-nixpkgs" } } } }),
    )
    const fixtureLauncher = join(scripts, "linux-container-run.sh")
    copyFileSync(launcher, fixtureLauncher)
    const frozenBytes = "console.log('fresh frozen collector fixture')\n"
    const revision = "b".repeat(40)
    writeFileSync(join(dist, "terminfo.bundle.mjs"), frozenBytes)
    writeFileSync(
      join(dist, "terminfo.bundle.receipt.json"),
      JSON.stringify({
        schemaVersion: 1,
        probeHash: "a".repeat(12),
        collectorRevision: revision,
        bundleSha256: createHash("sha256").update(frozenBytes).digest("hex"),
      }),
    )
    writeFileSync(join(cliBin, "terminfo.mjs"), `console.log("terminfo fixture (${"a".repeat(12)})")\n`)
    const freshId = `sha256:${"f".repeat(64)}`
    const oldId = `sha256:${"0".repeat(64)}`
    const freshReference = "terminfo-kitty-probe:fixture-frozen-content"
    const freshRunner = "/nix/store/fixture-fresh-terminfo-linux-runner"
    for (const [name, imageId, runner] of [
      ["fresh", freshId, freshRunner],
      ["old", oldId, "/nix/store/fixture-old-terminfo-linux-runner"],
    ]) {
      writeFileSync(
        join(dir, `${name}.json`),
        JSON.stringify([
          {
            Id: imageId,
            Architecture: "amd64",
            Config: {
              Entrypoint: ["/nix/store/fixture-bash/bin/bash", `${runner}/linux-container-run.sh`, "--inside"],
              Labels: {
                "org.hallohuman.terminfo.kitty.preset": "current",
                "org.hallohuman.terminfo.kitty.version": "fixture-1",
                "org.hallohuman.terminfo.kitty.source-url": "https://example.invalid/kitty.txz",
                "org.hallohuman.terminfo.kitty.source-sri": "sha256-fixture",
              },
              Env: [
                "TERMINFO_KITTY_PRESET=current",
                "KITTY_EXPECTED_VERSION=fixture-1",
                "KITTY_SOURCE_URL=https://example.invalid/kitty.txz",
                "KITTY_SOURCE_SRI=sha256-fixture",
                "KITTY_BINARY=/fixture/kitty",
                "KITTY_SOURCE_ARCHIVE=/kitty-source/fixture.txz",
                `TERMINFO_RUNNER=${runner}/index.js`,
              ],
            },
          },
        ]),
      )
    }
    const doubles: Record<string, string> = {
      "@in": `if [[ "$2 $3" == "bun build" ]]; then
  while [[ "$1" != --outdir ]]; do shift; done
  cp "$FIXTURE_ROOT/vendor/terminfo.dev/packages/terminfo.dev/dist/terminfo.bundle.mjs" "$2/terminfo.bundle.js"
fi`,
      git: `case "$*" in *rev-parse*) echo '${revision}';; *status*) ;; *) exit 81;; esac`,
      nix: `case "$1" in
  hash) echo sha256-fixture-bundle;;
  eval)
    [[ "$TERMINFO_LINUX_RUNNER_DIR" == "$(cat "$FIXTURE_HOME/build-runner-dir")" &&
       "$TERMINFO_LINUX_RUNNER_SHA256" == "$(cat "$FIXTURE_HOME/build-runner-hash")" &&
       "$TERMINFO_LINUX_RUNNER_SHA256" == sha256-fixture-bundle &&
       "$4" == "$(cat "$FIXTURE_HOME/build-attribute")" &&
       "$4" == '.#kitty-visual-current-image' ]]
    cmp "$TERMINFO_LINUX_RUNNER_DIR/index.js" "$FIXTURE_ROOT/vendor/terminfo.dev/packages/terminfo.dev/dist/terminfo.bundle.mjs"
    cmp "$TERMINFO_LINUX_RUNNER_DIR/linux-notify-recorder.ts" "$FIXTURE_ROOT/vendor/terminfo.dev/packages/terminfo.dev/src/linux-notify-recorder.ts"
    echo '${freshReference}';;
  build)
    printf '%s' "$TERMINFO_LINUX_RUNNER_DIR" > "$FIXTURE_HOME/build-runner-dir"
    printf '%s' "$TERMINFO_LINUX_RUNNER_SHA256" > "$FIXTURE_HOME/build-runner-hash"
    printf '%s' "$3" > "$FIXTURE_HOME/build-attribute"
    while [[ "$1" != --out-link ]]; do shift; done
    echo fixture-image-archive > "$2";;
  *) exit 82;;
esac`,
      docker: `case "$1 $2" in
  "load --input") echo 'Loaded image: ${freshReference}';;
  "image inspect")
    case "$3" in
      '${freshReference}'|'${freshId}') record="$FIXTURE_HOME/fresh.json";;
      'terminfo-kitty-probe:current'|'${oldId}') record="$FIXTURE_HOME/old.json";;
      *) exit 83;;
    esac
    case "\${5:-}" in '{{.Id}}') jq -r '.[0].Id' "$record";; '{{.Architecture}}') jq -r '.[0].Architecture' "$record";; *) cat "$record";; esac;;
  create*) echo 'fixture docker-create sentinel' >&2; exit 73;;
  *) exit 84;;
esac`,
    }
    for (const [name, body] of Object.entries(doubles)) {
      const path = join(bins, name)
      writeFileSync(
        path,
        `#!/usr/bin/env bash\nset -eu\nprintf '%s %s\\n' "$(basename "$0")" "$*" >> "$CALL_LOG"\n${body}\n`,
      )
      chmodSync(path, 0o755)
    }
    const result = spawnSync(
      "bash",
      [fixtureLauncher, "--target", "kitty", "--preset", "current", "--clipboard-profile", "default", output],
      {
        encoding: "utf8",
        timeout: 15_000,
        env: {
          ...process.env,
          PATH: `${bins}:${process.env.PATH ?? ""}`,
          CALL_LOG: calls,
          FIXTURE_ROOT: root,
          FIXTURE_HOME: dir,
        },
      },
    )
    expect(result.status, result.stderr).toBe(73)
    expect(result.stderr).toContain("fixture docker-create sentinel")
    const runs = readdirSync(output)
    expect(runs).toHaveLength(1)
    const run = join(output, runs[0]!)
    const host = JSON.parse(readFileSync(join(run, "raw/host-measured.json"), "utf8")) as {
      runnerArtifact: { frozenRunnerSha256: string }
      runtime: { imageId: string }
    }
    const image = (
      JSON.parse(readFileSync(join(run, "prep/image-inspect.json"), "utf8")) as {
        Config: { Entrypoint: string[]; Env: string[] }
      }[]
    )[0]!
    expect(host.runnerArtifact.frozenRunnerSha256).toBe(createHash("sha256").update(frozenBytes).digest("hex"))
    expect(host.runtime.imageId).toBe(freshId)
    expect(image.Config.Entrypoint[1]).toBe(`${freshRunner}/linux-container-run.sh`)
    expect(image.Config.Env).toContain(`TERMINFO_RUNNER=${freshRunner}/index.js`)
    expect(readFileSync(calls, "utf8")).toContain(`TERMINFO_IMAGE_ID=${freshId}`)
  })

  it.each([
    ["bogus", "default", "default", "Unknown target"],
    ["kitty", "unknown", "default", "Kitty takes --preset baseline|current"],
    ["xterm", "baseline", "default", "xterm has only the default preset"],
    ["kitty", "current", "unknown", "Unknown clipboard profile"],
  ])("refuses invalid target/preset/profile %s/%s/%s before preparing a run", (target, preset, profile, error) => {
    const result = spawnSync(
      "bash",
      [launcher, "--target", target, "--preset", preset, "--clipboard-profile", profile, dir],
      { encoding: "utf8" },
    )
    expect(result.status).not.toBe(0)
    expect(result.stderr).toContain(error)
    expect(existsSync(join(dir, "prep"))).toBe(false)
  })
})

/** The real launcher must stop after a failed frozen dependency prerequisite, even inside its checked group. */
describe("Linux runner prerequisite failure", () => {
  it("retains the failed install and never invokes CLI build, Nix or Docker afterwards", () => {
    const root = join(dir, "code")
    const scripts = join(root, "vendor/terminfo.dev/scripts")
    const bins = join(dir, "bin")
    const output = join(dir, "runs")
    const calls = join(dir, "calls.log")
    mkdirSync(scripts, { recursive: true })
    mkdirSync(bins)
    writeFileSync(join(root, "flake.nix"), "{}")
    writeFileSync(join(root, "bun.lock"), "{}")
    const fixtureLauncher = join(scripts, "linux-container-run.sh")
    copyFileSync(launcher, fixtureLauncher)
    for (const name of ["@in", "nix", "docker"]) {
      const path = join(bins, name)
      writeFileSync(
        path,
        `#!/usr/bin/env bash
printf '%s %s\n' "$(basename "$0")" "$*" >> "$CALL_LOG"
if [[ "$1 $2 $3" == "-- bun install" ]]; then
  echo "fixture frozen install failed (exit 41)" >&2
  exit 41
fi
exit 0
`,
      )
      chmodSync(path, 0o755)
    }
    const result = spawnSync(
      "bash",
      [fixtureLauncher, "--target", "kitty", "--preset", "current", "--clipboard-profile", "default", output],
      {
        encoding: "utf8",
        env: { ...process.env, PATH: `${bins}:${process.env.PATH ?? ""}`, CALL_LOG: calls },
        timeout: 5_000,
      },
    )
    expect(result.status).toBe(2)
    expect(result.stderr).toContain("fixture frozen install failed (exit 41)")
    expect(result.stderr).toContain("Offline frozen runner build failed; preserved at")
    const run = readdirSync(output)
    expect(run).toHaveLength(1)
    expect(readFileSync(join(output, run[0]!, "prep/bundle-build.log"), "utf8")).toContain(
      "fixture frozen install failed (exit 41)",
    )
    expect(readFileSync(calls, "utf8").trim().split("\n")).toEqual([
      "@in -- bun install --frozen-lockfile --ignore-scripts",
    ])
    expect(existsSync(join(output, run[0]!, "prep/bundle"))).toBe(false)
    expect(existsSync(join(output, run[0]!, "prep/nix-build.log"))).toBe(false)
    expect(existsSync(join(output, run[0]!, "raw/run-receipt.json"))).toBe(false)
  })
})

/** One target's clipboard-profile arguments, from the launcher's own profile case, parsed by bash. */
function clipboardProfileArgs(profile: string, app: string): string[] {
  const source = readFileSync(launcher, "utf8")
  const arm = new RegExp(`\\n {4}${profile}\\)\\n([\\s\\S]*?)\\n {6};;\\n`).exec(source)?.[1]
  const words = new RegExp(`^ {8}${app}\\) target_clipboard_args=\\((.*)\\) ;;$`, "m").exec(arm ?? "")?.[1]
  if (words === undefined) throw new Error(`${profile} ${app} clipboard arguments are missing`)
  const result = spawnSync("bash", ["-c", `args=(${words}); printf '%s\\0' "\${args[@]}"`], { encoding: "utf8" })
  expect(result.status, result.stderr).toBe(0)
  return result.stdout.split("\0").filter(Boolean)
}

/** Runs the launcher's own xterm paste-rebinding check on these arguments: the argument it refuses, or null. */
function pasteRebinding(args: readonly string[]): string | null {
  const result = spawnSync(
    "bash",
    ["-c", 'source "$1"; shift; xterm_paste_rebinding_arg "$@"', "_", launcher, ...args],
    {
      encoding: "utf8",
    },
  )
  return result.status === 0 ? result.stdout.trim() : null
}

// #32164 (@cto 8b9eb7c0): an xterm run owns PRIMARY for Shift+Insert, so the launcher refuses any argument that
// could rebind that paste. The default launch and 33119's read-allowed -xrm must pass the same check they run under.
describe("xterm paste route launch arguments", () => {
  it("passes xterm's default launch and its read-allowed profile, and refuses a rebinding resource", () => {
    const launch = launchArgs("xterm")
    const allow = clipboardProfileArgs("allow", "xterm")
    expect(allow).toEqual(["-xrm", "*disallowedWindowOps: GetChecksum,GetIconTitle,GetWinTitle,SetXprop"])
    expect(pasteRebinding(launch)).toBeNull()
    expect(pasteRebinding([...launch, ...allow])).toBeNull()
    expect(
      pasteRebinding([...launch, ...allow, "-xrm", "*VT100.translations: #override Shift<Key>Insert: string(x)"]),
    ).toBe("*VT100.translations: #override Shift<Key>Insert: string(x)")
    expect(pasteRebinding(["-xrm", "*selectToClipboard: true"])).toBe("*selectToClipboard: true")
  })
})

describe("private finite launch arguments", () => {
  it("refuses an unknown flag before preparing or building", () => {
    const result = spawnSync(
      "bash",
      [launcher, "--target", "kitty", "--preset", "current", "--clipboard-profile", "default", "--unknown", dir],
      { encoding: "utf8" },
    )
    expect(result.status).toBe(2)
    expect(result.stderr).toContain("Unknown flag")
    expect(readdirSync(dir)).toEqual([])
  })

  it.each([
    [[], "Missing --ids value"],
    [[""], "Invalid probe IDs"],
    [["cursor.hide,cursor.hide"], "Invalid probe IDs"],
    [["cursor.hide,"], "Invalid probe IDs"],
    [["cursor.hide", "--ids", "reset.decaln"], "Repeated --ids"],
  ])("refuses invalid supplied filter %j before preparing or building", (suffix, message) => {
    const result = spawnSync(
      "bash",
      [launcher, "--target", "kitty", "--preset", "current", "--clipboard-profile", "default", "--ids", ...suffix, dir],
      { encoding: "utf8" },
    )
    expect(result.status).toBe(2)
    expect(result.stderr).toContain(message)
    expect(readdirSync(dir)).toEqual([])
  })
})

/**
 * @failure The terminal starts before the private bus and Notify recorder are ready, or without the bus in its
 *   environment, or the run leaves the bus or recorder running: notification rows then read from a missing or
 *   foreign observer, or a standing process outlives the run (@cto c6ba9dbb + 7b8360fe).
 * @level l3 — runs the launcher's own session-bus block and cleanup with a real dbus-daemon and the real recorder.
 * @consumer scripts/linux-container-run.sh --inside private session bus (#33053 step 2)
 */
describe("private session bus is held before the terminal starts (#33053)", () => {
  const recorderDirectory = fileURLToPath(new URL("../packages/terminfo.dev/src/", import.meta.url))
  const bun = process.versions.bun !== undefined ? process.execPath : "bun"

  /** The production block from the bus start to the collector exports, with /out and the socket made private. */
  function sessionBusHarness(out: string, socket: string): string {
    const source = readFileSync(launcher, "utf8")
    const cleanupStart = source.indexOf("\n  cleanup() {")
    const cleanupEnd = source.indexOf("\n  trap cleanup EXIT", cleanupStart)
    const start = source.indexOf("\n  # One private session bus per run")
    const end = source.indexOf("\n  export TERMINFO_CAPTURE_DIRECTORY", start)
    const socketLine = "session_bus_socket=/tmp/terminfo-session-bus\n"
    if (cleanupStart < 0 || cleanupEnd < 0 || start < 0 || end < 0 || !source.slice(start, end).includes(socketLine)) {
      throw new Error("session bus block or cleanup not found in scripts/linux-container-run.sh")
    }
    const block = source
      .slice(start, end)
      .replace(socketLine, `session_bus_socket=${socket}\n`)
      .replaceAll("/out/", `${out}/`)
    return `source "$1"
set -euo pipefail
runner_dir=$2
xvfb_pid= focus_helper_pid= helper_pid= primary_helper_pid= session_bus_pid= notify_recorder_pid= daemon_pid= collector_pid=
target_id=kitty
${source.slice(cleanupStart, cleanupEnd)}
trap cleanup EXIT
${block}
printf 'PIDS %s %s\\n' "$session_bus_pid" "$notify_recorder_pid"
# Stands in for the terminal launch: a child of this shell, so it inherits exactly what the terminal would.
dbus-send --session --print-reply --dest=org.freedesktop.DBus /org/freedesktop/DBus \\
  org.freedesktop.DBus.GetNameOwner string:org.freedesktop.Notifications
echo TERMINAL_STARTED
`
  }

  function run(runnerDirectory: string) {
    for (const tool of ["dbus-daemon", "dbus-send"]) {
      const probe = spawnSync(tool, ["--version"], { encoding: "utf8" })
      if (probe.error) throw new Error(`${tool} is required on PATH (D-Bus package): ${probe.error.message}`)
    }
    const out = join(dir, "out")
    mkdirSync(out)
    const result = spawnSync("bash", ["-c", sessionBusHarness(out, join(dir, "bus")), "_", launcher, runnerDirectory], {
      encoding: "utf8",
      timeout: 30_000,
      env: {
        ...process.env,
        HOME: dir,
        PATH: `${dirname(bun)}:${process.env.PATH ?? ""}`,
        TERMINFO_RUN_ID: "a".repeat(32),
        DBUS_SESSION_BUS_ADDRESS: "",
      },
    })
    return { out, result }
  }

  const alive = (pid: number): boolean => {
    try {
      process.kill(pid, 0)
      return true
    } catch {
      return false
    }
  }

  it("holds org.freedesktop.Notifications, exports the bus to the child, records both PIDs, and stops both", () => {
    const { out, result } = run(recorderDirectory)
    expect(result.status, result.stderr).toBe(0)
    expect(result.stdout).toContain("TERMINAL_STARTED")
    const [, busPid, recorderPid] = /^PIDS (\d+) (\d+)$/m.exec(result.stdout)!.map(Number)
    const receiptPath = join(out, "notification-fixture.json")
    const receipt = JSON.parse(readFileSync(receiptPath, "utf8")) as { uniqueName: string; pid: number }
    // The child found the name owner through the inherited address, and that owner is our recorder.
    expect(result.stdout).toContain(`string "${receipt.uniqueName}"`)
    expect(receipt.pid).toBe(recorderPid)
    const record = JSON.parse(readFileSync(join(out, "session-bus.json"), "utf8")) as { address: string }
    const sha = (path: string) => createHash("sha256").update(readFileSync(path)).digest("hex")
    expect(record).toMatchObject({
      runId: "a".repeat(32),
      daemon: { pid: busPid },
      recorder: {
        pid: recorderPid,
        script: { sha256: sha(join(recorderDirectory, "linux-notify-recorder.ts")) },
        receipt: { path: receiptPath, sha256: sha(receiptPath) },
        record: join(out, "notifications.jsonl"),
      },
      nameHeldBeforeTerminal: true,
    })
    expect(record.address).toMatch(new RegExp(`^unix:path=${join(dir, "bus")},`))
    expect(alive(busPid!)).toBe(false)
    expect(alive(recorderPid!)).toBe(false)
  })

  it("never reaches the terminal launch when the recorder exits before holding the name", () => {
    const fake = join(dir, "fake-runner")
    mkdirSync(fake)
    writeFileSync(
      join(fake, "linux-notify-recorder.ts"),
      'console.error("fixture recorder: name already owned"); process.exit(1)\n',
    )
    const { out, result } = run(fake)
    expect(result.status).toBe(2)
    expect(result.stderr).toContain("Notify recorder exited before holding org.freedesktop.Notifications")
    expect(result.stderr).toContain("fixture recorder: name already owned")
    expect(result.stdout).not.toContain("TERMINAL_STARTED")
    expect(existsSync(join(out, "session-bus.json"))).toBe(false)
  })
})

/**
 * @failure cleanup's unbounded wait lets a SIGTERM-ignoring child (kitty / bun collector) keep the
 *   container alive until host `timeout 180 docker start --attach` SIGTERMs it, so a finished batch
 *   is refused as exit 143.
 * @level l1 — sources the launcher and SIGKILLs an owned sleep that traps TERM.
 * @consumer scripts/linux-container-run.sh stop_owned_processes (#28552)
 */
describe("owned process stop does not wait out the attach budget (#28552)", () => {
  it("SIGKILLs a child that ignores SIGTERM and returns before the 180 s attach budget", () => {
    const result = spawnSync(
      "bash",
      [
        "-c",
        `source "$1"
set -euo pipefail
bash -c 'trap "" TERM; exec sleep 30' &
pid=$!
start=$(date +%s%N)
TERMINFO_STOP_GRACE_SEC=1 stop_owned_processes "$pid"
elapsed_ms=$(( ( $(date +%s%N) - start ) / 1000000 ))
if kill -0 "$pid" 2>/dev/null; then
  echo STILL_ALIVE
  kill -KILL "$pid" 2>/dev/null || true
  wait "$pid" 2>/dev/null || true
  exit 2
fi
echo DEAD
echo ELAPSED_MS=$elapsed_ms
[[ "$elapsed_ms" -lt 5000 ]]
`,
        "_",
        launcher,
      ],
      { encoding: "utf8", timeout: 8_000 },
    )
    expect(result.status).toBe(0)
    expect(result.stdout).toContain("DEAD")
    expect(result.stdout).not.toContain("STILL_ALIVE")
  })
})

/**
 * @failure host attach exit 143 discards observed.json + container-receipt.json + v3-capture.json that
 *   the completed batch already wrote, so a 7.5 s kitty run is unusable.
 * @level l1 — sources completed_batch_survives_attach_timeout against owned temp receipts.
 * @consumer scripts/linux-container-run.sh host attach failure branch (#28552)
 */
describe("completed batch survives attach SIGTERM (#28552)", () => {
  it("treats exit 143 as a completed run only when the three batch receipts are present", () => {
    const raw = join(dir, "raw")
    mkdirSync(raw)
    writeFileSync(join(raw, "observed.json"), "{}\n")
    writeFileSync(join(raw, "container-receipt.json"), "{}\n")
    writeFileSync(join(raw, "v3-capture.json"), "{}\n")
    const completed = spawnSync(
      "bash",
      ["-c", 'source "$1"; completed_batch_survives_attach_timeout 143 "$2"', "_", launcher, raw],
      { encoding: "utf8" },
    )
    expect(completed.status).toBe(0)
    const other = spawnSync(
      "bash",
      ["-c", 'source "$1"; completed_batch_survives_attach_timeout 1 "$2"', "_", launcher, raw],
      { encoding: "utf8" },
    )
    expect(other.status).not.toBe(0)
    rmSync(join(raw, "observed.json"))
    const missing = spawnSync(
      "bash",
      ["-c", 'source "$1"; completed_batch_survives_attach_timeout 143 "$2"', "_", launcher, raw],
      { encoding: "utf8" },
    )
    expect(missing.status).not.toBe(0)
  })
})

describe("in-image source archive proof", () => {
  it("refuses a wrong declared flat hash for either proof kind through one comparison", () => {
    // A matching real run can never exercise a mismatch, so it is proven here: the derived kind and
    // the flat kind reach this SAME comparison, and a wrong pin or a missing declared hash is refused
    // (@cto 2026-10-06, 27892).
    const archive = join(dir, "derived-source-tar")
    writeFileSync(archive, "derived tar bytes\n")
    const digest = createHash("sha256").update(readFileSync(archive)).digest()
    const sri = (bytes: Buffer) => `sha256-${bytes.toString("base64")}`
    const check = (measured: string, declared: string) =>
      spawnSync(
        "bash",
        [
          "-c",
          'source "$1"; verify_source_archive_hash "$2" "$3" "Loaded ghostty source"',
          "_",
          launcher,
          measured,
          declared,
        ],
        { encoding: "utf8" },
      )
    expect(check(digest.toString("hex"), sri(digest)).status).toBe(0)
    const mismatch = check(digest.toString("hex"), sri(createHash("sha256").update("another tar").digest()))
    expect(mismatch.status).toBe(2)
    expect(mismatch.stderr).toContain("Loaded ghostty source archive differs from declared fixed hash")
    const undeclared = check(digest.toString("hex"), "")
    expect(undeclared.status).toBe(2)
    expect(undeclared.stderr).toContain("Loaded ghostty source has no declared flat sha256")
  })
})

describe("cli producer receipt gate", () => {
  const receipt = (overrides: Record<string, unknown> = {}) => ({
    schemaVersion: 1,
    probeHash: "a".repeat(12),
    collectorRevision: "b".repeat(40),
    bundleSha256: "d".repeat(64),
    ...overrides,
  })
  const gate = (value: unknown, cliBin?: string) => {
    const file = join(dir, "cli-receipt.json")
    writeFileSync(file, JSON.stringify(value))
    return spawnSync(
      "bash",
      [
        "-c",
        'source "$1"; require_cli_producer_receipt "$2" "${3:-}"',
        "_",
        launcher,
        file,
        ...(cliBin ? [cliBin] : []),
      ],
      {
        encoding: "utf8",
      },
    )
  }

  it("accepts a live-identity producer receipt and prints its suite hash", () => {
    const result = gate(receipt())
    expect(result.status).toBe(0)
    expect(result.stdout.trim()).toBe("a".repeat(12))
  })

  it("refuses when the CLI bundle reports a suite hash that disagrees with the producer receipt", () => {
    const fakeCli = join(dir, "fake-terminfo.mjs")
    writeFileSync(fakeCli, `console.log("4.0.0 (${"f".repeat(12)})")\n`)
    const result = gate(receipt(), fakeCli)
    expect(result.status).toBe(2)
    expect(result.stderr).toContain(
      `CLI bundle suite ${"f".repeat(12)} differs from producer receipt ${"a".repeat(12)}`,
    )
  })

  it("still refuses a malformed producer receipt generically", () => {
    const result = gate(receipt({ bundleSha256: "short" }))
    expect(result.status).toBe(2)
    expect(result.stderr).toContain("Invalid CLI producer receipt")
  })
})

/**
 * @failure xterm 411's 1304x814 window is larger than the Xvfb screen, so whole-window rgba is
 *   the screen (1024x768x4 = 3145728 bytes) and the collector errors instead of grading.
 * @level l1 — reads the launcher's Xvfb -screen geometry, the production display size.
 * @consumer scripts/linux-container-run.sh Xvfb screen vs launched xterm window (#28580)
 */
describe("Xvfb screen fits the launched xterm window (#28580)", () => {
  it("is large enough that a 1304x814 window is fully on-screen", () => {
    // xterm 411 -fs 16 -geometry 100x30 measured 1304x814 on the S+1 tree. 1024x768 clips xwd
    // to exactly 3145728 bytes (1024*768*4), which 28580 read as a 3 MiB capture buffer.
    const source = readFileSync(launcher, "utf8")
    const match = /Xvfb\b[^\n]*-screen 0 (\d+)x(\d+)x(\d+)/.exec(source)
    if (!match) throw new Error("Xvfb -screen geometry not found in scripts/linux-container-run.sh")
    expect(Number(match[1])).toBeGreaterThanOrEqual(1304)
    expect(Number(match[2])).toBeGreaterThanOrEqual(814)
  })
})

/**
 * @failure xterm renders with Xft antialiasing, so a plainly painted frame carries one more
 *   partial-coverage edge pixel than the same frame reached by an edit sequence; the exact-digest
 *   oracle then reads a one-pixel residual (255,255,255 vs 239,239,239) and cannot classify
 *   editing.decdc / editing.decic / editing.sl.
 * @level l1 — reads the launcher's xterm launch args, the production rendering context.
 * @consumer scripts/linux-container-run.sh xterm rendering pin (#28829)
 */
describe("xterm rendering is pinned AND RECORDED so a repaint is byte-exact (#28829)", () => {
  it("launches xterm with Xft antialiasing off, same font and geometry, and records the pin", () => {
    const source = readFileSync(launcher, "utf8")
    const start = source.indexOf("\n    xterm)")
    if (start < 0) throw new Error("xterm case not found in scripts/linux-container-run.sh")
    const xtermCase = source.slice(start, source.indexOf("parse_version", start))
    expect(xtermCase).toContain("-fa 'DejaVu Sans Mono'")
    expect(xtermCase).toContain("-fs 16 -geometry 100x30")
    expect(xtermCase).toContain("-xrm 'Xft.antialias: false'")
    // The pin must be RECORDED, not only applied: the run's context states it so an old run (which
    // carries no render key) is told apart from a new one. CTO O1: pin AND record.
    expect(xtermCase).toContain("target_render_pin=xft-antialias-off")
    expect(source).toContain("--arg render ")
    expect(source).toMatch(/context:"linux-x86_64-xvfb-llvmpipe"[^\n]*render:\$render/)
  })
})

/**
 * @failure split 120s curl / 180s attach budgets kill slow-but-complete groups (ghostty 140.6s,
 *   xterm 157.9s curl-28; wezterm attach-killed at 177s) so Candidate 2 rows go missing.
 *   A full WezTerm batch also progressed until the shared 600s SIGTERM on 2026-11-04 and 1200s
 *   SIGTERM (1196.9s solo App batch, exit 143) on 2026-11-09 (#32889).
 * @level l1 — reads the launcher's declared probe-batch timeout.
 * @consumer scripts/linux-container-run.sh PROBE_BATCH_TIMEOUT_SECONDS (@dev/3 51326e54)
 */
describe("declared probe-batch timeout is one value for curl and host attach", () => {
  it("uses PROBE_BATCH_TIMEOUT_SECONDS=1800 for both curl --max-time and docker start --attach", () => {
    const source = readFileSync(launcher, "utf8")
    expect(source).toMatch(/^PROBE_BATCH_TIMEOUT_SECONDS=1800$/m)
    expect(source).toMatch(/curl [^\n]*--max-time "\$PROBE_BATCH_TIMEOUT_SECONDS"/)
    expect(source).toMatch(/timeout "\$PROBE_BATCH_TIMEOUT_SECONDS" docker start --attach/)
    expect(source).not.toMatch(/--max-time 120\b/)
    expect(source).not.toMatch(/timeout 180 docker start --attach/)
  })
})

// Raw finalization owns this decision; receipt-only tests never execute it with a valid capture.
it.each([false, true])("writes a Linux completion receipt for captured bytes, pending=%s", (pending) => {
  const source = readFileSync(launcher, "utf8")
  const command = source.match(/^(?:TERMINFO_[A-Z_]+="[^\n]*\n?)+bun [^\n]*-e '[\s\S]*?^'/m)
  if (!command) throw new Error("Host Bun readback command not found")
  const receiptStart = source.indexOf('compose_receipt "$raw/host-measured.json"')
  if (receiptStart < 0) throw new Error("Host receipt completion block not found")
  const receiptTail = source.slice(receiptStart)
  const suite = probeSuiteSnapshot()
  const manifest = derivedSuiteManifest(suite)
  const revision = spawnSync("git", ["rev-parse", "HEAD"], {
    cwd: fileURLToPath(new URL("../", import.meta.url)),
    encoding: "utf8",
  }).stdout.trim()
  const subject = {
    kind: "term" as const,
    id: "kitty",
    version: "0.49.1",
    os: "linux",
    osVersion: null,
    outerTerminal: null,
    mux: null,
    config: null,
    permissions: null,
  }
  const capture = {
    ...initializeRunDraft({
      runId: "a".repeat(32),
      manifest,
      sourceRevision: revision,
      source: { kind: "live" },
      intendedSubject: subject,
    }),
    subject,
    identity: "unverified",
    measuredAt: "2026-11-02T12:00:00.000Z",
    origin: { kind: "collector" },
    screenshotRefs: [],
  }
  if (pending) {
    capture.results.find((row) => row.featureId === "device.primary-da")!.tests = [
      { id: "review", status: "probe-todo", attempt: { scope: "none" }, reason: "Required context review pending" },
    ]
  }
  writeFileSync(join(dir, "v3-capture.json"), JSON.stringify(capture))
  const prepared = compose()
  expect(prepared.result.status).toBe(0)
  rmSync(prepared.output)
  copyFileSync(join(dir, "host.json"), join(dir, "host-measured.json"))
  const container = {
    runId: capture.runId,
    invocation: { path: "/nix/store/kitty/bin/kitty", sha256: "wrapper-hash" },
    executable: { path: "/nix/store/kitty/bin/.kitty-wrapped", version: "kitty 0.49.1", sha256: "elf-hash" },
    sourceArtifact: { path: "/kitty-source/kitty.txz", sha256: "archive-hash" },
    collector: { frozenRunnerSha256: "runner-hash", buildReceiptSha256: "receipt-hash" },
    probeRun: {
      path: "v3-capture.json",
      runId: capture.runId,
      sha256: createHash("sha256")
        .update(readFileSync(join(dir, "v3-capture.json")))
        .digest("hex"),
    },
    display: { glxinfo: "llvmpipe", geometry: "WIDTH=800", focusHelper: DEFAULT_FOCUS_HELPER },
    clipboardFixture: { runId: capture.runId, profile: "default", sha256: "fixture-hash" },
    capture: null,
  }
  writeFileSync(join(dir, "container-receipt.json"), JSON.stringify(container))
  // Only bypass dirty-checkout discovery: capture decoding and finalization remain real.
  const fixtureCommand = command[0].replace(
    "-e '",
    `-e 'import {mock} from "bun:test"; mock.module("./packages/terminfo.dev/src/serve.ts",()=>({getTrustedSuiteReceipt:()=>JSON.parse(process.env.FIXTURE_RECEIPT)}));`,
  )
  const result = spawnSync(
    "bash",
    [
      "-c",
      `set -e\nsource "$5"\nsuite_hash=$1 source_revision=$2 raw=$3 run_dir=$3 vendor_root=$4\n${fixtureCommand}\n${receiptTail}`,
      "_",
      suite.probeHash,
      revision,
      dir,
      fileURLToPath(new URL("../", import.meta.url)),
      launcher,
    ],
    {
      encoding: "utf8",
      env: { ...process.env, FIXTURE_RECEIPT: JSON.stringify({ manifest, collectorRevision: revision }) },
    },
  )
  expect(result.status, result.stderr).toBe(0)
  expect(readdirSync(dir), `${result.stdout}\n${result.stderr}`).toContain("v3-run.draft.json")
  expect(existsSync(join(dir, "v3-run.json"))).toBe(false)
  const savedPath = join(dir, "v3-run.draft.json")
  const saved = JSON.parse(readFileSync(savedPath, "utf8")) as CapturedRunDraft
  expect(JSON.parse(readFileSync(join(dir, "run-receipt.json"), "utf8"))).toMatchObject({
    probeRun: {
      path: "v3-run.draft.json",
      runId: capture.runId,
      sha256: createHash("sha256").update(readFileSync(savedPath)).digest("hex"),
    },
    receiptInputs: {
      hostSha256: createHash("sha256")
        .update(readFileSync(join(dir, "host-measured.json")))
        .digest("hex"),
      containerSha256: createHash("sha256")
        .update(readFileSync(join(dir, "container-receipt.json")))
        .digest("hex"),
    },
  })
  expect(container.probeRun.sha256).toBe(
    createHash("sha256")
      .update(readFileSync(join(dir, "v3-capture.json")))
      .digest("hex"),
  )
  expect(result.stderr).toContain("Collected current schema-4 run")
  if (pending) {
    expect(saved.results.find((row) => row.featureId === "device.primary-da")?.tests).toContainEqual({
      id: "review",
      status: "probe-todo",
      attempt: { scope: "none" },
      reason: "Required context review pending",
    })
  }
})

// #32751: projected from retained tmux capture 76a2e18a19dfef55d3e1ad3191450ca7.
// Run the production admission, not a second predicate; no container or window starts.
const retainedTmuxAdmission = {
  schemaVersion: 4,
  runId: "76a2e18a19dfef55d3e1ad3191450ca7",
  subject: {
    kind: "mux",
    id: "tmux",
    version: "3.8",
    os: "linux",
    osVersion: "7.0.0-34-generic",
    outerTerminal: "kitty",
    mux: "tmux",
    config: "/out/mux-empty.conf",
    permissions: null,
  },
  identity: "verified",
  origin: {
    kind: "collector",
  },
  probeHash: "c189fc171f0b",
  suiteId: "c189fc171f0b",
  sourceRevision: "6862bb5d1e761ba5e90a4bd31917d7919ee21702",
  outerApp: {
    subject: {
      id: "kitty",
    },
    provenance: {
      executable: {
        path: "/nix/store/fbpk67n6fd9kb95vl7ksrc7pkh3gx3qx-kitty-official-binary-0.49.2/bin/kitty",
        sha256: "bb65c2d57e56eecca8143d73771432cf7dd386bccd36ae658950e5923a661886",
        version: "kitty 0.49.2 created by Kovid Goyal",
      },
    },
  },
  rawReplies: {
    "collector.identityCheck":
      '{"ok":true,"checked":true,"executable":{"path":"/nix/store/k111lnbq1vw0k4v4cjhi1iwp5lky3ryn-tmux-3.8/bin/tmux","sha256":"da3d96d5d01388873e01b326b7c7be219c9c382b976f726811cb1f7cf054e379","version":"3.8"}}',
  },
  assertions: [],
  results: [],
}

it.each(["verified", "unverified", "missing", "malformed", "bad-hash", "not-ok", "wrong-target"])(
  "enforces canonical unverified collector drafts for retained tmux %s",
  (scenario) => {
    const capture = structuredClone(retainedTmuxAdmission)
    if (scenario === "unverified") capture.identity = "unverified"
    if (scenario === "missing") Reflect.deleteProperty(capture.rawReplies, "collector.identityCheck")
    if (scenario === "malformed") capture.rawReplies["collector.identityCheck"] = "{broken"
    if (scenario === "bad-hash" || scenario === "not-ok") {
      const identity = JSON.parse(capture.rawReplies["collector.identityCheck"]) as {
        ok: boolean
        executable: { sha256: string }
      }
      if (scenario === "bad-hash") identity.executable.sha256 = "short"
      else identity.ok = false
      capture.rawReplies["collector.identityCheck"] = JSON.stringify(identity)
    }
    if (scenario === "wrong-target") {
      capture.identity = "unverified"
      capture.outerApp.subject.id = "xterm"
    }
    const raw = join(dir, "retained-capture.json"),
      build = join(dir, "build.json")
    writeFileSync(raw, JSON.stringify(capture))
    writeFileSync(
      build,
      JSON.stringify({
        probeHash: capture.probeHash,
        collectorRevision: capture.sourceRevision,
      }),
    )
    const source = readFileSync(launcher, "utf8")
    const start = source.indexOf('  jq -e --slurpfile build "$build_receipt"')
    const end = source.indexOf("  probe_run_id=", start)
    if (start < 0 || end < 0) throw new Error("Production capture admission block is missing")
    const admission = source.slice(start, end).replaceAll("/out/v3-capture.json", '"$capture"')
    const executable = capture.outerApp.provenance.executable
    const result = spawnSync(
      "bash",
      [
        "-c",
        `set -euo pipefail
build_receipt=$1 capture=$2 live_executable=$3 live_executable_sha=$4
target_id=kitty TERMINFO_MUX_KIND=tmux
${admission}`,
        "_",
        build,
        raw,
        executable.path,
        executable.sha256,
      ],
      { encoding: "utf8" },
    )
    expect(result.status, result.stderr).toBe(scenario === "unverified" ? 0 : 2)
    if (scenario === "wrong-target") expect(result.stderr).toContain("named a target other than kitty")
    else if (scenario !== "unverified") {
      expect(result.stderr).toContain("invalid schema-4 capture")
      expect(result.stderr).not.toContain("named a target other than")
    }
  },
)

/** The launcher's own mux-profile function, sourced: the config it records, or its refusal. */
function muxProfileConfig(mux: string, profile: string): { status: number | null; stdout: string; stderr: string } {
  const result = spawnSync("bash", ["-c", 'source "$1"; mux_profile_config "$2" "$3"', "_", launcher, mux, profile], {
    encoding: "utf8",
  })
  return { status: result.status, stdout: result.stdout.trim(), stderr: result.stderr.trim() }
}

// #33151 (@cto a2cb755c, 4a546051): the supplement keys a placed Screen run on the config the launcher records, so the
// two values live in the launcher and in context-supplements.ts and must stay equal; truecolor elsewhere is refused.
describe("mux profile configs", () => {
  it("records the default config and Screen's truecolor config exactly as the selection keys them", () => {
    expect(muxProfileConfig("screen", "default")).toMatchObject({ status: 0, stdout: MUX_DEFAULT_CONFIG })
    expect(muxProfileConfig("tmux", "default")).toMatchObject({ status: 0, stdout: MUX_DEFAULT_CONFIG })
    expect(muxProfileConfig("screen", "truecolor")).toMatchObject({ status: 0, stdout: SCREEN_TRUECOLOR_CONFIG })
    expect(TRUECOLOR_ON.config).toEqual({ screen: SCREEN_TRUECOLOR_CONFIG })
  })

  it("refuses truecolor on any mux but Screen, naming the mux and the profile", () => {
    expect(muxProfileConfig("tmux", "truecolor")).toMatchObject({
      status: 2,
      stderr: "mux profile truecolor has no declared option on mux tmux",
    })
    expect(muxProfileConfig("", "truecolor")).toMatchObject({
      status: 2,
      stderr: "mux profile truecolor has no declared option on mux (none)",
    })
  })

  // The placement check accepts Screen's truecolor label only when the receipt's config hash matches the declared
  // bytes, so the bytes the launcher writes and MUX_PROFILE_CONFIG_FILES must be the same.
  it("writes truecolor on after the unchanged default line, exactly the bytes the receipt check declares", () => {
    const content = (profile: string) =>
      spawnSync("bash", ["-c", 'source "$1"; screen_config_content "$2"', "_", launcher, profile], { encoding: "utf8" })
    expect(content("default")).toMatchObject({ status: 0, stdout: "defscrollback 1000\n" })
    expect(content("truecolor")).toMatchObject({
      status: 0,
      stdout: MUX_PROFILE_CONFIG_FILES[SCREEN_TRUECOLOR_CONFIG]?.content,
    })
    expect(MUX_PROFILE_CONFIG_FILES[SCREEN_TRUECOLOR_CONFIG]?.mux).toBe("screen")
    expect(readFileSync(launcher, "utf8")).toContain(
      'screen_config_content "${TERMINFO_MUX_PROFILE:-default}" > "$mux_config"',
    )
  })
})

/**
 * @failure The owned focus helper's mapping wait aborts the run on its first unmapped read: `xdotool search`
 *   exits 1 until the window exists, and a bare assignment from that pipeline ends the launcher under `set -e`,
 *   so the App run exits 1 with an empty helper log instead of waiting for the window (33305 App run
 *   2026-11-11T05-48Z stopped exactly there).
 * @level l3 — runs the launcher's own focus-helper block with real bash, a stub xterm and a stub xdotool that
 *   reports no window twice before it maps one.
 * @consumer scripts/linux-container-run.sh --inside focus helper mapping (#33305)
 */
describe("focus helper waits for its window instead of aborting the run (#33305)", () => {
  it("retries while xdotool reports no window yet, then exports the mapped window", () => {
    const source = readFileSync(launcher, "utf8")
    const start = source.indexOf("\n  xterm -geometry 20x3-0-0 -e sleep 36000")
    const end = source.indexOf("\n  baseline_path=", start)
    if (start < 0 || end < 0) throw new Error("focus helper block not found in scripts/linux-container-run.sh")
    const out = mkdtempSync(join(tmpdir(), "focus-helper-"))
    const bin = join(out, "bin")
    mkdirSync(bin)
    const counter = join(out, "search-count")
    writeFileSync(counter, "0")
    writeFileSync(join(bin, "xterm"), '#!/usr/bin/env bash\necho $$ > "$HOME/xterm-pid"\nexec sleep 30\n', {
      mode: 0o755,
    })
    writeFileSync(
      join(bin, "xdotool"),
      `#!/usr/bin/env bash
if [[ "$1" == "search" ]]; then
  n=$(cat "${counter}")
  n=$((n + 1))
  echo "$n" > "${counter}"
  if (( n < 3 )); then exit 1; fi
  echo 4242
  exit 0
fi
if [[ "$1" == "getwindowgeometry" ]]; then echo "WIDTH=160"; echo "HEIGHT=40"; exit 0; fi
exit 2
`,
      { mode: 0o755 },
    )
    const block = source.slice(start, end).replaceAll("/out/", `${out}/`)
    const script = `set -euo pipefail\n${block}\nprintf 'HELPER %s %s\\n' "$TERMINFO_FOCUS_HELPER_WINDOW" "$TERMINFO_FOCUS_HELPER_PID"\n`
    const result = spawnSync("bash", ["-c", script], {
      encoding: "utf8",
      env: { ...process.env, PATH: `${bin}:${process.env.PATH ?? ""}`, HOME: out },
    })
    expect(result.stderr).toBe("")
    expect(result.status).toBe(0)
    const [label, helperWindow, helperPid] = result.stdout.trim().split(/\s+/)
    expect(label).toBe("HELPER")
    expect(helperWindow).toBe("4242")
    // The exported PID must be the helper process itself, not merely a number: the capture gate
    // refuses any helper window whose getwindowpid differs from it.
    expect(helperPid).toBe(readFileSync(join(out, "xterm-pid"), "utf8").trim())
    expect(Number(readFileSync(counter, "utf8"))).toBe(3)
  })
})
