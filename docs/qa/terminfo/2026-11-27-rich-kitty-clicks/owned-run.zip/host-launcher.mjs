import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { acquireDesktopLease, desktopLockAuditPath } from '../../../scripts/terminfo/desktop-lock.mjs';

const container = 'ntilde-kitty-click-qualification';
const run = args => spawnSync('docker', ['exec', container, ...args], { stdio: 'inherit' });
const lease = await acquireDesktopLease({ entrypoint: 'kitty-click-docker-collection', worktree: process.cwd(), waitMs: 300000 });
let result;
try {
    lease.noteLaunchAttempt();
    result = run(['/opt/node-v24.22.2-linux-arm64/bin/node', 'scripts/terminfo-modern-x11-owned.mjs',
        '/opt/ntilde-kitty-click-width/Ntilde', '0.14.0+6054e9a8dd925acb6fc227b2aef0a987d77f5428', '--rich-kitty-clicks']);
} finally {
    const cleanup = run(['/bin/bash', '-c', 'test ! -e /root/.ntilde-qa-sidecars/.desktop-collection.lock && ! ps -axww -o args= | grep -E "[n]tilde-terminfo-(owner|worker|private-clipboard)=|^/usr/bin/[X]vfb"']);
    if (cleanup.status !== 0) {
        lease.retain('Inner X11 cleanup remains unverified');
        throw new Error('Batch desktop lock retained');
    }
    await lease.verifyCleanup();
    lease.release();
    const audit = readFileSync(desktopLockAuditPath(lease.lockPath), 'utf8').trimEnd().split('\n')
        .map(line => JSON.parse(line)).filter(event => event.lease === lease.leaseId);
    writeFileSync('artifacts/terminfo/kitty-click-batch/host-lease-' + lease.leaseId + '.json', JSON.stringify(audit, null, 2) + '\n');
}
process.exitCode = result.status ?? 1;
