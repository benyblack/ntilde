// Worker-side driver for the runtime-color reset qualification (extensions.osc104-reset-palette, osc110-reset-fg, osc111-reset-bg and
// osc112-reset-cursor). Replays each case's exact plan through the owned fence over the shared fenced-query machinery: every experiment's
// scene, then the PINNED bytes (BEL spelling) and the graded controls. A query step is one fenced exchange that retains the raw OSC reply
// (or its explicit absence) before the DA barrier; every read is journaled by the parent observer with the replies asked since the
// previous read. The pinned termless probe then runs over the three replies of its own pinned experiment. Runtime colors are
// session-wide and survive both the alternate-screen exit and DECSTR, so the finish write clears them explicitly; after a fatal input
// error only a bounded best-effort write is attempted, which can neither revive the fence nor establish restoration.
import { collectFencedQueryGrading } from './graded-plan.mjs';
import { colorResetContracts, colorResetNoncePrefix, colorResetBind, colorResetFinish, colorResetFeeds, colorResetReads, validateColorResetScreen } from './color-reset-contracts.mjs';

/** Serve the journaled replies of the pinned experiment to the pinned termless probe, cross-checking that the pinned code itself issues
 * exactly the contracted bytes, each as the contracted kind (a capture or a plain feed), in order, and nothing else. */
export function colorResetRecordingContext(contract, replies) {
    let fed = 0, captured = 0;
    const expect = (text, kind) => {
        if (fed >= contract.pinnedFeeds.length || text !== contract.pinnedFeeds[fed] || kind !== contract.pinnedKinds[fed]) {
            throw new Error(`Pinned ${contract.caseId} feed ${fed} differs from the contract.`);
        }
        fed++;
    };
    return {
        get fedCount() { return fed; },
        feed: text => expect(text, 'feed'),
        feedCapture: text => {
            expect(text, 'capture');
            return replies[captured++]?.raw ?? '';
        },
        getCell: () => { throw new Error(`Pinned ${contract.caseId} probe must not read cells.`); },
        getCursor: () => { throw new Error(`Pinned ${contract.caseId} probe must not read the cursor.`); },
        getText: () => { throw new Error(`Pinned ${contract.caseId} probe must not read text.`); },
    };
}

/** The replies of the pinned experiment's reads, in order: the original, the changed and the restored query of the pinned code. */
export function pinnedReplies(contract, reads) {
    return contract.pinnedRoles.map(role => reads[contract.roles.indexOf(role)].queries[0].reply);
}

/** The pinned result of one collected case: the pinned code runs over the three replies of its own pinned experiment, and its
 * consumption must be exactly the contracted five feeds (the probe may legitimately stop after the first capture when the
 * original reply is missing or malformed — that inconclusive is retained, any other early stop is an incomplete fixture). */
function pinnedResultOf(contract, item, gradingModule) {
    const replies = pinnedReplies(contract, item.reads);
    const context = colorResetRecordingContext(contract, replies);
    const pinned = gradingModule.ntildeRunColorResetTermless(contract.caseId, context);
    const stopped = context.fedCount === 1 && pinned.observation?.outcome === 'inconclusive' && ['no-response', 'invalid-reply'].includes(pinned.observation.reason);
    if (!stopped && context.fedCount !== contract.pinnedFeeds.length) throw new Error(`Pinned ${contract.caseId} did not replay its complete fixture.`);
    return pinned;
}


export async function collectColorResetGrading({ config, fence, owner, gradingModule }) {
    const adapter = gradingModule.ntildeColorResetAdapter;
    return collectFencedQueryGrading({ contracts: colorResetContracts, feedsOf: colorResetFeeds, readsOf: colorResetReads,
        validateScreen: validateColorResetScreen, prefix: 'crst', noncePrefix: colorResetNoncePrefix, bind: colorResetBind,
        finish: colorResetFinish, label: 'runtime-color', fence, owner, adapter, config,
        pinnedOf: (contract, item) => pinnedResultOf(contract, item, gradingModule) });
}
