import { createPrivateClipboardWorker } from "file:///private/var/folders/y_/56y55kgx31qd7x6nf0vm50l00000gn/T/ntilde-owned-sources-Mdti7M/scripts/terminfo/private-clipboard-worker.mjs";
import { verifyNtildeOutput as ntildeVerifyOutput, requestOwner as ntildePrivateOwnerRequest } from "file:///private/var/folders/y_/56y55kgx31qd7x6nf0vm50l00000gn/T/ntilde-owned-sources-Mdti7M/scripts/terminfo/ownership.mjs";
// Upstream CLI shebang removed for module import.
// @bun
var __esm = (fn, res, err) => () => {
  if (fn)
    try {
      res = fn(fn = 0);
    } catch (e) {
      err = [e];
    }
  if (err)
    throw err[0];
  return res;
};

// ../probe-defs/src/types.ts
function isNonMeasuringEvidence(evidence) {
  return NON_MEASURING_EVIDENCE.has(evidence);
}
var OBSERVATION_OUTCOMES, OBSERVATION_REASONS, OBSERVATION_EVIDENCE, NON_MEASURING_EVIDENCE;
var init_types = __esm(() => {
  OBSERVATION_OUTCOMES = ["supported", "unsupported", "inconclusive", "error"];
  OBSERVATION_REASONS = [
    "no-response",
    "timeout",
    "permission",
    "policy-refused",
    "collector-error",
    "invalid-reply",
    "insufficient-evidence"
  ];
  OBSERVATION_EVIDENCE = [
    "query",
    "behavior",
    "parser-state",
    "pixels",
    "interaction",
    "consumed",
    "legacy",
    "none"
  ];
  NON_MEASURING_EVIDENCE = new Set([
    "consumed",
    "legacy",
    "none"
  ]);
});

// ../probe-defs/src/helpers.ts
function parserStateResult(pass, expected, state, note) {
  const response = JSON.stringify(state);
  return {
    pass: pass === true,
    response,
    ...note && { note },
    observation: {
      outcome: pass === null ? "inconclusive" : pass ? "supported" : "unsupported",
      ...pass === null && { reason: "insufficient-evidence" },
      evidence: "parser-state",
      ...note && { note }
    },
    ...pass !== null && {
      assertions: [{ kind: pass ? "positive" : "negative", expected, observed: response }]
    }
  };
}
function notTestedResult(noObservable, state) {
  return {
    pass: false,
    response: JSON.stringify(state),
    note: noObservable,
    notTested: { reason: "no-semantic-observable", noObservable }
  };
}
function selectiveEraseResult(ctx, sequence, rectangular) {
  const expected = "DECSCA-protected P survives while selective erase clears ABCD";
  if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6) {
    return parserStateResult(null, expected, { cols: ctx.cols }, "Need six measured columns");
  }
  try {
    ctx.feed('\x1B[1;1H\x1B[1"qP\x1B[0"qABCDZ');
    const before = Array.from({ length: 6 }, (_, col) => ctx.getCell(0, col).char);
    if (before.join("") !== "PABCDZ") {
      return parserStateResult(null, expected, { before }, "Selective erase seed was not measured");
    }
    ctx.feed(sequence);
    const after = Array.from({ length: 6 }, (_, col) => ctx.getCell(0, col).char);
    const controlsValid = after[0] === "P" && (!rectangular || after[5] === "Z");
    return parserStateResult(controlsValid ? after.slice(1, rectangular ? 5 : 6).every(isBlank) : null, expected, { before, after }, controlsValid ? undefined : "Protection or outside-rectangle control failed; cannot attribute selective erase");
  } finally {
    ctx.feed('\x1B[0"q');
  }
}
function unmeasuredCellResult(position, feature) {
  return {
    pass: false,
    ...position && { response: `${position.row};${position.col}` },
    note: position ? `Cursor response does not measure ${feature}` : `No cursor response after ${feature}`,
    observation: {
      outcome: "inconclusive",
      reason: position ? "insufficient-evidence" : "no-response",
      evidence: "query"
    }
  };
}
function sgrProbe(id, sequence, check, noObservableWhen) {
  return {
    id,
    termNeedsGeometry: true,
    termObservationEvidence: "consumed",
    termless(ctx) {
      ctx.feed(sequence + "X");
      const cell = ctx.getCell(0, 0);
      if (cell.char === "X") {
        const noObservable = noObservableWhen?.(cell);
        if (noObservable)
          return notTestedResult(noObservable, cell);
      }
      const measured = cell.char === "X" && check(cell) === true;
      return parserStateResult(measured ? true : null, `${id}: attribute applied to the rendered X cell`, cell, cell.char !== "X" ? "No rendered X cell to evaluate" : measured ? undefined : "Cell readback cannot distinguish unsupported styling from unreported attributes or collapsed styles; a negative needs rendering review");
    },
    async term(ctx) {
      const minRows = ctx.capture ? 3 : 1;
      const minCols = ctx.capture ? 34 : 2;
      const rows = ctx.rows;
      const cols = ctx.cols;
      if (!Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < minRows || cols < minCols) {
        return {
          pass: false,
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "none",
            note: `SGR fixture needs at least ${minRows}x${minCols}, measured ${rows}x${cols}`
          }
        };
      }
      if (ctx.capture) {
        try {
          const sample = "AaBb 0123456789 - terminal text";
          ctx.write("\x1B[0m\x1B[2J\x1B[3;3H" + sample);
          const control = await ctx.capture({ role: "control", label: "Unstyled text sample" });
          ctx.write("\x1B[0m\x1B[2J\x1B[3;3H" + sequence + sample);
          const target = await ctx.capture({ role: "target", label: id });
          return {
            pass: false,
            response: JSON.stringify({
              sample,
              startRow: 3,
              startCol: 3,
              sampleCells: sample.length,
              control: control.label,
              target: target.label
            }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "pixels",
              screenshotRef: target.ref,
              frames: [control, target],
              note: "Control and target pixels captured; visual interpretation requires review"
            }
          };
        } finally {
          ctx.write("\x1B[0m");
        }
      }
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write(sequence + "X\x1B[0m");
      const pos = await ctx.queryCursorPosition();
      if (!pos) {
        return {
          pass: false,
          note: "No cursor response",
          observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
        };
      }
      return {
        pass: pos.col === 2,
        note: pos.col === 2 ? undefined : `cursor at col ${pos.col}, expected 2`,
        response: `${pos.row};${pos.col}`,
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "Cursor advance does not verify SGR styling"
        }
      };
    },
    termlessObservationEvidence: "parser-state"
  };
}
function cursorProbe(id, setup, move, expected, setupExpected) {
  const inconclusive = (origin, setupPosition, final, evidence, reason, note) => ({
    pass: false,
    response: JSON.stringify({ origin, setup: setupPosition, final }),
    note,
    observation: { outcome: "inconclusive", reason, evidence, note }
  });
  return {
    id,
    termNeedsGeometry: true,
    termObservationEvidence: "query",
    termless(ctx) {
      ctx.feed("\x1B[1;1H");
      const origin = ctx.getCursor();
      if (origin.x !== 0 || origin.y !== 0) {
        return inconclusive(origin, null, null, "parser-state", "insufficient-evidence", `Cursor origin measured ${origin.y};${origin.x}, expected 0;0`);
      }
      if (setup)
        ctx.feed(setup);
      const setupPosition = setup ? ctx.getCursor() : origin;
      if (setup && !setupExpected) {
        return inconclusive(origin, setupPosition, null, "parser-state", "insufficient-evidence", "Cursor setup has no expected position");
      }
      const wantedSetup = setupExpected ?? { row: 0, col: 0 };
      if (setupPosition.x !== wantedSetup.col || setupPosition.y !== wantedSetup.row) {
        return inconclusive(origin, setupPosition, null, "parser-state", "insufficient-evidence", `Cursor setup measured ${setupPosition.y};${setupPosition.x}, expected ${wantedSetup.row};${wantedSetup.col}`);
      }
      ctx.feed(move);
      const final = ctx.getCursor();
      return parserStateResult(final.x === expected.col && final.y === expected.row, `cursor row=${expected.row}, col=${expected.col} (0-based) after ${JSON.stringify(move)}`, { origin, setup: setupPosition, final });
    },
    async term(ctx) {
      const minRows = Math.max(1, expected.row + 1, (setupExpected?.row ?? 0) + 1);
      const minCols = Math.max(1, expected.col + 1, (setupExpected?.col ?? 0) + 1);
      if (ctx.rows < minRows || ctx.cols < minCols) {
        const note = `Cursor fixture needs at least ${minRows} rows and ${minCols} columns; measured ${ctx.rows}x${ctx.cols}`;
        return {
          pass: false,
          note,
          observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
        };
      }
      ctx.write("\x1B[1;1H");
      const origin = await ctx.queryCursorPosition();
      if (!origin)
        return inconclusive(null, null, null, "query", "no-response", "No cursor reply at origin");
      if (origin.row !== 1 || origin.col !== 1) {
        return inconclusive(origin, null, null, "query", "insufficient-evidence", `Cursor origin measured ${origin.row};${origin.col}, expected 1;1`);
      }
      if (setup)
        ctx.write(setup);
      const setupPosition = setup ? await ctx.queryCursorPosition() : origin;
      if (!setupPosition)
        return inconclusive(origin, null, null, "query", "no-response", "No cursor reply after setup");
      if (setup && !setupExpected) {
        return inconclusive(origin, setupPosition, null, "query", "insufficient-evidence", "Cursor setup has no expected position");
      }
      const wantedSetup = setupExpected ?? { row: 0, col: 0 };
      if (setupPosition.row !== wantedSetup.row + 1 || setupPosition.col !== wantedSetup.col + 1) {
        return inconclusive(origin, setupPosition, null, "query", "insufficient-evidence", `Cursor setup measured ${setupPosition.row};${setupPosition.col}, expected ${wantedSetup.row + 1};${wantedSetup.col + 1}`);
      }
      ctx.write(move);
      const final = await ctx.queryCursorPosition();
      if (!final) {
        return inconclusive(origin, setupPosition, null, "query", "no-response", "No cursor reply after movement");
      }
      const response = JSON.stringify({ origin, setup: setupPosition, final });
      const pass = final.row === expected.row + 1 && final.col === expected.col + 1;
      return {
        pass,
        response,
        ...pass ? {} : { note: `Cursor measured ${final.row};${final.col}, expected ${expected.row + 1};${expected.col + 1}` },
        observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
        assertions: [
          {
            kind: pass ? "positive" : "negative",
            expected: `cursor row=${expected.row + 1}, col=${expected.col + 1} after ${JSON.stringify(move)}`,
            observed: response
          }
        ]
      };
    },
    termlessObservationEvidence: "parser-state"
  };
}
function decrpmModeProbe(id, modeNum, termlessFn) {
  return {
    id,
    termWrites: "query",
    termObservationEvidence: "query",
    termless: termlessFn,
    async term(ctx) {
      return decrpmResult(await ctx.queryMode(modeNum), modeNum);
    }
  };
}
function decrpmResult(state, modeNum) {
  if (state === null) {
    return {
      pass: false,
      note: "No DECRPM response",
      observation: {
        outcome: "inconclusive",
        reason: "no-response",
        evidence: "query",
        note: "No DECRPM response"
      }
    };
  }
  if (state === "unknown") {
    return {
      pass: false,
      note: `DECRPM mode ${modeNum}: not recognized; mode behavior unmeasured`,
      response: state,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "query",
        note: `DECRPM mode ${modeNum}: not recognized; mode behavior unmeasured`
      }
    };
  }
  return {
    pass: true,
    note: `DECRPM mode ${modeNum}: ${state}`,
    response: state,
    observation: { outcome: "supported", evidence: "query" },
    assertions: [
      {
        kind: "positive",
        expected: `DECRPM mode ${modeNum} recognized (set or reset)`,
        observed: state
      }
    ]
  };
}
function isBlank(char) {
  return char === "" || char === " ";
}
function probe(id, termless, term, termObservationEvidence) {
  return { id, termless, term, ...termObservationEvidence && { termObservationEvidence } };
}
function readHyperlinkMetadata(available, readLink, row, col, backendName) {
  if (!available)
    return;
  if (typeof readLink !== "function") {
    throw new Error(`${backendName} declares OSC 8 metadata but has no getHyperlinkAt method at ${row},${col}`);
  }
  const hyperlink = readLink(row, col);
  if (hyperlink !== null && typeof hyperlink !== "string") {
    throw new Error(`${backendName} declares OSC 8 metadata but returned an invalid value at ${row},${col}`);
  }
  return hyperlink;
}

// ../probe-defs/src/sgr.ts
function sameRgb(a, b) {
  return a.r === b.r && a.g === b.g && a.b === b.b;
}
async function consumedSgr(ctx, sequence) {
  try {
    ctx.write("\x1B[1;1H\x1B[2K");
    ctx.write(sequence + "X");
    const pos = await ctx.queryCursorPosition();
    if (!pos) {
      return {
        pass: false,
        note: "No cursor response",
        observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
      };
    }
    return {
      pass: false,
      note: "Cursor advance does not verify SGR styling",
      response: `${pos.row};${pos.col}`,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: pos.row === 1 && pos.col === 2 ? "consumed" : "query",
        note: "Cursor advance does not verify SGR styling"
      }
    };
  } finally {
    ctx.write("\x1B[0m");
  }
}
function rgbUnderlineProbe(id) {
  const sequence = "\x1B[4m\x1B[58;2;255;0;128m";
  const original = sgrProbe(id, sequence, () => null);
  return {
    ...original,
    termless(ctx) {
      ctx.feed("\x1B[4m\x1B[59m\x1B[38;2;0;0;255mA\x1B[38;2;0;255;0mB\x1B[58;2;255;0;128mX");
      const blueControl = ctx.getCell(0, 0);
      const greenControl = ctx.getCell(0, 1);
      const target = ctx.getCell(0, 2);
      const state = { blueControl, greenControl, target };
      const expected = `${id}: X has explicit rgb(255,0,128) underline distinct from the reset/default B cell`;
      if (blueControl.char !== "A" || greenControl.char !== "B" || target.char !== "X" || !blueControl.underline || !greenControl.underline || !target.underline || target.underlineColor == null) {
        return parserStateResult(null, expected, state, "Underlined control, target, or target color was not exposed");
      }
      if (greenControl.underlineColor && sameRgb(greenControl.underlineColor, requestedUnderlineColor)) {
        return parserStateResult(null, expected, state, "Default underline already matches the requested color");
      }
      if (sameRgb(target.underlineColor, requestedUnderlineColor))
        return parserStateResult(true, expected, state);
      if (blueControl.fg && greenControl.fg && !sameRgb(blueControl.fg, greenControl.fg) && blueControl.underlineColor && greenControl.underlineColor && !sameRgb(blueControl.underlineColor, greenControl.underlineColor)) {
        return parserStateResult(false, expected, state);
      }
      return parserStateResult(null, expected, state, "Underline color readback was not calibrated for a negative");
    },
    termlessObservationEvidence: "parser-state"
  };
}
function measuredAttribute(cell, attribute) {
  const value = cell[attribute];
  if (value === undefined)
    return null;
  if (attribute === "underline")
    return value !== false && value !== null && value !== "none";
  return typeof value === "boolean" ? value : null;
}
function measuredReset(ctx, id, setup, reset, set, preserve) {
  ctx.feed(`C${setup}X${reset}Y`);
  const baseline = ctx.getCell(0, 0);
  const before = ctx.getCell(0, 1);
  const after = ctx.getCell(0, 2);
  const state = { baseline, before, after };
  const expected = `${id}: measured setup attributes clear on Y and unrelated attributes remain set`;
  if (baseline.char !== "C" || before.char !== "X" || after.char !== "Y") {
    return parserStateResult(null, expected, state, "Baseline, styled, or reset cell was not exposed");
  }
  const attributes = [...new Set([...set, ...preserve])];
  if (attributes.some((attribute) => measuredAttribute(baseline, attribute) !== false) || attributes.some((attribute) => measuredAttribute(before, attribute) !== true) || attributes.some((attribute) => measuredAttribute(after, attribute) === null)) {
    return parserStateResult(null, expected, state, "Neutral baseline, styled setup, or reset readback was not measured");
  }
  const cleared = set.every((attribute) => measuredAttribute(after, attribute) === false);
  const retained = preserve.every((attribute) => measuredAttribute(after, attribute) === true);
  return parserStateResult(cleared && retained, expected, state);
}
async function consumedResetSgr(ctx, setup, reset) {
  try {
    ctx.write("\x1B[1;1H\x1B[2K");
    ctx.write(`${setup}X${reset}Y`);
    const pos = await ctx.queryCursorPosition();
    if (!pos) {
      return {
        pass: false,
        observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
      };
    }
    const advanced = pos.row === 1 && pos.col === 3;
    return {
      pass: false,
      response: `${pos.row};${pos.col}`,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: advanced ? "consumed" : "query",
        note: advanced ? "Cursor advance does not verify SGR reset" : "Cursor did not reach the expected position"
      }
    };
  } finally {
    ctx.write("\x1B[0m");
  }
}
function resetProbe(id, setup, reset, set, preserve = []) {
  return {
    ...probe(id, (ctx) => measuredReset(ctx, id, setup, reset, set, preserve), (ctx) => consumedResetSgr(ctx, setup, reset), "consumed"),
    termlessObservationEvidence: "parser-state"
  };
}
function sameCellColor(a, b) {
  if (a === undefined || b === undefined)
    return false;
  if (a === null || b === null)
    return a === b;
  return sameRgb(a, b);
}
function namedColorProbe(id, channel, firstCode, secondCode) {
  const first = `\x1B[${firstCode}m`;
  const second = `\x1B[${secondCode}m`;
  return {
    ...probe(id, (ctx) => {
      ctx.feed(`C${first}X${second}Y`);
      const baseline = ctx.getCell(0, 0);
      const firstCell = ctx.getCell(0, 1);
      const secondCell = ctx.getCell(0, 2);
      const state = { baseline, first: firstCell, second: secondCell };
      const expected = `${id}: the two named colors select distinct exposed ${channel} RGB values`;
      if (baseline.char !== "C" || firstCell.char !== "X" || secondCell.char !== "Y") {
        return parserStateResult(null, expected, state, "Neutral control or named-color cells were not exposed");
      }
      const neutral = baseline[channel];
      const a = firstCell[channel];
      const b = secondCell[channel];
      if (neutral !== undefined && a && b && !sameCellColor(neutral, a) && !sameRgb(a, b)) {
        return parserStateResult(true, expected, state);
      }
      return parserStateResult(null, expected, state, "Baseline, theme colors, or color readback were indistinguishable");
    }, (ctx) => consumedSgr(ctx, first), "consumed"),
    termlessObservationEvidence: "parser-state"
  };
}
function indexedColorProbe(id, channel) {
  const sgr = channel === "fg" ? 38 : 48;
  const first = { r: 95, g: 135, b: 175 };
  const second = { r: 215, g: 135, b: 95 };
  return {
    ...probe(id, (ctx) => {
      ctx.feed(`C\x1B[${sgr};2;95;135;175mA\x1B[${sgr};2;215;135;95mB\x1B[${sgr};5;67mX\x1B[${sgr};5;173mY`);
      const baseline = ctx.getCell(0, 0);
      const directFirst = ctx.getCell(0, 1);
      const directSecond = ctx.getCell(0, 2);
      const indexedFirst = ctx.getCell(0, 3);
      const indexedSecond = ctx.getCell(0, 4);
      const state = { baseline, directFirst, directSecond, indexedFirst, indexedSecond };
      const expected = `${id}: indices 67 and 173 match two independently observed canonical RGB cube references`;
      if (baseline.char !== "C" || directFirst.char !== "A" || directSecond.char !== "B" || indexedFirst.char !== "X" || indexedSecond.char !== "Y") {
        return parserStateResult(null, expected, state, "Indexed or direct-RGB control cells were not exposed");
      }
      const a = directFirst[channel];
      const b = directSecond[channel];
      const x = indexedFirst[channel];
      const y = indexedSecond[channel];
      if (a && b && x && y && sameRgb(a, first) && sameRgb(b, second) && sameRgb(x, a) && sameRgb(y, b)) {
        return parserStateResult(true, expected, state);
      }
      return parserStateResult(null, expected, state, "RGB reference was not calibrated, or the backend may use a custom indexed palette");
    }, (ctx) => consumedSgr(ctx, `\x1B[${sgr};5;67m`), "consumed"),
    termlessObservationEvidence: "parser-state"
  };
}
function truecolorProbe(id, channel) {
  const sgr = channel === "fg" ? 38 : 48;
  const ordinary = channel === "fg" ? [31, 34] : [41, 44];
  const first = channel === "fg" ? { r: 255, g: 128, b: 0 } : { r: 0, g: 255, b: 128 };
  const second = { r: 17, g: 97, b: 201 };
  return {
    ...probe(id, (ctx) => {
      ctx.feed(`C\x1B[${ordinary[0]}mA\x1B[${ordinary[1]}mB\x1B[${sgr};2;${first.r};${first.g};${first.b}mX\x1B[${sgr};2;17;97;201mY`);
      const baseline = ctx.getCell(0, 0);
      const controlFirst = ctx.getCell(0, 1);
      const controlSecond = ctx.getCell(0, 2);
      const targetFirst = ctx.getCell(0, 3);
      const targetSecond = ctx.getCell(0, 4);
      const state = { baseline, controlFirst, controlSecond, targetFirst, targetSecond };
      const expected = `${id}: two distinct direct-RGB samples are exposed at their exact requested values`;
      if (baseline.char !== "C" || controlFirst.char !== "A" || controlSecond.char !== "B" || targetFirst.char !== "X" || targetSecond.char !== "Y") {
        return parserStateResult(null, expected, state, "RGB target or independent color-control cells were not exposed");
      }
      const x = targetFirst[channel];
      const y = targetSecond[channel];
      if (!x || !y)
        return parserStateResult(null, expected, state, "RGB target readback was absent");
      const preceding = controlSecond[channel];
      if (!preceding || sameRgb(preceding, first)) {
        return parserStateResult(null, expected, state, "The preceding color can mimic an ignored first RGB request");
      }
      if (sameRgb(x, first) && sameRgb(y, second))
        return parserStateResult(true, expected, state);
      const a = controlFirst[channel];
      const b = controlSecond[channel];
      if (a && b && !sameRgb(a, b))
        return parserStateResult(false, expected, state);
      return parserStateResult(null, expected, state, "Independent color-channel calibration was absent");
    }, (ctx) => consumedSgr(ctx, `\x1B[${sgr};2;${first.r};${first.g};${first.b}m`), "consumed"),
    termlessObservationEvidence: "parser-state"
  };
}
function defaultColorProbe(id, channel) {
  const setup = channel === "fg" ? 31 : 42;
  const reset = channel === "fg" ? 39 : 49;
  return {
    ...probe(id, (ctx) => {
      ctx.feed(`C\x1B[${setup}mX\x1B[${reset}mR`);
      const baseline = ctx.getCell(0, 0);
      const before = ctx.getCell(0, 1);
      const after = ctx.getCell(0, 2);
      const state = { baseline, before, after };
      const expected = `${id}: reset R restores the measured C ${channel} after a distinct colored X`;
      if (baseline.char !== "C" || before.char !== "X" || after.char !== "R") {
        return parserStateResult(null, expected, state, "Baseline, colored, or reset cell was not exposed");
      }
      const baseColor = baseline[channel];
      const changed = before[channel];
      const resetColor = after[channel];
      if (!changed || sameCellColor(baseColor, changed) || resetColor === undefined) {
        return parserStateResult(null, expected, state, "Distinct colored setup or reset color readback was absent");
      }
      return parserStateResult(sameCellColor(baseColor, resetColor), expected, state);
    }, (ctx) => consumedSgr(ctx, `\x1B[${reset}m`), "consumed"),
    termlessObservationEvidence: "parser-state"
  };
}
var requestedUnderlineColor, sgrProbes;
var init_sgr = __esm(() => {
  requestedUnderlineColor = { r: 255, g: 0, b: 128 };
  sgrProbes = [
    sgrProbe("sgr.bold", "\x1B[1m", (cell) => cell.bold === true),
    sgrProbe("sgr.faint", "\x1B[2m", (cell) => cell.dim === true),
    sgrProbe("sgr.italic", "\x1B[3m", (cell) => cell.italic === true),
    sgrProbe("sgr.underline.single", "\x1B[4m", (cell) => !!cell.underline),
    sgrProbe("sgr.underline.double", "\x1B[21m", (cell) => cell.underline === "double"),
    sgrProbe("sgr.underline.curly", "\x1B[4:3m", (cell) => cell.underline === "curly"),
    sgrProbe("sgr.underline.dotted", "\x1B[4:4m", (cell) => cell.underline === "dotted"),
    sgrProbe("sgr.underline.dashed", "\x1B[4:5m", (cell) => cell.underline === "dashed"),
    sgrProbe("sgr.blink", "\x1B[5m", (cell) => cell.blink === true),
    sgrProbe("sgr.inverse", "\x1B[7m", (cell) => cell.inverse === true),
    sgrProbe("sgr.hidden", "\x1B[8m", (cell) => cell.hidden === true),
    sgrProbe("sgr.strikethrough", "\x1B[9m", (cell) => cell.strikethrough === true),
    sgrProbe("sgr.overline", "\x1B[53m", (cell) => cell.overline === undefined ? null : cell.overline === true, (cell) => cell.overline === undefined ? "cell.overline field not exposed" : null),
    rgbUnderlineProbe("sgr.underline.color"),
    {
      ...probe("sgr.underline-color-indexed", (ctx) => {
        ctx.feed("\x1B[4;38;5;4m\x1B[59mA\x1B[58;5;5mX\x1B[38;5;5m\x1B[59mB\x1B[58;5;4mY");
        const default4 = ctx.getCell(0, 0);
        const target5 = ctx.getCell(0, 1);
        const default5 = ctx.getCell(0, 2);
        const target4 = ctx.getCell(0, 3);
        const state = {
          default4,
          target5,
          default5,
          target4
        };
        const expected = "SGR 58 index 5/4 underline colors match the opposite SGR 38 palette controls, not their same-foreground defaults";
        if (default4.char !== "A" || target5.char !== "X" || default5.char !== "B" || target4.char !== "Y" || !default4.underline || !target5.underline || !default5.underline || !target4.underline || !default4.fg || !default5.fg || target5.underlineColor == null || target4.underlineColor == null) {
          return parserStateResult(null, expected, state, "Palette control or underline cell state was not exposed");
        }
        if (sameRgb(default4.fg, default5.fg)) {
          return parserStateResult(null, expected, state, "Palette controls resolve to indistinguishable colors");
        }
        const matches = sameRgb(default5.fg, target5.underlineColor) && sameRgb(default4.fg, target4.underlineColor) && (!default4.underlineColor || !sameRgb(default4.underlineColor, target5.underlineColor)) && (!default5.underlineColor || !sameRgb(default5.underlineColor, target4.underlineColor));
        if (matches)
          return parserStateResult(true, expected, state);
        if (default4.underlineColor && default5.underlineColor && !sameRgb(default4.underlineColor, default5.underlineColor)) {
          return parserStateResult(false, expected, state);
        }
        return parserStateResult(null, expected, state, "Underline color readback was not calibrated for a negative");
      }, (ctx) => consumedSgr(ctx, "\x1B[4m\x1B[58;5;5m"), "consumed"),
      termlessObservationEvidence: "parser-state"
    },
    rgbUnderlineProbe("sgr.underline-color-rgb"),
    {
      ...probe("sgr.underline-color-reset", (ctx) => {
        ctx.feed("\x1B[4m\x1B[59mC\x1B[58;2;255;0;128mX\x1B[59mY");
        const baseline = ctx.getCell(0, 0);
        const before = ctx.getCell(0, 1);
        const after = ctx.getCell(0, 2);
        const state = { baseline, before, after };
        const expected = "X has explicit underline rgb(255,0,128); SGR 59 restores Y to the measured reset-state C color";
        if (baseline.char !== "C" || before.char !== "X" || after.char !== "Y" || !baseline.underline || !before.underline || !after.underline || baseline.underlineColor === undefined || before.underlineColor === undefined || after.underlineColor === undefined) {
          return parserStateResult(null, expected, state, "Reset control or underline cell state was not exposed");
        }
        if (!before.underlineColor || !sameRgb(before.underlineColor, requestedUnderlineColor) || baseline.underlineColor && sameRgb(baseline.underlineColor, requestedUnderlineColor)) {
          return parserStateResult(null, expected, state, "Requested colored underline prerequisite was not observed");
        }
        if (after.underlineColor && sameRgb(after.underlineColor, before.underlineColor)) {
          return parserStateResult(false, expected, state);
        }
        if (baseline.underlineColor === null || after.underlineColor === null) {
          if (baseline.underlineColor === after.underlineColor)
            return parserStateResult(true, expected, state);
          return parserStateResult(null, expected, state, "Reset-state color readback changed representation");
        }
        return parserStateResult(sameRgb(baseline.underlineColor, after.underlineColor), expected, state);
      }, (ctx) => consumedSgr(ctx, "\x1B[4m\x1B[58;2;255;0;128m\x1B[59m"), "consumed"),
      termlessObservationEvidence: "parser-state"
    },
    namedColorProbe("sgr.fg.standard", "fg", 31, 34),
    namedColorProbe("sgr.bg.standard", "bg", 41, 44),
    namedColorProbe("sgr.fg.bright", "fg", 91, 94),
    namedColorProbe("sgr.bg.bright", "bg", 101, 104),
    defaultColorProbe("sgr.fg.default", "fg"),
    defaultColorProbe("sgr.bg.default", "bg"),
    indexedColorProbe("sgr.fg.256", "fg"),
    indexedColorProbe("sgr.bg.256", "bg"),
    truecolorProbe("sgr.fg.truecolor", "fg"),
    truecolorProbe("sgr.bg.truecolor", "bg"),
    resetProbe("sgr.selective-reset.bold", "\x1B[1;2;3m", "\x1B[22m", ["bold", "dim"], ["italic"]),
    resetProbe("sgr.selective-reset.underline", "\x1B[1;4m", "\x1B[24m", ["underline"], ["bold"]),
    resetProbe("sgr.selective-reset.italic", "\x1B[1;3m", "\x1B[23m", ["italic"], ["bold"]),
    resetProbe("sgr.selective-reset.inverse", "\x1B[1;7m", "\x1B[27m", ["inverse"], ["bold"]),
    resetProbe("sgr.reset", "\x1B[1;3;4m", "\x1B[0m", ["bold", "italic", "underline"])
  ];
});

// ../probe-defs/src/cursor.ts
function headlessPosition(ctx, row, col) {
  const cursor = ctx.getCursor();
  return parserStateResult(cursor.y === row && cursor.x === col, `cursor row=${row}, col=${col} (0-based)`, cursor);
}
function headlessSavedCursor(ctx, initial, displaced, save, restore) {
  ctx.feed(`\x1B[${initial.row};${initial.col}H`);
  const setup = ctx.getCursor();
  if (setup.y !== initial.row - 1 || setup.x !== initial.col - 1) {
    return {
      pass: false,
      response: JSON.stringify({ setup }),
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "parser-state",
        note: "Save fixture initial CUP was not measured at its target"
      }
    };
  }
  ctx.feed(save);
  ctx.feed(`\x1B[${displaced.row};${displaced.col}H`);
  const displacedPosition = ctx.getCursor();
  if (displacedPosition.y !== displaced.row - 1 || displacedPosition.x !== displaced.col - 1) {
    ctx.feed(restore);
    return {
      pass: false,
      response: JSON.stringify({ setup, displaced: displacedPosition }),
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "parser-state",
        note: "Save fixture displacement was not measured at its target"
      }
    };
  }
  ctx.feed(restore);
  const final = ctx.getCursor();
  return parserStateResult(final.y === initial.row - 1 && final.x === initial.col - 1, `saved cursor returns to row ${initial.row - 1}, col ${initial.col - 1}`, { setup, displaced: displacedPosition, final });
}
async function appSavedCursor(ctx, initial, displaced, save, restore) {
  ctx.write(`\x1B[${initial.row};${initial.col}H`);
  const setup = await ctx.queryCursorPosition();
  if (!setup || setup.row !== initial.row || setup.col !== initial.col) {
    return {
      pass: false,
      response: JSON.stringify({ setup }),
      observation: {
        outcome: "inconclusive",
        reason: setup ? "insufficient-evidence" : "no-response",
        evidence: "query",
        note: "Save fixture initial CUP was not measured at its target"
      }
    };
  }
  ctx.write(save);
  let restored = false;
  try {
    ctx.write(`\x1B[${displaced.row};${displaced.col}H`);
    const displacedPosition = await ctx.queryCursorPosition();
    if (!displacedPosition || displacedPosition.row !== displaced.row || displacedPosition.col !== displaced.col) {
      return {
        pass: false,
        response: JSON.stringify({ setup, displaced: displacedPosition }),
        observation: {
          outcome: "inconclusive",
          reason: displacedPosition ? "insufficient-evidence" : "no-response",
          evidence: "query",
          note: "Save fixture displacement was not measured at its target"
        }
      };
    }
    ctx.write(restore);
    restored = true;
    const final = await ctx.queryCursorPosition();
    const response = JSON.stringify({ setup, displaced: displacedPosition, final });
    if (!final) {
      return {
        pass: false,
        response,
        observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
      };
    }
    const pass = final.row === initial.row && final.col === initial.col;
    return {
      pass,
      response,
      observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
      assertions: [
        {
          kind: pass ? "positive" : "negative",
          expected: `saved cursor returns to ${initial.row};${initial.col} after measured displacement`,
          observed: response
        }
      ]
    };
  } finally {
    if (!restored)
      ctx.write(restore);
  }
}
var cursorProbes;
var init_cursor = __esm(() => {
  cursorProbes = [
    cursorProbe("cursor.move.absolute", "", "\x1B[5;10H", { row: 4, col: 9 }, { row: 0, col: 0 }),
    cursorProbe("cursor.move.home", "ABC", "\x1B[H", { row: 0, col: 0 }, { row: 0, col: 3 }),
    cursorProbe("cursor.move.forward", "", "\x1B[5C", { row: 0, col: 5 }, { row: 0, col: 0 }),
    cursorProbe("cursor.move.back", "ABC", "\x1B[2D", { row: 0, col: 1 }, { row: 0, col: 3 }),
    cursorProbe("cursor.move.down", "", "\x1B[3B", { row: 3, col: 0 }, { row: 0, col: 0 }),
    cursorProbe("cursor.move.up", "\x1B[5B", "\x1B[2A", { row: 3, col: 0 }, { row: 5, col: 0 }),
    {
      ...probe("cursor.hide", (ctx) => {
        const before = ctx.getCursor().visible;
        const expected = "Cursor parser visibility changes from shown to hidden and its initial state is restored";
        if (before === null) {
          return parserStateResult(null, expected, { before }, "Initial cursor visibility readback is unavailable");
        }
        let shown = null;
        let hidden = null;
        try {
          ctx.feed("\x1B[?25h");
          shown = ctx.getCursor().visible;
          if (shown === true) {
            ctx.feed("\x1B[?25l");
            hidden = ctx.getCursor().visible;
          }
        } finally {
          ctx.feed(before ? "\x1B[?25h" : "\x1B[?25l");
        }
        const restored = ctx.getCursor().visible;
        const qualified = shown === true && hidden !== null && restored === before;
        return parserStateResult(qualified ? hidden === false : null, expected, { before, shown, hidden, restored }, qualified ? "Parser visibility state only; display pixels were not captured" : "Shown control, hidden readback or initial-state restoration was not established");
      }, async (ctx) => {
        const rows = ctx.rows;
        const cols = ctx.cols;
        const capture = ctx.capture;
        if (!capture || !Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 3 || cols < 6) {
          const note = `Cursor pixel fixture needs capture and measured 3x6 geometry; measured ${rows}x${cols}`;
          return {
            pass: false,
            note,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
          };
        }
        try {
          ctx.write("\x1B[0m\x1B[2J\x1B[H");
          ctx.write("\x1B[1;1HCURSOR\x1B[2;1HL  R\x1B[2;3H\x1B[2 q\x1B[?25h");
          const control = await capture({
            role: "control",
            label: "Shown steady block cursor requested at row 2 column 3"
          });
          ctx.write("\x1B[?25l");
          const target = await capture({ role: "target", label: "Hidden cursor requested at the same cell" });
          const observed = JSON.stringify({ rows, cols, cursor: { row: 2, col: 3 }, control, target });
          return {
            pass: false,
            response: observed,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "pixels",
              screenshotRef: target.ref,
              frames: [control, target],
              note: "Seeded cursor pixels require independent review: control must visibly show the cursor; blink phase or missing focus cannot establish a negative"
            },
            assertions: [
              {
                kind: "positive",
                expected: "Control visibly shows a cursor at row 2 column 3 between L and R; target removes that cursor while other seeded content is unchanged",
                observed,
                note: "capture-only assertion; cursor visibility and the control must be independently reviewed"
              }
            ]
          };
        } finally {
          ctx.write("\x1B[0m\x1B[2J\x1B[H\x1B[?25h\x1B[0 q");
        }
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    probe("cursor.shape", (ctx) => {
      ctx.feed("\x1B[6 q");
      const style = ctx.getCursor().style;
      return parserStateResult(style === null ? null : style === "beam", "DECSCUSR reports a beam cursor after CSI 6 SP q", { style }, style === null ? "Cursor style readback is unavailable" : undefined);
    }, async (ctx) => {
      if (!ctx.capture) {
        const note = "No cursor pixel readback for shape";
        return {
          pass: false,
          note,
          observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
        };
      }
      const control = await ctx.capture({ role: "control", label: "Default cursor shape" });
      try {
        ctx.write("\x1B[5 q");
        const target = await ctx.capture({ role: "target", label: "Bar cursor shape" });
        return {
          pass: false,
          response: JSON.stringify({
            rows: ctx.rows,
            cols: ctx.cols,
            cursorCell: null,
            detail: "DECSCUSR shape fixture does not establish the cursor cell; only measured geometry and roles",
            control: control.label,
            target: target.label
          }),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "pixels",
            screenshotRef: target.ref,
            frames: [control, target],
            note: "Cursor pixels captured; shape difference requires review"
          }
        };
      } finally {
        ctx.write("\x1B[0 q");
      }
    }),
    cursorProbe("cursor.horizontal-absolute", "\x1B[3;1H", "\x1B[15G", { row: 2, col: 14 }, { row: 2, col: 0 }),
    cursorProbe("cursor.next-line", "\x1B[3;5H", "\x1B[E", { row: 3, col: 0 }, { row: 2, col: 4 }),
    {
      ...probe("cursor.position-report", (ctx) => {
        ctx.feed("\x1B[3;5H");
        const response = ctx.feedCapture("\x1B[6n");
        if (!response) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        const match = response.startsWith("\x1B[") ? /^([1-9]\d*);([1-9]\d*)R$/.exec(response.slice(2)) : null;
        const row = Number(match?.[1]);
        const col = Number(match?.[2]);
        if (!match || !Number.isSafeInteger(row) || !Number.isSafeInteger(col)) {
          return {
            pass: false,
            response,
            observation: { outcome: "inconclusive", reason: "invalid-reply", evidence: "query" }
          };
        }
        const setup = ctx.getCursor();
        const measured = JSON.stringify({ setup, report: response });
        if (setup.y !== 2 || setup.x !== 4) {
          return {
            pass: false,
            response: measured,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "DSR setup CUP was not independently measured at 3;5"
            }
          };
        }
        const pass = row === 3 && col === 5;
        return {
          pass,
          response: measured,
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "ESC[3;5R after independently measured CUP 3;5",
              observed: measured
            }
          ]
        };
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "cursor.position-report fixture needs at least 3x5 measured cells"
            }
          };
        }
        const steps = [
          { row: 1, col: 4, writes: ["\x1B[1;1H", "\x1B[2K", "ABC"] },
          { row: 3, col: 6, writes: ["\x1B[3;1H", "\x1B[2K", "ABCDE"] }
        ];
        const measured = [];
        for (const step of steps) {
          for (const sequence of step.writes)
            ctx.write(sequence);
          const pos = await ctx.queryCursorPosition();
          if (!pos) {
            return {
              pass: false,
              response: JSON.stringify({ measured }),
              observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
            };
          }
          measured.push({ expected: step.row + ";" + step.col, report: pos });
          if (pos.row !== step.row || pos.col !== step.col) {
            return {
              pass: false,
              response: JSON.stringify({ measured }),
              observation: {
                outcome: "inconclusive",
                reason: "insufficient-evidence",
                evidence: "query",
                note: "Text-induced cursor advance was not reported at " + step.row + ";" + step.col
              }
            };
          }
        }
        const response = JSON.stringify({ measured });
        return {
          pass: true,
          response,
          observation: { outcome: "supported", evidence: "query" },
          assertions: [
            {
              kind: "positive",
              expected: "CPR tracks text-induced cursor advances at two distinct rows",
              observed: response
            }
          ]
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "query"
    },
    {
      ...probe("cursor.ansi-save", (ctx) => headlessSavedCursor(ctx, { row: 3, col: 5 }, { row: 10, col: 15 }, "\x1B[s", "\x1B[u"), async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 10 || ctx.cols < 15) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "cursor.ansi-save fixture needs at least 10x15 measured cells"
            }
          };
        }
        return appSavedCursor(ctx, { row: 3, col: 5 }, { row: 10, col: 15 }, "\x1B[s", "\x1B[u");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("cursor.ansi-restore", (ctx) => headlessSavedCursor(ctx, { row: 4, col: 6 }, { row: 12, col: 18 }, "\x1B[s", "\x1B[u"), async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 12 || ctx.cols < 18) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "cursor.ansi-restore fixture needs at least 12x18 measured cells"
            }
          };
        }
        return appSavedCursor(ctx, { row: 4, col: 6 }, { row: 12, col: 18 }, "\x1B[s", "\x1B[u");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("cursor.save-restore", (ctx) => headlessSavedCursor(ctx, { row: 3, col: 5 }, { row: 10, col: 10 }, "\x1B7", "\x1B8"), async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 10 || ctx.cols < 10) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "cursor.save-restore fixture needs at least 10x10 measured cells"
            }
          };
        }
        return appSavedCursor(ctx, { row: 3, col: 5 }, { row: 10, col: 10 }, "\x1B7", "\x1B8");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    probe("cursor.reverse-wrap", (ctx) => {
      const cols = ctx.cols;
      const rows = ctx.getScrollback().screenLines;
      const expected = "Backspace reverses a wrap across the measured row width";
      if (!Number.isSafeInteger(cols) || cols < 2 || !Number.isSafeInteger(rows) || rows < 2) {
        return parserStateResult(null, expected, { rows, cols }, "Measured grid needs two rows and at least two columns");
      }
      const originallyAutoWrap = ctx.getMode("autoWrap");
      try {
        ctx.feed("\x1B[?7h");
        ctx.feed("\x1B[?45h");
        ctx.feed("\x1B[H");
        const start = ctx.getCursor();
        if (start.y !== 0 || start.x !== 0) {
          return parserStateResult(null, expected, { cols, start }, "Home-position control was not measured");
        }
        ctx.feed("A".repeat(cols) + "B");
        const wrapped = ctx.getCursor();
        if (wrapped.y !== 1 || wrapped.x !== 1) {
          return parserStateResult(null, expected, { cols, start, wrapped }, "Second-row displacement was not measured");
        }
        ctx.feed("\b\b");
        const cursor = ctx.getCursor();
        return parserStateResult(cursor.y === 0 && cursor.x === cols - 1, expected, { cols, start, wrapped, cursor });
      } finally {
        ctx.feed("\x1B[?45l");
        ctx.feed(originallyAutoWrap ? "\x1B[?7h" : "\x1B[?7l");
      }
    }, async (ctx) => {
      const expected = "Backspace from column 1 of row 2 reverses the wrap to the last column of row 1";
      if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 2 || ctx.cols < 2) {
        return {
          pass: false,
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "none",
            note: "reverse-wrap fixture needs two measured rows and at least two columns"
          }
        };
      }
      const cols = ctx.cols;
      const measured = [];
      const ask = async (step) => {
        const pos = await ctx.queryCursorPosition();
        measured.push({ step, report: pos });
        return pos;
      };
      const inconclusive = (note) => ({
        pass: false,
        response: JSON.stringify({ measured }),
        observation: {
          outcome: "inconclusive",
          ...note ? { reason: "insufficient-evidence", note } : { reason: "no-response" },
          evidence: "query"
        }
      });
      ctx.write("\x1B[?45h");
      try {
        ctx.write("\x1B[?7h");
        ctx.write("\x1B[H");
        const home = await ask("home");
        if (!home)
          return inconclusive();
        if (home.row !== 1 || home.col !== 1)
          return inconclusive("Home position was not reported at 1;1");
        ctx.write("A".repeat(cols) + "B");
        const wrapped = await ask("wrapped");
        if (!wrapped)
          return inconclusive();
        if (wrapped.row !== 2 || wrapped.col !== 2) {
          return inconclusive("Deferred wrap was not reported at 2;2");
        }
        ctx.write("\b\b");
        const reverted = await ask("reverted");
        if (!reverted)
          return inconclusive();
        const response = JSON.stringify({ measured });
        if (reverted.row === 1 && reverted.col === cols) {
          return {
            pass: true,
            response,
            observation: { outcome: "supported", evidence: "query" },
            assertions: [{ kind: "positive", expected, observed: response }]
          };
        }
        return {
          pass: false,
          response,
          observation: {
            outcome: "unsupported",
            evidence: "query",
            note: "Measured wrap was not reversed to row 1 column " + cols
          },
          assertions: [{ kind: "negative", expected, observed: response }]
        };
      } finally {
        ctx.write("\x1B[?45l");
      }
    }),
    {
      ...probe("cursor.cup-boundaries", (ctx) => {
        const rows = ctx.getScrollback().screenLines;
        const cols = ctx.cols;
        if (!Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 2 || cols < 2) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `CUP edge fixture needs an initialized grid of at least 2x2, measured ${rows}x${cols}`
            }
          };
        }
        ctx.feed("\x1B[1;1H");
        const origin = ctx.getCursor();
        const originResponse = JSON.stringify({ rows, cols, origin });
        if (origin.y !== 0 || origin.x !== 0) {
          return {
            pass: false,
            response: originResponse,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: "CUP home control did not reach 0;0"
            }
          };
        }
        ctx.feed(`\x1B[${rows};${cols}H`);
        const edge = ctx.getCursor();
        const edgeResponse = JSON.stringify({ rows, cols, origin, edge });
        if (edge.y !== rows - 1 || edge.x !== cols - 1) {
          return {
            pass: false,
            response: edgeResponse,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: `CUP edge control did not reach ${rows - 1};${cols - 1}`
            }
          };
        }
        ctx.feed("\x1B[1;1H");
        const beforeTarget = ctx.getCursor();
        const beforeResponse = JSON.stringify({ rows, cols, origin, edge, beforeTarget });
        if (beforeTarget.y !== 0 || beforeTarget.x !== 0) {
          return {
            pass: false,
            response: beforeResponse,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: "CUP reset control did not reach 0;0"
            }
          };
        }
        const targetRow = Math.max(999, rows + 1);
        const targetCol = Math.max(999, cols + 1);
        ctx.feed(`\x1B[${targetRow};${targetCol}H`);
        const final = ctx.getCursor();
        const response = JSON.stringify({ rows, cols, origin, edge, beforeTarget, final });
        if (!Number.isSafeInteger(final.y) || !Number.isSafeInteger(final.x)) {
          return {
            pass: false,
            response,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: "CUP target cursor readback is invalid"
            }
          };
        }
        const pass = final.y === rows - 1 && final.x === cols - 1;
        return {
          pass,
          response,
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "parser-state" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: `CUP ${targetRow};${targetCol} clamps to measured ${rows - 1};${cols - 1} after qualified edge`,
              observed: response
            }
          ]
        };
      }, async (ctx) => {
        const { rows, cols } = ctx;
        if (!Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 2 || cols < 2) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `CUP edge fixture needs at least 2x2, measured ${rows}x${cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        const origin = await ctx.queryCursorPosition();
        if (!origin) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        if (origin.row !== 1 || origin.col !== 1) {
          return {
            pass: false,
            response: JSON.stringify({ origin }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "CUP home control did not reach 1;1"
            }
          };
        }
        ctx.write(`\x1B[${rows};${cols}H`);
        const edge = await ctx.queryCursorPosition();
        if (!edge) {
          return {
            pass: false,
            response: JSON.stringify({ origin, edge }),
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        if (edge.row !== rows || edge.col !== cols) {
          return {
            pass: false,
            response: JSON.stringify({ origin, edge }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: `CUP edge control did not reach ${rows};${cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        const beforeTarget = await ctx.queryCursorPosition();
        if (!beforeTarget) {
          return {
            pass: false,
            response: JSON.stringify({ origin, edge, beforeTarget }),
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        if (beforeTarget.row !== 1 || beforeTarget.col !== 1) {
          return {
            pass: false,
            response: JSON.stringify({ origin, edge, beforeTarget }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "CUP reset control did not reach 1;1"
            }
          };
        }
        const targetRow = Math.max(999, rows + 1);
        const targetCol = Math.max(999, cols + 1);
        ctx.write(`\x1B[${targetRow};${targetCol}H`);
        const final = await ctx.queryCursorPosition();
        const response = JSON.stringify({ rows, cols, origin, edge, beforeTarget, final });
        if (!final) {
          return {
            pass: false,
            response,
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        const pass = final.row === rows && final.col === cols;
        return {
          pass,
          response,
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: `CUP ${targetRow};${targetCol} clamps to measured ${rows};${cols} after qualified edge`,
              observed: response
            }
          ]
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    cursorProbe("cursor.cuu-past-top", "\x1B[4;1H", "\x1B[999A", { row: 0, col: 0 }, { row: 3, col: 0 }),
    {
      ...probe("cursor.cud-past-bottom", (ctx) => {
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(rows) || rows < 1) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Initialized screen row count is unavailable"
            }
          };
        }
        ctx.feed("\x1B[1;1H");
        const origin = ctx.getCursor();
        if (origin.y !== 0 || origin.x !== 0) {
          return {
            pass: false,
            response: JSON.stringify({ rows, origin }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: "CUD home control did not reach 0;0"
            }
          };
        }
        const target = Math.max(999, rows + 1);
        ctx.feed(`\x1B[${target}B`);
        const final = ctx.getCursor();
        const validFinal = Number.isSafeInteger(final.y) && Number.isSafeInteger(final.x);
        return parserStateResult(validFinal ? final.y === rows - 1 && final.x === 0 : null, `CUD ${target} clamps to last initialized row ${rows - 1}, col 0 after qualified home`, { rows, origin, final }, validFinal ? undefined : "CUD target cursor readback is invalid");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 2 || ctx.cols < 1) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "cursor.cud-past-bottom fixture needs at least 2x1 measured cells"
            }
          };
        }
        const rows = ctx.rows;
        const expected = "CUD past the newline-measured bottom clamps at the last row";
        const measured = [];
        const ask = async (step) => {
          const pos = await ctx.queryCursorPosition();
          measured.push({ step, report: pos });
          return pos;
        };
        const inconclusive = (note) => ({
          pass: false,
          response: JSON.stringify({ rows, measured }),
          observation: {
            outcome: "inconclusive",
            ...note ? { reason: "insufficient-evidence", note } : { reason: "no-response" },
            evidence: "query"
          }
        });
        ctx.write("\x1B[1;1H");
        const origin = await ask("origin");
        if (!origin)
          return inconclusive();
        if (origin.row !== 1 || origin.col !== 1)
          return inconclusive("CUD home control did not reach 1;1");
        ctx.write(`\r
`.repeat(rows - 1));
        const bottom = await ask("bottom");
        if (!bottom)
          return inconclusive();
        if (bottom.row !== rows || bottom.col !== 1) {
          return inconclusive("Newline-induced bottom was not reported at " + rows + ";1");
        }
        const target = Math.max(999, rows + 1);
        ctx.write("\x1B[" + target + "B");
        const final = await ask("clamped");
        if (!final)
          return inconclusive();
        const response = JSON.stringify({ rows, measured });
        if (final.row === rows && final.col === 1) {
          return {
            pass: true,
            response,
            observation: { outcome: "supported", evidence: "query" },
            assertions: [{ kind: "positive", expected, observed: response }]
          };
        }
        return {
          pass: false,
          response,
          observation: {
            outcome: "unsupported",
            evidence: "query",
            note: "CUD " + target + " did not clamp at row " + rows
          },
          assertions: [{ kind: "negative", expected, observed: response }]
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    cursorProbe("cursor.vpa", "\x1B[3;5H", "\x1B[10d", { row: 9, col: 4 }, { row: 2, col: 4 }),
    cursorProbe("cursor.cpl", "\x1B[6;10H", "\x1B[2F", { row: 3, col: 0 }, { row: 5, col: 9 }),
    cursorProbe("cursor.hpa", "\x1B[3;1H", "\x1B[15`", { row: 2, col: 14 }, { row: 2, col: 0 }),
    {
      ...probe("cursor.cup-scroll-region", (ctx) => {
        try {
          ctx.feed("\x1B[5;15r");
          ctx.feed("\x1B[?6h");
          ctx.feed("\x1B[1;1H");
          return headlessPosition(ctx, 4, 0);
        } finally {
          try {
            ctx.feed("\x1B[?6l");
          } finally {
            ctx.feed("\x1B[r");
          }
        }
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 15 || ctx.cols < 1) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "cursor.cup-scroll-region fixture needs at least 15x1 measured cells"
            }
          };
        }
        const rows = ctx.rows;
        const measured = [];
        const ask = async (step) => {
          const pos = await ctx.queryCursorPosition();
          measured.push({ step, report: pos });
          return pos;
        };
        try {
          ctx.write("\x1B[5;15r");
          ctx.write("\x1B[?6h");
          ctx.write("\x1B[1;1H");
          const top = await ask("region-top");
          ctx.write("\x1B[2;1H");
          const second = await ask("region-row-2");
          const target = Math.max(999, rows + 1);
          ctx.write("\x1B[" + target + "B");
          const bottom = await ask("region-bottom");
          if (!top || !second || !bottom) {
            return {
              pass: false,
              response: JSON.stringify({ rows, measured }),
              observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
            };
          }
          const relative = [top, second, bottom].map((sample) => sample.row + ";" + sample.col).join(", ");
          return {
            pass: false,
            response: JSON.stringify({ rows, measured }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "DECOM makes CPR region-relative (VT100: region top is 1, bottom is 11); measured " + relative + " \u2014 the physical row 5 and the margins still need an independent observable"
            }
          };
        } finally {
          try {
            ctx.write("\x1B[?6l");
          } finally {
            ctx.write("\x1B[r");
          }
        }
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    }
  ];
});

// ../probe-defs/src/text.ts
function installTabFixture(write) {
  write("\x1B[3g\x1B[1;9H\x1BH\x1B[1;17H\x1BH\x1B[1;1H");
}
function restoreDefaultTabs(write, cols) {
  let sequence = "\x1B[3g";
  for (let col = 9;col <= cols; col += 8)
    sequence += `\x1B[1;${col}H\x1BH`;
  write(sequence + "\x1B[1;1H");
}
function tooSmall(ctx, rows, cols) {
  if (validSize(ctx.rows, rows) && validSize(ctx.cols, cols))
    return;
  return {
    pass: false,
    observation: {
      outcome: "inconclusive",
      reason: "insufficient-evidence",
      evidence: "none",
      note: `Text fixture needs at least ${rows}x${cols}; measured ${ctx.rows}x${ctx.cols}`
    }
  };
}
function validSize(value, minimum) {
  return Number.isSafeInteger(value) && value >= minimum;
}
function tabCombinedResult(home, comparison, owned, cols) {
  const response = JSON.stringify({ cols, home, comparison, owned });
  if (!home) {
    return { pass: false, response, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
  }
  if (home.row !== 1 || home.col !== 1) {
    return {
      pass: false,
      response,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "query",
        note: "Measured home position was not row 1, column 1; the cursor-query provider is not position-sensitive"
      }
    };
  }
  if (!comparison) {
    return { pass: false, response, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
  }
  if (comparison.row !== 1 || comparison.col !== 9) {
    return {
      pass: false,
      response,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "query",
        note: "Comparison stop at column 9 was not established; fixture setup not qualified"
      }
    };
  }
  if (!owned) {
    return { pass: false, response, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
  }
  const expected = "combined HT/HTS fixture advances to the nearest owned stop at row 1, column 6";
  if (owned.row === 1 && owned.col === 6) {
    return {
      pass: true,
      response,
      observation: { outcome: "supported", evidence: "query" },
      assertions: [{ kind: "positive", expected, observed: JSON.stringify({ home, comparison, owned }) }]
    };
  }
  if (owned.row === 1 && owned.col === 9) {
    return {
      pass: false,
      response,
      observation: {
        outcome: "unsupported",
        evidence: "query",
        note: "Owned stop at column 6 was ignored; tab fell through to the measured comparison stop (home 1;1 and comparison 1;9 were both qualified)"
      },
      assertions: [{ kind: "negative", expected, observed: JSON.stringify({ home, comparison, owned }) }]
    };
  }
  return {
    pass: false,
    response,
    observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "query" }
  };
}
function tabClearResult(positions, cols, evidence) {
  const response = JSON.stringify({ cols, ...positions });
  const { oldFirst, oldSecond, oldThird, after } = positions;
  if (!oldFirst || !oldSecond || !oldThird || !after) {
    return {
      pass: false,
      response,
      observation: { outcome: "inconclusive", reason: "no-response", evidence }
    };
  }
  if (oldFirst.row !== 1 || oldFirst.col !== 9 || oldSecond.row !== 1 || oldSecond.col !== 17 || oldThird.row !== 1 || oldThird.col !== 25) {
    return {
      pass: false,
      response,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence,
        note: "Could not establish owned tab stops at columns 9, 17 and 25"
      }
    };
  }
  const pass = after.row === 1 && after.col === cols;
  const failedClear = after.row === 1 && [1, 9, 17, 25].includes(after.col);
  return {
    pass,
    response,
    observation: {
      outcome: pass ? "supported" : failedClear ? "unsupported" : "inconclusive",
      ...pass || failedClear ? {} : { reason: "insufficient-evidence" },
      evidence
    },
    ...pass || failedClear ? {
      assertions: [
        {
          kind: pass ? "positive" : "negative",
          expected: "After clearing old stops at columns 9, 17 and 25, tab reaches the right margin",
          observed: response
        }
      ]
    } : {}
  };
}
function tabPositionResult(position, expectedCol, evidence) {
  if (!position) {
    return {
      pass: false,
      note: "No cursor response",
      observation: { outcome: "inconclusive", reason: "no-response", evidence }
    };
  }
  const response = JSON.stringify(position);
  const pass = position.row === 1 && position.col === expectedCol;
  return {
    pass,
    response,
    observation: { outcome: pass ? "supported" : "unsupported", evidence },
    assertions: [{ kind: pass ? "positive" : "negative", expected: `row 1, col ${expectedCol}`, observed: response }]
  };
}
var DECAWM_MODE = 7, textProbes;
var init_text = __esm(() => {
  textProbes = [
    {
      ...probe("text.basic", (ctx) => {
        ctx.feed("\x1B[2J\x1B[H");
        const before = ctx.getText();
        ctx.feed("Hello");
        const after = ctx.getText();
        return parserStateResult(before.includes("Hello") ? null : after.includes("Hello"), "Hello appears after a measured empty control", { before, after }, before.includes("Hello") ? "Control already contained Hello" : undefined);
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 6);
        if (refusal)
          return refusal;
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("Hello");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "rendered Hello text");
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.newline", (ctx) => {
        ctx.feed("\x1B[2J\x1B[H");
        const before = [ctx.getCell(0, 0), ctx.getCell(1, 0)];
        ctx.feed(`A\r
B`);
        const first = ctx.getCell(0, 0);
        const second = ctx.getCell(1, 0);
        const ready = before.every((cell) => isBlank(cell.char));
        return parserStateResult(ready ? first.char === "A" && second.char === "B" : null, "CRLF places B below A", { before, first, second }, ready ? undefined : "Control cells were not blank");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 4, 5);
        if (refusal)
          return refusal;
        ctx.write("\x1B[3;5H");
        const before = await ctx.queryCursorPosition();
        ctx.write(`
`);
        const pos = await ctx.queryCursorPosition();
        if (!before || !pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        if (before.row !== 3 || before.col !== 5) {
          return {
            pass: false,
            response: JSON.stringify({ before, pos }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Could not establish starting cursor position"
            }
          };
        }
        const pass = pos.row === 4;
        return {
          pass,
          response: JSON.stringify({ before, pos }),
          observation: {
            outcome: pass ? "supported" : "unsupported",
            evidence: "query",
            ...pos.col !== 5 && {
              note: `Column changed from 5 to ${pos.col}; this probe does not distinguish terminal newline mode from TTY output processing`
            }
          },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "LF advances from row 3 to row 4",
              observed: JSON.stringify({ before, pos })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.wrap", (ctx) => {
        if (!validSize(ctx.cols, 2) || !validSize(ctx.getScrollback().screenLines, 2)) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        ctx.feed("\x1B[2J\x1B[H");
        const before = [ctx.getCell(0, ctx.cols - 1), ctx.getCell(1, 0)];
        ctx.feed("X".repeat(ctx.cols + 1));
        const last = ctx.getCell(0, ctx.cols - 1);
        const next = ctx.getCell(1, 0);
        const ready = before.every((cell) => isBlank(cell.char));
        return parserStateResult(ready ? last.char === "X" && next.char === "X" : null, "The next X wraps to the measured second row", { cols: ctx.cols, before, last, next }, ready ? undefined : "Control cells were not blank");
      }, async (ctx) => {
        const cols = ctx.cols;
        if (!validSize(ctx.rows, 2) || !validSize(cols, 2)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Wrap fixture needs at least 2x2, measured ${ctx.rows}x${cols}`
            }
          };
        }
        const decawm = await ctx.queryMode(DECAWM_MODE);
        if (decawm !== "set") {
          return {
            pass: false,
            response: JSON.stringify({ cols, decawm }),
            observation: {
              outcome: "inconclusive",
              reason: decawm === null ? "no-response" : "insufficient-evidence",
              evidence: "query",
              note: decawm === null ? "DECAWM setup did not reply" : `DECAWM measured ${decawm}; right-margin wrap not qualified`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        const home = await ctx.queryCursorPosition();
        if (!home) {
          return {
            pass: false,
            response: JSON.stringify({ cols, decawm }),
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        if (home.row !== 1 || home.col !== 1) {
          return {
            pass: false,
            response: JSON.stringify({ cols, decawm, home }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Measured home position was not row 1, column 1; the cursor-query provider is not position-sensitive"
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("W".repeat(cols - 1));
        const control = await ctx.queryCursorPosition();
        if (!control) {
          return {
            pass: false,
            response: JSON.stringify({ cols, decawm, home }),
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        if (control.row !== 1 || control.col !== cols) {
          return {
            pass: false,
            response: JSON.stringify({ cols, decawm, home, control }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Control did not leave the cursor at the right margin; wrap not qualified"
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("W".repeat(cols) + "X");
        const target = await ctx.queryCursorPosition();
        if (!target) {
          return {
            pass: false,
            response: JSON.stringify({ cols, decawm, home, control }),
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        const pass = target.row === 2 && target.col === 2;
        return {
          pass,
          response: JSON.stringify({ cols, decawm, home, control, target }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: `wrap after ${cols} columns lands the cursor at row 2, column 2`,
              observed: JSON.stringify({ home, control, target })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.tab", (ctx) => {
        if (!validSize(ctx.cols, 9)) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        try {
          ctx.feed("\x1B[3g\x1B[1;9H\x1BH\x1B[1;1H\tX");
          const cell = ctx.getCell(0, 8);
          return parserStateResult(cell.char === "X", "HT moves X to the owned stop at column 9", { cell });
        } finally {
          restoreDefaultTabs(ctx.feed, ctx.cols);
        }
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 9);
        if (refusal)
          return refusal;
        try {
          ctx.write("\x1B[3g\x1B[1;1H");
          const home = await ctx.queryCursorPosition();
          ctx.write("\x1B[1;9H\x1BH\x1B[1;1H");
          ctx.write("\t");
          const comparison = await ctx.queryCursorPosition();
          ctx.write("\x1B[1;6H\x1BH\x1B[1;1H");
          ctx.write("\t");
          const owned = await ctx.queryCursorPosition();
          return tabCombinedResult(home, comparison, owned, ctx.cols);
        } finally {
          restoreDefaultTabs(ctx.write, ctx.cols);
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.wide.emoji", (ctx) => {
        ctx.feed("AA");
        const ascii = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\x1B[1;1H\x1B[2K");
        ctx.feed("\uD83C\uDF89");
        const cell = ctx.getCell(0, 0);
        const ready = ascii[0]?.char === "A" && ascii[1]?.char === "A" && cell.char === "\uD83C\uDF89";
        return parserStateResult(ready ? cell.wide === true : null, "Emoji occupies a wide parser cell", { ascii, cell }, ready ? undefined : "ASCII control or emoji cell was not exposed");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 3);
        if (refusal)
          return refusal;
        const ascii = await ctx.measureRenderedWidth("AA");
        const width = await ctx.measureRenderedWidth("\uD83C\uDF89");
        if (ascii !== 2 || width === null) {
          return {
            pass: false,
            response: JSON.stringify({ ascii, width }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "ASCII width control or emoji width was unavailable"
            }
          };
        }
        const pass = width === 2;
        return {
          pass,
          response: JSON.stringify({ ascii, width }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "\uD83C\uDF89 occupies two columns after ASCII calibration",
              observed: JSON.stringify({ ascii, width })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.wide.cjk", (ctx) => {
        ctx.feed("AA");
        const ascii = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\x1B[1;1H\x1B[2K");
        ctx.feed("\u4E2D");
        const cell = ctx.getCell(0, 0);
        const ready = ascii[0]?.char === "A" && ascii[1]?.char === "A" && cell.char === "\u4E2D";
        return parserStateResult(ready ? cell.wide === true : null, "CJK sample occupies a wide parser cell", { ascii, cell }, ready ? undefined : "ASCII control or CJK cell was not exposed");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 3);
        if (refusal)
          return refusal;
        const ascii = await ctx.measureRenderedWidth("AA");
        const width = await ctx.measureRenderedWidth("\u4E2D");
        if (ascii !== 2 || width === null) {
          return {
            pass: false,
            response: JSON.stringify({ ascii, width }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "ASCII width control or CJK width was unavailable"
            }
          };
        }
        const pass = width === 2;
        return {
          pass,
          response: JSON.stringify({ ascii, width }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "\u4E2D occupies two columns after ASCII calibration",
              observed: JSON.stringify({ ascii, width })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.overwrite", (ctx) => {
        ctx.feed("AB");
        const before = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\x1B[1GC");
        const first = ctx.getCell(0, 0);
        const second = ctx.getCell(0, 1);
        const ready = before[0]?.char === "A" && before[1]?.char === "B";
        return parserStateResult(ready ? first.char === "C" && second.char === "B" : null, "C overwrites A while B remains", { before, first, second }, ready ? undefined : "AB control was not measured");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 3);
        if (refusal)
          return refusal;
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("AB");
        ctx.write("\x1B[1;2H");
        ctx.write("X");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "overwritten B cell");
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.cr", (ctx) => {
        ctx.feed("AB");
        const before = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\rC");
        const first = ctx.getCell(0, 0);
        const second = ctx.getCell(0, 1);
        const ready = before[0]?.char === "A" && before[1]?.char === "B";
        return parserStateResult(ready ? first.char === "C" && second.char === "B" : null, "CR returns C to the first column while B remains", { before, first, second }, ready ? undefined : "AB control was not measured");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 3);
        if (refusal)
          return refusal;
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("AB");
        const before = await ctx.queryCursorPosition();
        ctx.write("\r");
        const pos = await ctx.queryCursorPosition();
        if (!before || !pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        if (before.row !== 1 || before.col !== 3) {
          return {
            pass: false,
            response: JSON.stringify({ before, pos }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Could not establish cursor at 1;3 before CR"
            }
          };
        }
        const pass = pos.row === 1 && pos.col === 1;
        return {
          pass,
          response: JSON.stringify({ before, pos }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "CR moves cursor from 1;3 to 1;1",
              observed: JSON.stringify({ before, pos })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.backspace", (ctx) => {
        ctx.feed("AB");
        const before = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\bC");
        const first = ctx.getCell(0, 0);
        const second = ctx.getCell(0, 1);
        const ready = before[0]?.char === "A" && before[1]?.char === "B";
        return parserStateResult(ready ? first.char === "A" && second.char === "C" : null, "Backspace lets C overwrite B while A remains", { before, first, second }, ready ? undefined : "AB control was not measured");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 5);
        if (refusal)
          return refusal;
        ctx.write("\x1B[1;5H");
        const before = await ctx.queryCursorPosition();
        ctx.write("\b");
        const pos = await ctx.queryCursorPosition();
        if (!before || !pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        if (before.row !== 1 || before.col !== 5) {
          return {
            pass: false,
            response: JSON.stringify({ before, pos }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Could not establish cursor at 1;5 before BS"
            }
          };
        }
        const pass = pos.row === 1 && pos.col === 4;
        return {
          pass,
          response: JSON.stringify({ before, pos }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "BS moves from 1;5 to 1;4",
              observed: JSON.stringify({ before, pos })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.index", (ctx) => {
        ctx.feed("A");
        const before = ctx.getCursor();
        ctx.feed("\x1BD");
        const after = ctx.getCursor();
        const ready = before.y === 0 && before.x === 1;
        return parserStateResult(ready ? after.y === 1 && after.x === 1 : null, "IND advances the parser cursor one row", { before, after }, ready ? undefined : "Starting cursor position was not measured");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 4, 5);
        if (refusal)
          return refusal;
        ctx.write("\x1B[3;5H");
        const before = await ctx.queryCursorPosition();
        ctx.write("\x1BD");
        const pos = await ctx.queryCursorPosition();
        if (!before || !pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        if (before.row !== 3 || before.col !== 5) {
          return {
            pass: false,
            response: JSON.stringify({ before, pos }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Could not establish starting cursor position"
            }
          };
        }
        const pass = pos.row === 4 && pos.col === 5;
        return {
          pass,
          response: JSON.stringify({ before, pos }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "IND advances cursor from 3;5 to 4;5",
              observed: JSON.stringify({ before, pos })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.next-line", (ctx) => {
        ctx.feed("ABC");
        const before = ctx.getCursor();
        ctx.feed("\x1BE");
        const after = ctx.getCursor();
        const ready = before.y === 0 && before.x === 3;
        return parserStateResult(ready ? after.y === 1 && after.x === 0 : null, "NEL advances the parser cursor to row 2 column 1", { before, after }, ready ? undefined : "Starting cursor position was not measured");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 4, 5);
        if (refusal)
          return refusal;
        ctx.write("\x1B[3;5H");
        const before = await ctx.queryCursorPosition();
        ctx.write("\x1BE");
        const pos = await ctx.queryCursorPosition();
        if (!before || !pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        if (before.row !== 3 || before.col !== 5) {
          return {
            pass: false,
            response: JSON.stringify({ before, pos }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Could not establish starting cursor position"
            }
          };
        }
        const pass = pos.row === 4 && pos.col === 1;
        return {
          pass,
          response: JSON.stringify({ before, pos }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "NEL advances cursor from 3;5 to 4;1",
              observed: JSON.stringify({ before, pos })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.reverse-index-scroll", (ctx) => {
        if (!validSize(ctx.getScrollback().screenLines, 5)) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        try {
          ctx.feed("\x1B[1;5r");
          ctx.feed("\x1B[H");
          ctx.feed("MARKER");
          const before = ctx.getCell(0, 0);
          ctx.feed("\x1B[H");
          ctx.feed("\x1BM");
          const cell = ctx.getCell(1, 0);
          return parserStateResult(before.char === "M" ? cell.char === "M" : null, "RI moves the measured MARKER to row 2", { before, cell }, before.char === "M" ? undefined : "MARKER control was not measured");
        } finally {
          ctx.feed("\x1B[r");
        }
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 10, 1);
        if (refusal)
          return refusal;
        try {
          ctx.write("\x1B[3;10r");
          ctx.write("\x1B[3;1H");
          ctx.write("\x1BM");
          const pos = await ctx.queryCursorPosition();
          return unmeasuredCellResult(pos, "RI scrolling of region contents");
        } finally {
          ctx.write("\x1B[r");
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.combining", (ctx) => {
        ctx.feed("AB");
        const ascii = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\x1B[1;1H\x1B[2K");
        ctx.feed("e\u0301X");
        const first = ctx.getCell(0, 0);
        const second = ctx.getCell(0, 1);
        const ready = ascii[0]?.char === "A" && ascii[1]?.char === "B" && first.char.includes("e");
        return parserStateResult(ready ? second.char === "X" : null, "Combining accent keeps X in the next parser cell", { ascii, first, second }, ready ? undefined : "ASCII control or combining sample was not measured");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 3);
        if (refusal)
          return refusal;
        const ascii = await ctx.measureRenderedWidth("A");
        const width = await ctx.measureRenderedWidth("e\u0301");
        if (ascii !== 1 || width === null) {
          return {
            pass: false,
            response: JSON.stringify({ ascii, width }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "ASCII width control or combining width was unavailable"
            }
          };
        }
        const pass = width === 1;
        return {
          pass,
          response: JSON.stringify({ ascii, width }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "e plus accent occupies one column after ASCII calibration",
              observed: JSON.stringify({ ascii, width })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.hts", (ctx) => {
        try {
          ctx.feed("\x1B[3g\x1B[6G\x1BH\x1B[1G\t");
          const cursor = ctx.getCursor();
          return parserStateResult(cursor.x === 5 && cursor.y === 0, "HTS makes the tab advance to column 6", {
            cursor
          });
        } finally {
          restoreDefaultTabs(ctx.feed, ctx.cols);
        }
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 9);
        if (refusal)
          return refusal;
        try {
          ctx.write("\x1B[3g\x1B[1;1H");
          const home = await ctx.queryCursorPosition();
          ctx.write("\x1B[1;9H\x1BH\x1B[1;1H");
          ctx.write("\t");
          const comparison = await ctx.queryCursorPosition();
          ctx.write("\x1B[1;6H\x1BH\x1B[1;1H");
          ctx.write("\t");
          const owned = await ctx.queryCursorPosition();
          return tabCombinedResult(home, comparison, owned, ctx.cols);
        } finally {
          restoreDefaultTabs(ctx.write, ctx.cols);
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.tbc", (ctx) => {
        const cols = ctx.cols;
        if (!validSize(cols, 34)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: "Tab fixture needs at least 34 columns"
            }
          };
        }
        try {
          installTabFixture(ctx.feed);
          ctx.feed("\x1B[1;25H\x1BH\x1B[1;1H");
          ctx.feed("\t");
          const oldFirst = ctx.getCursor();
          ctx.feed("\t");
          const oldSecond = ctx.getCursor();
          ctx.feed("\t");
          const oldThird = ctx.getCursor();
          ctx.feed("\x1B[3g\x1B[1;1H\t");
          const after = ctx.getCursor();
          const position = (cursor) => ({ row: cursor.y + 1, col: cursor.x + 1 });
          return tabClearResult({
            oldFirst: position(oldFirst),
            oldSecond: position(oldSecond),
            oldThird: position(oldThird),
            after: position(after)
          }, cols, "parser-state");
        } finally {
          restoreDefaultTabs(ctx.feed, cols);
        }
      }, async (ctx) => {
        if (!validSize(ctx.cols, 34)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Tab fixture needs at least 34 columns"
            }
          };
        }
        try {
          installTabFixture(ctx.write);
          ctx.write("\x1B[1;25H\x1BH\x1B[1;1H");
          ctx.write("\t");
          const oldFirst = await ctx.queryCursorPosition();
          ctx.write("\t");
          const oldSecond = await ctx.queryCursorPosition();
          ctx.write("\t");
          const oldThird = await ctx.queryCursorPosition();
          ctx.write("\x1B[3g\x1B[1;1H\t");
          const after = await ctx.queryCursorPosition();
          return tabClearResult({ oldFirst, oldSecond, oldThird, after }, ctx.cols, "behavior");
        } finally {
          restoreDefaultTabs(ctx.write, ctx.cols);
        }
      }, "behavior"),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("text.cht", (ctx) => {
        const cols = ctx.cols;
        if (!validSize(cols, 21)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: "Tab fixture needs at least 21 columns"
            }
          };
        }
        try {
          installTabFixture(ctx.feed);
          ctx.feed("\x1B[2I");
          const cursor = ctx.getCursor();
          return tabPositionResult({ row: cursor.y + 1, col: cursor.x + 1 }, 17, "parser-state");
        } finally {
          restoreDefaultTabs(ctx.feed, cols);
        }
      }, async (ctx) => {
        if (!validSize(ctx.cols, 21)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Tab fixture needs at least 21 columns"
            }
          };
        }
        try {
          installTabFixture(ctx.write);
          ctx.write("\x1B[2I");
          return tabPositionResult(await ctx.queryCursorPosition(), 17, "behavior");
        } finally {
          restoreDefaultTabs(ctx.write, ctx.cols);
        }
      }, "behavior"),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("text.cbt", (ctx) => {
        const cols = ctx.cols;
        if (!validSize(cols, 21)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: "Tab fixture needs at least 21 columns"
            }
          };
        }
        try {
          installTabFixture(ctx.feed);
          ctx.feed("\x1B[1;21H\x1B[Z");
          const cursor = ctx.getCursor();
          return tabPositionResult({ row: cursor.y + 1, col: cursor.x + 1 }, 17, "parser-state");
        } finally {
          restoreDefaultTabs(ctx.feed, cols);
        }
      }, async (ctx) => {
        if (!validSize(ctx.cols, 21)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Tab fixture needs at least 21 columns"
            }
          };
        }
        try {
          installTabFixture(ctx.write);
          ctx.write("\x1B[1;21H\x1B[Z");
          return tabPositionResult(await ctx.queryCursorPosition(), 17, "behavior");
        } finally {
          restoreDefaultTabs(ctx.write, ctx.cols);
        }
      }, "behavior"),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("text.wide.emoji-flags", (ctx) => {
        ctx.feed("AA");
        const ascii = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\x1B[1;1H\x1B[2K");
        ctx.feed("\uD83C\uDDFA\uD83C\uDDF8X");
        const cell = ctx.getCell(0, 0);
        const next = ctx.getCell(0, 2);
        const ready = ascii[0]?.char === "A" && ascii[1]?.char === "A" && cell.char.includes("\uD83C\uDDFA") && next.char === "X";
        return parserStateResult(ready ? cell.wide === true : null, "Flag sample occupies one wide parser cell before X", { ascii, cell, next }, ready ? undefined : "ASCII, flag, or X control cells were not exposed");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 4);
        if (refusal)
          return refusal;
        const ascii = await ctx.measureRenderedWidth("AA");
        const width = await ctx.measureRenderedWidth("\uD83C\uDDFA\uD83C\uDDF8");
        if (ascii !== 2 || width === null) {
          return {
            pass: false,
            response: JSON.stringify({ ascii, width }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "ASCII width control or flag width was unavailable"
            }
          };
        }
        const pass = width === 2;
        return {
          pass,
          response: JSON.stringify({ ascii, width }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "Flag sample occupies two columns after ASCII calibration",
              observed: JSON.stringify({ ascii, width })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.wide.emoji-vs16", (ctx) => {
        ctx.feed("AA");
        const ascii = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\x1B[1;1H\x1B[2K");
        ctx.feed("\u263A\uFE0FX");
        const cell = ctx.getCell(0, 0);
        const next = ctx.getCell(0, 2);
        const ready = ascii[0]?.char === "A" && ascii[1]?.char === "A" && cell.char.includes("\u263A") && next.char === "X";
        return parserStateResult(ready ? cell.wide === true : null, "VS16 sample occupies one wide parser cell before X", { ascii, cell, next }, ready ? undefined : "ASCII, VS16, or X control cells were not exposed");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 3);
        if (refusal)
          return refusal;
        const ascii = await ctx.measureRenderedWidth("AA");
        const width = await ctx.measureRenderedWidth("\u263A\uFE0F");
        if (ascii !== 2 || width === null) {
          return {
            pass: false,
            response: JSON.stringify({ ascii, width }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "ASCII width control or VS16 width was unavailable"
            }
          };
        }
        const pass = width === 2;
        return {
          pass,
          response: JSON.stringify({ ascii, width }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "VS16 sample occupies two columns after ASCII calibration",
              observed: JSON.stringify({ ascii, width })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("text.wide.emoji-zwj", (ctx) => {
        ctx.feed("AA");
        const ascii = [ctx.getCell(0, 0), ctx.getCell(0, 1)];
        ctx.feed("\x1B[1;1H\x1B[2K");
        ctx.feed("\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67X");
        const cell = ctx.getCell(0, 0);
        const next = ctx.getCell(0, 2);
        const ready = ascii[0]?.char === "A" && ascii[1]?.char === "A" && cell.char.includes("\uD83D\uDC68") && next.char === "X";
        return parserStateResult(ready ? cell.wide === true : null, "ZWJ sample occupies one wide parser cell before X", { ascii, cell, next }, ready ? undefined : "ASCII, ZWJ, or X control cells were not exposed");
      }, async (ctx) => {
        const refusal = tooSmall(ctx, 1, 4);
        if (refusal)
          return refusal;
        const ascii = await ctx.measureRenderedWidth("AA");
        const width = await ctx.measureRenderedWidth("\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67");
        if (ascii !== 2 || width === null) {
          return {
            pass: false,
            response: JSON.stringify({ ascii, width }),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "ASCII width control or ZWJ width was unavailable"
            }
          };
        }
        const pass = width === 2;
        return {
          pass,
          response: JSON.stringify({ ascii, width }),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "ZWJ sample occupies two columns after ASCII calibration",
              observed: JSON.stringify({ ascii, width })
            }
          ]
        };
      }),
      termNeedsGeometry: true
    }
  ];
});

// ../probe-defs/src/erase.ts
function rowCells(ctx, row) {
  return Array.from({ length: 5 }, (_, col) => {
    const char = ctx.getCell(row, col).char;
    return typeof char === "string" ? char : null;
  });
}
function eraseRowResult(ctx, setup, sequence, expected, adjacentRow = false, expectedCursorX) {
  const rows = ctx.getScrollback().screenLines;
  if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6 || !Number.isSafeInteger(rows) || rows < (adjacentRow ? 2 : 1)) {
    return parserStateResult(null, "Complete erase row fixture", { cols: ctx.cols, rows }, "Measured geometry cannot fit the erase fixture");
  }
  ctx.feed(setup);
  const before = rowCells(ctx, 0);
  const neighborBefore = adjacentRow ? rowCells(ctx, 1) : undefined;
  const cursorBefore = expectedCursorX === undefined ? undefined : ctx.getCursor();
  ctx.feed(sequence);
  const after = rowCells(ctx, 0);
  const neighborAfter = adjacentRow ? rowCells(ctx, 1) : undefined;
  const response = JSON.stringify({
    before,
    ...cursorBefore && { cursorBefore: { x: cursorBefore.x, y: cursorBefore.y } },
    after,
    ...adjacentRow && { neighborBefore, neighborAfter }
  });
  const fixtureReady = before.join("") === "ABCDE" && (!adjacentRow || neighborBefore?.join("") === "KEEP!") && (expectedCursorX === undefined || cursorBefore?.x === expectedCursorX && cursorBefore?.y === 0);
  const measured = [...after, ...neighborAfter ?? []];
  if (!fixtureReady || measured.some((char) => char === null)) {
    return {
      pass: false,
      response,
      note: "Erase fixture, cursor setup, or cell metadata unavailable",
      observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "parser-state" }
    };
  }
  const exact = expected.every((char, col) => char === "blank" ? isBlank(after[col] ?? "\x00") : after[col] === char);
  const neighborPreserved = !adjacentRow || neighborAfter?.join("") === "KEEP!";
  const supported = exact && neighborPreserved;
  return {
    pass: supported,
    response,
    observation: { outcome: supported ? "supported" : "unsupported", evidence: "parser-state" },
    assertions: [
      {
        kind: supported ? "positive" : "negative",
        expected: `row 0 ${expected.join(",")}${adjacentRow ? "; row 1 KEEP!" : ""}${expectedCursorX === undefined ? "" : `; cursor before ${expectedCursorX},0`}`,
        observed: response
      }
    ]
  };
}
function eraseScreenResult(ctx, sequence, expected) {
  const initialScrollback = ctx.getScrollback();
  const lines = initialScrollback.screenLines;
  if (!Number.isSafeInteger(lines) || lines < 3 || !Number.isSafeInteger(ctx.cols) || ctx.cols < 6) {
    return {
      pass: false,
      response: JSON.stringify({ initialScrollback }),
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "parser-state",
        note: "Screen fixture needs at least three measured rows and six columns"
      }
    };
  }
  const middle = Math.floor(lines / 2);
  const rows = [0, middle, lines - 1];
  ctx.feed(`\x1B[1;1HAAAAA\x1B[${middle + 1};1HBBBBB\x1B[${lines};1HCCCCC\x1B[${middle + 1};3H`);
  const before = rows.map((row) => rowCells(ctx, row));
  const cursorBefore = ctx.getCursor();
  const scrollbackBefore = ctx.getScrollback();
  ctx.feed(sequence);
  const after = rows.map((row) => rowCells(ctx, row));
  const cursorAfter = ctx.getCursor();
  const scrollbackAfter = ctx.getScrollback();
  const response = JSON.stringify({
    rows,
    before,
    cursorBefore: { x: cursorBefore.x, y: cursorBefore.y },
    scrollbackBefore,
    after,
    cursorAfter: { x: cursorAfter.x, y: cursorAfter.y },
    scrollbackAfter
  });
  const fixtureReady = before.every((row, i) => row.join("") === ["AAAAA", "BBBBB", "CCCCC"][i]) && cursorBefore.x === 2 && cursorBefore.y === middle && Number.isInteger(scrollbackBefore.totalLines) && scrollbackBefore.totalLines >= lines && !after.some((row) => row.some((char) => char === null));
  if (!fixtureReady) {
    return {
      pass: false,
      response,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "parser-state",
        note: "Screen fixture, cursor setup, or cell readback unavailable"
      }
    };
  }
  const cellsMatch = expected.every((expectedRow, row) => [...expectedRow].every((expectedChar, col) => {
    const actual = after[row]?.[col];
    return expectedChar === " " ? isBlank(actual ?? "\x00") : actual === expectedChar;
  }));
  const preservedCursor = cursorAfter.x === cursorBefore.x && cursorAfter.y === cursorBefore.y;
  const supported = cellsMatch && preservedCursor;
  return {
    pass: supported,
    response,
    observation: { outcome: supported ? "supported" : "unsupported", evidence: "parser-state" },
    assertions: [
      {
        kind: supported ? "positive" : "negative",
        expected: `rows ${rows.join(",")}: ${expected.join("/")}; cursor preserved`,
        observed: response
      }
    ]
  };
}
async function captureEraseFixture(ctx, kind, sequence, expected) {
  const rows = ctx.rows;
  const cols = ctx.cols;
  const minRows = kind === "line" ? 2 : 3;
  const capture = ctx.capture;
  if (!capture || !Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < minRows || cols < 6) {
    const note = `Erase pixel fixture needs capture and measured ${minRows}x6 geometry; measured ${rows}x${cols}`;
    return {
      pass: false,
      observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
    };
  }
  const middle = Math.floor((rows + 1) / 2);
  const safeCursor = `\x1B[${kind === "line" ? 2 : rows};6H`;
  const seed = kind === "line" ? "\x1B[1;1HABCDE\x1B[2;1HKEEP!" : `\x1B[1;1HAAAAA\x1B[${middle};1HBBBBB\x1B[${rows};1HCCCCC`;
  const eraseAt = `\x1B[${kind === "line" ? 1 : middle};3H`;
  try {
    ctx.write("\x1B[0m");
    const blankRow = " ".repeat(cols);
    for (let row = 1;row <= rows; row++)
      ctx.write(`\x1B[${row};1H${blankRow}`);
    ctx.write(safeCursor);
    const blank = await capture({ role: "control", label: "Blank erase comparator" });
    ctx.write(seed);
    ctx.write(safeCursor);
    const before = await capture({ role: "control", label: "Before erase: seeded and unaffected cells" });
    ctx.write(eraseAt);
    ctx.write(sequence);
    ctx.write(safeCursor);
    const target = await capture({ role: "target", label: "After erase: target and unaffected cells" });
    const observed = JSON.stringify({
      rows,
      cols,
      middle: kind === "screen" ? middle : undefined,
      blank,
      before,
      target
    });
    return {
      pass: false,
      response: observed,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "pixels",
        screenshotRef: target.ref,
        frames: [blank, before, target],
        note: "Blank comparator and seeded target/control pixels captured; erase effect requires independent review"
      },
      assertions: [
        {
          kind: "positive",
          expected: `Capture blank comparator, seeded before, and post-${sequence} target at measured geometry; visual expectation ${expected}`,
          observed,
          note: "capture-only assertion; no erase support judgment"
        }
      ]
    };
  } finally {
    ctx.write("\x1B[0m\x1B[2J\x1B[H");
  }
}
var eraseProbes;
var init_erase = __esm(() => {
  eraseProbes = [
    {
      ...probe("erase.line.right", (ctx) => eraseRowResult(ctx, "ABCDE\x1B[3G", "\x1B[K", ["A", "B", "blank", "blank", "blank"], false, 2), (ctx) => captureEraseFixture(ctx, "line", "\x1B[0K", "row 1 AB___; row 2 KEEP!")),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("erase.line.left", (ctx) => eraseRowResult(ctx, "ABCDE\x1B[3G", "\x1B[1K", ["blank", "blank", "blank", "D", "E"], false, 2), (ctx) => captureEraseFixture(ctx, "line", "\x1B[1K", "row 1 ___DE; row 2 KEEP!")),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("erase.line.all", (ctx) => eraseRowResult(ctx, `ABCDE\r
KEEP!\x1B[1;3H`, "\x1B[2K", ["blank", "blank", "blank", "blank", "blank"], true), (ctx) => captureEraseFixture(ctx, "line", "\x1B[2K", "row 1 _____; row 2 KEEP!")),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("erase.screen.below", (ctx) => eraseScreenResult(ctx, "\x1B[0J", ["AAAAA", "BB   ", "     "]), (ctx) => captureEraseFixture(ctx, "screen", "\x1B[0J", "top AAAAA; middle BB___; bottom _____")),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("erase.screen.above", (ctx) => eraseScreenResult(ctx, "\x1B[1J", ["     ", "   BB", "CCCCC"]), (ctx) => captureEraseFixture(ctx, "screen", "\x1B[1J", "top _____; middle ___BB; bottom CCCCC")),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("erase.screen.all", (ctx) => eraseScreenResult(ctx, "\x1B[2J", ["     ", "     ", "     "]), (ctx) => captureEraseFixture(ctx, "screen", "\x1B[2J", "top/middle/bottom _____")),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("erase.screen.scrollback", (ctx) => {
        const expected = "ED3 removes measured scrollback while keeping screen geometry";
        const initial = ctx.getScrollback();
        const rows = initial.screenLines;
        if (!Number.isSafeInteger(rows) || rows < 1 || rows > 1000) {
          return parserStateResult(null, expected, { initial }, "Need a measured screen size for history setup");
        }
        ctx.feed(`\r
`.repeat(rows + 2));
        const before = ctx.getScrollback();
        if (!Number.isSafeInteger(before.totalLines) || before.totalLines <= rows || before.screenLines !== rows) {
          return parserStateResult(null, expected, { initial, before }, "No measured scrollback to erase");
        }
        ctx.feed("\x1B[3J");
        const after = ctx.getScrollback();
        const measured = Number.isSafeInteger(after.totalLines) && after.totalLines >= rows && after.screenLines === rows;
        return parserStateResult(measured ? after.totalLines === rows : null, expected, { before, after }, measured ? undefined : "Scrollback readback or geometry changed unexpectedly");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 5 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Erase fixture needs at least 5x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[5;5H");
        ctx.write("\x1B[3J");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "erased cells or scrollback");
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("erase.character", (ctx) => eraseRowResult(ctx, "ABCDE\x1B[1G", "\x1B[3X", ["blank", "blank", "blank", "D", "E"], false, 0), async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 6) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Erase fixture needs at least 1x6, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("ABCD");
        ctx.write("\x1B[1;2H");
        ctx.write("\x1B[2X");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "erased cells or scrollback");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("erase.selective", (ctx) => selectiveEraseResult(ctx, "\x1B[?2J", false), async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 6) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Erase fixture needs at least 1x6, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("ABCDE");
        ctx.write("\x1B[?2J");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "erased cells or scrollback");
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("erase.el-with-attrs", (ctx) => {
        const expected = "EL erases X while preserving its measured non-default background";
        try {
          ctx.feed("\x1B[42m\x1B[1;1HXXXXX\x1B[1;1H");
          const before = ctx.getCell(0, 0);
          if (before.char !== "X" || before.bg == null) {
            return parserStateResult(null, expected, { before }, "Colored X setup was not measured");
          }
          ctx.feed("\x1B[K");
          const after = ctx.getCell(0, 0);
          const measured = typeof after.char === "string" && after.bg != null;
          return parserStateResult(measured ? isBlank(after.char) && after.bg?.r === before.bg.r && after.bg?.g === before.bg.g && after.bg?.b === before.bg.b : null, expected, { before, after }, measured ? undefined : "Erased cell background metadata unavailable");
        } finally {
          ctx.feed("\x1B[0m");
        }
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 6) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Erase fixture needs at least 1x6, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        try {
          ctx.write("\x1B[42m");
          ctx.write("XXXXX");
          ctx.write("\x1B[1;1H");
          ctx.write("\x1B[K");
          const pos = await ctx.queryCursorPosition();
          return unmeasuredCellResult(pos, "erased cells or scrollback");
        } finally {
          ctx.write("\x1B[0m");
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("erase.ed-scroll-region", (ctx) => {
        const expected = "ED0 erases measured cells below the cursor and preserves the preceding row";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(rows) || rows < 10 || !Number.isSafeInteger(ctx.cols) || ctx.cols < 10) {
          return parserStateResult(null, expected, { rows, cols: ctx.cols }, "Need a measured 10x10 fixture");
        }
        try {
          ctx.feed("\x1B[1;1HKEEP!\x1B[3;1HERASE\x1B[3;10r\x1B[3;1H");
          const before = { control: rowCells(ctx, 0), target: rowCells(ctx, 2), cursor: ctx.getCursor() };
          if (before.control.join("") !== "KEEP!" || before.target.join("") !== "ERASE" || before.cursor.x !== 0 || before.cursor.y !== 2) {
            return parserStateResult(null, expected, { before }, "Erase region seed or cursor setup failed");
          }
          ctx.feed("\x1B[J");
          const after = { control: rowCells(ctx, 0), target: rowCells(ctx, 2) };
          const valid = after.control.join("") === "KEEP!" && after.target.every((char) => char !== null);
          return parserStateResult(valid ? after.target.every((char) => char !== null && isBlank(char)) : null, expected, { before, after }, valid ? undefined : "Preceding row or cell metadata was not preserved");
        } finally {
          ctx.feed("\x1B[r");
        }
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 10 || ctx.cols < 10) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Erase fixture needs at least 10x10, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[2J\x1B[H");
        ctx.write(`KEEP_THIS\r
`);
        for (let i = 1;i <= 5; i++)
          ctx.write(`row${i}\r
`);
        try {
          ctx.write("\x1B[3;10r");
          ctx.write("\x1B[3;1H");
          ctx.write("\x1B[J");
          const pos = await ctx.queryCursorPosition();
          return unmeasuredCellResult(pos, "erased cells or scrollback");
        } finally {
          ctx.write("\x1B[r");
        }
      }),
      termNeedsGeometry: true
    }
  ];
});

// ../probe-defs/src/editing.ts
function checksumResult(response) {
  const supported = /\x1bP1!~[0-9A-Fa-f]{4}\x1b\\/.test(response);
  return {
    pass: supported,
    response,
    note: "Checks framed reply and request id; checksum arithmetic is not verified",
    observation: {
      outcome: supported ? "supported" : "inconclusive",
      evidence: "query",
      ...!supported && { reason: response ? "invalid-reply" : "no-response" }
    },
    ...supported && {
      assertions: [
        { kind: "positive", expected: "Complete four-digit checksum reply for request 1", observed: response }
      ]
    }
  };
}
var editingProbes;
var init_editing = __esm(() => {
  editingProbes = [
    {
      ...probe("editing.insert-chars", (ctx) => {
        const expected = "ICH inserts a blank cell at column 3 and shifts measured text right; prefix stays intact";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 8) {
          return parserStateResult(null, expected, { cols: ctx.cols }, "Need eight measured columns for the ICH fixture");
        }
        ctx.feed("\x1B[1;1H\x1B[2KABCDEZQH");
        const before = Array.from({ length: 8 }, (_, col) => ctx.getCell(0, col).char);
        if (before.join("") !== "ABCDEZQH") {
          return parserStateResult(null, expected, { before }, "ICH seed was not measured before the edit");
        }
        ctx.feed("\x1B[1;3H");
        const setup = ctx.getCursor();
        if (setup.x !== 2 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "ICH cursor setup did not reach column 3");
        }
        ctx.feed("\x1B[1@");
        const after = Array.from({ length: 8 }, (_, col) => ctx.getCell(0, col).char);
        const controlsValid = after[0] === "A" && after[1] === "B";
        return parserStateResult(controlsValid ? isBlank(after[2] ?? "") && after.slice(3).join("") === "CDEZQ" : null, expected, { before, setup, after }, controlsValid ? undefined : "ICH prefix control changed during the edit");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 1x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("ABCD");
        ctx.write("\x1B[1;2H");
        ctx.write("\x1B[1@");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.delete-chars", (ctx) => {
        const expected = "DCH deletes the cell at column 3 and shifts measured text left; prefix stays intact";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 8) {
          return parserStateResult(null, expected, { cols: ctx.cols }, "Need eight measured columns for the DCH fixture");
        }
        ctx.feed("\x1B[1;1H\x1B[2KABCDEZQH");
        const before = Array.from({ length: 8 }, (_, col) => ctx.getCell(0, col).char);
        if (before.join("") !== "ABCDEZQH") {
          return parserStateResult(null, expected, { before }, "DCH seed was not measured before the edit");
        }
        ctx.feed("\x1B[1;3H");
        const setup = ctx.getCursor();
        if (setup.x !== 2 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "DCH cursor setup did not reach column 3");
        }
        ctx.feed("\x1B[1P");
        const after = Array.from({ length: 7 }, (_, col) => ctx.getCell(0, col).char);
        const controlsValid = after[0] === "A" && after[1] === "B";
        return parserStateResult(controlsValid ? after.slice(2).join("") === "DEZQH" : null, expected, { before, setup, after }, controlsValid ? undefined : "DCH prefix control changed during the edit");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 1x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("ABCD");
        ctx.write("\x1B[1;2H");
        ctx.write("\x1B[1P");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.insert-lines", (ctx) => {
        const expected = "IL inserts a blank row 2 and shifts measured rows down while row 1 stays intact";
        const screenLines = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6 || !Number.isSafeInteger(screenLines) || screenLines < 4) {
          return parserStateResult(null, expected, { cols: ctx.cols, screenLines }, "Need six measured columns and four measured screen lines for IL");
        }
        const seed = ["AAAAA", "BBBBB", "CCCCC", "DDDDD"];
        for (const [row, text] of seed.entries())
          ctx.feed(`\x1B[${row + 1};1H\x1B[2K${text}`);
        const before = seed.map((_, row) => Array.from({ length: 5 }, (_, col) => ctx.getCell(row, col).char));
        if (before.some((cells, row) => cells.join("") !== seed[row])) {
          return parserStateResult(null, expected, { before }, "IL source rows were not measured before the edit");
        }
        ctx.feed("\x1B[2;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 1) {
          return parserStateResult(null, expected, { before, setup }, "IL cursor setup did not reach row 2 column 1");
        }
        ctx.feed("\x1B[1L");
        const after = seed.map((_, row) => Array.from({ length: 5 }, (_, col) => ctx.getCell(row, col).char));
        const controlsValid = after[0]?.join("") === "AAAAA";
        return parserStateResult(controlsValid ? after[1]?.every(isBlank) === true && after[2]?.join("") === "BBBBB" && after[3]?.join("") === "CCCCC" : null, expected, { before, setup, after }, controlsValid ? undefined : "IL first-row control changed during the edit");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[3;5H");
        ctx.write("\x1B[1L");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.delete-lines", (ctx) => {
        const expected = "DL removes row 2 and shifts measured rows up while row 1 stays intact";
        const screenLines = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6 || !Number.isSafeInteger(screenLines) || screenLines < 4) {
          return parserStateResult(null, expected, { cols: ctx.cols, screenLines }, "Need six measured columns and four measured screen lines for DL");
        }
        const seed = ["AAAAA", "BBBBB", "CCCCC", "DDDDD"];
        for (const [row, text] of seed.entries())
          ctx.feed(`\x1B[${row + 1};1H\x1B[2K${text}`);
        const before = seed.map((_, row) => Array.from({ length: 5 }, (_, col) => ctx.getCell(row, col).char));
        if (before.some((cells, row) => cells.join("") !== seed[row])) {
          return parserStateResult(null, expected, { before }, "DL source rows were not measured before the edit");
        }
        ctx.feed("\x1B[2;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 1) {
          return parserStateResult(null, expected, { before, setup }, "DL cursor setup did not reach row 2 column 1");
        }
        ctx.feed("\x1B[1M");
        const after = Array.from({ length: 3 }, (_, row) => Array.from({ length: 5 }, (_, col) => ctx.getCell(row, col).char));
        const controlsValid = after[0]?.join("") === "AAAAA";
        return parserStateResult(controlsValid ? after[1]?.join("") === "CCCCC" && after[2]?.join("") === "DDDDD" : null, expected, { before, setup, after }, controlsValid ? undefined : "DL first-row control changed during the edit");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[3;5H");
        ctx.write("\x1B[1M");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.repeat-char", (ctx) => {
        const expected = "REP repeats the immediately preceding X into three target cells without changing flank controls";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6) {
          return parserStateResult(null, expected, { cols: ctx.cols }, "Need six measured columns for the REP fixture");
        }
        ctx.feed("\x1B[1;1H\x1B[2KAX   Z");
        const seed = Array.from({ length: 6 }, (_, col) => ctx.getCell(0, col).char);
        if (seed.join("") !== "AX   Z") {
          return parserStateResult(null, expected, { seed }, "REP flank and blank seed was not measured");
        }
        ctx.feed("\x1B[1;2H");
        const targetPosition = ctx.getCursor();
        if (targetPosition.x !== 1 || targetPosition.y !== 0) {
          return parserStateResult(null, expected, { seed, targetPosition }, "REP cursor setup did not reach column 2");
        }
        ctx.feed("X");
        const before = Array.from({ length: 6 }, (_, col) => ctx.getCell(0, col).char);
        const setup = ctx.getCursor();
        if (before.join("") !== "AX   Z" || setup.x !== 2 || setup.y !== 0) {
          return parserStateResult(null, expected, { seed, targetPosition, before, setup }, "REP X setup was not measured");
        }
        ctx.feed("\x1B[3b");
        const after = Array.from({ length: 6 }, (_, col) => ctx.getCell(0, col).char);
        const controlsValid = after[0] === "A" && after[5] === "Z";
        return parserStateResult(controlsValid ? after.slice(1, 5).join("") === "XXXX" : null, expected, { seed, targetPosition, before, setup, after }, controlsValid ? undefined : "REP flank control changed during the edit");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 6) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 1x6, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("X");
        ctx.write("\x1B[4b");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.decfra", (ctx) => {
        const expected = "DECFRA fills the measured 3x5 area and preserves its measured right flank";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6 || !Number.isSafeInteger(ctx.getScrollback().screenLines) || ctx.getScrollback().screenLines < 3) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows: ctx.getScrollback().screenLines }, "Need a measured 3x6 fixture");
        }
        ctx.feed("\x1B[1;1HaaaaaZ\x1B[2;1HbbbbbY\x1B[3;1HcccccW");
        const before = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col).char).join(""));
        if (before.join("|") !== "aaaaaZ|bbbbbY|cccccW") {
          return parserStateResult(null, expected, { before }, "DECFRA seed was not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "DECFRA cursor setup failed");
        }
        ctx.feed("\x1B[88;1;1;3;5$x");
        const after = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col).char).join(""));
        const controlsValid = after.every((line, row) => line[5] === before[row]?.[5]);
        return parserStateResult(controlsValid ? after.every((line) => line.slice(0, 5) === "XXXXX") : null, expected, { before, setup, after }, controlsValid ? undefined : "DECFRA outside control changed");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        ctx.write("\x1B[88;1;1;3;5$x");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.decera", (ctx) => {
        const expected = "DECERA blanks measured 3x5 cells and preserves their measured right flank";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6 || !Number.isSafeInteger(rows) || rows < 3) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 3x6 fixture");
        }
        const seeds = ["aaaaaZ", "bbbbbY", "cccccX"];
        ctx.feed("\x1B[1;1HaaaaaZ\x1B[2;1HbbbbbY\x1B[3;1HcccccX");
        const before = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col).char));
        if (!before.every((line, row) => line.every((char, col) => char === seeds[row]?.[col]))) {
          return parserStateResult(null, expected, { before }, "DECERA seed was not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "DECERA cursor setup failed");
        }
        ctx.feed("\x1B[1;1;3;5$z");
        const after = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col).char));
        const controlsValid = after.every((line, row) => line[5] === before[row]?.[5]);
        return parserStateResult(controlsValid ? after.every((line) => line.slice(0, 5).every(isBlank)) : null, expected, { before, setup, after }, controlsValid ? undefined : "DECERA outside control changed");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        ctx.write("\x1B[1;1;3;5$z");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.decsera", (ctx) => selectiveEraseResult(ctx, "\x1B[1;1;1;5${", true), async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        ctx.write("\x1B[1;1;3;5${");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("editing.deccra", (ctx) => {
        const expected = "DECCRA copies measured 2x5 source cells to row 5 column 10 without changing the source";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 14 || !Number.isSafeInteger(rows) || rows < 6) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 6x14 fixture");
        }
        ctx.feed("\x1B[1;1HABCDE.........\x1B[2;1HFGHIJ.........\x1B[3;1H..............\x1B[4;1H..............\x1B[5;1H.........12345\x1B[6;1H.........67890");
        const before = Array.from({ length: 6 }, (_, row) => Array.from({ length: 14 }, (_, col) => ctx.getCell(row, col).char).join(""));
        if (before.join("|") !== "ABCDE.........|FGHIJ.........|..............|..............|.........12345|.........67890") {
          return parserStateResult(null, expected, { before }, "DECCRA source and destination were not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "DECCRA cursor setup failed");
        }
        ctx.feed("\x1B[1;1;2;5;1;5;10$v");
        const after = Array.from({ length: 6 }, (_, row) => Array.from({ length: 14 }, (_, col) => ctx.getCell(row, col).char).join(""));
        const controlsValid = after.slice(0, 4).every((line, row) => line === before[row]) && after[4]?.slice(0, 9) === before[4]?.slice(0, 9) && after[5]?.slice(0, 9) === before[5]?.slice(0, 9);
        return parserStateResult(controlsValid ? after[4]?.slice(9) === "ABCDE" && after[5]?.slice(9) === "FGHIJ" : null, expected, { before, setup, after }, controlsValid ? undefined : "DECCRA source or outside control changed");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 6 || ctx.cols < 14) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 6x14, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        ctx.write("\x1B[1;1;2;5;1;5;10$v");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.deccara", (ctx) => {
        const expected = "DECCARA sets inverse on measured 3x5 cells, preserving text and right flank";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6 || !Number.isSafeInteger(rows) || rows < 3) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 3x6 fixture");
        }
        ctx.feed("\x1B[1;1HaaaaaZ\x1B[2;1HbbbbbY\x1B[3;1HcccccX");
        const before = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col)));
        if (before.map((line) => line.map((cell) => cell.char).join("")).join("|") !== "aaaaaZ|bbbbbY|cccccX" || before.some((line) => line.some((cell) => cell.inverse))) {
          return parserStateResult(null, expected, { before }, "DECCARA character and attribute seed was not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "DECCARA cursor setup failed");
        }
        ctx.feed("\x1B[1;1;3;5;7$r");
        const after = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col)));
        const controlsValid = after.every((line, row) => line.every((cell, col) => cell.char === before[row]?.[col]?.char) && !line[5]?.inverse);
        return parserStateResult(controlsValid ? after.every((line) => line.slice(0, 5).every((cell) => cell.inverse)) : null, expected, { before, setup, after }, controlsValid ? undefined : "DECCARA character or outside attribute control changed");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        ctx.write("\x1B[1;1;3;5;7$r");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.decrara", (ctx) => {
        const expected = "DECRARA clears inverse on measured 3x5 inverse cells, preserving text and right flank";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 6 || !Number.isSafeInteger(rows) || rows < 3) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 3x6 fixture");
        }
        ctx.feed("\x1B[1;1H\x1B[7maaaaa\x1B[0mZ\x1B[2;1H\x1B[7mbbbbb\x1B[0mY\x1B[3;1H\x1B[7mccccc\x1B[0mX");
        const before = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col)));
        if (before.map((line) => line.map((cell) => cell.char).join("")).join("|") !== "aaaaaZ|bbbbbY|cccccX" || before.some((line) => !line.slice(0, 5).every((cell) => cell.inverse) || line[5]?.inverse)) {
          return parserStateResult(null, expected, { before }, "DECRARA inverse seed was not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "DECRARA cursor setup failed");
        }
        ctx.feed("\x1B[1;1;3;5;7$t");
        const after = Array.from({ length: 3 }, (_, row) => Array.from({ length: 6 }, (_, col) => ctx.getCell(row, col)));
        const controlsValid = after.every((line, row) => line.every((cell, col) => cell.char === before[row]?.[col]?.char) && !line[5]?.inverse);
        return parserStateResult(controlsValid ? after.every((line) => line.slice(0, 5).every((cell) => !cell.inverse)) : null, expected, { before, setup, after }, controlsValid ? undefined : "DECRARA character or outside attribute control changed");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H");
        ctx.write("\x1B[1;1;3;5;7$t");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    probe("editing.decsace", (ctx) => {
      ctx.feed("\x1B[1;1H\x1B[2*x");
      const text = ctx.getText();
      return {
        pass: false,
        response: JSON.stringify({ text }),
        note: "Sequence consumption does not measure attribute-change extent",
        observation: { outcome: "inconclusive", evidence: "consumed", reason: "insufficient-evidence" }
      };
    }, () => {
      const note = "DECSACE was not attempted; this probe does not measure attribute-change extent";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    probe("editing.decrqcra", (ctx) => {
      ctx.feed("ABCDE\x1B[1;1H");
      return checksumResult(ctx.feedCapture("\x1B[1;1;1;1;1;5*y"));
    }, async (ctx) => {
      const reply = await ctx.queryOutcome("\x1B[1;1;1;1;1;1*y", /\x1bP1!~[0-9A-Fa-f]{4}\x1b\\/, 2000);
      return checksumResult(reply.raw);
    }),
    {
      ...probe("editing.sl", (ctx) => {
        const expected = "SL shifts the first nine observed cells of two rows left by two columns";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 9 || !Number.isSafeInteger(rows) || rows < 2) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 2x9 fixture");
        }
        const measuredWidth = Math.min(ctx.cols, 11);
        const seeds = ["ABCDEFGHIJK".slice(0, measuredWidth), "JKLMNOPQRST".slice(0, measuredWidth)];
        ctx.feed(`\x1B[1;1H${seeds[0]}\x1B[2;1H${seeds[1]}`);
        const before = Array.from({ length: 2 }, (_, row) => Array.from({ length: measuredWidth }, (_, col) => ctx.getCell(row, col).char));
        if (!before.every((line, row) => line.every((char, col) => char === seeds[row]?.[col]))) {
          return parserStateResult(null, expected, { before }, "SL seed and incoming sources were not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "SL cursor setup failed");
        }
        ctx.feed("\x1B[2 @");
        const after = Array.from({ length: 2 }, (_, row) => Array.from({ length: 9 }, (_, col) => ctx.getCell(row, col).char));
        return parserStateResult(after.every((line, row) => line.every((char, col) => col + 2 < ctx.cols ? char === before[row]?.[col + 2] : isBlank(char))), expected, { before, setup, after });
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 8) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 1x8, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("1234567");
        ctx.write("\x1B[2 @");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.sr", (ctx) => {
        const expected = "SR shifts the first nine measured cells of two rows right by two columns";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 9 || !Number.isSafeInteger(rows) || rows < 2) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 2x9 fixture");
        }
        const seeds = ["ABCDEFGHI", "JKLMNOPQR"];
        ctx.feed("\x1B[1;1HABCDEFGHI\x1B[2;1HJKLMNOPQR");
        const before = Array.from({ length: 2 }, (_, row) => Array.from({ length: 9 }, (_, col) => ctx.getCell(row, col).char));
        if (!before.every((line, row) => line.every((char, col) => char === seeds[row]?.[col]))) {
          return parserStateResult(null, expected, { before }, "SR seed was not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setup = ctx.getCursor();
        if (setup.x !== 0 || setup.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "SR cursor setup failed");
        }
        ctx.feed("\x1B[2 A");
        const after = Array.from({ length: 2 }, (_, row) => Array.from({ length: 9 }, (_, col) => ctx.getCell(row, col).char));
        return parserStateResult(after.every((line, row) => line.every((char, col) => col < 2 ? isBlank(char) : char === before[row]?.[col - 2])), expected, { before, setup, after });
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 9) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 1x9, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("1234567");
        ctx.write("\x1B[2 A");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.decic", (ctx) => {
        const expected = "DECIC inserts two blank columns at column 3 on three measured rows";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 8 || !Number.isSafeInteger(rows) || rows < 3) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 3x8 fixture");
        }
        const seeds = ["ABCDEFGH", "IJKLMNOP", "QRSTUVWX"];
        ctx.feed("\x1B[1;1HABCDEFGH\x1B[2;1HIJKLMNOP\x1B[3;1HQRSTUVWX");
        const before = Array.from({ length: 3 }, (_, row) => Array.from({ length: 8 }, (_, col) => ctx.getCell(row, col).char));
        if (!before.every((line, row) => line.every((char, col) => char === seeds[row]?.[col]))) {
          return parserStateResult(null, expected, { before }, "DECIC seed was not measured");
        }
        ctx.feed("\x1B[2;3H");
        const setup = ctx.getCursor();
        if (setup.x !== 2 || setup.y !== 1) {
          return parserStateResult(null, expected, { before, setup }, "DECIC cursor setup failed");
        }
        ctx.feed("\x1B[2'}");
        const after = Array.from({ length: 3 }, (_, row) => Array.from({ length: 8 }, (_, col) => ctx.getCell(row, col).char));
        const controlsValid = after.every((line, row) => line.slice(0, 2).every((char, col) => char === before[row]?.[col]));
        return parserStateResult(controlsValid ? after.every((line, row) => line.every((char, col) => col < 2 ? true : col < 4 ? isBlank(char) : char === before[row]?.[col - 2])) : null, expected, { before, setup, after }, controlsValid ? undefined : "DECIC unchanged-prefix control changed");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 4) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x4, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[3;3H");
        ctx.write("\x1B[2'}");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("editing.decdc", (ctx) => {
        const expected = "DECDC deletes two columns at column 3 on three measured rows";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 8 || !Number.isSafeInteger(rows) || rows < 3) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "Need a measured 3x8 fixture");
        }
        const measuredWidth = Math.min(ctx.cols, 10);
        const seeds = ["ABCDEFGHIJ", "IJKLMNOPQR", "QRSTUVWXab"].map((line) => line.slice(0, measuredWidth));
        ctx.feed(`\x1B[1;1H${seeds[0]}\x1B[2;1H${seeds[1]}\x1B[3;1H${seeds[2]}`);
        const before = Array.from({ length: 3 }, (_, row) => Array.from({ length: measuredWidth }, (_, col) => ctx.getCell(row, col).char));
        if (!before.every((line, row) => line.every((char, col) => char === seeds[row]?.[col]))) {
          return parserStateResult(null, expected, { before }, "DECDC seed and incoming sources were not measured");
        }
        ctx.feed("\x1B[2;3H");
        const setup = ctx.getCursor();
        if (setup.x !== 2 || setup.y !== 1) {
          return parserStateResult(null, expected, { before, setup }, "DECDC cursor setup failed");
        }
        ctx.feed("\x1B[2'~");
        const after = Array.from({ length: 3 }, (_, row) => Array.from({ length: 8 }, (_, col) => ctx.getCell(row, col).char));
        const controlsValid = after.every((line, row) => line.slice(0, 2).every((char, col) => char === before[row]?.[col]));
        return parserStateResult(controlsValid ? after.every((line, row) => line.every((char, col) => col < 2 ? true : col + 2 < ctx.cols ? char === before[row]?.[col + 2] : isBlank(char))) : null, expected, { before, setup, after }, controlsValid ? undefined : "DECDC unchanged-prefix control changed");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 4) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Editing fixture needs at least 3x4, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[3;3H");
        ctx.write("\x1B[2'~");
        const pos = await ctx.queryCursorPosition();
        return unmeasuredCellResult(pos, "edited cells or attributes");
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    }
  ];
});

// ../probe-defs/src/modes.ts
function readAlt1049Span(ctx, row, length) {
  let text = "";
  for (let index = 0;index < length; index += 1)
    text += ctx.getCell(row, index).char;
  return text;
}
function alt1049SpanBlank(ctx, row, length) {
  for (let index = 0;index < length; index += 1) {
    if (!isBlank(ctx.getCell(row, index).char))
      return false;
  }
  return true;
}
function altScreen1049Roundtrip(ctx, phase) {
  const expected = phase === "enter" ? "CSI ? 1049 h switches to a cleared alternate buffer (full seeded roundtrip)" : "CSI ? 1049 l restores the primary buffer and the saved cursor";
  const rows = ctx.getScrollback().screenLines;
  const cols = ctx.cols;
  const needed = Math.max(ALT_1049_SEED_A.length, ALT_1049_SEED_B.length, ALT_1049_MARK.length);
  if (!Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 5 || cols < needed) {
    return parserStateResult(null, expected, { rows, cols, needed }, "1049 fixture needs at least 5 visible rows and " + needed + " columns");
  }
  ctx.feed("\x1B[2J\x1B[1;1H" + ALT_1049_SEED_A);
  ctx.feed("\x1B[3;1H" + ALT_1049_SEED_B);
  ctx.feed("\x1B[5;7H");
  let before;
  let seedA;
  let seedB;
  try {
    before = { ...ctx.getCursor() };
    seedA = readAlt1049Span(ctx, 0, ALT_1049_SEED_A.length);
    seedB = readAlt1049Span(ctx, 2, ALT_1049_SEED_B.length);
  } catch (error) {
    return alt1049ReadbackInconclusive(expected, "Primary seed readback failed", error);
  }
  if (seedA !== ALT_1049_SEED_A || seedB !== ALT_1049_SEED_B) {
    return parserStateResult(null, expected, { rows, cols, seedA, seedB }, "Primary seed was not measured");
  }
  if (!Number.isSafeInteger(before.x) || !Number.isSafeInteger(before.y) || before.x !== 6 || before.y !== 4) {
    return parserStateResult(null, expected, { before, expectedCursor: { x: 6, y: 4 } }, "Parked pre-cursor was not measured at row 4/col 6");
  }
  try {
    ctx.feed("\x1B[?1049h");
    let blankA;
    let blankB;
    try {
      blankA = alt1049SpanBlank(ctx, 0, ALT_1049_SEED_A.length);
      blankB = alt1049SpanBlank(ctx, 2, ALT_1049_SEED_B.length);
    } catch (error) {
      return alt1049ReadbackInconclusive(expected, "Alternate-buffer readback failed", error);
    }
    if (!blankA || !blankB) {
      if (phase === "exit") {
        return parserStateResult(null, expected, { seedA, seedB, blankA, blankB }, "Entry did not clear the seeded primary spans; exit cannot be attributed");
      }
      return parserStateResult(false, expected, { seedA, seedB, blankA, blankB }, "CSI ? 1049 h did not clear the seeded primary spans");
    }
    ctx.feed("\x1B[1;1H" + ALT_1049_MARK);
    let mark;
    try {
      mark = readAlt1049Span(ctx, 0, ALT_1049_MARK.length);
    } catch (error) {
      return alt1049ReadbackInconclusive(expected, "Alternate-marker readback failed", error);
    }
    if (mark !== ALT_1049_MARK) {
      return parserStateResult(null, expected, { mark }, "Alternate marker was not measured");
    }
    ctx.feed("\x1B[?1049l");
    let restoredA;
    let restoredB;
    let leaked;
    let after;
    try {
      restoredA = readAlt1049Span(ctx, 0, ALT_1049_SEED_A.length);
      restoredB = readAlt1049Span(ctx, 2, ALT_1049_SEED_B.length);
      leaked = readAlt1049Span(ctx, 0, ALT_1049_MARK.length) === ALT_1049_MARK;
      after = { ...ctx.getCursor() };
    } catch (error) {
      return alt1049ReadbackInconclusive(expected, "Restored-primary readback failed", error);
    }
    const state = { before, seedA, seedB, mark, restoredA, restoredB, leaked, after };
    const failures = [];
    if (restoredA !== ALT_1049_SEED_A)
      failures.push("PRIMARY-A not restored");
    if (restoredB !== ALT_1049_SEED_B)
      failures.push("PRIMARY-B not restored");
    if (leaked)
      failures.push("ALT-MARK leaked into the restored position");
    if (after.x !== before.x || after.y !== before.y)
      failures.push("saved cursor not restored");
    if (failures.length === 0)
      return parserStateResult(true, expected, state, undefined);
    return parserStateResult(null, expected, state, "1049 roundtrip failed: " + failures.join("; ") + "; cannot attribute failure to enter or exit: blank spans and ALT-MARK do not distinguish an alternate buffer from erasure, and cursor mismatch does not distinguish save from restore");
  } finally {
    ctx.feed("\x1B[?1049l\x1B[0m");
  }
}
function alt1049ReadbackInconclusive(expected, note, error) {
  const message = error instanceof Error ? error.message : String(error);
  return parserStateResult(null, expected, { readbackError: message }, note);
}
var ALT_1049_SEED_A = "PRIMARY-A", ALT_1049_SEED_B = "PRIMARY-B", ALT_1049_MARK = "ALT-MARK", modesProbes;
var init_modes = __esm(() => {
  modesProbes = [
    decrpmModeProbe("modes.alt-screen.enter", 1049, (ctx) => altScreen1049Roundtrip(ctx, "enter")),
    {
      ...probe("modes.alt-screen.exit", (ctx) => altScreen1049Roundtrip(ctx, "exit"), async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 3 || ctx.cols < 3) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Alt-screen exit fixture needs at least 3x3, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[?1049h");
        try {
          ctx.write("\x1B[3;3H");
        } finally {
          ctx.write("\x1B[?1049l");
        }
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor responsiveness after exit does not measure the restored buffer"
          }
        };
      }),
      termNeedsGeometry: true
    },
    decrpmModeProbe("modes.bracketed-paste", 2004, (ctx) => {
      ctx.feed("\x1B[?2004h");
      return notTestedResult("input events", { mode: ctx.getMode("bracketedPaste") });
    }),
    decrpmModeProbe("modes.application-cursor", 1, (ctx) => {
      ctx.feed("\x1B[?1h");
      return notTestedResult("key events", { mode: ctx.getMode("applicationCursor") });
    }),
    decrpmModeProbe("modes.auto-wrap", 7, (ctx) => {
      const expected = "DECAWM wraps Y after a full measured row of X";
      const rows = ctx.getScrollback().screenLines;
      if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 2 || !Number.isSafeInteger(rows) || rows < 2) {
        return parserStateResult(null, expected, { rows, cols: ctx.cols }, "Measured grid needs two rows");
      }
      const originallyEnabled = ctx.getMode("autoWrap");
      try {
        ctx.feed("\x1B[?7h");
        const enabled = ctx.getMode("autoWrap");
        if (!enabled) {
          return parserStateResult(null, expected, { originallyEnabled, enabled }, "Auto-wrap setup was not measured");
        }
        ctx.feed("X".repeat(ctx.cols) + "Y");
        const last = ctx.getCell(0, ctx.cols - 1);
        const next = ctx.getCell(1, 0);
        return parserStateResult(last.char === "X" && next.char === "Y", expected, {
          rows,
          cols: ctx.cols,
          originallyEnabled,
          enabled,
          last,
          next
        });
      } finally {
        ctx.feed(originallyEnabled ? "\x1B[?7h" : "\x1B[?7l");
      }
    }),
    decrpmModeProbe("modes.mouse-tracking", 1000, (ctx) => {
      ctx.feed("\x1B[?1000h");
      return notTestedResult("mouse events", { mode: ctx.getMode("mouseTracking") });
    }),
    decrpmModeProbe("modes.focus-tracking", 1004, (ctx) => {
      ctx.feed("\x1B[?1004h");
      return notTestedResult("focus events", { mode: ctx.getMode("focusTracking") });
    }),
    decrpmModeProbe("modes.reverse-video", 5, (ctx) => {
      ctx.feed("\x1B[?5h");
      return notTestedResult("rendered colors (pixels)", { mode: ctx.getMode("reverseVideo") });
    }),
    decrpmModeProbe("modes.synchronized-output", 2026, (ctx) => {
      ctx.feed("\x1B[?2026h");
      ctx.feed("Hello");
      ctx.feed("\x1B[?2026l");
      return notTestedResult("frame timing", { text: ctx.getText() });
    }),
    decrpmModeProbe("modes.origin", 6, (ctx) => {
      ctx.feed("\x1B[?6h");
      const result = ctx.getMode("originMode") === true;
      ctx.feed("\x1B[?6l");
      return parserStateResult(null, "Origin mode changes cursor addressing within margins", { mode: result }, "Mode metadata does not measure addressing");
    }),
    {
      ...probe("modes.insert-replace", (ctx) => {
        const expected = "IRM inserts X before measured ABC instead of replacing A";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 4 || !Number.isSafeInteger(rows) || rows < 1) {
          return parserStateResult(null, expected, { cols: ctx.cols, rows }, "IRM fixture needs at least 1x4");
        }
        ctx.feed("\x1B[4l\x1B[1;1H\x1B[2KABC");
        const seed = Array.from({ length: 4 }, (_, col) => ctx.getCell(0, col).char);
        ctx.feed("\x1B[1;1H");
        const origin = ctx.getCursor();
        if (seed[0] !== "A" || seed[1] !== "B" || seed[2] !== "C" || !isBlank(seed[3] ?? "\x00") || origin.x !== 0 || origin.y !== 0) {
          return parserStateResult(null, expected, { seed, origin }, "Cannot verify IRM seed and cursor origin");
        }
        try {
          ctx.feed("\x1B[4h");
          ctx.feed("X");
          const after = Array.from({ length: 4 }, (_, col) => ctx.getCell(0, col).char);
          const inserted = after[0] === "X" && after[1] === "A" && after[2] === "B" && after[3] === "C";
          const replaced = after[0] === "X" && after[1] === "B" && after[2] === "C" && isBlank(after[3] ?? "\x00");
          return parserStateResult(inserted ? true : replaced ? false : null, expected, { seed, origin, after }, inserted || replaced ? undefined : "Measured cells match neither insertion nor replacement");
        } finally {
          ctx.feed("\x1B[4l");
        }
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Insert-replace fixture needs at least 1x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("ABCD");
        ctx.write("\x1B[1;2H");
        ctx.write("\x1B[4h");
        try {
          ctx.write("X");
        } finally {
          ctx.write("\x1B[4l");
        }
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor advance does not measure whether X displaced the existing cells"
          }
        };
      }),
      termNeedsGeometry: true
    },
    decrpmModeProbe("modes.mouse-sgr", 1006, (ctx) => {
      ctx.feed("\x1B[?1006h");
      const pass = ctx.getMode("sgrMouse") === true;
      ctx.feed("\x1B[?1006l");
      return notTestedResult("encoded mouse events", { mode: pass });
    }),
    decrpmModeProbe("modes.mouse-all", 1003, (ctx) => {
      ctx.feed("\x1B[?1003h");
      const pass = ctx.getMode("mouseTracking") === true;
      ctx.feed("\x1B[?1003l");
      return notTestedResult("mouse movement", { mode: pass });
    }),
    probe("modes.application-keypad", (ctx) => {
      ctx.feed("\x1B=");
      const on = ctx.getMode("applicationKeypad") === true;
      ctx.feed("\x1B>");
      const off = ctx.getMode("applicationKeypad") === false;
      return notTestedResult("keypad input", { on, off });
    }, () => Promise.resolve({
      pass: false,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "none",
        note: "Keypad mode left unchanged; this probe does not measure keypad input encoding"
      }
    })),
    probe("modes.left-right-margin", (ctx) => {
      ctx.feed("\x1B[?69h");
      const pass = ctx.getMode("leftRightMargin") === true;
      ctx.feed("\x1B[?69l");
      return parserStateResult(null, "Left-right margin mode constrains horizontal operations", { mode: pass }, "Mode metadata does not measure margins");
    }, () => Promise.resolve({
      pass: false,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "none",
        note: "Margin mode left unchanged; this probe does not measure left/right margin behavior"
      }
    })),
    probe("modes.altscreen-47", (ctx) => {
      ctx.feed("\x1B[?47h");
      const entered = ctx.getMode("altScreen") === true;
      ctx.feed("\x1B[?47l");
      const exited = ctx.getMode("altScreen") === false;
      return parserStateResult(null, "?47 swaps the visible screen buffer", { entered, exited }, "Mode metadata does not measure the buffer");
    }, () => Promise.resolve({
      pass: false,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "none",
        note: "Alternate buffer left unchanged; this probe does not measure its visible contents"
      }
    })),
    probe("modes.altscreen-1047", (ctx) => {
      ctx.feed("\x1B[?1047h");
      const entered = ctx.getMode("altScreen") === true;
      ctx.feed("\x1B[?1047l");
      const exited = ctx.getMode("altScreen") === false;
      return parserStateResult(null, "?1047 swaps and clears the visible alternate buffer", { entered, exited }, "Mode metadata does not measure the buffer");
    }, async (ctx) => {
      const decrpmResult = await ctx.queryMode(1047);
      return {
        pass: false,
        ...decrpmResult !== null && { response: decrpmResult },
        observation: {
          outcome: "inconclusive",
          reason: decrpmResult === null ? "no-response" : "insufficient-evidence",
          evidence: "query",
          note: decrpmResult === null ? "No DECRPM reply; alternate-buffer clearing was not measured" : "DECRPM status does not measure alternate-buffer clearing"
        }
      };
    }, "query"),
    {
      ...probe("modes.altscreen-1048", (ctx) => {
        const expected = "?1048 restores saved cursor from 15;20 to 5;10";
        const rows = ctx.getScrollback().screenLines;
        if (!Number.isSafeInteger(rows) || !Number.isSafeInteger(ctx.cols) || rows < 15 || ctx.cols < 20) {
          return parserStateResult(null, expected, { rows, cols: ctx.cols }, "Cursor-save fixture needs at least 15x20");
        }
        ctx.feed("\x1B[5;10H");
        const before = { ...ctx.getCursor() };
        if (before.y !== 4 || before.x !== 9) {
          return parserStateResult(null, expected, { before }, "Cursor-save fixture did not establish its start position");
        }
        ctx.feed("\x1B[?1048h");
        let displaced;
        try {
          ctx.feed("\x1B[15;20H");
          displaced = { ...ctx.getCursor() };
          if (displaced.y !== 14 || displaced.x !== 19) {
            return parserStateResult(null, expected, { before, displaced }, "Cursor-save fixture did not measure displacement");
          }
        } finally {
          ctx.feed("\x1B[?1048l");
        }
        const after = ctx.getCursor();
        return parserStateResult(after.y === 4 && after.x === 9, expected, {
          before,
          displaced,
          after
        });
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 15 || ctx.cols < 20) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Cursor-save fixture needs at least 15x20, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[5;10H");
        const before = await ctx.queryCursorPosition();
        if (!before || before.row !== 5 || before.col !== 10) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: before ? "insufficient-evidence" : "no-response",
              evidence: "query",
              note: "Cursor-save fixture did not establish its start position"
            }
          };
        }
        ctx.write("\x1B[?1048h");
        let displaced = null;
        try {
          ctx.write("\x1B[15;20H");
          displaced = await ctx.queryCursorPosition();
          if (!displaced || displaced.row !== 15 || displaced.col !== 20) {
            return {
              pass: false,
              observation: {
                outcome: "inconclusive",
                reason: displaced ? "insufficient-evidence" : "no-response",
                evidence: "query",
                note: "Cursor-save fixture did not measure displacement"
              }
            };
          }
        } finally {
          ctx.write("\x1B[?1048l");
        }
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        const measured = { before, displaced, after: pos };
        const pass = pos.row === 5 && pos.col === 10;
        return {
          pass,
          response: JSON.stringify(measured),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "?1048 restores cursor from 15;20 to 5;10",
              observed: JSON.stringify(measured)
            }
          ]
        };
      }),
      termNeedsGeometry: true
    },
    decrpmModeProbe("modes.alt-scroll-1007", 1007, (ctx) => {
      ctx.feed("\x1B[?1007h");
      const response = ctx.feedCapture("\x1B[?1007$p");
      ctx.feed("\x1B[?1007l");
      if (response.includes("$y")) {
        return parserStateResult(null, "Alt-scroll changes wheel behavior", { response }, "DECRPM reports a mode state, not a wheel event");
      }
      ctx.feed("X");
      const ok = ctx.getCell(0, 0).char === "X";
      return parserStateResult(null, "Alt-scroll changes wheel behavior", { responsive: ok }, "Parser responsiveness does not measure wheel behavior");
    }),
    decrpmModeProbe("modes.utf8-mouse-1005", 1005, (ctx) => {
      ctx.feed("\x1B[?1005h");
      const response = ctx.feedCapture("\x1B[?1005$p");
      ctx.feed("\x1B[?1005l");
      if (response.includes("$y")) {
        return notTestedResult("encoded UTF-8 mouse events", { response });
      }
      ctx.feed("X");
      const ok = ctx.getCell(0, 0).char === "X";
      return notTestedResult("encoded UTF-8 mouse events", { responsive: ok });
    }),
    decrpmModeProbe("modes.deccolm", 3, (ctx) => {
      ctx.feed("\x1B[?3h");
      const response = ctx.feedCapture("\x1B[?3$p");
      ctx.feed("\x1B[?3l");
      if (response.includes("$y")) {
        return parserStateResult(null, "DECCOLM switches the measured grid width", { response, cols: ctx.cols }, "DECRPM state does not establish a width transition");
      }
      ctx.feed("X");
      const ok = ctx.getText().includes("X");
      return parserStateResult(null, "DECCOLM switches the measured grid width", { responsive: ok, cols: ctx.cols }, "Parser responsiveness does not measure a width transition");
    }),
    decrpmModeProbe("modes.decsclm", 4, (ctx) => {
      ctx.feed("\x1B[?4h");
      const response = ctx.feedCapture("\x1B[?4$p");
      ctx.feed("\x1B[?4l");
      return parserStateResult(null, "DECSCLM changes scroll timing", { response }, "DECRPM state does not measure scroll timing");
    }),
    {
      ...probe("modes.color-scheme-reporting", (ctx) => {
        const initiallyEnabled = ctx.getMode("colorSchemeReporting");
        try {
          ctx.feed("\x1B[?2031h");
          const enabled = ctx.getMode("colorSchemeReporting");
          return parserStateResult(null, "Mode 2031 emits color-scheme changes", { enabled }, "Mode metadata does not measure update events");
        } finally {
          ctx.feed(initiallyEnabled ? "\x1B[?2031h" : "\x1B[?2031l");
        }
      }, async (ctx) => {
        const result = await ctx.queryMode(2031);
        const recognized = result === "set" || result === "reset";
        const note = result === null ? "No DECRPM 2031 reply; update events were not tested" : result === "unknown" ? "DECRPM 2031 explicitly unrecognized" : `DECRPM 2031 recognized (${result}); update events were not tested`;
        return {
          pass: recognized,
          note,
          response: result ?? undefined,
          observation: {
            outcome: result === null ? "inconclusive" : recognized ? "supported" : "unsupported",
            evidence: "query",
            ...result === null && { reason: "no-response" },
            note
          },
          ...result !== null && {
            assertions: [
              {
                kind: recognized ? "positive" : "negative",
                expected: "DECRPM 2031 recognizes color-scheme reporting mode",
                observed: result
              }
            ]
          }
        };
      }, "query"),
      termWrites: "query"
    },
    probe("modes.xtpushsgr", (ctx) => {
      const pushOut = ctx.feedCapture("\x1B[#{");
      if (pushOut.length > 0) {
        return {
          pass: false,
          response: pushOut,
          observation: {
            outcome: "inconclusive",
            reason: "invalid-reply",
            evidence: "query",
            note: "Unexpected output during stack operation"
          }
        };
      }
      const probeResponse = ctx.feedCapture("\x1B[c");
      ctx.feed("\x1B[#}");
      return {
        pass: false,
        response: probeResponse,
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "DA1 responsiveness does not measure saved/restored stack state"
        }
      };
    }, async (ctx) => {
      ctx.write("\x1B[#{");
      try {
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor responsiveness does not measure saved/restored state"
          }
        };
      } finally {
        ctx.write("\x1B[#}");
      }
    }),
    probe("modes.xtpopsgr", (ctx) => {
      ctx.feed("\x1B[#{");
      const popOut = ctx.feedCapture("\x1B[#}");
      if (popOut.length > 0) {
        return {
          pass: false,
          response: popOut,
          observation: {
            outcome: "inconclusive",
            reason: "invalid-reply",
            evidence: "query",
            note: "Unexpected output during stack operation"
          }
        };
      }
      const probeResponse = ctx.feedCapture("\x1B[c");
      return {
        pass: false,
        response: probeResponse,
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "DA1 responsiveness does not measure saved/restored stack state"
        }
      };
    }, async (ctx) => {
      ctx.write("\x1B[#{");
      ctx.write("\x1B[#}");
      const pos = await ctx.queryCursorPosition();
      if (!pos) {
        return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
      }
      return {
        pass: false,
        response: JSON.stringify(pos),
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "Cursor responsiveness does not measure saved/restored state"
        }
      };
    }),
    probe("modes.xtsave", (ctx) => {
      const saveOut = ctx.feedCapture("\x1B[?7s");
      if (saveOut.length > 0) {
        return {
          pass: false,
          response: saveOut,
          observation: {
            outcome: "inconclusive",
            reason: "invalid-reply",
            evidence: "query",
            note: "Unexpected output during stack operation"
          }
        };
      }
      const probeResponse = ctx.feedCapture("\x1B[c");
      ctx.feed("\x1B[?7r");
      return {
        pass: false,
        response: probeResponse,
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "DA1 responsiveness does not measure saved/restored stack state"
        }
      };
    }, async (ctx) => {
      ctx.write("\x1B[?7s");
      try {
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor responsiveness does not measure saved/restored state"
          }
        };
      } finally {
        ctx.write("\x1B[?7r");
      }
    }),
    probe("modes.xtrestore", (ctx) => {
      ctx.feed("\x1B[?7s");
      const restoreOut = ctx.feedCapture("\x1B[?7r");
      if (restoreOut.length > 0) {
        return {
          pass: false,
          response: restoreOut,
          observation: {
            outcome: "inconclusive",
            reason: "invalid-reply",
            evidence: "query",
            note: "Unexpected output during stack operation"
          }
        };
      }
      const probeResponse = ctx.feedCapture("\x1B[c");
      return {
        pass: false,
        response: probeResponse,
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "DA1 responsiveness does not measure saved/restored stack state"
        }
      };
    }, async (ctx) => {
      ctx.write("\x1B[?7s");
      ctx.write("\x1B[?7r");
      const pos = await ctx.queryCursorPosition();
      if (!pos) {
        return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
      }
      return {
        pass: false,
        response: JSON.stringify(pos),
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "Cursor responsiveness does not measure saved/restored state"
        }
      };
    }),
    probe("modes.xtpushcolors", (ctx) => {
      const pushOut = ctx.feedCapture("\x1B[#P");
      if (pushOut.length > 0) {
        return {
          pass: false,
          response: pushOut,
          observation: {
            outcome: "inconclusive",
            reason: "invalid-reply",
            evidence: "query",
            note: "Unexpected output during stack operation"
          }
        };
      }
      const probeResponse = ctx.feedCapture("\x1B[c");
      ctx.feed("\x1B[#Q");
      return {
        pass: false,
        response: probeResponse,
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "DA1 responsiveness does not measure saved/restored stack state"
        }
      };
    }, async (ctx) => {
      ctx.write("\x1B[#P");
      try {
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor responsiveness does not measure saved/restored state"
          }
        };
      } finally {
        ctx.write("\x1B[#Q");
      }
    }),
    probe("modes.xtpopcolors", (ctx) => {
      ctx.feed("\x1B[#P");
      const popOut = ctx.feedCapture("\x1B[#Q");
      if (popOut.length > 0) {
        return {
          pass: false,
          response: popOut,
          observation: {
            outcome: "inconclusive",
            reason: "invalid-reply",
            evidence: "query",
            note: "Unexpected output during stack operation"
          }
        };
      }
      const probeResponse = ctx.feedCapture("\x1B[c");
      return {
        pass: false,
        response: probeResponse,
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "DA1 responsiveness does not measure saved/restored stack state"
        }
      };
    }, async (ctx) => {
      ctx.write("\x1B[#P");
      ctx.write("\x1B[#Q");
      const pos = await ctx.queryCursorPosition();
      if (!pos) {
        return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
      }
      return {
        pass: false,
        response: JSON.stringify(pos),
        observation: {
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "consumed",
          note: "Cursor responsiveness does not measure saved/restored state"
        }
      };
    })
  ];
});

// ../probe-defs/src/device.ts
function deviceReplyResult(spec, raw, matchedFrame, reason) {
  const da1At = raw.search(/\x1b\[\?[0-9;]*c/);
  if (matchedFrame && da1At !== -1 && raw.indexOf(matchedFrame) > da1At)
    matchedFrame = null;
  const valid = matchedFrame ? spec.valid.exec(matchedFrame) : null;
  if (valid?.[0]) {
    const note = spec.note?.(valid[0]);
    return {
      pass: true,
      response: raw,
      ...note && { note },
      observation: { outcome: "supported", evidence: "query", ...note && { note } },
      assertions: [{ kind: "positive", expected: spec.expected, observed: valid[0] }]
    };
  }
  const refusal = matchedFrame ? spec.refusal?.exec(matchedFrame) : null;
  if (refusal?.[0]) {
    return {
      pass: false,
      response: raw,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "query",
        note: "Requested setting or name refused; other settings or names unmeasured"
      }
    };
  }
  const contradiction = matchedFrame ? spec.contradicts?.exec(matchedFrame) ?? null : null;
  if (contradiction?.[0]) {
    return {
      pass: false,
      response: raw,
      observation: { outcome: "unsupported", evidence: "query" },
      assertions: [{ kind: "negative", expected: spec.expected, observed: contradiction[0] }]
    };
  }
  const hasCompleteUnmatchedFrame = spec.valid.test(raw) || spec.refusal?.test(raw) === true || spec.contradicts?.test(raw) === true;
  const missingReason = !hasCompleteUnmatchedFrame && spec.malformed.test(raw) ? "invalid-reply" : reason === "timeout" ? "timeout" : "no-response";
  return {
    pass: false,
    response: raw,
    observation: { outcome: "inconclusive", reason: missingReason, evidence: "query" }
  };
}
function answerPattern(spec) {
  const sources = [spec.valid.source, spec.refusal?.source, spec.contradicts?.source].filter((source) => source !== undefined);
  return new RegExp(sources.join("|"), spec.valid.flags);
}
function deviceQuery(spec) {
  const responsePattern = answerPattern(spec);
  const definition = probe(spec.id, (ctx) => {
    const raw = ctx.feedCapture(spec.query);
    return deviceReplyResult(spec, raw, responsePattern.exec(raw)?.[0] ?? null, "sentinel");
  }, async (ctx) => {
    const outcome = spec.direct ? await ctx.queryOutcome(spec.query, responsePattern) : await ctx.queryWithSentinelOutcome(spec.query, responsePattern);
    const matchedFrame = outcome.reason === "reply" ? outcome.match?.[0] ?? null : null;
    return deviceReplyResult(spec, outcome.raw, matchedFrame, outcome.reason);
  }, "query");
  return { ...definition, termWrites: "query", termlessObservationEvidence: "query" };
}
var iconLabelReply, windowTitleReply, deviceProbes;
var init_device = __esm(() => {
  iconLabelReply = {
    id: "device.xtwinops-20",
    query: "\x1B[20t",
    valid: /\x1b\]Ltest-icon(?:\x07|\x1b\\)/,
    malformed: /\x1b\]L/,
    contradicts: /\x1b\]L[^\x07\x1b]*(?:\x07|\x1b\\)/,
    expected: "OSC 1 + CSI 20 t round trip returns the exact icon label"
  };
  windowTitleReply = {
    id: "device.xtwinops-21",
    query: "\x1B[21t",
    valid: /\x1b\]ltest-title(?:\x07|\x1b\\)/,
    malformed: /\x1b\]l/,
    expected: "CSI 21 t returns the exact window title set by OSC 2"
  };
  deviceProbes = [
    deviceQuery({
      id: "device.primary-da",
      query: "\x1B[c",
      valid: /\x1b\[\?[0-9]+(?:;[0-9]+)*;?c/,
      malformed: /\x1b\[\?/,
      expected: "complete DA1 CSI ? numeric attributes c",
      direct: true
    }),
    deviceQuery({
      id: "device.status-report",
      query: "\x1B[5n",
      valid: /\x1b\[(?:0|3)n/,
      malformed: /\x1b\[[0-9]*n/,
      expected: "complete DSR 5 status 0 (ready) or 3 (malfunction)",
      note: (frame) => frame === "\x1B[3n" ? "Terminal reports malfunction" : undefined
    }),
    deviceQuery({
      id: "device.secondary-da",
      query: "\x1B[>c",
      valid: /\x1b\[>[0-9]+;[0-9]+;[0-9]+c/,
      malformed: /\x1b\[>/,
      expected: "complete DA2 CSI > three numeric fields c"
    }),
    deviceQuery({
      id: "device.tertiary-da",
      query: "\x1B[=c",
      valid: /\x1bP!\|[0-9A-Fa-f]{8}\x1b\\/,
      malformed: /\x1bP!\|/,
      expected: "complete DECRPTUI DCS !| followed by four hexadecimal pairs and ST"
    }),
    deviceQuery({
      id: "device.decrqss",
      query: "\x1BP$qm\x1B\\",
      valid: /\x1bP1\$r[0-9:;]*m\x1b\\/,
      refusal: /\x1bP0\$r\x1b\\/,
      malformed: /\x1bP[01]\$r/,
      expected: "complete DECRQSS status 1 SGR parameters ending m and ST"
    }),
    deviceQuery({
      id: "device.xtgettcap",
      query: "\x1BP+q544e\x1B\\",
      valid: /\x1bP1\+r544e=(?:[0-9A-Fa-f]{2})+\x1b\\/i,
      refusal: /\x1bP0\+r\x1b\\/,
      malformed: /\x1bP[01]\+r/,
      expected: "complete XTGETTCAP status 1 for TN with even-length hex value and ST"
    }),
    deviceQuery({
      id: "device.decrpm",
      query: "\x1B[?7$p",
      valid: /\x1b\[\?7;[1-4]\$y/,
      refusal: /\x1b\[\?7;0\$y/,
      malformed: /\x1b\[\?[0-9]+;[0-9]*\$y|\x1b\[\?7(?:;|\$)/,
      expected: "complete DECRPM for DECAWM mode 7 with recognized state 1\u20134"
    }),
    deviceQuery({
      id: "device.xtversion",
      query: "\x1B[>0q",
      valid: /\x1bP>\|[\x20-\x7e]+\x1b\\/,
      malformed: /\x1bP>\|/,
      expected: "complete XTVERSION DCS >| printable name/version ST"
    }),
    probe("device.term-features", null, () => {
      const advertised = typeof process !== "undefined" && !!process.env.TERM_FEATURES;
      return Promise.resolve({
        pass: false,
        note: advertised ? "TERM_FEATURES advertised; source unverified" : "TERM_FEATURES not advertised",
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy" }
      });
    }, "legacy"),
    {
      ...probe("device.dsr-996-color-scheme", (ctx) => {
        const response = ctx.feedCapture("\x1B[?996n");
        const match = /\x1b\[\?997;([12])n/.exec(response);
        if (!match?.[0]) {
          return {
            pass: false,
            note: "No valid DSR ?997 color-scheme response",
            response,
            observation: {
              outcome: "inconclusive",
              evidence: "query",
              reason: response.includes("\x1B[?997;") ? "invalid-reply" : "no-response"
            }
          };
        }
        return {
          pass: true,
          note: match[1] === "1" ? "dark" : "light",
          response,
          observation: {
            outcome: "supported",
            evidence: "query",
            note: "Current scheme queried; unsolicited change events were not tested"
          },
          assertions: [
            { kind: "positive", expected: "DSR ?996 yields complete DSR ?997;1n or ?997;2n", observed: match[0] }
          ]
        };
      }, async (ctx) => {
        const reply = await ctx.queryWithSentinelOutcome("\x1B[?996n", /\x1b\[\?997;([12])n/);
        const match = reply.match;
        if (!match?.[0]) {
          return {
            pass: false,
            note: "No valid DSR ?997 color-scheme response",
            response: reply.raw,
            observation: {
              outcome: "inconclusive",
              evidence: "query",
              reason: reply.raw.includes("\x1B[?997;") ? "invalid-reply" : reply.reason === "timeout" ? "timeout" : "no-response"
            }
          };
        }
        return {
          pass: true,
          note: match[1] === "1" ? "dark" : "light",
          response: match[0],
          observation: {
            outcome: "supported",
            evidence: "query",
            note: "Current scheme queried; unsolicited change events were not tested"
          },
          assertions: [
            { kind: "positive", expected: "DSR ?996 yields complete DSR ?997;1n or ?997;2n", observed: match[0] }
          ]
        };
      }, "query"),
      termWrites: "query",
      termlessObservationEvidence: "query"
    },
    deviceQuery({
      id: "device.xtwinops-14",
      query: "\x1B[14t",
      valid: /\x1b\[4;[1-9][0-9]*;[1-9][0-9]*t/,
      malformed: /\x1b\[4;/,
      expected: "CSI 14 t returns a complete CSI 4;positive-height;positive-width t frame"
    }),
    deviceQuery({
      id: "device.xtwinops-16",
      query: "\x1B[16t",
      valid: /\x1b\[6;[1-9][0-9]*;[1-9][0-9]*t/,
      malformed: /\x1b\[6;/,
      expected: "CSI 16 t returns a complete CSI 6;positive-height;positive-width t frame"
    }),
    deviceQuery({
      id: "device.xtwinops-18",
      query: "\x1B[18t",
      valid: /\x1b\[8;[1-9][0-9]*;[1-9][0-9]*t/,
      malformed: /\x1b\[8;/,
      expected: "CSI 18 t returns a complete CSI 8;positive-rows;positive-columns t frame"
    }),
    {
      ...probe("device.xtwinops-20", (ctx) => {
        ctx.feed("\x1B]1;test-icon\x07");
        const raw = ctx.feedCapture(iconLabelReply.query);
        return deviceReplyResult(iconLabelReply, raw, answerPattern(iconLabelReply).exec(raw)?.[0] ?? null, "sentinel");
      }, async (ctx) => {
        ctx.write("\x1B]1;test-icon\x07");
        const reply = await ctx.queryWithSentinelOutcome(iconLabelReply.query, answerPattern(iconLabelReply));
        return deviceReplyResult(iconLabelReply, reply.raw, reply.reason === "reply" ? reply.match?.[0] ?? null : null, reply.reason);
      }),
      termlessObservationEvidence: "query"
    },
    {
      ...probe("device.xtwinops-21", (ctx) => {
        ctx.feed("\x1B]2;test-title\x07");
        const raw = ctx.feedCapture(windowTitleReply.query);
        return deviceReplyResult(windowTitleReply, raw, windowTitleReply.valid.exec(raw)?.[0] ?? null, "sentinel");
      }, async (ctx) => {
        ctx.write("\x1B]2;test-title\x07");
        const reply = await ctx.queryWithSentinelOutcome(windowTitleReply.query, windowTitleReply.valid);
        return deviceReplyResult(windowTitleReply, reply.raw, reply.reason === "reply" ? reply.match?.[0] ?? null : null, reply.reason);
      }),
      termlessObservationEvidence: "query"
    },
    {
      ...probe("device.xtwinops-22", (ctx) => {
        ctx.feed("\x1B]2;pushed-title\x07");
        const original = ctx.getTitle();
        ctx.feed("\x1B[22;0t");
        ctx.feed("\x1B]2;new-title\x07");
        const changed = ctx.getTitle();
        ctx.feed("\x1B[23;0t");
        const restored = ctx.getTitle();
        return parserStateResult(original === "pushed-title" && changed === "new-title" && restored === "pushed-title" ? true : null, "XTWINOPS 22 preserves the old title on its stack after a different title is set", { original, changed, restored }, original !== "pushed-title" || changed !== "new-title" ? "Title setup was not observable" : restored !== "pushed-title" ? "Title push/pop did not restore the old title; the failing operation is unknown" : undefined);
      }, async (ctx) => {
        ctx.write("\x1B]2;pushed-title\x07");
        ctx.write("\x1B[22;0t");
        ctx.write("\x1B]2;new-title\x07");
        const pos = await ctx.queryCursorPosition();
        return {
          pass: false,
          note: pos ? "Cursor answered after title push; title stack was not measured" : "No DSR response after title push",
          observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "consumed" }
        };
      }),
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("device.xtwinops-23", (ctx) => {
        ctx.feed("\x1B]2;pushed-title\x07");
        const original = ctx.getTitle();
        ctx.feed("\x1B[22;0t");
        ctx.feed("\x1B]2;new-title\x07");
        const changed = ctx.getTitle();
        ctx.feed("\x1B[23;0t");
        const restored = ctx.getTitle();
        return parserStateResult(original === "pushed-title" && changed === "new-title" && restored === "pushed-title" ? true : null, "XTWINOPS 23 restores the title saved before a different title was set", { original, changed, restored }, original !== "pushed-title" || changed !== "new-title" ? "Title setup was not observable" : restored !== "pushed-title" ? "Title push/pop did not restore the old title; the failing operation is unknown" : undefined);
      }, async (ctx) => {
        ctx.write("\x1B[22;0t");
        ctx.write("\x1B[23;0t");
        const pos = await ctx.queryCursorPosition();
        return {
          pass: false,
          note: pos ? "Cursor answered after title pop; restored title was not measured" : "No DSR response after title pop",
          observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "consumed" }
        };
      }),
      termlessObservationEvidence: "parser-state"
    },
    deviceQuery({
      id: "device.xtreportcolors",
      query: "\x1B[#R",
      valid: /\x1b\[[0-9;]*#Q/,
      malformed: /\x1b\[[0-9;]*#|#Q/,
      expected: "CSI # R returns a complete CSI Pm # Q frame"
    }),
    deviceQuery({
      id: "device.xtgetxres",
      query: "\x1BP+Q7465726d4e616d65\x1B\\",
      valid: /\x1bP1\+R7465726d4e616d65=[0-9A-Fa-f]+\x1b\\/i,
      refusal: /\x1bP0\+R7465726d4e616d65\x1b\\/i,
      malformed: /\x1bP[01]\+R/,
      expected: "XTGETXRES returns a complete status-1 termName resource value"
    })
  ];
});

// ../probe-defs/src/extensions.ts
import { randomUUID } from "crypto";
function queryOnly(definition) {
  return { ...definition, termWrites: "query" };
}
function oscReplyResult(raw, frame, expected, prefix) {
  if (frame) {
    return {
      pass: true,
      response: raw,
      observation: { outcome: "supported", evidence: "query" },
      assertions: [{ kind: "positive", expected, observed: frame }]
    };
  }
  return {
    pass: false,
    response: raw,
    observation: {
      outcome: "inconclusive",
      reason: prefix.test(raw) ? "invalid-reply" : "no-response",
      evidence: "query"
    }
  };
}
function unverifiedEffect(note, response) {
  return {
    pass: false,
    ...response !== undefined && { response },
    note,
    observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "consumed", note }
  };
}
function unmeasuredStateEffect(feature) {
  const note = `${feature} was not attempted; this probe has no effect readback or prior-state restoration`;
  return {
    pass: false,
    note,
    observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
  };
}
function sixelDa1Result(raw, frame) {
  const match = frame ? sixelDa1Reply.exec(frame) : null;
  if (!match) {
    return {
      pass: false,
      response: raw,
      observation: {
        outcome: "inconclusive",
        reason: raw.includes("\x1B[?") ? "invalid-reply" : "no-response",
        evidence: "query"
      }
    };
  }
  const advertised = (match[1]?.split(";") ?? []).includes("4");
  return {
    pass: advertised,
    response: raw,
    observation: { outcome: advertised ? "supported" : "unsupported", evidence: "query" },
    assertions: [
      {
        kind: advertised ? "positive" : "negative",
        expected: "Complete DA1 advertises Sixel attribute 4",
        observed: match[0]
      }
    ]
  };
}
function sixelGeometryResult(raw, frame, missingReason) {
  const reply = frame ? /\x1b\[\?2;([0-9]+);([0-9;]*)S/.exec(frame) : null;
  if (!reply) {
    const malformed = frame !== null;
    const note = malformed ? "Malformed Sixel geometry response" : "No Sixel geometry response for item 2";
    return {
      pass: false,
      response: raw,
      note,
      observation: {
        outcome: "inconclusive",
        evidence: "query",
        reason: malformed ? "invalid-reply" : missingReason,
        note
      }
    };
  }
  const status = Number(reply[1]);
  if (status !== 0) {
    const validFailure = status === 1 || status === 2 || status === 3;
    const note = validFailure ? `Sixel geometry query reported protocol status ${status}` : `Unknown Sixel geometry protocol status ${reply[1]}`;
    return {
      pass: false,
      response: raw,
      note,
      observation: {
        outcome: "inconclusive",
        evidence: "query",
        reason: validFailure ? "insufficient-evidence" : "invalid-reply",
        note
      }
    };
  }
  const dimensions = reply[2]?.split(";") ?? [];
  const width = Number(dimensions[0]);
  const height = Number(dimensions[1]);
  if (dimensions.length !== 2 || dimensions.some((value) => !/^[0-9]+$/.test(value)) || !Number.isSafeInteger(width) || !Number.isSafeInteger(height)) {
    const note = "Successful Sixel geometry response lacked two numeric pixel dimensions";
    return {
      pass: false,
      response: raw,
      note,
      observation: { outcome: "inconclusive", evidence: "query", reason: "invalid-reply", note }
    };
  }
  if (width === 0 || height === 0) {
    const note = `Sixel geometry reported ${width}\xD7${height} pixels; usable dimensions were not established`;
    return {
      pass: false,
      response: raw,
      note,
      observation: { outcome: "inconclusive", evidence: "query", reason: "insufficient-evidence", note }
    };
  }
  const note = `Current Sixel geometry reported as ${width}\xD7${height} pixels`;
  return {
    pass: true,
    response: raw,
    note,
    observation: { outcome: "supported", evidence: "query", note },
    assertions: [
      {
        kind: "positive",
        expected: "XTSMGRAPHICS item 2 read returns status 0 and two positive pixel dimensions",
        observed: reply[0]
      }
    ]
  };
}
function oscColorQueryProbe(id, oscCode) {
  const querySeq = `\x1B]${oscCode};?\x07`;
  const pattern = new RegExp(`\\x1b\\]${oscCode};rgb:[0-9a-f]{1,4}/[0-9a-f]{1,4}/[0-9a-f]{1,4}(?:\\x07|\\x1b\\\\)`, "i");
  const prefix = new RegExp(`\\x1b\\]${oscCode};`);
  return {
    ...queryOnly(probe(id, (ctx) => {
      const raw = ctx.feedCapture(querySeq);
      return oscReplyResult(raw, pattern.exec(raw)?.[0] ?? null, `Complete OSC ${oscCode} color reply`, prefix);
    }, async (ctx) => {
      const reply = await ctx.queryWithSentinelOutcome(querySeq, pattern);
      return oscReplyResult(reply.raw, reply.reason === "reply" ? reply.match?.[0] ?? null : null, `Complete OSC ${oscCode} color reply`, prefix);
    }, "query")),
    termlessObservationEvidence: "query"
  };
}
function oscSimpleQueryProbe(id, query, pattern, prefix, expected) {
  return {
    ...queryOnly(probe(id, (ctx) => {
      const raw = ctx.feedCapture(query);
      return oscReplyResult(raw, pattern.exec(raw)?.[0] ?? null, expected, prefix);
    }, async (ctx) => {
      const reply = await ctx.queryWithSentinelOutcome(query, pattern);
      return oscReplyResult(reply.raw, reply.reason === "reply" ? reply.match?.[0] ?? null : null, expected, prefix);
    }, "query")),
    termlessObservationEvidence: "query"
  };
}
function colorResetProbe(setCode, resetCode, index) {
  const indexPart = index === undefined ? "" : `${index};`;
  const query = `\x1B]${setCode};${indexPart}?\x07`;
  const replyPattern = new RegExp(`\\x1b\\]${setCode};${indexPart}(rgb:[0-9a-f]{1,4}/[0-9a-f]{1,4}/[0-9a-f]{1,4})(?:\\x07|\\x1b\\\\)`, "i");
  return (ctx) => {
    const originalRaw = ctx.feedCapture(query);
    const original = replyPattern.exec(originalRaw)?.[1];
    if (!original) {
      return oscReplyResult(originalRaw, null, `OSC ${setCode} color before reset`, new RegExp(`\\x1b\\]${setCode};`));
    }
    const requested = probeForeground(original);
    let mustReset = false;
    try {
      ctx.feed(`\x1B]${setCode};${indexPart}${requested}\x07`);
      mustReset = true;
      const changedRaw = ctx.feedCapture(query);
      const changed = replyPattern.exec(changedRaw)?.[1];
      ctx.feed(`\x1B]${resetCode}${index === undefined ? "" : `;${index}`}\x07`);
      mustReset = false;
      const restoredRaw = ctx.feedCapture(query);
      const restored = replyPattern.exec(restoredRaw)?.[1];
      const response = JSON.stringify({ originalRaw, changedRaw, restoredRaw });
      if (!changed || !restored || !sameRgb2(changed, requested)) {
        return {
          pass: false,
          response,
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Color mutation or readback control was not established"
          }
        };
      }
      const pass = sameRgb2(restored, original);
      return {
        pass,
        response,
        observation: { outcome: pass ? "supported" : "unsupported", evidence: "behavior" },
        assertions: [
          {
            kind: pass ? "positive" : "negative",
            expected: `OSC ${resetCode} restores the prior OSC ${setCode} color after a verified change`,
            observed: response
          }
        ]
      };
    } finally {
      if (mustReset)
        ctx.feed(`\x1B]${resetCode}${index === undefined ? "" : `;${index}`}\x07`);
    }
  };
}
function foregroundValue(response) {
  return foregroundReply.exec(response)?.[1] ?? null;
}
function sameRgb2(left, right) {
  const channels = (color) => color.slice(4).split("/").map((channel) => Math.round(parseInt(channel, 16) / (16 ** channel.length - 1) * 65535));
  const actual = channels(left);
  const expected = channels(right);
  return actual.every((channel, index) => channel === expected[index]);
}
function sameRgbCells(left, right) {
  return left.r === right.r && left.g === right.g && left.b === right.b;
}
function probeForeground(before) {
  return sameRgb2(before, "rgb:aa/bb/cc") ? "rgb:12/34/56" : "rgb:aa/bb/cc";
}
function colorStackResult(before, requested, changed, restored) {
  const changedAsRequested = sameRgb2(changed, requested);
  const restoredOriginal = sameRgb2(restored, before);
  const pass = changedAsRequested && restoredOriginal;
  const response = JSON.stringify({ before, changed, restored });
  const note = pass ? "Foreground changed and color-stack pop restored its original value" : "Foreground change or stack restoration was not observed";
  return {
    pass,
    response,
    note,
    observation: { outcome: pass ? "supported" : "unsupported", evidence: "behavior", note },
    assertions: [
      {
        kind: pass ? "positive" : "negative",
        expected: "Changed foreground and restored original after color-stack pop",
        observed: response
      }
    ]
  };
}
function promptConsumptionResult(consumed) {
  const note = consumed === null ? "No cursor reply after semantic prompt marker" : consumed ? "Marker was consumed; shell prompt integration was not observed" : "Marker consumption was not confirmed; shell prompt integration was not observed";
  return {
    pass: false,
    note,
    observation: {
      outcome: "inconclusive",
      evidence: consumed === null ? "query" : "consumed",
      reason: consumed === null ? "no-response" : "insufficient-evidence",
      note
    }
  };
}
function colorStackError(evidence, action, error) {
  if (!(error instanceof Error))
    throw error;
  const note = `${action} (${evidence}) failed: ${error.name}: ${error.message}`;
  return { pass: false, note, observation: { outcome: "error", reason: "collector-error", evidence, note } };
}
function colorStackProbe() {
  return (ctx) => {
    let result;
    let primaryError;
    const queryForeground = (action) => {
      let response;
      try {
        response = ctx.feedCapture(foregroundQuery);
      } catch (error) {
        primaryError = error;
        return colorStackError("query", action, error);
      }
      return foregroundValue(response);
    };
    const feed = (sequence, action) => {
      try {
        ctx.feed(sequence);
        return;
      } catch (error) {
        primaryError = error;
        return colorStackError("behavior", action, error);
      }
    };
    const before = queryForeground("Original foreground query");
    if (before !== null && typeof before !== "string")
      return before;
    if (!before) {
      return {
        pass: false,
        note: "No original OSC 10 foreground reply",
        observation: { outcome: "inconclusive", evidence: "query", reason: "no-response" }
      };
    }
    let pushed = false;
    let unexpectedlyFailed = false;
    const requested = probeForeground(before);
    try {
      result = feed(colorPush, "Color-stack push");
      if (result !== undefined)
        return result;
      pushed = true;
      result = feed(`\x1B]10;${requested}\x07`, "Foreground mutation");
      if (result !== undefined)
        return result;
      const changed = queryForeground("Foreground query after mutation");
      if (changed !== null && typeof changed !== "string") {
        result = changed;
        return result;
      }
      result = feed(colorPop, "Color-stack pop");
      if (result !== undefined)
        return result;
      pushed = false;
      const restored = queryForeground("Foreground query after pop");
      if (restored !== null && typeof restored !== "string") {
        result = restored;
        return result;
      }
      result = !changed || !restored ? {
        pass: false,
        note: "No OSC 10 reply after changing or popping color",
        observation: { outcome: "inconclusive", evidence: "query", reason: "no-response" }
      } : colorStackResult(before, requested, changed, restored);
      return result;
    } catch (error) {
      unexpectedlyFailed = true;
      primaryError = error;
      throw error;
    } finally {
      const cleanupFailures = [];
      try {
        if (pushed)
          ctx.feed(colorPop);
      } catch (error) {
        cleanupFailures.push({ action: "Color-stack cleanup pop", error });
      } finally {
        try {
          ctx.feed(`\x1B]10;${before}\x07`);
        } catch (error) {
          cleanupFailures.push({ action: "Foreground cleanup restore", error });
        }
      }
      if (cleanupFailures.length > 0) {
        const cleanupNote = cleanupFailures.map(({ action, error }) => error instanceof Error ? `${action} (behavior) failed: ${error.name}: ${error.message}` : `${action} (behavior) threw unexpectedly: ${String(error)}`).join("; ");
        const primaryNote = unexpectedlyFailed ? `Color-stack callback threw unexpectedly: ${primaryError instanceof Error ? `${primaryError.name}: ${primaryError.message}` : String(primaryError)}` : result?.observation?.outcome === "error" ? result.note : undefined;
        const note = primaryNote ? `${primaryNote}; ${cleanupNote}` : cleanupNote;
        if (unexpectedlyFailed || cleanupFailures.some(({ error }) => !(error instanceof Error))) {
          throw new AggregateError([
            ...unexpectedlyFailed || result?.observation?.outcome === "error" ? [primaryError] : [],
            ...cleanupFailures.map(({ error }) => error)
          ], note, { cause: primaryError });
        }
        if (result) {
          const evidence = result.observation?.outcome === "error" ? result.observation.evidence : "behavior";
          result.pass = false;
          result.note = note;
          result.observation = { outcome: "error", reason: "collector-error", evidence, note };
          delete result.response;
          delete result.assertions;
        }
      }
    }
  };
}
async function colorStackTermProbe(ctx) {
  const originalReply = await ctx.queryWithSentinelOutcome(foregroundQuery, foregroundReply);
  const before = foregroundValue(originalReply.match?.[0] ?? "");
  if (!before)
    return unansweredQuery(originalReply, "No original OSC 10 foreground reply; color stack was not changed");
  let pushed = false;
  const requested = probeForeground(before);
  try {
    ctx.write(colorPush);
    pushed = true;
    ctx.write(`\x1B]10;${requested}\x07`);
    const changedReply = await ctx.queryWithSentinelOutcome(foregroundQuery, foregroundReply);
    const changed = foregroundValue(changedReply.match?.[0] ?? "");
    if (!changed)
      return unansweredQuery(changedReply, "No OSC 10 reply after changing foreground");
    ctx.write(colorPop);
    pushed = false;
    const restoredReply = await ctx.queryWithSentinelOutcome(foregroundQuery, foregroundReply);
    const restored = foregroundValue(restoredReply.match?.[0] ?? "");
    if (!restored)
      return unansweredQuery(restoredReply, "No OSC 10 reply after color-stack pop");
    return colorStackResult(before, requested, changed, restored);
  } finally {
    try {
      if (pushed)
        ctx.write(colorPop);
    } finally {
      ctx.write(`\x1B]10;${before}\x07`);
    }
  }
}
function osc720ScrollProbe() {
  return (ctx) => {
    for (let i = 0;i < 30; i++)
      ctx.feed(`scroll-${i}\r
`);
    const before = ctx.getScrollback();
    if (before.totalLines <= before.screenLines || before.viewportOffset <= 0) {
      return parserStateResult(null, "OSC 720 moves the scrollback viewport up", { before }, "No scrollback viewport available");
    }
    ctx.feed("\x1B]720\x07");
    const after = ctx.getScrollback();
    const pass = after.viewportOffset < before.viewportOffset;
    return parserStateResult(pass, "OSC 720 moves the scrollback viewport up", { before, after });
  };
}
function kittyDetection(raw) {
  const flags = KITTY_FLAGS.exec(raw);
  const da1 = DA1_COMPLETE.exec(raw);
  if (flags !== null && da1 !== null && da1.index < flags.index) {
    return { kind: "inconclusive", reason: "invalid-reply" };
  }
  if (flags !== null)
    return { kind: "answered" };
  if (KITTY_FLAGS_SHAPED.test(raw) || KITTY_FLAGS_TRUNCATED.test(raw)) {
    return { kind: "inconclusive", reason: "invalid-reply" };
  }
  if (da1 !== null) {
    return da1.index === 0 && da1[0].length === raw.length ? { kind: "absent" } : { kind: "inconclusive", reason: "invalid-reply" };
  }
  return { kind: "inconclusive", reason: "no-response" };
}
function kittyProtocolAbsent(response) {
  const note = "DA1 answered without any Kitty keyboard flags reply; the protocol is not supported (necessary-condition negative; key-event conformance was not tested)";
  return {
    pass: false,
    response,
    note,
    observation: { outcome: "unsupported", evidence: "query", note },
    assertions: [
      {
        kind: "negative",
        expected: "A complete Kitty keyboard flags reply answers before the DA1 reply",
        observed: response
      }
    ]
  };
}
function kittyInconclusive(detection, reason, response) {
  const note = detection.reason === "invalid-reply" ? "Unreadable or out-of-order Kitty keyboard flags / DA1 reply (malformed, truncated, duplicate or residual bytes); no support conclusion" : "No answer to the Kitty keyboard flags query or the DA1 follow-up; no support conclusion";
  return {
    pass: false,
    response,
    note,
    observation: { outcome: "inconclusive", evidence: "query", reason, note }
  };
}
function kittyKeyboardFlagProbe(id, pushValue, flagBit) {
  const definition = probe(id, (ctx) => {
    const detectionRaw = ctx.feedCapture(`\x1B[?u\x1B[c`);
    const detection = kittyDetection(detectionRaw);
    if (detection.kind !== "answered") {
      return detection.kind === "absent" ? kittyProtocolAbsent(detectionRaw) : kittyInconclusive(detection, detection.reason, detectionRaw);
    }
    ctx.feed(`\x1B[>${pushValue}u`);
    try {
      return keyboardFlagsResult(ctx.feedCapture(`\x1B[?u`), flagBit);
    } finally {
      ctx.feed("\x1B[<u");
    }
  }, async (ctx) => {
    const detection = await ctx.queryWithSentinelOutcome(`\x1B[?u`, KITTY_FLAGS);
    const verdict = kittyDetection(detection.raw);
    if (verdict.kind !== "answered") {
      if (verdict.kind === "absent")
        return kittyProtocolAbsent(detection.raw);
      const reason = verdict.reason === "invalid-reply" ? "invalid-reply" : detection.reason === "timeout" ? "timeout" : "no-response";
      return kittyInconclusive(verdict, reason, detection.raw);
    }
    ctx.write(`\x1B[>${pushValue}u`);
    try {
      const reply = await ctx.queryWithSentinelOutcome(`\x1B[?u`, KITTY_FLAGS);
      if (!reply.match)
        return unansweredQuery(reply, "No Kitty keyboard reply; key events were not tested");
      return keyboardFlagsResult(reply.match[0] ?? "", flagBit);
    } finally {
      ctx.write("\x1B[<u");
    }
  });
  return { ...definition, termObservationEvidence: "query", termlessObservationEvidence: "query" };
}
function unansweredQuery(reply, note) {
  return {
    pass: false,
    response: reply.raw,
    note,
    observation: {
      outcome: "inconclusive",
      evidence: "query",
      reason: reply.reason === "timeout" ? "timeout" : "no-response",
      note
    }
  };
}
function keyboardFlagsResult(response, flagBits) {
  const match = /\x1b\[\?(\d+)u/.exec(response);
  if (!match?.[1]) {
    return unansweredQuery({ match: null, reason: "sentinel", raw: response, rawBase64: btoa(response) }, "No Kitty keyboard reply; key events were not tested");
  }
  const flags = Number(match[1]);
  const pass = (flags & flagBits) === flagBits;
  const note = `Queried enhancement flags=${flags}; actual key press, repeat and release events were not tested`;
  return {
    pass,
    response,
    note,
    observation: { outcome: pass ? "supported" : "unsupported", evidence: "query", note },
    assertions: [
      {
        kind: pass ? "positive" : "negative",
        expected: `Acknowledged flags include mask ${flagBits}`,
        observed: `flags=${flags}`
      }
    ]
  };
}
function graphicsQueryResult(response, imageId, acceptedNote = "Graphics query accepted RGB pixel data; visible rendering was not tested") {
  const match = new RegExp(`\\x1b_Gi=${imageId};([^\\x1b]+)\\x1b\\\\`).exec(response);
  if (!match) {
    return unansweredQuery({ match: null, reason: "sentinel", raw: response, rawBase64: btoa(response) }, "No matching graphics query reply; image rendering was not tested");
  }
  const pass = match[1] === "OK";
  const note = pass ? acceptedNote : `Graphics query returned ${match[1]}; no support conclusion`;
  return {
    pass,
    response,
    note,
    observation: {
      outcome: pass ? "supported" : "inconclusive",
      evidence: "query",
      ...!pass && { reason: "invalid-reply" },
      note
    },
    ...pass && {
      assertions: [{ kind: "positive", expected: `Graphics reply i=${imageId};OK`, observed: match[0] }]
    }
  };
}
function imageTransferRequest(imageNumber) {
  return `\x1B_Ga=t,f=24,s=1,v=1,t=d,I=${imageNumber};/wAA\x1B\\`;
}
function allocatedImageResult(response, imageNumber) {
  const match = new RegExp(`\\x1b_Gi=(\\d+),I=${imageNumber};([^\\x1b]+)\\x1b\\\\`).exec(response);
  const imageId = match ? Number(match[1]) : 0;
  if (!match || imageId < 1 || imageId > 4294967295) {
    return {
      imageId: null,
      result: unansweredQuery({ match: null, reason: "sentinel", raw: response, rawBase64: btoa(response) }, "No matching image allocation reply; no image ownership or transmission conclusion")
    };
  }
  const pass = match[2] === "OK";
  const note = pass ? "RGB image transmission acknowledged; display was not tested" : `Image transmission returned ${match[2]}; no support conclusion`;
  return {
    imageId: pass ? imageId : null,
    result: {
      pass,
      response,
      note,
      observation: {
        outcome: pass ? "supported" : "inconclusive",
        evidence: "query",
        ...!pass && { reason: "invalid-reply" },
        note
      },
      ...pass && {
        assertions: [
          {
            kind: "positive",
            expected: `A fresh image ID and I=${imageNumber};OK acknowledge the transmitted RGB pixel`,
            observed: match[0]
          }
        ]
      }
    }
  };
}
function kittyImageTransferProbe(id, display) {
  const newNumber = () => Number.parseInt(globalThis.crypto.randomUUID().slice(0, 8), 16) % 4294967294 + 1;
  return {
    ...probe(id, (ctx) => {
      const imageNumber = newNumber();
      let imageId = null;
      try {
        const uploaded = allocatedImageResult(ctx.feedCapture(imageTransferRequest(imageNumber)), imageNumber);
        imageId = uploaded.imageId;
        if (!imageId || !display)
          return uploaded.result;
        const response = ctx.feedCapture(`\x1B_Ga=p,i=${imageId},c=2,r=1,C=1\x1B\\`);
        return graphicsQueryResult(response, imageId, "Image placement acknowledged; visible pixels were not tested");
      } finally {
        if (imageId)
          ctx.feed(`\x1B_Ga=d,d=I,i=${imageId},q=2\x1B\\`);
      }
    }, async (ctx) => {
      const imageNumber = newNumber();
      let imageId = null;
      try {
        const reply = await ctx.queryWithSentinelOutcome(imageTransferRequest(imageNumber), new RegExp(`\\x1b_Gi=(\\d+),I=${imageNumber};([^\\x1b]+)\\x1b\\\\`));
        if (!reply.match) {
          return unansweredQuery(reply, "No matching image allocation reply; no image ownership or transmission conclusion");
        }
        const uploaded = allocatedImageResult(reply.match[0] ?? "", imageNumber);
        imageId = uploaded.imageId;
        if (!imageId || !display)
          return uploaded.result;
        const placement = await ctx.queryWithSentinelOutcome(`\x1B_Ga=p,i=${imageId},c=2,r=1,C=1\x1B\\`, new RegExp(`\\x1b_Gi=${imageId};([^\\x1b]+)\\x1b\\\\`));
        if (!placement.match) {
          return unansweredQuery(placement, "No matching placement reply; visible pixels were not tested");
        }
        return graphicsQueryResult(placement.match[0] ?? "", imageId, "Image placement acknowledged; visible pixels were not tested");
      } finally {
        if (imageId)
          ctx.write(`\x1B_Ga=d,d=I,i=${imageId},q=2\x1B\\`);
      }
    }, "query"),
    termlessObservationEvidence: "query"
  };
}
function kittyForegroundResult(response) {
  const match = /\x1b\]21;([^\x07\x1b]*)(?:\x07|\x1b\\)/.exec(response);
  if (!match) {
    return unansweredQuery({ match: null, reason: "sentinel", raw: response, rawBase64: btoa(response) }, "No OSC 21 reply; color rendering was not tested");
  }
  const values = match[1]?.split(";").filter((field) => field.startsWith("foreground=")) ?? [];
  const value = values.length === 1 ? values[0]?.slice("foreground=".length) : undefined;
  const pass = value === "" || value !== undefined && /^rgb:[a-f\d]{1,4}\/[a-f\d]{1,4}\/[a-f\d]{1,4}$/i.test(value);
  const note = pass ? "Foreground query recognized; setting colors and visible rendering were not tested" : "OSC 21 replied without one verifiable foreground value; no support conclusion";
  return {
    pass,
    response,
    note,
    observation: { outcome: pass ? "supported" : "inconclusive", evidence: "query", note },
    ...pass && {
      assertions: [
        {
          kind: "positive",
          expected: "OSC 21 foreground query returns RGB or an explicitly undefined value",
          observed: match[0]
        }
      ]
    }
  };
}
function textSizingResult(before, width, scale, evidence) {
  const widthWorks = width.row === before.row && width.col === before.col + 2;
  const scaleWorks = scale.row === width.row && scale.col === width.col + 2;
  const pass = widthWorks && scaleWorks;
  const note = `Cursor advance: width ${widthWorks ? "verified" : "not verified"}; scale ${scaleWorks ? "verified" : "not verified"}. Glyph appearance needs a visual check.`;
  const response = JSON.stringify({ before, width, scale });
  return {
    pass,
    note,
    response,
    observation: { outcome: pass ? "supported" : "unsupported", evidence, note },
    assertions: [
      {
        kind: pass ? "positive" : "negative",
        expected: "Each OSC 66 width/scale sequence advances two columns without changing row",
        observed: response
      }
    ]
  };
}
function clipboardProtocolResult(response) {
  const match = /\x1b\[\?5522;([0-4])\$y/.exec(response);
  if (!match) {
    return unansweredQuery({ match: null, reason: "sentinel", raw: response, rawBase64: btoa(response) }, "No DECRPM response for mode 5522");
  }
  const supported = match[1] !== "0" && match[1] !== "4";
  const note = supported ? "Protocol recognized; clipboard access permissions not tested" : "Mode 5522 not supported";
  return {
    pass: supported,
    note,
    response,
    observation: { outcome: supported ? "supported" : "unsupported", evidence: "query", note },
    assertions: [
      {
        kind: supported ? "positive" : "negative",
        expected: "DECRPM 5522 has Ps=1, 2 or 3; Ps=0 or 4 explicitly rejects support",
        observed: response
      }
    ]
  };
}
function headlessClipboardRoundtrip(ctx) {
  const nonce = `terminfo-osc52-${randomUUID()}`;
  const encoded = btoa(nonce);
  ctx.feed(`\x1B]52;c;${encoded}\x07`);
  const response = ctx.feedCapture("\x1B]52;c;?\x07");
  const frames = response.matchAll(/\x1b\]52;c;([^\x07\x1b]*)(?:\x07|\x1b\\)/g);
  let sawCompleteFrame = false;
  let sawInvalidFrame = false;
  for (const frame of frames) {
    sawCompleteFrame = true;
    const data = frame[1] ?? "";
    try {
      if (btoa(atob(data)) !== data) {
        sawInvalidFrame = true;
        continue;
      }
      if (atob(data) === nonce) {
        const note = "Isolated backend returned the exact OSC 52 clipboard nonce";
        return {
          pass: true,
          response,
          note,
          observation: { outcome: "supported", evidence: "query", note },
          assertions: [
            { kind: "positive", expected: "OSC 52 c query returns the exact written nonce", observed: frame[0] }
          ]
        };
      }
    } catch {
      sawInvalidFrame = true;
    }
  }
  const reason = sawInvalidFrame || response.length > 0 && !sawCompleteFrame ? "invalid-reply" : sawCompleteFrame ? "insufficient-evidence" : "no-response";
  const note = reason === "invalid-reply" ? "No complete, canonical OSC 52 c reply was received from the isolated backend" : reason === "insufficient-evidence" ? "OSC 52 c replied with data other than the written nonce" : "No OSC 52 c query response from the isolated backend";
  return {
    pass: false,
    response,
    note,
    observation: { outcome: "inconclusive", reason, evidence: "query", note }
  };
}
function liveClipboardNotTested() {
  const note = "Collector policy: no owned disposable clipboard with verified restoration; OSC 52 was not sent";
  return {
    pass: false,
    note,
    observation: { outcome: "inconclusive", reason: "policy-refused", evidence: "none", note }
  };
}
function clipboardQueryResult(outcome, expected) {
  const frame = osc52Reply.exec(outcome.raw);
  if (!frame || outcome.reason !== "reply" || !outcome.match) {
    const reason = outcome.raw ? "invalid-reply" : "no-response";
    return {
      pass: false,
      observation: { outcome: "inconclusive", reason, evidence: "query", note: "No complete OSC 52 c reply" }
    };
  }
  const encoded = frame[1] ?? "";
  let decoded;
  try {
    decoded = atob(encoded);
    if (btoa(decoded) !== encoded)
      throw new Error("Noncanonical base64");
  } catch {
    return { pass: false, observation: { outcome: "inconclusive", reason: "invalid-reply", evidence: "query" } };
  }
  const pass = decoded === expected;
  return {
    pass,
    response: frame[0],
    observation: {
      outcome: pass ? "supported" : "inconclusive",
      ...!pass && { reason: "insufficient-evidence" },
      evidence: "query"
    },
    ...pass && {
      assertions: [
        { kind: "positive", expected: "OSC 52 c returns the independently written nonce", observed: frame[0] }
      ]
    }
  };
}
async function liveClipboardProbe(ctx, kind) {
  if (!ctx.withClipboardFixture)
    return liveClipboardNotTested();
  return ctx.withClipboardFixture(async (fixture) => {
    if (kind !== "read") {
      const nonce = `terminfo-osc52-${randomUUID()}`;
      if (typeof fixture.beforeOsc52Write !== "function") throw new Error("Missing private clipboard preparation");
      await fixture.beforeOsc52Write(nonce);
      ctx.write(`\x1B]52;c;${btoa(nonce)}\x07`);
      const cursor = await ctx.queryCursorPosition();
      if (!cursor) {
        return {
          pass: false,
          observation: {
            outcome: "inconclusive",
            reason: "no-response",
            evidence: "behavior",
            note: "No cursor reply after OSC 52 write; clipboard contents were not measured"
          }
        };
      }
      const measured = await fixture.readText();
      if (measured !== nonce) {
        return {
          pass: false,
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "behavior",
            note: "Independent clipboard read did not equal the OSC 52 write nonce"
          }
        };
      }
      if (kind === "write") {
        return {
          pass: true,
          observation: { outcome: "supported", evidence: "behavior" },
          assertions: [
            { kind: "positive", expected: "Independent clipboard text equals OSC 52 write nonce", observed: measured }
          ]
        };
      }
    }
    const nonce = `terminfo-osc52-${randomUUID()}`;
    await fixture.writeText(nonce);
    const outcome = await ctx.queryOutcome("\x1B]52;c;?\x07", osc52Reply);
    const result = clipboardQueryResult(outcome, nonce);
    if (!outcome.raw && ctx.capture && result.observation) {
      const frame = await ctx.capture({ role: "target", label: "Clipboard query after no response" });
      return {
        ...result,
        observation: {
          ...result.observation,
          screenshotRef: frame.ref,
          note: "No OSC 52 reply; retained the visible window for prompt/no-prompt review without automatic interaction"
        }
      };
    }
    return result;
  });
}
var sixelDa1Reply, foregroundQuery = "\x1B]10;?\x07", foregroundReply, colorPush = "\x1B]30001\x1B\\", colorPop = "\x1B]30101\x1B\\", DA1_COMPLETE, KITTY_FLAGS, KITTY_FLAGS_SHAPED, KITTY_FLAGS_TRUNCATED, osc52Reply, extensionsProbes;
var init_extensions = __esm(() => {
  sixelDa1Reply = /\x1b\[\?([0-9]+(?:;[0-9]+)*);?c/;
  foregroundReply = /\x1b\]10;(rgb:[a-f\d]{1,4}\/[a-f\d]{1,4}\/[a-f\d]{1,4})(?:\x07|\x1b\\)/i;
  DA1_COMPLETE = /\x1b\[\?[0-9;]+c/;
  KITTY_FLAGS = /\x1b\[\?(\d+)u/;
  KITTY_FLAGS_SHAPED = /\x1b\[\?[0-9;]*u/;
  KITTY_FLAGS_TRUNCATED = /\x1b\[\?[0-9;]*(?=\x1b|$)/;
  osc52Reply = /\x1b\]52;c;([A-Za-z0-9+/=]*)(?:\x07|\x1b\\)/;
  extensionsProbes = [
    {
      ...probe("extensions.truecolor", (ctx) => {
        const first = { r: 255, g: 128, b: 0 };
        const second = { r: 17, g: 97, b: 201 };
        ctx.feed("C\x1B[31mA\x1B[34mB\x1B[38;2;255;128;0mX\x1B[38;2;17;97;201mY");
        const baseline = ctx.getCell(0, 0);
        const controlFirst = ctx.getCell(0, 1);
        const controlSecond = ctx.getCell(0, 2);
        const targetFirst = ctx.getCell(0, 3);
        const targetSecond = ctx.getCell(0, 4);
        const state = { baseline, controlFirst, controlSecond, targetFirst, targetSecond };
        const expected = "Two distinct direct-RGB foreground samples match their requested values";
        const same = (a, b) => a !== null && a !== undefined && a.r === b.r && a.g === b.g && a.b === b.b;
        if (baseline.char !== "C" || controlFirst.char !== "A" || controlSecond.char !== "B" || targetFirst.char !== "X" || targetSecond.char !== "Y" || !targetFirst.fg || !targetSecond.fg) {
          return parserStateResult(null, expected, state, "RGB targets or controls were not exposed");
        }
        if (!controlSecond.fg || same(controlSecond.fg, first)) {
          return parserStateResult(null, expected, state, "The preceding color can mimic an ignored RGB request");
        }
        if (same(targetFirst.fg, first) && same(targetSecond.fg, second)) {
          return parserStateResult(true, expected, state);
        }
        if (controlFirst.fg && !sameRgbCells(controlFirst.fg, controlSecond.fg)) {
          return parserStateResult(false, expected, state);
        }
        return parserStateResult(null, expected, state, "Independent color-channel calibration was absent");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B[38;2;255;0;128mX\x1B[0m");
        const pos = await ctx.queryCursorPosition();
        if (!pos)
          return unverifiedEffect("No cursor response; RGB color was not measured");
        return unverifiedEffect(pos.col === 2 ? "SGR was consumed; RGB cell color was not measured" : `Cursor at col ${pos.col}; RGB color was not measured`);
      }),
      termlessObservationEvidence: "parser-state"
    },
    kittyKeyboardFlagProbe("extensions.kitty-keyboard", 1, 1),
    kittyKeyboardFlagProbe("extensions.kitty-keyboard.disambiguate", 1, 1),
    kittyKeyboardFlagProbe("extensions.kitty-keyboard.report-events", 3, 2),
    kittyKeyboardFlagProbe("extensions.kitty-keyboard.report-alternate", 5, 4),
    kittyKeyboardFlagProbe("extensions.kitty-keyboard.report-all-keys", 9, 8),
    kittyKeyboardFlagProbe("extensions.kitty-keyboard.report-text", 25, 24),
    {
      ...queryOnly(probe("extensions.kitty-graphics", (ctx) => graphicsQueryResult(ctx.feedCapture("\x1B_Gi=31,s=1,v=1,a=q,t=d,f=24;AAAA\x1B\\"), 31), async (ctx) => {
        const reply = await ctx.queryWithSentinelOutcome("\x1B_Gi=31,s=1,v=1,a=q,t=d,f=24;AAAA\x1B\\", /\x1b_Gi=31;([^\x1b]+)\x1b\\/);
        if (!reply.match) {
          return unansweredQuery(reply, "No matching graphics query reply; image rendering was not tested");
        }
        return graphicsQueryResult(reply.match[0] ?? "", 31);
      }, "query")),
      termlessObservationEvidence: "query"
    },
    kittyImageTransferProbe("extensions.kitty-graphics.transmit", false),
    kittyImageTransferProbe("extensions.kitty-graphics.display", true),
    probe("extensions.kitty-graphics.animation", (ctx) => {
      const note = "Declared Kitty graphics capability does not establish timed animation playback";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.kittyGraphics === true }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No timed frame playback or pixel readback for Kitty animation";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    probe("extensions.kitty-graphics.unicode-placeholders", (ctx) => {
      const note = "Declared Kitty graphics capability does not establish Unicode placeholder rendering";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.kittyGraphics === true }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No pixel and placeholder-cell readback for Kitty Unicode placeholders";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    probe("extensions.sixel", (ctx) => {
      const note = "Declared Sixel capability does not establish rendered pixels";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.sixel === true }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No pixel readback for Sixel rendering";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    {
      ...probe("extensions.osc8", (ctx) => {
        const uri = "https://example.com/osc8-proof";
        ctx.feed(`\x1B[1;1H\x1B[2KA\x1B]8;;${uri}\x07LINK\x1B]8;;\x07Z`);
        const cells = Array.from({ length: 6 }, (_, col) => {
          const { hyperlink: _unreported, ...cell } = ctx.getCell(0, col);
          const hyperlink = readHyperlinkMetadata(ctx.capabilities.extensions.has("hyperlinks"), ctx.getHyperlinkAt, 0, col, "OSC 8 context");
          return { ...cell, ...hyperlink !== undefined && { hyperlink } };
        });
        const expectedChars = "ALINKZ";
        const links = cells.map((cell) => cell.hyperlink !== undefined ? { reported: true, uri: cell.hyperlink } : { reported: false });
        const response = JSON.stringify({ chars: cells.map((cell) => cell.char), links });
        const reported = links.every((link) => link.reported);
        const charsMatch = cells.every((cell, index) => cell.char === expectedChars[index]);
        if (!reported || !charsMatch || cells.slice(1, 5).some((cell) => cell.hyperlink === null)) {
          return {
            pass: false,
            response,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "parser-state",
              note: !reported ? "Backend did not report OSC 8 link metadata" : "Linked text was not observable"
            }
          };
        }
        const expected = JSON.stringify({
          chars: [...expectedChars],
          links: [null, uri, uri, uri, uri, null].map((link) => ({ reported: true, uri: link }))
        });
        const observed = response;
        const pass = observed === expected;
        return {
          pass,
          response,
          observation: {
            outcome: pass ? "supported" : "unsupported",
            evidence: "parser-state",
            ...!pass && { note: "OSC 8 cell URI differs from the exact requested link or leaked past close" }
          },
          assertions: [{ kind: pass ? "positive" : "negative", expected, observed }]
        };
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 7) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `OSC 8 fixture needs at least 1x7, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("A\x1B]8;;https://example.com/osc8-proof\x07LINK\x1B]8;;\x07Z");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return {
            pass: false,
            note: "No cursor response",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "consumed" }
          };
        }
        return {
          pass: false,
          response: `${pos.row};${pos.col}`,
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor movement cannot verify OSC 8 link metadata or click behavior"
          }
        };
      }, "consumed"),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    probe("extensions.reflow", (ctx) => {
      const note = "No controlled resize and cell-content readback to measure reflow";
      return {
        pass: false,
        response: JSON.stringify({ declaredReflow: ctx.capabilities.reflow === true }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No controlled resize and cell-content readback to measure reflow";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    probe("extensions.semantic-prompts", (ctx) => {
      const note = "Declared semantic-prompt capability does not establish shell prompt integration";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.semanticPrompts === true }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No shell prompt integration metadata or behavior readback for OSC 133";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    {
      ...probe("extensions.osc2-title", (ctx) => {
        ctx.feed("\x1B]2;Test Title\x07");
        const title = ctx.getTitle();
        return parserStateResult(title === "Test Title", "OSC 2 sets the exact requested window title", { title });
      }, () => Promise.resolve(unmeasuredStateEffect("OSC 2 window title"))),
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("extensions.osc0-icon-title", (ctx) => {
        const before = ctx.getTitle();
        ctx.feed("\x1B]0;My Title\x07");
        const after = ctx.getTitle();
        return notTestedResult("icon-name state", { before, after });
      }, () => {
        const note = "No icon-name and window-title readback for OSC 0";
        return Promise.resolve({
          pass: false,
          note,
          observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
        });
      }),
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("extensions.osc52-clipboard", headlessClipboardRoundtrip, (ctx) => liveClipboardProbe(ctx, "roundtrip"), "behavior"),
      termlessObservationEvidence: "query"
    },
    {
      ...probe("extensions.osc52-write", headlessClipboardRoundtrip, (ctx) => liveClipboardProbe(ctx, "write"), "behavior"),
      termlessObservationEvidence: "query"
    },
    {
      ...probe("extensions.osc52-read", headlessClipboardRoundtrip, (ctx) => liveClipboardProbe(ctx, "read"), "query"),
      termlessObservationEvidence: "query"
    },
    oscColorQueryProbe("extensions.osc10-fg-color", 10),
    oscColorQueryProbe("extensions.osc11-bg-color", 11),
    probe("extensions.osc7-cwd", (ctx) => {
      const note = "Declared OSC 7 capability does not establish working-directory metadata delivery";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.extensions.has("osc7") }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No working-directory metadata readback for OSC 7";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    probe("extensions.osc-633-vscode", (ctx) => {
      const note = "Declared semantic-prompt capability does not establish VS Code OSC 633 shell integration";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.semanticPrompts === true }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No VS Code shell integration metadata or behavior readback for OSC 633";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    {
      ...probe("extensions.osc133-a", (ctx) => {
        ctx.feed("\x1B]133;A\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]133;A\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc133-b", (ctx) => {
        ctx.feed("\x1B]133;B\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]133;B\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc133-c", (ctx) => {
        ctx.feed("\x1B]133;C\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]133;C\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc133-d", (ctx) => {
        ctx.feed("\x1B]133;D;0\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]133;D;0\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc133-p", (ctx) => {
        ctx.feed("\x1B]133;P;Cwd=/tmp\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]133;P;Cwd=/tmp\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc633-a", (ctx) => {
        ctx.feed("\x1B]633;A\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]633;A\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc633-b", (ctx) => {
        ctx.feed("\x1B]633;B\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]633;B\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc633-c", (ctx) => {
        ctx.feed("\x1B]633;C\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]633;C\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc633-d", (ctx) => {
        ctx.feed("\x1B]633;D;0\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]633;D;0\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc633-e", (ctx) => {
        ctx.feed("\x1B]633;E;ls -la;nonce123\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]633;E;ls -la;nonce123\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    {
      ...probe("extensions.osc633-p", (ctx) => {
        ctx.feed("\x1B]633;P;Cwd=/tmp\x07X");
        const cell = ctx.getCell(0, 0);
        return promptConsumptionResult(cell.char === "X");
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]633;P;Cwd=/tmp\x07X");
        const pos = await ctx.queryCursorPosition();
        return promptConsumptionResult(pos === null ? null : pos.col === 2);
      }),
      termlessObservationEvidence: "consumed"
    },
    probe("extensions.notifications", (ctx) => {
      const note = "Declared OSC 9 capability does not establish desktop notification delivery";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.extensions.has("osc9") }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No desktop notification delivery readback for OSC 9";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    probe("extensions.iterm2-images", (ctx) => {
      const note = "Declared iTerm2 image capability does not establish rendered image pixels";
      return {
        pass: false,
        response: JSON.stringify({ declared: ctx.capabilities.extensions.has("iterm2Images") }),
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "legacy", note }
      };
    }, () => {
      const note = "No pixel readback for iTerm2 inline image rendering";
      return Promise.resolve({
        pass: false,
        note,
        observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
      });
    }),
    oscSimpleQueryProbe("extensions.osc1337-cellsize", "\x1B]1337;ReportCellSize\x07", /\x1b\]1337;ReportCellSize=[1-9][0-9]*(?:\.[0-9]+)?;[1-9][0-9]*(?:\.[0-9]+)?(?:\x07|\x1b\\)/, /\x1b\]1337;ReportCellSize=/, "Complete OSC 1337 ReportCellSize reply with two positive dimensions"),
    oscSimpleQueryProbe("extensions.osc1337-capabilities", "\x1B]1337;RequestCapabilities\x07", /\x1b\]1337;Capabilities=[^\x07\x1b]*(?:\x07|\x1b\\)/, /\x1b\]1337;Capabilities=/, "Complete OSC 1337 Capabilities reply"),
    probe("extensions.osc9-progress", null, () => Promise.resolve(unmeasuredStateEffect("OSC 9;4 progress display"))),
    {
      ...probe("extensions.osc66-text-sizing", (ctx) => {
        ctx.feed("\x1B[1;1H\x1B[2K\r");
        const before = { ...ctx.getCursor() };
        if (before.x !== 0 || before.y !== 0) {
          const note = `OSC 66 baseline cursor did not reach home: ${before.y};${before.x}`;
          return {
            pass: false,
            response: JSON.stringify({ row: before.y, col: before.x }),
            note,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "parser-state", note }
          };
        }
        ctx.feed("\x1B]66;w=2; \x07");
        const width = { ...ctx.getCursor() };
        ctx.feed("\x1B]66;s=2; \x07");
        const scale = { ...ctx.getCursor() };
        return textSizingResult({ row: before.y, col: before.x }, { row: width.y, col: width.x }, { row: scale.y, col: scale.x }, "parser-state");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `OSC 66 fixture needs at least 1x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K\r");
        const before = await ctx.queryCursorPosition();
        if (!before) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              evidence: "behavior",
              reason: "no-response",
              note: "No baseline cursor response"
            }
          };
        }
        if (before.row !== 1 || before.col !== 1) {
          const note = `OSC 66 baseline cursor did not reach home: ${before.row};${before.col}`;
          return {
            pass: false,
            response: JSON.stringify(before),
            note,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "behavior", note }
          };
        }
        ctx.write("\x1B]66;w=2; \x07");
        const width = await ctx.queryCursorPosition();
        ctx.write("\x1B]66;s=2; \x07");
        const scale = await ctx.queryCursorPosition();
        if (!width || !scale) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              evidence: "behavior",
              reason: "no-response",
              note: "Missing cursor response for text sizing"
            }
          };
        }
        return textSizingResult(before, width, scale, "behavior");
      }, "behavior"),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...queryOnly(probe("extensions.osc5522-clipboard", (ctx) => clipboardProtocolResult(ctx.feedCapture("\x1B[?5522$p")), async (ctx) => {
        const reply = await ctx.queryWithSentinelOutcome("\x1B[?5522$p", /\x1b\[\?5522;([0-4])\$y/);
        if (!reply.match)
          return unansweredQuery(reply, "No DECRPM response for mode 5522");
        return clipboardProtocolResult(reply.match[0] ?? "");
      }, "query")),
      termlessObservationEvidence: "query"
    },
    {
      ...probe("extensions.osc1-icon", (ctx) => {
        const before = ctx.getTitle();
        ctx.feed("\x1B]1;test-icon\x07");
        const after = ctx.getTitle();
        return notTestedResult("icon-name state", { before, after });
      }, () => {
        const note = "No icon-name readback for OSC 1";
        return Promise.resolve({
          pass: false,
          note,
          observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
        });
      }),
      termlessObservationEvidence: "parser-state"
    },
    oscSimpleQueryProbe("extensions.osc4-palette", "\x1B]4;0;?\x07", /\x1b\]4;0;rgb:[0-9a-f]{1,4}\/[0-9a-f]{1,4}\/[0-9a-f]{1,4}(?:\x07|\x1b\\)/i, /\x1b\]4;0;/, "Complete OSC 4 index-0 color reply"),
    oscSimpleQueryProbe("extensions.osc5-special-color", "\x1B]5;0;?\x07", /\x1b\]5;0;rgb:[0-9a-f]{1,4}\/[0-9a-f]{1,4}\/[0-9a-f]{1,4}(?:\x07|\x1b\\)/i, /\x1b\]5;0;/, "Complete OSC 5 index-0 color reply"),
    oscColorQueryProbe("extensions.osc12-cursor-color", 12),
    probe("extensions.osc104-reset-palette", colorResetProbe(4, 104, 0), () => Promise.resolve(unmeasuredStateEffect("OSC 104 palette reset"))),
    probe("extensions.osc110-reset-fg", colorResetProbe(10, 110), () => Promise.resolve(unmeasuredStateEffect("OSC 110 foreground reset"))),
    probe("extensions.osc111-reset-bg", colorResetProbe(11, 111), () => Promise.resolve(unmeasuredStateEffect("OSC 111 background reset"))),
    probe("extensions.osc112-reset-cursor", colorResetProbe(12, 112), () => Promise.resolve(unmeasuredStateEffect("OSC 112 cursor-color reset"))),
    {
      ...probe("extensions.osc117-reset-highlight-bg", (ctx) => {
        ctx.feed("\x1B]117\x07X");
        const cell = ctx.getCell(0, 0);
        return notTestedResult("highlight background color", { cell });
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]117\x07");
        const pos = await ctx.queryCursorPosition();
        return unverifiedEffect(pos ? "Cursor answered; highlight background was not read back" : "No cursor response after OSC 117");
      }),
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("extensions.osc119-reset-highlight-fg", (ctx) => {
        ctx.feed("\x1B]119\x07X");
        const cell = ctx.getCell(0, 0);
        return notTestedResult("highlight foreground color", { cell });
      }, async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]119\x07");
        const pos = await ctx.queryCursorPosition();
        return unverifiedEffect(pos ? "Cursor answered; highlight foreground was not read back" : "No cursor response after OSC 119");
      }),
      termlessObservationEvidence: "parser-state"
    },
    oscColorQueryProbe("extensions.osc17-highlight-bg", 17),
    oscColorQueryProbe("extensions.osc19-highlight-fg", 19),
    probe("extensions.osc22-pointer", null, async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]22;pointer\x07");
      const pos = await ctx.queryCursorPosition();
      return unmeasuredCellResult(pos, "OSC 22 pointer shape");
    }),
    queryOnly(probe("extensions.osc99-kitty-notify", null, async (ctx) => {
      const id = globalThis.crypto.randomUUID();
      const reply = await ctx.queryWithSentinelOutcome(`\x1B]99;i=${id}:p=?;\x1B\\`, new RegExp(`\\x1b\\]99;i=${id}:p=\\?;([^\\x07\\x1b]*)(?:\\x07|\\x1b\\\\)`));
      if (!reply.match) {
        return unansweredQuery(reply, "No matching notification query reply; OS display was not tested");
      }
      const payloadFields = reply.match[1]?.split(":").filter((field) => field.startsWith("p=")) ?? [];
      const pass = payloadFields.length === 1 && payloadFields[0]?.slice(2).split(",").includes("title") === true;
      const note = pass ? "Notification capabilities acknowledge title payloads; OS display, activation and close events were not tested" : "Notification reply does not advertise the required title payload; no support conclusion";
      return {
        pass,
        response: reply.match[0],
        note,
        observation: {
          outcome: pass ? "supported" : "inconclusive",
          evidence: "query",
          ...!pass && { reason: "invalid-reply" },
          note
        },
        ...pass && {
          assertions: [
            {
              kind: "positive",
              expected: `OSC 99 echoes i=${id}, p=? and advertises p=title`,
              observed: reply.match[0] ?? ""
            }
          ]
        }
      };
    }, "query")),
    probe("extensions.osc777-notify", null, async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]777;notify;test;body\x07");
      const pos = await ctx.queryCursorPosition();
      return unmeasuredCellResult(pos, "OSC 777 notification delivery");
    }),
    probe("extensions.osc666-termprop", null, async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]666;test-prop=value\x07");
      const pos = await ctx.queryCursorPosition();
      return unmeasuredCellResult(pos, "OSC 666 terminal property");
    }),
    probe("extensions.osc3008-context", null, async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]3008;type=test\x07");
      const pos = await ctx.queryCursorPosition();
      return unmeasuredCellResult(pos, "OSC 3008 systemd context");
    }),
    probe("extensions.osc113-reset-pointer-fg", colorResetProbe(13, 113), async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]113\x07");
      const pos = await ctx.queryCursorPosition();
      return unverifiedEffect(pos ? "Cursor answered; pointer foreground restoration was not measured" : "No cursor response after OSC 113");
    }),
    probe("extensions.osc114-reset-pointer-bg", colorResetProbe(14, 114), async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]114\x07");
      const pos = await ctx.queryCursorPosition();
      return unverifiedEffect(pos ? "Cursor answered; pointer background restoration was not measured" : "No cursor response after OSC 114");
    }),
    {
      ...queryOnly(probe("extensions.osc21-kitty-color", (ctx) => kittyForegroundResult(ctx.feedCapture("\x1B]21;foreground=?\x1B\\")), async (ctx) => {
        const reply = await ctx.queryWithSentinelOutcome("\x1B]21;foreground=?\x1B\\", /\x1b\]21;([^\x07\x1b]*)(?:\x07|\x1b\\)/);
        if (!reply.match)
          return unansweredQuery(reply, "No OSC 21 reply; color rendering was not tested");
        return kittyForegroundResult(reply.match[0] ?? "");
      }, "query")),
      termlessObservationEvidence: "query"
    },
    probe("extensions.osc30001-color-stack-push", colorStackProbe(), colorStackTermProbe, "behavior"),
    probe("extensions.osc30101-color-stack-pop", colorStackProbe(), colorStackTermProbe, "behavior"),
    probe("extensions.osc176-app-id", null, async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]176;terminfo-test\x07");
      const pos = await ctx.queryCursorPosition();
      return unmeasuredCellResult(pos, "OSC 176 Wayland app-id");
    }),
    probe("extensions.osc555-flash", null, async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]555\x07");
      const pos = await ctx.queryCursorPosition();
      return unmeasuredCellResult(pos, "OSC 555 screen flash");
    }),
    probe("extensions.osc440-audio", null, async (ctx) => {
      ctx.write("\x1B[1;1H\x1B[2K");
      ctx.write("\x1B]440;bell.wav\x07");
      const pos = await ctx.queryCursorPosition();
      return unmeasuredCellResult(pos, "OSC 440 audio playback");
    }),
    oscSimpleQueryProbe("extensions.osc7770-font-size", "\x1B]7770;?\x07", /\x1b\]7770;[0-9]+(?:\x07|\x1b\\)/, /\x1b\]7770;/, "Complete OSC 7770 font-size reply"),
    oscSimpleQueryProbe("extensions.osc7777-font-window-size", "\x1B]7777;?\x07", /\x1b\]7777;[0-9]+(?:\x07|\x1b\\)/, /\x1b\]7777;/, "Complete OSC 7777 window-size reply"),
    oscSimpleQueryProbe("extensions.osc701-locale", "\x1B]701;?\x07", /\x1b\]701;[A-Za-z0-9_.-]+(?:\x07|\x1b\\)/, /\x1b\]701;/, "Complete OSC 701 locale reply"),
    oscSimpleQueryProbe("extensions.osc702-version", "\x1B]702\x07", /\x1b\]702;[^\x07\x1b]+(?:\x07|\x1b\\)/, /\x1b\]702;/, "Complete OSC 702 version reply"),
    probe("extensions.osc710-font-normal", null, () => Promise.resolve(unmeasuredStateEffect("OSC 710 font selection"))),
    {
      ...probe("extensions.osc720-scroll-up", osc720ScrollProbe(), async (ctx) => {
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B]720\x07");
        const pos = await ctx.queryCursorPosition();
        return unverifiedEffect(pos ? "Cursor answered; scrollback viewport was not measured" : "No cursor response after OSC 720");
      }),
      termlessObservationEvidence: "parser-state"
    },
    oscSimpleQueryProbe("extensions.osc776-cell-size", "\x1B]776\x07", /\x1b\]776;[0-9]+;[0-9]+;[0-9]+(?:\x07|\x1b\\)/, /\x1b\]776;/, "Complete OSC 776 cell-size reply"),
    {
      ...queryOnly(probe("extensions.sixel-da1", (ctx) => {
        const raw = ctx.feedCapture("\x1B[c");
        return sixelDa1Result(raw, sixelDa1Reply.exec(raw)?.[0] ?? null);
      }, async (ctx) => {
        const reply = await ctx.queryOutcome("\x1B[c", sixelDa1Reply);
        return sixelDa1Result(reply.raw, reply.reason === "reply" ? reply.match?.[0] ?? null : null);
      }, "query")),
      termlessObservationEvidence: "query"
    },
    {
      ...queryOnly(probe("extensions.sixel-geometry-report", (ctx) => {
        const raw = ctx.feedCapture("\x1B[?2;1;0S");
        const frame = /\x1b\[\?2;[0-9;]*S/.exec(raw)?.[0] ?? null;
        return sixelGeometryResult(raw, frame, "no-response");
      }, async (ctx) => {
        const reply = await ctx.queryWithSentinelOutcome("\x1B[?2;1;0S", /\x1b\[\?2;[0-9;]*S/, 1000);
        const frame = reply.reason === "reply" ? reply.match?.[0] ?? null : null;
        return sixelGeometryResult(reply.raw, frame, reply.reason === "timeout" ? "timeout" : "no-response");
      }, "query")),
      termlessObservationEvidence: "query"
    }
  ];
});

// ../probe-defs/src/input.ts
function mouseInputProbe(id, modeName) {
  return probe(id, (ctx) => ({
    pass: false,
    response: JSON.stringify({ currentMode: ctx.getMode(modeName) === true }),
    note: absentEventNote,
    observation: {
      outcome: "inconclusive",
      reason: "insufficient-evidence",
      evidence: "legacy",
      note: absentEventNote
    }
  }), () => Promise.resolve({
    pass: false,
    note: absentEventNote,
    observation: {
      outcome: "inconclusive",
      reason: "insufficient-evidence",
      evidence: "none",
      note: absentEventNote
    }
  }));
}
var absentEventNote = "No generated input event and encoded report were validated", inputProbes;
var init_input = __esm(() => {
  init_extensions();
  inputProbes = [
    probe("input.modify-other-keys", (ctx) => ({
      pass: false,
      response: JSON.stringify({ declaredModifyOtherKeys: ctx.capabilities.extensions.has("modifyOtherKeys") }),
      note: absentEventNote,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "legacy",
        note: absentEventNote
      }
    }), () => Promise.resolve({
      pass: false,
      note: absentEventNote,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "none",
        note: absentEventNote
      }
    })),
    kittyKeyboardFlagProbe("input.csi-u", 1, 1),
    mouseInputProbe("input.pixel-mouse", "pixelMouse"),
    mouseInputProbe("input.urxvt-mouse", "mouseTracking"),
    mouseInputProbe("input.x10-mouse", "mouseTracking"),
    probe("input.modify-other-keys-3", (ctx) => ({
      pass: false,
      response: JSON.stringify({ declaredModifyOtherKeys: ctx.capabilities.extensions.has("modifyOtherKeys") }),
      note: absentEventNote,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "legacy",
        note: absentEventNote
      }
    }), () => Promise.resolve({
      pass: false,
      note: absentEventNote,
      observation: {
        outcome: "inconclusive",
        reason: "insufficient-evidence",
        evidence: "none",
        note: absentEventNote
      }
    })),
    mouseInputProbe("input.button-event-mouse", "mouseTracking")
  ];
});

// ../probe-defs/src/reset.ts
var resetProbes;
var init_reset = __esm(() => {
  resetProbes = [
    {
      ...probe("reset.sgr", (ctx) => {
        ctx.feed("\x1B[1;3;7mX\x1B[0mY");
        const before = ctx.getCell(0, 0);
        const after = ctx.getCell(0, 1);
        const state = { before, after };
        const expected = "SGR 0 clears measured bold, italic, and inverse styling on Y";
        if (before.char !== "X" || after.char !== "Y" || !before.bold || !before.italic || !before.inverse) {
          return parserStateResult(null, expected, state, "Styled control or reset cell was not measured");
        }
        return parserStateResult(!after.bold && !after.italic && !after.inverse, expected, state);
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 2) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Reset fixture needs at least 1x2, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B[1m");
        ctx.write("\x1B[0m");
        ctx.write("X");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor advance does not measure SGR styling after reset"
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("reset.ris", (ctx) => {
        ctx.feed("Hello World");
        const before = { ...ctx.getCursor(), text: ctx.getText() };
        ctx.feed("\x1Bc");
        const after = { ...ctx.getCursor(), text: ctx.getText() };
        const expected = "RIS returns the cursor home and clears measured text";
        if (!before.text.includes("Hello World") || before.x === 0) {
          return parserStateResult(null, expected, { before, after }, "RIS control state was not measured");
        }
        return parserStateResult(after.x === 0 && after.y === 0 && !after.text.includes("Hello World"), expected, {
          before,
          after
        });
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 5 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Reset fixture needs at least 5x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[5;5H");
        const before = await ctx.queryCursorPosition();
        if (!before) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        ctx.write("\x1Bc");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        const measured = { before, after: pos };
        const setup = before.row === 5 && before.col === 5;
        const home = pos.row === 1 && pos.col === 1;
        return {
          pass: setup && home,
          response: JSON.stringify(measured),
          observation: {
            outcome: setup ? home ? "supported" : "unsupported" : "inconclusive",
            ...setup ? {} : { reason: "insufficient-evidence" },
            evidence: "query",
            note: "Measured RIS cursor reset; other reset effects were not inspected"
          },
          ...setup && {
            assertions: [
              {
                kind: home ? "positive" : "negative",
                expected: "RIS homes cursor from 5;5",
                observed: JSON.stringify(measured)
              }
            ]
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("reset.soft", (ctx) => {
        ctx.feed("\x1B[?1h");
        const before = ctx.getMode("applicationCursor");
        ctx.feed("Hello");
        ctx.feed("\x1B[!p");
        const after = ctx.getMode("applicationCursor");
        return parserStateResult(before ? !after : null, "DECSTR clears an enabled application-cursor mode", { before, after }, before ? undefined : "Application-cursor mode was not enabled before DECSTR");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 5 || ctx.cols < 5) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Reset fixture needs at least 5x5, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        const before = await ctx.queryMode(1);
        if (before === null || before === "unknown") {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "no-response",
              evidence: "query",
              note: "Cannot restore prior application-cursor mode without its readback"
            }
          };
        }
        ctx.write("\x1B[?1h");
        try {
          const enabled = await ctx.queryMode(1);
          ctx.write("\x1B[!p");
          const after = await ctx.queryMode(1);
          const measured = { before, enabled, after };
          if (enabled !== "set" || after === null || after === "unknown") {
            return {
              pass: false,
              response: JSON.stringify(measured),
              observation: {
                outcome: "inconclusive",
                reason: "insufficient-evidence",
                evidence: "query",
                note: "Application-cursor mode setup or reset readback was unavailable"
              }
            };
          }
          const pass = after === "reset";
          return {
            pass,
            response: JSON.stringify(measured),
            observation: { outcome: pass ? "supported" : "unsupported", evidence: "query" },
            assertions: [
              {
                kind: pass ? "positive" : "negative",
                expected: "DECSTR resets previously enabled DECCKM mode 1",
                observed: JSON.stringify(measured)
              }
            ]
          };
        } finally {
          if (before === "set")
            ctx.write("\x1B[?1h");
          else
            ctx.write("\x1B[?1l");
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("reset.decaln", (ctx) => {
        ctx.feed("\x1B#8");
        const cell = ctx.getCell(0, 0);
        return parserStateResult(cell.char === "E", "DECALN fills the measured cell (0,0) with E", { cell });
      }, async (ctx) => {
        const rows = ctx.rows;
        const cols = ctx.cols;
        const capture = ctx.capture;
        if (!capture || !Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 2 || cols < 2) {
          const note = `DECALN pixel fixture needs capture and measured 2x2 geometry; measured ${rows}x${cols}`;
          return {
            pass: false,
            note,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none", note }
          };
        }
        const seed = "AB".repeat(Math.ceil(cols / 2)).slice(0, cols);
        try {
          ctx.write("\x1B[0m\x1B[2J\x1B[H");
          for (let row = 1;row <= rows; row++)
            ctx.write(`\x1B[${row};1H${seed}`);
          ctx.write("\x1B[H");
          const control = await capture({ role: "control", label: "Known non-E AB grid before DECALN" });
          ctx.write("\x1B#8");
          const postAlignmentCursor = await ctx.queryCursorPosition();
          const target = await capture({ role: "target", label: "DECALN alignment grid after ESC # 8" });
          const delayedCaptureMs = 5000;
          await new Promise((resolve) => {
            setTimeout(resolve, delayedCaptureMs);
          });
          const delayedTarget = await capture({
            role: "target",
            label: "DECALN alignment grid after delayed checkpoint"
          });
          ctx.write("\x1B[H");
          const cursorOnlyControl = await capture({ role: "control", label: "Cursor-only control after CUP home" });
          ctx.write("X");
          const redrawControl = await capture({ role: "control", label: "Redraw control after one ordinary glyph" });
          const observed = JSON.stringify({
            rows,
            cols,
            seed,
            postAlignmentCursor,
            control,
            target,
            delayedCaptureMs,
            delayedTarget,
            cursorOnlyControl,
            redrawControl
          });
          return {
            pass: false,
            response: observed,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "pixels",
              screenshotRef: target.ref,
              frames: [control, target, delayedTarget, cursorOnlyControl, redrawControl],
              note: `${postAlignmentCursor === null ? "No post-DECALN CPR response; processing barrier unconfirmed. " : ""}Known non-E grid, initial and delayed DECALN targets, cursor-only control and ordinary-glyph redraw control captured; repeated E glyphs across measured rows and columns require independent review. CPR at the already-homed cursor records responsiveness, not DECALN recognition or render completion`
            },
            assertions: [
              {
                kind: "positive",
                expected: `Control shows alternating A/B across ${rows} rows and ${cols} columns; DECALN target shows repeated E across that same measured grid`,
                observed,
                note: "capture-only assertion; glyphs and full-grid coverage must be independently reviewed"
              }
            ]
          };
        } finally {
          ctx.write("\x1B[0m\x1B[2J\x1B[H");
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("reset.method", (ctx) => {
        ctx.feed("Hello World");
        const before = { ...ctx.getCursor(), text: ctx.getText() };
        ctx.reset();
        const after = { ...ctx.getCursor(), text: ctx.getText() };
        const expected = "Reset method returns the cursor home and clears measured text";
        if (!before.text.includes("Hello World") || before.x === 0) {
          return parserStateResult(null, expected, { before, after }, "Reset-method control state was not measured");
        }
        return parserStateResult(after.x === 0 && after.y === 0 && !after.text.includes("Hello World"), expected, {
          before,
          after
        });
      }, () => {
        const note = "The app context has no reset() method or equivalent state readback";
        return Promise.resolve({
          pass: false,
          note,
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "none",
            note
          }
        });
      })
    }
  ];
});

// ../probe-defs/src/scrollback.ts
function tooSmall2(ctx, rows, cols) {
  if (validSize2(ctx.rows, rows) && validSize2(ctx.cols, cols))
    return;
  return {
    pass: false,
    observation: {
      outcome: "inconclusive",
      reason: "insufficient-evidence",
      evidence: "none",
      note: `Scrollback fixture needs at least ${rows}x${cols}; measured ${ctx.rows}x${ctx.cols}`
    }
  };
}
function validSize2(value, minimum) {
  return Number.isSafeInteger(value) && value >= minimum;
}
var scrollbackProbes;
var init_scrollback = __esm(() => {
  scrollbackProbes = [
    {
      ...probe("scrollback.accumulate", (ctx) => {
        const baseline = ctx.getScrollback();
        const rows = baseline.screenLines;
        if (!validSize2(rows, 1) || !validSize2(ctx.cols, `line ${rows + 9}`.length)) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        for (let i = 0;i < rows + 10; i++)
          ctx.feed(`line ${i}\r
`);
        const scroll = ctx.getScrollback();
        return parserStateResult(scroll.totalLines > baseline.totalLines, "Written lines increase measured scrollback history", { baseline, scroll });
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 1, `line-${ctx.rows + 9}`.length);
        if (refusal)
          return refusal;
        const rows = ctx.rows;
        ctx.write("\x1B[2J\x1B[H");
        const lineCount = rows + 10;
        for (let i = 0;i < lineCount; i++) {
          ctx.write(`line-${i}
`);
        }
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor position does not measure scrollback history"
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.total-lines", (ctx) => {
        const baseline = ctx.getScrollback();
        const rows = baseline.screenLines;
        if (!validSize2(rows, 1) || !validSize2(ctx.cols, `line ${rows + 9}`.length)) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        const lineCount = rows + 10;
        for (let i = 0;i < lineCount; i++)
          ctx.feed(`line ${i}\r
`);
        const scroll = ctx.getScrollback();
        return parserStateResult(scroll.totalLines > baseline.totalLines, "Measured total lines increase after writing beyond the screen", { baseline, lineCount, scroll });
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 5, `total-${ctx.rows + 9}`.length);
        if (refusal)
          return refusal;
        ctx.write("\x1B[2J\x1B[H");
        for (let i = 0;i < ctx.rows + 10; i++)
          ctx.write(`total-${i}
`);
        ctx.write("\x1B[5;1H");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor position does not measure total scrollback lines"
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.scroll-up", (ctx) => {
        const initial = ctx.getScrollback();
        const rows = initial.screenLines;
        if (!validSize2(rows, 5) || !validSize2(ctx.cols, 3) || initial.totalLines !== rows) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        const expected = "Interior-region SU shifts the measured middle and bottom rows up, clearing the region bottom";
        ctx.feed("\x1B[2J");
        for (const [row, marker] of ["A", "B", "C", "D", "E"].entries()) {
          ctx.feed(`\x1B[${row + 1};1H${marker}`);
        }
        try {
          ctx.feed("\x1B[2;4r");
          const seed = Array.from({ length: 5 }, (_, row) => ctx.getCell(row, 0).char);
          const beforeScroll = ctx.getScrollback();
          if (seed.join("") !== "ABCDE" || beforeScroll.totalLines !== rows) {
            return parserStateResult(null, expected, { seed, beforeScroll }, "Interior-region SU seed or history was not established");
          }
          ctx.feed("\x1B[S");
          const after = Array.from({ length: 5 }, (_, row) => ctx.getCell(row, 0).char);
          const afterScroll = ctx.getScrollback();
          const controlsValid = after[0] === "A" && after[4] === "E" && afterScroll.totalLines === rows;
          const shifted = after[1] === "C" && after[2] === "D" && isBlank(after[3] ?? "\x00");
          const unchanged = after.join("") === "ABCDE";
          return parserStateResult(controlsValid ? shifted ? true : unchanged ? false : null : null, expected, { seed, beforeScroll, after, afterScroll }, controlsValid && (shifted || unchanged) ? undefined : "Interior-region SU controls or output were not measured");
        } finally {
          ctx.feed("\x1B[r");
        }
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 5, 5);
        if (refusal)
          return refusal;
        ctx.write("\x1B[5;5H");
        ctx.write("\x1B[1S");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor position does not measure scroll-up contents"
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.reverse-index", (ctx) => {
        ctx.feed(`A\r
B\r
C`);
        const before = ctx.getCell(0, 0);
        ctx.feed("\x1B[H\x1BM");
        const after = ctx.getCell(0, 0);
        return parserStateResult(before.char === "A" ? isBlank(after.char) : null, "RI inserts a blank row above the measured A marker", { before, after }, before.char === "A" ? undefined : "A marker was not measured before reverse index");
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 1, 5);
        if (refusal)
          return refusal;
        ctx.write("\x1B[1;5H");
        ctx.write("\x1BM");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor position does not measure reverse-index contents"
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.scroll-down", (ctx) => {
        ctx.feed(`LINE1\r
LINE2\r
LINE3`);
        const before = ctx.getCell(0, 0);
        ctx.feed("\x1B[T");
        const after = ctx.getCell(0, 0);
        return parserStateResult(before.char === "L" ? isBlank(after.char) : null, "SD inserts a blank row above the measured LINE marker", { before, after }, before.char === "L" ? undefined : "LINE marker was not measured before scroll down");
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 5, 5);
        if (refusal)
          return refusal;
        ctx.write("\x1B[5;5H");
        ctx.write("\x1B[1T");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor position does not measure scroll-down contents"
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.set-region", (ctx) => {
        ctx.feed("\x1B[5;10r");
        const cursor = ctx.getCursor();
        ctx.feed("\x1B[r");
        return parserStateResult(null, "DECSTBM constrains scrolling to the requested region", { cursor }, "Cursor position alone does not measure the scrolling region");
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 10, 1);
        if (refusal)
          return refusal;
        try {
          ctx.write("\x1B[5;10r");
          const pos = await ctx.queryCursorPosition();
          if (!pos) {
            return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
          }
          return {
            pass: false,
            response: JSON.stringify(pos),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Cursor position does not measure the scrolling region"
            }
          };
        } finally {
          ctx.write("\x1B[r");
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.alt-screen", (ctx) => {
        ctx.feed("NORMAL");
        ctx.feed("\x1B[?1049h");
        return parserStateResult(null, "Alt screen preserves normal scrollback", { mode: ctx.getMode("altScreen") }, "Mode metadata does not measure preserved scrollback");
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 1, 19);
        if (refusal)
          return refusal;
        ctx.write("\x1B[2J\x1B[H");
        ctx.write("MAIN_SCREEN_MARKER");
        const pos1 = await ctx.queryCursorPosition();
        if (!pos1) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        try {
          ctx.write("\x1B[?1049h");
          ctx.write("\x1B[2J\x1B[H");
          ctx.write("ALT_SCREEN");
        } finally {
          ctx.write("\x1B[?1049l");
        }
        const pos2 = await ctx.queryCursorPosition();
        if (!pos2) {
          return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
        }
        return {
          pass: false,
          response: JSON.stringify({ pos1, pos2 }),
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "query",
            note: "Cursor positions do not measure retained main-screen contents"
          }
        };
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.decstbm", (ctx) => {
        const rows = ctx.getScrollback().screenLines;
        if (!validSize2(rows, 10) || !validSize2(ctx.cols, 9)) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        ctx.feed(`FIXED_TOP\r
`);
        const before = ctx.getCell(0, 0);
        ctx.feed("\x1B[3;10r");
        try {
          ctx.feed("\x1B[3;1HINNER");
          const innerBefore = ctx.getCell(2, 0);
          ctx.feed(`\x1B[10;1HZ\r
`);
          const innerAfter = ctx.getCell(2, 0);
          const topAfter = ctx.getCell(0, 0);
          const state = { before, innerBefore, innerAfter, topAfter };
          const expected = "DECSTBM scrolls the inner marker while preserving FIXED_TOP outside the region";
          if (before.char !== "F" || innerBefore.char !== "I" || innerAfter.char === "I") {
            return parserStateResult(null, expected, state, "Top marker or inner scrolling control was not established");
          }
          return parserStateResult(topAfter.char === "F", expected, state);
        } finally {
          ctx.feed("\x1B[r");
        }
      }, async (ctx) => {
        const refusal = tooSmall2(ctx, 10, 10);
        if (refusal)
          return refusal;
        ctx.write("\x1B[2J\x1B[H");
        ctx.write(`FIXED_TOP\r
`);
        try {
          ctx.write("\x1B[3;10r");
          ctx.write("\x1B[3;1H");
          for (let i = 0;i < 20; i++)
            ctx.write(`scroll-${i}\r
`);
          const pos = await ctx.queryCursorPosition();
          if (!pos) {
            return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
          }
          return {
            pass: false,
            response: JSON.stringify(pos),
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "Cursor position does not measure whether FIXED_TOP survived scrolling"
            }
          };
        } finally {
          ctx.write("\x1B[r");
        }
      }),
      termNeedsGeometry: true
    },
    {
      ...probe("scrollback.decstbm-reset", (ctx) => {
        const baseline = ctx.getScrollback();
        const rows = baseline.screenLines;
        if (!validSize2(rows, 10) || !validSize2(ctx.cols, `line-${rows + 9}`.length)) {
          return {
            pass: false,
            observation: { outcome: "inconclusive", reason: "insufficient-evidence", evidence: "none" }
          };
        }
        ctx.feed("\x1B[5;10r");
        ctx.feed("\x1B[r");
        ctx.feed("\x1B[H");
        for (let i = 0;i < rows + 10; i++)
          ctx.feed(`line-${i}\r
`);
        const scroll = ctx.getScrollback();
        return parserStateResult(null, "Reset DECSTBM permits full-screen scrolling into history", { baseline, scroll }, "Scrollback growth does not prove the earlier region was active before reset");
      }, async (ctx) => {
        if (!validSize2(ctx.rows, 10) || !validSize2(ctx.cols, 1)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "DECSTBM fixture needs at least 10 rows"
            }
          };
        }
        try {
          ctx.write("\x1B[5;10r");
          ctx.write("\x1B[r");
          ctx.write("\x1B[H");
          ctx.write(`\x1B[${ctx.rows}B`);
          const pos = await ctx.queryCursorPosition();
          if (!pos) {
            return { pass: false, observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" } };
          }
          return {
            pass: false,
            response: `${pos.row};${pos.col}`,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "query",
              note: "CUD and cursor position do not measure scrollback after DECSTBM reset"
            }
          };
        } finally {
          ctx.write("\x1B[r");
        }
      }),
      termNeedsGeometry: true
    }
  ];
});

// ../probe-defs/src/charsets.ts
var charsetsProbes;
var init_charsets = __esm(() => {
  charsetsProbes = [
    {
      ...probe("charsets.dec-special", (ctx) => {
        const expected = "ASCII q controls flank DEC Special Graphics q mapped to U+2500";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 3) {
          return parserStateResult(null, expected, { cols: ctx.cols }, "Need at least three measured columns for charset controls");
        }
        try {
          ctx.feed("\x0F\x1B(B\x1B)B\x1B[1;1H\x1B[2Kqqq");
          const before = Array.from({ length: 3 }, (_, col) => ctx.getCell(0, col).char);
          if (before.join("") !== "qqq") {
            return parserStateResult(null, expected, { before }, "ASCII seed was not measured before DEC designation");
          }
          ctx.feed("\x1B[1;2H");
          const cursor = ctx.getCursor();
          const setup = [{ x: cursor.x, y: cursor.y }];
          if (cursor.x !== 1 || cursor.y !== 0) {
            return parserStateResult(null, expected, { before, setup }, "Target CUP did not reach DEC graphics cell");
          }
          ctx.feed("\x1B(0q\x1B(Bq");
          const after = Array.from({ length: 3 }, (_, col) => ctx.getCell(0, col).char);
          const controlsValid = after[0] === "q" && after[2] === "q";
          return parserStateResult(controlsValid ? after[1] === "\u2500" : null, expected, { before, setup, after }, controlsValid ? undefined : "ASCII flank control changed after DEC designation");
        } finally {
          ctx.feed("\x0F\x1B(B\x1B)B");
        }
      }, async (ctx) => {
        const capture = ctx.capture;
        if (capture) {
          const rows = ctx.rows;
          const cols = ctx.cols;
          if (!Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) || rows < 4 || cols < 6) {
            return {
              pass: false,
              observation: {
                outcome: "inconclusive",
                reason: "insufficient-evidence",
                evidence: "none",
                note: `Charset capture fixture needs at least 4x6, measured ${rows}x${cols}`
              }
            };
          }
          try {
            ctx.write("\x0F\x1B(B\x1B)B\x1B[0m");
            ctx.write("\x1B[1;1H     \x1B[1;1Hqqq");
            ctx.write("\x1B[2;1H     \x1B[2;1Hq\u2500q");
            ctx.write("\x1B[3;1H     \x1B[3;1Hqqq");
            ctx.write("\x1B[4;1H     \x1B[4;1Hqqq");
            ctx.write("\x1B[4;6H");
            const control = await capture({
              role: "control",
              label: "ASCII q controls on rows 1, 3 and 4; direct Unicode q\u2500q on row 2"
            });
            ctx.write("\x1B[3;2H\x1B(0q\x1B(Bq");
            ctx.write("\x0F\x1B(B\x1B)B\x1B[4;1Hqqq\x1B[4;6H");
            const target = await capture({
              role: "target",
              label: "DEC Special Graphics sample at row 3, column 2; restored ASCII qqq on row 4"
            });
            return {
              pass: false,
              response: JSON.stringify({
                rows,
                cols,
                sampleCell: { row: 3, col: 2 },
                control: control.label,
                target: target.label
              }),
              observation: {
                outcome: "inconclusive",
                reason: "insufficient-evidence",
                evidence: "pixels",
                screenshotRef: target.ref,
                frames: [control, target],
                note: "Sampled row 3, column 2 horizontal-line appearance relative to row 2 Unicode and ASCII q controls requires independent review; pixels do not measure a numeric codepoint or the whole charset"
              }
            };
          } finally {
            ctx.write("\x1B[0m\x0F\x1B(B\x1B)B");
          }
        }
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 2) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Charset fixture needs at least 1x2, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B(0");
        ctx.write("q");
        ctx.write("\x1B(B");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return {
            pass: false,
            note: "No cursor response",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          note: "Cursor movement does not verify charset glyph rendering or mapping",
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor movement does not verify charset glyph rendering or mapping"
          }
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("charsets.utf8", (ctx) => {
        const expected = "Sampled Unicode characters \xE9 and \u4E16 occupy their target cells with ASCII controls intact";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 5) {
          return parserStateResult(null, expected, { cols: ctx.cols }, "Need at least five measured columns for Unicode controls");
        }
        ctx.feed("\x1B[1;1H\x1B[2KAxy?Z");
        const before = Array.from({ length: 5 }, (_, col) => ctx.getCell(0, col).char);
        if (before.join("") !== "Axy?Z") {
          return parserStateResult(null, expected, { before }, "ASCII seed was not measured before Unicode samples");
        }
        ctx.feed("\x1B[1;2H");
        const first = ctx.getCursor();
        const setup = [{ x: first.x, y: first.y }];
        if (first.x !== 1 || first.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "First target CUP did not reach Unicode sample cell");
        }
        ctx.feed("\xE9");
        ctx.feed("\x1B[1;3H");
        const second = ctx.getCursor();
        setup.push({ x: second.x, y: second.y });
        if (second.x !== 2 || second.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "Second target CUP did not reach Unicode sample cell");
        }
        ctx.feed("\u4E16");
        const after = Array.from({ length: 5 }, (_, col) => ctx.getCell(0, col).char);
        const controlsValid = after[0] === "A" && after[4] === "Z";
        return parserStateResult(controlsValid ? after[1] === "\xE9" && after[2] === "\u4E16" : null, expected, { before, setup, after }, controlsValid ? undefined : "ASCII control changed after Unicode samples");
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 2) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Charset fixture needs at least 1x2, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\xE9");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return {
            pass: false,
            note: "No cursor response",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          note: "Cursor movement does not verify charset glyph rendering or mapping",
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor movement does not verify charset glyph rendering or mapping"
          }
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("charsets.g0-g1-switching", (ctx) => {
        const expected = "G0 ASCII l, SO-selected G1 DEC l\u2192U+250C, then SI-selected G0 ASCII l, within A/Z controls";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 5) {
          return parserStateResult(null, expected, { cols: ctx.cols }, "Need at least five measured columns for G0/G1 controls");
        }
        try {
          ctx.feed("\x0F\x1B(B\x1B)B\x1B[1;1H\x1B[2KAlllZ");
          const before = Array.from({ length: 5 }, (_, col) => ctx.getCell(0, col).char);
          if (before.join("") !== "AlllZ") {
            return parserStateResult(null, expected, { before }, "ASCII seed was not measured before G0/G1 switching");
          }
          ctx.feed("\x1B[1;2H");
          const cursor = ctx.getCursor();
          const setup = [{ x: cursor.x, y: cursor.y }];
          if (cursor.x !== 1 || cursor.y !== 0) {
            return parserStateResult(null, expected, { before, setup }, "Target CUP did not reach G0/G1 switching cells");
          }
          ctx.feed("\x1B(B\x1B)0l\x0El\x0Fl");
          const after = Array.from({ length: 5 }, (_, col) => ctx.getCell(0, col).char);
          const controlsValid = after[0] === "A" && after[4] === "Z";
          return parserStateResult(controlsValid ? after[1] === "l" && after[2] === "\u250C" && after[3] === "l" : null, expected, { before, setup, after }, controlsValid ? undefined : "ASCII A/Z control changed after G0/G1 switching");
        } finally {
          ctx.feed("\x0F\x1B(B\x1B)B");
        }
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 2) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Charset fixture needs at least 1x2, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B(0");
        ctx.write("l");
        ctx.write("\x1B(B");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return {
            pass: false,
            note: "No cursor response",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          note: "Cursor movement does not verify charset glyph rendering or mapping",
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor movement does not verify charset glyph rendering or mapping"
          }
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("charsets.dec-line-drawing", (ctx) => {
        const expected = "DEC jklmqx map exactly to \u2518\u2510\u250C\u2514\u2500\u2502 while trailing ASCII j remains unchanged";
        if (!Number.isSafeInteger(ctx.cols) || ctx.cols < 7) {
          return parserStateResult(null, expected, { cols: ctx.cols }, "Need at least seven measured columns for line-drawing controls");
        }
        try {
          ctx.feed("\x0F\x1B(B\x1B)B\x1B[1;1H\x1B[2Kjklmqxj");
          const before = Array.from({ length: 7 }, (_, col) => ctx.getCell(0, col).char);
          if (before.join("") !== "jklmqxj") {
            return parserStateResult(null, expected, { before }, "ASCII seed was not measured before line drawing");
          }
          ctx.feed("\x1B[1;1H");
          const cursor = ctx.getCursor();
          const setup = [{ x: cursor.x, y: cursor.y }];
          if (cursor.x !== 0 || cursor.y !== 0) {
            return parserStateResult(null, expected, { before, setup }, "Target CUP did not reach line-drawing start cell");
          }
          ctx.feed("\x1B(0jklmqx\x1B(B");
          const after = Array.from({ length: 7 }, (_, col) => ctx.getCell(0, col).char);
          const controlsValid = after[6] === "j";
          return parserStateResult(controlsValid ? after.slice(0, 6).join("") === "\u2518\u2510\u250C\u2514\u2500\u2502" : null, expected, { before, setup, after }, controlsValid ? undefined : "Trailing ASCII j control changed after DEC line drawing");
        } finally {
          ctx.feed("\x0F\x1B(B\x1B)B");
        }
      }, async (ctx) => {
        if (!Number.isSafeInteger(ctx.rows) || !Number.isSafeInteger(ctx.cols) || ctx.rows < 1 || ctx.cols < 7) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Charset fixture needs at least 1x7, measured ${ctx.rows}x${ctx.cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2K");
        ctx.write("\x1B(0");
        ctx.write("jklmqx");
        ctx.write("\x1B(B");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return {
            pass: false,
            note: "No cursor response",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        return {
          pass: false,
          response: JSON.stringify(pos),
          note: "Cursor movement does not verify charset glyph rendering or mapping",
          observation: {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            evidence: "consumed",
            note: "Cursor movement does not verify charset glyph rendering or mapping"
          }
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    }
  ];
});

// ../probe-defs/src/unicode.ts
function validSize3(value, minimum) {
  return Number.isSafeInteger(value) && value >= minimum;
}
var unicodeProbes;
var init_unicode = __esm(() => {
  unicodeProbes = [
    {
      ...probe("unicode.east-asian-ambiguous", (ctx) => {
        const expected = "ASCII seed/control is preserved; ambiguous symbol advances one or two cells before X";
        if (!validSize3(ctx.cols, 4)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Need at least four columns for width controls"
            }
          };
        }
        ctx.feed("\x1B[1;1H\x1B[2KAQ");
        const before = Array.from({ length: 2 }, (_, col) => ctx.getCell(0, col).char);
        if (before.join("") !== "AQ") {
          return parserStateResult(null, expected, { before }, "ASCII seed was not measured before ambiguous sample");
        }
        ctx.feed("\x1B[1;1H");
        const cursor = ctx.getCursor();
        const setup = [{ x: cursor.x, y: cursor.y }];
        if (cursor.x !== 0 || cursor.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "Target CUP did not reach sample start");
        }
        ctx.feed("\u25CFX");
        const after = Array.from({ length: 4 }, (_, col) => ctx.getCell(0, col).char);
        const pass = after[1] === "X" || after[2] === "X";
        return parserStateResult(pass, expected, { before, setup, after });
      }, async (ctx) => {
        if (!validSize3(ctx.cols, 3)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Fixture needs at least 3 columns"
            }
          };
        }
        const width = await ctx.measureRenderedWidth("\u25CF");
        if (width === null) {
          return {
            pass: false,
            note: "Cannot measure width",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "behavior" }
          };
        }
        const pass = width === 1 || width === 2;
        return {
          pass,
          note: `width=${width} (ambiguous chars vary by terminal/locale)`,
          response: String(width),
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "behavior" },
          assertions: [{ kind: pass ? "positive" : "negative", expected: "width 1 or 2", observed: String(width) }]
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("unicode.grapheme-cursor", (ctx) => {
        if (!validSize3(ctx.cols, 3)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Need at least three measured columns"
            }
          };
        }
        const sample = "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67";
        ctx.feed("\x1B[1;1H\x1B[2KAB");
        const before = Array.from({ length: 2 }, (_, col) => ctx.getCell(0, col).char);
        if (before.join("") !== "AB") {
          return parserStateResult(null, "ZWJ sample occupies two cells", { before }, "ASCII seed was not measured");
        }
        ctx.feed("\x1B[1;1H");
        const setupCursor = ctx.getCursor();
        const setup = [{ x: setupCursor.x, y: setupCursor.y }];
        if (setupCursor.x !== 0 || setupCursor.y !== 0) {
          return parserStateResult(null, "ZWJ sample occupies two cells", { before, setup }, "Target CUP did not reach sample start");
        }
        ctx.feed(sample);
        const cursor = ctx.getCursor();
        const cell = ctx.getCell(0, 0);
        const pass = cursor.y === 0 && cursor.x === 2 && cell.wide && cell.char.length > 0;
        return parserStateResult(pass, "ZWJ sample occupies two cells", { before, setup, cursor, cell });
      }, async (ctx) => {
        if (!validSize3(ctx.cols, 3)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Fixture needs at least 3 columns"
            }
          };
        }
        const width = await ctx.measureRenderedWidth("\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67");
        if (width === null) {
          return {
            pass: false,
            note: "Cannot measure width",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "behavior" }
          };
        }
        return {
          pass: width === 2,
          note: width === 2 ? undefined : `width=${width}, expected 2`,
          response: String(width),
          observation: { outcome: width === 2 ? "supported" : "unsupported", evidence: "behavior" },
          assertions: [{ kind: width === 2 ? "positive" : "negative", expected: "2", observed: String(width) }]
        };
      }, "behavior"),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("unicode.wrap-boundary", (ctx) => {
        if (!validSize3(ctx.cols, 2) || !validSize3(ctx.getScrollback().screenLines, 2)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Need at least two columns and two screen rows"
            }
          };
        }
        const expected = "Wide CJK character wraps from final column to row 2 while ASCII control is preserved";
        ctx.feed("\x1B[1;1H\x1B[2J");
        ctx.feed("A".repeat(ctx.cols));
        const before = Array.from({ length: ctx.cols }, (_, col) => ctx.getCell(0, col).char);
        if (before.some((char) => char !== "A")) {
          return parserStateResult(null, expected, { before }, "ASCII row seed was not measured");
        }
        ctx.feed(`\x1B[1;${ctx.cols}H`);
        const cursor = ctx.getCursor();
        const setup = [{ x: cursor.x, y: cursor.y }];
        if (cursor.x !== ctx.cols - 1 || cursor.y !== 0) {
          return parserStateResult(null, expected, { before, setup }, "Target CUP did not reach final column");
        }
        ctx.feed("\u4E2D");
        const after = [ctx.getCell(0, ctx.cols - 1).char, ctx.getCell(1, 0).char];
        const control = ctx.getCell(0, 0).char;
        const pass = control === "A" && after[1] === "\u4E2D";
        return parserStateResult(pass, expected, { before, setup, control, after });
      }, async (ctx) => {
        const cols = ctx.cols;
        if (!validSize3(ctx.rows, 2) || !validSize3(cols, 2)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: `Wide-wrap fixture needs at least 2x2, measured ${ctx.rows}x${cols}`
            }
          };
        }
        ctx.write("\x1B[1;1H\x1B[2J");
        ctx.write("A".repeat(cols - 1));
        ctx.write("\u4E2D");
        const pos = await ctx.queryCursorPosition();
        if (!pos) {
          return {
            pass: false,
            note: "No cursor response",
            observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
          };
        }
        const pass = pos.row === 2;
        return {
          pass,
          response: JSON.stringify(pos),
          note: pass ? undefined : `cursor at row ${pos.row}, expected 2 (wide char should wrap)`,
          observation: { outcome: pass ? "supported" : "unsupported", evidence: "behavior" },
          assertions: [
            {
              kind: pass ? "positive" : "negative",
              expected: "cursor row 2 after wide wrap",
              observed: JSON.stringify(pos)
            }
          ]
        };
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    },
    {
      ...probe("unicode.tab-stops", (ctx) => {
        if (!validSize3(ctx.cols, 10)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Need at least ten measured columns"
            }
          };
        }
        try {
          ctx.feed("\x1B[3g\x1B[1;9H\x1BH\x1B[1;1H\x1B[2K");
          ctx.feed("AB");
          const before = Array.from({ length: 2 }, (_, col) => ctx.getCell(0, col).char);
          if (before.join("") !== "AB") {
            return parserStateResult(null, "A at column 1; B after tab at configured column 9", { before }, "ASCII seed was not measured");
          }
          ctx.feed("\x1B[1;1H");
          const cursor = ctx.getCursor();
          const setup = [{ x: cursor.x, y: cursor.y }];
          if (cursor.x !== 0 || cursor.y !== 0) {
            return parserStateResult(null, "A at column 1; B after tab at configured column 9", { before, setup }, "Target CUP did not reach tab sample start");
          }
          ctx.feed("A\tB");
          const after = Array.from({ length: 10 }, (_, col) => ctx.getCell(0, col).char);
          return parserStateResult(after[8] === "B", "A at column 1; B after tab at configured column 9", {
            before,
            setup,
            after
          });
        } finally {
          let restore = "\x1B[3g";
          for (let col = 9;col <= ctx.cols; col += 8)
            restore += `\x1B[1;${col}H\x1BH`;
          ctx.feed(restore + "\x1B[1;1H");
        }
      }, async (ctx) => {
        if (!validSize3(ctx.cols, 10)) {
          return {
            pass: false,
            observation: {
              outcome: "inconclusive",
              reason: "insufficient-evidence",
              evidence: "none",
              note: "Fixture needs at least 10 columns"
            }
          };
        }
        try {
          ctx.write("\x1B[3g\x1B[1;9H\x1BH\x1B[1;1H\x1B[2K");
          ctx.write("A\tB");
          const pos = await ctx.queryCursorPosition();
          if (!pos) {
            return {
              pass: false,
              note: "No cursor response",
              observation: { outcome: "inconclusive", reason: "no-response", evidence: "query" }
            };
          }
          const pass = pos.col === 10;
          return {
            pass,
            response: JSON.stringify(pos),
            note: pass ? undefined : `cursor at col ${pos.col}, expected 10 (A + tab to 9 + B)`,
            observation: { outcome: pass ? "supported" : "unsupported", evidence: "behavior" },
            assertions: [
              {
                kind: pass ? "positive" : "negative",
                expected: "cursor column 10 after tab",
                observed: JSON.stringify(pos)
              }
            ]
          };
        } finally {
          let restore = "\x1B[3g";
          for (let col = 9;col <= ctx.cols; col += 8)
            restore += `\x1B[1;${col}H\x1BH`;
          ctx.write(restore + "\x1B[1;1H");
        }
      }),
      termNeedsGeometry: true,
      termlessObservationEvidence: "parser-state"
    }
  ];
});

// ../probe-defs/src/index.ts
var clipboardProbes, ALL_PROBES;
var init_src = __esm(() => {
  init_types();
  init_sgr();
  init_cursor();
  init_text();
  init_erase();
  init_editing();
  init_modes();
  init_device();
  init_extensions();
  init_input();
  init_reset();
  init_scrollback();
  init_charsets();
  init_unicode();
  clipboardProbes = extensionsProbes.filter((probe) => probe.id.startsWith("extensions.osc52-"));
  ALL_PROBES = [
    ...extensionsProbes.filter((probe) => !probe.id.startsWith("extensions.osc52-")),
    ...sgrProbes,
    ...cursorProbes,
    ...textProbes,
    ...eraseProbes,
    ...editingProbes,
    ...modesProbes,
    ...deviceProbes,
    ...inputProbes,
    ...resetProbes,
    ...scrollbackProbes,
    ...charsetsProbes,
    ...unicodeProbes,
    ...clipboardProbes
  ];
});

// ../run-parser/src/index.ts
import { createHash } from "crypto";
function fail(path, message) {
  throw new Error(`${path}: ${message}`);
}
function rejectDuplicateKeys(source, path) {
  let i = 0;
  const ws = () => {
    while (/\s/.test(source[i] ?? ""))
      i++;
  };
  const quoted = () => {
    const start = i++;
    while (i < source.length) {
      if (source[i] === "\\") {
        i += 2;
        continue;
      }
      if (source[i++] === '"')
        break;
    }
    return JSON.parse(source.slice(start, i));
  };
  const value = () => {
    ws();
    if (source[i] === "{") {
      i++;
      const keys = new Set;
      ws();
      while (source[i] !== "}") {
        const key = quoted();
        if (keys.has(key))
          fail(path, `duplicate key ${key}`);
        keys.add(key);
        ws();
        i++;
        value();
        ws();
        if (source[i] === ",") {
          i++;
          ws();
        } else
          break;
      }
      i++;
    } else if (source[i] === "[") {
      i++;
      ws();
      while (source[i] !== "]") {
        value();
        ws();
        if (source[i] === ",") {
          i++;
          ws();
        } else
          break;
      }
      i++;
    } else if (source[i] === '"') {
      quoted();
    } else {
      while (i < source.length && !/[\s,}\]]/.test(source.charAt(i)))
        i++;
    }
  };
  value();
}
function parseJsonStrict(path, source) {
  let parsed;
  try {
    parsed = JSON.parse(source);
  } catch (error) {
    fail(path, `invalid JSON: ${String(error)}`);
  }
  rejectDuplicateKeys(source, path);
  return parsed;
}
function parseTarget(value, path) {
  if (!object(value))
    fail(path, "missing target");
  if (!["app", "headless", "mux"].includes(String(value.kind)))
    fail(path, "invalid target.kind");
  return {
    kind: value.kind,
    id: asString(value.id, path, "target.id"),
    version: asString(value.version, path, "target.version"),
    os: nullableString(value.os, path, "target.os"),
    osVersion: nullableString(value.osVersion, path, "target.osVersion"),
    outerTerminal: nullableString(value.outerTerminal, path, "target.outerTerminal"),
    mux: nullableString(value.mux, path, "target.mux"),
    config: nullableString(value.config, path, "target.config"),
    permissions: nullableString(value.permissions, path, "target.permissions")
  };
}
function parseRuntimeIdentity(value, target, path) {
  if (target.kind !== "headless") {
    if (value !== undefined)
      fail(path, "runtimeIdentity is only valid for headless targets");
    return;
  }
  if (!object(value) || !["js", "native"].includes(String(value.kind)))
    fail(path, "missing headless runtimeIdentity");
  const engineVersion = asString(value.engineVersion, path, "runtimeIdentity.engineVersion");
  if (engineVersion !== target.version) {
    fail(path, `runtimeIdentity.engineVersion ${engineVersion} conflicts with target.version ${target.version}`);
  }
  const adapterVersion = asString(value.adapterVersion, path, "runtimeIdentity.adapterVersion");
  const termlessRevision = asString(value.termlessRevision, path, "runtimeIdentity.termlessRevision");
  const sha256 = (digest, field) => {
    const parsed = asString(digest, path, field);
    if (!/^[0-9a-f]{64}$/.test(parsed))
      fail(path, `${field} must be SHA256`);
    return parsed;
  };
  const loadedBinary = (binary) => {
    if (!object(binary))
      fail(path, "runtimeIdentity.loadedBinary is missing");
    return {
      path: asString(binary.path, path, "runtimeIdentity.loadedBinary.path"),
      sha256: sha256(binary.sha256, "runtimeIdentity.loadedBinary.sha256")
    };
  };
  const cleanTree = (value) => {
    if (typeof value !== "boolean")
      fail(path, "runtimeIdentity.integrity.cleanTree must be boolean");
    return value;
  };
  if (value.kind === "js") {
    if (!object(value.integrity))
      fail(path, "runtimeIdentity.integrity is missing");
    const integrity = value.integrity.kind === "registry" ? {
      kind: "registry",
      lockIntegrity: asString(value.integrity.lockIntegrity, path, "runtimeIdentity.integrity.lockIntegrity")
    } : value.integrity.kind === "source" ? {
      kind: "source",
      repository: asString(value.integrity.repository, path, "runtimeIdentity.integrity.repository"),
      revision: asString(value.integrity.revision, path, "runtimeIdentity.integrity.revision"),
      treeOid: asString(value.integrity.treeOid, path, "runtimeIdentity.integrity.treeOid"),
      cleanTree: cleanTree(value.integrity.cleanTree)
    } : fail(path, "runtimeIdentity.integrity.kind must be registry or source");
    if (integrity.kind === "source") {
      if (!/^[0-9a-f]{40}$/.test(integrity.revision) || !/^[0-9a-f]{40}$/.test(integrity.treeOid) || typeof integrity.cleanTree !== "boolean") {
        fail(path, "runtimeIdentity source integrity has invalid revision, treeOid, or cleanTree");
      }
    }
    const runtimeFormat = value.runtimeFormat;
    if (runtimeFormat !== "js" && runtimeFormat !== "wasm") {
      fail(path, "runtimeIdentity.runtimeFormat must be js or wasm");
    }
    const common = {
      kind: "js",
      engineVersion,
      resolvedPath: asString(value.resolvedPath, path, "runtimeIdentity.resolvedPath"),
      integrity,
      adapterVersion,
      termlessRevision
    };
    if (runtimeFormat === "wasm")
      return { ...common, runtimeFormat, loadedBinary: loadedBinary(value.loadedBinary) };
    if (value.loadedBinary !== undefined)
      fail(path, "pure JS runtimeIdentity cannot claim loadedBinary");
    return {
      ...common,
      runtimeFormat
    };
  }
  const binary = loadedBinary(value.loadedBinary);
  if (!object(value.provenance))
    fail(path, "runtimeIdentity.provenance is missing");
  const provenance = {
    sha256: sha256(value.provenance.sha256, "runtimeIdentity.provenance.sha256"),
    sourceCommit: asString(value.provenance.sourceCommit, path, "runtimeIdentity.provenance.sourceCommit"),
    buildHash: sha256(value.provenance.buildHash, "runtimeIdentity.provenance.buildHash"),
    toolchain: asString(value.provenance.toolchain, path, "runtimeIdentity.provenance.toolchain"),
    lockSha256: sha256(value.provenance.lockSha256, "runtimeIdentity.provenance.lockSha256")
  };
  if (provenance.sha256 !== binary.sha256)
    fail(path, "native sidecar SHA256 differs from loaded binary");
  return {
    kind: "native",
    engineVersion,
    loadedBinary: binary,
    provenance,
    adapterVersion,
    termlessRevision
  };
}
function parseObservationFrames(value, path, featureId, screenshotRefs, primaryRef, evidence) {
  if (value === undefined)
    return;
  if (evidence !== "pixels" || !Array.isArray(value) || value.length < 2) {
    fail(path, `invalid frames for ${featureId}; pixels require control and target`);
  }
  const frames = value.map((entry, index) => {
    if (!object(entry) || !["control", "target"].includes(String(entry.role))) {
      fail(path, `invalid frame role ${index} for ${featureId}`);
    }
    const ref = asString(entry.ref, path, `frame ${index} ref for ${featureId}`);
    if (!screenshotDigest(ref))
      fail(path, `invalid frame ref ${index} for ${featureId}`);
    if (!screenshotRefs.includes(ref))
      fail(path, `frame ${ref} is absent from run`);
    if (typeof entry.capturedAt !== "number" || !Number.isFinite(entry.capturedAt) || entry.capturedAt < 0) {
      fail(path, `invalid frame capturedAt ${index} for ${featureId}`);
    }
    const label = asString(entry.label, path, `frame ${index} label for ${featureId}`);
    const sourceRef = entry.sourceRef;
    if (sourceRef !== undefined && !screenshotDigest(sourceRef)) {
      fail(path, `invalid frame sourceRef ${index} for ${featureId}`);
    }
    return {
      role: entry.role,
      ref,
      capturedAt: entry.capturedAt,
      label,
      ...sourceRef && { sourceRef }
    };
  });
  const targets = frames.filter((frame) => frame.role === "target");
  if (!frames.some((frame) => frame.role === "control") || targets.length === 0) {
    fail(path, `frames for ${featureId} require control and target`);
  }
  if (!primaryRef || !targets.some((frame) => frame.ref === primaryRef)) {
    fail(path, `primary screenshotRef for ${featureId} must be a target frame`);
  }
  let priorTargetAt = -1;
  for (const targetFrame of targets) {
    if (targetFrame.capturedAt <= priorTargetAt) {
      fail(path, `target frames for ${featureId} require strictly increasing capturedAt`);
    }
    priorTargetAt = targetFrame.capturedAt;
  }
  return frames;
}
function parseObservation(value, path, catalog, rawReplies, assertions, screenshotRefs) {
  if (!object(value))
    fail(path, "invalid observation");
  const featureId = asString(value.featureId, path, "observation.featureId");
  if (!catalog.has(featureId))
    fail(path, `unknown feature ${featureId}`);
  validateObservationOutcome(value, path, featureId);
  if (value.evidence === "none" && value.screenshotRef !== undefined) {
    fail(path, `none evidence for ${featureId} cannot carry screenshotRef`);
  }
  if (value.evidence === "none" && value.frames !== undefined) {
    fail(path, `none evidence for ${featureId} cannot carry frames`);
  }
  if (value.evidence === "pixels" && (value.outcome === "supported" || value.outcome === "unsupported")) {
    fail(path, `collector pixels for ${featureId} must remain inconclusive until reviewed Interpretation`);
  }
  const rawReplyRef = value.rawReplyRef === undefined ? undefined : asString(value.rawReplyRef, path, `rawReplyRef for ${featureId}`);
  if (rawReplyRef && !Object.hasOwn(rawReplies, rawReplyRef)) {
    fail(path, `missing raw reply ${rawReplyRef} for ${featureId}`);
  }
  const screenshotRef = value.screenshotRef === undefined ? undefined : asString(value.screenshotRef, path, `screenshotRef for ${featureId}`);
  if (value.evidence === "pixels" && value.outcome !== "error" && !screenshotRef) {
    fail(path, `pixels observation ${featureId} requires screenshotRef`);
  }
  if (screenshotRef && !screenshotRefs.includes(screenshotRef)) {
    fail(path, `screenshotRef ${screenshotRef} is absent from run`);
  }
  const frames = parseObservationFrames(value.frames, path, featureId, screenshotRefs, screenshotRef, value.evidence);
  const observation = {
    featureId,
    outcome: value.outcome,
    evidence: value.evidence
  };
  if (value.reason !== undefined)
    observation.reason = value.reason;
  if (rawReplyRef)
    observation.rawReplyRef = rawReplyRef;
  if (screenshotRef)
    observation.screenshotRef = screenshotRef;
  if (frames)
    observation.frames = frames;
  if (value.note !== undefined)
    observation.note = asString(value.note, path, `note for ${featureId}`);
  validateObservation(observation, path, rawReplies, assertions);
  return observation;
}
function validateObservation(observation, path, rawReplies, assertions) {
  const { featureId, evidence, outcome, rawReplyRef } = observation;
  if (rawReplyRef && !Object.hasOwn(rawReplies, rawReplyRef)) {
    fail(path, `missing raw reply ${rawReplyRef} for ${featureId}`);
  }
  if ((outcome === "supported" || outcome === "unsupported") && isNonMeasuringEvidence(evidence)) {
    fail(path, `conclusive ${featureId} cannot use ${evidence} evidence`);
  }
  if (evidence === "none") {
    if (outcome !== "inconclusive" || observation.reason !== "policy-refused" && observation.reason !== "insufficient-evidence") {
      fail(path, `none evidence for ${featureId} requires inconclusive policy-refused or insufficient-evidence outcome`);
    }
    if (observation.screenshotRef !== undefined || observation.frames !== undefined) {
      fail(path, `none evidence for ${featureId} cannot carry screenshotRef or frames`);
    }
    if (!rawReplyRef || rawReplyRef !== featureId) {
      fail(path, `none evidence for ${featureId} requires its own rawReplyRef`);
    }
    const rawTrace = rawReplies[rawReplyRef];
    if (typeof rawTrace !== "string")
      fail(path, `none evidence for ${featureId} requires its own raw trace`);
    const trace = parseJsonStrict(`${path}: ${featureId} none trace`, rawTrace);
    if (!object(trace) || Object.keys(trace).sort().join(",") !== "events,queries,writes" || !Array.isArray(trace.writes) || trace.writes.length !== 0 || !Array.isArray(trace.queries) || trace.queries.length !== 0 || !Array.isArray(trace.events) || trace.events.length !== 0 || assertions.some((entry) => entry.featureId === featureId)) {
      fail(path, `none evidence for ${featureId} requires a zero-byte trace without assertions`);
    }
  }
  if (outcome !== "supported" && outcome !== "unsupported")
    return;
  if (evidence === "pixels")
    return;
  const kind = outcome === "supported" ? "positive" : "negative";
  const assertion = assertions.find((entry) => entry.featureId === featureId && entry.kind === kind && nonempty(rawReplyRef) && entry.rawReplyRef === rawReplyRef);
  if (!assertion)
    fail(path, `${featureId} lacks bound ${kind} assertion`);
  if (!nonempty(assertion.expected) || !nonempty(assertion.observed)) {
    fail(path, `${featureId} assertion requires expected and observed evidence`);
  }
  if (evidence === "parser-state" || evidence === "interaction") {
    const state = parseJsonStrict(`${path}: ${featureId} state snapshot`, assertion.observed);
    if (!object(state) || Object.keys(state).length === 0)
      fail(path, `${featureId} requires an actual state snapshot`);
    if (evidence === "interaction" && !nonempty(assertion.action)) {
      fail(path, `${featureId} requires the performed action`);
    }
  }
}
function parseDiagnostics(value, path, catalog, observations) {
  if (value === undefined)
    return {};
  if (!object(value))
    fail(path, "invalid ungradedDiagnostics");
  const diagnostics = {};
  for (const [id, entry] of Object.entries(value)) {
    if (!catalog.has(id))
      fail(path, `unknown diagnostic feature ${id}`);
    if (observations.some((observation) => observation.featureId === id)) {
      fail(path, `${id} occurs in both observations and ungradedDiagnostics`);
    }
    if (!object(entry))
      fail(path, `invalid diagnostic for ${id}`);
    const allowed = entry.kind === "legacy-callback" ? ["kind", "pass", "note", "response"] : ["kind", "name", "message"];
    if (Object.keys(entry).some((key) => !allowed.includes(key)))
      fail(path, `invalid diagnostic fields for ${id}`);
    if (entry.kind === "legacy-callback" && typeof entry.pass === "boolean") {
      for (const key of ["note", "response"]) {
        if (entry[key] !== undefined && typeof entry[key] !== "string") {
          fail(path, `invalid diagnostic ${key} for ${id}`);
        }
      }
    } else if (entry.kind === "collector-error" && nonempty(entry.name)) {
      if (entry.message !== undefined && typeof entry.message !== "string") {
        fail(path, `invalid diagnostic message for ${id}`);
      }
    } else
      fail(path, `invalid diagnostic for ${id}`);
    diagnostics[id] = entry;
  }
  return diagnostics;
}
function validateObservationOutcome(value, path, featureId) {
  if (!OBSERVATION_OUTCOMES.includes(value.outcome)) {
    fail(path, `invalid outcome for ${featureId}`);
  }
  if (!OBSERVATION_EVIDENCE.includes(value.evidence)) {
    fail(path, `invalid evidence for ${featureId}`);
  }
  if (value.reason !== undefined && !OBSERVATION_REASONS.includes(value.reason)) {
    fail(path, `invalid reason for ${featureId}`);
  }
  if (value.reason === "insufficient-evidence" && value.outcome !== "inconclusive") {
    fail(path, `insufficient-evidence requires inconclusive outcome for ${featureId}`);
  }
  if ((value.outcome === "error" || value.outcome === "inconclusive") && !value.reason) {
    fail(path, `missing reason for ${featureId}`);
  }
  if ((value.outcome === "supported" || value.outcome === "unsupported") && value.reason) {
    fail(path, `conclusive ${featureId} cannot have an unknown-cause reason`);
  }
}
function parseAppLaunchReceipt(value, originKind, targetKind, path) {
  if (value === undefined)
    return;
  if (originKind !== "collector" || targetKind !== "app" || !object(value)) {
    fail(path, "appLaunch requires an app collector run");
  }
  const bundlePath = asString(value.bundlePath, path, "appLaunch.bundlePath");
  const cfBundleShortVersionString = asString(value.cfBundleShortVersionString, path, "appLaunch.cfBundleShortVersionString");
  const cfBundleVersion = asString(value.cfBundleVersion, path, "appLaunch.cfBundleVersion");
  const executablePath = asString(value.executablePath, path, "appLaunch.executablePath");
  if (!bundlePath.startsWith("/") || !executablePath.startsWith("/")) {
    fail(path, "appLaunch bundle and executable paths must be absolute");
  }
  if (!/^[a-f0-9]{64}$/.test(String(value.executableSha256))) {
    fail(path, "invalid appLaunch.executableSha256");
  }
  if (!object(value.sourceArtifact))
    fail(path, "missing appLaunch.sourceArtifact");
  let sourceArtifact;
  if (value.sourceArtifact.kind === "sealed-macos-system-volume") {
    if (Object.keys(value.sourceArtifact).sort().join(",") !== "codeSignature,kind,macOSBuild,sealed,snapshotName,snapshotUUID") {
      fail(path, "invalid sealed appLaunch.sourceArtifact fields");
    }
    const macOSBuild = asString(value.sourceArtifact.macOSBuild, path, "appLaunch.sourceArtifact.macOSBuild");
    const snapshotUUID = asString(value.sourceArtifact.snapshotUUID, path, "appLaunch.sourceArtifact.snapshotUUID");
    const snapshotName = asString(value.sourceArtifact.snapshotName, path, "appLaunch.sourceArtifact.snapshotName");
    if (!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(snapshotUUID)) {
      fail(path, "invalid appLaunch.sourceArtifact.snapshotUUID");
    }
    if (value.sourceArtifact.sealed !== true)
      fail(path, "appLaunch.sourceArtifact.sealed must be true");
    if (!object(value.sourceArtifact.codeSignature))
      fail(path, "missing appLaunch.sourceArtifact.codeSignature");
    const identifier = asString(value.sourceArtifact.codeSignature.identifier, path, "appLaunch.codeSignature.identifier");
    const cdHash = asString(value.sourceArtifact.codeSignature.cdHash, path, "appLaunch.codeSignature.cdHash");
    if (!/^[a-f0-9]{40}$/.test(cdHash))
      fail(path, "invalid appLaunch.sourceArtifact.codeSignature.cdHash");
    if (value.sourceArtifact.codeSignature.strictVerified !== true) {
      fail(path, "appLaunch.sourceArtifact.codeSignature.strictVerified must be true");
    }
    sourceArtifact = {
      kind: "sealed-macos-system-volume",
      macOSBuild,
      snapshotUUID,
      snapshotName,
      sealed: true,
      codeSignature: { identifier, cdHash, strictVerified: true }
    };
  } else if (value.sourceArtifact.kind === undefined) {
    const sourcePath = asString(value.sourceArtifact.path, path, "appLaunch.sourceArtifact.path");
    if (!sourcePath.startsWith("/") || !/^[a-f0-9]{64}$/.test(String(value.sourceArtifact.sha256))) {
      fail(path, "invalid appLaunch.sourceArtifact");
    }
    sourceArtifact = { path: sourcePath, sha256: value.sourceArtifact.sha256 };
  } else {
    fail(path, "unknown appLaunch.sourceArtifact kind");
  }
  return {
    bundlePath,
    cfBundleShortVersionString,
    cfBundleVersion,
    executablePath,
    executableSha256: value.executableSha256,
    sourceArtifact
  };
}
function parseRunProvenance(value, target, expected, path) {
  if (value === undefined)
    return;
  if (target.kind !== "app")
    fail(path, "native provenance requires an app target");
  if (!object(value) || !object(value.executable) || !object(value.sourceArtifact) || !object(value.runtime) || !object(value.fixture)) {
    fail(path, "invalid native provenance blocks");
  }
  const digest = (input, field) => {
    const parsed = asString(input, path, field);
    if (!/^[a-f0-9]{64}$/.test(parsed))
      fail(path, `invalid ${field} SHA256`);
    return parsed;
  };
  const executablePath = asString(value.executable.path, path, "provenance.executable.path");
  if (!executablePath.startsWith("/"))
    fail(path, "provenance.executable.path must be absolute");
  const version = asString(value.executable.version, path, "provenance.executable.version");
  const versionTokens = version.match(/(?<![A-Za-z0-9.])\d+(?:\.\d+){1,3}(?:[-+][A-Za-z0-9.-]+)?(?![A-Za-z0-9.])/g);
  if (versionTokens?.length !== 1 || versionTokens[0] !== target.version) {
    fail(path, `provenance.executable.version differs from target.version ${target.version}`);
  }
  const sourceUrl = asString(value.sourceArtifact.url, path, "provenance.sourceArtifact.url");
  let parsedUrl;
  try {
    parsedUrl = new URL(sourceUrl);
  } catch {
    fail(path, "invalid provenance.sourceArtifact.url");
  }
  if (parsedUrl.protocol !== "https:")
    fail(path, "provenance.sourceArtifact.url must use HTTPS");
  const imageId = asString(value.runtime.imageId, path, "provenance.runtime.imageId");
  if (!/^sha256:[a-f0-9]{64}$/.test(imageId))
    fail(path, "invalid provenance.runtime.imageId");
  const nixLockRevision = asString(value.runtime.nixLockRevision, path, "provenance.runtime.nixLockRevision");
  if (!/^[a-f0-9]{40}$/.test(nixLockRevision))
    fail(path, "invalid provenance.runtime.nixLockRevision");
  const sourceRevision = asString(value.runtime.sourceRevision, path, "provenance.runtime.sourceRevision");
  if (!/^[a-f0-9]{40}$/.test(sourceRevision) || sourceRevision !== expected.sourceRevision) {
    fail(path, "provenance.runtime.sourceRevision differs from run sourceRevision");
  }
  const suiteHash = asString(value.runtime.suiteHash, path, "provenance.runtime.suiteHash");
  if (suiteHash !== expected.probeHash)
    fail(path, "provenance.runtime.suiteHash differs from run probeHash");
  if (typeof value.runtime.cleanTree !== "boolean")
    fail(path, "provenance.runtime.cleanTree must be boolean");
  return {
    executable: {
      path: executablePath,
      sha256: digest(value.executable.sha256, "provenance.executable.sha256"),
      version
    },
    sourceArtifact: { url: sourceUrl, sha256: digest(value.sourceArtifact.sha256, "provenance.sourceArtifact.sha256") },
    runtime: {
      imageId,
      imageTarSha256: digest(value.runtime.imageTarSha256, "provenance.runtime.imageTarSha256"),
      arch: asString(value.runtime.arch, path, "provenance.runtime.arch"),
      nixLockRevision,
      sourceRevision,
      cleanTree: value.runtime.cleanTree,
      suiteHash
    },
    fixture: {
      definition: asString(value.fixture.definition, path, "provenance.fixture.definition"),
      config: asString(value.fixture.config, path, "provenance.fixture.config"),
      font: asString(value.fixture.font, path, "provenance.fixture.font"),
      geometry: asString(value.fixture.geometry, path, "provenance.fixture.geometry"),
      display: asString(value.fixture.display, path, "provenance.fixture.display"),
      gl: asString(value.fixture.gl, path, "provenance.fixture.gl")
    }
  };
}
function parseNotTested(value, path, catalog, expected, rawReplies, observations, assertions) {
  if (value === undefined)
    return [];
  if (!Array.isArray(value))
    fail(path, "invalid notTested");
  const records = [];
  const seen = new Set;
  for (const entry of value) {
    if (!object(entry))
      fail(path, "invalid notTested record");
    const featureId = asString(entry.featureId, path, "notTested.featureId");
    if (!catalog.has(featureId))
      fail(path, `unknown notTested feature ${featureId}`);
    if (!expected.has(featureId))
      fail(path, `notTested ${featureId} is outside the trusted suite`);
    if (seen.has(featureId))
      fail(path, `duplicate notTested feature ${featureId}`);
    seen.add(featureId);
    if (entry.reason !== "no-semantic-observable")
      fail(path, `invalid notTested reason for ${featureId}`);
    const noObservable = asString(entry.noObservable, path, `notTested.noObservable for ${featureId}`);
    if (noObservable.trim().length === 0)
      fail(path, `notTested ${featureId} requires a specific noObservable`);
    const rawReplyRef = asString(entry.rawReplyRef, path, `notTested.rawReplyRef for ${featureId}`);
    if (rawReplyRef !== featureId) {
      fail(path, `notTested ${featureId} requires its own rawReplyRef`);
    }
    const rawTrace = rawReplies[rawReplyRef];
    if (typeof rawTrace !== "string" || rawTrace.length === 0) {
      fail(path, `notTested ${featureId} requires a retained nonempty raw trace`);
    }
    if (entry.probeId !== undefined) {
      const probeId = asString(entry.probeId, path, `notTested.probeId for ${featureId}`);
      if (probeId !== featureId)
        fail(path, `notTested probeId ${probeId} does not identify ${featureId}`);
    }
    if (observations.some((item) => item.featureId === featureId)) {
      fail(path, `notTested ${featureId} also occurs in observations`);
    }
    if (assertions.some((item) => item.featureId === featureId)) {
      fail(path, `notTested ${featureId} also occurs in assertions`);
    }
    records.push({ featureId, reason: "no-semantic-observable", noObservable, rawReplyRef });
  }
  return records;
}
function parseRun(path, source, catalogIds, suites = new Map) {
  const raw = parseJsonStrict(path, source);
  if (!object(raw))
    fail(path, "run must be an object");
  if (raw.schemaVersion !== undefined && raw.schemaVersion !== 2) {
    fail(path, `unsupported schemaVersion ${String(raw.schemaVersion)}`);
  }
  const catalog = new Set(catalogIds);
  const sha256 = createHash("sha256").update(source).digest("hex");
  if (raw.schemaVersion === 2) {
    if (Object.hasOwn(raw, "results"))
      fail(path, "v2 run cannot contain legacy boolean results");
    const target = parseTarget(raw.target, path);
    const runtimeIdentity = parseRuntimeIdentity(raw.runtimeIdentity, target, path);
    const runId = asString(raw.runId, path, "runId");
    if (!["verified", "unverified", "disputed"].includes(String(raw.identity)))
      fail(path, "invalid identity");
    if (!object(raw.origin) || !["collector", "community-issue", "manual-capture"].includes(String(raw.origin.kind))) {
      fail(path, "invalid origin");
    }
    const appLaunch = parseAppLaunchReceipt(raw.origin.appLaunch, raw.origin.kind, target.kind, path);
    if (!object(raw.rawReplies) || !Object.values(raw.rawReplies).every((v) => typeof v === "string")) {
      fail(path, "invalid rawReplies");
    }
    if (!Array.isArray(raw.assertions) || !Array.isArray(raw.screenshotRefs) || !raw.screenshotRefs.every(screenshotDigest)) {
      fail(path, "invalid assertions or screenshotRefs");
    }
    const assertions = raw.assertions;
    for (const assertion of assertions) {
      if (!object(assertion) || !catalog.has(assertion.featureId) || !["positive", "negative"].includes(assertion.kind)) {
        fail(path, "invalid assertion");
      }
      if (assertion.rawReplyRef && !Object.hasOwn(raw.rawReplies, assertion.rawReplyRef)) {
        fail(path, `missing assertion raw reply ${assertion.rawReplyRef}`);
      }
    }
    if (!Array.isArray(raw.observations))
      fail(path, "missing observations");
    const observations = raw.observations.map((v) => parseObservation(v, path, catalog, raw.rawReplies, assertions, raw.screenshotRefs));
    if (new Set(observations.map((v) => v.featureId)).size !== observations.length) {
      fail(path, "duplicate observation feature ID");
    }
    if (raw.suiteComplete !== true && raw.suiteComplete !== false)
      fail(path, "missing suiteComplete");
    const probeHash = asString(raw.probeHash, path, "probeHash");
    const sourceRevision = asString(raw.sourceRevision, path, "sourceRevision");
    const provenance = parseRunProvenance(raw.provenance, target, { probeHash, sourceRevision }, path);
    const manifest = suites.get(probeHash);
    if (!manifest || manifest.probeHash !== probeHash) {
      fail(path, `unknown suite ${probeHash}; missing trusted manifest`);
    }
    const expected = new Set(manifest.probes[target.kind]);
    for (const assertion of assertions) {
      if (!expected.has(assertion.featureId)) {
        fail(path, `assertion ${assertion.featureId} is outside suite ${probeHash} for ${target.kind}`);
      }
    }
    for (const observation of observations) {
      if (!expected.has(observation.featureId)) {
        fail(path, `${observation.featureId} is outside suite ${probeHash} for ${target.kind}`);
      }
    }
    const notTested = parseNotTested(raw.notTested, path, catalog, expected, raw.rawReplies, observations, assertions);
    const suiteComplete = observations.length + notTested.length === expected.size;
    if (raw.suiteComplete !== suiteComplete) {
      fail(path, `suiteComplete disagrees with observed and not-tested membership (${observations.length} measured + ${notTested.length} not tested of ${expected.size} probes)`);
    }
    const ungradedDiagnostics = parseDiagnostics(raw.ungradedDiagnostics, path, catalog, observations);
    for (const id of Object.keys(ungradedDiagnostics)) {
      if (!expected.has(id))
        fail(path, `diagnostic ${id} is outside suite ${probeHash} for ${target.kind}`);
      if (notTested.some((item) => item.featureId === id)) {
        fail(path, `diagnostic ${id} also occurs in notTested`);
      }
    }
    if (!date(raw.measuredAt))
      fail(path, "invalid measuredAt");
    return {
      path,
      sha256,
      schemaVersion: 2,
      runId,
      target,
      identity: raw.identity,
      ...runtimeIdentity && { runtimeIdentity },
      ...provenance && { provenance },
      suiteId: asString(raw.suiteId, path, "suiteId"),
      probeHash,
      suiteComplete,
      suiteProbeCount: expected.size,
      sourceRevision,
      measuredAt: raw.measuredAt,
      origin: {
        kind: raw.origin.kind,
        ...typeof raw.origin.url === "string" && { url: raw.origin.url },
        ...appLaunch && { appLaunch }
      },
      rawReplies: raw.rawReplies,
      assertions,
      screenshotRefs: raw.screenshotRefs,
      observations,
      notTested,
      ungradedDiagnostics,
      legacy: false
    };
  }
  const kind = path.includes("probes-mux/") ? "mux" : raw.backend ? "headless" : "app";
  const id = asString(raw.backend ?? raw.terminal, path, "backend/terminal");
  const version = asString(raw.version ?? raw.terminalVersion, path, "version");
  if (!date(raw.generated))
    fail(path, "invalid generated timestamp");
  if (!object(raw.results))
    fail(path, "missing results");
  const observations = [];
  for (const [featureId, value] of Object.entries(raw.results)) {
    if (!catalog.has(featureId))
      fail(path, `unknown feature ${featureId}`);
    if (typeof value !== "boolean")
      fail(path, `invalid legacy result for ${featureId}`);
    observations.push({ featureId, outcome: value ? "supported" : "unsupported", evidence: "legacy" });
  }
  const target = {
    kind,
    id,
    version,
    os: typeof raw.os === "string" ? raw.os : null,
    osVersion: typeof raw.osVersion === "string" ? raw.osVersion : null,
    outerTerminal: null,
    mux: null,
    config: null,
    permissions: null
  };
  return {
    path,
    sha256,
    schemaVersion: 1,
    runId: typeof raw.runId === "string" ? raw.runId : `legacy-${sha256.slice(0, 16)}`,
    target,
    identity: "unverified",
    suiteId: "legacy",
    probeHash: typeof raw.probeHash === "string" ? raw.probeHash : null,
    suiteComplete: false,
    suiteProbeCount: null,
    sourceRevision: null,
    measuredAt: raw.generated,
    origin: { kind: "collector" },
    rawReplies: object(raw.responses) && Object.values(raw.responses).every((v) => typeof v === "string") ? raw.responses : {},
    assertions: [],
    screenshotRefs: [],
    observations,
    notTested: [],
    ungradedDiagnostics: {},
    legacy: true
  };
}
function decodeExactUtf8(bytes, path) {
  let source;
  try {
    source = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    return fail(path, "invalid UTF-8 in raw run");
  }
  if (!Buffer.from(source, "utf8").equals(Buffer.from(bytes))) {
    fail(path, "raw UTF-8 bytes change when decoded");
  }
  return source;
}
function decodeCollectorRun(path, raw, manifest, collectorRevision) {
  const catalog = [...new Set(Object.values(manifest.probes).flat())];
  const measured = parseRun(path, raw, catalog, new Map([[manifest.probeHash, manifest]]));
  if (measured.schemaVersion !== 2)
    fail(path, "expected schemaVersion 2 collector run, not legacy boolean results");
  if (measured.probeHash !== manifest.probeHash || measured.suiteId !== manifest.probeHash) {
    fail(path, `collector suite differs from trusted ${manifest.probeHash}`);
  }
  if (measured.sourceRevision !== collectorRevision) {
    fail(path, `collector sourceRevision differs from trusted ${collectorRevision}`);
  }
  if (measured.identity !== "unverified" || measured.origin.kind !== "collector") {
    fail(path, "public collector run must have unverified identity and collector origin");
  }
  const run = {
    schemaVersion: 2,
    runId: measured.runId,
    target: measured.target,
    identity: "unverified",
    ...measured.runtimeIdentity && { runtimeIdentity: measured.runtimeIdentity },
    ...measured.provenance && { provenance: measured.provenance },
    suiteId: measured.suiteId,
    probeHash: manifest.probeHash,
    suiteComplete: measured.suiteComplete,
    sourceRevision: collectorRevision,
    measuredAt: measured.measuredAt,
    origin: measured.origin,
    rawReplies: measured.rawReplies,
    assertions: measured.assertions,
    screenshotRefs: measured.screenshotRefs,
    observations: measured.observations,
    ...measured.notTested.length > 0 && { notTested: measured.notTested },
    ungradedDiagnostics: measured.ungradedDiagnostics
  };
  return { run, raw, sha256: measured.sha256 };
}
var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value), nonempty = (value) => typeof value === "string" && value.length > 0, screenshotDigest = (value) => typeof value === "string" && /^sha256:[0-9a-f]{64}$/.test(value), date = (value) => nonempty(value) && !Number.isNaN(Date.parse(value)), asString = (value, path, name) => nonempty(value) ? value : fail(path, `missing ${name}`), nullableString = (value, path, name) => value === null ? null : asString(value, path, name);
var init_src2 = __esm(() => {
  init_src();
});

// src/detect.ts
import { release } from "os";
import { execFileSync } from "child_process";
function detectTerminal() {
  const os = detectOS();
  const osVersion = detectOSVersion();
  let name = "unknown";
  let version = "";
  const bundleId = process.env.__CFBundleIdentifier;
  if (bundleId && os === "macos") {
    for (const [termName, bid] of Object.entries(BUNDLE_IDS)) {
      if (bundleId === bid) {
        name = termName;
        break;
      }
    }
    if (name === "unknown" && bundleId) {
      name = bundleId;
    }
  }
  if (name === "unknown") {
    const termProgram = process.env.TERM_PROGRAM;
    if (termProgram) {
      name = TERM_PROGRAM_MAP[termProgram] ?? termProgram.toLowerCase();
      version = process.env.TERM_PROGRAM_VERSION ?? "";
    }
  }
  if (name === "unknown") {
    for (const { env, name: n } of ENV_DETECTORS) {
      if (process.env[env]) {
        name = n;
        break;
      }
    }
  }
  if (name === "unknown") {
    const termEmu = process.env.TERMINAL_EMULATOR;
    if (termEmu)
      name = termEmu.toLowerCase();
  }
  if (name === "unknown") {
    if (process.env.GNOME_TERMINAL_SCREEN)
      name = "gnome-terminal";
    else if (process.env.KONSOLE_VERSION) {
      name = "konsole";
      version = process.env.KONSOLE_VERSION;
    } else if (process.env.TILIX_ID)
      name = "tilix";
  }
  if (name === "unknown" && os === "windows") {
    if (process.env.WT_SESSION)
      name = "windows-terminal";
  }
  if (name === "unknown") {
    name = process.env.TERM ?? "unknown";
  }
  if (!version && os === "macos") {
    version = getMacOSAppVersion(name);
  }
  return { name, version, os, osVersion };
}
function getMacOSAppVersion(terminalName) {
  try {
    let bundleId = process.env.__CFBundleIdentifier;
    if (!bundleId)
      bundleId = BUNDLE_IDS[terminalName];
    if (!bundleId)
      return "";
    const appPath = execFileSync("mdfind", [`kMDItemCFBundleIdentifier == '${bundleId}'`], {
      encoding: "utf-8",
      timeout: 3000
    }).trim().split(`
`)[0];
    if (!appPath)
      return "";
    const version = execFileSync("/usr/libexec/PlistBuddy", ["-c", "Print :CFBundleShortVersionString", `${appPath}/Contents/Info.plist`], { encoding: "utf-8", timeout: 2000 }).trim();
    return version;
  } catch {
    return "";
  }
}
function detectOS() {
  switch (process.platform) {
    case "darwin":
      return "macos";
    case "linux":
      return "linux";
    case "win32":
      return "windows";
    default:
      return process.platform;
  }
}
function detectOSVersion() {
  if (process.platform === "darwin") {
    let version;
    try {
      version = execFileSync("/usr/bin/sw_vers", ["-productVersion"], {
        encoding: "utf8",
        timeout: 2000,
        maxBuffer: 128
      }).trim();
    } catch (error) {
      throw new Error(`sw_vers -productVersion failed: ${error instanceof Error ? error.message : String(error)}`);
    }
    if (!/^[1-9]\d{0,2}\.(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2}))?$/.test(version)) {
      throw new Error(`sw_vers -productVersion returned invalid macOS version: ${JSON.stringify(version)}`);
    }
    return version;
  }
  try {
    return release();
  } catch {
    return "";
  }
}
var ENV_DETECTORS, TERM_PROGRAM_MAP, BUNDLE_IDS;
var init_detect = __esm(() => {
  ENV_DETECTORS = [
    { env: "GHOSTTY_RESOURCES_DIR", name: "ghostty" },
    { env: "KITTY_WINDOW_ID", name: "kitty" },
    { env: "WEZTERM_EXECUTABLE", name: "wezterm" },
    { env: "ALACRITTY_WINDOW_ID", name: "alacritty" }
  ];
  TERM_PROGRAM_MAP = {
    iTerm: "iterm2",
    "iTerm.app": "iterm2",
    Apple_Terminal: "terminal-app",
    WezTerm: "wezterm",
    vscode: "vscode",
    Hyper: "hyper",
    tmux: "tmux",
    WarpTerminal: "warp"
  };
  BUNDLE_IDS = {
    cmux: "com.cmuxterm.app",
    cursor: "com.todesktop.230313mzl4w4u92",
    ghostty: "com.mitchellh.ghostty",
    kitty: "net.kovidgoyal.kitty",
    iterm2: "com.googlecode.iterm2",
    "terminal-app": "com.apple.Terminal",
    wezterm: "org.wezfurlong.wezterm",
    alacritty: "org.alacritty",
    warp: "dev.warp.Warp-Stable"
  };
});

// src/identity-guard.ts
function deriveIdentity(responses) {
  const source = responses && Object.hasOwn(responses, "collector.xtversion") ? "collector" : "feature";
  const raw = responses?.[source === "collector" ? "collector.xtversion" : "device.xtversion"];
  const complete = raw ? COMPLETE_XTVERSION.exec(raw) : null;
  const da1Only = DA1_ONLY.test(raw ?? "");
  if (source === "collector" && raw && !complete && !da1Only) {
    throw new Error(`identity: XTVERSION preflight malformed, raw ${Buffer.from(raw).toString("base64")}`);
  }
  const collectorDa1 = source === "collector" ? complete?.[2] ?? (da1Only ? raw : undefined) : undefined;
  const explicitDa1 = responses && Object.hasOwn(responses, "device.primary-da");
  const da1 = explicitDa1 ? responses["device.primary-da"] : collectorDa1;
  if (explicitDa1 && source === "collector" && complete?.[2]) {
    if (!DA1_ONLY.test(da1 ?? "")) {
      throw new Error(`identity: DA1 malformed, raw ${Buffer.from(da1 ?? "").toString("base64")}`);
    }
    if (da1 !== collectorDa1) {
      throw new Error(`identity: DA1 mismatch, explicit ${JSON.stringify(da1)}, collector ${JSON.stringify(collectorDa1)}`);
    }
  }
  return {
    source,
    xtversionRaw: raw,
    xtversionPayload: complete ? complete[1] : da1Only || raw?.startsWith("\x1BP") ? undefined : raw,
    da1
  };
}
function resolveMeasuredAppVersion(terminal, detectedVersion, responses) {
  if (terminal !== "kitty")
    return detectedVersion || "unknown";
  const identity = deriveIdentity(responses);
  if (identity.source === "collector" && !identity.xtversionPayload) {
    throw new Error("identity: XTVERSION preflight silent");
  }
  if (identity.source === "feature" && !identity.xtversionRaw?.startsWith("\x1BP"))
    return detectedVersion || "unknown";
  const payload = identity.xtversionPayload;
  if (!payload)
    return detectedVersion || "unknown";
  const version = /^kitty\((\d+(?:\.\d+){1,3}(?:[-+][a-zA-Z0-9.-]+)?)\)$/i.exec(payload)?.[1];
  if (!version)
    throw new Error(`Kitty identity mismatch: measured XTVERSION ${payload}`);
  if (detectedVersion && detectedVersion !== version) {
    throw new Error(`Kitty version mismatch: detected ${detectedVersion}, measured ${version}`);
  }
  return version;
}
var DA1_GRAMMAR, DA1_ONLY, COMPLETE_XTVERSION;
var init_identity_guard = __esm(() => {
  DA1_GRAMMAR = String.raw`\x1b\[\?[0-9;]+c`;
  DA1_ONLY = new RegExp(`^${DA1_GRAMMAR}$`);
  COMPLETE_XTVERSION = new RegExp(String.raw`^\x1bP>\|([^\x1b]+)\x1b\\(${DA1_GRAMMAR})?$`);
});

// src/tty.ts
import { AsyncLocalStorage } from "async_hooks";
import { openSync } from "fs";
import { WriteStream } from "tty";
function openControllingTTY() {
  if (process.platform === "win32")
    throw new Error("JSON/file collection requires a proved Windows controlling TTY");
  if (!process.stdin.isTTY)
    throw new Error("JSON/file collection requires interactive TTY stdin for probe replies");
  let fd;
  try {
    fd = openSync("/dev/tty", "w");
  } catch (error) {
    throw new Error(`Cannot open controlling /dev/tty before probing: ${error instanceof Error ? error.message : String(error)}`);
  }
  const out = new WriteStream(fd);
  collectorOpenedControllingOutputs.add(out);
  return out;
}
function wasCollectorOpenedControllingTTY(out) {
  return collectorOpenedControllingOutputs.has(out);
}
function withTTYQueryTrace(queries, events, fn) {
  return queryTraceContext.run({ queries, events }, fn);
}
function withTTYOperation(fn, out) {
  const active = operationContext.getStore();
  if (active?.active) {
    if (out && out !== active.out)
      throw new Error("Nested TTY operation changed output stream");
    return fn();
  }
  const previous = ttyOperations.get(process.stdin) ?? Promise.resolve();
  const current = previous.catch(() => {}).then(() => {
    const lease = { active: true, out: out ?? process.stdout };
    return operationContext.run(lease, async () => {
      try {
        return await fn();
      } finally {
        lease.active = false;
      }
    });
  });
  ttyOperations.set(process.stdin, current.then(() => {
    return;
  }, () => {
    return;
  }));
  return current;
}
function currentTTYOutput() {
  const lease = operationContext.getStore();
  return lease?.active ? lease.out : process.stdout;
}
function matchResponse(pattern, timeoutMs, write, sentinel = false, sequence = "") {
  const trace = queryTraceContext.getStore();
  return new Promise((resolve) => {
    const chunks = [];
    let buf = "";
    const cleanup = () => {
      clearTimeout(timer);
      process.stdin.off("data", onData);
    };
    const finish = (match, reason) => {
      cleanup();
      const outcome = { match, reason, raw: buf, rawBase64: Buffer.concat(chunks).toString("base64") };
      trace?.queries.push({ sequence, ...outcome });
      trace?.events.push({ kind: "query", sequence, ...outcome });
      resolve(outcome);
    };
    const onData = (chunk) => {
      chunks.push(Buffer.from(chunk));
      buf = Buffer.concat(chunks).toString();
      const match = buf.match(pattern);
      const end = sentinel ? buf.search(/\x1b\[\?[0-9;]+c/) : -1;
      if (end >= 0) {
        if (match && (match.index ?? 0) < end)
          finish([...match], "reply");
        else
          finish(null, "sentinel");
      } else if (match && !sentinel) {
        finish([...match], "reply");
      }
    };
    const timer = setTimeout(() => {
      const match = buf.match(pattern);
      finish(match ? [...match] : null, match ? "reply" : "timeout");
    }, timeoutMs);
    process.stdin.on("data", onData);
    try {
      write?.();
    } catch (error) {
      cleanup();
      throw error;
    }
  });
}
async function query(sequence, responsePattern, timeoutMs = 1000) {
  return (await queryOutcome(sequence, responsePattern, timeoutMs)).match;
}
async function queryOutcome(sequence, responsePattern, timeoutMs = 1000) {
  return withTTYOperation(() => matchResponse(responsePattern, timeoutMs, () => currentTTYOutput().write(sequence), false, sequence));
}
async function queryWithSentinelOutcome(sequence, responsePattern, timeoutMs = 2000) {
  if (sequence === "\x1B[c") {
    return queryOutcome(sequence, responsePattern, timeoutMs);
  }
  return withTTYOperation(() => matchResponse(responsePattern, timeoutMs, () => currentTTYOutput().write(sequence + "\x1B[c"), true, sequence + "\x1B[c"));
}
async function queryWithSentinel(sequence, responsePattern, timeoutMs = 2000) {
  const outcome = await queryWithSentinelOutcome(sequence, responsePattern, timeoutMs);
  return outcome.match;
}
async function queryCursorPosition() {
  const match = await query("\x1B[6n", /\x1b\[(\d+);(\d+)R/);
  if (!match?.[1] || !match[2])
    return null;
  return [parseInt(match[1], 10), parseInt(match[2], 10)];
}
async function measureRenderedWidth(text) {
  return withTTYOperation(async () => {
    currentTTYOutput().write("\x1B7");
    try {
      currentTTYOutput().write("\x1B[2;1H");
      const secondRow = await queryCursorPosition();
      if (secondRow?.[0] !== 2 || secondRow[1] !== 1)
        return null;
      currentTTYOutput().write("\x1B[1;1HA");
      const ascii = await queryCursorPosition();
      if (ascii?.[0] !== 1 || ascii[1] !== 2)
        return null;
      currentTTYOutput().write("\x1B[1;1H" + text);
      const pos = await queryCursorPosition();
      if (pos?.[0] !== 1 || !Number.isSafeInteger(pos[1]) || pos[1] <= 1)
        return null;
      currentTTYOutput().write("A");
      const next = await queryCursorPosition();
      return next?.[0] === 1 && next[1] === pos[1] + 1 ? pos[1] - 1 : null;
    } finally {
      currentTTYOutput().write("\x1B8");
    }
  });
}
async function queryMode(modeNumber) {
  const match = await queryWithSentinel(`\x1B[?${modeNumber}$p`, new RegExp(`\\x1b\\[\\?${modeNumber};([0-4])\\$y`));
  if (!match)
    return null;
  const status = parseInt(match[1] ?? "", 10);
  switch (status) {
    case 1:
    case 3:
      return "set";
    case 2:
    case 4:
      return "reset";
    case 0:
      return "unknown";
    default:
      return null;
  }
}
async function drainStdin(ms = 300) {
  return new Promise((resolve) => {
    if (!process.stdin.readable) {
      resolve();
      return;
    }
    process.stdin.resume();
    let timer = setTimeout(done, ms);
    function onData() {
      while (process.stdin.read() !== null) {}
      clearTimeout(timer);
      timer = setTimeout(done, ms);
    }
    function done() {
      process.stdin.removeListener("readable", onData);
      resolve();
    }
    process.stdin.on("readable", onData);
  });
}
async function withRawMode(fn, out) {
  return withTTYOperation(async () => {
    const wasRaw = process.stdin.isRaw;
    const wasFlowing = process.stdin.readableFlowing;
    if (process.stdin.isTTY) {
      process.stdin.setRawMode(true);
      process.stdin.resume();
    }
    try {
      return await fn();
    } finally {
      if (process.stdin.isTTY)
        process.stdin.setRawMode(wasRaw ?? false);
      if (wasFlowing !== true)
        process.stdin.pause();
    }
  }, out);
}
var ttyOperations, operationContext, collectorOpenedControllingOutputs, queryTraceContext;
var init_tty = __esm(() => {
  ttyOperations = new WeakMap;
  operationContext = new AsyncLocalStorage;
  collectorOpenedControllingOutputs = new WeakSet;
  queryTraceContext = new AsyncLocalStorage;
});

// src/linux-capture.ts
import { execFile } from "child_process";
import { createHash as createHash2 } from "crypto";
import { mkdirSync, readFileSync, realpathSync, writeFileSync } from "fs";
import { join } from "path";
function assertLiveExecutable(pid, expected) {
  if (!Number.isSafeInteger(pid) || pid < 2 || !expected.path.startsWith("/") || !/^[0-9a-f]{64}$/.test(expected.sha256)) {
    throw new Error("Invalid measured executable identity");
  }
  const path = realpathSync(`/proc/${pid}/exe`);
  if (path !== expected.path)
    throw new Error(`Live executable path mismatch for PID ${pid}: ${path}`);
  if (digest(readFileSync(`/proc/${pid}/exe`)) !== expected.sha256) {
    throw new Error(`Live executable digest mismatch for PID ${pid}`);
  }
}
function command(file, args, input) {
  return new Promise((resolve, reject) => {
    let stdinError;
    const child = execFile(file, args, { encoding: "buffer", timeout: 1e4, maxBuffer: 32 * 1024 * 1024 }, (error, stdout) => {
      if (error)
        reject(error);
      else if (stdinError)
        reject(stdinError);
      else
        resolve(Buffer.isBuffer(stdout) ? stdout : Buffer.from(stdout));
    });
    if (!child.stdin) {
      if (input)
        reject(new Error(`Capture command ${file} has no stdin for ${input.length} input bytes`));
      return;
    }
    child.stdin.on("error", (error) => {
      stdinError = error;
    });
    child.stdin.end(input);
  });
}
function digest(bytes) {
  return createHash2("sha256").update(bytes).digest("hex");
}
function retain(directory, bytes, extension) {
  const hash = digest(bytes);
  const path = join(directory, `${hash}.${extension}`);
  try {
    writeFileSync(path, bytes, { flag: "wx", mode: 384 });
  } catch (error) {
    if (error.code !== "EEXIST")
      throw error;
    if (!readFileSync(path).equals(bytes))
      throw new Error(`Capture artifact digest collision at ${path}`);
  }
  return `sha256:${hash}`;
}
function kittyAncestor(executable) {
  let pid = process.pid;
  for (let depth = 0;depth < 64 && pid > 1; depth++) {
    const path = realpathSync(`/proc/${pid}/exe`);
    if (path === executable.path) {
      assertLiveExecutable(pid, executable);
      return pid;
    }
    const stat = readFileSync(`/proc/${pid}/stat`, "utf8");
    const fields = stat.slice(stat.lastIndexOf(")") + 2).split(" ");
    const parent = Number(fields[1]);
    if (!Number.isSafeInteger(parent) || parent < 1 || parent === pid) {
      throw new Error(`Cannot resolve terminal parent of collector PID ${pid}`);
    }
    pid = parent;
  }
  throw new Error(`Collector PID ${process.pid} has no ancestor running ${executable.path}`);
}
async function createLinuxCapture(directory, executable) {
  if (process.platform !== "linux" || !process.env.DISPLAY) {
    throw new Error("Linux capture requires Linux and the owned DISPLAY");
  }
  const kittyPid = kittyAncestor(executable);
  const windows = (await command("xdotool", ["search", "--onlyvisible", "--pid", String(kittyPid)])).toString().trim().split(/\s+/).filter(Boolean);
  const windowId = windows[0];
  if (windows.length !== 1 || !windowId || !/^\d+$/.test(windowId)) {
    throw new Error(`Collector's Kitty PID ${kittyPid} owns ${windows.length} visible windows; expected one`);
  }
  const ownedWindowId = windowId;
  const display = (await command("xdpyinfo", [])).toString();
  const rootLines = display.split(`
`).filter((line) => /root window id:/.test(line));
  const roots = rootLines.map((line) => {
    const match = /^\s*root window id:\s*0x([0-9a-fA-F]+)\s*$/.exec(line);
    const rootId = match?.[1];
    return rootId === undefined ? NaN : Number.parseInt(rootId, 16);
  });
  if (roots.length === 0 || roots.some((root) => !Number.isSafeInteger(root))) {
    throw new Error("Cannot identify DISPLAY root windows for capture");
  }
  async function assertOwned() {
    if (kittyAncestor(executable) !== kittyPid)
      throw new Error("Collector terminal process changed during capture");
    const owner = (await command("xdotool", ["getwindowpid", ownedWindowId])).toString().trim();
    if (owner !== String(kittyPid))
      throw new Error(`Capture window ${windowId} no longer belongs to Kitty ${kittyPid}`);
    const visible = (await command("xdotool", ["search", "--onlyvisible", "--maxdepth", "1", "--name", ".*"])).toString().trim().split(/\s+/);
    if (visible.some((id) => !/^\d+$/.test(id) || !Number.isSafeInteger(Number(id)))) {
      throw new Error("Invalid visible top-level window census for capture");
    }
    const topLevel = visible.filter((id) => !roots.includes(Number(id)));
    if (topLevel.length !== 1 || topLevel[0] !== ownedWindowId) {
      throw new Error(`Capture requires only its owned visible top-level window; found ${topLevel.join(", ")}`);
    }
  }
  await assertOwned();
  mkdirSync(directory, { recursive: true, mode: 448 });
  const converter = (await command("magick", ["-version"])).toString().trim();
  const geometry = (await command("xdotool", ["getwindowgeometry", "--shell", windowId])).toString();
  return async ({ featureId, role, label }) => {
    await new Promise((resolve) => {
      setTimeout(resolve, 150);
    });
    await assertOwned();
    const before = (await command("xdotool", ["getwindowgeometry", "--shell", windowId])).toString();
    if (before !== geometry)
      throw new Error(`Capture window ${windowId} geometry changed during ${featureId}`);
    const original = await command("xwd", ["-id", windowId, "-silent"]);
    const capturedAt = Date.now();
    const png = await command("magick", ["xwd:-", "png:-"], original);
    if (!png.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
      throw new Error(`Capture conversion did not produce PNG bytes for ${featureId}`);
    }
    await assertOwned();
    const after = (await command("xdotool", ["getwindowgeometry", "--shell", windowId])).toString();
    if (after !== geometry)
      throw new Error(`Capture window ${windowId} geometry changed during ${featureId}`);
    const sourceRef = retain(directory, original, "xwd");
    const ref = retain(directory, png, "png");
    return {
      frame: { role, label, capturedAt, ref, sourceRef },
      trace: {
        featureId,
        collectorPid: process.pid,
        kittyPid,
        executable,
        windowId,
        geometry,
        converter,
        settleMs: 150
      }
    };
  };
}
var init_linux_capture = () => {};

// src/linux-clipboard.ts
import { execFile as execFile2, spawn } from "child_process";
import { createHash as createHash3 } from "crypto";
import { readFileSync as readFileSync2, realpathSync as realpathSync2, statSync } from "fs";
import { homedir } from "os";
import { basename, dirname, sep } from "path";
function createClipboardTransaction(baseline, io) {
  let busy = false;
  return async (work, trace) => {
    if (busy)
      throw new Error("Owned clipboard transaction cannot nest or overlap");
    busy = true;
    let result;
    let failure;
    try {
      await io.assertOwned();
      if (await io.readText(trace) !== baseline)
        throw new Error("Owned clipboard baseline changed before callback");
      const fixture = {
        readText: () => io.readText(trace),
        writeText: (text) => io.writeText(text, trace)
      };
      result = await work(fixture);
    } catch (error) {
      failure = error;
    } finally {
      try {
        await io.writeText(baseline, trace, "clipboard-restore");
        if (await io.readText(trace, "clipboard-verify") !== baseline) {
          throw new Error("Owned clipboard restoration verification failed");
        }
      } catch (error) {
        failure = new Error(`Owned clipboard restoration failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      busy = false;
    }
    if (failure)
      throw failure;
    if (!result)
      throw new Error("Owned clipboard callback returned no result");
    return result;
  };
}
function ownedFile(path) {
  const home = realpathSync2(homedir());
  const real = realpathSync2(path);
  if (!real.startsWith(`${home}${sep}`))
    throw new Error(`Clipboard fixture path is outside private HOME: ${path}`);
  const stat = statSync(real);
  if (!stat.isFile() || (stat.mode & 63) !== 0 || stat.uid !== process.getuid?.()) {
    throw new Error(`Clipboard fixture is not a private owned file: ${path}`);
  }
  return real;
}
function ownedReceipt(path) {
  const capture = process.env.TERMINFO_CAPTURE_DIRECTORY;
  if (!capture || dirname(realpathSync2(path)) !== realpathSync2(dirname(capture))) {
    throw new Error("Clipboard receipt is outside the controlled capture directory");
  }
  const stat = statSync(path);
  if (!stat.isFile() || (stat.mode & 18) !== 0 || stat.uid !== process.getuid?.()) {
    throw new Error("Clipboard receipt is not an owned non-writable-by-others file");
  }
  return path;
}
function processExecutable(pid) {
  if (!Number.isSafeInteger(pid) || pid < 2)
    throw new Error(`Invalid owned clipboard PID ${pid}`);
  const status = readFileSync2(`/proc/${pid}/status`, "utf8");
  const uid = Number(/^Uid:\s+(\d+)/m.exec(status)?.[1]);
  if (uid !== process.getuid?.())
    throw new Error(`Clipboard process ${pid} has another owner`);
  return realpathSync2(`/proc/${pid}/exe`);
}
function ancestorOfCollector(pid) {
  let current = process.pid;
  for (let depth = 0;depth < 64 && current > 1; depth++) {
    if (current === pid)
      return true;
    const stat = readFileSync2(`/proc/${current}/stat`, "utf8");
    current = Number(stat.slice(stat.lastIndexOf(")") + 2).split(" ")[1]);
  }
  return false;
}
function command2(file, args, env) {
  return new Promise((resolve, reject) => {
    execFile2(file, args, { encoding: "utf8", timeout: 3000, maxBuffer: 1024 * 1024, env }, (error, stdout) => {
      if (error)
        reject(error);
      else
        resolve(stdout);
    });
  });
}
function assertShape(value) {
  if (!value || typeof value !== "object")
    throw new Error("Invalid owned clipboard receipt");
  const r = value;
  if (r.schemaVersion !== 1 || !/^[0-9a-f]{32}$/.test(r.runId ?? "") || !["default", "allow", "deny-read"].includes(r.profile ?? "") || !r.display || !r.terminal || !r.selection || typeof r.config !== "string" || typeof r.permissions !== "string") {
    throw new Error("Invalid owned clipboard receipt shape");
  }
  for (const pid of [
    r.display.xvfbPid,
    r.terminal.pid,
    r.terminal.collectorPid,
    r.terminal.windowPid,
    r.selection.helperPid
  ]) {
    if (!Number.isSafeInteger(pid) || (pid ?? 0) < 2)
      throw new Error("Owned clipboard receipt has invalid PID");
  }
  if (!Number.isSafeInteger(r.display.number) || r.display.name !== `:${r.display.number}` || typeof r.display.displayFdPath !== "string" || !r.display.displayFdPath.startsWith("/") || typeof r.terminal.windowId !== "string" || !/^\d+$/.test(r.terminal.windowId) || typeof r.selection.helperExecutable?.path !== "string" || !r.selection.helperExecutable.path.startsWith("/") || typeof r.selection.baselinePath !== "string" || !r.selection.baselinePath.startsWith("/") || !/^[0-9a-f]{64}$/.test(r.selection.helperExecutable?.sha256 ?? "") || !/^[0-9a-f]{64}$/.test(r.selection.baselineSha256 ?? "") || r.selection.initialReadSha256 !== r.selection.baselineSha256) {
    throw new Error("Owned clipboard receipt has invalid display, window, or digest");
  }
  return r;
}
function assertKittyClipboardProfile(profile, argv) {
  const commandIndex = argv.findIndex((part) => part === "bun");
  const options = commandIndex < 0 ? argv : argv.slice(0, commandIndex);
  const controls = options.filter((part, index) => options[index - 1] === "-o" && part.startsWith("clipboard_control="));
  const expected = {
    default: [],
    allow: ["clipboard_control=write-clipboard read-clipboard"],
    "deny-read": ["clipboard_control=write-clipboard"]
  }[profile];
  if (JSON.stringify(controls) !== JSON.stringify(expected)) {
    throw new Error(`Owned Kitty argv clipboard control differs from ${profile} receipt`);
  }
}
async function createLinuxClipboardAdapter(receiptPath, expectedLaunchRunId, executable) {
  if (process.platform !== "linux")
    throw new Error("Owned clipboard fixture requires Linux");
  const receiptBytes = readFileSync2(ownedReceipt(receiptPath));
  const receipt = assertShape(JSON.parse(receiptBytes.toString("utf8")));
  if (receipt.runId !== expectedLaunchRunId || process.env.DISPLAY !== receipt.display.name || process.env.TERMINFO_CLIPBOARD_PROFILE !== receipt.profile || receipt.terminal.collectorPid !== process.pid || receipt.terminal.windowPid !== receipt.terminal.pid) {
    throw new Error("Owned clipboard receipt does not match this collector run, display, or terminal");
  }
  const expectedPermissions = {
    default: "clipboard: read=ask,write=allow; OSC52=not-run",
    allow: "clipboard: read=allow,write=allow",
    "deny-read": "clipboard: read=deny,write=allow"
  }[receipt.profile];
  if (receipt.permissions !== expectedPermissions) {
    throw new Error("Owned clipboard profile and Kitty configuration disagree");
  }
  const displayNumber = readFileSync2(ownedFile(receipt.display.displayFdPath), "utf8").trim();
  if (displayNumber !== String(receipt.display.number))
    throw new Error("Owned Xvfb displayfd differs from receipt");
  const baseline = readFileSync2(ownedFile(receipt.selection.baselinePath), "utf8");
  if (baseline !== `terminfo-owned-clipboard-${receipt.runId}` || digest2(baseline) !== receipt.selection.baselineSha256) {
    throw new Error("Owned clipboard baseline is not this collector's generated nonce");
  }
  const helperExe = realpathSync2(receipt.selection.helperExecutable.path);
  if (digest2(readFileSync2(helperExe)) !== receipt.selection.helperExecutable.sha256) {
    throw new Error("Owned xclip executable digest mismatch");
  }
  const env = { ...process.env, DISPLAY: receipt.display.name };
  async function assertOwned() {
    if (basename(processExecutable(receipt.display.xvfbPid)) !== "Xvfb" || !readFileSync2(`/proc/${receipt.display.xvfbPid}/cmdline`, "utf8").includes("-displayfd") || !ancestorOfCollector(receipt.terminal.pid)) {
      throw new Error("Owned clipboard Xvfb or Kitty process no longer owns this collector");
    }
    processExecutable(receipt.terminal.pid);
    assertLiveExecutable(receipt.terminal.pid, executable);
    assertKittyClipboardProfile(receipt.profile, readFileSync2(`/proc/${receipt.terminal.pid}/cmdline`, "utf8").split("\x00").filter(Boolean));
    const owner = (await command2("xdotool", ["getwindowpid", receipt.terminal.windowId], env)).trim();
    if (owner !== String(receipt.terminal.pid))
      throw new Error("Clipboard window owner differs from receipt");
  }
  await assertOwned();
  if (processExecutable(receipt.selection.helperPid) !== helperExe) {
    throw new Error("Owned clipboard selection helper executable differs from receipt");
  }
  const children = new Set;
  const log = (trace, kind, text, helperPid) => trace({
    kind,
    at: new Date().toISOString(),
    sha256: digest2(text),
    length: Buffer.byteLength(text),
    ...helperPid && { helperPid }
  });
  async function readText(trace, kind = "clipboard-read") {
    const at = new Date().toISOString();
    try {
      await assertOwned();
      const text = await command2(helperExe, ["-quiet", "-selection", "clipboard", "-o"], env);
      trace({ kind, at, sha256: digest2(text), length: Buffer.byteLength(text) });
      return text;
    } catch (error) {
      trace({ kind, at, status: "error" });
      throw error;
    }
  }
  async function writeText(text, trace, kind = "clipboard-write") {
    const at = new Date().toISOString();
    try {
      await assertOwned();
    } catch (error) {
      trace({ kind, at, status: "error" });
      throw error;
    }
    const child = spawn(helperExe, ["-quiet", "-selection", "clipboard", "-i"], {
      env,
      stdio: ["pipe", "ignore", "ignore"]
    });
    let childError;
    child.once("error", (error) => {
      childError = error;
    });
    child.stdin.once("error", (error) => {
      childError = error;
    });
    children.add(child);
    child.once("exit", () => children.delete(child));
    if (!child.pid) {
      trace({ kind, at, status: "error" });
      throw new Error("Owned xclip writer failed to start");
    }
    child.stdin.end(text);
    log(trace, kind, text, child.pid);
    for (let attempt = 0;attempt < 30; attempt++) {
      if (childError)
        throw childError;
      try {
        if (await readText(trace) === text)
          return;
      } catch (error) {
        if (attempt === 29)
          throw error;
      }
      await new Promise((resolve) => {
        setTimeout(resolve, 20);
      });
    }
    throw new Error("Owned xclip writer did not acquire the clipboard selection");
  }
  if (await readText(() => {}) !== baseline) {
    throw new Error("Initial owned clipboard readback differs from generated baseline");
  }
  const withClipboardFixture = createClipboardTransaction(baseline, { assertOwned, readText, writeText });
  const adapter = {
    profile: receipt.profile,
    config: receipt.config,
    permissions: receipt.permissions,
    summary: JSON.stringify({
      receiptSha256: digest2(receiptBytes),
      runId: receipt.runId,
      profile: receipt.profile,
      config: receipt.config,
      permissions: receipt.permissions,
      display: { name: receipt.display.name, xvfbPid: receipt.display.xvfbPid },
      terminal: receipt.terminal,
      selection: {
        helperPid: receipt.selection.helperPid,
        helperExecutableSha256: receipt.selection.helperExecutable.sha256,
        baselineSha256: receipt.selection.baselineSha256,
        initialReadSha256: receipt.selection.initialReadSha256
      }
    }),
    withClipboardFixture,
    async dispose() {
      await Promise.all([...children].map((child) => new Promise((resolve, reject) => {
        if (child.exitCode !== null || child.signalCode !== null) {
          resolve();
          return;
        }
        const timer = setTimeout(() => reject(new Error(`Owned xclip PID ${child.pid} did not exit`)), 3000);
        child.once("exit", () => {
          clearTimeout(timer);
          resolve();
        });
        child.kill("SIGTERM");
      })));
    }
  };
  return adapter;
}
var digest2 = (bytes) => createHash3("sha256").update(bytes).digest("hex");
var init_linux_clipboard = __esm(() => {
  init_linux_capture();
});

// src/owned-terminal.ts
import { execFileSync as execFileSync2, spawn as spawn2 } from "child_process";
import { closeSync, constants, fstatSync, openSync as openSync2, readFileSync as readFileSync3, statSync as statSync2 } from "fs";
import { isatty, WriteStream as WriteStream2 } from "tty";
function parseTerminalAppOwner(value) {
  const invalid = () => new Error("Invalid Terminal.app owner assertion");
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw invalid();
  const object = value;
  const keys = ["asserter", "launchRunId", "workerPid", "windowId", "tabTty", "intendedVersion"];
  if (Object.keys(object).length !== keys.length || keys.some((key) => !Object.hasOwn(object, key)))
    throw invalid();
  if (object.asserter !== "terminfo-admin" || typeof object.launchRunId !== "string" || !/^[0-9a-f]{32}$/.test(object.launchRunId) || typeof object.workerPid !== "number" || !Number.isSafeInteger(object.workerPid) || object.workerPid < 1 || typeof object.windowId !== "number" || !Number.isSafeInteger(object.windowId) || object.windowId < 1 || typeof object.tabTty !== "string" || !/^\/dev\/tty[a-zA-Z0-9._-]+$/.test(object.tabTty) || typeof object.intendedVersion !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9.+_-]{0,79}$/.test(object.intendedVersion)) {
    throw invalid();
  }
  return {
    asserter: object.asserter,
    launchRunId: object.launchRunId,
    workerPid: object.workerPid,
    windowId: object.windowId,
    tabTty: object.tabTty,
    intendedVersion: object.intendedVersion
  };
}
function selectedFd(out) {
  const fd = out.fd;
  if (typeof fd !== "number" || !Number.isSafeInteger(fd) || fd < 0 || out !== process.stdout && !(out instanceof WriteStream2)) {
    throw new Error(`Owned output is not a real TTY stream (fd ${String(fd)})`);
  }
  if (!isatty(0))
    throw new Error("Owned input fd 0 is not a TTY");
  if (!isatty(fd))
    throw new Error(`Owned output fd ${fd} is not a TTY`);
  return fd;
}
function linuxOutput(out) {
  const fd = selectedFd(out);
  const stat = readFileSync3("/proc/self/stat", "utf8");
  const fields = stat.slice(stat.lastIndexOf(")") + 2).trim().split(/\s+/);
  const ttyNumber = Number(fields[4]);
  if (!Number.isInteger(ttyNumber) || ttyNumber < -2147483648 || ttyNumber > 2147483647) {
    throw new Error(`Invalid controlling tty_nr ${String(fields[4])}`);
  }
  const controlling = ttyNumber >>> 0;
  const inputDevice = device(fstatSync(0, { bigint: true }));
  if (controlling === 0 || inputDevice.rdev !== String(controlling)) {
    throw new Error(`Owned input device ${inputDevice.rdev} differs from controlling tty_nr ${controlling}`);
  }
  const inputRdev = controlling;
  const outputDevice = device(fstatSync(fd, { bigint: true }));
  if (outputDevice.rdev === String(controlling)) {
    return {
      platform: "linux",
      matched: "pty",
      selectedFd: fd,
      controllingTtyNr: controlling,
      inputRdev,
      outputRdev: controlling,
      outputDevice
    };
  }
  if (wasCollectorOpenedControllingTTY(out) && outputDevice.rdev === "1280") {
    return {
      platform: "linux",
      matched: "dev-tty",
      selectedFd: fd,
      controllingTtyNr: controlling,
      inputRdev,
      outputRdev: 1280,
      outputDevice
    };
  }
  throw new Error(`Owned output device ${outputDevice.rdev} differs from controlling tty_nr ${controlling}`);
}
function darwinOutput(out, assertion) {
  if (out !== process.stdout || out.fd !== 1) {
    throw new Error("Terminal.app owned output requires the daemon's real stdout PTY");
  }
  selectedFd(out);
  const controllingTty = execFileSync2("/bin/ps", ["-p", String(process.pid), "-o", "tty="], {
    encoding: "utf8",
    timeout: 1000,
    maxBuffer: 256
  }).trim();
  if (!/^tty[a-zA-Z0-9._-]+$/.test(controllingTty)) {
    throw new Error(`Terminal.app worker has no valid controlling TTY: ${JSON.stringify(controllingTty)}`);
  }
  if (`/dev/${controllingTty}` !== assertion.tabTty) {
    throw new Error(`Terminal.app worker TTY /dev/${controllingTty} differs from asserted tab ${assertion.tabTty}`);
  }
  const inputDevice = device(fstatSync(0, { bigint: true }));
  const outputDevice = device(fstatSync(1, { bigint: true }));
  const tabDevice = device(statSync2(assertion.tabTty, { bigint: true }));
  if (!sameDevice(inputDevice, outputDevice) || !sameDevice(outputDevice, tabDevice)) {
    throw new Error("Terminal.app input, selected stdout and asserted tab PTY device identities differ");
  }
  return { platform: "darwin", selectedFd: 1, controllingTty, tabTty: assertion.tabTty, inputDevice, outputDevice };
}
async function readBoundGeometry(binding) {
  const at = new Date().toISOString();
  const source = geometrySource(binding);
  const unavailable = (diagnostic, stdout = "", stderr = "") => ({
    status: "unavailable",
    at,
    source,
    diagnostic,
    stdout,
    stderr
  });
  return new Promise((resolve) => {
    let stdout = "";
    let stderr = "";
    let diagnostic;
    let settled = false;
    let inputFd;
    try {
      const path = binding.platform === "linux" ? "/proc/self/fd" : "/dev/fd";
      inputFd = openSync2(`${path}/${binding.selectedFd}`, constants.O_RDONLY | constants.O_NOCTTY);
      const reopened = device(fstatSync(inputFd, { bigint: true }));
      if (!isatty(inputFd) || !sameDevice(reopened, binding.outputDevice)) {
        closeSync(inputFd);
        inputFd = undefined;
        resolve(unavailable(`stty reopened selected output fd ${binding.selectedFd} is not the verified output device`));
        return;
      }
    } catch (error) {
      if (inputFd !== undefined)
        closeSync(inputFd);
      resolve(unavailable(`stty could not reopen selected output fd ${binding.selectedFd}: ${error instanceof Error ? error.message : String(error)}`));
      return;
    }
    let child;
    try {
      child = spawn2(binding.platform === "darwin" ? "/bin/stty" : "stty", ["size"], {
        stdio: [inputFd, "pipe", "pipe"]
      });
    } catch (error) {
      closeSync(inputFd);
      resolve(unavailable(`stty size failed to start: ${error instanceof Error ? error.message : String(error)}`));
      return;
    }
    const finish = (code) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      closeSync(inputFd);
      if (!diagnostic && code !== 0)
        diagnostic = `stty size exited ${String(code)}`;
      const match = /^(\d+) (\d+)\n?$/.exec(stdout);
      const rows = Number(match?.[1]);
      const cols = Number(match?.[2]);
      if (!diagnostic && match && Number.isSafeInteger(rows) && rows > 0 && Number.isSafeInteger(cols) && cols > 0) {
        resolve({ status: "measured", at, source, rows, cols, stdout, stderr });
      } else {
        resolve(unavailable(diagnostic ?? "stty size returned invalid rows and cols", stdout, stderr));
      }
    };
    const append = (current, chunk) => {
      const next = current + chunk.toString("utf8");
      if (Buffer.byteLength(next) > 256) {
        diagnostic = "stty size output exceeded 256 bytes";
        child.kill("SIGKILL");
      }
      return next.slice(0, 256);
    };
    child.stdout?.on("data", (chunk) => {
      stdout = append(stdout, chunk);
    });
    child.stderr?.on("data", (chunk) => {
      stderr = append(stderr, chunk);
    });
    child.on("error", (error) => {
      diagnostic = `stty size failed: ${error.message}`;
      finish(null);
    });
    child.on("close", finish);
    const timer = setTimeout(() => {
      diagnostic = "stty size timed out after 1000 ms";
      child.kill("SIGKILL");
      finish(null);
    }, 1000);
  });
}
function ownedTerminalVerifiedFor(owner, captureRunId, out) {
  const grant = owner && verifiedTerminalOwners.get(owner);
  return grant !== undefined && grant.captureRunId === captureRunId && grant.out === out;
}
async function createOwnedTerminal(options) {
  const { captureRunId, out, expectedLaunchRunId, linux, terminalApp } = options;
  if (!/^[0-9a-f]{32}$/.test(captureRunId))
    throw new Error("Invalid capture run ID for owned terminal");
  if (!/^[0-9a-f]{32}$/.test(expectedLaunchRunId))
    throw new Error("Invalid launch run ID for owned terminal");
  if (Boolean(linux) === Boolean(terminalApp))
    throw new Error("Owned terminal requires exactly one platform receipt");
  let binding;
  if (linux) {
    if (process.platform !== "linux")
      throw new Error("Owned Linux fixture requires Linux");
    binding = linuxOutput(out);
  } else {
    if (process.platform !== "darwin")
      throw new Error("Terminal.app owner requires Darwin");
    const assertion = parseTerminalAppOwner(terminalApp);
    if (assertion.launchRunId !== expectedLaunchRunId || process.env.TERMINFO_RUN_ID !== expectedLaunchRunId || assertion.workerPid !== process.pid) {
      throw new Error("Terminal.app owner assertion differs from this worker launch run or PID");
    }
    binding = darwinOutput(out, assertion);
  }
  let clipboard;
  try {
    if (linux)
      clipboard = await createLinuxClipboardAdapter(linux.receiptPath, expectedLaunchRunId, linux.executable);
    const geometryAtGrant = await readBoundGeometry(binding);
    const source = geometrySource(binding);
    const summary = JSON.stringify({
      platform: binding.platform,
      outputBinding: binding,
      geometryAtGrant,
      ...terminalApp && {
        ownerAssertion: parseTerminalAppOwner(terminalApp),
        ownerAssertionSource: "authenticated-admin-request"
      }
    });
    const owner = {
      geometryAtGrant,
      geometrySource: source,
      summary,
      ...clipboard && { clipboard },
      async readGeometry() {
        if (!verifiedTerminalOwners.has(owner))
          throw new Error("Owned geometry read has no live bound capture");
        const current = binding.platform === "linux" ? linuxOutput(out) : darwinOutput(out, parseTerminalAppOwner(terminalApp));
        if (current.platform !== binding.platform || current.selectedFd !== binding.selectedFd || !sameDevice(current.outputDevice, binding.outputDevice) || current.platform === "linux" && binding.platform === "linux" && current.controllingTtyNr !== binding.controllingTtyNr) {
          throw new Error("Owned geometry output binding changed");
        }
        return readBoundGeometry(current);
      },
      async dispose() {
        verifiedTerminalOwners.delete(owner);
        await clipboard?.dispose();
      }
    };
    verifiedTerminalOwners.set(owner, { captureRunId, out });
    return owner;
  } catch (error) {
    await clipboard?.dispose();
    throw error;
  }
}
var device = (stat) => ({
  dev: stat.dev.toString(),
  rdev: stat.rdev.toString(),
  ino: stat.ino.toString()
}), sameDevice = (left, right) => left.dev === right.dev && left.rdev === right.rdev && left.ino === right.ino, geometrySource = (binding) => binding.platform === "linux" ? "stty size on a /proc/self/fd reopen of the verified output device" : "stty size on a /dev/fd reopen of the verified output device", verifiedTerminalOwners;
var init_owned_terminal = __esm(() => {
  init_linux_clipboard();
  init_tty();
  verifiedTerminalOwners = new WeakMap;
});

// src/probes/unified.ts
function createTermContext({
  out,
  writes,
  events,
  probe,
  geometry
}) {
  const size = () => {
    if (probe.termNeedsGeometry !== true || !geometry) {
      const error = new Error(`App callback ${probe.id} accessed undeclared or unavailable terminal geometry`);
      error.name = "UndeclaredTerminalGeometry";
      throw error;
    }
    return geometry;
  };
  return {
    write(text) {
      writes?.push(text);
      events?.push({ kind: "write", sequence: text });
      out.write(text);
    },
    async queryCursorPosition() {
      const result = await queryCursorPosition();
      if (!result)
        return null;
      return { row: result[0], col: result[1] };
    },
    async measureRenderedWidth(text) {
      const setup = "\x1B7\x1B[1G" + text;
      writes?.push(setup);
      events?.push({ kind: "write", sequence: setup });
      try {
        return await measureRenderedWidth(text);
      } finally {
        writes?.push("\x1B8");
        events?.push({ kind: "write", sequence: "\x1B8" });
      }
    },
    query,
    queryOutcome,
    queryWithSentinel,
    queryWithSentinelOutcome,
    queryMode,
    get cols() {
      return size().cols;
    },
    get rows() {
      return size().rows;
    }
  };
}
function selectAppProbes(ids) {
  const expected = ALL_PROBES.filter((probe) => probe.term !== null);
  const requested = ids ? ids.map((id) => {
    const probe = expected.find((item) => item.id === id);
    if (!probe)
      throw new Error(`Unknown or inapplicable app probe ${id}`);
    return probe;
  }) : expected;
  if (new Set(requested.map((probe) => probe.id)).size !== requested.length) {
    throw new Error("Duplicate probe ID in app batch");
  }
  return {
    expected,
    selected: [
      ...requested.filter((probe) => !probe.id.startsWith("extensions.osc52-")),
      ...requested.filter((probe) => probe.id.startsWith("extensions.osc52-"))
    ]
  };
}
function refusedClaimEvidence(result) {
  const parts = [];
  const observation = result.observation;
  if (observation) {
    parts.push(`observation(${[
      `outcome=${observation.outcome}`,
      ...observation.reason ? [`reason=${observation.reason}`] : [],
      `evidence=${observation.evidence}`,
      ...observation.note ? [`note=${JSON.stringify(observation.note)}`] : []
    ].join(", ")})`);
  }
  for (const assertion of result.assertions ?? []) {
    parts.push(`assertion(${[
      `kind=${assertion.kind}`,
      `expected=${JSON.stringify(assertion.expected)}`,
      `observed=${JSON.stringify(assertion.observed)}`,
      ...assertion.note ? [`note=${JSON.stringify(assertion.note)}`] : []
    ].join(", ")})`);
  }
  return parts.join(" and ");
}
async function runProbeBatch(options = {}) {
  const out = options.out ?? process.stdout;
  const { expected, selected } = selectAppProbes(options.ids);
  const batch = {
    rawReplies: {},
    observations: [],
    assertions: [],
    notTested: [],
    ungradedDiagnostics: {},
    suiteComplete: false,
    screenshotRefs: []
  };
  const geometryChecks = [];
  const unavailable = (error) => ({
    status: "unavailable",
    at: new Date().toISOString(),
    source: options.ownedTerminal?.geometrySource ?? "unavailable: no verified output device",
    diagnostic: error instanceof Error ? error.message : String(error),
    stdout: "",
    stderr: ""
  });
  const readGeometry = async () => {
    try {
      if (!options.ownedTerminal)
        throw new Error("No owned geometry reader");
      return await options.ownedTerminal.readGeometry();
    } catch (error) {
      return unavailable(error);
    }
  };
  for (const probe of selected) {
    const writes = [];
    const queries = [];
    const events = [];
    const clipboardEvents = [];
    const captures = [];
    let captureAttempted = false;
    if (probe.termWrites !== "query" && !ownedTerminalVerifiedFor(options.ownedTerminal, options.captureRunId ?? "", out)) {
      batch.observations.push({
        featureId: probe.id,
        outcome: "inconclusive",
        reason: "policy-refused",
        evidence: "none",
        note: "Collector refused before sending bytes because disposable terminal ownership was not verified",
        rawReplyRef: probe.id
      });
      batch.rawReplies[probe.id] = JSON.stringify({ writes, queries, events });
      continue;
    }
    let preGeometry;
    let geometryCheck;
    if (probe.termNeedsGeometry) {
      geometryCheck = { featureId: probe.id };
      geometryChecks.push(geometryCheck);
      const geometryOwner = ownedTerminalVerifiedFor(options.ownedTerminal, options.captureRunId ?? "", out);
      const grant = geometryOwner ? options.ownedTerminal?.geometryAtGrant : undefined;
      if (grant?.status === "measured") {
        preGeometry = await readGeometry();
        geometryCheck.pre = preGeometry;
      }
      const corroboration = options.geometryCorroboration;
      const diagnostic = !geometryOwner ? "No verified owned terminal for geometry read" : grant?.status !== "measured" ? `Grant geometry unavailable: ${grant?.status === "unavailable" ? grant.diagnostic : "no owned measurement"}` : preGeometry?.status !== "measured" ? `Pre-callback geometry unavailable: ${preGeometry?.status === "unavailable" ? preGeometry.diagnostic : "no measurement"}` : corroboration?.status === "conflict" ? `CSI 18t geometry ${corroboration.rows}x${corroboration.cols} conflicts with stty ${preGeometry.rows}x${preGeometry.cols}` : corroboration?.status === "agree" && (corroboration.rows !== preGeometry.rows || corroboration.cols !== preGeometry.cols) ? `Pre-callback stty geometry ${preGeometry.rows}x${preGeometry.cols} differs from CSI 18t ${corroboration.rows}x${corroboration.cols}` : undefined;
      if (diagnostic) {
        geometryCheck.diagnostic = diagnostic;
        batch.observations.push({
          featureId: probe.id,
          outcome: "inconclusive",
          reason: "insufficient-evidence",
          evidence: "none",
          note: diagnostic,
          rawReplyRef: probe.id
        });
        batch.rawReplies[probe.id] = JSON.stringify({ writes, queries, events });
        continue;
      }
    }
    const context = createTermContext({
      out,
      writes,
      events,
      probe,
      geometry: preGeometry?.status === "measured" ? preGeometry : undefined
    });
    if (options.ownedTerminal?.clipboard && options.ownedTerminal.clipboard.profile !== "default"
        && (options.ownedTerminal.clipboard.profile !== "ntilde-private-app-v1" || ["extensions.osc52-clipboard", "extensions.osc52-write", "extensions.osc52-read"].includes(probe.id))) {
      const clipboard = options.ownedTerminal.clipboard;
      context.withClipboardFixture = (work) => clipboard.profile === "ntilde-private-app-v1"
        ? clipboard.withClipboardFixture(probe.id, work, (event) => clipboardEvents.push(event))
        : clipboard.withClipboardFixture(work, (event) => clipboardEvents.push(event));
    }
    const capture = options.capture;
    if (capture) {
      context.capture = async (checkpoint) => {
        captureAttempted = true;
        const result = await capture({ featureId: probe.id, ...checkpoint });
        if (result.frame.role !== checkpoint.role || !/^sha256:[a-f0-9]{64}$/.test(result.frame.ref)) {
          throw new Error(`Capture adapter returned an invalid frame for ${probe.id} ${checkpoint.role}`);
        }
        captures.push(result);
        if (!batch.screenshotRefs.includes(result.frame.ref))
          batch.screenshotRefs.push(result.frame.ref);
        return result.frame;
      };
    }
    try {
      if (!probe.term)
        throw new Error(`No app callback for ${probe.id}`);
      const callback = probe.term;
      let result;
      try {
        result = await withTTYOperation(() => withTTYQueryTrace(queries, events, () => callback(context)), out);
      } finally {
        if (geometryCheck)
          geometryCheck.post = await readGeometry();
      }
      if (result.notTested) {
        const reason = result.notTested.reason;
        const noObservable = result.notTested.noObservable;
        if (result.response !== undefined) {
          batch.rawReplies[`${probe.id}.callbackResponse`] = result.response;
        }
        if (result.observation !== undefined || (result.assertions?.length ?? 0) > 0) {
          batch.ungradedDiagnostics[probe.id] = {
            kind: "collector-error",
            name: "Error",
            message: `Not-tested coverage for ${probe.id} arrived beside ${refusedClaimEvidence(result)}; a probe that claims no semantic observable cannot also carry a measurement, so the coverage claim is refused and its evidence stays a collector error`
          };
        } else if (reason !== "no-semantic-observable" || noObservable.trim().length === 0) {
          batch.ungradedDiagnostics[probe.id] = {
            kind: "collector-error",
            name: "Error",
            message: "Not-tested coverage for " + probe.id + " requires a closed reason and a specific noObservable"
          };
        } else {
          batch.notTested.push({ featureId: probe.id, reason, noObservable, rawReplyRef: probe.id });
        }
      } else if (result.observation) {
        if (result.response !== undefined) {
          batch.rawReplies[`${probe.id}.callbackResponse`] = result.response;
        }
        const rawReplyRef = queries.length || captureAttempted || clipboardEvents.length || result.observation.evidence === "none" ? probe.id : undefined;
        const post = geometryCheck?.post;
        const resized = preGeometry?.status === "measured" && (post?.status !== "measured" || post.rows !== preGeometry.rows || post.cols !== preGeometry.cols);
        batch.observations.push({
          featureId: probe.id,
          ...result.observation,
          ...resized ? {
            outcome: "inconclusive",
            reason: "insufficient-evidence",
            note: `Measured geometry changed or became unavailable after ${probe.id}`
          } : {},
          ...rawReplyRef ? { rawReplyRef } : {}
        });
        for (const assertion of resized ? [] : result.assertions ?? []) {
          batch.assertions.push({ featureId: probe.id, ...assertion, ...rawReplyRef ? { rawReplyRef } : {} });
        }
      } else {
        batch.ungradedDiagnostics[probe.id] = {
          kind: "legacy-callback",
          pass: result.pass,
          ...result.note ? { note: result.note } : {},
          ...result.response ? { response: result.response } : {}
        };
      }
    } catch (error) {
      const name = error instanceof Error ? error.name : "Error";
      const message = error instanceof Error ? error.message : String(error);
      const errorEvidence = name === "UndeclaredTerminalGeometry" ? undefined : captureAttempted ? "pixels" : probe.termObservationEvidence;
      if (errorEvidence) {
        batch.observations.push({
          featureId: probe.id,
          outcome: "error",
          reason: "collector-error",
          evidence: errorEvidence,
          note: message,
          ...queries.length || captureAttempted || clipboardEvents.length ? { rawReplyRef: probe.id } : {}
        });
      } else {
        batch.ungradedDiagnostics[probe.id] = { kind: "collector-error", name, message };
      }
    } finally {
      const trace = JSON.stringify({
        writes,
        queries,
        events,
        ...clipboardEvents.length ? { clipboard: clipboardEvents } : {},
        ...captureAttempted ? { captures } : {}
      });
      if (probe.id === "device.primary-da" || probe.id === "device.secondary-da" || probe.id === "device.xtversion") {
        const queriedRaw = queries.map((item) => item.raw).join("");
        const emittedNotTested = batch.notTested.some((entry) => entry.featureId === probe.id);
        batch.rawReplies[probe.id] = emittedNotTested && queriedRaw.length === 0 ? trace : queriedRaw;
        batch.rawReplies[`${probe.id}.trace`] = trace;
      } else {
        batch.rawReplies[probe.id] = trace;
      }
    }
  }
  if (options.ownedTerminal && ownedTerminalVerifiedFor(options.ownedTerminal, options.captureRunId ?? "", out)) {
    batch.rawReplies["collector.geometry"] = JSON.stringify({
      source: options.ownedTerminal?.geometrySource ?? "unavailable: no verified output device",
      bindingReceiptRef: "collector.terminalOwnership",
      grant: options.ownedTerminal.geometryAtGrant ?? null,
      corroboration: options.geometryCorroboration ?? null,
      checks: geometryChecks
    });
  }
  const observed = new Set(batch.observations.map((item) => item.featureId));
  const namedNotTested = new Set(batch.notTested.map((item) => item.featureId));
  batch.suiteComplete = expected.every((probe) => observed.has(probe.id) || namedNotTested.has(probe.id)) && Object.keys(batch.ungradedDiagnostics).length === 0;
  return batch;
}
var ALL_PROBES2;
var init_unified = __esm(() => {
  init_src();
  init_tty();
  init_owned_terminal();
  ALL_PROBES2 = ALL_PROBES.filter((p) => p.term !== null).map((p) => ({
    id: p.id,
    name: p.id
  }));
});

// src/serve.ts
import { createStyle } from "@silvery/ansi";
import { createServer } from "http";
import { mkdirSync as mkdirSync2, writeFileSync as writeFileSync2, unlinkSync, readdirSync, readFileSync as readFileSync4 } from "fs";
import { join as join2 } from "path";
import { homedir as homedir2 } from "os";
import { randomBytes, timingSafeEqual } from "crypto";
import { execFileSync as execFileSync3 } from "child_process";
import { dirname as dirname2 } from "path";
import { fileURLToPath } from "url";
function measuredExecutable(value) {
  if (!value || typeof value !== "object")
    throw new Error("Runtime provenance has no executable");
  const executable = value.executable;
  if (!executable || typeof executable !== "object")
    throw new Error("Runtime provenance has no executable");
  const { path, sha256 } = executable;
  if (typeof path !== "string" || !path.startsWith("/") || typeof sha256 !== "string" || !/^[0-9a-f]{64}$/.test(sha256)) {
    throw new Error("Runtime provenance has invalid measured executable");
  }
  return { path, sha256 };
}
function assertLoadedAppSuite(manifest, probeHash, location) {
  const actual = ALL_PROBES2.map((probe) => probe.id).sort();
  if (manifest.probeHash !== probeHash || JSON.stringify(manifest.probes.app) !== JSON.stringify(actual)) {
    throw new Error(`Loaded app probes disagree with suite declaration ${location}`);
  }
}
function getTrustedSuiteReceipt() {
  if (bundledSuite) {
    const { manifest, collectorRevision } = bundledSuite;
    if (!/^[0-9a-f]{12}$/.test(manifest.probeHash) || !/^[0-9a-f]{40}$/.test(collectorRevision)) {
      throw new Error("Compiled CLI has invalid suite or collector revision metadata");
    }
    assertLoadedAppSuite(manifest, manifest.probeHash, "compiled CLI receipt");
    if (process.env.TERMINFO_PROBE_HASH && process.env.TERMINFO_PROBE_HASH !== manifest.probeHash || process.env.TERMINFO_SOURCE_REVISION && process.env.TERMINFO_SOURCE_REVISION !== collectorRevision) {
      throw new Error("Runtime suite metadata disagrees with compiled CLI receipt");
    }
    return { manifest, collectorRevision };
  }
  const probeHash = process.env.TERMINFO_PROBE_HASH;
  const sourceRevision = process.env.TERMINFO_SOURCE_REVISION;
  if (!probeHash || !/^[0-9a-f]{12}$/.test(probeHash) || !sourceRevision || !/^[0-9a-f]{40}$/.test(sourceRevision)) {
    throw new Error("v2 collection requires TERMINFO_PROBE_HASH and TERMINFO_SOURCE_REVISION from a source-tree launcher");
  }
  const manifestPath = join2(SOURCE_ROOT, "content", "suites", `${probeHash}.json`);
  const manifest = JSON.parse(readFileSync4(manifestPath, "utf8"));
  assertLoadedAppSuite(manifest, probeHash, manifestPath);
  const revision = execFileSync3("git", ["rev-parse", "HEAD"], { cwd: SOURCE_ROOT, encoding: "utf8" }).trim();
  if (revision !== sourceRevision)
    throw new Error(`Collector revision differs from TERMINFO_SOURCE_REVISION`);
  const dirty = execFileSync3("git", [
    "status",
    "--porcelain",
    "--",
    "packages/probe-defs/src",
    "packages/terminfo.dev/src",
    "packages/terminfo.dev/package.json",
    "packages/run-parser/src",
    "packages/run-parser/package.json"
  ], {
    cwd: SOURCE_ROOT,
    encoding: "utf8"
  }).trim();
  if (dirty)
    throw new Error(`Collector source is uncommitted: ${dirty}`);
  return { manifest, collectorRevision: sourceRevision };
}
async function collectProbeRun(options = {}) {
  const out = options.out ?? process.stdout;
  const captureRunId = randomBytes(16).toString("hex");
  const terminal = detectTerminal();
  const { manifest, collectorRevision: sourceRevision } = getTrustedSuiteReceipt();
  const probeHash = manifest.probeHash;
  const captureDirectory = process.env.TERMINFO_CAPTURE_DIRECTORY;
  const clipboardReceipt = process.env.TERMINFO_CLIPBOARD_FIXTURE_RECEIPT;
  const provenancePath = process.env.TERMINFO_RUNTIME_PROVENANCE;
  if ((captureDirectory || clipboardReceipt) && !provenancePath) {
    throw new Error("Controlled Linux collection requires runtime provenance");
  }
  if (provenancePath && !captureDirectory && !clipboardReceipt) {
    throw new Error("Runtime provenance requires owned capture or clipboard");
  }
  const provenanceSource = provenancePath ? JSON.parse(readFileSync4(provenancePath, "utf8")) : undefined;
  const executable = provenanceSource ? measuredExecutable(provenanceSource) : undefined;
  if ((captureDirectory || clipboardReceipt) && !executable) {
    throw new Error("Controlled Linux collection lacks measured executable");
  }
  let capture;
  if (captureDirectory) {
    if (!executable)
      throw new Error("Configured Linux capture lacks measured executable");
    capture = await createLinuxCapture(captureDirectory, executable);
  }
  let ownedTerminal;
  if (options.ntildeOwner) {
    if (clipboardReceipt || options.terminalAppOwner) throw new Error("Conflicting Ntilde ownership");
    ownedTerminal = await createNtildeOwnedTerminal(options.ntildeOwner, captureRunId, out);
  }
  if (clipboardReceipt && options.terminalAppOwner) {
    throw new Error("Collection cannot have both Linux and Terminal.app owners");
  }
  if (clipboardReceipt) {
    if (!executable)
      throw new Error("Owned clipboard receipt lacks measured executable");
    ownedTerminal = await createOwnedTerminal({
      captureRunId,
      out,
      expectedLaunchRunId: process.env.TERMINFO_RUN_ID ?? "",
      linux: { receiptPath: clipboardReceipt, executable }
    });
  } else if (options.terminalAppOwner) {
    ownedTerminal = await createOwnedTerminal({
      captureRunId,
      out,
      expectedLaunchRunId: options.expectedLaunchRunId ?? process.env.TERMINFO_RUN_ID ?? "",
      terminalApp: options.terminalAppOwner
    });
  }
  const clipboard = options.ntildeOwner ? undefined : ownedTerminal?.clipboard;
  let batch, ntildeCollectionError, ntildeFinalizeError;
  let ntildeCollectionFailed = false, ntildeFinalizeFailed = false;
  try {
    batch = await withRawMode(async () => {
      let geometryCorroboration;
      let identityQuery;
      if (ownedTerminal) {
        const response = await queryWithSentinelOutcome("\x1B[18t", /\x1b\[8;([1-9][0-9]*);([1-9][0-9]*)t/, 700);
        const query = {
          sequence: "\x1B[18t",
          outbound: "\x1B[18t\x1B[c",
          reason: response.reason,
          raw: response.raw,
          rawBase64: response.rawBase64
        };
        if (response.match) {
          const rows = Number(response.match[1]);
          const cols = Number(response.match[2]);
          const grant = ownedTerminal.geometryAtGrant;
          const status = !Number.isSafeInteger(rows) || !Number.isSafeInteger(cols) ? "malformed" : grant?.status !== "measured" ? "uncorroborated" : rows === grant.rows && cols === grant.cols ? "agree" : "conflict";
          geometryCorroboration = { status, query, ...status !== "malformed" ? { rows, cols } : {} };
        } else {
          geometryCorroboration = {
            status: response.raw.includes("\x1B[8;") ? "malformed" : "silent",
            query
          };
        }
        const identity = await queryWithSentinelOutcome("\x1B[>0q", COMPLETE_XTVERSION, 700);
        identityQuery = {
          sequence: "\x1B[>0q",
          outbound: "\x1B[>0q\x1B[c",
          reason: identity.reason,
          raw: identity.raw,
          rawBase64: identity.rawBase64
        };
        resolveMeasuredAppVersion(terminal.name, terminal.version, { "collector.xtversion": identity.raw });
      }
      const result = await runProbeBatch({
        ids: options.ids,
        out,
        captureRunId,
        ...capture && { capture },
        ...ownedTerminal && { ownedTerminal },
        ...geometryCorroboration && { geometryCorroboration }
      });
      if (identityQuery) {
        result.rawReplies["collector.xtversion"] = identityQuery.raw;
        result.rawReplies["collector.xtversionQuery"] = JSON.stringify(identityQuery);
      }
      await drainStdin(1000);
      return result;
    }, out);
  } catch (error) { ntildeCollectionError = error; ntildeCollectionFailed = true; } finally {
    try { await ownedTerminal?.dispose(); } catch (error) { ntildeFinalizeError = error; ntildeFinalizeFailed = true; }
  }
  if (ntildeCollectionFailed && ntildeFinalizeFailed) throw new AggregateError([ntildeCollectionError, ntildeFinalizeError], "Ntilde collection and private finalization failed.");
  if (ntildeCollectionFailed) throw ntildeCollectionError;
  if (ntildeFinalizeFailed) throw ntildeFinalizeError;
  if (ownedTerminal)
    batch.rawReplies["collector.terminalOwnership"] = ownedTerminal.summary;
  if (options.ntildeOwner && ownedTerminal?.clipboard) batch.rawReplies["collector.ntildePrivateClipboard"] = ownedTerminal.clipboard.summary;
  if (clipboard)
    batch.rawReplies["collector.clipboardFixture"] = clipboard.summary;
  const target = {
    kind: "app",
    id: terminal.name,
    version: resolveMeasuredAppVersion(terminal.name, terminal.version, batch.rawReplies),
    os: terminal.os,
    osVersion: terminal.osVersion,
    outerTerminal: null,
    mux: null,
    config: null,
    permissions: null
  };
  const provenance = provenancePath ? parseRunProvenance(provenanceSource, target, { probeHash, sourceRevision }, provenancePath) : undefined;
  if (provenancePath && !provenance)
    throw new Error(`Missing runtime provenance in ${provenancePath}`);
  if (provenance)
    target.config = provenance.fixture.config;
  if (clipboard) {
    if (!provenance || provenance.fixture.config !== clipboard.config) {
      throw new Error("Owned clipboard profile config differs from runtime provenance");
    }
    if (clipboard.profile !== "default")
      target.permissions = clipboard.permissions;
  }
  return {
    schemaVersion: 2,
    runId: captureRunId,
    target,
    ...provenance && { provenance },
    identity: "unverified",
    suiteId: probeHash,
    probeHash,
    suiteComplete: batch.suiteComplete,
    sourceRevision,
    measuredAt: new Date().toISOString(),
    origin: { kind: "collector" },
    rawReplies: batch.rawReplies,
    assertions: batch.assertions,
    screenshotRefs: batch.screenshotRefs,
    observations: batch.observations,
    ...batch.notTested?.length ? { notTested: batch.notTested } : {},
    ungradedDiagnostics: batch.ungradedDiagnostics
  };
}
function register(info) {
  mkdirSync2(DAEMON_DIR, { recursive: true, mode: 448 });
  const filename = `${info.terminal}-${info.pid}.json`;
  const filepath = join2(DAEMON_DIR, filename);
  writeFileSync2(filepath, JSON.stringify(info, null, 2), { flag: "wx", mode: 384 });
  return filepath;
}
function unregister(filepath) {
  try {
    unlinkSync(filepath);
  } catch (err) {
    if (err.code === "ENOENT")
      return;
    throw new Error(`Could not remove daemon registration ${filepath}: ${err instanceof Error ? err.message : String(err)}`);
  }
}
function listDaemons() {
  let files;
  try {
    files = readdirSync(DAEMON_DIR).filter((f) => f.endsWith(".json"));
  } catch (err) {
    if (err.code === "ENOENT")
      return [];
    throw new Error(`Could not list daemon registrations in ${DAEMON_DIR}: ${err instanceof Error ? err.message : String(err)}`);
  }
  return files.map((file) => {
    const filepath = join2(DAEMON_DIR, file);
    try {
      const data = JSON.parse(readFileSync4(filepath, "utf-8"));
      if (!Number.isInteger(data.pid) || !Number.isInteger(data.port) || !/^[0-9a-f]{64}$/.test(data.token)) {
        throw new Error("missing or invalid pid, port, or token");
      }
      return data;
    } catch (err) {
      throw new Error(`Invalid daemon registration ${filepath}: ${err instanceof Error ? err.message : String(err)}`);
    }
  });
}
function startDaemon(port = 0) {
  let ids;
  if (process.env.TERMINFO_PROBE_IDS !== undefined) {
    let value;
    try {
      value = JSON.parse(process.env.TERMINFO_PROBE_IDS);
    } catch {
      throw new Error("Invalid TERMINFO_PROBE_IDS JSON");
    }
    if (!Array.isArray(value) || value.length === 0)
      throw new Error("TERMINFO_PROBE_IDS requires a nonempty array");
    const invalid = value.filter((id) => typeof id !== "string" || !ALL_PROBES2.some((probe) => probe.id === id));
    if (invalid.length)
      throw new Error(`Unknown or inapplicable TERMINFO_PROBE_IDS: ${JSON.stringify(invalid)}`);
    if (new Set(value).size !== value.length)
      throw new Error(`Duplicate TERMINFO_PROBE_IDS: ${JSON.stringify(value)}`);
    ids = value;
  }
  const terminal = detectTerminal();
  const token = randomBytes(32).toString("hex");
  const runId = process.env.TERMINFO_RUN_ID && /^[0-9a-f]{32}$/.test(process.env.TERMINFO_RUN_ID) ? process.env.TERMINFO_RUN_ID : randomBytes(16).toString("hex");
  const server = createServer((req, res) => {
    (async () => {
      res.setHeader("Content-Type", "application/json");
      const url = new URL(req.url ?? "/", `http://localhost`);
      const mutatesTTY = url.pathname === "/probe" || url.pathname === "/probe/single" || url.pathname === "/query";
      if (mutatesTTY) {
        const supplied = req.headers.authorization?.replace(/^Bearer /, "") ?? "";
        const expected = Buffer.from(token);
        const actual = Buffer.from(supplied);
        const authorized = actual.length === expected.length && timingSafeEqual(actual, expected);
        const origin = req.headers.origin;
        const sameOrigin = !origin || origin === `http://${req.headers.host}`;
        if (!authorized || !sameOrigin) {
          res.statusCode = 403;
          res.end(JSON.stringify({ error: "TTY mutation requires this daemon's token and same origin" }));
          return;
        }
      }
      if (url.pathname === "/info") {
        res.end(JSON.stringify({
          terminal: terminal.name,
          terminalVersion: terminal.version,
          pid: process.pid,
          runId,
          os: terminal.os,
          osVersion: terminal.osVersion,
          probes: "loaded-at-start"
        }));
        return;
      }
      if (url.pathname === "/probe") {
        let terminalAppOwner;
        if (req.method === "POST") {
          try {
            const body = JSON.parse(await readBody(req));
            if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).some((key) => key !== "terminalAppOwner")) {
              throw new Error("Invalid probe request shape");
            }
            if ("terminalAppOwner" in body)
              terminalAppOwner = parseTerminalAppOwner(body.terminalAppOwner);
            if (terminalAppOwner && (terminalAppOwner.launchRunId !== runId || terminalAppOwner.workerPid !== process.pid)) {
              throw new Error("Terminal.app owner assertion differs from this daemon's launch run or PID");
            }
          } catch {
            res.statusCode = 400;
            res.end(JSON.stringify({ error: "Invalid or mismatched Terminal.app owner assertion" }));
            return;
          }
        } else if (req.method !== "GET") {
          res.statusCode = 405;
          res.end(JSON.stringify({ error: "Probe collection requires GET or POST" }));
          return;
        }
        console.log(s.dim(`[${new Date().toISOString()}] Running ${ids?.length ?? ALL_PROBES2.length} probes...`));
        const run = await collectProbeRun({ ...ids && { ids }, terminalAppOwner, expectedLaunchRunId: runId });
        console.log(s.dim(`Collected ${run.observations.length}/${ALL_PROBES2.length} explicit observations; partial=${!run.suiteComplete}`));
        res.end(JSON.stringify(run));
        return;
      }
      if (url.pathname === "/probe/single") {
        const probeId = url.searchParams.get("id");
        if (!probeId) {
          res.statusCode = 400;
          res.end(JSON.stringify({ error: "Missing ?id= parameter" }));
          return;
        }
        const probes = ALL_PROBES2;
        const probe = probes.find((p) => p.id === probeId);
        if (!probe) {
          res.statusCode = 404;
          res.end(JSON.stringify({ error: `Unknown probe: ${probeId}` }));
          return;
        }
        res.end(JSON.stringify(await collectProbeRun({ ids: [probeId] })));
        return;
      }
      if (url.pathname === "/query" && req.method === "POST") {
        try {
          const body = await readBody(req);
          const { commands } = JSON.parse(body);
          if (!Array.isArray(commands)) {
            res.statusCode = 400;
            res.end(JSON.stringify({ error: "commands must be an array" }));
            return;
          }
          if (commands.length > 64 || commands.some((cmd) => typeof cmd !== "object" || cmd === null || cmd.write !== undefined && (typeof cmd.write !== "string" || cmd.write.length > 16384) || cmd.measure !== undefined && (typeof cmd.measure !== "string" || cmd.measure.length > 16384) || cmd.read !== undefined && (typeof cmd.read !== "string" || cmd.read.length > 512) || cmd.timeout !== undefined && (!Number.isInteger(cmd.timeout) || cmd.timeout < 1 || cmd.timeout > 5000))) {
            res.statusCode = 400;
            res.end(JSON.stringify({ error: "commands exceed count, size, or timeout limits" }));
            return;
          }
          const results = [];
          await withRawMode(async () => {
            process.stdout.write("\x1B[0m\x1B[2J\x1B[H");
            for (const cmd of commands) {
              try {
                if (cmd.measure) {
                  await Promise.resolve().then(() => init_tty());
                  const width = await measureRenderedWidth(cmd.measure);
                  results.push({ width });
                } else if (cmd.write && cmd.read) {
                  await Promise.resolve().then(() => init_tty());
                  const match = await query(unescapeSequence(cmd.write), new RegExp(cmd.read), cmd.timeout ?? 1000);
                  results.push({ response: match ? match[0] : null });
                } else if (cmd.write) {
                  process.stdout.write(unescapeSequence(cmd.write));
                  results.push({ response: "ok" });
                } else {
                  results.push({ error: "command needs write, read, or measure" });
                }
              } catch (err) {
                results.push({ error: err instanceof Error ? err.message : String(err) });
              }
            }
            process.stdout.write("\x1B[0m\x1B[2J\x1B[H");
            await drainStdin(500);
          });
          console.log(s.dim(`[${new Date().toISOString()}] Executed ${commands.length} commands`));
          res.end(JSON.stringify({ terminal: terminal.name, results }));
        } catch (err) {
          res.statusCode = err instanceof RangeError ? 413 : 400;
          res.end(JSON.stringify({ error: err instanceof Error ? err.message : String(err) }));
        }
        return;
      }
      res.end(JSON.stringify({
        endpoints: {
          "/info": "Terminal info",
          "/probe": "Run all probes loaded at daemon startup",
          "/probe/single?id=sgr.bold": "Run single probe",
          "/query": "POST \u2014 execute raw escape sequence commands"
        },
        terminal: terminal.name,
        version: terminal.version
      }));
    })().catch((err) => {
      console.error("Probe daemon request failed:", err);
      if (res.headersSent)
        res.destroy(err instanceof Error ? err : new Error(String(err)));
      else {
        res.statusCode = 500;
        res.end(JSON.stringify({ error: "Probe daemon request failed" }));
      }
    });
  });
  server.listen(port, "127.0.0.1", () => {
    const addr = server.address();
    if (!addr || typeof addr === "string")
      return;
    const actualPort = addr.port;
    const info = {
      pid: process.pid,
      port: actualPort,
      terminal: terminal.name,
      terminalVersion: terminal.version,
      os: terminal.os,
      osVersion: terminal.osVersion,
      started: new Date().toISOString(),
      token,
      runId
    };
    const filepath = register(info);
    console.log(s.yellow(`! Probe daemon listening on localhost:${actualPort}; stop with Ctrl+C when done.
`));
    console.log(`${s.bold("terminfo.dev")} daemon running
`);
    console.log(`  Terminal:  ${s.bold(terminal.name)} ${terminal.version}`);
    console.log(`  Port:      ${s.bold(String(actualPort))}`);
    console.log(`  Probes:    loaded at startup (restart after definitions change)`);
    console.log(``);
    console.log(`  Test:   use the registered daemon token to authorize /probe`);
    console.log(`  Info:   curl http://localhost:${actualPort}/info`);
    console.log(`  Single: /probe/single?id=sgr.bold (token required)`);
    const cleanup = () => {
      let exitCode = 0;
      try {
        unregister(filepath);
      } catch (err) {
        console.error(err);
        exitCode = 1;
      }
      server.close();
      process.exit(exitCode);
    };
    process.on("SIGINT", cleanup);
    process.on("SIGTERM", cleanup);
  });
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > 65536) {
        reject(new RangeError("Query body exceeds 64 KiB"));
      } else
        chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString()));
    req.on("error", reject);
  });
}
function unescapeSequence(s) {
  return s.replace(/\\x([0-9a-fA-F]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16))).replace(/\\e/g, "\x1B").replace(/\\n/g, `
`).replace(/\\r/g, "\r").replace(/\\t/g, "\t");
}
var s, DAEMON_DIR, SOURCE_ROOT, bundledSuite;
var init_serve = __esm(() => {
  init_detect();
  init_identity_guard();
  init_tty();
  init_unified();
  init_linux_capture();
  init_owned_terminal();
  init_src2();
  s = createStyle();
  DAEMON_DIR = join2(homedir2(), ".terminfo-dev", "daemons");
  SOURCE_ROOT = join2(dirname2(fileURLToPath(import.meta.url)), "..", "..", "..");
  bundledSuite = typeof { manifest: { probeHash: "16a690f34c0e", sourceRevision: "619aa6bc1db45a495a3fd76c4bff6bd277d6b991", generatedAt: "2026-10-05T03:42:22.579Z", adapterVersion: "4.0.0", probes: { app: ["charsets.dec-line-drawing", "charsets.dec-special", "charsets.g0-g1-switching", "charsets.utf8", "cursor.ansi-restore", "cursor.ansi-save", "cursor.cpl", "cursor.cud-past-bottom", "cursor.cup-boundaries", "cursor.cup-scroll-region", "cursor.cuu-past-top", "cursor.hide", "cursor.horizontal-absolute", "cursor.hpa", "cursor.move.absolute", "cursor.move.back", "cursor.move.down", "cursor.move.forward", "cursor.move.home", "cursor.move.up", "cursor.next-line", "cursor.position-report", "cursor.reverse-wrap", "cursor.save-restore", "cursor.shape", "cursor.vpa", "device.decrpm", "device.decrqss", "device.dsr-996-color-scheme", "device.primary-da", "device.secondary-da", "device.status-report", "device.term-features", "device.tertiary-da", "device.xtgettcap", "device.xtgetxres", "device.xtreportcolors", "device.xtversion", "device.xtwinops-14", "device.xtwinops-16", "device.xtwinops-18", "device.xtwinops-20", "device.xtwinops-21", "device.xtwinops-22", "device.xtwinops-23", "editing.deccara", "editing.deccra", "editing.decdc", "editing.decera", "editing.decfra", "editing.decic", "editing.decrara", "editing.decrqcra", "editing.decsace", "editing.decsera", "editing.delete-chars", "editing.delete-lines", "editing.insert-chars", "editing.insert-lines", "editing.repeat-char", "editing.sl", "editing.sr", "erase.character", "erase.ed-scroll-region", "erase.el-with-attrs", "erase.line.all", "erase.line.left", "erase.line.right", "erase.screen.above", "erase.screen.all", "erase.screen.below", "erase.screen.scrollback", "erase.selective", "extensions.iterm2-images", "extensions.kitty-graphics", "extensions.kitty-graphics.animation", "extensions.kitty-graphics.display", "extensions.kitty-graphics.transmit", "extensions.kitty-graphics.unicode-placeholders", "extensions.kitty-keyboard", "extensions.kitty-keyboard.disambiguate", "extensions.kitty-keyboard.report-all-keys", "extensions.kitty-keyboard.report-alternate", "extensions.kitty-keyboard.report-events", "extensions.kitty-keyboard.report-text", "extensions.notifications", "extensions.osc-633-vscode", "extensions.osc0-icon-title", "extensions.osc1-icon", "extensions.osc10-fg-color", "extensions.osc104-reset-palette", "extensions.osc11-bg-color", "extensions.osc110-reset-fg", "extensions.osc111-reset-bg", "extensions.osc112-reset-cursor", "extensions.osc113-reset-pointer-fg", "extensions.osc114-reset-pointer-bg", "extensions.osc117-reset-highlight-bg", "extensions.osc119-reset-highlight-fg", "extensions.osc12-cursor-color", "extensions.osc133-a", "extensions.osc133-b", "extensions.osc133-c", "extensions.osc133-d", "extensions.osc133-p", "extensions.osc1337-capabilities", "extensions.osc1337-cellsize", "extensions.osc17-highlight-bg", "extensions.osc176-app-id", "extensions.osc19-highlight-fg", "extensions.osc2-title", "extensions.osc21-kitty-color", "extensions.osc22-pointer", "extensions.osc30001-color-stack-push", "extensions.osc3008-context", "extensions.osc30101-color-stack-pop", "extensions.osc4-palette", "extensions.osc440-audio", "extensions.osc5-special-color", "extensions.osc52-clipboard", "extensions.osc52-read", "extensions.osc52-write", "extensions.osc5522-clipboard", "extensions.osc555-flash", "extensions.osc633-a", "extensions.osc633-b", "extensions.osc633-c", "extensions.osc633-d", "extensions.osc633-e", "extensions.osc633-p", "extensions.osc66-text-sizing", "extensions.osc666-termprop", "extensions.osc7-cwd", "extensions.osc701-locale", "extensions.osc702-version", "extensions.osc710-font-normal", "extensions.osc720-scroll-up", "extensions.osc776-cell-size", "extensions.osc777-notify", "extensions.osc7770-font-size", "extensions.osc7777-font-window-size", "extensions.osc8", "extensions.osc9-progress", "extensions.osc99-kitty-notify", "extensions.reflow", "extensions.semantic-prompts", "extensions.sixel", "extensions.sixel-da1", "extensions.sixel-geometry-report", "extensions.truecolor", "input.button-event-mouse", "input.csi-u", "input.modify-other-keys", "input.modify-other-keys-3", "input.pixel-mouse", "input.urxvt-mouse", "input.x10-mouse", "modes.alt-screen.enter", "modes.alt-screen.exit", "modes.alt-scroll-1007", "modes.altscreen-1047", "modes.altscreen-1048", "modes.altscreen-47", "modes.application-cursor", "modes.application-keypad", "modes.auto-wrap", "modes.bracketed-paste", "modes.color-scheme-reporting", "modes.deccolm", "modes.decsclm", "modes.focus-tracking", "modes.insert-replace", "modes.left-right-margin", "modes.mouse-all", "modes.mouse-sgr", "modes.mouse-tracking", "modes.origin", "modes.reverse-video", "modes.synchronized-output", "modes.utf8-mouse-1005", "modes.xtpopcolors", "modes.xtpopsgr", "modes.xtpushcolors", "modes.xtpushsgr", "modes.xtrestore", "modes.xtsave", "reset.decaln", "reset.method", "reset.ris", "reset.sgr", "reset.soft", "scrollback.accumulate", "scrollback.alt-screen", "scrollback.decstbm", "scrollback.decstbm-reset", "scrollback.reverse-index", "scrollback.scroll-down", "scrollback.scroll-up", "scrollback.set-region", "scrollback.total-lines", "sgr.bg.256", "sgr.bg.bright", "sgr.bg.default", "sgr.bg.standard", "sgr.bg.truecolor", "sgr.blink", "sgr.bold", "sgr.faint", "sgr.fg.256", "sgr.fg.bright", "sgr.fg.default", "sgr.fg.standard", "sgr.fg.truecolor", "sgr.hidden", "sgr.inverse", "sgr.italic", "sgr.overline", "sgr.reset", "sgr.selective-reset.bold", "sgr.selective-reset.inverse", "sgr.selective-reset.italic", "sgr.selective-reset.underline", "sgr.strikethrough", "sgr.underline-color-indexed", "sgr.underline-color-reset", "sgr.underline-color-rgb", "sgr.underline.color", "sgr.underline.curly", "sgr.underline.dashed", "sgr.underline.dotted", "sgr.underline.double", "sgr.underline.single", "text.backspace", "text.basic", "text.cbt", "text.cht", "text.combining", "text.cr", "text.hts", "text.index", "text.newline", "text.next-line", "text.overwrite", "text.reverse-index-scroll", "text.tab", "text.tbc", "text.wide.cjk", "text.wide.emoji", "text.wide.emoji-flags", "text.wide.emoji-vs16", "text.wide.emoji-zwj", "text.wrap", "unicode.east-asian-ambiguous", "unicode.grapheme-cursor", "unicode.tab-stops", "unicode.wrap-boundary"], headless: ["charsets.dec-line-drawing", "charsets.dec-special", "charsets.g0-g1-switching", "charsets.utf8", "cursor.ansi-restore", "cursor.ansi-save", "cursor.cpl", "cursor.cud-past-bottom", "cursor.cup-boundaries", "cursor.cup-scroll-region", "cursor.cuu-past-top", "cursor.hide", "cursor.horizontal-absolute", "cursor.hpa", "cursor.move.absolute", "cursor.move.back", "cursor.move.down", "cursor.move.forward", "cursor.move.home", "cursor.move.up", "cursor.next-line", "cursor.position-report", "cursor.reverse-wrap", "cursor.save-restore", "cursor.shape", "cursor.vpa", "device.decrpm", "device.decrqss", "device.dsr-996-color-scheme", "device.primary-da", "device.secondary-da", "device.status-report", "device.tertiary-da", "device.xtgettcap", "device.xtgetxres", "device.xtreportcolors", "device.xtversion", "device.xtwinops-14", "device.xtwinops-16", "device.xtwinops-18", "device.xtwinops-20", "device.xtwinops-21", "device.xtwinops-22", "device.xtwinops-23", "editing.deccara", "editing.deccra", "editing.decdc", "editing.decera", "editing.decfra", "editing.decic", "editing.decrara", "editing.decrqcra", "editing.decsace", "editing.decsera", "editing.delete-chars", "editing.delete-lines", "editing.insert-chars", "editing.insert-lines", "editing.repeat-char", "editing.sl", "editing.sr", "erase.character", "erase.ed-scroll-region", "erase.el-with-attrs", "erase.line.all", "erase.line.left", "erase.line.right", "erase.screen.above", "erase.screen.all", "erase.screen.below", "erase.screen.scrollback", "erase.selective", "extensions.iterm2-images", "extensions.kitty-graphics", "extensions.kitty-graphics.animation", "extensions.kitty-graphics.display", "extensions.kitty-graphics.transmit", "extensions.kitty-graphics.unicode-placeholders", "extensions.kitty-keyboard", "extensions.kitty-keyboard.disambiguate", "extensions.kitty-keyboard.report-all-keys", "extensions.kitty-keyboard.report-alternate", "extensions.kitty-keyboard.report-events", "extensions.kitty-keyboard.report-text", "extensions.notifications", "extensions.osc-633-vscode", "extensions.osc0-icon-title", "extensions.osc1-icon", "extensions.osc10-fg-color", "extensions.osc104-reset-palette", "extensions.osc11-bg-color", "extensions.osc110-reset-fg", "extensions.osc111-reset-bg", "extensions.osc112-reset-cursor", "extensions.osc113-reset-pointer-fg", "extensions.osc114-reset-pointer-bg", "extensions.osc117-reset-highlight-bg", "extensions.osc119-reset-highlight-fg", "extensions.osc12-cursor-color", "extensions.osc133-a", "extensions.osc133-b", "extensions.osc133-c", "extensions.osc133-d", "extensions.osc133-p", "extensions.osc1337-capabilities", "extensions.osc1337-cellsize", "extensions.osc17-highlight-bg", "extensions.osc19-highlight-fg", "extensions.osc2-title", "extensions.osc21-kitty-color", "extensions.osc30001-color-stack-push", "extensions.osc30101-color-stack-pop", "extensions.osc4-palette", "extensions.osc5-special-color", "extensions.osc52-clipboard", "extensions.osc52-read", "extensions.osc52-write", "extensions.osc5522-clipboard", "extensions.osc633-a", "extensions.osc633-b", "extensions.osc633-c", "extensions.osc633-d", "extensions.osc633-e", "extensions.osc633-p", "extensions.osc66-text-sizing", "extensions.osc7-cwd", "extensions.osc701-locale", "extensions.osc702-version", "extensions.osc720-scroll-up", "extensions.osc776-cell-size", "extensions.osc7770-font-size", "extensions.osc7777-font-window-size", "extensions.osc8", "extensions.reflow", "extensions.semantic-prompts", "extensions.sixel", "extensions.sixel-da1", "extensions.sixel-geometry-report", "extensions.truecolor", "input.button-event-mouse", "input.csi-u", "input.modify-other-keys", "input.modify-other-keys-3", "input.pixel-mouse", "input.urxvt-mouse", "input.x10-mouse", "modes.alt-screen.enter", "modes.alt-screen.exit", "modes.alt-scroll-1007", "modes.altscreen-1047", "modes.altscreen-1048", "modes.altscreen-47", "modes.application-cursor", "modes.application-keypad", "modes.auto-wrap", "modes.bracketed-paste", "modes.color-scheme-reporting", "modes.deccolm", "modes.decsclm", "modes.focus-tracking", "modes.insert-replace", "modes.left-right-margin", "modes.mouse-all", "modes.mouse-sgr", "modes.mouse-tracking", "modes.origin", "modes.reverse-video", "modes.synchronized-output", "modes.utf8-mouse-1005", "modes.xtpopcolors", "modes.xtpopsgr", "modes.xtpushcolors", "modes.xtpushsgr", "modes.xtrestore", "modes.xtsave", "reset.decaln", "reset.method", "reset.ris", "reset.sgr", "reset.soft", "scrollback.accumulate", "scrollback.alt-screen", "scrollback.decstbm", "scrollback.decstbm-reset", "scrollback.reverse-index", "scrollback.scroll-down", "scrollback.scroll-up", "scrollback.set-region", "scrollback.total-lines", "sgr.bg.256", "sgr.bg.bright", "sgr.bg.default", "sgr.bg.standard", "sgr.bg.truecolor", "sgr.blink", "sgr.bold", "sgr.faint", "sgr.fg.256", "sgr.fg.bright", "sgr.fg.default", "sgr.fg.standard", "sgr.fg.truecolor", "sgr.hidden", "sgr.inverse", "sgr.italic", "sgr.overline", "sgr.reset", "sgr.selective-reset.bold", "sgr.selective-reset.inverse", "sgr.selective-reset.italic", "sgr.selective-reset.underline", "sgr.strikethrough", "sgr.underline-color-indexed", "sgr.underline-color-reset", "sgr.underline-color-rgb", "sgr.underline.color", "sgr.underline.curly", "sgr.underline.dashed", "sgr.underline.dotted", "sgr.underline.double", "sgr.underline.single", "text.backspace", "text.basic", "text.cbt", "text.cht", "text.combining", "text.cr", "text.hts", "text.index", "text.newline", "text.next-line", "text.overwrite", "text.reverse-index-scroll", "text.tab", "text.tbc", "text.wide.cjk", "text.wide.emoji", "text.wide.emoji-flags", "text.wide.emoji-vs16", "text.wide.emoji-zwj", "text.wrap", "unicode.east-asian-ambiguous", "unicode.grapheme-cursor", "unicode.tab-stops", "unicode.wrap-boundary"], mux: ["charsets.dec-line-drawing", "charsets.dec-special", "charsets.g0-g1-switching", "charsets.utf8", "cursor.ansi-restore", "cursor.ansi-save", "cursor.cpl", "cursor.cud-past-bottom", "cursor.cup-boundaries", "cursor.cup-scroll-region", "cursor.cuu-past-top", "cursor.hide", "cursor.horizontal-absolute", "cursor.hpa", "cursor.move.absolute", "cursor.move.back", "cursor.move.down", "cursor.move.forward", "cursor.move.home", "cursor.move.up", "cursor.next-line", "cursor.position-report", "cursor.reverse-wrap", "cursor.save-restore", "cursor.shape", "cursor.vpa", "device.decrpm", "device.decrqss", "device.dsr-996-color-scheme", "device.primary-da", "device.secondary-da", "device.status-report", "device.term-features", "device.tertiary-da", "device.xtgettcap", "device.xtgetxres", "device.xtreportcolors", "device.xtversion", "device.xtwinops-14", "device.xtwinops-16", "device.xtwinops-18", "device.xtwinops-20", "device.xtwinops-21", "device.xtwinops-22", "device.xtwinops-23", "editing.deccara", "editing.deccra", "editing.decdc", "editing.decera", "editing.decfra", "editing.decic", "editing.decrara", "editing.decrqcra", "editing.decsace", "editing.decsera", "editing.delete-chars", "editing.delete-lines", "editing.insert-chars", "editing.insert-lines", "editing.repeat-char", "editing.sl", "editing.sr", "erase.character", "erase.ed-scroll-region", "erase.el-with-attrs", "erase.line.all", "erase.line.left", "erase.line.right", "erase.screen.above", "erase.screen.all", "erase.screen.below", "erase.screen.scrollback", "erase.selective", "extensions.iterm2-images", "extensions.kitty-graphics", "extensions.kitty-graphics.animation", "extensions.kitty-graphics.display", "extensions.kitty-graphics.transmit", "extensions.kitty-graphics.unicode-placeholders", "extensions.kitty-keyboard", "extensions.kitty-keyboard.disambiguate", "extensions.kitty-keyboard.report-all-keys", "extensions.kitty-keyboard.report-alternate", "extensions.kitty-keyboard.report-events", "extensions.kitty-keyboard.report-text", "extensions.notifications", "extensions.osc-633-vscode", "extensions.osc0-icon-title", "extensions.osc1-icon", "extensions.osc10-fg-color", "extensions.osc104-reset-palette", "extensions.osc11-bg-color", "extensions.osc110-reset-fg", "extensions.osc111-reset-bg", "extensions.osc112-reset-cursor", "extensions.osc113-reset-pointer-fg", "extensions.osc114-reset-pointer-bg", "extensions.osc117-reset-highlight-bg", "extensions.osc119-reset-highlight-fg", "extensions.osc12-cursor-color", "extensions.osc133-a", "extensions.osc133-b", "extensions.osc133-c", "extensions.osc133-d", "extensions.osc133-p", "extensions.osc1337-capabilities", "extensions.osc1337-cellsize", "extensions.osc17-highlight-bg", "extensions.osc176-app-id", "extensions.osc19-highlight-fg", "extensions.osc2-title", "extensions.osc21-kitty-color", "extensions.osc22-pointer", "extensions.osc30001-color-stack-push", "extensions.osc3008-context", "extensions.osc30101-color-stack-pop", "extensions.osc4-palette", "extensions.osc440-audio", "extensions.osc5-special-color", "extensions.osc52-clipboard", "extensions.osc52-read", "extensions.osc52-write", "extensions.osc5522-clipboard", "extensions.osc555-flash", "extensions.osc633-a", "extensions.osc633-b", "extensions.osc633-c", "extensions.osc633-d", "extensions.osc633-e", "extensions.osc633-p", "extensions.osc66-text-sizing", "extensions.osc666-termprop", "extensions.osc7-cwd", "extensions.osc701-locale", "extensions.osc702-version", "extensions.osc710-font-normal", "extensions.osc720-scroll-up", "extensions.osc776-cell-size", "extensions.osc777-notify", "extensions.osc7770-font-size", "extensions.osc7777-font-window-size", "extensions.osc8", "extensions.osc9-progress", "extensions.osc99-kitty-notify", "extensions.reflow", "extensions.semantic-prompts", "extensions.sixel", "extensions.sixel-da1", "extensions.sixel-geometry-report", "extensions.truecolor", "input.button-event-mouse", "input.csi-u", "input.modify-other-keys", "input.modify-other-keys-3", "input.pixel-mouse", "input.urxvt-mouse", "input.x10-mouse", "modes.alt-screen.enter", "modes.alt-screen.exit", "modes.alt-scroll-1007", "modes.altscreen-1047", "modes.altscreen-1048", "modes.altscreen-47", "modes.application-cursor", "modes.application-keypad", "modes.auto-wrap", "modes.bracketed-paste", "modes.color-scheme-reporting", "modes.deccolm", "modes.decsclm", "modes.focus-tracking", "modes.insert-replace", "modes.left-right-margin", "modes.mouse-all", "modes.mouse-sgr", "modes.mouse-tracking", "modes.origin", "modes.reverse-video", "modes.synchronized-output", "modes.utf8-mouse-1005", "modes.xtpopcolors", "modes.xtpopsgr", "modes.xtpushcolors", "modes.xtpushsgr", "modes.xtrestore", "modes.xtsave", "reset.decaln", "reset.method", "reset.ris", "reset.sgr", "reset.soft", "scrollback.accumulate", "scrollback.alt-screen", "scrollback.decstbm", "scrollback.decstbm-reset", "scrollback.reverse-index", "scrollback.scroll-down", "scrollback.scroll-up", "scrollback.set-region", "scrollback.total-lines", "sgr.bg.256", "sgr.bg.bright", "sgr.bg.default", "sgr.bg.standard", "sgr.bg.truecolor", "sgr.blink", "sgr.bold", "sgr.faint", "sgr.fg.256", "sgr.fg.bright", "sgr.fg.default", "sgr.fg.standard", "sgr.fg.truecolor", "sgr.hidden", "sgr.inverse", "sgr.italic", "sgr.overline", "sgr.reset", "sgr.selective-reset.bold", "sgr.selective-reset.inverse", "sgr.selective-reset.italic", "sgr.selective-reset.underline", "sgr.strikethrough", "sgr.underline-color-indexed", "sgr.underline-color-reset", "sgr.underline-color-rgb", "sgr.underline.color", "sgr.underline.curly", "sgr.underline.dashed", "sgr.underline.dotted", "sgr.underline.double", "sgr.underline.single", "text.backspace", "text.basic", "text.cbt", "text.cht", "text.combining", "text.cr", "text.hts", "text.index", "text.newline", "text.next-line", "text.overwrite", "text.reverse-index-scroll", "text.tab", "text.tbc", "text.wide.cjk", "text.wide.emoji", "text.wide.emoji-flags", "text.wide.emoji-vs16", "text.wide.emoji-zwj", "text.wrap", "unicode.east-asian-ambiguous", "unicode.grapheme-cursor", "unicode.tab-stops", "unicode.wrap-boundary"] } }, collectorRevision: "cf7d8759c7e637aa8dba1e429f3dddd1c0124158" } === "undefined" ? null : { manifest: { probeHash: "16a690f34c0e", sourceRevision: "619aa6bc1db45a495a3fd76c4bff6bd277d6b991", generatedAt: "2026-10-05T03:42:22.579Z", adapterVersion: "4.0.0", probes: { app: ["charsets.dec-line-drawing", "charsets.dec-special", "charsets.g0-g1-switching", "charsets.utf8", "cursor.ansi-restore", "cursor.ansi-save", "cursor.cpl", "cursor.cud-past-bottom", "cursor.cup-boundaries", "cursor.cup-scroll-region", "cursor.cuu-past-top", "cursor.hide", "cursor.horizontal-absolute", "cursor.hpa", "cursor.move.absolute", "cursor.move.back", "cursor.move.down", "cursor.move.forward", "cursor.move.home", "cursor.move.up", "cursor.next-line", "cursor.position-report", "cursor.reverse-wrap", "cursor.save-restore", "cursor.shape", "cursor.vpa", "device.decrpm", "device.decrqss", "device.dsr-996-color-scheme", "device.primary-da", "device.secondary-da", "device.status-report", "device.term-features", "device.tertiary-da", "device.xtgettcap", "device.xtgetxres", "device.xtreportcolors", "device.xtversion", "device.xtwinops-14", "device.xtwinops-16", "device.xtwinops-18", "device.xtwinops-20", "device.xtwinops-21", "device.xtwinops-22", "device.xtwinops-23", "editing.deccara", "editing.deccra", "editing.decdc", "editing.decera", "editing.decfra", "editing.decic", "editing.decrara", "editing.decrqcra", "editing.decsace", "editing.decsera", "editing.delete-chars", "editing.delete-lines", "editing.insert-chars", "editing.insert-lines", "editing.repeat-char", "editing.sl", "editing.sr", "erase.character", "erase.ed-scroll-region", "erase.el-with-attrs", "erase.line.all", "erase.line.left", "erase.line.right", "erase.screen.above", "erase.screen.all", "erase.screen.below", "erase.screen.scrollback", "erase.selective", "extensions.iterm2-images", "extensions.kitty-graphics", "extensions.kitty-graphics.animation", "extensions.kitty-graphics.display", "extensions.kitty-graphics.transmit", "extensions.kitty-graphics.unicode-placeholders", "extensions.kitty-keyboard", "extensions.kitty-keyboard.disambiguate", "extensions.kitty-keyboard.report-all-keys", "extensions.kitty-keyboard.report-alternate", "extensions.kitty-keyboard.report-events", "extensions.kitty-keyboard.report-text", "extensions.notifications", "extensions.osc-633-vscode", "extensions.osc0-icon-title", "extensions.osc1-icon", "extensions.osc10-fg-color", "extensions.osc104-reset-palette", "extensions.osc11-bg-color", "extensions.osc110-reset-fg", "extensions.osc111-reset-bg", "extensions.osc112-reset-cursor", "extensions.osc113-reset-pointer-fg", "extensions.osc114-reset-pointer-bg", "extensions.osc117-reset-highlight-bg", "extensions.osc119-reset-highlight-fg", "extensions.osc12-cursor-color", "extensions.osc133-a", "extensions.osc133-b", "extensions.osc133-c", "extensions.osc133-d", "extensions.osc133-p", "extensions.osc1337-capabilities", "extensions.osc1337-cellsize", "extensions.osc17-highlight-bg", "extensions.osc176-app-id", "extensions.osc19-highlight-fg", "extensions.osc2-title", "extensions.osc21-kitty-color", "extensions.osc22-pointer", "extensions.osc30001-color-stack-push", "extensions.osc3008-context", "extensions.osc30101-color-stack-pop", "extensions.osc4-palette", "extensions.osc440-audio", "extensions.osc5-special-color", "extensions.osc52-clipboard", "extensions.osc52-read", "extensions.osc52-write", "extensions.osc5522-clipboard", "extensions.osc555-flash", "extensions.osc633-a", "extensions.osc633-b", "extensions.osc633-c", "extensions.osc633-d", "extensions.osc633-e", "extensions.osc633-p", "extensions.osc66-text-sizing", "extensions.osc666-termprop", "extensions.osc7-cwd", "extensions.osc701-locale", "extensions.osc702-version", "extensions.osc710-font-normal", "extensions.osc720-scroll-up", "extensions.osc776-cell-size", "extensions.osc777-notify", "extensions.osc7770-font-size", "extensions.osc7777-font-window-size", "extensions.osc8", "extensions.osc9-progress", "extensions.osc99-kitty-notify", "extensions.reflow", "extensions.semantic-prompts", "extensions.sixel", "extensions.sixel-da1", "extensions.sixel-geometry-report", "extensions.truecolor", "input.button-event-mouse", "input.csi-u", "input.modify-other-keys", "input.modify-other-keys-3", "input.pixel-mouse", "input.urxvt-mouse", "input.x10-mouse", "modes.alt-screen.enter", "modes.alt-screen.exit", "modes.alt-scroll-1007", "modes.altscreen-1047", "modes.altscreen-1048", "modes.altscreen-47", "modes.application-cursor", "modes.application-keypad", "modes.auto-wrap", "modes.bracketed-paste", "modes.color-scheme-reporting", "modes.deccolm", "modes.decsclm", "modes.focus-tracking", "modes.insert-replace", "modes.left-right-margin", "modes.mouse-all", "modes.mouse-sgr", "modes.mouse-tracking", "modes.origin", "modes.reverse-video", "modes.synchronized-output", "modes.utf8-mouse-1005", "modes.xtpopcolors", "modes.xtpopsgr", "modes.xtpushcolors", "modes.xtpushsgr", "modes.xtrestore", "modes.xtsave", "reset.decaln", "reset.method", "reset.ris", "reset.sgr", "reset.soft", "scrollback.accumulate", "scrollback.alt-screen", "scrollback.decstbm", "scrollback.decstbm-reset", "scrollback.reverse-index", "scrollback.scroll-down", "scrollback.scroll-up", "scrollback.set-region", "scrollback.total-lines", "sgr.bg.256", "sgr.bg.bright", "sgr.bg.default", "sgr.bg.standard", "sgr.bg.truecolor", "sgr.blink", "sgr.bold", "sgr.faint", "sgr.fg.256", "sgr.fg.bright", "sgr.fg.default", "sgr.fg.standard", "sgr.fg.truecolor", "sgr.hidden", "sgr.inverse", "sgr.italic", "sgr.overline", "sgr.reset", "sgr.selective-reset.bold", "sgr.selective-reset.inverse", "sgr.selective-reset.italic", "sgr.selective-reset.underline", "sgr.strikethrough", "sgr.underline-color-indexed", "sgr.underline-color-reset", "sgr.underline-color-rgb", "sgr.underline.color", "sgr.underline.curly", "sgr.underline.dashed", "sgr.underline.dotted", "sgr.underline.double", "sgr.underline.single", "text.backspace", "text.basic", "text.cbt", "text.cht", "text.combining", "text.cr", "text.hts", "text.index", "text.newline", "text.next-line", "text.overwrite", "text.reverse-index-scroll", "text.tab", "text.tbc", "text.wide.cjk", "text.wide.emoji", "text.wide.emoji-flags", "text.wide.emoji-vs16", "text.wide.emoji-zwj", "text.wrap", "unicode.east-asian-ambiguous", "unicode.grapheme-cursor", "unicode.tab-stops", "unicode.wrap-boundary"], headless: ["charsets.dec-line-drawing", "charsets.dec-special", "charsets.g0-g1-switching", "charsets.utf8", "cursor.ansi-restore", "cursor.ansi-save", "cursor.cpl", "cursor.cud-past-bottom", "cursor.cup-boundaries", "cursor.cup-scroll-region", "cursor.cuu-past-top", "cursor.hide", "cursor.horizontal-absolute", "cursor.hpa", "cursor.move.absolute", "cursor.move.back", "cursor.move.down", "cursor.move.forward", "cursor.move.home", "cursor.move.up", "cursor.next-line", "cursor.position-report", "cursor.reverse-wrap", "cursor.save-restore", "cursor.shape", "cursor.vpa", "device.decrpm", "device.decrqss", "device.dsr-996-color-scheme", "device.primary-da", "device.secondary-da", "device.status-report", "device.tertiary-da", "device.xtgettcap", "device.xtgetxres", "device.xtreportcolors", "device.xtversion", "device.xtwinops-14", "device.xtwinops-16", "device.xtwinops-18", "device.xtwinops-20", "device.xtwinops-21", "device.xtwinops-22", "device.xtwinops-23", "editing.deccara", "editing.deccra", "editing.decdc", "editing.decera", "editing.decfra", "editing.decic", "editing.decrara", "editing.decrqcra", "editing.decsace", "editing.decsera", "editing.delete-chars", "editing.delete-lines", "editing.insert-chars", "editing.insert-lines", "editing.repeat-char", "editing.sl", "editing.sr", "erase.character", "erase.ed-scroll-region", "erase.el-with-attrs", "erase.line.all", "erase.line.left", "erase.line.right", "erase.screen.above", "erase.screen.all", "erase.screen.below", "erase.screen.scrollback", "erase.selective", "extensions.iterm2-images", "extensions.kitty-graphics", "extensions.kitty-graphics.animation", "extensions.kitty-graphics.display", "extensions.kitty-graphics.transmit", "extensions.kitty-graphics.unicode-placeholders", "extensions.kitty-keyboard", "extensions.kitty-keyboard.disambiguate", "extensions.kitty-keyboard.report-all-keys", "extensions.kitty-keyboard.report-alternate", "extensions.kitty-keyboard.report-events", "extensions.kitty-keyboard.report-text", "extensions.notifications", "extensions.osc-633-vscode", "extensions.osc0-icon-title", "extensions.osc1-icon", "extensions.osc10-fg-color", "extensions.osc104-reset-palette", "extensions.osc11-bg-color", "extensions.osc110-reset-fg", "extensions.osc111-reset-bg", "extensions.osc112-reset-cursor", "extensions.osc113-reset-pointer-fg", "extensions.osc114-reset-pointer-bg", "extensions.osc117-reset-highlight-bg", "extensions.osc119-reset-highlight-fg", "extensions.osc12-cursor-color", "extensions.osc133-a", "extensions.osc133-b", "extensions.osc133-c", "extensions.osc133-d", "extensions.osc133-p", "extensions.osc1337-capabilities", "extensions.osc1337-cellsize", "extensions.osc17-highlight-bg", "extensions.osc19-highlight-fg", "extensions.osc2-title", "extensions.osc21-kitty-color", "extensions.osc30001-color-stack-push", "extensions.osc30101-color-stack-pop", "extensions.osc4-palette", "extensions.osc5-special-color", "extensions.osc52-clipboard", "extensions.osc52-read", "extensions.osc52-write", "extensions.osc5522-clipboard", "extensions.osc633-a", "extensions.osc633-b", "extensions.osc633-c", "extensions.osc633-d", "extensions.osc633-e", "extensions.osc633-p", "extensions.osc66-text-sizing", "extensions.osc7-cwd", "extensions.osc701-locale", "extensions.osc702-version", "extensions.osc720-scroll-up", "extensions.osc776-cell-size", "extensions.osc7770-font-size", "extensions.osc7777-font-window-size", "extensions.osc8", "extensions.reflow", "extensions.semantic-prompts", "extensions.sixel", "extensions.sixel-da1", "extensions.sixel-geometry-report", "extensions.truecolor", "input.button-event-mouse", "input.csi-u", "input.modify-other-keys", "input.modify-other-keys-3", "input.pixel-mouse", "input.urxvt-mouse", "input.x10-mouse", "modes.alt-screen.enter", "modes.alt-screen.exit", "modes.alt-scroll-1007", "modes.altscreen-1047", "modes.altscreen-1048", "modes.altscreen-47", "modes.application-cursor", "modes.application-keypad", "modes.auto-wrap", "modes.bracketed-paste", "modes.color-scheme-reporting", "modes.deccolm", "modes.decsclm", "modes.focus-tracking", "modes.insert-replace", "modes.left-right-margin", "modes.mouse-all", "modes.mouse-sgr", "modes.mouse-tracking", "modes.origin", "modes.reverse-video", "modes.synchronized-output", "modes.utf8-mouse-1005", "modes.xtpopcolors", "modes.xtpopsgr", "modes.xtpushcolors", "modes.xtpushsgr", "modes.xtrestore", "modes.xtsave", "reset.decaln", "reset.method", "reset.ris", "reset.sgr", "reset.soft", "scrollback.accumulate", "scrollback.alt-screen", "scrollback.decstbm", "scrollback.decstbm-reset", "scrollback.reverse-index", "scrollback.scroll-down", "scrollback.scroll-up", "scrollback.set-region", "scrollback.total-lines", "sgr.bg.256", "sgr.bg.bright", "sgr.bg.default", "sgr.bg.standard", "sgr.bg.truecolor", "sgr.blink", "sgr.bold", "sgr.faint", "sgr.fg.256", "sgr.fg.bright", "sgr.fg.default", "sgr.fg.standard", "sgr.fg.truecolor", "sgr.hidden", "sgr.inverse", "sgr.italic", "sgr.overline", "sgr.reset", "sgr.selective-reset.bold", "sgr.selective-reset.inverse", "sgr.selective-reset.italic", "sgr.selective-reset.underline", "sgr.strikethrough", "sgr.underline-color-indexed", "sgr.underline-color-reset", "sgr.underline-color-rgb", "sgr.underline.color", "sgr.underline.curly", "sgr.underline.dashed", "sgr.underline.dotted", "sgr.underline.double", "sgr.underline.single", "text.backspace", "text.basic", "text.cbt", "text.cht", "text.combining", "text.cr", "text.hts", "text.index", "text.newline", "text.next-line", "text.overwrite", "text.reverse-index-scroll", "text.tab", "text.tbc", "text.wide.cjk", "text.wide.emoji", "text.wide.emoji-flags", "text.wide.emoji-vs16", "text.wide.emoji-zwj", "text.wrap", "unicode.east-asian-ambiguous", "unicode.grapheme-cursor", "unicode.tab-stops", "unicode.wrap-boundary"], mux: ["charsets.dec-line-drawing", "charsets.dec-special", "charsets.g0-g1-switching", "charsets.utf8", "cursor.ansi-restore", "cursor.ansi-save", "cursor.cpl", "cursor.cud-past-bottom", "cursor.cup-boundaries", "cursor.cup-scroll-region", "cursor.cuu-past-top", "cursor.hide", "cursor.horizontal-absolute", "cursor.hpa", "cursor.move.absolute", "cursor.move.back", "cursor.move.down", "cursor.move.forward", "cursor.move.home", "cursor.move.up", "cursor.next-line", "cursor.position-report", "cursor.reverse-wrap", "cursor.save-restore", "cursor.shape", "cursor.vpa", "device.decrpm", "device.decrqss", "device.dsr-996-color-scheme", "device.primary-da", "device.secondary-da", "device.status-report", "device.term-features", "device.tertiary-da", "device.xtgettcap", "device.xtgetxres", "device.xtreportcolors", "device.xtversion", "device.xtwinops-14", "device.xtwinops-16", "device.xtwinops-18", "device.xtwinops-20", "device.xtwinops-21", "device.xtwinops-22", "device.xtwinops-23", "editing.deccara", "editing.deccra", "editing.decdc", "editing.decera", "editing.decfra", "editing.decic", "editing.decrara", "editing.decrqcra", "editing.decsace", "editing.decsera", "editing.delete-chars", "editing.delete-lines", "editing.insert-chars", "editing.insert-lines", "editing.repeat-char", "editing.sl", "editing.sr", "erase.character", "erase.ed-scroll-region", "erase.el-with-attrs", "erase.line.all", "erase.line.left", "erase.line.right", "erase.screen.above", "erase.screen.all", "erase.screen.below", "erase.screen.scrollback", "erase.selective", "extensions.iterm2-images", "extensions.kitty-graphics", "extensions.kitty-graphics.animation", "extensions.kitty-graphics.display", "extensions.kitty-graphics.transmit", "extensions.kitty-graphics.unicode-placeholders", "extensions.kitty-keyboard", "extensions.kitty-keyboard.disambiguate", "extensions.kitty-keyboard.report-all-keys", "extensions.kitty-keyboard.report-alternate", "extensions.kitty-keyboard.report-events", "extensions.kitty-keyboard.report-text", "extensions.notifications", "extensions.osc-633-vscode", "extensions.osc0-icon-title", "extensions.osc1-icon", "extensions.osc10-fg-color", "extensions.osc104-reset-palette", "extensions.osc11-bg-color", "extensions.osc110-reset-fg", "extensions.osc111-reset-bg", "extensions.osc112-reset-cursor", "extensions.osc113-reset-pointer-fg", "extensions.osc114-reset-pointer-bg", "extensions.osc117-reset-highlight-bg", "extensions.osc119-reset-highlight-fg", "extensions.osc12-cursor-color", "extensions.osc133-a", "extensions.osc133-b", "extensions.osc133-c", "extensions.osc133-d", "extensions.osc133-p", "extensions.osc1337-capabilities", "extensions.osc1337-cellsize", "extensions.osc17-highlight-bg", "extensions.osc176-app-id", "extensions.osc19-highlight-fg", "extensions.osc2-title", "extensions.osc21-kitty-color", "extensions.osc22-pointer", "extensions.osc30001-color-stack-push", "extensions.osc3008-context", "extensions.osc30101-color-stack-pop", "extensions.osc4-palette", "extensions.osc440-audio", "extensions.osc5-special-color", "extensions.osc52-clipboard", "extensions.osc52-read", "extensions.osc52-write", "extensions.osc5522-clipboard", "extensions.osc555-flash", "extensions.osc633-a", "extensions.osc633-b", "extensions.osc633-c", "extensions.osc633-d", "extensions.osc633-e", "extensions.osc633-p", "extensions.osc66-text-sizing", "extensions.osc666-termprop", "extensions.osc7-cwd", "extensions.osc701-locale", "extensions.osc702-version", "extensions.osc710-font-normal", "extensions.osc720-scroll-up", "extensions.osc776-cell-size", "extensions.osc777-notify", "extensions.osc7770-font-size", "extensions.osc7777-font-window-size", "extensions.osc8", "extensions.osc9-progress", "extensions.osc99-kitty-notify", "extensions.reflow", "extensions.semantic-prompts", "extensions.sixel", "extensions.sixel-da1", "extensions.sixel-geometry-report", "extensions.truecolor", "input.button-event-mouse", "input.csi-u", "input.modify-other-keys", "input.modify-other-keys-3", "input.pixel-mouse", "input.urxvt-mouse", "input.x10-mouse", "modes.alt-screen.enter", "modes.alt-screen.exit", "modes.alt-scroll-1007", "modes.altscreen-1047", "modes.altscreen-1048", "modes.altscreen-47", "modes.application-cursor", "modes.application-keypad", "modes.auto-wrap", "modes.bracketed-paste", "modes.color-scheme-reporting", "modes.deccolm", "modes.decsclm", "modes.focus-tracking", "modes.insert-replace", "modes.left-right-margin", "modes.mouse-all", "modes.mouse-sgr", "modes.mouse-tracking", "modes.origin", "modes.reverse-video", "modes.synchronized-output", "modes.utf8-mouse-1005", "modes.xtpopcolors", "modes.xtpopsgr", "modes.xtpushcolors", "modes.xtpushsgr", "modes.xtrestore", "modes.xtsave", "reset.decaln", "reset.method", "reset.ris", "reset.sgr", "reset.soft", "scrollback.accumulate", "scrollback.alt-screen", "scrollback.decstbm", "scrollback.decstbm-reset", "scrollback.reverse-index", "scrollback.scroll-down", "scrollback.scroll-up", "scrollback.set-region", "scrollback.total-lines", "sgr.bg.256", "sgr.bg.bright", "sgr.bg.default", "sgr.bg.standard", "sgr.bg.truecolor", "sgr.blink", "sgr.bold", "sgr.faint", "sgr.fg.256", "sgr.fg.bright", "sgr.fg.default", "sgr.fg.standard", "sgr.fg.truecolor", "sgr.hidden", "sgr.inverse", "sgr.italic", "sgr.overline", "sgr.reset", "sgr.selective-reset.bold", "sgr.selective-reset.inverse", "sgr.selective-reset.italic", "sgr.selective-reset.underline", "sgr.strikethrough", "sgr.underline-color-indexed", "sgr.underline-color-reset", "sgr.underline-color-rgb", "sgr.underline.color", "sgr.underline.curly", "sgr.underline.dashed", "sgr.underline.dotted", "sgr.underline.double", "sgr.underline.single", "text.backspace", "text.basic", "text.cbt", "text.cht", "text.combining", "text.cr", "text.hts", "text.index", "text.newline", "text.next-line", "text.overwrite", "text.reverse-index-scroll", "text.tab", "text.tbc", "text.wide.cjk", "text.wide.emoji", "text.wide.emoji-flags", "text.wide.emoji-vs16", "text.wide.emoji-zwj", "text.wrap", "unicode.east-asian-ambiguous", "unicode.grapheme-cursor", "unicode.tab-stops", "unicode.wrap-boundary"] } }, collectorRevision: "cf7d8759c7e637aa8dba1e429f3dddd1c0124158" };
});

// src/daemon-client.ts
init_src2();
init_serve();
init_owned_terminal();
async function verifyDaemonInfo(daemon) {
  if (!daemon.runId || !Number.isInteger(daemon.pid) || !daemon.terminal) {
    throw new Error(`Daemon on port ${daemon.port} lacks run identity; restart it with the current CLI`);
  }
  const response = await fetch(`http://127.0.0.1:${daemon.port}/info`, { signal: AbortSignal.timeout(2000) });
  if (!response.ok)
    throw new Error(`Daemon on port ${daemon.port}: /info HTTP ${response.status}`);
  const info = await response.json();
  if (info.runId !== daemon.runId || info.pid !== daemon.pid || info.terminal !== daemon.terminal || info.terminalVersion !== daemon.terminalVersion) {
    throw new Error(`Daemon identity mismatch on port ${daemon.port}`);
  }
}
async function requestDaemonProbe(daemon, terminalAppOwner) {
  if (!Number.isInteger(daemon.port) || daemon.port < 1 || daemon.port > 65535) {
    throw new Error(`Invalid daemon port: ${daemon.port}`);
  }
  if (!daemon.token) {
    throw new Error(`Daemon on port ${daemon.port} has no authorization token; restart it with the current CLI`);
  }
  const owner = terminalAppOwner === undefined ? undefined : parseTerminalAppOwner(terminalAppOwner);
  if (owner && (owner.launchRunId !== daemon.runId || owner.workerPid !== daemon.pid || daemon.terminal !== "terminal-app")) {
    throw new Error("Terminal.app owner assertion differs from the selected daemon");
  }
  await verifyDaemonInfo(daemon);
  const response = await fetch(`http://127.0.0.1:${daemon.port}/probe`, {
    method: owner ? "POST" : "GET",
    headers: { Authorization: `Bearer ${daemon.token}`, ...owner && { "Content-Type": "application/json" } },
    ...owner && { body: JSON.stringify({ terminalAppOwner: owner }) },
    signal: AbortSignal.timeout(120000)
  });
  if (!response.ok) {
    throw new Error(`Daemon on port ${daemon.port}: HTTP ${response.status}`);
  }
  return response;
}
async function readRawDaemonProbeResponse(response, receipt = getTrustedSuiteReceipt()) {
  const raw = decodeExactUtf8(Buffer.from(await response.arrayBuffer()), "daemon /probe");
  const decoded = decodeCollectorRun("daemon /probe", raw, receipt.manifest, receipt.collectorRevision);
  if (decoded.run.target.kind !== "app" && decoded.run.target.kind !== "mux") {
    throw new Error(`Daemon /probe target kind ${decoded.run.target.kind} is not an app or mux`);
  }
  return decoded;
}

// src/index.tsx
import { writeFileSync as writeFileSync4 } from "fs";
import { isAbsolute } from "path";
import { Command, uint } from "@silvery/commander";
import { renderString } from "silvery";
// package.json
var version = "4.0.0";

// src/index.tsx
init_detect();
init_unified();

// src/views/DetectView.tsx
import { Box, Text, H2 } from "silvery";
import { jsxDEV } from "react/jsx-dev-runtime";
function DetectView({ terminal }) {
  const version = terminal.version ? ` ${terminal.version}` : "";
  return /* @__PURE__ */ jsxDEV(Box, {
    flexDirection: "column",
    gap: 1,
    children: [
      /* @__PURE__ */ jsxDEV(H2, {
        children: "terminfo detect"
      }, undefined, false, undefined, this),
      /* @__PURE__ */ jsxDEV(Box, {
        flexDirection: "column",
        paddingLeft: 2,
        children: [
          /* @__PURE__ */ jsxDEV(Text, {
            children: [
              "Terminal:",
              " ",
              /* @__PURE__ */ jsxDEV(Text, {
                bold: true,
                children: [
                  terminal.name,
                  version
                ]
              }, undefined, true, undefined, this)
            ]
          }, undefined, true, undefined, this),
          /* @__PURE__ */ jsxDEV(Text, {
            children: [
              "OS: ",
              terminal.os,
              " ",
              terminal.osVersion
            ]
          }, undefined, true, undefined, this)
        ]
      }, undefined, true, undefined, this)
    ]
  }, undefined, true, undefined, this);
}

// src/index.tsx
init_src2();

// src/submit.ts
init_src2();
import { existsSync, readFileSync as readFileSync5, writeFileSync as writeFileSync3 } from "fs";
import { basename as basename2, dirname as dirname3, join as join3 } from "path";
function fenceFor(source) {
  const longest = Math.max(3, ...Array.from(source.matchAll(/~+/g), ([run]) => run.length));
  return "~".repeat(longest + 1);
}
function createDraft(rawRunPath, draftPath, receipt) {
  const rawBytes = readFileSync5(rawRunPath);
  const raw = decodeExactUtf8(rawBytes, rawRunPath);
  const decoded = decodeCollectorRun(rawRunPath, raw, receipt.manifest, receipt.collectorRevision);
  const { run } = decoded;
  if (run.screenshotRefs.length > 0) {
    throw new Error(`${rawRunPath}: screenshot artifact bytes are not retained with this offline draft`);
  }
  const expected = receipt.manifest.probes[run.target.kind].length;
  const ungraded = Object.keys(run.ungradedDiagnostics ?? {}).length;
  const missing = expected - run.observations.length - ungraded;
  if (missing < 0)
    throw new Error(`${rawRunPath}: observation/diagnostic counts exceed trusted suite`);
  const context = {
    target: run.target.kind,
    terminal: run.target.id,
    version: run.target.version,
    os: run.target.os ?? "unknown",
    osVersion: run.target.osVersion ?? "unknown",
    outerTerminal: run.target.outerTerminal ?? "unknown",
    mux: run.target.mux ?? "unknown",
    config: run.target.config ?? "unknown",
    permissions: run.target.permissions ?? "unknown",
    measuredAt: run.measuredAt,
    cliVersion: receipt.cliVersion,
    suiteId: run.suiteId,
    probeHash: run.probeHash,
    sourceRevision: run.sourceRevision,
    identity: run.identity,
    runId: run.runId,
    runSha256: decoded.sha256,
    runByteLength: rawBytes.length,
    coverage: {
      explicit: `${run.observations.length}/${expected}`,
      ungraded,
      missing,
      suiteComplete: run.suiteComplete
    }
  };
  const contextJson = JSON.stringify(context, null, 2);
  const fence = fenceFor(contextJson);
  const attachmentPath = join3(dirname3(draftPath), `${decoded.sha256}.json`);
  if (attachmentPath === draftPath)
    throw new Error("Draft path cannot be the raw attachment path");
  const draft = [
    "# Terminal observation draft",
    "",
    "This command creates files offline and does not send them. Review this draft before posting it as a GitHub issue.",
    "If you choose to contribute, include this consent statement:",
    "I dedicate these results to the public domain (CC0 1.0) so terminfo.dev can publish them under any license.",
    ...run.suiteComplete ? [] : ["This run is partial: history only; not current terminal support."],
    "",
    "## Measured context and coverage",
    "",
    `${fence}json`,
    contextJson,
    fence,
    "",
    "## Exact original run bytes",
    "",
    `[Attach the original JSON file](${basename2(attachmentPath)}) (SHA256 ${decoded.sha256}; ${rawBytes.length} bytes).`,
    ""
  ].join(`
`);
  if (existsSync(attachmentPath)) {
    if (!readFileSync5(attachmentPath).equals(rawBytes)) {
      throw new Error(`${attachmentPath}: existing content-addressed attachment differs from raw run bytes`);
    }
  } else {
    writeFileSync3(attachmentPath, rawBytes, { flag: "wx", mode: 384 });
  }
  writeFileSync3(draftPath, draft, { flag: "wx", mode: 384 });
  return { sha256: decoded.sha256, runId: run.runId, suiteComplete: run.suiteComplete, attachmentPath };
}

// src/index.tsx
init_tty();
import { jsxDEV as jsxDEV2 } from "react/jsx-dev-runtime";
async function runProbes(out) {
  await Promise.resolve().then(() => init_serve());
  const run = await collectProbeRun(out ? { out } : {});
  return { run, receipt: getTrustedSuiteReceipt() };
}
function outputPath(path) {
  if (!isAbsolute(path))
    throw new Error(`Raw --output must be an absolute file path: ${path}`);
  return path;
}
async function printView(element) {
  const width = process.stdout.columns || 80;
  const output = await renderString(element, { width });
  console.log(output);
}
var program = new Command().name("terminfo").description(`Can your terminal do that? \u2014 record available checks across ${ALL_PROBES2.length} feature definitions`).version(version);
program.addHelpSection("Examples:", [
  ["$ npx terminfo.dev test", "Record available checks; other checks may be refused"],
  ["$ npx terminfo.dev test --json > raw.json", "One raw run; TTY input, controls on /dev/tty"],
  ["$ npx terminfo.dev test --output /tmp/terminfo-run.json", "Private raw file at an absolute path"],
  [
    "$ npx terminfo.dev submit /tmp/terminfo-run.json --draft /tmp/terminfo-draft.md",
    "Offline draft and adjacent raw attachment; nothing is sent"
  ],
  ["$ npx terminfo.dev detect", "What terminal am I in?"]
]);
program.command("test").description("Record terminal observations; state-changing checks require a verified test environment").argument("[daemon]", "Daemon name to test").option("--json", "Write one raw JSON run to stdout (inline probes require interactive TTY)").option("--output <file>", "Write exact raw JSON to an absolute file").option("--serve", "Start daemon for remote testing").option("-p, --port <port>", "Port for --serve", uint).option("--all", "Unavailable: collecting multiple daemons is refused").actionMerged(async (opts) => {
  if (opts.json && opts.output)
    throw new Error("Choose --json or --output for one raw run");
  if (opts.output)
    outputPath(opts.output);
  if (opts.all)
    throw new Error("Collecting multiple daemons is unavailable; test one named daemon with --output");
  if (opts.serve && (opts.json || opts.output || opts.daemon)) {
    throw new Error("--serve cannot be combined with raw output or a daemon target");
  }
  if (opts.serve) {
    await Promise.resolve().then(() => init_serve());
    startDaemon(opts.port ?? 0);
    return;
  }
  if (opts.daemon) {
    if (!opts.json && !opts.output) {
      throw new Error("Daemon collection requires --json or an absolute --output file");
    }
    await Promise.resolve().then(() => init_serve());
    const daemons = listDaemons();
    const selectedName = opts.daemon.toLowerCase();
    const targets = daemons.filter((d) => d.terminal.toLowerCase() === selectedName || d.terminal.toLowerCase().includes(selectedName));
    if (targets.length !== 1) {
      throw new Error(`Daemon target "${opts.daemon}" matched ${targets.length} registrations; name exactly one`);
    }
    const daemon = targets[0];
    if (!daemon)
      throw new Error("Selected daemon registration disappeared");
    const decoded = await readRawDaemonProbeResponse(await requestDaemonProbe(daemon));
    if (opts.output) {
      writeFileSync4(opts.output, decoded.raw, { flag: "wx", mode: 384 });
      console.error(`Raw run ${decoded.run.runId} saved to ${opts.output}; SHA256 ${decoded.sha256}; identity unverified`);
    } else {
      process.stdout.write(decoded.raw);
      console.error(`Raw run ${decoded.run.runId}; SHA256 ${decoded.sha256}; identity unverified`);
    }
    return;
  }
  const out = opts.json || opts.output ? openControllingTTY() : undefined;
  let collected;
  try {
    collected = await runProbes(out);
  } finally {
    if (out) {
      await new Promise((resolve) => {
        out.end(resolve);
      });
    }
  }
  const raw = `${JSON.stringify(collected.run)}
`;
  const decoded = decodeCollectorRun("inline collector", raw, collected.receipt.manifest, collected.receipt.collectorRevision);
  if (opts.output) {
    writeFileSync4(opts.output, raw, { flag: "wx", mode: 384 });
    console.error(`Raw run ${decoded.run.runId} saved to ${opts.output}; SHA256 ${decoded.sha256}; identity unverified`);
    return;
  }
  if (opts.json) {
    process.stdout.write(raw);
    console.error(`Raw run ${decoded.run.runId}; SHA256 ${decoded.sha256}; identity unverified`);
    return;
  }
  const data = decoded.run;
  console.log(`${data.target.id} ${data.target.version}: ${data.observations.length}/${ALL_PROBES2.length} recorded outcomes (including inconclusive checks)`);
  console.log(`Run ${data.runId} is unreviewed${data.suiteComplete ? "" : " and partial"}; use --json for raw evidence and any policy refusals.`);
});
program.command("submit").description("Prepare an offline draft and adjacent raw attachment from one unreviewed v2 run; nothing is sent").argument("<raw>", "Exact raw JSON file from test --output").option("--draft <file>", "Write an offline Markdown draft").actionMerged(async (opts) => {
  if (!opts.draft)
    throw new Error("submit requires --draft <file>; no run was posted");
  await Promise.resolve().then(() => init_serve());
  const result = createDraft(opts.raw, opts.draft, { ...getTrustedSuiteReceipt(), cliVersion: version });
  console.log(`Offline draft ${opts.draft}; raw attachment ${result.attachmentPath}; SHA256 ${result.sha256}`);
});
program.command("detect").description("Detect current terminal").option("--json", "Output as JSON").action(async (opts) => {
  const terminal = detectTerminal();
  if (opts.json) {
    console.log(JSON.stringify(terminal, null, 2));
    return;
  }
  await printView(/* @__PURE__ */ jsxDEV2(DetectView, {
    terminal
  }, undefined, false, undefined, this));
});
// CLI dispatch is disabled in the local adapter module.


// This capability is registered only after the local launcher and PTY proof.
// Existing upstream owners, policy checks and callback grading remain intact.
async function createNtildeOwnedTerminal(assertion, captureRunId, out) {
  init_owned_terminal();
  const binding = await ntildeVerifyOutput(assertion, out);
  const geometryAtGrant = await readBoundGeometry(binding);
  if (geometryAtGrant.status !== "measured") throw new Error(geometryAtGrant.diagnostic);
  const clipboard = createPrivateClipboardWorker(frame => ntildePrivateOwnerRequest(assertion, "private-clipboard", { tty: binding.tabTty, frame }).then(reply => { if (reply.ownerPid !== binding.ownerPid) throw new Error("Private clipboard owner changed"); return reply.result; }), assertion.runId);
  const owner = {
    clipboard,
    geometryAtGrant,
    geometrySource: geometrySource(binding),
    summary: JSON.stringify({ adapter: "ntilde-owned-macos-v1", binding, geometryAtGrant }),
    async readGeometry() {
      if (!verifiedTerminalOwners.has(owner)) throw new Error("Ntilde owner grant has expired");
      const current = await ntildeVerifyOutput(assertion, out);
      if (!sameDevice(current.outputDevice, binding.outputDevice)) throw new Error("Ntilde output device changed");
      return readBoundGeometry(current);
    },
    async dispose() { try { await clipboard.finish(); } finally { verifiedTerminalOwners.delete(owner); } }
  };
  verifiedTerminalOwners.set(owner, { captureRunId, out });
  return owner;
}
export async function collectNtildeRun(assertion) {
  init_serve();
  return collectProbeRun({ ntildeOwner: assertion, out: process.stdout });
}


// Local grading extension "ntilde-owned-ascii-sgr-grading-v1". Derived from the
// owned adapter; probe definitions, policy gates and stock grading are intact.
export const ntildeGradingAdapter = Object.freeze({
  id: "ntilde-owned-ascii-sgr-grading-v1",
  probeIds: ["text.basic","text.overwrite","sgr.bold","sgr.italic"]
});
export function ntildeRunTermless(probeId, ctx) {
  init_src();
  const probe = ALL_PROBES.find(item => item.id === probeId);
  if (!probe || typeof probe.termless !== "function") throw new Error("Unknown pinned probe " + probeId);
  const result = probe.termless(ctx);
  return { probeId, ...result };
}


// Local SGR-colors grading extension "ntilde-owned-sgr-colors-grading-v1".
// Derived from the ASCII/SGR grading extension; probe definitions, policy
// gates and stock grading remain intact.
export const ntildeSgrColorsAdapter = Object.freeze({
  id: "ntilde-owned-sgr-colors-grading-v1",
  probeIds: ["sgr.selective-reset.bold","sgr.selective-reset.italic","sgr.reset","sgr.fg.standard","sgr.bg.standard"]
});
export function ntildeRunSgrColorsTermless(probeId, ctx) {
  init_src();
  const probe = ALL_PROBES.find(item => item.id === probeId);
  if (!probe || typeof probe.termless !== "function") throw new Error("Unknown pinned probe " + probeId);
  const result = probe.termless(ctx);
  return { probeId, ...result };
}


// Local SGR-RGB grading extension "ntilde-owned-sgr-rgb-grading-v1".
// Derived from the SGR-colors grading extension; probe definitions, policy
// gates and stock grading remain intact.
export const ntildeSgrRgbAdapter = Object.freeze({
  id: "ntilde-owned-sgr-rgb-grading-v1",
  probeIds: ["sgr.fg.standard","sgr.bg.standard"]
});
/** Execute one pinned termless probe over caller-served cells. */
export function ntildeRunSgrRgbTermless(probeId, ctx) {
  init_src();
  const probe = ALL_PROBES.find(item => item.id === probeId);
  if (!probe || typeof probe.termless !== "function") throw new Error("Unknown pinned probe " + probeId);
  const result = probe.termless(ctx);
  return { probeId, ...result };
}


// Local SGR-attributes grading extension "ntilde-owned-sgr-attributes-grading-v1".
// Derived from the SGR-RGB grading extension; probe definitions, policy gates
// and stock grading remain intact.
export const ntildeSgrAttrsAdapter = Object.freeze({
  id: "ntilde-owned-sgr-attributes-grading-v1",
  probeIds: ["sgr.underline.single","sgr.inverse","sgr.faint","sgr.hidden","sgr.strikethrough"]
});
/** Execute one pinned termless probe over caller-served cells. */
export function ntildeRunSgrAttrsTermless(probeId, ctx) {
  init_src();
  const probe = ALL_PROBES.find(item => item.id === probeId);
  if (!probe || typeof probe.termless !== "function") throw new Error("Unknown pinned probe " + probeId);
  const result = probe.termless(ctx);
  return { probeId, ...result };
}


// Local SGR-palette grading extension "ntilde-owned-sgr-palette-grading-v1".
// Derived from the SGR-attributes grading extension; probe definitions, policy
// gates and stock grading remain intact.
export const ntildeSgrPaletteAdapter = Object.freeze({
  id: "ntilde-owned-sgr-palette-grading-v1",
  probeIds: ["sgr.fg.bright","sgr.bg.bright","sgr.fg.256","sgr.bg.256","sgr.fg.default","sgr.bg.default"]
});
/** Execute one pinned termless probe over caller-served cells. */
export function ntildeRunSgrPaletteTermless(probeId, ctx) {
  init_src();
  const probe = ALL_PROBES.find(item => item.id === probeId);
  if (!probe || typeof probe.termless !== "function") throw new Error("Unknown pinned probe " + probeId);
  const result = probe.termless(ctx);
  return { probeId, ...result };
}


// Local SGR-truecolor grading extension "ntilde-owned-sgr-truecolor-grading-v1".
// Derived from the SGR-palette grading extension; probe definitions, policy
// gates and stock grading remain intact.
export const ntildeSgrTruecolorAdapter = Object.freeze({
  id: "ntilde-owned-sgr-truecolor-grading-v1",
  probeIds: ["sgr.fg.truecolor","sgr.bg.truecolor"]
});
/** Execute one pinned termless probe over caller-served cells. */
export function ntildeRunSgrTruecolorTermless(probeId, ctx) {
  init_src();
  const probe = ALL_PROBES.find(item => item.id === probeId);
  if (!probe || typeof probe.termless !== "function") throw new Error("Unknown pinned probe " + probeId);
  const result = probe.termless(ctx);
  return { probeId, ...result };
}


// Local SGR-underline grading extension "ntilde-owned-sgr-underline-grading-v1".
// Derived from the SGR-truecolor grading extension; probe definitions, policy
// gates and stock grading remain intact.
export const ntildeSgrUnderlineAdapter = Object.freeze({
  id: "ntilde-owned-sgr-underline-grading-v1",
  probeIds: ["sgr.underline.double","sgr.underline.curly","sgr.underline.dotted","sgr.underline.dashed"]
});
/** Execute one pinned termless probe over caller-served cells. */
export function ntildeRunSgrUnderlineTermless(probeId, ctx) {
  init_src();
  const probe = ALL_PROBES.find(item => item.id === probeId);
  if (!probe || typeof probe.termless !== "function") throw new Error("Unknown pinned probe " + probeId);
  const result = probe.termless(ctx);
  return { probeId, ...result };
}
