import { randomInt } from 'node:crypto';
import { existsSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { FocusedImageCollection } from './static-images-capture.mjs';
import { parseStaticKittyReply, staticImageAnchor } from './static-images-cases.mjs';
import { staticImageEnvelope } from './static-images-oracle.mjs';
import { deriveFocusedImageRun } from './static-images-receipt.mjs';
import { checkImages, imageRestore, imageSetup, retainedImagePixel, StaticImageReport, staticImageSuite } from './static-images.mjs';
import { pngHash } from './pixels-capture.mjs';

export const scope = Object.freeze({ id: 'ntilde-owned-kitty-graphics-v1', persistence: 'Off', deadlineMs: 90000 });
export const prefix = 'kgraphics-';
export const workerFile = 'kitty-graphics-worker.mjs';
export const imageOwnership = true;
export const caseIds = Object.freeze(['extensions.kitty-graphics.transmit', 'extensions.kitty-graphics.display']);
const [transmit, display] = caseIds;
export const maximumPinnedNumber = 0xfffffffe;
const rgb = Buffer.from([255, 0, 0]);
const apc = body => '\x1b_G' + body + '\x1b\\';
const commands = {
    upload: ({ number }) => apc('a=t,f=24,s=1,v=1,t=d,I=' + number + ';' + rgb.toString('base64')),
    place: ({ firstId }) => apc('a=p,i=' + firstId + ',c=2,r=1,C=1'),
    delete: ({ firstId }) => apc('a=d,d=I,i=' + firstId + ',q=2'),
};
const stage = (caseId, stageId) => ({ kind: 'read', caseId, stageId });
export const plan = Object.freeze([
    { kind: 'bind' }, stage(transmit, 'upload'), stage(transmit, 'delete'),
    stage(display, 'upload'), stage(display, 'place'), stage(display, 'delete'), { kind: 'finish' },
].map(Object.freeze));

function action(entry, state, runId, cursorVisible) {
    if (entry.kind === 'bind') return { command: imageSetup(runId), skipReason: null };
    if (entry.kind === 'finish') return { command: imageRestore(cursorVisible), skipReason: null };
    const skipped = entry.stageId !== 'upload' && state.firstId === null;
    return { command: skipped ? '' : commands[entry.stageId](state), skipReason: skipped ? 'no correlated allocation' : null };
}

function acceptReply(bytes, entry, states) {
    if (!bytes.length) return;
    const raw = bytes.toString('ascii'), state = states.get(entry.caseId);
    const { fields, status } = parseStaticKittyReply(raw);
    if (entry.stageId === 'upload') {
        checkImages(fields.I === state.number && raw === apc('i=' + fields.i + ',I=' + fields.I + ';' + status));
        if (status === 'OK') {
            checkImages(fields.i > 0);
            state.firstId = fields.i;
        }
    } else {
        checkImages(entry.stageId === 'place' && fields.i === state.firstId && raw === apc('i=' + fields.i + ';' + status));
    }
}

const cells = Object.freeze({ cols: 2, rows: 1 });
function comparePixelRow(before, after, envelope, y, difference) {
    const targetRow = y >= envelope.y && y < envelope.y + envelope.height;
    for (let x = 0; x < before.width; x++) {
        const offset = (y * before.width + x) * 4;
        const within = targetRow && x >= envelope.x && x < envelope.x + envelope.width;
        const initial = before.pixels.readUInt32BE(offset), observed = after.pixels.readUInt32BE(offset);
        if (within && initial !== 0x101010ff) difference.background = false;
        if (initial === observed) continue;
        if (!within) { difference.outside++; continue; }
        difference.changed++;
        if (observed !== 0xff0000ff) difference.otherColor++;
        difference.left = Math.min(difference.left, x);
        difference.top = Math.min(difference.top, y);
        difference.right = Math.max(difference.right, x);
        difference.bottom = Math.max(difference.bottom, y);
    }
}

// Derive changed bounds from the PNGs. The source is a solid red square fitted
// inside the requested cells. A one-pixel rounding tolerance permits fractional scale.
export function redPixels(before, after, grid) {
    const envelope = staticImageEnvelope(before, grid, staticImageAnchor, cells);
    checkImages(after.width === before.width && after.height === before.height);
    const difference = { left: Infinity, top: Infinity, right: -1, bottom: -1,
        changed: 0, outside: 0, otherColor: 0, background: true };
    for (let y = 0; y < before.height; y++) comparePixelRow(before, after, envelope, y, difference);
    const { left, top, right, bottom, changed, outside, otherColor, background } = difference;
    const bounds = changed ? { x: left, y: top, width: right - left + 1, height: bottom - top + 1 } : null;
    const side = Math.min(envelope.width, envelope.height);
    const square = bounds && Math.abs(bounds.width - side) <= 1 && Math.abs(bounds.height - side) <= 1
        && changed === bounds.width * bounds.height;
    return { envelope, bounds, changed, outside, otherColor, background, redSquare: Boolean(square && !outside && !otherColor) };
}

function placementMatches(details) {
    const [placement] = details.placements;
    return details.totalPlacements === 1 && placement.col === staticImageAnchor.col && placement.viewportRow === staticImageAnchor.row
        && placement.widthCells === cells.cols && placement.heightCells === cells.rows
        && placement.bitmapWidthPx === 1 && placement.bitmapHeightPx === 1 && placement.preserveAspectRatio
        && placement.clipTopRows === 0 && placement.clipBottomRows === 0 && placement.clipRightColumns === 0;
}

class GraphicsReport extends StaticImageReport {
    observe(entry, index, [pixel], replyBytes, { action, expected }) {
        acceptReply(replyBytes, entry, this.states);
        const placing = entry.stageId === 'place';
        const measurement = redPixels(this.boundPixel.image, pixel.image, pixel.details.grid);
        checkImages(measurement.background);
        const sameAsBlank = measurement.changed === 0 && measurement.outside === 0 && pixel.imageDetails.totalPlacements === 0;
        const passed = placing ? measurement.redSquare && placementMatches(pixel.imageDetails) : sameAsBlank;
        let verdict = passed ? 'passed' : 'failed';
        if (expected.skipReason) verdict = 'inconclusive';
        this.observations.push({
            caseId: entry.caseId, stage: entry.stageId, snapshot: index,
            replyEvidence: { requestHex: action.commandHex, replyHex: replyBytes.toString('hex') },
            pixelEvidence: { verdict, measurement, placement: pixel.imageDetails.placements[0] ?? null },
        });
    }
}

const captureKind = kind => kind.replace(prefix, staticImageSuite.prefix);
const input = { file: 'image-inputs/pinned-red.rgb', bytes: rgb, sha256: pngHash(rgb) };
export const suite = Object.freeze({
    ...staticImageSuite, plan, prefix, action, acceptReply,
    newState(states) {
        const used = new Set([...states.values()].map(state => state.number));
        let number;
        do { number = randomInt(1, maximumPinnedNumber + 1); } while (used.has(number));
        return { number, firstId: null };
    },
    registerState(actionFacts, states) {
        checkImages(actionFacts.number <= maximumPinnedNumber);
        return staticImageSuite.registerState(actionFacts, states);
    },
    inputs: () => [input], captureKind,
    retainPixel: (output, pixel, screen, kind) => retainedImagePixel(output, pixel, screen, captureKind(kind)),
    buildReport(frames, actions, seal, runId, output, priorChallenges) {
        checkImages(/^[a-f\d]{32}$/.test(runId) && priorChallenges.length === 0
            && frames.length === plan.length + 1 && actions.length === plan.length);
        const report = new GraphicsReport(frames, actions, runId, output, priorChallenges, suite);
        frames.forEach((frame, index) => report.processFrame(frame, index));
        report.checkSeal(seal);
        return { suite: scope.id, runId, observations: report.observations };
    },
});

const files = { frames: 'graphics-frames.jsonl', actions: 'graphics-actions.jsonl', seal: 'graphics-seal.json',
    report: 'graphics-report.json', receipt: 'graphics-receipt.json', context: 'context.json', proof: 'ownership-proof.json',
    source: 'source-snapshot.json', settings: 'initial-settings.json' };
const write = (output, name, value) => writeFileSync(join(output, name), JSON.stringify(value, null, 2) + '\n', { mode: 0o600, flag: 'wx' });

export class Collection extends FocusedImageCollection {
    constructor(run) { super(run, suite, files); }
}

export function deriveRun(output) {
    return deriveFocusedImageRun(output, { files, rawFailure: 'graphics-raw-failure.json', scope, suite });
}

export function completeReceipt(output, scratch) {
    checkImages(!existsSync(scratch));
    const { report, receipt } = deriveRun(output);
    write(output, files.report, report);
    write(output, files.receipt, receipt);
    return { ...receipt, verdict: report.observations.map(row => [row.caseId, row.stage, row.pixelEvidence.verdict]) };
}
