#!/usr/bin/env node
import { adaptFontSizeCollector, fontSizeAdapterId } from './terminfo/font-size-grading-collector.mjs';
import { fontSizeNonce, fontSizePrefix, fontSizeSuiteId, fontSizeVersion } from './terminfo/font-size-contracts.mjs';
import { buildFontSizeReport, fontSizeCounts } from './terminfo/font-size-grading.mjs';
import { FontSizeObserver } from './terminfo/font-size-capture.mjs';
import { adaptOscTitleCollector, oscTitleAdapterId } from './terminfo/osc-title-grading-collector.mjs';
import { oscTitleCaseIds, oscTitleContractsVersion, oscTitlePrefix, oscTitleSuiteId } from './terminfo/osc-title-contracts.mjs';
import { buildOscTitleReport, matchesOscTitleBaseline, oscTitleCounts, oscTitleObserverPlan } from './terminfo/osc-title-grading.mjs';
import { exposeOscTitleFacts, oscTitlePrerequisiteReason } from './terminfo/osc-title-collector.mjs';
import { reverseWideSuiteId, ReverseWideObserver, buildReverseWideReport } from './terminfo/core-reverse-wide.mjs';
import { sgrRasterSuiteId, SgrRasterObserver, buildSgrRasterReport } from './terminfo/core-sgr-raster.mjs';
import { WrapObserver } from './terminfo/core-wrap-observer.mjs';
import { deriveWrapEvidence } from './terminfo/core-wrap-contract.mjs';
import { wrapSuiteId } from './terminfo/core-wrap-collector.mjs';
import { tabStopsSuiteId, TabStopsObserver, buildTabStopsReport } from './terminfo/core-tab-stops.mjs';
import { eraseSuiteId as coreEraseSuiteId, EraseObserver, buildEraseReport as buildCoreEraseReport } from './terminfo/core-erase.mjs';
import { modernCursorSuiteId, modernCursorPrefix, modernCursorNonce, ModernCursorObserver } from './terminfo/modern-cursor.mjs';
import { deriveModernCursorEvidence } from './terminfo/modern-cursor-receipt.mjs';
import { modernModesSuiteId, modernModesNonce, ModernModesObserver } from './terminfo/modern-modes.mjs';
import { deriveModernModesEvidence } from './terminfo/modern-modes-receipt.mjs';
import { textCursorSuiteId, TextCursorObserver, buildTextCursorReport } from './terminfo/core-text-cursor.mjs';
import { coreGapsSuiteId, coreGapsAdapterId, adaptCoreGapsCollector, CoreGapsObserver, buildCoreGapsReport } from './terminfo/core-gaps.mjs';
import { ownedSourceFiles, ownedSourcePath, assertOwnedSourcesUnchanged, readSourceSnapshot, removeSourceSnapshot, sourceSnapshotPolicy } from './terminfo/owned-sources.mjs';
import { OwnedMetadataObserver, initialMetadataRefusal, metadataFailure } from './terminfo/metadata-capture.mjs';
import { inputPlanForSuiteId as ownedInputPlanForSuiteId } from './terminfo/input-plan.mjs';
import { metadataSuiteId, ownedMetadataPolicy, makeMetadataCases } from './terminfo/metadata-cases.mjs';
import { buildMetadataReport } from './terminfo/metadata.mjs';
// Launches a private macOS desktop instance; never attaches to an existing pane.
import { spawn, spawnSync, execFileSync } from 'node:child_process';
import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { appendFileSync, chmodSync, closeSync, existsSync, mkdirSync, mkdtempSync, openSync, readFileSync, realpathSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:net';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { adapterId, adaptCollector, upstreamBundleSha256, upstreamReceipt, validateCollectorReceipt } from './terminfo/collector.mjs';
import { adaptGradingCollector, gradingAdapterId } from './terminfo/grading-collector.mjs';
import { adaptSgrColorsCollector, sgrColorsAdapterId } from './terminfo/sgr-colors-grading-collector.mjs';
import { sgrColorsContractsVersion, sgrColorsSuiteId } from './terminfo/sgr-colors-contracts.mjs';
import { buildSgrColorsGradingReport } from './terminfo/sgr-colors-grading.mjs';
import { adaptSgrRgbCollector, sgrRgbAdapterId } from './terminfo/sgr-rgb-grading-collector.mjs';
import { sgrRgbContractsVersion, sgrRgbSuiteId } from './terminfo/sgr-rgb-contracts.mjs';
import { buildSgrRgbGradingReport } from './terminfo/sgr-rgb-grading.mjs';
import { adaptSgrAttrsCollector, sgrAttrsAdapterId } from './terminfo/sgr-attrs-grading-collector.mjs';
import { sgrAttrsContractsVersion, sgrAttrsSuiteId } from './terminfo/sgr-attrs-contracts.mjs';
import { buildSgrAttrsGradingReport } from './terminfo/sgr-attrs-grading.mjs';
import { adaptSgrPaletteCollector, sgrPaletteAdapterId } from './terminfo/sgr-palette-grading-collector.mjs';
import { sgrPaletteContractsVersion, sgrPaletteSuiteId } from './terminfo/sgr-palette-contracts.mjs';
import { buildSgrPaletteGradingReport } from './terminfo/sgr-palette-grading.mjs';
import { adaptSgrTruecolorCollector, sgrTruecolorAdapterId } from './terminfo/sgr-truecolor-grading-collector.mjs';
import { sgrTruecolorContractsVersion, sgrTruecolorSuiteId } from './terminfo/sgr-truecolor-contracts.mjs';
import { buildSgrTruecolorGradingReport } from './terminfo/sgr-truecolor-grading.mjs';
import { truecolorFindingContractsVersion, truecolorFindingSuiteId } from './terminfo/truecolor-literal-finding-contracts.mjs';
import { adaptSgrUnderlineCollector, sgrUnderlineAdapterId } from './terminfo/sgr-underline-grading-collector.mjs';
import { sgrUnderlineContractsVersion, sgrUnderlineSuiteId } from './terminfo/sgr-underline-contracts.mjs';
import { buildSgrUnderlineGradingReport } from './terminfo/sgr-underline-grading.mjs';
import { adaptSgrUnderlineColorCollector, sgrUnderlineColorAdapterId } from './terminfo/sgr-underline-color-grading-collector.mjs';
import { sgrUnderlineColorContractsVersion, sgrUnderlineColorSuiteId } from './terminfo/sgr-underline-color-contracts.mjs';
import { buildSgrUnderlineColorGradingReport } from './terminfo/sgr-underline-color-grading.mjs';
import { underlineResolvedContractsVersion, underlineResolvedSuiteId } from './terminfo/sgr-underline-color-resolved-contracts.mjs';
import { buildUnderlineResolvedReport } from './terminfo/sgr-underline-color-resolved-grading.mjs';
import { adaptSgrResetCollector, sgrResetAdapterId } from './terminfo/sgr-reset-grading-collector.mjs';
import { sgrResetContractsVersion, sgrResetSuiteId } from './terminfo/sgr-reset-contracts.mjs';
import { buildSgrResetGradingReport } from './terminfo/sgr-reset-grading.mjs';
import { adaptSgrClosureCollector, sgrClosureAdapterId } from './terminfo/sgr-closure-grading-collector.mjs';
import { sgrClosureContractsVersion, sgrClosureSuiteId } from './terminfo/sgr-closure-contracts.mjs';
import { buildSgrClosureGradingReport } from './terminfo/sgr-closure-grading.mjs';
import { adaptEraseLineCollector, eraseLineAdapterId } from './terminfo/erase-line-grading-collector.mjs';
import { eraseLineContractsVersion, eraseLineSuiteId } from './terminfo/erase-line-contracts.mjs';
import { buildEraseLineGradingReport } from './terminfo/erase-line-grading.mjs';
import { adaptCharEditCollector, charEditAdapterId } from './terminfo/char-edit-grading-collector.mjs';
import { charEditContractsVersion, charEditSuiteId } from './terminfo/char-edit-contracts.mjs';
import { buildCharEditGradingReport } from './terminfo/char-edit-grading.mjs';
import { adaptEraseDisplayCollector, eraseDisplayAdapterId } from './terminfo/erase-display-grading-collector.mjs';
import { adaptLineEditCollector, lineEditAdapterId } from './terminfo/line-edit-grading-collector.mjs';
import { eraseDisplayContractsVersion, eraseDisplayGeometry, eraseDisplaySuiteId } from './terminfo/erase-display-contracts.mjs';
import { lineEditContractsVersion, lineEditSuiteId } from './terminfo/line-edit-contracts.mjs';
import { buildEraseDisplayGradingReport } from './terminfo/erase-display-grading.mjs';
import { buildLineEditGradingReport } from './terminfo/line-edit-grading.mjs';
import { adaptCharsetsCollector, charsetsAdapterId } from './terminfo/charsets-grading-collector.mjs';
import { charsetsContractsVersion, charsetsSuiteId } from './terminfo/charsets-contracts.mjs';
import { buildCharsetsGradingReport } from './terminfo/charsets-grading.mjs';
import { adaptScrollbackCollector, scrollbackAdapterId } from './terminfo/scrollback-grading-collector.mjs';
import { scrollbackContractsVersion, scrollbackSuiteId } from './terminfo/scrollback-contracts.mjs';
import { buildScrollbackGradingReport } from './terminfo/scrollback-grading.mjs';
import { adaptSavedResetCollector, savedResetAdapterId } from './terminfo/saved-reset-grading-collector.mjs';
import { savedResetContractsVersion, savedResetSuiteId } from './terminfo/saved-reset-contracts.mjs';
import { buildSavedResetGradingReport } from './terminfo/saved-reset-grading.mjs';
import { savedResetCounts } from './terminfo/saved-reset-receipt.mjs';
import { adaptEraseAttrsRegionCollector, eraseAttrsRegionAdapterId } from './terminfo/erase-attrs-region-grading-collector.mjs';
import { eraseAttrsRegionContractsVersion, eraseAttrsRegionSuiteId } from './terminfo/erase-attrs-region-contracts.mjs';
import { buildEraseAttrsRegionGradingReport } from './terminfo/erase-attrs-region-grading.mjs';
import { eraseAttrsRegionCounts } from './terminfo/erase-attrs-region-receipt.mjs';
import { adaptAttrRectCollector, attrRectAdapterId } from './terminfo/attr-rect-grading-collector.mjs';
import { attrRectContractsVersion, attrRectSuiteId } from './terminfo/attr-rect-contracts.mjs';
import { buildAttrRectGradingReport } from './terminfo/attr-rect-grading.mjs';
import { attrRectCounts } from './terminfo/attr-rect-receipt.mjs';
import { adaptCursorQualCollector, cursorQualAdapterId } from './terminfo/cursor-qual-grading-collector.mjs';
import { cursorQualContractsVersion, cursorQualSuiteId } from './terminfo/cursor-qual-contracts.mjs';
import { buildCursorQualGradingReport, verifyCursorQualLiveReplay } from './terminfo/cursor-qual-grading.mjs';
import { CursorQualObserver } from './terminfo/cursor-qual-capture.mjs';
import { adaptEraseCharsHistoryCollector, eraseCharsHistoryAdapterId } from './terminfo/erase-chars-history-grading-collector.mjs';
import { eraseCharsHistoryContractsVersion, eraseCharsHistorySuiteId } from './terminfo/erase-chars-history-contracts.mjs';
import { buildEraseCharsHistoryGradingReport } from './terminfo/erase-chars-history-grading.mjs';
import { eraseCharsHistoryCounts } from './terminfo/erase-chars-history-receipt.mjs';
import { adaptSelectiveEraseCollector, selectiveEraseAdapterId } from './terminfo/selective-erase-grading-collector.mjs';
import { selectiveEraseContractsVersion, selectiveEraseSuiteId } from './terminfo/selective-erase-contracts.mjs';
import { buildSelectiveEraseGradingReport } from './terminfo/selective-erase-grading.mjs';
import { selectiveEraseCounts } from './terminfo/selective-erase-receipt.mjs';
import { adaptRectEditCollector, rectEditAdapterId } from './terminfo/rect-edit-grading-collector.mjs';
import { rectEditContractsVersion, rectEditSuiteId } from './terminfo/rect-edit-contracts.mjs';
import { buildRectEditGradingReport } from './terminfo/rect-edit-grading.mjs';
import { rectEditCounts } from './terminfo/rect-edit-receipt.mjs';
import { adaptColEditCollector, colEditAdapterId } from './terminfo/col-edit-grading-collector.mjs';
import { colEditContractsVersion, colEditSuiteId } from './terminfo/col-edit-contracts.mjs';
import { buildColEditGradingReport } from './terminfo/col-edit-grading.mjs';
import { colEditCounts } from './terminfo/col-edit-receipt.mjs';
import { adaptRectChecksumCollector, rectChecksumAdapterId } from './terminfo/rect-checksum-grading-collector.mjs';
import { rectChecksumContractsVersion, rectChecksumSuiteId } from './terminfo/rect-checksum-contracts.mjs';
import { buildRectChecksumGradingReport } from './terminfo/rect-checksum-grading.mjs';
import { rectChecksumCounts } from './terminfo/rect-checksum-receipt.mjs';
import { RectChecksumObserver } from './terminfo/rect-checksum-capture.mjs';
import { adaptLrMarginsCollector, lrMarginsAdapterId } from './terminfo/lr-margins-grading-collector.mjs';
import { lrMarginsContractsVersion, lrMarginsSuiteId } from './terminfo/lr-margins-contracts.mjs';
import { buildLrMarginsGradingReport } from './terminfo/lr-margins-grading.mjs';
import { lrMarginsCounts } from './terminfo/lr-margins-receipt.mjs';
import { adaptRoutedInputCollector, routedInputAdapterId } from './terminfo/routed-input-grading-collector.mjs';
import { routedInputContractsVersion, routedInputGradedSuiteId } from './terminfo/routed-input-contracts.mjs';
import { buildRoutedInputGradingReport } from './terminfo/routed-input-grading.mjs';
import { routedInputCounts } from './terminfo/routed-input-receipt.mjs';
import { adaptColorResetCollector, colorResetAdapterId } from './terminfo/color-reset-grading-collector.mjs';
import { colorResetContractsVersion, colorResetSuiteId } from './terminfo/color-reset-contracts.mjs';
import { buildColorResetGradingReport } from './terminfo/color-reset-grading.mjs';
import { colorResetCounts } from './terminfo/color-reset-receipt.mjs';
import { adaptOsc133Collector, osc133AdapterId } from './terminfo/osc133-grading-collector.mjs';
import { legacyScope, osc633Scope, persistentAnimationScope, persistentRestoreScope, persistentComposeScope, directComposeScope, persistentPlaceholdersScope, directPlaceholdersScope, persistentPlaceholderGridScope, directPlaceholderGridScope, isOsc633Scope, verifyScopePredecessor } from './terminfo/collection-scope.mjs';
import { adaptOsc633Collector, osc633AdapterId } from './terminfo/osc633-grading-collector.mjs';
import { osc633ContractsVersion, osc633Prefix, osc633SuiteId } from './terminfo/osc633-contracts.mjs';
import { buildOsc633GradingReport, osc633Counts, osc633ObserverPlan } from './terminfo/osc633-grading.mjs';
import { osc133ContractsVersion, osc133Minimum, osc133Prefix, osc133SuiteId } from './terminfo/osc133-contracts.mjs';
import { buildOsc133GradingReport, matchesOsc133Baseline, osc133Counts, osc133ObserverPlan } from './terminfo/osc133-grading.mjs';
import { adaptOsc78Collector, osc78AdapterId } from './terminfo/osc78-grading-collector.mjs';
import { osc78ContractsVersion, osc78Minimum, osc78Prefix, osc78SuiteId } from './terminfo/osc78-contracts.mjs';
import { buildOsc78GradingReport, matchesOsc78Baseline, osc78Counts, osc78ObserverPlan } from './terminfo/osc78-grading.mjs';
import { adaptTitleStackCollector, titleStackAdapterId } from './terminfo/title-stack-grading-collector.mjs';
import { adaptInsertReplaceCollector, insertReplaceAdapterId } from './terminfo/insert-replace-grading-collector.mjs';
import { insertReplaceContractsVersion, insertReplaceNoncePrefix, insertReplaceSuiteId } from './terminfo/insert-replace-contracts.mjs';
import { buildInsertReplaceReport, verifyInsertReplaceTerminalReplay } from './terminfo/insert-replace-grading.mjs';
import { titleStackCaseIds, titleStackContractsVersion, titleStackMinimum, titleStackPrefix, titleStackSuiteId } from './terminfo/title-stack-contracts.mjs';
import { buildTitleStackGradingReport, matchesTitleStackBaseline, titleStackCounts, titleStackObserverPlan } from './terminfo/title-stack-grading.mjs';
import { exposeTitleStackFacts } from './terminfo/title-stack-collector.mjs';
import { adaptXtgettcapCollector, xtgettcapAdapterId } from './terminfo/xtgettcap-grading-collector.mjs';
import { xtgettcapContractsVersion, xtgettcapSuiteId } from './terminfo/xtgettcap-contracts.mjs';
import { buildXtgettcapGradingReport } from './terminfo/xtgettcap-grading.mjs';
import { xtgettcapCounts } from './terminfo/xtgettcap-receipt.mjs';
import { XtgettcapObserver } from './terminfo/xtgettcap-capture.mjs';
import { adaptOsc9Collector, osc9AdapterId } from './terminfo/osc9-grading-collector.mjs';
import { osc9CaseIds, osc9ContractsVersion, osc9Prefix, osc9SuiteId } from './terminfo/osc9-contracts.mjs';
import { buildOsc9Report, matchesOsc9Baseline, osc9Counts, osc9ObserverPlan } from './terminfo/osc9-grading.mjs';
import { exposeOsc9Facts, osc9PrerequisiteReason } from './terminfo/osc9-collector.mjs';
import { runFocusAction } from './terminfo/osc9-focus.mjs';
import { adaptNotifyCollector, notifyAdapterId } from './terminfo/notify-grading-collector.mjs';
import { notifyCaseIds, notifyContractsVersion, notifyPrefix, notifySuiteId } from './terminfo/notify-contracts.mjs';
import { buildNotifyReport, matchesNotifyBaseline, notifyCounts, notifyObserverPlan } from './terminfo/notify-grading.mjs';
import { exposeNotifyFacts, notifyPrerequisiteReason } from './terminfo/notify-collector.mjs';
import { adaptDevqCollector, devqAdapterId } from './terminfo/devq-grading-collector.mjs';
import { devqContractsVersion, devqNoncePrefix, devqPrefix, devqSuiteId } from './terminfo/devq-contracts.mjs';
import { buildDevqGradingReport } from './terminfo/devq-grading.mjs';
import { devqCounts } from './terminfo/devq-receipt.mjs';
import { DevqObserver } from './terminfo/devq-capture.mjs';
import { CellSizeObserver } from './terminfo/cell-size-capture.mjs';
import { adaptCellSizeCollector, cellSizeAdapterId } from './terminfo/cell-size-grading-collector.mjs';
import { cellSizeNonce, cellSizePrefix, cellSizeSuiteId, cellSizeVersion } from './terminfo/cell-size-contracts.mjs';
import { buildCellSizeReport, cellSizeCounts } from './terminfo/cell-size-grading.mjs';
import { adaptXcsCollector, xcsAdapterId } from './terminfo/xcs-grading-collector.mjs';
import { xcsContractsVersion, xcsNoncePrefix, xcsPrefix, xcsSuiteId } from './terminfo/xcs-contracts.mjs';
import { buildXcsGradingReport } from './terminfo/xcs-grading.mjs';
import { xcsCounts } from './terminfo/xcs-receipt.mjs';
import { XcsObserver } from './terminfo/xcs-capture.mjs';
import { adaptXssCollector, xssAdapterId } from './terminfo/xss-grading-collector.mjs';
import { xssContractsVersion, xssNoncePrefix, xssPrefix, xssSuiteId } from './terminfo/xss-contracts.mjs';
import { buildXssGradingReport } from './terminfo/xss-grading.mjs';
import { xssCounts } from './terminfo/xss-receipt.mjs';
import { XssObserver } from './terminfo/xss-capture.mjs';
import { adaptXsvCollector, xsvAdapterId } from './terminfo/xsv-grading-collector.mjs';
import { xsvContractsVersion, xsvNoncePrefix, xsvPrefix, xsvSuiteId } from './terminfo/xsv-contracts.mjs';
import { buildXsvGradingReport } from './terminfo/xsv-grading.mjs';
import { xsvCounts } from './terminfo/xsv-receipt.mjs';
import { XsvObserver } from './terminfo/xsv-capture.mjs';
import { adaptKclCollector, kclAdapterId } from './terminfo/kcl-grading-collector.mjs';
import { kclContractsVersion, kclNoncePrefix, kclPrefix, kclSuiteId } from './terminfo/kcl-contracts.mjs';
import { buildKclGradingReport } from './terminfo/kcl-grading.mjs';
import { kclCounts } from './terminfo/kcl-receipt.mjs';
import { KclObserver } from './terminfo/kcl-capture.mjs';
import { adaptOsc5Collector, osc5AdapterId } from './terminfo/osc5-grading-collector.mjs';
import { osc5ContractsVersion, osc5NoncePrefix, osc5Prefix, osc5SuiteId } from './terminfo/osc5-contracts.mjs';
import { buildOsc5GradingReport } from './terminfo/osc5-grading.mjs';
import { osc5Counts } from './terminfo/osc5-receipt.mjs';
import { Osc5Observer } from './terminfo/osc5-capture.mjs';
import { adaptCapsCollector, capsAdapterId } from './terminfo/caps-grading-collector.mjs';
import { capsContractsVersion, capsNoncePrefix, capsPrefix, capsSuiteId } from './terminfo/caps-contracts.mjs';
import { adaptPclCollector, pclAdapterId } from './terminfo/pcl-grading-collector.mjs';
import { pclContractsVersion, pclNoncePrefix, pclPrefix, pclSuiteId } from './terminfo/pcl-contracts.mjs';
import { buildPclGradingReport } from './terminfo/pcl-grading.mjs';
import { pclCounts } from './terminfo/pcl-receipt.mjs';
import { PclObserver } from './terminfo/pcl-capture.mjs';
import { adaptDclCollector, dclAdapterId } from './terminfo/dcl-grading-collector.mjs';
import { dclContractsVersion, dclNoncePrefix, dclPrefix, dclSuiteId } from './terminfo/dcl-contracts.mjs';
import { buildDclGradingReport } from './terminfo/dcl-grading.mjs';
import { dclCounts } from './terminfo/dcl-receipt.mjs';
import { DclObserver } from './terminfo/dcl-capture.mjs';
import { adaptDslCollector, dslAdapterId } from './terminfo/dsl-grading-collector.mjs';
import { dslContractsVersion, dslNoncePrefix, dslPrefix, dslSuiteId } from './terminfo/dsl-contracts.mjs';
import { buildDslGradingReport } from './terminfo/dsl-grading.mjs';
import { dslCounts } from './terminfo/dsl-receipt.mjs';
import { DslObserver } from './terminfo/dsl-capture.mjs';
import { buildCapsGradingReport } from './terminfo/caps-grading.mjs';
import { capsCounts } from './terminfo/caps-receipt.mjs';
import { CapsObserver } from './terminfo/caps-capture.mjs';
import { adaptOsc720Collector, osc720AdapterId } from './terminfo/osc720-grading-collector.mjs';
import { osc720CaseIds, osc720ContractsVersion, osc720Prefix, osc720SuiteId } from './terminfo/osc720-contracts.mjs';
import { buildOsc720Report, matchesOsc720Baseline, osc720Counts, osc720ObserverPlan } from './terminfo/osc720-grading.mjs';
import { exposeOsc720Facts, osc720PrerequisiteReason } from './terminfo/osc720-collector.mjs';
import { runViewAction } from './terminfo/osc720-action.mjs';
import { adaptOsc3008Collector, osc3008AdapterId, osc3008DerivedFromAdapterId } from './terminfo/osc3008-grading-collector.mjs';
import { osc3008ContractsVersion, osc3008Prefix, osc3008SuiteId } from './terminfo/osc3008-contracts.mjs';
import { buildOsc3008GradingReport, matchesOsc3008Baseline, osc3008Counts, osc3008ObserverPlan, verifyOsc3008PinnedCode } from './terminfo/osc3008-grading.mjs';
import { adaptOsc22Collector, osc22AdapterId, osc22DerivedFromAdapterId } from './terminfo/osc22-grading-collector.mjs';
import { osc22ContractsVersion, osc22Prefix, osc22SuiteId } from './terminfo/osc22-contracts.mjs';
import { buildOsc22GradingReport, matchesOsc22Baseline, osc22Counts, osc22ObserverPlan, verifyOsc22PinnedCode } from './terminfo/osc22-grading.mjs';
import { adaptModifyOtherKeysCollector, modifyOtherKeysAdapterId } from './terminfo/modify-other-keys-grading-collector.mjs';
import { modifyOtherKeysCaseIds, modifyOtherKeysContractsVersion, modifyOtherKeysGradedSuiteId } from './terminfo/modify-other-keys-contracts.mjs';
import { buildModifyOtherKeysGradingReport, modifyOtherKeysCounts } from './terminfo/modify-other-keys-grading.mjs';
import { modifyOtherKeysFirstPolicy } from './terminfo/input-plan.mjs';
import { adaptMexCollector, mexAdapterId } from './terminfo/mex-grading-collector.mjs';
import { mexContractsVersion, mexGradedSuiteId } from './terminfo/mex-contracts.mjs';
import { buildMexGradingReport, mexCounts } from './terminfo/mex-grading.mjs';
import { adaptPxmCollector, pxmAdapterId } from './terminfo/pxm-grading-collector.mjs';
import { pxmContractsVersion, pxmGradedSuiteId } from './terminfo/pxm-contracts.mjs';
import { buildPxmGradingReport, pxmCounts } from './terminfo/pxm-grading.mjs';
import { ColorResetObserver } from './terminfo/color-reset-capture.mjs';
import { SelectionColorsObserver } from './terminfo/color-reset-capture.mjs';
import { adaptSelectionColorsCollector, selectionColorsAdapterId } from './terminfo/selection-colors-grading-collector.mjs';
import { selectionColorsContractsVersion, selectionColorsSuiteId } from './terminfo/selection-colors-contracts.mjs';
import { buildSelectionColorsGradingReport, selectionColorsCounts } from './terminfo/selection-colors-grading.mjs';
import { buildTruecolorFindingReport } from './terminfo/truecolor-literal-finding-grading.mjs';
import { asciiSgrContractsVersion, asciiSgrSuiteId } from './terminfo/ascii-sgr-contracts.mjs';
import { buildAsciiSgrGradingReport } from './terminfo/ascii-sgr-grading.mjs';
import { processBirth, outputDevice, assertProcessOwnership, matchesRecordedWorker, processRecord, terminateRecordedWorker, workerExists, readPersistentDaemon, persistentDaemonIdentity, terminateRecordedDaemon, admitRelaunch } from './terminfo/ownership.mjs';
import { createPrivateScratch, createProcessBudget, installLockedCollector, readCollectorLockfile, resolveOwnedExecutable, validateCollectorInputs } from './terminfo/runtime.mjs';
import { OwnedSavedObserver } from './terminfo/saved-capture.mjs';
import { savedSuiteId, ownedSavedPolicy } from './terminfo/saved-cases.mjs';
import { buildSavedReport } from './terminfo/saved.mjs';
import { OwnedResizeObserver } from './terminfo/resize-capture.mjs';
import { resizeSuiteId, ownedResizePolicy } from './terminfo/resize-cases.mjs';
import { buildResizeReport } from './terminfo/resize.mjs';
import { resizeOwnedPane } from './terminfo/resize-action.mjs';
import { OwnedInputObserver } from './terminfo/input-capture.mjs';
import { currentInputPlan } from './terminfo/input-plan.mjs';
const inputSuiteId = currentInputPlan.suiteId, ownedInputPolicy = currentInputPlan.policy;
import { generateOwnedInput } from './terminfo/input-action.mjs';
import { OwnedQueryObserver, rejectQueryOwnerRequest } from './terminfo/query-capture.mjs';
import { querySuiteId, ownedQueryPolicy, queryPriorCounts } from './terminfo/queries.mjs';
import { OwnedStaticImageObserver } from './terminfo/static-images-capture.mjs';
import { staticImageSuiteId } from './terminfo/static-images-cases.mjs';
import { calibratedStaticImageCaptureScale, ownedStaticImagePolicy } from './terminfo/static-images.mjs';
import { OwnedAnimationObserver, animationObserverOf } from './terminfo/kitty-animation-capture.mjs';
import { animationSuiteId, animationSuiteIds, animationCases, animationCasesByVersion, currentAnimationVersion, restoreAnimationVersion } from './terminfo/kitty-animation-cases.mjs';
import { ownedAnimationPolicy, ownedAnimationPolicies, animationPlannedStages, animationSuites } from './terminfo/kitty-animation.mjs';
import { OwnedCellObserver, agentRequest, observerEndpoint } from './terminfo/agent-observer.mjs';
import { buildCellReport } from './terminfo/cells.mjs';
import { buildSgrReport } from './terminfo/sgr.mjs';
import { buildRgbReport, rgbCases, rgbSuiteId } from './terminfo/rgb.mjs';
import { buildRenditionReport, renditionCases, renditionSuiteId } from './terminfo/rendition.mjs';
import { buildCursorReport, cursorCases, cursorSuiteId } from './terminfo/cursor.mjs';
import { OwnedPixelObserver } from './terminfo/pixels-capture.mjs';
import { pixelSuiteId, pixelScenes } from './terminfo/pixels-cases.mjs';
import { OwnedColorObserver } from './terminfo/color-capture.mjs';
import { colorSuiteId, colorCases } from './terminfo/color-cases.mjs';
import { buildColorReport } from './terminfo/colors.mjs';
import { buildPixelReport } from './terminfo/pixels.mjs';
import { OwnedEditingObserver } from './terminfo/editing-capture.mjs';
import { eraseSuiteId, editingSuiteId } from './terminfo/editing-cases.mjs';
import { buildEraseReport, buildCellEditingReport } from './terminfo/editing.mjs';
import { OwnedHistoryObserver } from './terminfo/history-capture.mjs';
import { historySuiteId } from './terminfo/history-cases.mjs';
import { buildHistoryReport } from './terminfo/history.mjs';
import { completeOwnedReceipt } from './terminfo/receipt.mjs';
import { readOwnedTerminalState, privateClipboardOutputPolicy, readOwnedOutputMode, validateOutputGeometry } from './terminfo/terminal-output.mjs';

import { abortPrivateClipboardWithFacts, privateClipboardFailureFacts, privateClipboardEvidenceJson } from './terminfo/private-clipboard.mjs';
import { OwnedPrivateClipboardObserver, privateClipboardScreen } from './terminfo/private-clipboard-capture.mjs';
import { ownedPrivateClipboardPolicy, ownedPrivateClipboardSuiteId } from './terminfo/private-clipboard-worker.mjs';

/** The observation request prefixes whose `-start`, `-bind`, `-read` and `-finish` kinds are cell observations served without translation. */
const untranslatedCellPrefixes = new Set([
    'cell', 'sgr', 'grading', 'sgcolors', 'sgrgb', 'sgattr', 'sgpal', 'sgtc', 'sgtf', 'sgus', 'sguc', 'sgur', 'sgsr', 'sgcl', 'erln', 'ched', 'erdi',
    'ptr', 'ledt', 'irm', 'chrs', 'scrl', 'svrs', 'erar', 'atrc', 'curq', 'echh', 'sels', 'rect', 'cole', 'csum', 'lrmm', 'cg', 'tc', 'ce', 'ts', 'sr', 'rw', 'crst', 'selc', 'shi', 'vsc', 'lnk', 'tst', 'ost', 'xgtc', 'osn', 'ntf', 'dvq', 'csz', 'xcs', 'xss', 'xsv', 'kcl', 'scol', 'ocx', 'caps', 'pcl', 'dcl', 'dsl', 'ovu', 'rgb', 'rendition', 'cursor', 'pixel', 'color', 'erase', 'editing',
    'history', 'saved', 'metadata', 'fnt', modernCursorPrefix, 'mmod',
]);
const coreWrapKinds = new Set(['cw-geometry-start', 'cw-narrow', 'cw-start', 'cw-bind', 'cw-read', 'cw-finish', 'cw-restore', 'cw-abort', 'cw-seal']);
/** The parent-performed focus actions of the OSC 9 suite: exact kinds, answered by the runner rather than by an observer. */
const osc9ActionKinds = new Set(['osn-defocus', 'osn-refocus']);
/** The parent-performed focus actions of the OSC 777 / OSC 99 notification suite: exact kinds, answered by the runner. */
const notifyActionKinds = new Set(['ntf-defocus', 'ntf-refocus']);
/** The parent-performed wheel action of the OSC 720 suite: one exact kind, answered by the runner through the owned generated-input path. */
const osc720ActionKinds = new Set(['ovu-scroll-up', 'ovu-scroll-down']);
const untranslatedCellSteps = new Set(['start', 'bind', 'read', 'finish']);
/** Whether a request kind is exactly `<prefix>-<step>` for one of the cell observation prefixes and steps. */
function untranslatedCellKind(kind) {
    const parts = typeof kind === 'string' ? kind.split('-') : [];
    return parts.length === 2 && untranslatedCellPrefixes.has(parts[0]) && untranslatedCellSteps.has(parts[1]);
}

const sourceRepo = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const repo = process.env.NTILDE_TERMINFO_ORIGINAL_REPO ?? sourceRepo;
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const writeJson = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
/** The launcher owns the desktop lease; the runner may only take it (once) and report launch and cleanup facts through it. */
async function acquireDesktopLease(pendingInterruption) {
    const broker = globalThis[Symbol.for('ntilde.terminfo.desktopLease')];
    if (typeof broker?.acquire !== 'function') throw new Error('The owned runner must be started through scripts/terminfo-owned.mjs, which owns the desktop lease.');
    const lease = await broker.acquire();
    lease.assertHeld();
    const interruption = pendingInterruption();
    if (interruption) throw interruption; // the launcher settles (releases) the lease: nothing was launched
    return lease;
}
const quote = value => "'" + value.replaceAll("'", String.raw`'\''`) + "'";

/** Attempt parent-owned abort, then retain bounded primary/cleanup facts before independent process shutdown. */
async function retainPrivateClipboardAbort(state, error, phase, retain) {
    if (!state?.observer) return;
    await abortPrivateClipboardWithFacts(state, error, phase, createProcessBudget(4000));
    retain();
}
/** Keep at most eight privacy-safe journal-write failures; retention failure never grants completion or skips shutdown. */
function recordPrivateClipboardRetentionFailure(state, phase, error) {
    state.retentionFailures ??= [];
    if (state.retentionFailures.length < 8) state.retentionFailures.push({ phase, error: privateClipboardFailureFacts(error) });
    else state.retentionFailuresTruncated = true;
}

/** Retain privacy-safe private failure facts and return an Error preserving the original cause. */
function retainOwnedFailure(output, error, privateState) {
    let message = 'Owned private clipboard collection failed; see bounded failure facts.';
    if (!privateState) message = String(error?.message ?? error);
    const failure = { error: message, at: new Date().toISOString() };
    if (privateState) {
        failure.primary = privateClipboardFailureFacts(error);
        failure.privateClipboardFailures = privateState.failures ?? [];
        failure.failureFactsTruncated = privateState.failureFactsTruncated === true;
        failure.privateClipboardRetentionFailures = privateState.retentionFailures ?? [];
        failure.retentionFailuresTruncated = privateState.retentionFailuresTruncated === true;
    }
    writeJson(join(output, 'failure.json'), failure);
    return new Error(`${message} Evidence retained in ${output}`, { cause: error });
}

/** Await one shutdown attempt and retain rejection presence independently of its value. */
async function captureOwnedCleanup(action) {
    try { await action(); return { failed: false }; }
    catch (error) { return { failed: true, error }; }
}
/** Await one source-known evidence write; keep arbitrary rejection reasons inside an explicit outcome, never Promise-assimilate them. */
async function retainOwnedFailureStep(outcome, action) {
    try {
        const replacement = await action(outcome.error);
        if (replacement !== undefined) outcome.error = replacement;
    } catch (error_) {
        outcome.error = new AggregateError([outcome.error, error_], 'Owned failure evidence retention failed.');
    }
}
/** Chain every source-known failure journal serially so later writes see all earlier original/save outcomes before shutdown. */
async function retainOwnedFailureSequence(error, actions) {
    const outcome = { failed: true, error };
    await actions.reduce((pending, action) => pending.then(() => retainOwnedFailureStep(outcome, action)), Promise.resolve());
    return outcome;
}
/** Run after finally: aggregate the original run/cause and shutdown failure without truthiness tests. */
function throwOwnedRunFailures(run, cleanup) {
    if (run.failed && cleanup.failed) throw new AggregateError([run.error, cleanup.error], 'Owned run and process cleanup failed.');
    if (run.failed) throw run.error;
    if (cleanup.failed) throw cleanup.error;
}

/** Preserve only source-known initial App/geometry-budget refusal codes. */
function ownerFailure(error, privateFailure = false) {
    if (privateFailure) return { ok: false, error: 'Owned private clipboard owner refused; see bounded parent failure facts.' };
    return { ok: false, error: error.message,
        ...(['screenDetailsUnavailable', 'resizeGeometryUnavailable', 'savedGeometryUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable', 'inputGeometryUnavailable', 'imageGeometryUnavailable'].includes(error.code) ? { code: error.code } : {}) };
}

function requireInputCompletion(state) {
    if (!state?.observer?.restored && !state?.unavailable) throw new Error('Input suite is not sealed or initially unavailable.');
}
function requireAnimationCompletion(state) {
    if (!state?.observer?.captureRestored && !state?.unavailable) throw new Error('Kitty animation must be restored and sealed.');
}
function requireStaticImageCompletion(state) {
    if (!state?.observer?.captureRestored && !state?.unavailable) throw new Error('Static images must be restored and sealed.');
}

function requireQueryCompletion(state) {
    if (!state?.observer?.restored && !state?.unavailable) throw new Error('Query suite must be sealed and restored or initially unavailable.');
}
function assertExecutableUnchanged(executable, image) {
    const current = statSync(executable);
    if (image.ino !== current.ino || image.size !== current.size || image.mtimeMs !== current.mtimeMs)
        throw new Error('Owned executable changed during collection.');
}
function retainQueryReport(output, state, runId) {
    requireQueryCompletion(state);
    if (state.unavailable) return state.unavailable;
    const report = state.observer.report, file = 'query-observations.json'; writeJson(join(output, file), report);
    const counts = {};
    for (const item of report.observations) { const key = item.contractMatched ? 'matched' : 'mismatched'; counts[key] = (counts[key] ?? 0) + 1; }
    return { runId, suiteId: querySuiteId, file, sha256: hash(readFileSync(join(output, file))), counts, provisionalUntil: 'cell-receipt.json' };
}

function retainFailedMetadataAttempt(output, request, error, observer, file = 'metadata-failed-observation.json') {
    if (observer.lastAttempt && !initialMetadataRefusal(request, error, observer))
        writeJson(join(output, file), { ...observer.lastAttempt, error: observer.failure(error) });
}

const focusedSuite = globalThis[Symbol.for('ntilde.terminfo.focusedSuite')];

function validateInvocation(args) {
    if (![4, 6].includes(args.length) || args[0] !== '--executable' || args[2] !== '--app-version'
        || (args.length === 6 && (args[4] !== '--scope' || !['osc633', 'static-images', 'persistent-animation', 'persistent-restore', 'persistent-compose', 'direct-compose', 'persistent-placeholders', 'direct-placeholders', 'persistent-placeholder-grid', 'direct-placeholder-grid', 'modern-blink', 'modern-viewport', 'modern-osc-titles', 'modern-osc7-cwd', 'modern-child-environment', 'rich-vendor-environment', 'unicode-width', 'unicode-boundaries', 'kitty-graphics', 'font-ligatures', 'modify-other-keys-3', 'modify-other-keys-3-baseline', 'osc66', 'sixel-reports', 'osc633-metadata'].includes(args[5])))
        || !/^\d[\dA-Za-z.+_-]*$/.test(args[3])) throw new Error('Use --help for the required executable and version arguments.');
    if (process.platform !== 'darwin') throw new Error('The owned adapter currently supports macOS only.');
    if (Number(process.versions.node.split('.')[0]) < 24) throw new Error('Node 24+ is required.');
    return resolveOwnedExecutable(args[1]);
}

function readPreparedCollector(tool) {
    const pkg = join(tool, 'node_modules', 'terminfo.dev');
    const original = join(pkg, 'dist', 'terminfo.bundle.mjs');
    if (!existsSync(original)) throw new Error('Prepare the pinned collector first; see docs/qa/QA_TERMINFO.md.');
    if (JSON.parse(readFileSync(join(pkg, 'package.json'))).version !== '4.0.0') throw new Error('Expected terminfo.dev 4.0.0.');
    const source = readFileSync(original, 'utf8');
    const receiptBytes = readFileSync(join(pkg, 'dist', 'terminfo.bundle.receipt.json'));
    validateCollectorReceipt(source, JSON.parse(receiptBytes));
    const lockBytes = readCollectorLockfile(tool);
    const manifestBytes = readFileSync(join(tool, 'package.json'));
    validateCollectorInputs(manifestBytes, lockBytes);
    return { source, receiptBytes, lockBytes, manifestBytes };
}

function prepareCollector(tool) {
    const { source, receiptBytes, lockBytes } = readPreparedCollector(tool);
    const ownerModule = join(sourceRepo, 'scripts', 'terminfo', 'ownership.mjs');
    const privateClipboardModulePath = join(sourceRepo, 'scripts', 'terminfo', 'private-clipboard-worker.mjs');
    const adapted = adaptCollector(source, ownerModule, { privateClipboardModulePath });
    const adapterBundleSha256 = hash(adapted);
    // Keep external package resolution beside the original bundle. A derived
    // file is content-addressed; the downloaded original is never overwritten.
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-${adapterBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== adapterBundleSha256) throw new Error('Derived adapter bundle digest mismatch.');

    return { ownerModule, bundle, adapterBundleSha256, receiptBytes, lockBytes, originalBundle: source };
}

/** Derive and lock the ASCII/SGR grading extension beside the owned adapter. */
function prepareGradingCollector(tool, ownedBundle, output) {
    const adapted = adaptGradingCollector(readFileSync(ownedBundle));
    const gradingBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-grading-${gradingBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== gradingBundleSha256) throw new Error('Derived grading bundle digest mismatch.');
    writeFileSync(join(output, 'collector-grading.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, gradingBundleSha256 };
}

/** Derive and lock the layered SGR-colors grading extension over the first. */
function prepareSgrColorsCollector(tool, gradingBundle, output) {
    const adapted = adaptSgrColorsCollector(readFileSync(gradingBundle));
    const sgrColorsBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgrcolors-${sgrColorsBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrColorsBundleSha256) throw new Error('Derived SGR-colors bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgcolors.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrColorsBundleSha256 };
}

/** Derive and lock the layered SGR-RGB grading extension over the SGR-colors one. */
function prepareSgrRgbCollector(tool, sgrColorsBundle, output) {
    const adapted = adaptSgrRgbCollector(readFileSync(sgrColorsBundle));
    const sgrRgbBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgrrgb-${sgrRgbBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrRgbBundleSha256) throw new Error('Derived SGR-RGB bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgrgb.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrRgbBundleSha256 };
}

/** Derive and lock the layered SGR-attributes grading extension over the SGR-RGB one. */
function prepareSgrAttrsCollector(tool, sgrRgbBundle, output) {
    const adapted = adaptSgrAttrsCollector(readFileSync(sgrRgbBundle));
    const sgrAttrsBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgrattr-${sgrAttrsBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrAttrsBundleSha256) throw new Error('Derived SGR-attributes bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgattr.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrAttrsBundleSha256 };
}

/** Derive and lock the layered SGR-palette grading extension over the SGR-attributes one. */
function prepareSgrPaletteCollector(tool, sgrAttrsBundle, output) {
    const adapted = adaptSgrPaletteCollector(readFileSync(sgrAttrsBundle));
    const sgrPaletteBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgrpal-${sgrPaletteBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrPaletteBundleSha256) throw new Error('Derived SGR-palette bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgpal.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrPaletteBundleSha256 };
}

/** Derive and lock the layered SGR-underline-color grading extension over the SGR-underline one. */
function prepareSgrUnderlineColorCollector(tool, sgrUnderlineBundle, output) {
    const adapted = adaptSgrUnderlineColorCollector(readFileSync(sgrUnderlineBundle));
    const sgrUnderlineColorBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgruc-${sgrUnderlineColorBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrUnderlineColorBundleSha256) throw new Error('Derived SGR-underline-color bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sguc.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrUnderlineColorBundleSha256 };
}

/** Derive and lock the layered SGR-underline grading extension over the SGR-truecolor one. */
function prepareSgrUnderlineCollector(tool, sgrTruecolorBundle, output) {
    const adapted = adaptSgrUnderlineCollector(readFileSync(sgrTruecolorBundle));
    const sgrUnderlineBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgrus-${sgrUnderlineBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrUnderlineBundleSha256) throw new Error('Derived SGR-underline bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgus.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrUnderlineBundleSha256 };
}

/** Derive and lock the layered SGR-truecolor grading extension over the SGR-palette one. */
function prepareSgrTruecolorCollector(tool, sgrPaletteBundle, output) {
    const adapted = adaptSgrTruecolorCollector(readFileSync(sgrPaletteBundle));
    const sgrTruecolorBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgrtc-${sgrTruecolorBundleSha256}.mjs`);
    if (!existsSync(bundle)) writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrTruecolorBundleSha256) throw new Error('Derived SGR-truecolor bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgtc.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrTruecolorBundleSha256 };
}

function collectionSummary(output, appVersion) {
    const rawPath = join(output, 'raw.json');
    const raw = JSON.parse(readFileSync(rawPath));
    if (raw.schemaVersion !== 2 || raw.target?.id !== 'ntilde' || raw.target?.version !== appVersion
        || raw.collectorAdapter?.id !== adapterId || raw.probeHash !== upstreamReceipt.probeHash
        || raw.sourceRevision !== upstreamReceipt.collectorRevision) throw new Error('Unexpected collected identity or suite.');
    const counts = {};
    const reasons = {};
    for (const observation of raw.observations) {
        counts[observation.outcome] = (counts[observation.outcome] ?? 0) + 1;
        if (observation.reason) reasons[observation.reason] = (reasons[observation.reason] ?? 0) + 1;
    }
    return { runId: raw.runId, suiteId: raw.suiteId, suiteComplete: raw.suiteComplete,
        ungradedDiagnostics: raw.ungradedDiagnostics, measuredAt: raw.measuredAt, target: raw.target,
        adapter: raw.collectorAdapter, observations: raw.observations.length, counts, reasons, rawSha256: hash(readFileSync(rawPath)) };
}

/** The private settings of an owned collection: one disposable profile running the worker, with Observe and Act access and no unrelated UI. */
function ownedSettings({ profileId, profileName, command, scratch, persistence }) {
    return {
        Profiles: [{ Id: profileId, Name: profileName, Command: command, Arguments: '', StartingDirectory: scratch, Type: 0 }],
        DefaultProfileId: profileId, SessionPersistence: persistence, ShellExitPolicy: 'Always', PaneClosePolicy: 'Always',
        QuakeModeEnabled: false, AutomaticUpdateChecks: false, AllowOsc52ClipboardWrite: true, AllowRectangleChecksumReport: true, AllowTitleReport: true,
        MinimumContrast: 1, EnableLigatures: false,
        BellAudioEnabled: false, BellVisualEnabled: false, SmoothScrolling: false,
        Osc9NotificationsEnabled: true, Osc9ProgressReportingEnabled: true, TabStripOrientation: 'Horizontal',
        CommandAssistEnabled: false, CommandAssistShellIntegrationEnabled: false,
        CommandAssistPowerShellIntegrationEnabled: false, AgentAccessObserveEnabled: true, AgentAccessActEnabled: true,
    };
}

/** Archive exact executed adapter and source/input bytes before publishing their digests. */
function retainCollectorEvidence(output, bundle, expectedDigest, ownerModule, workerScript) {
    const bundleBytes = readFileSync(bundle);
    if (hash(bundleBytes) !== expectedDigest) throw new Error('Derived adapter changed before evidence retention.');
    writeFileSync(join(output, 'collector-adapter.mjs'), bundleBytes, { flag: 'wx', mode: 0o600 });
    const { sources, digests } = retainSourceCopies(output);
    if (sources.ownershipSourceSha256 !== ownerModule || sources.workerSourceSha256 !== workerScript)
        throw new Error('Executed worker or ownership source differs from the retained inventory.');
    return digests;
}

/** Copy every measured source file into the run's evidence and name its digest; returns the paths read and the digests by inventory field. */
function retainSourceCopies(output) {
    const sourceDirectory = join(output, 'sources');
    mkdirSync(sourceDirectory, { mode: 0o700 });
    const sources = Object.fromEntries(Object.entries(ownedSourceFiles).map(([key, file]) => [key, ownedSourcePath(sourceRepo, file)]));
    const digests = {};
    for (const [field, path] of Object.entries(sources)) {
        const bytes = readFileSync(path);
        writeFileSync(join(sourceDirectory, ownedSourceFiles[field]), bytes, { flag: 'wx', mode: 0o600 });
        digests[field] = hash(bytes);
    }
    return { sources, digests };
}

/**
 * One image-carrier suite's observer: created on first use from the previous suite's evidence, bound to the proved worker and PTY, and
 * journaled as it goes. `carrier` names the suite's state, proof slot, retained files, plan size and prerequisite; `environment` is the
 * run's App, profile, output, proofs and (when a cell suite ran first) the reference pane the carrier must agree with.
 */
async function observeImageCarrierIn(environment, carrier, request, budget, ownership) {
    const { appData, app, profileName, output, runId, proofs, reference } = environment;
    carrier.require();
    let state = carrier.state();
    if (!state) {
        const priorChallenges = carrier.priorFrames().filter(frame => frame.capture).map(frame => frame.capture.nonces.join(','));
        state = carrier.setState({ workerPid: request.workerPid, tty: request.tty, recordedFrames: 0, recordedActions: 0,
            observer: new carrier.Observer({ appData, ownerPid: app.pid, profileName, output,
                nonce: 'NTILDE_IMG_' + runId, expectedPaneId: reference?.paneId, priorChallenges, captureScale: carrier.captureScale, deferReport: environment.deferReport === true }) });
        proofs[0][carrier.proof].actions = state.observer.actions;
    }
    if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error(carrier.label + ' fixture ownership changed.');
    try {
        const result = await state.observer.handle(request, budget, ownership);
        if (request.kind === carrier.prefix + 'start') {
            if (reference && (result.screen.rows !== reference.baseline.rows || result.screen.cols !== reference.baseline.cols)) throw new Error(carrier.label + ' fixture geometry changed.');
            proofs[0][carrier.proof].paneId = state.observer.paneId;
            proofs[0][carrier.proof].geometry = { rows: result.screen.rows, cols: result.screen.cols };
        }
        if (request.kind === carrier.prefix + 'seal') proofs[0][carrier.proof].seal = state.observer.seal;
        return result;
    } catch (error) {
        const initial = request.kind === carrier.prefix + 'start' && ['screenDetailsUnavailable', 'imageGeometryUnavailable'].includes(error.code)
            && !state.observer.baseline && !state.observer.frames.length && !state.observer.actions.length
            && !existsSync(join(output, carrier.pixelDir)) && !existsSync(join(output, carrier.inputDir));
        if (initial) {
            const file = carrier.file + '-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: carrier.suiteId, status: 'unavailable',
                reason: error.code, fixtureStarted: false, plannedExperiments: carrier.planned.experiments, plannedStages: carrier.planned.stages });
            state.unavailable = { runId, suiteId: carrier.suiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason: error.code, counts: {} };
        } else if (state.observer.lastAttempt) writeJson(join(output, carrier.file + '-failed-observation.json'), state.observer.lastAttempt);
        throw error;
    } finally {
        for (const frame of state.observer.frames.slice(state.recordedFrames)) appendFileSync(join(output, carrier.file + '-snapshots.jsonl'), JSON.stringify(frame) + '\n');
        state.recordedFrames = state.observer.frames.length;
        for (const action of state.observer.actions.slice(state.recordedActions)) appendFileSync(join(output, carrier.file + '-actions.jsonl'), JSON.stringify(action) + '\n');
        state.recordedActions = state.observer.actions.length;
    }
}

/** Retain a restored suite report as provisional evidence until the shared cleanup receipt exists. */
function retainCellReport(output, observer, runId, buildReport = buildCellReport, file = 'cell-observations.json') {
    if (!observer?.restored) throw new Error('Owned cell observation or restoration did not complete.');
    const report = buildReport(observer.frames, runId);
    writeJson(join(output, file), report);
    const counts = {};
    for (const item of report.observations) counts[item.result] = (counts[item.result] ?? 0) + 1;
    return { runId, suiteId: report.suiteId, file, sha256: hash(readFileSync(join(output, file))), counts,
        provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-colors report parent-side with the layered pinned replay. */
async function retainSgrColorsEvidence(output, runId, sgrColorsBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgcolors-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgcolors-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgcolors.mjs'));
    const adapter = { id: sgrColorsAdapterId, derivedFromAdapterId: 'ntilde-owned-ascii-sgr-grading-v1',
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrColorsBundle).href);
    const report = buildSgrColorsGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgcolors-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrColorsSuiteId, file: 'sgcolors-observations.json',
        sha256: hash(readFileSync(join(output, 'sgcolors-observations.json'))),
        runFile: 'sgcolors-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrColorsContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-RGB report parent-side with the layered pinned replay. */
async function retainSgrRgbEvidence(output, runId, sgrRgbBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgrgb-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgrgb-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgrgb.mjs'));
    const adapter = { id: sgrRgbAdapterId, derivedFromAdapterId: sgrColorsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrRgbBundle).href);
    const report = buildSgrRgbGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgrgb-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrRgbSuiteId, file: 'sgrgb-observations.json',
        sha256: hash(readFileSync(join(output, 'sgrgb-observations.json'))),
        runFile: 'sgrgb-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrRgbContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-attributes report parent-side with the layered pinned replay. */
async function retainSgrAttrsEvidence(output, runId, sgrAttrsBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgattr-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgattr-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgattr.mjs'));
    const adapter = { id: sgrAttrsAdapterId, derivedFromAdapterId: sgrRgbAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrAttrsBundle).href);
    const report = buildSgrAttrsGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgattr-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrAttrsSuiteId, file: 'sgattr-observations.json',
        sha256: hash(readFileSync(join(output, 'sgattr-observations.json'))),
        runFile: 'sgattr-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrAttrsContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-palette report parent-side with the layered pinned replay. */
async function retainSgrPaletteEvidence(output, runId, sgrPaletteBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgpal-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgpal-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgpal.mjs'));
    const adapter = { id: sgrPaletteAdapterId, derivedFromAdapterId: sgrAttrsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrPaletteBundle).href);
    const report = buildSgrPaletteGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgpal-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrPaletteSuiteId, file: 'sgpal-observations.json',
        sha256: hash(readFileSync(join(output, 'sgpal-observations.json'))),
        runFile: 'sgpal-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrPaletteContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-truecolor report parent-side with the layered pinned replay. */
async function retainSgrTruecolorEvidence(output, runId, sgrTruecolorBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgtc-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgtc-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgtc.mjs'));
    const adapter = { id: sgrTruecolorAdapterId, derivedFromAdapterId: sgrPaletteAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrTruecolorBundle).href);
    const report = buildSgrTruecolorGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgtc-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrTruecolorSuiteId, file: 'sgtc-observations.json',
        sha256: hash(readFileSync(join(output, 'sgtc-observations.json'))),
        runFile: 'sgtc-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrTruecolorContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered SGR selective-reset grading extension over the SGR-underline-color one. */
function prepareSgrResetCollector(tool, sgrUnderlineColorBundle, output) {
    const adapted = adaptSgrResetCollector(readFileSync(sgrUnderlineColorBundle));
    const sgrResetBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgsr-${sgrResetBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrResetBundleSha256) throw new Error('Derived SGR selective-reset bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgsr.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrResetBundleSha256 };
}

/** Derive and lock the layered SGR closure grading extension over the SGR selective-reset one. */
function prepareSgrClosureCollector(tool, sgrResetBundle, output) {
    const adapted = adaptSgrClosureCollector(readFileSync(sgrResetBundle));
    const sgrClosureBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sgcl-${sgrClosureBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sgrClosureBundleSha256) throw new Error('Derived SGR closure bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sgcl.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, sgrClosureBundleSha256 };
}

/** Re-derive the SGR closure report parent-side with the layered pinned replay. */
async function retainSgrClosureEvidence(output, runId, sgrClosureBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgcl-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgcl-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgcl.mjs'));
    const adapter = { id: sgrClosureAdapterId, derivedFromAdapterId: sgrResetAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrClosureBundle).href);
    const report = buildSgrClosureGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgcl-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrClosureSuiteId, file: 'sgcl-observations.json',
        sha256: hash(readFileSync(join(output, 'sgcl-observations.json'))),
        runFile: 'sgcl-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrClosureContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR selective-reset report parent-side with the layered pinned replay. */
async function retainSgrResetEvidence(output, runId, sgrResetBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgsr-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgsr-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgsr.mjs'));
    const adapter = { id: sgrResetAdapterId, derivedFromAdapterId: sgrUnderlineColorAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrResetBundle).href);
    const report = buildSgrResetGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgsr-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrResetSuiteId, file: 'sgsr-observations.json',
        sha256: hash(readFileSync(join(output, 'sgsr-observations.json'))),
        runFile: 'sgsr-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrResetContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered erase-in-line grading extension over the SGR closure one. */
function prepareEraseLineCollector(tool, sgrClosureBundle, output) {
    const adapted = adaptEraseLineCollector(readFileSync(sgrClosureBundle));
    const eraseLineBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-erln-${eraseLineBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== eraseLineBundleSha256) throw new Error('Derived erase-in-line bundle digest mismatch.');
    writeFileSync(join(output, 'collector-erln.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, eraseLineBundleSha256 };
}

/** Re-derive the erase-in-line report parent-side with the layered pinned replay. */
async function retainEraseLineEvidence(output, runId, eraseLineBundle, upstream) {
    const runBytes = readFileSync(join(output, 'erln-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'erln-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-erln.mjs'));
    const adapter = { id: eraseLineAdapterId, derivedFromAdapterId: sgrClosureAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(eraseLineBundle).href);
    const report = buildEraseLineGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'erln-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: eraseLineSuiteId, file: 'erln-observations.json',
        sha256: hash(readFileSync(join(output, 'erln-observations.json'))),
        runFile: 'erln-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: eraseLineContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered character-editing grading extension over the erase-in-line one. */
function prepareCharEditCollector(tool, eraseLineBundle, output) {
    const adapted = adaptCharEditCollector(readFileSync(eraseLineBundle));
    const charEditBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-ched-${charEditBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== charEditBundleSha256) throw new Error('Derived character-editing bundle digest mismatch.');
    writeFileSync(join(output, 'collector-ched.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, charEditBundleSha256 };
}

/** Re-derive the character-editing report parent-side with the layered pinned replay. */
async function retainCharEditEvidence(output, runId, charEditBundle, upstream) {
    const runBytes = readFileSync(join(output, 'ched-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'ched-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-ched.mjs'));
    const adapter = { id: charEditAdapterId, derivedFromAdapterId: eraseLineAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(charEditBundle).href);
    const report = buildCharEditGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'ched-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: charEditSuiteId, file: 'ched-observations.json',
        sha256: hash(readFileSync(join(output, 'ched-observations.json'))),
        runFile: 'ched-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: charEditContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered erase-in-display grading extension over the character-editing one. */
function prepareEraseDisplayCollector(tool, charEditBundle, output) {
    const adapted = adaptEraseDisplayCollector(readFileSync(charEditBundle));
    const eraseDisplayBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-erdi-${eraseDisplayBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== eraseDisplayBundleSha256) throw new Error('Derived erase-in-display bundle digest mismatch.');
    writeFileSync(join(output, 'collector-erdi.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, eraseDisplayBundleSha256 };
}

/** Re-derive the erase-in-display report parent-side with the layered pinned replay. */
async function retainEraseDisplayEvidence(output, runId, eraseDisplayBundle, upstream) {
    const runBytes = readFileSync(join(output, 'erdi-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'erdi-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-erdi.mjs'));
    const adapter = { id: eraseDisplayAdapterId, derivedFromAdapterId: charEditAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(eraseDisplayBundle).href);
    const report = buildEraseDisplayGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'erdi-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: eraseDisplaySuiteId, file: 'erdi-observations.json',
        sha256: hash(readFileSync(join(output, 'erdi-observations.json'))),
        runFile: 'erdi-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: eraseDisplayContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered line-editing grading extension over the character-editing one. */
function prepareLineEditCollector(tool, eraseDisplayBundle, output) {
    const adapted = adaptLineEditCollector(readFileSync(eraseDisplayBundle));
    const lineEditBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-ledt-${lineEditBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== lineEditBundleSha256) throw new Error('Derived line-editing bundle digest mismatch.');
    writeFileSync(join(output, 'collector-ledt.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, lineEditBundleSha256 };
}

/** Re-derive the line-editing report parent-side with the layered pinned replay. */
async function retainLineEditEvidence(output, runId, lineEditBundle, upstream) {
    const runBytes = readFileSync(join(output, 'ledt-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'ledt-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-ledt.mjs'));
    const adapter = { id: lineEditAdapterId, derivedFromAdapterId: eraseDisplayAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(lineEditBundle).href);
    const report = buildLineEditGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'ledt-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: lineEditSuiteId, file: 'ledt-observations.json',
        sha256: hash(readFileSync(join(output, 'ledt-observations.json'))),
        runFile: 'ledt-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: lineEditContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered charsets grading extension over the line-editing one. */
function prepareCharsetsCollector(tool, lineEditBundle, output) {
    const adapted = adaptCharsetsCollector(readFileSync(lineEditBundle));
    const charsetsBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-chrs-${charsetsBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== charsetsBundleSha256) throw new Error('Derived charsets bundle digest mismatch.');
    writeFileSync(join(output, 'collector-chrs.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, charsetsBundleSha256 };
}

/** Re-derive the charsets report parent-side with the layered pinned replay. */
async function retainCharsetsEvidence(output, runId, charsetsBundle, upstream) {
    const runBytes = readFileSync(join(output, 'chrs-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'chrs-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-chrs.mjs'));
    const adapter = { id: charsetsAdapterId, derivedFromAdapterId: lineEditAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(charsetsBundle).href);
    const report = buildCharsetsGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'chrs-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: charsetsSuiteId, file: 'chrs-observations.json',
        sha256: hash(readFileSync(join(output, 'chrs-observations.json'))),
        runFile: 'chrs-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: charsetsContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered scrolling/history grading extension over the charsets one. */
function prepareScrollbackCollector(tool, charsetsBundle, output) {
    const adapted = adaptScrollbackCollector(readFileSync(charsetsBundle));
    const scrollbackBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-scrl-${scrollbackBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== scrollbackBundleSha256) throw new Error('Derived scrolling/history bundle digest mismatch.');
    writeFileSync(join(output, 'collector-scrl.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, scrollbackBundleSha256 };
}

/** Re-derive the scrolling/history report parent-side with the layered pinned replay. */
async function retainScrollbackEvidence(output, runId, scrollbackBundle, upstream) {
    const runBytes = readFileSync(join(output, 'scrl-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'scrl-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-scrl.mjs'));
    const adapter = { id: scrollbackAdapterId, derivedFromAdapterId: charsetsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(scrollbackBundle).href);
    const report = buildScrollbackGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'scrl-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: scrollbackSuiteId, file: 'scrl-observations.json',
        sha256: hash(readFileSync(join(output, 'scrl-observations.json'))),
        runFile: 'scrl-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: scrollbackContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered saved-state/reset grading extension over the scrolling/history one. */
function prepareSavedResetCollector(tool, scrollbackBundle, output) {
    const adapted = adaptSavedResetCollector(readFileSync(scrollbackBundle));
    const savedResetBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-svrs-${savedResetBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== savedResetBundleSha256) throw new Error('Derived saved-state/reset bundle digest mismatch.');
    writeFileSync(join(output, 'collector-svrs.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, savedResetBundleSha256 };
}

/** Re-derive the saved-state/reset report parent-side with the layered pinned replay. */
async function retainSavedResetEvidence(output, runId, savedResetBundle, upstream) {
    const runBytes = readFileSync(join(output, 'svrs-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'svrs-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-svrs.mjs'));
    const adapter = { id: savedResetAdapterId, derivedFromAdapterId: scrollbackAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(savedResetBundle).href);
    const report = buildSavedResetGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'svrs-observations.json'), report);
    const { counts, effectCounts } = savedResetCounts(report);
    return { runId, suiteId: savedResetSuiteId, file: 'svrs-observations.json',
        sha256: hash(readFileSync(join(output, 'svrs-observations.json'))),
        runFile: 'svrs-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: savedResetContractsVersion, counts, effectCounts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered erase attributes / erase margins grading extension over the saved-state/reset one. */
function prepareEraseAttrsRegionCollector(tool, savedResetBundle, output) {
    const adapted = adaptEraseAttrsRegionCollector(readFileSync(savedResetBundle));
    const eraseAttrsRegionBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-erar-${eraseAttrsRegionBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== eraseAttrsRegionBundleSha256) throw new Error('Derived erase-attributes bundle digest mismatch.');
    writeFileSync(join(output, 'collector-erar.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, eraseAttrsRegionBundleSha256 };
}

/** Re-derive the erase attributes / erase margins report parent-side with the layered pinned replay. */
async function retainEraseAttrsRegionEvidence(output, runId, eraseAttrsRegionBundle, upstream) {
    const runBytes = readFileSync(join(output, 'erar-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'erar-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-erar.mjs'));
    const adapter = { id: eraseAttrsRegionAdapterId, derivedFromAdapterId: savedResetAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(eraseAttrsRegionBundle).href);
    const report = buildEraseAttrsRegionGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'erar-observations.json'), report);
    const { counts } = eraseAttrsRegionCounts(report);
    return { runId, suiteId: eraseAttrsRegionSuiteId, file: 'erar-observations.json',
        sha256: hash(readFileSync(join(output, 'erar-observations.json'))),
        runFile: 'erar-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: eraseAttrsRegionContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered attribute-rectangle grading extension over the erase attributes / erase margins one. */
function prepareAttrRectCollector(tool, eraseAttrsRegionBundle, output) {
    const adapted = adaptAttrRectCollector(readFileSync(eraseAttrsRegionBundle));
    const attrRectBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-atrc-${attrRectBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== attrRectBundleSha256) throw new Error('Derived attribute-rectangle bundle digest mismatch.');
    writeFileSync(join(output, 'collector-atrc.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, attrRectBundleSha256 };
}

/** Re-derive the attribute-rectangle report parent-side with the layered pinned replay. */
async function retainAttrRectEvidence(output, runId, attrRectBundle, upstream) {
    const runBytes = readFileSync(join(output, 'atrc-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'atrc-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-atrc.mjs'));
    const adapter = { id: attrRectAdapterId, derivedFromAdapterId: eraseAttrsRegionAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(attrRectBundle).href);
    const report = buildAttrRectGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'atrc-observations.json'), report);
    const { counts, effectCounts } = attrRectCounts(report);
    return { runId, suiteId: attrRectSuiteId, file: 'atrc-observations.json',
        sha256: hash(readFileSync(join(output, 'atrc-observations.json'))),
        runFile: 'atrc-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: attrRectContractsVersion, counts, effectCounts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered cursor grading extension over the attribute-rectangle one. */
function prepareCursorQualCollector(tool, attrRectBundle, output) {
    const adapted = adaptCursorQualCollector(readFileSync(attrRectBundle));
    const cursorQualBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-curq-${cursorQualBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== cursorQualBundleSha256) throw new Error('Derived cursor bundle digest mismatch.');
    writeFileSync(join(output, 'collector-curq.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, cursorQualBundleSha256 };
}

/** Re-derive the cursor report parent-side (ports, retained CPR exchanges and every retained PNG), then replay the LIVE pinned callbacks. */
async function retainCursorQualEvidence(output, runId, cursorQualBundle, upstream) {
    const runBytes = readFileSync(join(output, 'curq-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'curq-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-curq.mjs'));
    const adapter = { id: cursorQualAdapterId, derivedFromAdapterId: attrRectAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const report = buildCursorQualGradingReport(frames, run, runId, adapter, { output });
    await verifyCursorQualLiveReplay(frames, run, runId, adapter, await import(pathToFileURL(cursorQualBundle).href));
    writeJson(join(output, 'curq-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: cursorQualSuiteId, file: 'curq-observations.json',
        sha256: hash(readFileSync(join(output, 'curq-observations.json'))),
        runFile: 'curq-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: cursorQualContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered erase-character/saved-lines grading extension over the cursor-qualification one. */
function prepareEraseCharsHistoryCollector(tool, cursorQualBundle, output) {
    const adapted = adaptEraseCharsHistoryCollector(readFileSync(cursorQualBundle));
    const eraseCharsHistoryBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-echh-${eraseCharsHistoryBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== eraseCharsHistoryBundleSha256) throw new Error('Derived erase-character/saved-lines bundle digest mismatch.');
    writeFileSync(join(output, 'collector-echh.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, eraseCharsHistoryBundleSha256 };
}

/** Re-derive the erase-character/saved-lines report parent-side with the layered pinned replay. */
async function retainEraseCharsHistoryEvidence(output, runId, eraseCharsHistoryBundle, upstream) {
    const runBytes = readFileSync(join(output, 'echh-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'echh-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-echh.mjs'));
    const adapter = { id: eraseCharsHistoryAdapterId, derivedFromAdapterId: cursorQualAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(eraseCharsHistoryBundle).href);
    const report = buildEraseCharsHistoryGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'echh-observations.json'), report);
    return { runId, suiteId: eraseCharsHistorySuiteId, file: 'echh-observations.json',
        sha256: hash(readFileSync(join(output, 'echh-observations.json'))),
        runFile: 'echh-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: eraseCharsHistoryContractsVersion, counts: eraseCharsHistoryCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered selective-erasure grading extension over the erase-character/saved-lines one. */
function prepareSelectiveEraseCollector(tool, eraseCharsHistoryBundle, output) {
    const adapted = adaptSelectiveEraseCollector(readFileSync(eraseCharsHistoryBundle));
    const selectiveEraseBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-sels-${selectiveEraseBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== selectiveEraseBundleSha256) throw new Error('Derived selective-erasure bundle digest mismatch.');
    writeFileSync(join(output, 'collector-sels.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, selectiveEraseBundleSha256 };
}

/** Re-derive the selective-erasure report parent-side with the layered pinned replay. */
async function retainSelectiveEraseEvidence(output, runId, selectiveEraseBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sels-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sels-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sels.mjs'));
    const adapter = { id: selectiveEraseAdapterId, derivedFromAdapterId: eraseCharsHistoryAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(selectiveEraseBundle).href);
    const report = buildSelectiveEraseGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sels-observations.json'), report);
    return { runId, suiteId: selectiveEraseSuiteId, file: 'sels-observations.json',
        sha256: hash(readFileSync(join(output, 'sels-observations.json'))),
        runFile: 'sels-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: selectiveEraseContractsVersion, counts: selectiveEraseCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered rectangle-editing grading extension over the selective-erasure one. */
function prepareRectEditCollector(tool, selectiveEraseBundle, output) {
    const adapted = adaptRectEditCollector(readFileSync(selectiveEraseBundle));
    const rectEditBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-rect-${rectEditBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== rectEditBundleSha256) throw new Error('Derived rectangle-editing bundle digest mismatch.');
    writeFileSync(join(output, 'collector-rect.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, rectEditBundleSha256 };
}

/** Re-derive the rectangle-editing report parent-side with the layered pinned replay. */
async function retainRectEditEvidence(output, runId, rectEditBundle, upstream) {
    const runBytes = readFileSync(join(output, 'rect-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'rect-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-rect.mjs'));
    const adapter = { id: rectEditAdapterId, derivedFromAdapterId: selectiveEraseAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(rectEditBundle).href);
    const report = buildRectEditGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'rect-observations.json'), report);
    return { runId, suiteId: rectEditSuiteId, file: 'rect-observations.json',
        sha256: hash(readFileSync(join(output, 'rect-observations.json'))),
        runFile: 'rect-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: rectEditContractsVersion, counts: rectEditCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered column-editing grading extension over the rectangle-editing one. */
function prepareColEditCollector(tool, rectEditBundle, output) {
    const adapted = adaptColEditCollector(readFileSync(rectEditBundle));
    const colEditBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-cole-${colEditBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== colEditBundleSha256) throw new Error('Derived column-editing bundle digest mismatch.');
    writeFileSync(join(output, 'collector-cole.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, colEditBundleSha256 };
}

/** Re-derive the column-editing report parent-side with the layered pinned replay. */
async function retainColEditEvidence(output, runId, colEditBundle, upstream) {
    const runBytes = readFileSync(join(output, 'cole-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'cole-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-cole.mjs'));
    const adapter = { id: colEditAdapterId, derivedFromAdapterId: rectEditAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(colEditBundle).href);
    const report = buildColEditGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'cole-observations.json'), report);
    return { runId, suiteId: colEditSuiteId, file: 'cole-observations.json',
        sha256: hash(readFileSync(join(output, 'cole-observations.json'))),
        runFile: 'cole-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: colEditContractsVersion, counts: colEditCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered rectangle-checksum grading extension over the column-editing one. */
function prepareRectChecksumCollector(tool, colEditBundle, output) {
    const adapted = adaptRectChecksumCollector(readFileSync(colEditBundle));
    const rectChecksumBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-csum-${rectChecksumBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== rectChecksumBundleSha256) throw new Error('Derived rectangle-checksum bundle digest mismatch.');
    writeFileSync(join(output, 'collector-csum.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, rectChecksumBundleSha256 };
}

/** Re-derive the rectangle-checksum report parent-side with the layered pinned replay. */
async function retainRectChecksumEvidence(output, runId, rectChecksumBundle, upstream) {
    const runBytes = readFileSync(join(output, 'csum-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'csum-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-csum.mjs'));
    const adapter = { id: rectChecksumAdapterId, derivedFromAdapterId: colEditAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(rectChecksumBundle).href);
    const report = buildRectChecksumGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'csum-observations.json'), report);
    return { runId, suiteId: rectChecksumSuiteId, file: 'csum-observations.json',
        sha256: hash(readFileSync(join(output, 'csum-observations.json'))),
        runFile: 'csum-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: rectChecksumContractsVersion, counts: rectChecksumCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered left/right-margin grading extension over the rectangle-checksum one. */
function prepareLrMarginsCollector(tool, rectChecksumBundle, output) {
    const adapted = adaptLrMarginsCollector(readFileSync(rectChecksumBundle));
    const lrMarginsBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-lrmm-${lrMarginsBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== lrMarginsBundleSha256) throw new Error('Derived left/right-margin bundle digest mismatch.');
    writeFileSync(join(output, 'collector-lrmm.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, lrMarginsBundleSha256 };
}

/** Re-derive the left/right-margin report parent-side with the layered pinned replay. */
async function retainLrMarginsEvidence(output, runId, lrMarginsBundle, upstream) {
    const runBytes = readFileSync(join(output, 'lrmm-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'lrmm-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-lrmm.mjs'));
    const adapter = { id: lrMarginsAdapterId, derivedFromAdapterId: rectChecksumAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(lrMarginsBundle).href);
    const report = buildLrMarginsGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'lrmm-observations.json'), report);
    return { runId, suiteId: lrMarginsSuiteId, file: 'lrmm-observations.json',
        sha256: hash(readFileSync(join(output, 'lrmm-observations.json'))),
        runFile: 'lrmm-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: lrMarginsContractsVersion, counts: lrMarginsCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered routed-input grading extension over the left/right-margin one. */
function prepareRoutedInputCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptRoutedInputCollector(readFileSync(lrMarginsBundle));
    const routedInputBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-rin-${routedInputBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== routedInputBundleSha256) throw new Error('Derived routed-input bundle digest mismatch.');
    writeFileSync(join(output, 'collector-rin.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, routedInputBundleSha256 };
}

/** Derive and lock the layered OSC 133 grading extension over the left/right-margin one. */
function prepareOsc133Collector(tool, lrMarginsBundle, output) {
    const adapted = adaptOsc133Collector(readFileSync(lrMarginsBundle));
    const osc133BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-shi-${osc133BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc133BundleSha256) throw new Error('Derived OSC 133 bundle digest mismatch.');
    writeFileSync(join(output, 'collector-shi.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc133BundleSha256 };
}

/** Re-derive the OSC 133 report parent-side from the paired journal and the layered pinned replay. */
async function retainOsc133Evidence(output, runId, osc133Bundle, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-shi.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'shi-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: osc133SuiteId, file: 'shi-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: osc133ContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'shi-run.json'));
    const frames = readFileSync(join(output, 'shi-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: osc133AdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(osc133Bundle).href);
    const report = buildOsc133GradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'shi-observations.json'), report);
    return { runId, suiteId: osc133SuiteId, file: 'shi-observations.json', sha256: hash(readFileSync(join(output, 'shi-observations.json'))),
        runFile: 'shi-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: osc133ContractsVersion, counts: osc133Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered OSC 633 grading extension over the OSC 133 one. */
function prepareOsc633Collector(tool, osc133Bundle, output) {
    const adapted = adaptOsc633Collector(readFileSync(osc133Bundle));
    const osc633BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-vs633-${osc633BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc633BundleSha256) throw new Error('Derived OSC 633 bundle digest mismatch.');
    writeFileSync(join(output, 'collector-vs633.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc633BundleSha256 };
}

/** Re-derive the OSC 633 report parent-side from the paired journal and the layered pinned replay. */
async function retainOsc633Evidence(output, runId, osc633Bundle, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-vs633.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'vs633-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: osc633SuiteId, file: 'vs633-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: osc633ContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'vs633-run.json'));
    const frames = readFileSync(join(output, 'vs633-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: osc633AdapterId, derivedFromAdapterId: osc133AdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(osc633Bundle).href);
    const report = buildOsc633GradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'vs633-observations.json'), report);
    return { runId, suiteId: osc633SuiteId, file: 'vs633-observations.json', sha256: hash(readFileSync(join(output, 'vs633-observations.json'))),
        runFile: 'vs633-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: osc633ContractsVersion, counts: osc633Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered OSC 7/8 grading extension over the left/right-margin one. */
function prepareOsc78Collector(tool, lrMarginsBundle, output) {
    const adapted = adaptOsc78Collector(readFileSync(lrMarginsBundle));
    const osc78BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-lnk-${osc78BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc78BundleSha256) throw new Error('Derived OSC 7/8 bundle digest mismatch.');
    writeFileSync(join(output, 'collector-lnk.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc78BundleSha256 };
}

/** Re-derive the OSC 7/8 report parent-side from the paired journal and the layered pinned replay. */
async function retainOsc78Evidence(output, runId, osc78Bundle, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-lnk.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'lnk-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: osc78SuiteId, file: 'lnk-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: osc78ContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'lnk-run.json'));
    const frames = readFileSync(join(output, 'lnk-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: osc78AdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(osc78Bundle).href);
    const report = buildOsc78GradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'lnk-observations.json'), report);
    return { runId, suiteId: osc78SuiteId, file: 'lnk-observations.json', sha256: hash(readFileSync(join(output, 'lnk-observations.json'))),
        runFile: 'lnk-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: osc78ContractsVersion, counts: osc78Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered title-stack grading extension over the left/right-margin one. */
function prepareInsertReplaceCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptInsertReplaceCollector(readFileSync(lrMarginsBundle));
    const insertReplaceBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-irm-${insertReplaceBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== insertReplaceBundleSha256) throw new Error('Derived IRM bundle digest mismatch.');
    writeFileSync(join(output, 'collector-irm.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, insertReplaceBundleSha256 };
}

async function retainInsertReplaceEvidence(output, runId, bundle, upstream) {
    const adapterBytes = readFileSync(join(output, 'collector-irm.mjs'));
    const runBytes = readFileSync(join(output, 'irm-run.json'));
    const frames = readFileSync(join(output, 'irm-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: insertReplaceAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(bundle).href);
    const run = JSON.parse(runBytes);
    const report = buildInsertReplaceReport(frames, run, runId, adapter, { replayModule });
    await verifyInsertReplaceTerminalReplay(replayModule, frames.at(-2).screen, run.terminalPinned);
    writeJson(join(output, 'irm-observations.json'), report);
    return { runId, suiteId: insertReplaceSuiteId, file: 'irm-observations.json', sha256: hash(readFileSync(join(output, 'irm-observations.json'))),
        runFile: 'irm-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256, contractsVersion: insertReplaceContractsVersion,
        counts: { [report.effect.outcome]: 1 }, provisionalUntil: 'cell-receipt.json' };
}

function prepareTitleStackCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptTitleStackCollector(readFileSync(lrMarginsBundle));
    const titleStackBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-tst-${titleStackBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== titleStackBundleSha256) throw new Error('Derived title-stack bundle digest mismatch.');
    writeFileSync(join(output, 'collector-tst.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, titleStackBundleSha256 };
}

/** Derive and lock the layered modifyOtherKeys grading extension over the left/right-margin one. */
function prepareModifyOtherKeysCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptModifyOtherKeysCollector(readFileSync(lrMarginsBundle));
    const modifyOtherKeysBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-mok-${modifyOtherKeysBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== modifyOtherKeysBundleSha256) throw new Error('Derived modifyOtherKeys bundle digest mismatch.');
    writeFileSync(join(output, 'collector-mok.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, modifyOtherKeysBundleSha256 };
}

/** Derive and lock the layered extended-mouse-encoding grading extension over the left/right-margin one (a sibling of the routed-input and modifyOtherKeys layers). */
function prepareMexCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptMexCollector(readFileSync(lrMarginsBundle));
    const mexBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-mex-${mexBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== mexBundleSha256) throw new Error('Derived extended-mouse bundle digest mismatch.');
    writeFileSync(join(output, 'collector-mex.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, mexBundleSha256 };
}

/** Derive and lock the layered SGR pixel-coordinate mouse grading extension over the left/right-margin one (a sibling of the routed-input and modifyOtherKeys layers). */
function preparePxmCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptPxmCollector(readFileSync(lrMarginsBundle));
    const pxmBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-pxm-${pxmBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== pxmBundleSha256) throw new Error('Derived SGR-pixel bundle digest mismatch.');
    writeFileSync(join(output, 'collector-pxm.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, pxmBundleSha256 };
}

/** Re-derive the title-stack report parent-side from the paired journal and the layered pinned replay. */
async function retainTitleStackEvidence(output, runId, titleStackBundle, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-tst.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'tst-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: titleStackSuiteId, file: 'tst-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: titleStackContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'tst-run.json'));
    const frames = readFileSync(join(output, 'tst-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: titleStackAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(titleStackBundle).href);
    const report = buildTitleStackGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'tst-observations.json'), report);
    return { runId, suiteId: titleStackSuiteId, file: 'tst-observations.json', sha256: hash(readFileSync(join(output, 'tst-observations.json'))),
        runFile: 'tst-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: titleStackContractsVersion, counts: titleStackCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered OSC 9 grading extension over the left/right-margin one (a sibling of the OSC 7/8 and title/icon-stack layers). */
function prepareOsc9Collector(tool, lrMarginsBundle, output) {
    const adapted = adaptOsc9Collector(readFileSync(lrMarginsBundle));
    const osc9BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-osn-${osc9BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc9BundleSha256) throw new Error('Derived OSC 9 bundle digest mismatch.');
    writeFileSync(join(output, 'collector-osn.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc9BundleSha256 };
}

/** Re-derive the OSC 9 report parent-side from the paired journal, the worker's run log and the parent's focus record. */
function retainOsc9Evidence(output, runId, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-osn.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'osn-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: osc9SuiteId, file: 'osn-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: osc9ContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'osn-run.json'));
    const frames = readFileSync(join(output, 'osn-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: osc9AdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const report = buildOsc9Report(frames, JSON.parse(runBytes), runId, adapter);
    writeJson(join(output, 'osn-observations.json'), report);
    return { runId, suiteId: osc9SuiteId, file: 'osn-observations.json', sha256: hash(readFileSync(join(output, 'osn-observations.json'))),
        runFile: 'osn-run.json', runSha256: hash(runBytes), focusFile: 'osn-focus.json', focusSha256: hash(readFileSync(join(output, 'osn-focus.json'))),
        adapterBundleSha256: adapter.bundleSha256, contractsVersion: osc9ContractsVersion, counts: osc9Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered OSC 777 / OSC 99 notification grading extension over the left/right-margin one (a sibling of the OSC 9 layer). */
function prepareNotifyCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptNotifyCollector(readFileSync(lrMarginsBundle));
    const notifyBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-ntf-${notifyBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== notifyBundleSha256) throw new Error('Derived notification bundle digest mismatch.');
    writeFileSync(join(output, 'collector-ntf.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, notifyBundleSha256 };
}

/** Re-derive the notification report parent-side from the paired journal, the worker's run log and the parent's focus record. */
function retainNotifyEvidence(output, runId, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-ntf.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'ntf-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: notifySuiteId, file: 'ntf-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: notifyContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'ntf-run.json'));
    const frames = readFileSync(join(output, 'ntf-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: notifyAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const report = buildNotifyReport(frames, JSON.parse(runBytes), runId, adapter);
    writeJson(join(output, 'ntf-observations.json'), report);
    return { runId, suiteId: notifySuiteId, file: 'ntf-observations.json', sha256: hash(readFileSync(join(output, 'ntf-observations.json'))),
        runFile: 'ntf-run.json', runSha256: hash(runBytes), focusFile: 'ntf-focus.json', focusSha256: hash(readFileSync(join(output, 'ntf-focus.json'))),
        adapterBundleSha256: adapter.bundleSha256, contractsVersion: notifyContractsVersion, counts: notifyCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered device-query grading extension over the left/right-margin one (a sibling of the OSC 9 and notification layers). */
function prepareDevqCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptDevqCollector(readFileSync(lrMarginsBundle));
    const devqBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-dvq-${devqBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== devqBundleSha256) throw new Error('Derived device-query bundle digest mismatch.');
    writeFileSync(join(output, 'collector-dvq.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, devqBundleSha256 };
}

/** Re-derive the device-query report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainDevqEvidence(output, runId, devqBundle, upstream) {
    const runBytes = readFileSync(join(output, 'dvq-run.json'));
    const frames = readFileSync(join(output, 'dvq-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-dvq.mjs'));
    const adapter = { id: devqAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(devqBundle).href);
    const report = buildDevqGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'dvq-observations.json'), report);
    return { runId, suiteId: devqSuiteId, file: 'dvq-observations.json', sha256: hash(readFileSync(join(output, 'dvq-observations.json'))),
        runFile: 'dvq-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: devqContractsVersion, counts: devqCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered xterm color-stack grading extension over the left/right-margin one (a sibling of the device-query, OSC 9 and notification layers). */
function prepareXcsCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptXcsCollector(readFileSync(lrMarginsBundle));
    const xcsBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-xcs-${xcsBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== xcsBundleSha256) throw new Error('Derived xterm color-stack bundle digest mismatch.');
    writeFileSync(join(output, 'collector-xcs.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, xcsBundleSha256 };
}

/** Re-derive the xterm color-stack report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainXcsEvidence(output, runId, xcsBundle, upstream) {
    const runBytes = readFileSync(join(output, 'xcs-run.json'));
    const frames = readFileSync(join(output, 'xcs-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-xcs.mjs'));
    const adapter = { id: xcsAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(xcsBundle).href);
    const report = buildXcsGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'xcs-observations.json'), report);
    return { runId, suiteId: xcsSuiteId, file: 'xcs-observations.json', sha256: hash(readFileSync(join(output, 'xcs-observations.json'))),
        runFile: 'xcs-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: xcsContractsVersion, counts: xcsCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered xterm SGR-stack grading extension over the left/right-margin one (a sibling of the device-query, color-stack and notification layers). */
function prepareXssCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptXssCollector(readFileSync(lrMarginsBundle));
    const xssBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-xss-${xssBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== xssBundleSha256) throw new Error('Derived xterm SGR-stack bundle digest mismatch.');
    writeFileSync(join(output, 'collector-xss.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, xssBundleSha256 };
}

/** Re-derive the xterm SGR-stack report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainXssEvidence(output, runId, xssBundle, upstream) {
    const runBytes = readFileSync(join(output, 'xss-run.json'));
    const frames = readFileSync(join(output, 'xss-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-xss.mjs'));
    const adapter = { id: xssAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(xssBundle).href);
    const report = buildXssGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'xss-observations.json'), report);
    return { runId, suiteId: xssSuiteId, file: 'xss-observations.json', sha256: hash(readFileSync(join(output, 'xss-observations.json'))),
        runFile: 'xss-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: xssContractsVersion, counts: xssCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered xterm saved-mode grading extension over the left/right-margin one (a sibling of the device-query, color-stack and notification layers). */
function prepareXsvCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptXsvCollector(readFileSync(lrMarginsBundle));
    const xsvBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-xsv-${xsvBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== xsvBundleSha256) throw new Error('Derived xterm saved-mode bundle digest mismatch.');
    writeFileSync(join(output, 'collector-xsv.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, xsvBundleSha256 };
}

/** Re-derive the xterm saved-mode report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainXsvEvidence(output, runId, xsvBundle, upstream) {
    const runBytes = readFileSync(join(output, 'xsv-run.json'));
    const frames = readFileSync(join(output, 'xsv-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-xsv.mjs'));
    const adapter = { id: xsvAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(xsvBundle).href);
    const report = buildXsvGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'xsv-observations.json'), report);
    return { runId, suiteId: xsvSuiteId, file: 'xsv-observations.json', sha256: hash(readFileSync(join(output, 'xsv-observations.json'))),
        runFile: 'xsv-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: xsvContractsVersion, counts: xsvCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered kitty color-control grading extension over the left/right-margin one (a sibling of the device-query, color-stack and notification layers). */
function prepareKclCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptKclCollector(readFileSync(lrMarginsBundle));
    const kclBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-kcl-${kclBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== kclBundleSha256) throw new Error('Derived kitty color-control bundle digest mismatch.');
    writeFileSync(join(output, 'collector-kcl.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, kclBundleSha256 };
}

/** Re-derive the kitty color-control report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainKclEvidence(output, runId, kclBundle, upstream) {
    const runBytes = readFileSync(join(output, 'kcl-run.json'));
    const frames = readFileSync(join(output, 'kcl-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-kcl.mjs'));
    const adapter = { id: kclAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(kclBundle).href);
    const report = buildKclGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'kcl-observations.json'), report);
    return { runId, suiteId: kclSuiteId, file: 'kcl-observations.json', sha256: hash(readFileSync(join(output, 'kcl-observations.json'))),
        runFile: 'kcl-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: kclContractsVersion, counts: kclCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered rxvt special-color grading extension over the left/right-margin one (a sibling of the kitty-color and device-query layers). */
function prepareOsc5Collector(tool, lrMarginsBundle, output) {
    const adapted = adaptOsc5Collector(readFileSync(lrMarginsBundle));
    const osc5BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-osc5-${osc5BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc5BundleSha256) throw new Error('Derived rxvt special-color bundle digest mismatch.');
    writeFileSync(join(output, 'collector-osc5.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc5BundleSha256 };
}

/** Re-derive the special-color report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainOsc5Evidence(output, runId, osc5Bundle, upstream) {
    const runBytes = readFileSync(join(output, 'osc5-run.json'));
    const frames = readFileSync(join(output, 'osc5-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-osc5.mjs'));
    const adapter = { id: osc5AdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(osc5Bundle).href);
    const report = buildOsc5GradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'osc5-observations.json'), report);
    return { runId, suiteId: osc5SuiteId, file: 'osc5-observations.json', sha256: hash(readFileSync(join(output, 'osc5-observations.json'))),
        runFile: 'osc5-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: osc5ContractsVersion, counts: osc5Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered OSC 3008 grading extension over the left/right-margin one (a sibling of the special-color, notification and OSC 133 layers). */
function prepareOsc3008Collector(tool, lrMarginsBundle, output) {
    const adapted = adaptOsc3008Collector(readFileSync(lrMarginsBundle));
    const osc3008BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-osc3008-${osc3008BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc3008BundleSha256) throw new Error('Derived OSC 3008 bundle digest mismatch.');
    writeFileSync(join(output, 'collector-ocx.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc3008BundleSha256 };
}

/** Re-derive the OSC 3008 report parent-side from the paired journal and the worker's run log, then run the PINNED terminal-path code from the retained derived bundle over the journaled cursor. */
async function retainOsc3008Evidence(output, runId, osc3008Bundle, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-ocx.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'ocx-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: osc3008SuiteId, file: 'ocx-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: osc3008ContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'ocx-run.json')), run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'ocx-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: osc3008AdapterId, derivedFromAdapterId: osc3008DerivedFromAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    await verifyOsc3008PinnedCode(run, await import(pathToFileURL(osc3008Bundle).href));
    const report = buildOsc3008GradingReport(frames, run, runId, adapter);
    writeJson(join(output, 'ocx-observations.json'), report);
    return { runId, suiteId: osc3008SuiteId, file: 'ocx-observations.json', sha256: hash(readFileSync(join(output, 'ocx-observations.json'))),
        runFile: 'ocx-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: osc3008ContractsVersion, counts: osc3008Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered rxvt OSC 720 grading extension over the left/right-margin one (a sibling of the OSC 5 and OSC 9 layers). */
function prepareOsc720Collector(tool, lrMarginsBundle, output) {
    const adapted = adaptOsc720Collector(readFileSync(lrMarginsBundle));
    const osc720BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-ovu-${osc720BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc720BundleSha256) throw new Error('Derived OSC 720 bundle digest mismatch.');
    writeFileSync(join(output, 'collector-ovu.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc720BundleSha256 };
}

/** Re-derive the OSC 720 report parent-side from the paired journal, the worker's run log and the parent's retained wheel actions. */
function retainOsc720Evidence(output, runId, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-ovu.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'ovu-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: osc720SuiteId, file: 'ovu-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: osc720ContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'ovu-run.json'));
    const frames = readFileSync(join(output, 'ovu-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: osc720AdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const report = buildOsc720Report(frames, JSON.parse(runBytes), runId, adapter);
    writeJson(join(output, 'ovu-observations.json'), report);
    return { runId, suiteId: osc720SuiteId, file: 'ovu-observations.json', sha256: hash(readFileSync(join(output, 'ovu-observations.json'))),
        runFile: 'ovu-run.json', runSha256: hash(runBytes), actionsFile: 'ovu-actions.json', actionsSha256: hash(readFileSync(join(output, 'ovu-actions.json'))),
        adapterBundleSha256: adapter.bundleSha256, contractsVersion: osc720ContractsVersion, counts: osc720Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered OSC 22 grading extension over the left/right-margin one (a sibling of the special-color, notification and OSC 133 layers). */
function prepareOsc22Collector(tool, lrMarginsBundle, output) {
    const adapted = adaptOsc22Collector(readFileSync(lrMarginsBundle));
    const osc22BundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-osc22-${osc22BundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== osc22BundleSha256) throw new Error('Derived OSC 22 bundle digest mismatch.');
    writeFileSync(join(output, 'collector-ptr.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, osc22BundleSha256 };
}

/** Re-derive the OSC 22 report parent-side from the paired journal and the worker's run log, then run the PINNED terminal-path code from the retained derived bundle over the journaled cursor. */
async function retainOsc22Evidence(output, runId, osc22Bundle, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-ptr.mjs'));
    if (unavailable) {
        const markerBytes = readFileSync(join(output, 'ptr-unavailable.json')), marker = JSON.parse(markerBytes);
        return { runId, suiteId: osc22SuiteId, file: 'ptr-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: osc22ContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'ptr-run.json')), run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'ptr-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: osc22AdapterId, derivedFromAdapterId: osc22DerivedFromAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    await verifyOsc22PinnedCode(run, await import(pathToFileURL(osc22Bundle).href));
    const report = buildOsc22GradingReport(frames, run, runId, adapter);
    writeJson(join(output, 'ptr-observations.json'), report);
    return { runId, suiteId: osc22SuiteId, file: 'ptr-observations.json', sha256: hash(readFileSync(join(output, 'ptr-observations.json'))),
        runFile: 'ptr-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: osc22ContractsVersion, counts: osc22Counts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered iTerm2 feature-reporting grading extension over the left/right-margin one (a sibling of the special-color, OSC 720, OSC 22, cell-size and OSC 3008 layers). */
function prepareCapsCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptCapsCollector(readFileSync(lrMarginsBundle));
    const capsBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-caps-${capsBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== capsBundleSha256) throw new Error('Derived feature-reporting bundle digest mismatch.');
    writeFileSync(join(output, 'collector-caps.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, capsBundleSha256 };
}

/** Re-derive the feature-reporting report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainCapsEvidence(output, runId, capsBundle, upstream) {
    const runBytes = readFileSync(join(output, 'caps-run.json'));
    const frames = readFileSync(join(output, 'caps-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-caps.mjs'));
    const adapter = { id: capsAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(capsBundle).href);
    const report = buildCapsGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'caps-observations.json'), report);
    return { runId, suiteId: capsSuiteId, file: 'caps-observations.json', sha256: hash(readFileSync(join(output, 'caps-observations.json'))),
        runFile: 'caps-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: capsContractsVersion, counts: capsCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered xterm DECCOLM grading extension over the left/right-margin one (a sibling of the pointer-color, feature-reporting, special-color, OSC 720, OSC 22, cell-size and OSC 3008 layers). */
function prepareDclCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptDclCollector(readFileSync(lrMarginsBundle));
    const dclBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-dcl-${dclBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== dclBundleSha256) throw new Error('Derived DECCOLM bundle digest mismatch.');
    writeFileSync(join(output, 'collector-dcl.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, dclBundleSha256 };
}

/** Re-derive the DECCOLM report parent-side from the paired journal (every frame carrying its independently read kernel PTY grid) and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainDclEvidence(output, runId, dclBundle, upstream) {
    const runBytes = readFileSync(join(output, 'dcl-run.json'));
    const frames = readFileSync(join(output, 'dcl-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-dcl.mjs'));
    const adapter = { id: dclAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(dclBundle).href);
    const report = buildDclGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'dcl-observations.json'), report);
    return { runId, suiteId: dclSuiteId, file: 'dcl-observations.json', sha256: hash(readFileSync(join(output, 'dcl-observations.json'))),
        runFile: 'dcl-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: dclContractsVersion, counts: dclCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered xterm DECSCLM grading extension over the left/right-margin one (a sibling of the DECCOLM, pointer-color, feature-reporting, special-color, OSC 720, OSC 22, cell-size and OSC 3008 layers). */
function prepareDslCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptDslCollector(readFileSync(lrMarginsBundle));
    const dslBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-dsl-${dslBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== dslBundleSha256) throw new Error('Derived DECSCLM bundle digest mismatch.');
    writeFileSync(join(output, 'collector-dsl.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, dslBundleSha256 };
}

/** Re-derive the DECSCLM report parent-side from the paired journal (every frame carrying the parent's own monotonic timing) and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainDslEvidence(output, runId, dslBundle, upstream) {
    const runBytes = readFileSync(join(output, 'dsl-run.json'));
    const frames = readFileSync(join(output, 'dsl-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-dsl.mjs'));
    const adapter = { id: dslAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(dslBundle).href);
    const report = buildDslGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'dsl-observations.json'), report);
    return { runId, suiteId: dslSuiteId, file: 'dsl-observations.json', sha256: hash(readFileSync(join(output, 'dsl-observations.json'))),
        runFile: 'dsl-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: dslContractsVersion, counts: dslCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered xterm pointer-color grading extension over the left/right-margin one (a sibling of the feature-reporting, special-color, OSC 720, OSC 22, cell-size and OSC 3008 layers). */
function preparePclCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptPclCollector(readFileSync(lrMarginsBundle));
    const pclBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-pcl-${pclBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== pclBundleSha256) throw new Error('Derived pointer-color bundle digest mismatch.');
    writeFileSync(join(output, 'collector-pcl.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, pclBundleSha256 };
}

/** Re-derive the pointer-color report parent-side from the paired journal and the worker's run log, replaying both pinned paths from the retained derived bundle. */
async function retainPclEvidence(output, runId, pclBundle, upstream) {
    const runBytes = readFileSync(join(output, 'pcl-run.json'));
    const frames = readFileSync(join(output, 'pcl-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-pcl.mjs'));
    const adapter = { id: pclAdapterId, derivedFromAdapterId: lrMarginsAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(pclBundle).href);
    const report = buildPclGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'pcl-observations.json'), report);
    return { runId, suiteId: pclSuiteId, file: 'pcl-observations.json', sha256: hash(readFileSync(join(output, 'pcl-observations.json'))),
        runFile: 'pcl-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: pclContractsVersion, counts: pclCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered XTGETTCAP grading extension over the title/icon-stack one. */
function prepareXtgettcapCollector(tool, titleStackBundle, output) {
    const adapted = adaptXtgettcapCollector(readFileSync(titleStackBundle));
    const xtgettcapBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-xgtc-${xtgettcapBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== xtgettcapBundleSha256) throw new Error('Derived XTGETTCAP bundle digest mismatch.');
    writeFileSync(join(output, 'collector-xgtc.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, xtgettcapBundleSha256 };
}

/** Re-derive the XTGETTCAP report parent-side from the journaled replies and the layered pinned replay. */
async function retainXtgettcapEvidence(output, runId, xtgettcapBundle, upstream) {
    const runBytes = readFileSync(join(output, 'xgtc-run.json'));
    const frames = readFileSync(join(output, 'xgtc-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-xgtc.mjs'));
    const adapter = { id: xtgettcapAdapterId, derivedFromAdapterId: titleStackAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(xtgettcapBundle).href);
    const report = buildXtgettcapGradingReport(frames, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'xgtc-observations.json'), report);
    return { runId, suiteId: xtgettcapSuiteId, file: 'xgtc-observations.json', sha256: hash(readFileSync(join(output, 'xgtc-observations.json'))),
        runFile: 'xgtc-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: xtgettcapContractsVersion, counts: xtgettcapCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered selection-color grading extension over the OSC title one. */
function prepareSelectionColorsCollector(tool, oscTitleBundle, output) {
    const adapted = adaptSelectionColorsCollector(readFileSync(oscTitleBundle));
    const sha = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-selc-${sha}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== sha) throw new Error('Derived selection-color bundle digest mismatch.');
    writeFileSync(join(output, 'collector-selc.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, selectionColorsBundleSha256: sha };
}
function prepareOscTitleCollector(tool, previous, output) {
    const adapted = adaptOscTitleCollector(readFileSync(previous));
    const oscTitleBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-ost-${oscTitleBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== oscTitleBundleSha256) throw new Error('Derived OSC title bundle digest mismatch.');
    writeFileSync(join(output, 'collector-ost.mjs'), adapted, { flag: 'wx', mode: 0o600 });
    return { bundle, oscTitleBundleSha256 };
}
function retainOscTitleEvidence(output, runId, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-ost.mjs'));
    if (unavailable) {
        const bytes = readFileSync(join(output, 'ost-unavailable.json')), marker = JSON.parse(bytes);
        return { runId, suiteId: oscTitleSuiteId, file: 'ost-unavailable.json', sha256: hash(bytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: oscTitleContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'ost-run.json'));
    const frames = readFileSync(join(output, 'ost-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapter = { id: oscTitleAdapterId, derivedFromAdapterId: titleStackAdapterId, bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const report = buildOscTitleReport(frames, JSON.parse(runBytes), runId, adapter);
    writeJson(join(output, 'ost-observations.json'), report);
    return { runId, suiteId: oscTitleSuiteId, file: 'ost-observations.json', sha256: hash(readFileSync(join(output, 'ost-observations.json'))),
        runFile: 'ost-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: oscTitleContractsVersion, counts: oscTitleCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** /** Derive and lock the ASCII reflow grading extension over the XTGETTCAP one. */
function prepareReflowCollector(tool, previous, output) {
    const adapted = adaptReflowCollector(readFileSync(previous));
    const asciiReflowBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-rfl-${asciiReflowBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== asciiReflowBundleSha256) throw new Error('Derived ASCII reflow bundle digest mismatch.');
    writeFileSync(join(output, 'collector-rfl.mjs'), adapted, { flag: 'wx', mode: 0o600 });
    return { bundle, asciiReflowBundleSha256 };
}

/** Re-derive the ASCII reflow report parent-side from the paired journals and the layered pinned replay. */
async function retainReflowEvidence(output, runId, reflowBundle, upstream, unavailable) {
    const adapterBytes = readFileSync(join(output, 'collector-rfl.mjs'));
    if (unavailable) {
        const bytes = readFileSync(join(output, 'reflow-unavailable.json')), marker = JSON.parse(bytes);
        if (marker.reason !== unavailable.reason) throw new Error('ASCII reflow unavailable marker differs from its recorded refusal.');
        return { runId, suiteId: asciiReflowSuiteId, file: 'reflow-unavailable.json', sha256: hash(bytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(adapterBytes), contractsVersion: asciiReflowContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    const runBytes = readFileSync(join(output, 'rf-run.json'));
    const frames = readFileSync(join(output, 'reflow-snapshots.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const actions = readFileSync(join(output, 'reflow-actions.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapter = { id: asciiReflowAdapterId, derivedFromAdapterId: 'ntilde-owned-osc-title-grading-v1', bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(reflowBundle).href);
    const report = buildReflowReport(frames, actions, JSON.parse(runBytes), runId, adapter, { replayModule });
    writeJson(join(output, 'reflow-observations.json'), report);
    return { runId, suiteId: asciiReflowSuiteId, file: 'reflow-observations.json', sha256: hash(readFileSync(join(output, 'reflow-observations.json'))),
        runFile: 'rf-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: asciiReflowContractsVersion, counts: reflowCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the routed-input report parent-side from the owned input journal and the layered pinned replay. */
async function retainRoutedInputEvidence(output, runId, routedInputBundle, upstream, inputBinding, seal, inputSuiteId) {
    if (inputBinding?.status === 'unavailable') {
        // The owned input suite could not run on this grid; the layer records the same typed unavailability and nothing else.
        const markerBytes = readFileSync(join(output, 'rin-unavailable.json')), marker = JSON.parse(markerBytes);
        if (marker.reason !== inputBinding.reason) throw new Error('Routed-input unavailable marker differs from the input suite.');
        return { runId, suiteId: routedInputGradedSuiteId, file: 'rin-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(readFileSync(join(output, 'collector-rin.mjs'))), contractsVersion: routedInputContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    if (inputBinding?.file !== 'input-observations.json') throw new Error('Routed-input evidence requires the owned input suite.');
    const runBytes = readFileSync(join(output, 'rin-run.json'));
    const run = JSON.parse(runBytes);
    const lines = file => readFileSync(join(output, file), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-rin.mjs'));
    const adapter = { id: routedInputAdapterId, derivedFromAdapterId: lrMarginsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(routedInputBundle).href);
    const report = buildRoutedInputGradingReport({ frames: lines('input-snapshots.jsonl'), actions: lines('input-actions.jsonl'), seal }, run, runId, adapter,
        { replayModule, inputPlan: ownedInputPlanForSuiteId(inputSuiteId), inputReportSha256: inputBinding.sha256 });
    writeJson(join(output, 'rin-observations.json'), report);
    return { runId, suiteId: routedInputGradedSuiteId, file: 'rin-observations.json',
        sha256: hash(readFileSync(join(output, 'rin-observations.json'))),
        runFile: 'rin-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: routedInputContractsVersion, counts: routedInputCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the modifyOtherKeys report parent-side from the owned input journal and the layered pinned replay. */
async function retainModifyOtherKeysEvidence(output, runId, modifyOtherKeysBundle, upstream, inputBinding, seal, inputSuiteId) {
    if (inputBinding?.status === 'unavailable') {
        const markerBytes = readFileSync(join(output, 'mok-unavailable.json')), marker = JSON.parse(markerBytes);
        if (marker.reason !== inputBinding.reason) throw new Error('modifyOtherKeys unavailable marker differs from the input suite.');
        return { runId, suiteId: modifyOtherKeysGradedSuiteId, file: 'mok-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(readFileSync(join(output, 'collector-mok.mjs'))), contractsVersion: modifyOtherKeysContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    if (inputBinding?.file !== 'input-observations.json') throw new Error('modifyOtherKeys evidence requires the owned input suite.');
    const runBytes = readFileSync(join(output, 'mok-run.json'));
    const run = JSON.parse(runBytes);
    const lines = file => readFileSync(join(output, file), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-mok.mjs'));
    const adapter = { id: modifyOtherKeysAdapterId, derivedFromAdapterId: lrMarginsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(modifyOtherKeysBundle).href);
    const report = buildModifyOtherKeysGradingReport({ frames: lines('input-snapshots.jsonl'), actions: lines('input-actions.jsonl'), seal }, run, runId, adapter,
        { replayModule, inputPlan: ownedInputPlanForSuiteId(inputSuiteId), inputReportSha256: inputBinding.sha256 });
    writeJson(join(output, 'mok-observations.json'), report);
    return { runId, suiteId: modifyOtherKeysGradedSuiteId, file: 'mok-observations.json',
        sha256: hash(readFileSync(join(output, 'mok-observations.json'))),
        runFile: 'mok-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: modifyOtherKeysContractsVersion, counts: modifyOtherKeysCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the extended-mouse report parent-side from the owned input journal and the layered pinned replay. */
async function retainMexEvidence(output, runId, mexBundle, upstream, inputBinding, seal, inputSuiteId) {
    if (inputBinding?.status === 'unavailable') {
        const markerBytes = readFileSync(join(output, 'mex-unavailable.json')), marker = JSON.parse(markerBytes);
        if (marker.reason !== inputBinding.reason) throw new Error('Extended-mouse unavailable marker differs from the input suite.');
        return { runId, suiteId: mexGradedSuiteId, file: 'mex-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(readFileSync(join(output, 'collector-mex.mjs'))), contractsVersion: mexContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    if (inputBinding?.file !== 'input-observations.json') throw new Error('Extended-mouse evidence requires the owned input suite.');
    const runBytes = readFileSync(join(output, 'mex-run.json'));
    const run = JSON.parse(runBytes);
    const lines = file => readFileSync(join(output, file), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-mex.mjs'));
    const adapter = { id: mexAdapterId, derivedFromAdapterId: lrMarginsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(mexBundle).href);
    const report = buildMexGradingReport({ frames: lines('input-snapshots.jsonl'), actions: lines('input-actions.jsonl'), seal }, run, runId, adapter,
        { replayModule, inputPlan: ownedInputPlanForSuiteId(inputSuiteId), inputReportSha256: inputBinding.sha256 });
    writeJson(join(output, 'mex-observations.json'), report);
    return { runId, suiteId: mexGradedSuiteId, file: 'mex-observations.json',
        sha256: hash(readFileSync(join(output, 'mex-observations.json'))),
        runFile: 'mex-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: mexContractsVersion, counts: mexCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-pixel report parent-side from the owned input journal and the layered pinned replay. */
async function retainPxmEvidence(output, runId, pxmBundle, upstream, inputBinding, seal, inputSuiteId) {
    if (inputBinding?.status === 'unavailable') {
        const markerBytes = readFileSync(join(output, 'pxm-unavailable.json')), marker = JSON.parse(markerBytes);
        if (marker.reason !== inputBinding.reason) throw new Error('SGR-pixel unavailable marker differs from the input suite.');
        return { runId, suiteId: pxmGradedSuiteId, file: 'pxm-unavailable.json', sha256: hash(markerBytes), status: 'unavailable', reason: marker.reason, counts: {},
            adapterBundleSha256: hash(readFileSync(join(output, 'collector-pxm.mjs'))), contractsVersion: pxmContractsVersion, provisionalUntil: 'cell-receipt.json' };
    }
    if (inputBinding?.file !== 'input-observations.json') throw new Error('SGR-pixel evidence requires the owned input suite.');
    const runBytes = readFileSync(join(output, 'pxm-run.json'));
    const run = JSON.parse(runBytes);
    const lines = file => readFileSync(join(output, file), 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-pxm.mjs'));
    const adapter = { id: pxmAdapterId, derivedFromAdapterId: lrMarginsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(pxmBundle).href);
    const report = buildPxmGradingReport({ frames: lines('input-snapshots.jsonl'), actions: lines('input-actions.jsonl'), seal }, run, runId, adapter,
        { replayModule, inputPlan: ownedInputPlanForSuiteId(inputSuiteId), inputReportSha256: inputBinding.sha256 });
    writeJson(join(output, 'pxm-observations.json'), report);
    return { runId, suiteId: pxmGradedSuiteId, file: 'pxm-observations.json',
        sha256: hash(readFileSync(join(output, 'pxm-observations.json'))),
        runFile: 'pxm-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: pxmContractsVersion, counts: pxmCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-underline-color report parent-side with the layered pinned replay. */
async function retainSgrUnderlineColorEvidence(output, runId, sgrUnderlineColorBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sguc-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sguc-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sguc.mjs'));
    const adapter = { id: sgrUnderlineColorAdapterId, derivedFromAdapterId: sgrUnderlineAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrUnderlineColorBundle).href);
    const report = buildSgrUnderlineColorGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sguc-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrUnderlineColorSuiteId, file: 'sguc-observations.json',
        sha256: hash(readFileSync(join(output, 'sguc-observations.json'))),
        runFile: 'sguc-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrUnderlineColorContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Derive and lock the layered runtime-color reset grading extension over the left/right-margin one. */
function prepareColorResetCollector(tool, lrMarginsBundle, output) {
    const adapted = adaptColorResetCollector(readFileSync(lrMarginsBundle));
    const colorResetBundleSha256 = hash(adapted);
    const bundle = join(tool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-crst-${colorResetBundleSha256}.mjs`);
    writeFileSync(bundle, adapted, { flag: 'wx', mode: 0o600 });
    if (hash(readFileSync(bundle)) !== colorResetBundleSha256) throw new Error('Derived runtime-color reset bundle digest mismatch.');
    writeFileSync(join(output, 'collector-crst.mjs'), readFileSync(bundle), { flag: 'wx', mode: 0o600 });
    return { bundle, colorResetBundleSha256 };
}

/** Re-derive the runtime-color reset report parent-side with the layered pinned replay over the retained captures. */
async function retainColorResetEvidence(output, runId, colorResetBundle, upstream) {
    const runBytes = readFileSync(join(output, 'crst-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'crst-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-crst.mjs'));
    const adapter = { id: colorResetAdapterId, derivedFromAdapterId: lrMarginsAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(colorResetBundle).href);
    const report = buildColorResetGradingReport(frames, run, runId, adapter, { replayModule, output });
    writeJson(join(output, 'crst-observations.json'), report);
    return { runId, suiteId: colorResetSuiteId, file: 'crst-observations.json',
        sha256: hash(readFileSync(join(output, 'crst-observations.json'))),
        runFile: 'crst-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: colorResetContractsVersion, counts: colorResetCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the selection-color report parent-side over the retained captures (no pinned replay: the layer's own model and the App-resolved colors decide). */
function retainSelectionColorsEvidence(output, runId, upstream) {
    const runBytes = readFileSync(join(output, 'selc-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'selc-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-selc.mjs'));
    const adapter = { id: selectionColorsAdapterId, derivedFromAdapterId: oscTitleAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const report = buildSelectionColorsGradingReport(frames, run, runId, adapter, { output });
    writeJson(join(output, 'selc-observations.json'), report);
    return { runId, suiteId: selectionColorsSuiteId, file: 'selc-observations.json',
        sha256: hash(readFileSync(join(output, 'selc-observations.json'))),
        runFile: 'selc-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: selectionColorsContractsVersion, counts: selectionColorsCounts(report), provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the SGR-underline report parent-side with the layered pinned replay. */
async function retainSgrUnderlineEvidence(output, runId, sgrUnderlineBundle, upstream) {
    const runBytes = readFileSync(join(output, 'sgus-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgus-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-sgus.mjs'));
    const adapter = { id: sgrUnderlineAdapterId, derivedFromAdapterId: sgrTruecolorAdapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(sgrUnderlineBundle).href);
    const report = buildSgrUnderlineGradingReport(frames, run, runId, adapter, { replayModule });
    writeJson(join(output, 'sgus-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: sgrUnderlineSuiteId, file: 'sgus-observations.json',
        sha256: hash(readFileSync(join(output, 'sgus-observations.json'))),
        runFile: 'sgus-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: sgrUnderlineContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the App-observed underline-color resolution report parent-side (no pinned probe to replay). */
function retainUnderlineResolvedEvidence(output, runId) {
    const runBytes = readFileSync(join(output, 'sgur-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgur-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const report = buildUnderlineResolvedReport(frames, run, runId);
    writeJson(join(output, 'sgur-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: underlineResolvedSuiteId, file: 'sgur-observations.json',
        sha256: hash(readFileSync(join(output, 'sgur-observations.json'))),
        runFile: 'sgur-run.json', runSha256: hash(runBytes), contractsVersion: underlineResolvedContractsVersion, counts,
        provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the truecolor-literal finding report parent-side (no pinned probe to replay). */
function retainTruecolorFindingEvidence(output, runId) {
    const runBytes = readFileSync(join(output, 'sgtf-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'sgtf-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const report = buildTruecolorFindingReport(frames, run, runId);
    writeJson(join(output, 'sgtf-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: truecolorFindingSuiteId, file: 'sgtf-observations.json',
        sha256: hash(readFileSync(join(output, 'sgtf-observations.json'))),
        runFile: 'sgtf-run.json', runSha256: hash(runBytes), contractsVersion: truecolorFindingContractsVersion, counts,
        provisionalUntil: 'cell-receipt.json' };
}

/** Re-derive the graded report parent-side, replaying the pinned probes over
 * the retained journal before publishing the binding. */
async function retainGradingEvidence(output, runId, gradingBundle, upstream) {
    const runBytes = readFileSync(join(output, 'grading-run.json'));
    const run = JSON.parse(runBytes);
    const frames = readFileSync(join(output, 'grading-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
    const adapterBytes = readFileSync(join(output, 'collector-grading.mjs'));
    const adapter = { id: gradingAdapterId, derivedFromAdapterId: adapterId,
        bundleSha256: hash(adapterBytes), upstreamBundleSha256: upstream };
    const replayModule = await import(pathToFileURL(gradingBundle).href);
    const report = buildAsciiSgrGradingReport(frames, run, runId, adapter, replayModule);
    writeJson(join(output, 'grading-observations.json'), report);
    const counts = {};
    for (const item of report.cases) counts[item.conclusion.outcome] = (counts[item.conclusion.outcome] ?? 0) + 1;
    return { runId, suiteId: asciiSgrSuiteId, file: 'grading-observations.json',
        sha256: hash(readFileSync(join(output, 'grading-observations.json'))),
        runFile: 'grading-run.json', runSha256: hash(runBytes), adapterBundleSha256: adapter.bundleSha256,
        contractsVersion: asciiSgrContractsVersion, counts, provisionalUntil: 'cell-receipt.json' };
}

/** The one place an owned App is started: the launch intent is persisted in the lease first, so a failed write stops the launch. */
function launchOwnedApp(lease, executable, runId, env, logFd) {
    lease.noteLaunchAttempt();
    return spawn(executable, [`--ntilde-terminfo-owner=${runId}`, `--ntilde-terminfo-private-clipboard=${runId}`], { env, cwd: dirname(executable), stdio: ['ignore', logFd, logFd] });
}

/** Terminate the App: SIGTERM first, SIGKILL if it is still running two seconds later. Resolves with whether the kill was escalated. */
async function terminateLaunchedApp(app) {
    const outcome = { escalated: false };
    if (!app?.pid || app.exitCode !== null || app.signalCode !== null) return outcome;
    app.kill('SIGTERM');
    await new Promise((resolve, reject) => {
        let killTimer, giveUpTimer;
        app.once('exit', () => { clearTimeout(killTimer); clearTimeout(giveUpTimer); resolve(); });
        killTimer = setTimeout(() => {
            outcome.escalated = true;
            app.kill('SIGKILL');
            // An App that outlives SIGKILL must fail cleanup (and so retain the desktop lease), not hang the run.
            giveUpTimer = setTimeout(() => { app.unref(); reject(new Error(`Owned app ${app.pid} did not exit after SIGKILL.`)); }, 2000);
        }, 2000);
    });
    return outcome;
}

async function cleanupOwnedRun({ lease, workerIdentity, daemonIdentity, daemonProof, executable, appData, runId, app, logFd, server, output, proofs, completed, scratch, collectionScope }) {
    let workerError;
    try { await terminateRecordedWorker(workerIdentity, runId); }
    catch (error) { workerError = error; }
    // App shutdown still runs if worker verification or termination failed.
    let appError;
    try { await terminateLaunchedApp(app); }
    catch (error) { appError = error; }
    // A persistent tab's multiplexer daemon outlives both by design: stop it through its private root, only while it is verifiably this run's.
    let daemonError;
    try { if (collectionScope?.persistence === 'KeepOnClose') await terminateRecordedDaemon(daemonIdentity, { executable, appData, runId }); }
    catch (error) { daemonError = error; }
    if (logFd !== undefined) closeSync(logFd);
    await new Promise(resolve => server.close(() => resolve()));
    // Parent shutdown can reap an already-exited worker that was a zombie.
    if (workerError && workerIdentity && !workerExists(workerIdentity.pid)) workerError = undefined;
    // Cleanup is verified only when both terminations succeeded AND no process carrying this lease's run markers survives; a
    // failed scan is a failure. A failed termination never reaches the scan, so a changed command line cannot hide a live process.
    let survivorError;
    if (!workerError && !appError && !daemonError) {
        try { await lease.verifyCleanup(); }
        catch (error) { survivorError = error; }
    }
    const cleanupError = workerError ?? appError ?? daemonError ?? survivorError;
    const cleanup = cleanupError
        ? { cleanupError: cleanupError.message, retainedFixture: scratch }
        : { cleanedUpAt: new Date().toISOString() };
    writeJson(join(output, 'ownership-proof.json'), { proofs, completed, ...(collectionScope ? { collectionScope } : {}), ...(daemonProof ? { persistentDaemon: daemonProof } : {}), ...cleanup });
    if (cleanupError) throw cleanupError;
}

function retainPreparationFailure(output, error) {
    if (output && !existsSync(join(output, 'failure.json'))) {
        writeJson(join(output, 'failure.json'), { error: error.message, at: new Date().toISOString() });
    }
}

/** Collect only through a proved disposable app/PTY, then finalize after complete cleanup. */
async function main() {
    const snapshot = readSourceSnapshot(sourceRepo);
    const args = process.argv.slice(2);
    if (args.length === 1 && ['--help', '-h'].includes(args[0])) {
        console.log(`Usage: node scripts/terminfo-owned.mjs --executable /absolute/path/Ntilde --app-version VERSION [--scope osc633|static-images|persistent-animation|persistent-restore|persistent-compose|direct-compose|persistent-placeholders|direct-placeholders|persistent-placeholder-grid|direct-placeholder-grid|modern-blink|modern-viewport|modern-osc-titles|modern-osc7-cwd|modern-child-environment|rich-vendor-environment|unicode-width|unicode-boundaries|kitty-graphics|font-ligatures|modify-other-keys-3|modify-other-keys-3-baseline|osc66|sixel-reports|osc633-metadata]

Requires macOS, Node 24+ and an uninstalled sidecar outside .app bundles.
Packaged apps are refused because a staged update can restart outside the fixture.
Enables Act access only in fresh private settings for parent-selected resize and declared routed-input actions.
Requires an npm installation (or NTILDE_TERMINFO_NPM_CLI) to recreate locked dependencies.
Prepare terminfo.dev@4.0.0 under
artifacts/terminfo/tool (see docs/qa/QA_TERMINFO.md). Launches a disposable
Ntilde process with private settings and runs a locally extended collector.
Includes synthetic App-private clipboard transactions with native providers disabled; no OS clipboard qualification.
Results go to artifacts/terminfo/owned-*. No existing sessions are used.
The collector extension and its digest are recorded; this is not stock CLI data.`);
        return;
    }
    const executable = validateInvocation(args);
    if (args[5] === 'persistent-animation') return persistentAnimationMain(args, executable, snapshot, persistentAnimationScope);
    if (args[5] === 'persistent-restore') return persistentAnimationMain(args, executable, snapshot, persistentRestoreScope);
    if (args[5] === 'persistent-compose') return persistentAnimationMain(args, executable, snapshot, persistentComposeScope);
    if (args[5] === 'direct-compose') return persistentAnimationMain(args, executable, snapshot, directComposeScope);
    if (args[5] === 'persistent-placeholders') return persistentAnimationMain(args, executable, snapshot, persistentPlaceholdersScope);
    if (args[5] === 'direct-placeholders') return persistentAnimationMain(args, executable, snapshot, directPlaceholdersScope);
    if (args[5] === 'persistent-placeholder-grid') return persistentAnimationMain(args, executable, snapshot, persistentPlaceholderGridScope);
    if (args[5] === 'direct-placeholder-grid') return persistentAnimationMain(args, executable, snapshot, directPlaceholderGridScope);
    if (['modern-blink', 'modern-viewport', 'modern-osc-titles', 'modern-osc7-cwd', 'modern-child-environment', 'rich-vendor-environment', 'unicode-width', 'unicode-boundaries', 'kitty-graphics', 'font-ligatures', 'modify-other-keys-3', 'modify-other-keys-3-baseline', 'osc66', 'sixel-reports', 'osc633-metadata'].includes(args[5])) {
        if (!focusedSuite) throw new Error('Expected the captured focused scope.');
        return persistentAnimationMain(args, executable, snapshot, focusedSuite.scope);
    }
    const collectionScope = args.length === 6 ? osc633Scope : legacyScope;
    const input = readPreparedCollector(join(repo, 'artifacts', 'terminfo', 'tool'));

    let resolveDone;
    let rejectDone;
    const done = new Promise((resolve, reject) => { resolveDone = resolve; rejectDone = reject; });
    done.catch(() => {});
    let interruption;
    const interrupted = signal => {
        interruption ??= new Error(`Interrupted by ${signal}.`);
        process.exitCode = 1;
        rejectDone(interruption);
    };
    const onInt = () => interrupted('SIGINT');
    const onTerm = () => interrupted('SIGTERM');
    const onHup = () => interrupted('SIGHUP');
    let scratch;
    let output;
    let lease;
    let preserveScratch = false;
    let cellEvidence;
    let sgrEvidence;
    let gradingEvidence;
    let sgrColorsEvidence;
    let sgrRgbEvidence;
    let sgrAttrsEvidence;
    let sgrPaletteEvidence;
    let sgrTruecolorEvidence;
    let truecolorFindingEvidence;
    let sgrUnderlineEvidence;
    let sgrUnderlineColorEvidence;
    let underlineResolvedEvidence;
    let sgrResetEvidence;
    let sgrClosureEvidence;
    let eraseLineEvidence;
    let charEditEvidence;
    let eraseDisplayEvidence;
    let lineEditEvidence;
    let insertReplaceEvidence;
    let charsetsEvidence;
    let scrollbackEvidence;
    let savedResetEvidence;
    let eraseAttrsRegionEvidence;
    let attrRectEvidence;
    let cursorQualEvidence;
    let eraseCharsHistoryEvidence;
    let selectiveEraseEvidence;
    let rectEditEvidence;
    let colEditEvidence;
    let rectChecksumEvidence;
    let lrMarginsEvidence;
    let coreGapsEvidence;
    let textCursorEvidence;
    let modernCursorEvidence, modernModesEvidence;
    let coreEraseEvidence;
    let tabStopsEvidence;
    let coreWrapEvidence;
    let sgrRasterEvidence;
    let reverseWideEvidence;
    let routedInputEvidence;
    let modifyOtherKeysEvidence;
    let mexEvidence;
    let pxmEvidence;
    let osc133Evidence;
    let osc633Evidence;
    let osc78Evidence;
    let titleStackEvidence;
    let xtgettcapEvidence;
    let osc9Evidence;
    let notifyEvidence;
    let devqEvidence;
    let cellSizeEvidence;
    let fontSizeEvidence;
    let xcsEvidence;
    let xssEvidence;
    let xsvEvidence;
    let kclEvidence;
    let osc5Evidence;
    let osc720Evidence;
    let osc3008Evidence;
    let osc22Evidence;
    let oscTitleEvidence;
    let selectionColorsEvidence;
    let colorResetEvidence;
    let rgbEvidence;
    let renditionEvidence;
    let cursorEvidence;
    let pixelEvidence;
    let colorEvidence;
    let eraseEvidence;
    let editingEvidence;
    let historyEvidence;
    let resizeEvidence;
    let reflowEvidence;
    let savedEvidence;
    let metadataEvidence;
    let inputEvidence;
    let staticImageEvidence;
    let animationEvidence;
    let queryEvidence;
    let privateClipboardEvidence;
    let capsEvidence;
    let pclEvidence;
    let dclEvidence;
    let dslEvidence;
    let sourceContext;
    // Persistent handlers also protect against a second signal during teardown.
    process.on('SIGINT', onInt);
    process.on('SIGTERM', onTerm);
    process.on('SIGHUP', onHup);
    if (['SIGINT', 'SIGTERM', 'SIGHUP'].includes(process.env.NTILDE_TERMINFO_PENDING_SIGNAL)) interrupted(process.env.NTILDE_TERMINFO_PENDING_SIGNAL);
    try {
        // Exclusive desktop ownership before any output, App or window action; refused contenders launch nothing.
        lease = await acquireDesktopLease(() => interruption);
        output = mkdtempSync(join(repo, 'artifacts', 'terminfo', 'owned-'));
        writeFileSync(join(output, 'source-snapshot.json'), snapshot.bytes, { flag: 'wx', mode: 0o600 });
        if (isOsc633Scope(collectionScope)) {
            const predecessor = readFileSync(join(repo, 'docs', 'qa', 'terminfo', '2026-11-16-sgr-pixel-mouse', 'owned-run.zip'));
            writeFileSync(join(output, collectionScope.predecessor.file), predecessor, { flag: 'wx', mode: 0o600 });
            verifyScopePredecessor(output, completeOwnedReceipt);
        }
        scratch = createPrivateScratch();
        if (interruption) throw interruption;
        const privateTool = join(scratch, 'collector');
        installLockedCollector(privateTool, input.manifestBytes, input.lockBytes);
        const { ownerModule, bundle, adapterBundleSha256, receiptBytes, lockBytes, originalBundle } = prepareCollector(privateTool);
        const cellSizeSource = adaptCellSizeCollector(readFileSync(bundle));
        const cellSizeBundleSha256 = hash(cellSizeSource);
        const cellSizeBundle = join(privateTool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-cell-size-${cellSizeBundleSha256}.mjs`);
        writeFileSync(cellSizeBundle, cellSizeSource, { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'collector-cell-size.mjs'), cellSizeSource, { flag: 'wx', mode: 0o600 });
        const fontSizeSource = adaptFontSizeCollector(readFileSync(bundle));
        const fontSizeBundleSha256 = hash(fontSizeSource);
        const fontSizeBundle = join(privateTool, 'node_modules', 'terminfo.dev', 'dist', `ntilde-font-size-${fontSizeBundleSha256}.mjs`);
        writeFileSync(fontSizeBundle, fontSizeSource, { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'collector-font-size.mjs'), fontSizeSource, { flag: 'wx', mode: 0o600 });
        const { bundle: gradingBundle, gradingBundleSha256 } = prepareGradingCollector(privateTool, bundle, output);
        const { bundle: sgrColorsBundle, sgrColorsBundleSha256 } = prepareSgrColorsCollector(privateTool, gradingBundle, output);
        const { bundle: sgrRgbBundle, sgrRgbBundleSha256 } = prepareSgrRgbCollector(privateTool, sgrColorsBundle, output);
        const { bundle: sgrAttrsBundle, sgrAttrsBundleSha256 } = prepareSgrAttrsCollector(privateTool, sgrRgbBundle, output);
        const { bundle: sgrPaletteBundle, sgrPaletteBundleSha256 } = prepareSgrPaletteCollector(privateTool, sgrAttrsBundle, output);
        const { bundle: sgrTruecolorBundle, sgrTruecolorBundleSha256 } = prepareSgrTruecolorCollector(privateTool, sgrPaletteBundle, output);
        const { bundle: sgrUnderlineBundle, sgrUnderlineBundleSha256 } = prepareSgrUnderlineCollector(privateTool, sgrTruecolorBundle, output);
        const { bundle: sgrUnderlineColorBundle, sgrUnderlineColorBundleSha256 } = prepareSgrUnderlineColorCollector(privateTool, sgrUnderlineBundle, output);
        const { bundle: sgrResetBundle, sgrResetBundleSha256 } = prepareSgrResetCollector(privateTool, sgrUnderlineColorBundle, output);
        const { bundle: sgrClosureBundle, sgrClosureBundleSha256 } = prepareSgrClosureCollector(privateTool, sgrResetBundle, output);
        const { bundle: eraseLineBundle, eraseLineBundleSha256 } = prepareEraseLineCollector(privateTool, sgrClosureBundle, output);
        const { bundle: charEditBundle, charEditBundleSha256 } = prepareCharEditCollector(privateTool, eraseLineBundle, output);
        const { bundle: eraseDisplayBundle, eraseDisplayBundleSha256 } = prepareEraseDisplayCollector(privateTool, charEditBundle, output);
        const { bundle: lineEditBundle, lineEditBundleSha256 } = prepareLineEditCollector(privateTool, eraseDisplayBundle, output);
        const { bundle: charsetsBundle, charsetsBundleSha256 } = prepareCharsetsCollector(privateTool, lineEditBundle, output);
        const { bundle: scrollbackBundle, scrollbackBundleSha256 } = prepareScrollbackCollector(privateTool, charsetsBundle, output);
        const { bundle: savedResetBundle, savedResetBundleSha256 } = prepareSavedResetCollector(privateTool, scrollbackBundle, output);
        const { bundle: eraseAttrsRegionBundle, eraseAttrsRegionBundleSha256 } = prepareEraseAttrsRegionCollector(privateTool, savedResetBundle, output);
        const { bundle: attrRectBundle, attrRectBundleSha256 } = prepareAttrRectCollector(privateTool, eraseAttrsRegionBundle, output);
        const { bundle: cursorQualBundle, cursorQualBundleSha256 } = prepareCursorQualCollector(privateTool, attrRectBundle, output);
        const { bundle: eraseCharsHistoryBundle, eraseCharsHistoryBundleSha256 } = prepareEraseCharsHistoryCollector(privateTool, cursorQualBundle, output);
        const { bundle: selectiveEraseBundle, selectiveEraseBundleSha256 } = prepareSelectiveEraseCollector(privateTool, eraseCharsHistoryBundle, output);
        const { bundle: rectEditBundle, rectEditBundleSha256 } = prepareRectEditCollector(privateTool, selectiveEraseBundle, output);
        const { bundle: colEditBundle, colEditBundleSha256 } = prepareColEditCollector(privateTool, rectEditBundle, output);
        const { bundle: rectChecksumBundle, rectChecksumBundleSha256 } = prepareRectChecksumCollector(privateTool, colEditBundle, output);
        const { bundle: lrMarginsBundle, lrMarginsBundleSha256 } = prepareLrMarginsCollector(privateTool, rectChecksumBundle, output);
        const { bundle: insertReplaceBundle, insertReplaceBundleSha256 } = prepareInsertReplaceCollector(privateTool, lrMarginsBundle, output);
        const coreGapsSource = adaptCoreGapsCollector(readFileSync(lrMarginsBundle));
        const coreGapsBundleSha256 = hash(coreGapsSource);
        const coreGapsBundle = join(privateTool, 'node_modules', 'terminfo.dev', 'dist', 'ntilde-cg-' + coreGapsBundleSha256 + '.mjs');
        writeFileSync(coreGapsBundle, coreGapsSource, { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'collector-cg.mjs'), coreGapsSource, { flag: 'wx', mode: 0o600 });
        const { bundle: routedInputBundle, routedInputBundleSha256 } = prepareRoutedInputCollector(privateTool, lrMarginsBundle, output);
        const { bundle: osc133Bundle, osc133BundleSha256 } = prepareOsc133Collector(privateTool, lrMarginsBundle, output);
        const { bundle: osc633Bundle, osc633BundleSha256 } = isOsc633Scope(collectionScope) ? prepareOsc633Collector(privateTool, osc133Bundle, output) : {};
        const { bundle: osc78Bundle, osc78BundleSha256 } = prepareOsc78Collector(privateTool, lrMarginsBundle, output);
        const { bundle: titleStackBundle, titleStackBundleSha256 } = prepareTitleStackCollector(privateTool, lrMarginsBundle, output);
        const { bundle: oscTitleBundle, oscTitleBundleSha256 } = prepareOscTitleCollector(privateTool, titleStackBundle, output);
        const { bundle: xtgettcapBundle, xtgettcapBundleSha256 } = prepareXtgettcapCollector(privateTool, titleStackBundle, output);
        const { bundle: osc9Bundle, osc9BundleSha256 } = prepareOsc9Collector(privateTool, lrMarginsBundle, output);
        const { bundle: notifyBundle, notifyBundleSha256 } = prepareNotifyCollector(privateTool, lrMarginsBundle, output);
        const { bundle: devqBundle, devqBundleSha256 } = prepareDevqCollector(privateTool, lrMarginsBundle, output);
        const { bundle: xcsBundle, xcsBundleSha256 } = prepareXcsCollector(privateTool, lrMarginsBundle, output);
        const { bundle: xssBundle, xssBundleSha256 } = prepareXssCollector(privateTool, lrMarginsBundle, output);
        const { bundle: xsvBundle, xsvBundleSha256 } = prepareXsvCollector(privateTool, lrMarginsBundle, output);
        const { bundle: kclBundle, kclBundleSha256 } = prepareKclCollector(privateTool, lrMarginsBundle, output);
        const { bundle: osc5Bundle, osc5BundleSha256 } = prepareOsc5Collector(privateTool, lrMarginsBundle, output);
        const { bundle: osc720Bundle, osc720BundleSha256 } = prepareOsc720Collector(privateTool, lrMarginsBundle, output);
        const { bundle: osc3008Bundle, osc3008BundleSha256 } = prepareOsc3008Collector(privateTool, lrMarginsBundle, output);
        const { bundle: osc22Bundle, osc22BundleSha256 } = prepareOsc22Collector(privateTool, lrMarginsBundle, output);
        const { bundle: modifyOtherKeysBundle, modifyOtherKeysBundleSha256 } = prepareModifyOtherKeysCollector(privateTool, lrMarginsBundle, output);
        const { bundle: mexBundle, mexBundleSha256 } = prepareMexCollector(privateTool, lrMarginsBundle, output);
        const { bundle: pxmBundle, pxmBundleSha256 } = preparePxmCollector(privateTool, lrMarginsBundle, output);
        const { bundle: reflowBundle, asciiReflowBundleSha256 } = prepareReflowCollector(privateTool, oscTitleBundle, output);
        const { bundle: colorResetBundle, colorResetBundleSha256 } = prepareColorResetCollector(privateTool, lrMarginsBundle, output);
        const { bundle: capsBundle, capsBundleSha256 } = prepareCapsCollector(privateTool, lrMarginsBundle, output);
        const { bundle: pclBundle, pclBundleSha256 } = preparePclCollector(privateTool, lrMarginsBundle, output);
        const { bundle: dclBundle, dclBundleSha256 } = prepareDclCollector(privateTool, lrMarginsBundle, output);
        const { bundle: dslBundle, dslBundleSha256 } = prepareDslCollector(privateTool, lrMarginsBundle, output);
        const { bundle: selectionColorsBundle, selectionColorsBundleSha256 } = prepareSelectionColorsCollector(privateTool, oscTitleBundle, output);
        const appData = join(scratch, 'appdata');
        mkdirSync(appData, { mode: 0o700 });
        const runId = lease.leaseId; // the App/worker markers carry the lease identity, so survivors are attributable
        const token = randomBytes(32).toString('hex');
        const configPath = join(scratch, 'worker.json');
        const workerScript = join(sourceRepo, 'scripts', 'terminfo', 'worker.mjs');
        const profileName = `terminfo disposable worker ${runId}`;
        const config = { privateClipboard: true, runId, token, appData, output, executable, bundle, gradingBundle, gradingBundleSha256,
            cellSizeBundle, cellSizeBundleSha256, fontSizeBundle, fontSizeBundleSha256,
            ...(collectionScope ? { collectionScope } : {}),
            sgrColorsBundle, sgrColorsBundleSha256, sgrRgbBundle, sgrRgbBundleSha256, sgrAttrsBundle, sgrAttrsBundleSha256,
            sgrPaletteBundle, sgrPaletteBundleSha256, sgrTruecolorBundle, sgrTruecolorBundleSha256, sgrUnderlineBundle, sgrUnderlineBundleSha256, sgrUnderlineColorBundle, sgrUnderlineColorBundleSha256, sgrResetBundle, sgrResetBundleSha256, sgrClosureBundle, sgrClosureBundleSha256, eraseLineBundle, eraseLineBundleSha256, charEditBundle, charEditBundleSha256, eraseDisplayBundle, eraseDisplayBundleSha256, lineEditBundle, lineEditBundleSha256, charsetsBundle, charsetsBundleSha256, scrollbackBundle, scrollbackBundleSha256, savedResetBundle, savedResetBundleSha256, eraseAttrsRegionBundle, eraseAttrsRegionBundleSha256, attrRectBundle, attrRectBundleSha256, cursorQualBundle, cursorQualBundleSha256, eraseCharsHistoryBundle, eraseCharsHistoryBundleSha256, selectiveEraseBundle, selectiveEraseBundleSha256, rectEditBundle, rectEditBundleSha256, colEditBundle, colEditBundleSha256, rectChecksumBundle, rectChecksumBundleSha256, lrMarginsBundle, lrMarginsBundleSha256, colorResetBundle, colorResetBundleSha256,
            coreGapsBundle, coreGapsBundleSha256, routedInputBundle, routedInputBundleSha256, osc133Bundle, osc133BundleSha256, osc633Bundle, osc633BundleSha256, osc78Bundle, osc78BundleSha256, titleStackBundle, titleStackBundleSha256, xtgettcapBundle, xtgettcapBundleSha256, osc9Bundle, osc9BundleSha256, notifyBundle, notifyBundleSha256, devqBundle, devqBundleSha256, xcsBundle, xcsBundleSha256, xssBundle, xssBundleSha256, xsvBundle, xsvBundleSha256, kclBundle, kclBundleSha256, osc5Bundle, osc5BundleSha256, osc720Bundle, osc720BundleSha256, osc3008Bundle, osc3008BundleSha256, osc22Bundle, osc22BundleSha256, capsBundle, capsBundleSha256, pclBundle, pclBundleSha256, dclBundle, dclBundleSha256, dslBundle, dslBundleSha256, mexBundle, mexBundleSha256, pxmBundle, pxmBundleSha256, oscTitleBundle, oscTitleBundleSha256, selectionColorsBundle, selectionColorsBundleSha256, insertReplaceBundle, insertReplaceBundleSha256, modifyOtherKeysBundle, modifyOtherKeysBundleSha256, reflowBundle, reflowBundleSha256: asciiReflowBundleSha256,
            profileName, cellNonce: `NTILDE_QA_${runId}`,
            socket: join(scratch, 'owner.sock'), adapterBundleSha256, upstreamBundleSha256 };
        writeJson(configPath, config);
        const command = join(scratch, 'worker.sh');
        writeFileSync(command, `#!/bin/sh\nexec ${quote(process.execPath)} ${quote(workerScript)} ${quote(configPath)} --ntilde-terminfo-worker=${runId}\n`, { flag: 'wx', mode: 0o700 });
        const profileId = randomUUID();
        const settings = ownedSettings({ profileId, profileName, command, scratch, persistence: 'Off' });
        settings.FontSize = 40 / 3; // Ten points at unity zoom.
        settings.UiScale = 1;
        const staticImageCaptureScale = args[5] === 'static-images' ? calibratedStaticImageCaptureScale : undefined;
        writeJson(join(appData, 'settings.json'), settings);
        writeJson(join(output, 'initial-settings.json'), settings);
        writeFileSync(join(output, 'upstream-suite-receipt.json'), receiptBytes, { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'collector-original.mjs'), originalBundle, { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'package-lock.json'), lockBytes, { flag: 'wx', mode: 0o600 });

        let app;
        let workerIdentity;
        let cellObserver;
        let sgrObserver;
        let gradingObserver;
        let sgrColorsObserver;
        let sgrRgbObserver;
        let sgrAttrsObserver;
        let sgrPaletteObserver;
        let sgrTruecolorObserver;
        let truecolorFindingObserver;
        let sgrUnderlineObserver;
        let sgrUnderlineColorObserver;
        let underlineResolvedObserver;
        let sgrResetObserver;
        let sgrClosureObserver;
        let eraseLineObserver;
        let charEditObserver;
        let eraseDisplayObserver;
        let lineEditObserver;
        let insertReplaceObserver;
        let charsetsObserver;
        let scrollbackObserver;
        let savedResetObserver;
        let eraseAttrsRegionObserver;
        let attrRectObserver;
        let cursorQualObserver;
        let eraseCharsHistoryObserver;
        let selectiveEraseObserver;
        let rectEditObserver;
        let colEditObserver;
        let rectChecksumObserver;
        let lrMarginsObserver;
        let xtgettcapObserver;
        let devqObserver;
        let cellSizeObserver;
        let fontSizeObserver;
        let xcsObserver;
        let xssObserver;
        let xsvObserver;
        let kclObserver;
        let osc5Observer;
        let coreGapsObserver;
        let textCursorObserver;
        let modernCursorObserver, modernModesObserver;
        let coreEraseObserver;
        let tabStopsObserver;
        let coreWrapState;
        let sgrRasterObserver;
        let reverseWideObserver;
        let colorResetObserver;
        let selectionColorsObserver;
        let pixelObserver;
        let pixelUnavailable;
        let colorObserver;
        let colorUnavailable;
        const editingStates = new Map();
        const editingSpecs = {
            erase: { nonce: 'NTILDE_ER_', suiteId: eraseSuiteId, count: 13, report: buildEraseReport },
            editing: { previous: 'erase', nonce: 'NTILDE_EC_', suiteId: editingSuiteId, count: 22, report: buildCellEditingReport },
            history: { previous: 'editing', nonce: 'NTILDE_HS_', suiteId: historySuiteId, count: 30, report: buildHistoryReport, observer: OwnedHistoryObserver },
        };
        const detailStates = new Map();
        const detailSpecs = {
            rgb: { previous: 'sgr', nonce: 'NTILDE_RG_', suiteId: rgbSuiteId, cases: rgbCases, report: buildRgbReport },
            rendition: { previous: 'rgb', nonce: 'NTILDE_RD_', suiteId: renditionSuiteId, cases: renditionCases, report: buildRenditionReport, includeOverline: true },
            cursor: { previous: 'rendition', nonce: 'NTILDE_CS_', suiteId: cursorSuiteId, cases: cursorCases, report: buildCursorReport, includeCursorMode: true },
        };
        let resizeState;
        let reflowState;
        let savedState;
        let metadataState;
        let inputState;
        let staticImageState;
        let animationState;
        let queryState;
        let privateClipboardState;
        let completed = false, outputModeVerified = false;
        const proofs = [];
        const image = statSync(executable);
        const context = {
            adapter: adapterId, adapterBundleSha256, upstreamBundleSha256, appVersion: args[3],
            ...(collectionScope ? { collectionScope } : {}),
            coreGapsSuiteId, coreGapsAdapterId, coreGapsBundleSha256, textCursorSuiteId, modernCursorSuiteId, modernModesSuiteId, coreEraseSuiteId, tabStopsSuiteId, coreWrapSuiteId: wrapSuiteId, sgrRasterSuiteId, reverseWideSuiteId,
            sourceSnapshotPolicy, sourceSnapshotManifestSha256: snapshot.sha256, sourceSnapshotRoot: sourceRepo,
            appVersionSource: 'operator supplied; not independently verified',
            initialSettingsSha256: hash(readFileSync(join(output, 'initial-settings.json'))),
            executable, executableSha256: hash(readFileSync(executable)),
            assemblySha256: existsSync(join(dirname(executable), 'Ntilde.dll')) ? hash(readFileSync(join(dirname(executable), 'Ntilde.dll'))) : null,
            nodeVersion: process.version, dependencyInstall: 'isolated npm ci --ignore-scripts', startedAt: new Date().toISOString(), runId,
            ...retainCollectorEvidence(output, bundle, adapterBundleSha256, ownerModule, workerScript),
            retainedAdapterBundle: 'collector-adapter.mjs', retainedSources: 'sources',
            clipboard: 'armed synthetic App-private storage only; no native interchange or OSC52 read permission',
            privateClipboardSuiteId: ownedPrivateClipboardSuiteId, ownedPrivateClipboardPolicy,
            privateClipboardReferenceScope: 'selected App/VT observational reference inputs; not complete App closure or binary-source attestation',
            staticImageCaptureScale,
            retainedOriginalCollector: 'collector-original.mjs', terminalOutput: privateClipboardOutputPolicy, querySuiteId, ownedQueryPolicy, staticImageSuiteId, ownedStaticImagePolicy, animationSuiteId, ownedAnimationPolicy, inputSuiteId, ownedInputPolicy, metadataSuiteId, ownedMetadataPolicy, savedSuiteId, ownedSavedPolicy, resizeSuiteId, ownedResizePolicy, historySuiteId, eraseSuiteId, editingSuiteId, colorSuiteId, pixelSuiteId, pixels: 'nonce-bound owned offscreen renders; fixed synthetic phases, retained PNGs and render context; no live desktop timing',
            gradingAdapterId, asciiSgrSuiteId, gradingBundleSha256, gradingContractsVersion: asciiSgrContractsVersion,
            grading: 'versioned collector extension; pinned termless criteria replayed on parent-observed cells; not stock output',
            sgrColorsAdapterId, sgrColorsSuiteId, sgrColorsBundleSha256, sgrColorsContractsVersion,
            sgrColors: 'layered versioned collector extension; pinned reset/standard-color termless criteria replayed on parent-observed stored attributes and palette indices; not stock output',
            sgrPaletteAdapterId, sgrPaletteSuiteId, sgrPaletteBundleSha256, sgrPaletteContractsVersion,
            sgrTruecolorAdapterId, sgrTruecolorSuiteId, sgrTruecolorBundleSha256, sgrTruecolorContractsVersion,
            truecolorFindingSuiteId, truecolorFindingContractsVersion,
            sgrUnderlineAdapterId, sgrUnderlineSuiteId, sgrUnderlineBundleSha256, sgrUnderlineContractsVersion,
            sgrUnderlineColorAdapterId, sgrUnderlineColorSuiteId, sgrUnderlineColorBundleSha256, sgrUnderlineColorContractsVersion,
            underlineResolvedSuiteId, underlineResolvedContractsVersion,
            sgrResetAdapterId, sgrResetSuiteId, sgrResetBundleSha256, sgrResetContractsVersion,
            sgrClosureAdapterId, sgrClosureSuiteId, sgrClosureBundleSha256, sgrClosureContractsVersion,
            sgrClosure: 'layered versioned collector extension; pinned termless criteria sgr.blink, sgr.overline and sgr.underline.color replayed byte-exactly on parent-observed stored blink flag, explicit overline boolean and stored underline color with reset, decoy, independence and sibling-shared color controls; sgr.underline.color is graded from its own reads, never from the sibling sgr.underline-color-rgb verdict; no blink timing, rendering or App-resolved color; not stock output',
            eraseLineAdapterId, eraseLineSuiteId, eraseLineBundleSha256, eraseLineContractsVersion,
            charEditAdapterId, charEditSuiteId, charEditBundleSha256, charEditContractsVersion,
            charEdit: 'layered versioned collector extension; pinned character-editing termless criteria (editing.insert-chars with the explicit-1 ICH spelling, editing.delete-chars with the explicit-1 DCH spelling, editing.repeat-char with REP count 3) replayed on parent-observed stored ASCII cells, cursor and stored attribute details, with unmodified-seed, other-count-spelling, wide-row, right-edge, REP-after-barrier and attribute controls; REP graphic and repeat sent in one fenced write; created-blank and repeated-cell attributes observed not required; the pinned pixel/query paths never measure cells and are not qualified; no Unicode, wide-cell or combining editing; not stock output',
            eraseDisplayAdapterId, eraseDisplaySuiteId, eraseDisplayBundleSha256, eraseDisplayContractsVersion,
            lineEditAdapterId, lineEditSuiteId, lineEditBundleSha256, lineEditContractsVersion,
            insertReplaceAdapterId, insertReplaceSuiteId, insertReplaceBundleSha256, insertReplaceContractsVersion,
            charsetsAdapterId, charsetsSuiteId, charsetsBundleSha256, charsetsContractsVersion,
            charsets: 'layered versioned collector extension; pinned charset termless criteria (charsets.utf8, charsets.dec-special, charsets.dec-line-drawing, charsets.g0-g1-switching) replayed byte-exactly (UTF-8 text, escape designations and shift controls untouched) on parent-observed decoded physical cells from complete stored cell details (never attribute strings or UTF-16 offsets), the cursor and neutral stored attributes, with ASCII, designation, invocation, uppercase and lowercase restoration-witness controls; the pinned terminal pixel capture and cursor-query paths are never verdicts and are not qualified; no glyph, pixel, font, keyboard, locale or platform claim',
            scrollbackAdapterId, scrollbackSuiteId, scrollbackBundleSha256, scrollbackContractsVersion,
            savedResetAdapterId, savedResetSuiteId, savedResetBundleSha256, savedResetContractsVersion,
            eraseAttrsRegionAdapterId, eraseAttrsRegionSuiteId, eraseAttrsRegionBundleSha256, eraseAttrsRegionContractsVersion,
            eraseAttrsRegion: 'layered versioned collector extension; pinned termless criteria erase.el-with-attrs (EL with the omitted parameter over a measured SGR 42 background: the erased cell (0,0) reads blank with the same App-resolved background RGB as the X it replaced) and erase.ed-scroll-region (ED with the omitted parameter, margins 3;10 and the cursor at row 2: the preceding row KEEP! survives and the target cells read blank) replayed byte-exactly on the disposable App main screen and graded from parent-observed stored cells, App-resolved colors, the cursor, margins, mode flags and history, with a colored-X seed proof, pen and margin restoration witnesses, a full-screen control against accidental whole-screen clearing, resolved-color versus stored-representation comparison and current-pen versus preserved-background controls (observed, not required) and a marker fill recording where ED stopped relative to the margins (observed, not graded; no clipping claim); the pinned terminal cursor-query paths never carry a verdict and are not qualified; no rendered-appearance claim; not stock output',
            savedReset: 'layered versioned collector extension; pinned termless criteria modes.alt-screen.exit (the seeded ?1049 roundtrip), modes.altscreen-47, modes.altscreen-1047 (inconclusive by design in the pinned probe), reset.sgr (a case separate from sgr.reset) and reset.decaln (cell 0,0) replayed byte-exactly on the disposable App main screen and graded from parent-observed stored cells, cursor, active-buffer flag, margins, mode flags and history; the visible-buffer effect contracts for ?47 and ?1047 are separately identified Ntilde observations beside the preserved pinned verdicts; active-screen reads only, no direct inactive-bank inspection; reset.method, RIS and the pinned DECALN pixel path are not claimed',
            cursorQualAdapterId, cursorQualSuiteId, cursorQualBundleSha256, cursorQualContractsVersion,
            eraseCharsHistoryAdapterId, eraseCharsHistorySuiteId, eraseCharsHistoryBundleSha256, eraseCharsHistoryContractsVersion,
            selectiveEraseAdapterId, selectiveEraseSuiteId, selectiveEraseBundleSha256, selectiveEraseContractsVersion,
            selectiveErase: 'layered versioned collector extension; pinned termless criteria erase.selective (DECSED, ESC[?2J) and editing.decsera (DECSERA, ESC[1;1;1;5${) replayed byte-exactly over the seeded DECSCA-protected P and unprotected ABCDZ and graded from parent-observed stored cells, per-cell DECSCA protection (observed, never inferred from a surviving marker), cursor, stored attributes, mode flags, buffer state and saved lines, with ordinary-erase, protection-off, overwrite, restoration, full-screen, edge, bold-attribute, history and incorrect-bounds or other-mode controls; the pinned terminal pixel and cursor-query paths never carry a verdict and are not qualified; ASCII only; not stock output',
            rectEditAdapterId, rectEditSuiteId, rectEditBundleSha256, rectEditContractsVersion,
            colEditAdapterId, colEditSuiteId, colEditBundleSha256, colEditContractsVersion,
            rectChecksumAdapterId, rectChecksumSuiteId, rectChecksumBundleSha256, rectChecksumContractsVersion,
            lrMarginsAdapterId, lrMarginsSuiteId, lrMarginsBundleSha256, lrMarginsContractsVersion,
            colorResetAdapterId, colorResetSuiteId, colorResetBundleSha256, colorResetContractsVersion,
            selectionColorsAdapterId, selectionColorsSuiteId, selectionColorsBundleSha256, selectionColorsContractsVersion,
            colorReset: 'layered versioned collector extension; pinned termless criteria extensions.osc104-reset-palette, osc110-reset-fg, osc111-reset-bg and osc112-reset-cursor (the BEL-spelled query, set of rgb:aa/bb/cc, query, reset and query) replayed byte-exactly on a disposable App and graded from exact fenced OSC replies, the App-resolved colors and override metadata, stored default/palette/literal cells, the cursor and controlled offscreen renders by an independent runtime-color model over the measured baseline; the pinned terminal paths (unmeasuredStateEffect) stay inconclusive by design; not stock CLI data',
            lrMargins: 'layered versioned collector extension; pinned termless modes.left-right-margin code (ESC[?69h, the mode metadata, ESC[?69l; inconclusive by design) replayed byte-exactly and preserved, beside a separately identified effect contract graded from parent-observed stored cells, the cursor and the App-stored region, left/right margins, DECLRMM, origin and insert mode by an independent margins model over sixteen controls; stored ASCII cells only, no stock grades',
            routedInputAdapterId, routedInputSuiteId: routedInputGradedSuiteId, routedInputBundleSha256, routedInputContractsVersion,
            modifyOtherKeysAdapterId, modifyOtherKeysSuiteId: modifyOtherKeysGradedSuiteId, modifyOtherKeysBundleSha256, modifyOtherKeysContractsVersion, modifyOtherKeysFirstPolicy,
            mexAdapterId, mexSuiteId: mexGradedSuiteId, mexBundleSha256, mexContractsVersion,
            pxmAdapterId, pxmSuiteId: pxmGradedSuiteId, pxmBundleSha256, pxmContractsVersion,
            modifyOtherKeys: 'layered versioned collector extension; pinned termless input.modify-other-keys code (always inconclusive by design) replayed over the declaration value the child itself answered by XTGETTCAP and preserved, beside a separately identified effect contract graded from the owned routed-input v3 plan: declared Avalonia events routed through the production App input path and the exact bytes the child received for the negotiated XTMODKEYS levels 1 and 2 (subcases of one benchmark id), every dispatch preceded by a child XTQMODKEYS proof of the level, literal protocol expectations cross-checked by an independent oracle, disabled/level-1/level-2 transitions, paired key-down/backend-text duplicate suppression, documented Shift-only-printable, Meta and AltGr policy limits, key-up and deliberately unhandled controls and a bounded kitty-precedence control; generated events, not physical keyboard input; no level 3, no formatOtherKeys, no Kitty expansion; direct-local only; no stock grades',
            mex: 'layered versioned collector extension; pinned termless modes.utf8-mouse-1005 code (feeds ?1005h, captures the DECRQM reply, feeds ?1005l, then notTestedResult: always inconclusive by design) and input.urxvt-mouse code (mouseInputProbe: always inconclusive) replayed over the DECRQM reply and tracking state the child itself received and preserved, beside separately identified effect contracts graded from the owned routed-input v4 plan: declared Avalonia events routed through the production App input path and the exact bytes the child received for UTF-8 (1005) and urxvt (1015) coordinates under X10, normal, button-event and any-event tracking, every dispatch preceded by child DECRQM proofs of the encoding and tracking state, literal protocol expectations cross-checked by an independent oracle written from xterm button.c, legacy and SGR controls, the single-slot selection rules and their reset forms; generated events, not physical pointer input; the stock terminal path of modes.utf8-mouse-1005 is a separate stock-collector result; direct-local only; no stock grade change by this layer',
            pxm: 'layered versioned collector extension; pinned termless input.pixel-mouse code (mouseInputProbe reading ctx.getMode("pixelMouse"): always inconclusive) replayed over the DECRQM 1016 state the child itself received and preserved, beside a separately identified effect contract graded from the owned routed-input v5 plan: declared Avalonia events routed through the production App input path, named by exact device-pixel positions in the pane text area, and the exact bytes the child received for SGR-Pixels (1016) reports under X10, normal, button-event and any-event tracking, every dispatch preceded by child DECRQM proofs of the encoding and tracking state, literal protocol expectations cross-checked by an independent oracle written from xterm button.c, legacy and SGR cell-coordinate controls, per-pixel motion, the single-slot selection rules and their reset forms; generated events, not physical pointer input; the pixel unit is the App device-pixel unit, declared and not compared with another terminal; direct-local only; no stock grade change by this layer',
            routedInput: 'layered versioned collector extension; pinned termless input.x10-mouse, input.button-event-mouse and modes.application-keypad code (always inconclusive by design) replayed over mode values the child itself received as DECRQM replies and preserved, beside separately identified effect contracts graded from the owned routed-input suite: declared Avalonia events routed through the production App input path and the exact bytes the child received, literal protocol expectations cross-checked by an independent oracle; generated events, not physical input; direct-local only; no stock grades',
            osc133AdapterId, osc133SuiteId, osc133BundleSha256, osc133ContractsVersion,
            ...(isOsc633Scope(collectionScope) ? { osc633AdapterId, osc633SuiteId, osc633BundleSha256, osc633ContractsVersion } : {}),
            osc78AdapterId, osc78SuiteId, osc78BundleSha256, osc78ContractsVersion,
            osc78: 'layered versioned collector extension; pinned extensions.osc7-cwd (no fixture bytes: declared-capability and no-readback results, inconclusive by design) and extensions.osc8 (termless: stored cells and hyperlink metadata of the pinned fixture; terminal: cursor position, inconclusive by design) replayed over parent-journaled observations and preserved, beside separately identified effect contracts graded from paired complete stored cells, pane metadata (title, host working directory, hyperlink runs with snapshot-local identities) and session status by an independent oracle: reported working-directory metadata only (not the child process directory or path existence) and stored hyperlink-bearing cells only (not click handling, URL opening or rendering); protocol handling in a disposable direct-local App only; no stock-grade claim',
            titleStackAdapterId, titleStackSuiteId, titleStackBundleSha256, titleStackContractsVersion,
            oscTitleAdapterId, oscTitleSuiteId, oscTitleBundleSha256, oscTitleContractsVersion,
            titleStack: 'layered versioned collector extension; pinned device.xtwinops-22 and device.xtwinops-23 termless code (feed a title, CSI 22;0t, feed another title, CSI 23;0t, getTitle() after each stage; supported only when all three titles are as expected, never unsupported) and terminal code (the writes then a cursor query; inconclusive by design) replayed over parent-journaled observations and preserved, beside separately identified effect contracts graded from paired complete stored cells and the raw title, raw icon name, display title and tab text of the same observation by an independent title-stack oracle: each pinned fixture executed from a measured prepared baseline, plus combined, title-only, icon-only, nested (LIFO), mixed-selector, empty-pop, bounded-depth, alternate-screen, DECSTR and RIS experiments; raw icon-name state only, no host icon presentation, no title or icon report query, no direct-slot addressing, disposable direct-local App only, no stock grade',
            xtgettcapAdapterId, xtgettcapSuiteId, xtgettcapBundleSha256, xtgettcapContractsVersion,
            asciiReflowAdapterId, asciiReflowSuiteId, asciiReflowBundleSha256, asciiReflowContractsVersion, ownedAsciiReflowPolicy,
            osc9AdapterId, osc9SuiteId, osc9BundleSha256, osc9ContractsVersion,
            notifyAdapterId, notifySuiteId, notifyBundleSha256, notifyContractsVersion,
            devqAdapterId, devqSuiteId, devqBundleSha256, devqContractsVersion,
            cellSizeAdapterId, cellSizeSuiteId, cellSizeBundleSha256, cellSizeContractsVersion: cellSizeVersion,
            fontSizeAdapterId, fontSizeSuiteId, fontSizeBundleSha256, fontSizeContractsVersion: fontSizeVersion,
            xcsAdapterId, xcsSuiteId, xcsBundleSha256, xcsContractsVersion,
            xssAdapterId, xssSuiteId, xssBundleSha256, xssContractsVersion,
            xsvAdapterId, xsvSuiteId, xsvBundleSha256, xsvContractsVersion,
            kclAdapterId, kclSuiteId, kclBundleSha256, kclContractsVersion,
            osc5AdapterId, osc5SuiteId, osc5BundleSha256, osc5ContractsVersion,
            osc720AdapterId, osc720SuiteId, osc720BundleSha256, osc720ContractsVersion,
            osc3008AdapterId, osc3008SuiteId, osc3008BundleSha256, osc3008ContractsVersion,
            osc22AdapterId, osc22SuiteId, osc22BundleSha256, osc22ContractsVersion,
            capsAdapterId, capsSuiteId, capsBundleSha256, capsContractsVersion,
            pclAdapterId, pclSuiteId, pclBundleSha256, pclContractsVersion,
            dclAdapterId, dclSuiteId, dclBundleSha256, dclContractsVersion,
            dslAdapterId, dslSuiteId, dslBundleSha256, dslContractsVersion,
            xtgettcap: 'layered versioned collector extension; pinned device.xtgettcap termless and terminal code (DCS + q 544e ST; a 1+r544e=<even hex> value reply is supported, the bare 0+r refusal and silence stay inconclusive) replayed byte-exactly over the journaled raw replies of its own fenced exchange and preserved — TN is deliberately refused, so both pinned verdicts stay inconclusive — beside the separately identified effect contract ntilde-xtgettcap-capability-report-effect-v1 graded by an independent reply oracle over the same fence: the exact pinned request, the numeric Co/colors replies, the RGB/Tc flag replies, one string reply, multi-name reply order with per-name outcomes, documented unavailable and unknown names, case-sensitivity, the uppercase echo, malformed lists with exactly one refusal and verified recovery after each; every exchange must leave the complete screen, cursor, rendition, margins, modes and active screen unchanged; capability-report replies only — no rendering, color accuracy, control-string execution, Ms clipboard, X resource, remote-delivery or other-platform claim, no stock grade',
            asciiReflow: 'layered versioned collector extension; pinned extensions.reflow code (no fixture, no resize request, no cell readback; both arms always inconclusive by design) replayed byte-exactly over the journaled declared capability and preserved, beside a separately identified effect contract graded from paired complete stored cells, cursor, modes, attributes and complete ordered history at three actual geometries per experiment, proven by parent-selected App resize actions with independent kernel geometry and output-processing proof: an independent character-slicing model must reproduce the width round trip and the history round trip with top-anchored restoration in a disposable main screen buffer; the alternate screen is observed once as the nonce-bind control; no Unicode, wide-cell, grapheme or history-attribute claim, no images, pixels or rendered appearance, no saved banks, remote delivery or other platforms, no stock grades',
            osc9: 'layered versioned collector extension; pinned extensions.osc9-progress (no termless function; terminal path unmeasuredStateEffect) and extensions.notifications (declared-capability report; no delivery readback) preserved as always inconclusive and replayed over the layered derivation, beside separately identified effect contracts graded by an independent OSC 9 oracle from paired complete stored cells, pane metadata and session status: OSC 9;4 stored progress kind, percent and owner and the actual horizontal tab suffix (states 1-4, withdrawal, percentage present/clamped, ST terminator, unmarked and withdrawal controls; absent-percentage, unknown/malformed-state and bare-4 behavior recorded as policy, never graded), and the private in-window toast title, message, visibility and auto-hide with the window-focus and opt-in preconditions recorded at control time and at delivery (the parent defocuses the App by activating Finder and records it); no OS taskbar or desktop notification delivery, no OSC 777/99 or other OSC 9 variants, no real-program emission, no remote/mux, Windows/Linux, hidden-pane or unobserved focus-change claim, no stock grade',
            devq: 'layered versioned collector extension; pinned device.xtgetxres (DCS + Q 7465726d4e616d65 ST), device.xtreportcolors (CSI # R), device.xtwinops-20 (OSC 1;test-icon BEL then CSI 20 t) and device.xtwinops-21 (OSC 2;test-title BEL then CSI 21 t) termless and terminal code replayed byte-exactly over the journaled raw replies of their own fenced exchanges on a disposable App whose initial settings turn on AllowTitleReport (off by default) — the pinned verdicts are the replayed code\'s own (XTREPORTCOLORS stays inconclusive: its pinned pattern has no ? marker and cannot match xterm\'s CSI ? depth ; deepest # Q) — beside the separately identified effect contract ntilde-device-query-report-effect-v1 graded by an independent oracle written from xterm\'s control sequence text and source: XTGETXRES termName replies, the xterm palette stack (XTPUSHCOLORS/XTPOPCOLORS/XTREPORTCOLORS) read back through OSC 11 and OSC 4 replies, and the title and icon label reports, each exchange leaving the complete screen, cursor, rendition, margins, modes and active screen unchanged; device.term-features is documented only (no request, no case); termName is the documented session TERM, not read from the child; no stock grades.',
            xcs: 'layered versioned collector extension; pinned modes.xtpushcolors (CSI # P) and modes.xtpopcolors (CSI # Q), both always inconclusive by construction (they measure DA1 and cursor responsiveness, never stack state), replayed byte-exactly over the journaled raw bytes of their own fenced exchange and the cursor of its read and preserved, beside the separately identified effect contract ntilde-xterm-color-stack-effect-v1 graded by an independent oracle written from xterm\'s control sequence text: silence of both sequences, the foreground, background, cursor and ANSI palette entry 5 colors read back through OSC 10/11/12 and OSC 4 replies after pops and numbered restores, restoration of the untouched host default, LIFO order, snapshot copy semantics and numbered slots, each exchange leaving the complete screen, cursor, rendition, margins, modes and active screen unchanged; palette entry 200 and a pop with nothing stored are policy groups that never decide; no depth-report, rendering or stock-grade claim.',
            xss: 'layered versioned collector extension; pinned modes.xtpushsgr (CSI # {) and modes.xtpopsgr (CSI # }), both always inconclusive by construction (they measure DA1 and cursor responsiveness, never stack state), replayed byte-exactly over the journaled raw bytes of their own fenced exchange and the cursor of its read and preserved, beside the separately identified effect contract ntilde-xterm-sgr-stack-effect-v1 graded by an independent oracle written from xterm\'s control sequence text: silence of both sequences, and after pops the stored bold, faint, italic, underline, blink, inverse, hidden, strikethrough, foreground and background of a probe character\'s cell, the selection of each documented push parameter alone, the argument-less push saving all of them, LIFO order, snapshot copy semantics, ten levels holding and the baseline pen restored, each exchange leaving the complete screen, cursor, margins, modes and active screen unchanged; the eleventh push, a pop with nothing saved, an unlisted value and the overline and underline color are policy groups that never decide; stored cell attributes, no rendering, XTREPORTSGR or stock-grade claim.',
            xsv: 'layered versioned collector extension; pinned modes.xtsave (CSI ? 7 s) and modes.xtrestore (CSI ? 7 r), both always inconclusive by construction (they measure DA1 and cursor responsiveness, never saved-mode state), replayed byte-exactly over the journaled raw bytes of their own fenced exchange and the cursor of its read and preserved, beside the separately identified effect contract ntilde-xterm-saved-modes-effect-v1 graded by an independent oracle written from xterm\'s control sequence text: silence of both sequences, and after restores the stored DECAWM (also as a pending wrap after a character in the last column), DECOM, DECLRMM and DECTCEM state, each mode returning to its saved value in both polarities, only the listed modes restored, a list restoring together, a second save replacing the first, neither sequence being SCOSC, SCORC or DECSTBM, each exchange leaving the complete screen, cursor, margins, insert mode and active screen unchanged; values the text does not list, a repeated restore, the ?1048 cursor save and the cursor move of a restored ?6 are policy groups that never decide; stored state, no rendering, no claim for the input-side, mouse, alternate-screen, reverse-wrap or sixel modes and no stock-grade claim.',
            kcl: 'layered versioned collector extension; pinned extensions.osc21-kitty-color (OSC 21;foreground=? ST, a query-only probe the stock collector also grades), both pinned paths replayed byte-exactly over the journaled raw replies of their own fenced exchange, beside the separately identified effect contract ntilde-kitty-color-control-effect-v1 graded by an independent oracle written from kitty\'s color-control protocol text: exact 8-bit rgb replies for foreground, background, cursor, the selection colors and palette entries set by other sequences (OSC 4, 10, 11, 12, 17, 19), each key alone and together in request order, ST-terminated replies to BEL requests, set-then-query and the numeric encodings read back through the oracle\'s own parser and through OSC 10/4 replies, a bare key restoring the baseline reply, unknown keys as Base64 unknown fields, every exchange leaving the complete screen, cursor, margins, modes and active screen unchanged; color names, alpha, the empty (dynamic) value, cursor_text, oversize sequences and the field cap are policy groups that never decide; raw replies and state, no rendering or painted-pixel claim.',
            osc22: 'bounded basic OSC 22 setters: requested shape and actual Avalonia Cursor kind via paired metadata; pinned terminal CPR-only inconclusive retained; no native pointer-image, full Kitty, mux/replay or stock-score claim',
            caps: 'layered versioned collector extension; pinned extensions.osc1337-capabilities (OSC 1337 ; RequestCapabilities BEL, a query-only probe the stock collector also grades whose valid pattern accepts any feature string), both pinned paths replayed byte-exactly over the journaled raw replies of their own fenced exchange, beside the separately identified effect contract ntilde-osc1337-capabilities-effect-v1 graded by an independent literal written from the iTerm2 feature-reporting specification code table over this terminal implemented, tested capabilities: the exact pinned request, the same request ended by ST answered by the same ST-terminated reply, two requests answered by two identical replies in request order, and silence for an unsolicited Capabilities assignment, a bare or query Capabilities form, a suffixed or wrong-case request and another OSC, with the exact request still answered after them; every exchange must leave the complete screen, cursor, rendition, margins, modes and active screen unchanged; the measured run direct pane accepts OSC 52 writes under its default initial settings so the declaration includes Cw, a host that cannot answer omits it (policy, unit-tested, not measured here); Aw, Uw and the measured-unsupported Sx stay undeclared; the per-code behavior of every declared capability is owned by that capability own implementations and tests; raw replies and state, no rendering or painted-pixel claim.',
            pcl: 'layered versioned collector extension; pinned extensions.osc113-reset-pointer-fg and extensions.osc114-reset-pointer-bg (colorResetProbe(13, 113) and (14, 114): the termless path queries OSC 13 / OSC 14 and is inconclusive without a complete rgb reply, the terminal path writes the reset, asks the cursor position and returns unverifiedEffect), both pinned paths replayed byte-exactly over the journaled raw reply and cursor of their own fenced exchange, beside the separately identified effect contract ntilde-pointer-color-unsupported-effect-v1 graded by independent literals written from the seeded colors and the xterm chain order: every pointer-color query, set, reset and chained set is ignored and never answered, changes no screen, cursor, margin or mode state and leaves the foreground, background, cursor and selection colors exactly as seeded; raw replies and stored terminal state, not the operating system pointer image or painted pixels',
            dcl: 'layered versioned collector extension; pinned modes.deccolm (decrpmModeProbe("modes.deccolm", 3): the termless path feeds CSI ? 3 h, captures the CSI ? 3 $ p reply and feeds CSI ? 3 l and is inconclusive by construction, the terminal path queries mode 3 through the DA-sentinel DECRQM and is inconclusive for the not-recognized reply) both pinned paths replayed byte-exactly over the journaled raw replies of their own fenced exchange, beside the separately identified effect contract ntilde-deccolm-unsupported-effect-v1 graded by independent literals: Ntilde ignores DEC private modes 3 and 40 whole (the App has no program-initiated resize path), so every set, reset and allow-switching sequence leaves the complete screen, cursor, rendition, margins, modes and active screen unchanged, mode 3 and mode 40 are still answered not recognized, and the App grid and the kernel PTY grid, read by the parent with the system stty against the proved private PTY, both keep their baseline size at every read, beside control groups proving the reply channel answers recognised modes and the state reader sees a clear and a home; raw replies, stored terminal state and PTY geometry, no window-manager size, remote/mux or other-platform claim',
            dsl: 'layered versioned collector extension; pinned modes.decsclm (decrpmModeProbe("modes.decsclm", 4): the termless path feeds CSI ? 4 h, captures the CSI ? 4 $ p reply and feeds CSI ? 4 l and is inconclusive by construction, the terminal path queries mode 4 through the DA-sentinel DECRQM and is inconclusive for the not-recognized reply) both pinned paths replayed byte-exactly over the journaled raw replies of their own fenced exchange, beside the separately identified effect contract ntilde-decsclm-unsupported-effect-v1 graded by independent literals: Ntilde ignores DEC private mode 4 whole (terminal output always jump-scrolls, #1001), so with the mode set, held, reset and never touched a burst of forty line feeds that scrolls the margin band ends in the same deterministic screen, cursor and rendition state and every exchange finishes inside the two-second timing bound on the parent monotonic clock (the DEC smooth rate would need at least 6.6 seconds), mode 4 is still answered not recognized, beside control groups proving the reply channel answers recognised modes, the timing reader sees a slower exchange (a contracted 2.5 second worker hold) and the state reader sees a clear and a home; raw replies, stored terminal state and parent timing, no rendered frame, repaint cadence, window-manager, remote/mux or other-platform claim; a run whose fast exchanges miss the bound is inconclusive, never unsupported',
            osc3008: 'layered versioned collector extension; pinned extensions.osc3008-context (no termless function; the terminal path writes two strings, ESC[1;1H ESC[2K and OSC 3008;type=test BEL, then asks for the cursor position and returns unmeasuredCellResult, inconclusive by construction; the payload is not a UAPI.15 start or end) replayed byte-exactly over the journaled cursor, with the unchanged pinned code re-run from the retained derived bundle, and preserved, beside the separately identified effect contract ntilde-osc3008-context-effect-v1 graded by an independent oracle written from UAPI.15 v1.0 over paired complete stored cells, pane metadata (including the untrusted stored context stack and ended records) and session status: start and end of one and nested contexts, the specification example, an update flushing metadata and ending sub-contexts, BEL and ST terminators, id bounds, field validity (unknown and invalid fields ignored, ABNF bounds, escapes), end metadata, a soft terminal reset leaving the stack alone, and negative controls (the pinned payload, foreign spellings, OSC 133/633 not creating a context and a context not changing title, working directory or shell state); the stack depth, the ended-record ring, end-ends-sub-contexts, repeated fields and bare backslashes are policy groups that never decide; stored untrusted metadata only: no presentation (breadcrumbs, tinting, actions), command-assist or agent use, no hangup, RIS or alternate-screen claim, no real-program emission, remote/mux, Windows/Linux or stock-grade claim',
            osc5: 'layered versioned collector extension; pinned extensions.osc5-special-color (OSC 5;0;? BEL, a query-only probe the stock collector also grades), both pinned paths replayed byte-exactly over the journaled raw replies of their own fenced exchange, beside the separately identified effect contract ntilde-osc5-special-colors-effect-v1 graded by an independent oracle written from rxvt\'s special-color text: chained numeric selector/value pairs (0 bold, 1 underline, 2 blink, 3 reverse, 4 italic) over a five-slot resource set separate from the OSC 4 palette, the OSC 10-19 dynamic colors and the kitty OSC 21 keys (pinned by within-exchange reply equalities), per-slot and bare OSC 105 resets, the numeric encodings, reply order and the ST terminator; numeric selectors 0-4 only, ignored unmodeled selectors, malformed pairs, the oversize cap, set-only silence and the default-foreground slot default are policy groups that never decide; raw replies and state, no rendering or painted-pixel claim.',
            osc720: 'layered versioned collector extension; pinned extensions.osc720-scroll-up (the bare OSC 720 BEL, which has no `;` and which rxvt-unicode therefore does not dispatch): the terminal path (two writes and a cursor query, always inconclusive) and the termless function (30 fed lines, two scrollback reads, replayed unchanged over a parent-built scrollback context mapped from the App view position) preserved, beside a separately identified effect contract graded from the App view scroll position, stored history, cursor and screen with wheel and ED 3 observer controls; no stock grades.',
            notify: 'layered versioned collector extension; pinned extensions.osc777-notify (no termless function; the terminal path writes two strings and asks for the cursor position, inconclusive by construction) replayed over the journaled cursor and preserved, and pinned extensions.osc99-kitty-notify (decided by the unchanged stock probe in the same run and by the exact-query witness under query policy v3, identified here only), beside separately identified effect contracts graded by an independent oracle from paired complete stored cells and pane metadata: OSC 777 notify title and body and OSC 99 title, body, hold-until-done chunking, concatenation, base64 and ignored payload types as the private in-window toast title, message, visibility and auto-hide with the window-focus and opt-in preconditions recorded at control time and at delivery (the parent defocuses the App by activating Finder and records it); flattening, caps, unknown keys, refused chunks and empty payloads recorded as policy, never graded; no OS desktop notification delivery, no OSC 99 actions, close reports, icons, buttons, urgency, sounds or expiry, no real-program emission, no remote/mux, Windows/Linux, hidden-pane or unobserved focus-change claim, no stock grade for OSC 777',
            osc133: 'layered versioned collector extension; pinned extensions.osc133-a, -b, -c and -d termless and terminal code (marker + X consumption, always inconclusive by design) replayed over parent-journaled observations and preserved, beside separately identified effect contracts graded from paired complete stored cells, pane metadata (title, cwd, input window, raw command/output anchors) and session status by an independent lifecycle oracle: each pinned fixture executed from a measured prior state with an unmarked control and gating markers, plus canonical cycle, payload, boundary, terminator-variant and exit-payload observations; protocol handling in a disposable direct-local App only, no real-shell, remote, OSC 133 P, OSC 633 or stock-grade claim',
            rectChecksum: 'layered versioned collector extension; pinned termless criterion editing.decrqcra (ESC[1;1;1;1;1;5*y after ABCDE ESC[1;1H, a framed DCS 1 ! ~ hhhh ST) replayed byte-exactly on a disposable App whose initial settings turn on AllowRectangleChecksumReport (off by default), graded from raw replies bound to their DA barriers and parent-observed stored cells by an independent checksum model (character sum, bold/blink/reverse/underline weights, defaults, origin offset, page clipping, request id, non-admitted spellings, unchanged state); stored ASCII cells only, no stock grades',
            colEdit: 'layered versioned collector extension; pinned termless criteria editing.sl (ESC[2 @), editing.sr (ESC[2 A), editing.decic (ESC[2\'}) and editing.decdc (ESC[2\'~) replayed byte-exactly on a disposable App and graded from parent-observed stored cells of the whole screen, the cursor, App-stored margins, origin and insert mode, stored attribute tuples and per-cell DECSCA protection, with count, default, zero, clamp, region-inside/outside, origin, insert-mode, non-admitted-identity, first/last-column, moved-attribute, attribute-free-blank and moved-protection controls over a seed at both page edges; the pending-wrap state is observed, never graded; stored ASCII state with full-width horizontal margins only (DECLRMM is not implemented or claimed), the pinned pixel path never carries a verdict and is not qualified; no Unicode, wide-cell, scaled-text, image-plane, DECRQCRA, rectangle or rendered-appearance claim; not stock output',
            rectEdit: 'layered versioned collector extension; pinned termless criteria editing.decfra (ESC[88;1;1;3;5$x), editing.decera (ESC[1;1;3;5$z) and editing.deccra (ESC[1;1;2;5;1;5;10$v) replayed byte-exactly on a disposable App and graded from parent-observed stored cells of the whole screen, the cursor, App-stored margins, origin and insert mode and stored attribute tuples, with single-cell, inclusive-border, omitted, zero, clipped, no-op, origin, margin, insert-mode, live-pen, literal-pen and attributed-seed controls, unconditional erasure over DECSCA-marked text, and for DECCRA non-overlapping, overlapping (every direction), self, clipped, attribute-preserving and unsupported-page controls (pages are an observed Ntilde policy, never graded); stored ASCII state only, the pinned pixel path never carries a verdict and is not qualified; no Unicode, wide-cell, scaled-text, image-plane, protected-cell, DECSERA, DECCARA/DECRARA, DECSACE, checksum or rendered-appearance claim; not stock output',
            eraseCharsHistory: 'layered versioned collector extension; pinned termless criteria erase.character (ECH ESC[3X, explicit count 3, over ABCDE at column 0) and erase.screen.scrollback (ED 3 ESC[3J after rows+2 line feeds) replayed byte-exactly on the disposable App main screen and graded from parent-observed viewport text, stored cells and attributes, cursor, margins, modes, active buffer and the actual ordered saved lines and count, with erased-range, retained-cell, wide-row, oversized-count, right-edge, attribute, ordered-history, CSI 2J, ordinary-scrolling, empty-history and regrowth controls; ECH spellings other than the pinned one are observed, not graded; physical rows only; the pinned pixel/query paths never carry a verdict and are not qualified; ASCII only; not stock output',
            cursorQual: 'layered versioned collector extension; the four pinned cursor criteria (cursor.cup-scroll-region, cursor.hide, cursor.shape, cursor.reverse-wrap): the termless AND app callbacks replayed byte-exactly on a measured reset alternate screen over parent-observed stored state, physical cursor, margins, origin and cursor mode, raw CPR exchanges and controlled synthetic-phase render captures, with controls for DECOM off/on, region boundaries, restoration, visible and hidden references, steady shapes, blink phase and the mode-off reverse-wrap fixture; the geometry-repaired derivation for cursor.reverse-wrap and cursor.shape keeps the original callbacks and retains the original UndeclaredTerminalGeometry failures',
            attrRectAdapterId, attrRectSuiteId, attrRectBundleSha256, attrRectContractsVersion,
            attrRect: 'layered versioned collector extension; pinned termless criteria editing.deccara (ESC[1;1;3;5;7$r, set inverse over rows 1-3 columns 1-5 of aaaaaZ/bbbbbY/cccccX), editing.decrara (ESC[1;1;3;5;7$t, toggle inverse off the same seeded area) and editing.decsace (inconclusive by design in the pinned probe: it only feeds ESC[2*x and reports consumption) replayed byte-exactly on parent-observed stored cells, cursor and stored attribute details; the pinned verdicts are preserved and the separately identified effect contracts grade the attribute change itself with default-stream versus rectangle extent controls (DECSACE 0, 1 and 2), set/clear/toggle operand controls, preserved text, colors and current pen, outside-area controls, second-application restoration and extent-restoration witnesses; the extent setting is not readable from the App, so it is observed only through behavior; stored state only, no rendered appearance, no stock grades',
            scrollback: 'layered versioned collector extension; the nine pinned scrolling/history termless criteria (scrollback.accumulate, total-lines, scroll-up, reverse-index, scroll-down, set-region, alt-screen, decstbm, decstbm-reset) replayed byte-exactly on a measured reset main screen and graded from parent-observed viewport text, actual scrollback lines and count, margins, active screen, modes, cursor and stored attributes, with empty-history, pre-overflow, region-confinement, wrong-direction, no-op, whole-screen, alternate-screen isolation and unreset-region controls; three pinned probes are null by construction and the contract measurement beyond them is recorded as a divergence; ASCII only; not stock output',
            lineEdit: 'layered versioned collector extension; pinned line-editing termless criteria (editing.insert-lines with ESC[1L, editing.delete-lines with ESC[1M, each at row 2 column 1 over four seeded rows) replayed byte-exactly on parent-observed stored cells of the whole screen, cursor, App-stored margins, origin and insert mode and stored attribute details, with no-op, count-spelling (observed), full-height boundary, scroll-region, origin-mode and attribute controls; stored ASCII state only, the pinned pixel path never carries a verdict and is not qualified, scrollback observed on the alternate screen only',
            eraseDisplay: 'layered versioned collector extension; pinned erase-in-display termless criteria (erase.screen.below with ED 0, erase.screen.above with ED 1, erase.screen.all with ED 2, all explicit-parameter) replayed byte-exactly on parent-observed stored cells, cursor, stored attribute details, buffer state and saved lines, with unmodified-seed, other-spelling (omitted, explicit 0/1/2), full-screen fill, boundary, bold-seeded attribute and main-screen history controls; background-color erase observed not required; the pinned pixel capture path is capture-only upstream and not qualified; CSI 3J not graded; not stock output',
            eraseLine: 'layered versioned collector extension; pinned erase-in-line termless criteria (erase.line.right with the omitted-parameter spelling, erase.line.left with EL 1, erase.line.all with EL 2) replayed byte-exactly on parent-observed stored cells, cursor and stored attribute details, with unmodified-seed, other-spelling (omitted, explicit 0/1/2), wide-row and bold-seeded attribute controls; background-color erase observed not required; the pinned pixel capture path is capture-only upstream and not qualified; not stock output',
            sgrReset: 'layered versioned collector extension; pinned selective-reset termless criteria (sgr.selective-reset.underline via SGR 24 and sgr.selective-reset.inverse via SGR 27) replayed byte-exactly on parent-observed stored flags, exact underline style, stored colors and overline, with no-op, full-reset, wrong-reset and DECSCNM controls; underline-color behavior observed not required; rendered appearance not claimed; not stock output',
            underlineResolved: 'Ntilde extension controls (not terminfo.dev cases, no pinned probe, no collector extension): the opt-in App-reported resolved underline color (readScreen includeResolvedUnderlineColors) compared with an independent expectation derived from stored underline state, the recorded palette binding and contracted OSC 4 constants, for indexed, literal and default-inheritance underlines with an OSC 4 mutation and its OSC 104 restoration; theme-resolution stage only; rendered appearance is not claimed',
            sgrUnderlineColor: 'layered versioned collector extension; pinned underline-color termless criteria (sgr.underline-color-indexed, -rgb, -reset; the aggregate sgr.underline.color is not qualified) replayed on parent-observed stored underline style and color index/literal/default with parent-derived resolved RGB and an OSC 4 mutation control; colon forms are ungraded controls; rendered underline appearance not claimed; not stock output',
            sgrUnderline: 'layered versioned collector extension; pinned underline-style termless criteria (sgr.underline.double via SGR 21; sgr.underline.curly, .dotted, .dashed via SGR 4:3, 4:4, 4:5) replayed on parent-observed stored underline flag and exact stored style; SGR 4, 4:1 and 4:2 are labeled controls without a grade; stroke appearance not claimed; not stock output',
            truecolorFinding: 'Ntilde finding (not a terminfo.dev case, no pinned probe, no collector extension): five exact direct-RGB values on fg/bg graded from parent-observed stored literal bytes and App-resolved RGB bound to the per-frame recorded palette, with an indexed positive control, an OSC 4 mutation of the aliased entry and its restoration; no pixels',
            sgrTruecolor: 'layered versioned collector extension; pinned truecolor termless criteria (sgr.fg.truecolor, sgr.bg.truecolor; semicolon 38/48;2;r;g;b form only) replayed on parent-observed stored literal bytes (palette index and default marker cleared) with App-resolved RGB bound to one recorded palette/theme; no pixels; not stock output',
            sgrPalette: 'layered versioned collector extension; pinned bright, 256-color and default-color termless criteria (sgr.fg/bg.bright, .256, .default) replayed on parent-observed stored palette indices, default markers and literal bytes with App-resolved RGB bound to one recorded palette/theme; no pixels; not stock output',
            sgrAttrsAdapterId, sgrAttrsSuiteId, sgrAttrsBundleSha256, sgrAttrsContractsVersion,
            sgrAttrs: 'layered versioned collector extension; pinned SGR attribute termless criteria (underline.single, inverse, faint, hidden, strikethrough) replayed on parent-observed stored flags and underline style with DECSCNM, neutral-baseline and reset controls; stored state only, no pixels; not stock output',
            sgrRgbAdapterId, sgrRgbSuiteId, sgrRgbBundleSha256, sgrRgbContractsVersion,
            sgrRgb: 'layered versioned collector extension; pinned named-color RGB termless criteria replayed on parent-observed App-resolved colors bound to one recorded theme state; not stock output',
            resolvedColors: 'opt-in readScreen projection resolved in the App rendering layer; storage-to-theme resolution stage, one coherent render snapshot; no pixels',
            cells: 'private AgentHost readScreen; nonce-bound pane; separate ASCII cell-state suite',
            attributes: 'separate ASCII SGR flags and palette-index suite',
            cellDetails: 'separate stored ARGB/underline and rendition/charset suites; no theme resolution or pixels',
            cursorModes: 'stored cursor style/blink/default/visibility; pristine owned DECSTR cleanup, no host appearance or blink phase',
        };
        sourceContext = context;
        writeFileSync(join(output, 'cell-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgr-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'grading-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgcolors-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgrgb-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgattr-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgpal-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgtc-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgtf-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgus-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sguc-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgur-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgsr-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sgcl-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'erln-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'ched-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'erdi-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'ledt-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'irm-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'chrs-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'scrl-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'svrs-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'erar-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'atrc-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'curq-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'echh-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'sels-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'rect-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'cole-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'csum-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'lrmm-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'shi-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        if (isOsc633Scope(collectionScope)) writeFileSync(join(output, 'vs633-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'lnk-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'tst-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'ost-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'xgtc-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        if (!isOsc633Scope(collectionScope)) {
            writeFileSync(join(output, 'osn-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
            writeFileSync(join(output, 'ntf-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        }
        writeFileSync(join(output, 'dvq-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'cell-size-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'xcs-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'xss-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'xsv-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'kcl-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'osc5-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'ovu-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'ocx-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'ptr-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'caps-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'pcl-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'dcl-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'dsl-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'crst-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        for (const prefix of [...Object.keys(detailSpecs), 'pixel', 'color', ...Object.keys(editingSpecs), 'resize', 'saved', 'metadata', 'input', 'image', 'query'])
            writeFileSync(join(output, `${prefix}-snapshots.jsonl`), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'reflow-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'reflow-actions.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'resize-actions.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'input-actions.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'image-actions.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'animation-snapshots.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'animation-actions.jsonl'), '', { flag: 'wx', mode: 0o600 });
        writeFileSync(join(output, 'query-actions.jsonl'), '', { flag: 'wx', mode: 0o600 });
        /** Complete each prior suite before capturing this one; only initial typed refusal is optional. */
        const observeDetails = async (prefix, request, budget) => {
            const spec = detailSpecs[prefix];
            const previous = detailStates.get(spec.previous);
            const ready = spec.previous === 'sgr' ? sgrObserver?.restored : previous?.observer.restored || previous?.unavailable;
            if (!ready) throw new Error('The preceding owned suite must complete before detail observations.');
            let state = detailStates.get(prefix);
            if (!state) {
                state = { observer: new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: spec.nonce + runId, includeCellDetails: true, includeCursorMode: spec.includeCursorMode ?? false, includeOverline: spec.includeOverline ?? false,
                    prefix, expectedPaneId: cellObserver.paneId }) };
                detailStates.set(prefix, state);
            }
            if (state.unavailable) throw new Error('Detail observation was already recorded as unavailable.');
            try {
                const result = await state.observer.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, `${prefix}-snapshots.jsonl`), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                if (request.kind === prefix + '-start' && error.code === 'screenDetailsUnavailable'
                    && !state.observer.baseline && !state.observer.frames.length && state.observer.snapshots === 1) {
                    const file = `${prefix}-unavailable.json`;
                    writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: spec.suiteId,
                        status: 'unavailable', reason: error.code, fixtureStarted: false, plannedExperiments: spec.cases.length });
                    state.unavailable = { runId, suiteId: spec.suiteId, file, sha256: hash(readFileSync(join(output, file))),
                        status: 'unavailable', reason: error.code, counts: {}, provisionalUntil: 'cell-receipt.json' };
                }
                throw error;
            }
        };
        const retainDetails = prefix => {
            const state = detailStates.get(prefix), spec = detailSpecs[prefix];
            return state?.unavailable ?? retainCellReport(output, state?.observer, runId, spec.report, `${prefix}-observations.json`);
        };
        const recordPixelUnavailable = () => {
            const file = 'pixel-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: pixelSuiteId,
                status: 'unavailable', reason: 'screenDetailsUnavailable', fixtureStarted: false, plannedExperiments: pixelScenes.length });
            pixelUnavailable = { runId, suiteId: pixelSuiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason: 'screenDetailsUnavailable', counts: {}, provisionalUntil: 'cell-receipt.json' };
        };
        const observePixels = async (request, budget) => {
            const previous = detailStates.get('cursor');
            if (previous?.unavailable && request.kind === 'pixel-start' && !pixelUnavailable) {
                recordPixelUnavailable();
                const error = new Error('Pixel fixture requires complete screen details.');
                error.code = 'screenDetailsUnavailable';
                throw error;
            }
            if (!previous?.observer.restored) throw new Error('Cursor suite must restore before pixel observations.');
            pixelObserver ??= new OwnedPixelObserver({ output, appData, ownerPid: app.pid, profileName,
                nonce: `NTILDE_PX_${runId}`, expectedPaneId: cellObserver.paneId });
            try {
                const result = await pixelObserver.handle(request, budget);
                appendFileSync(join(output, 'pixel-snapshots.jsonl'), JSON.stringify(pixelObserver.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                if (request.kind === 'pixel-start' && error.code === 'screenDetailsUnavailable'
                    && !pixelObserver.before.baseline && pixelObserver.before.snapshots === 1 && !pixelObserver.frames.length) recordPixelUnavailable();
                throw error;
            }
        };
        const recordColorUnavailable = () => {
            const file = 'color-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: colorSuiteId,
                status: 'unavailable', reason: 'screenDetailsUnavailable', fixtureStarted: false, plannedExperiments: colorCases.length });
            colorUnavailable = { runId, suiteId: colorSuiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason: 'screenDetailsUnavailable', counts: {}, provisionalUntil: 'cell-receipt.json' };
        };
        const observeColors = async (request, budget) => {
            const previous = { unavailable: pixelUnavailable, observer: pixelObserver };
            if (previous?.unavailable && request.kind === 'color-start' && !colorUnavailable) {
                recordColorUnavailable();
                const error = new Error('Color fixture requires complete screen details.');
                error.code = 'screenDetailsUnavailable';
                throw error;
            }
            if (!previous?.observer.restored) throw new Error('Pixel suite must restore before color observations.');
            colorObserver ??= new OwnedColorObserver({ output, appData, ownerPid: app.pid, profileName,
                nonce: `NTILDE_CL_${runId}`, expectedPaneId: cellObserver.paneId });
            try {
                const result = await colorObserver.handle(request, budget);
                appendFileSync(join(output, 'color-snapshots.jsonl'), JSON.stringify(colorObserver.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                if (request.kind === 'color-start' && error.code === 'screenDetailsUnavailable'
                    && !colorObserver.before.baseline && colorObserver.before.snapshots === 1 && !colorObserver.frames.length) recordColorUnavailable();
                throw error;
            }
        };
        const recordEditingUnavailable = (prefix, state) => {
            const spec = editingSpecs[prefix], file = `${prefix}-unavailable.json`;
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: spec.suiteId,
                status: 'unavailable', reason: 'screenDetailsUnavailable', fixtureStarted: false, plannedExperiments: spec.count });
            state.unavailable = { runId, suiteId: spec.suiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason: 'screenDetailsUnavailable', counts: {}, provisionalUntil: 'cell-receipt.json' };
        };
        /** Run each known cell plan only after its predecessor restored or declined before writes. */
        const observeEditing = async (prefix, request, budget) => {
            const spec = editingSpecs[prefix];
            const previous = prefix === 'erase' ? { observer: colorObserver, unavailable: colorUnavailable } : editingStates.get(spec.previous);
            if (!previous?.observer?.restored && !previous?.unavailable) throw new Error('The previous suite must restore before editing observations.');
            let state = editingStates.get(prefix);
            if (!state) {
                state = { observer: new (spec.observer ?? OwnedEditingObserver)({ prefix, appData, ownerPid: app.pid, profileName,
                    nonce: editingSpecs[prefix].nonce + runId, expectedPaneId: cellObserver.paneId }) };
                editingStates.set(prefix, state);
            }
            if (state.unavailable) throw new Error('Editing unavailability was already recorded.');
            if (previous.unavailable && request.kind === prefix + '-start') {
                recordEditingUnavailable(prefix, state);
                const error = new Error('Editing fixture requires complete screen details.');
                error.code = 'screenDetailsUnavailable';
                throw error;
            }
            try {
                const result = await state.observer.handle(request, budget);
                appendFileSync(join(output, `${prefix}-snapshots.jsonl`), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                if (request.kind === prefix + '-start' && error.code === 'screenDetailsUnavailable'
                    && !state.observer.before.baseline && state.observer.before.snapshots === 1 && !state.observer.frames.length) recordEditingUnavailable(prefix, state);
                throw error;
            }
        };
        const retainEditing = prefix => {
            const state = editingStates.get(prefix);
            return state?.unavailable ?? retainCellReport(output, state?.observer, runId, editingSpecs[prefix].report, `${prefix}-observations.json`);
        };
        /** Record only a source-known initial refusal, before binding or requesting any resize. */
        const recordResizeUnavailable = reason => {
            const file = 'resize-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: resizeSuiteId,
                status: 'unavailable', reason, fixtureStarted: false, plannedExperiments: 3 });
            resizeState.unavailable = { runId, suiteId: resizeSuiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason, counts: {}, provisionalUntil: 'cell-receipt.json' };
        };
        /** Source-selected geometry changes stay separate from the ordinary fixed-baseline readers. */
        const observeResize = async (request, budget) => {
            const previous = editingStates.get('history');
            if (!previous?.observer?.restored && !previous?.unavailable) throw new Error('History must restore before resize observations.');
            if (!resizeState) {
                resizeState = { workerPid: request.workerPid, tty: request.tty, recordedFrames: 0, recordedActions: 0 };
                resizeState.observer = new OwnedResizeObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: 'NTILDE_RZ_' + runId, expectedPaneId: cellObserver.paneId,
                    performResize: (rows, cols, actionBudget) => resizeOwnedPane({ app, appData, executable, runId,
                        paneId: resizeState.observer.paneId, uid: process.getuid(),
                        workerPid: resizeState.workerPid, tty: resizeState.tty }, rows, cols, actionBudget) });
                proofs[0].resize.actions = resizeState.observer.actions;
            }
            const state = resizeState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('Resize fixture ownership or availability changed.');
            if (previous.unavailable && request.kind === 'resize-start') {
                recordResizeUnavailable('screenDetailsUnavailable');
                throw Object.assign(new Error('Resize fixture requires complete screen details.'), { code: 'screenDetailsUnavailable' });
            }
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === 'resize-start') {
                    proofs[0].resize.paneId = state.observer.paneId;
                    proofs[0].resize.originalGeometry = state.observer.original;
                }
                for (const frame of state.observer.frames.slice(state.recordedFrames)) {
                    appendFileSync(join(output, 'resize-snapshots.jsonl'), JSON.stringify(frame) + '\n');
                    state.recordedFrames++;
                }
                return result;
            } catch (error) {
                if (request.kind === 'resize-start' && ['screenDetailsUnavailable', 'resizeGeometryUnavailable'].includes(error.code)
                    && !state.observer.baseline && !state.observer.frames.length && !state.observer.actions.length) recordResizeUnavailable(error.code);
                throw error;
            } finally {
                for (const action of state.observer.actions.slice(state.recordedActions)) {
                    appendFileSync(join(output, 'resize-actions.jsonl'), JSON.stringify(action) + '\n');
                    state.recordedActions++;
                }
            }
        };
        /** Record only a source-known initial refusal, before binding or requesting any reflow resize. */
        const recordReflowUnavailable = reason => {
            const file = 'reflow-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: asciiReflowSuiteId,
                status: 'unavailable', reason, fixtureStarted: false, plannedExperiments: 2 });
            reflowState.unavailable = { runId, suiteId: asciiReflowSuiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason, counts: {}, provisionalUntil: 'cell-receipt.json' };
        };
        /** The ASCII reflow suite reuses the parent-owned resize action under its own prefix and plan; it runs after the resize suite restores. */
        const observeReflow = async (request, budget) => {
            const previous = editingStates.get('history');
            if (!resizeState?.observer?.restored && !resizeState?.unavailable) throw new Error('Resize must restore before ASCII reflow observations.');
            if (!previous?.observer?.restored && !previous?.unavailable) throw new Error('History must restore before ASCII reflow observations.');
            if (!reflowState) {
                reflowState = { workerPid: request.workerPid, tty: request.tty, recordedFrames: 0, recordedActions: 0 };
                reflowState.observer = new OwnedReflowObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: 'NTILDE_RF_' + runId, expectedPaneId: cellObserver.paneId,
                    performResize: (rows, cols, actionBudget) => resizeOwnedPane({ app, appData, executable, runId,
                        paneId: reflowState.observer.paneId, uid: process.getuid(),
                        workerPid: reflowState.workerPid, tty: reflowState.tty }, rows, cols, actionBudget) });
                proofs[0].asciiReflow.actions = reflowState.observer.actions;
            }
            const state = reflowState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('ASCII reflow fixture ownership or availability changed.');
            if (previous.unavailable && request.kind === 'reflow-start') {
                recordReflowUnavailable('screenDetailsUnavailable');
                throw Object.assign(new Error('ASCII reflow fixture requires complete screen details.'), { code: 'screenDetailsUnavailable' });
            }
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === 'reflow-start') {
                    proofs[0].asciiReflow.paneId = state.observer.paneId;
                    proofs[0].asciiReflow.originalGeometry = state.observer.original;
                }
                for (const frame of state.observer.frames.slice(state.recordedFrames)) {
                    appendFileSync(join(output, 'reflow-snapshots.jsonl'), JSON.stringify(frame) + '\n');
                    state.recordedFrames++;
                }
                return result;
            } catch (error) {
                if (request.kind === 'reflow-start' && ['screenDetailsUnavailable', 'asciiReflowGeometryUnavailable'].includes(error.code)
                    && !state.observer.baseline && !state.observer.frames.length && !state.observer.actions.length) recordReflowUnavailable(error.code);
                throw error;
            } finally {
                for (const action of state.observer.actions.slice(state.recordedActions)) {
                    appendFileSync(join(output, 'reflow-actions.jsonl'), JSON.stringify(action) + '\n');
                    state.recordedActions++;
                }
            }
        };
        /** Only an initial typed refusal may omit source-known saved-state stages. */
        const recordSavedUnavailable = reason => {
            const file = 'saved-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: savedSuiteId,
                status: 'unavailable', reason, fixtureStarted: false, plannedExperiments: 9 });
            savedState.unavailable = { runId, suiteId: savedSuiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason, counts: {}, provisionalUntil: 'cell-receipt.json' };
        };
        const observeSaved = async (request, budget) => {
            if (!resizeState?.observer?.restored && !resizeState?.unavailable) throw new Error('Resize must restore before saved-state observations.');
            savedState ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedSavedObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: 'NTILDE_SV_' + runId, expectedPaneId: cellObserver.paneId }) };
            const state = savedState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('Saved-state fixture ownership or availability changed.');
            if (resizeState.unavailable?.reason === 'screenDetailsUnavailable' && request.kind === 'saved-start') {
                recordSavedUnavailable('screenDetailsUnavailable');
                throw Object.assign(new Error('Saved-state fixture requires complete screen details.'), { code: 'screenDetailsUnavailable' });
            }
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === 'saved-start') {
                    if (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols) throw new Error('Original geometry changed before saved-state observations.');
                    proofs[0].saved.paneId = state.observer.paneId;
                    proofs[0].saved.geometry = { rows: result.screen.rows, cols: result.screen.cols };
                }
                appendFileSync(join(output, 'saved-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                if (request.kind === 'saved-start' && ['screenDetailsUnavailable', 'savedGeometryUnavailable'].includes(error.code)
                    && !state.observer.baseline && !state.observer.frames.length) recordSavedUnavailable(error.code);
                throw error;
            }
        };
        const recordMetadataUnavailable = reason => {
            const file = 'metadata-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: metadataSuiteId,
                status: 'unavailable', reason, fixtureStarted: false, plannedExperiments: 13 });
            metadataState.unavailable = { runId, suiteId: metadataSuiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason, counts: {}, provisionalUntil: 'cell-receipt.json' };
        };
        const observeMetadata = async (request, budget) => {
            if (!savedState?.observer?.restored && !savedState?.unavailable) throw new Error('Saved-state must restore before metadata observations.');
            metadataState ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName,
                    runId, expectedPaneId: cellObserver.paneId }) };
            const state = metadataState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('Metadata-state fixture ownership or availability changed.');
            if (savedState.unavailable?.reason === 'screenDetailsUnavailable' && request.kind === 'metadata-start') {
                recordMetadataUnavailable('screenDetailsUnavailable');
                throw Object.assign(new Error('Metadata-state fixture requires complete screen details.'), { code: 'screenDetailsUnavailable' });
            }
            try {
                if (request.kind === 'metadata-start') makeMetadataCases(cellObserver.baseline.rows, cellObserver.baseline.cols, runId);
                const result = await state.observer.handle(request, budget);
                if (request.kind === 'metadata-start') {
                    if (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols) throw new Error('Original geometry changed before metadata-state observations.');
                    proofs[0].metadata.paneId = state.observer.paneId;
                    proofs[0].metadata.geometry = { rows: result.screen.rows, cols: result.screen.cols };
                }
                appendFileSync(join(output, 'metadata-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer);
                if (initialMetadataRefusal(request, error, state.observer)) recordMetadataUnavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let osc133State;
        const recordOsc133Unavailable = reason => {
            writeJson(join(output, 'shi-unavailable.json'), { schemaVersion: 1, runId, suiteId: osc133SuiteId, status: 'unavailable', reason, plannedCases: 4 });
            osc133State.unavailable = true;
        };
        /** The OSC 133 suite reuses the paired metadata/status observer under its own prefix and plan; it runs after the left/right-margin suite. */
        const observeOsc133 = async (request, budget) => {
            if (!lrMarginsObserver?.restored) throw new Error('Left/right-margin suite must restore before OSC 133 observations.');
            osc133State ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: osc133Prefix, includeResolvedColors: true, planOf: osc133ObserverPlan, matchesBaseline: matchesOsc133Baseline }) };
            const state = osc133State;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC 133 fixture ownership or availability changed.');
            if (request.kind === `${osc133Prefix}-start`) {
                const { rows, cols } = cellObserver.baseline;
                const reason = metadataState?.unavailable?.reason ?? savedState?.unavailable?.reason
                    ?? (rows < osc133Minimum.rows || cols < osc133Minimum.cols ? 'metadataGeometryUnavailable' : null);
                if (reason !== null && !['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC 133 unavailability reason.');
                if (reason !== null) {
                    recordOsc133Unavailable(reason);
                    throw Object.assign(new Error('OSC 133 fixture is unavailable.'), { code: reason });
                }
            }
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${osc133Prefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before OSC 133 observations.');
                }
                appendFileSync(join(output, 'shi-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'shi-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOsc133Unavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let osc633State;
        const recordOsc633Unavailable = reason => {
            writeJson(join(output, 'vs633-unavailable.json'), { schemaVersion: 1, runId, suiteId: osc633SuiteId, status: 'unavailable', reason, plannedCases: 4 });
            osc633State.unavailable = true;
        };
        const refuseOsc633StartWhenUnavailable = () => {
            const { rows, cols } = cellObserver.baseline;
            const reason = metadataState?.unavailable?.reason ?? savedState?.unavailable?.reason
                ?? (rows < osc133Minimum.rows || cols < osc133Minimum.cols ? 'metadataGeometryUnavailable' : null);
            if (reason === null) return;
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC 633 unavailability reason.');
            recordOsc633Unavailable(reason);
            throw Object.assign(new Error('OSC 633 fixture is unavailable.'), { code: reason });
        };
        /** The OSC 633 suite reuses the paired metadata/status observer under its own prefix and plan; it runs after the left/right-margin suite. */
        const observeOsc633 = async (request, budget) => {
            if (!osc133State?.unavailable && !osc133State?.observer?.restored) throw new Error('OSC 133 suite must restore before OSC 633 observations.');
            osc633State ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: osc633Prefix, includeResolvedColors: true, planOf: osc633ObserverPlan, matchesBaseline: matchesOsc133Baseline }) };
            const state = osc633State;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC 633 fixture ownership or availability changed.');
            if (request.kind === `${osc633Prefix}-start`) refuseOsc633StartWhenUnavailable();
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${osc633Prefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before OSC 633 observations.');
                }
                appendFileSync(join(output, 'vs633-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'vs633-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOsc633Unavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let osc3008State;
        let capsObserver;
        let pclObserver;
        let dclState;
        let dslState;
        const recordOsc3008Unavailable = reason => {
            writeJson(join(output, 'ocx-unavailable.json'), { schemaVersion: 1, runId, suiteId: osc3008SuiteId, status: 'unavailable', reason, plannedCases: 1 });
            osc3008State.unavailable = true;
        };
        const refuseOsc3008StartWhenUnavailable = () => {
            const { rows, cols } = cellObserver.baseline;
            const reason = metadataState?.unavailable?.reason ?? savedState?.unavailable?.reason ?? osc133State?.unavailable?.reason
                ?? (rows < osc133Minimum.rows || cols < osc133Minimum.cols ? 'metadataGeometryUnavailable' : null);
            if (reason === null) return;
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC 3008 unavailability reason.');
            recordOsc3008Unavailable(reason);
            throw Object.assign(new Error('OSC 3008 fixture is unavailable.'), { code: reason });
        };
        /** The OSC 3008 suite reuses the paired metadata/status observer under its own prefix and plan; it runs after the OSC 720 suite. */
        const observeOsc3008 = async (request, budget) => {
            if (!osc5Observer?.restored) throw new Error('Special-color suite must restore before OSC 3008 observations.');
            osc3008State ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: osc3008Prefix, includeResolvedColors: true, planOf: osc3008ObserverPlan, matchesBaseline: matchesOsc3008Baseline }) };
            const state = osc3008State;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC 3008 fixture ownership or availability changed.');
            if (request.kind === `${osc3008Prefix}-start`) refuseOsc3008StartWhenUnavailable();
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${osc3008Prefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before OSC 3008 observations.');
                }
                appendFileSync(join(output, 'ocx-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'ocx-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOsc3008Unavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        /** The feature-reporting suite follows the OSC 3008 suite; a report read also journals the raw reply list bound to its barrier. */
        const observeCaps = async (request, budget) => {
            // The feature-reporting suite binds its own nonce against the pane; it does not depend on the OSC 3008 suite's outcome.
            capsObserver ??= new CapsObserver({ appData, ownerPid: app.pid, profileName,
                nonce: `${capsNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
            const result = await capsObserver.handle(request, budget);
            appendFileSync(join(output, 'caps-snapshots.jsonl'), JSON.stringify(capsObserver.frames.at(-1)) + '\n');
            return result;
        };
        /** The pointer-color suite follows the feature-reporting suite; a report read also journals the raw reply list bound to its barrier. */
        const observePcl = async (request, budget) => {
            pclObserver ??= new PclObserver({ appData, ownerPid: app.pid, profileName,
                nonce: `${pclNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
            const result = await pclObserver.handle(request, budget);
            appendFileSync(join(output, 'pcl-snapshots.jsonl'), JSON.stringify(pclObserver.frames.at(-1)) + '\n');
            return result;
        };
        /** The DECCOLM suite follows the pointer-color suite; a report read also journals the raw reply list bound to its barrier, and every read frame carries the kernel PTY grid the parent reads from the proved private PTY. */
        const observeDcl = async (request, budget) => {
            // The tty is the one the owner socket already proved against the worker for this request; later requests must keep the same worker and PTY.
            dclState ??= { workerPid: request.workerPid, tty: request.tty };
            if (dclState.workerPid !== request.workerPid || dclState.tty !== request.tty) throw new Error('DECCOLM fixture ownership changed.');
            dclState.observer ??= new DclObserver({ appData, ownerPid: app.pid, profileName,
                nonce: `${dclNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId,
                readKernel: remaining => readOwnedOutputMode(dclState.tty, remaining()) });
            const result = await dclState.observer.handle(request, budget);
            appendFileSync(join(output, 'dcl-snapshots.jsonl'), JSON.stringify(dclState.observer.frames.at(-1)) + '\n');
            return result;
        };
        /** The DECSCLM suite follows the DECCOLM suite; every read frame carries the parent's own monotonic timing (the observer's default clock), so unlike the DECCOLM suite no kernel PTY grid is read. */
        const observeDsl = async (request, budget) => {
            // The tty is the one the owner socket already proved against the worker for this request; later requests must keep the same worker and PTY.
            dslState ??= { workerPid: request.workerPid, tty: request.tty };
            if (dslState.workerPid !== request.workerPid || dslState.tty !== request.tty) throw new Error('DECSCLM fixture ownership changed.');
            dslState.observer ??= new DslObserver({ appData, ownerPid: app.pid, profileName,
                nonce: `${dslNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
            const result = await dslState.observer.handle(request, budget);
            appendFileSync(join(output, 'dsl-snapshots.jsonl'), JSON.stringify(dslState.observer.frames.at(-1)) + '\n');
            return result;
        };
        let osc22State;
        const recordOsc22Unavailable = reason => {
            writeJson(join(output, 'ptr-unavailable.json'), { schemaVersion: 1, runId, suiteId: osc22SuiteId, status: 'unavailable', reason, plannedCases: 1 });
            osc22State.unavailable = true;
        };
        const refuseOsc22StartWhenUnavailable = () => {
            const { rows, cols } = cellObserver.baseline;
            const reason = metadataState?.unavailable?.reason ?? savedState?.unavailable?.reason ?? osc133State?.unavailable?.reason
                ?? (rows < osc133Minimum.rows || cols < osc133Minimum.cols ? 'metadataGeometryUnavailable' : null);
            if (reason === null) return;
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC 22 unavailability reason.');
            recordOsc22Unavailable(reason);
            throw Object.assign(new Error('OSC 22 fixture is unavailable.'), { code: reason });
        };
        /** The OSC 22 suite reuses the paired metadata/status observer under its own prefix and plan; it runs after the OSC 720 suite. */
        const observeOsc22 = async (request, budget) => {
            if (!osc720State?.observer.restored && !osc720State?.unavailable) throw new Error('OSC 720 suite must restore before OSC 22 observations.');
            osc22State ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: osc22Prefix, includeResolvedColors: true, planOf: osc22ObserverPlan, matchesBaseline: matchesOsc22Baseline }) };
            const state = osc22State;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC 22 fixture ownership or availability changed.');
            if (request.kind === `${osc22Prefix}-start`) refuseOsc22StartWhenUnavailable();
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${osc22Prefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before OSC 22 observations.');
                }
                appendFileSync(join(output, 'ptr-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'ptr-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOsc22Unavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let osc78State;
        const recordOsc78Unavailable = reason => {
            writeJson(join(output, 'lnk-unavailable.json'), { schemaVersion: 1, runId, suiteId: osc78SuiteId, status: 'unavailable', reason, plannedCases: 2 });
            osc78State.unavailable = true;
        };
        /** The typed refusal of the very first OSC 7/8 observation: an earlier metadata or saved-state refusal, or a grid below the fixture minimum. */
        const osc78StartRefusal = () => {
            const { rows, cols } = cellObserver.baseline;
            const reason = metadataState?.unavailable?.reason ?? savedState?.unavailable?.reason
                ?? (rows < osc78Minimum.rows || cols < osc78Minimum.cols ? 'metadataGeometryUnavailable' : null);
            if (reason === null) return;
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC 7/8 unavailability reason.');
            recordOsc78Unavailable(reason);
            throw Object.assign(new Error('OSC 7/8 fixture is unavailable.'), { code: reason });
        };
        /** Journal the accepted frame; a read also answers with the stored link runs the worker's pinned OSC 8 termless replay reads (the parent re-derives them). */
        const answerOsc78 = (request, result, observer) => {
            const isStart = request.kind === `${osc78Prefix}-start`, frame = observer.frames.at(-1);
            if (isStart && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                throw new Error('Original geometry changed before OSC 7/8 observations.');
            }
            appendFileSync(join(output, 'lnk-snapshots.jsonl'), JSON.stringify(frame) + '\n');
            return request.kind === `${osc78Prefix}-read` ? { ...result, links: structuredClone(frame.before.metadata.buffer.links) } : result;
        };
        /** The OSC 7/8 suite reuses the paired metadata/status observer under its own prefix and plan; it runs after the Core reverse-video/wide-cell suite. */
        const observeOsc78 = async (request, budget) => {
            if (reverseWideObserver?.frames.at(-1)?.kind !== 'rw-finish') throw new Error('Core reverse-video/wide-cell suite must restore before OSC 7/8 observations.');
            osc78State ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: osc78Prefix, includeResolvedColors: true, planOf: osc78ObserverPlan, matchesBaseline: matchesOsc78Baseline }) };
            const state = osc78State;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC 7/8 fixture ownership or availability changed.');
            if (request.kind === `${osc78Prefix}-start`) osc78StartRefusal();
            try {
                return answerOsc78(request, await state.observer.handle(request, budget), state.observer);
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'lnk-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOsc78Unavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let titleStackState;
        const recordTitleStackUnavailable = reason => {
            writeJson(join(output, 'tst-unavailable.json'), { schemaVersion: 1, runId, suiteId: titleStackSuiteId, status: 'unavailable', reason, plannedCases: titleStackCaseIds.length });
            titleStackState.unavailable = true;
        };
        /** Why the title-stack fixture cannot start, or null: the earlier metadata or saved-state suite was unavailable, or the grid is too small. Any other reason is fatal. */
        const titleStackStartReason = () => {
            const { rows, cols } = cellObserver.baseline;
            const reason = metadataState?.unavailable?.reason ?? savedState?.unavailable?.reason
                ?? (rows < titleStackMinimum.rows || cols < titleStackMinimum.cols ? 'metadataGeometryUnavailable' : null);
            if (reason !== null && !['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected title-stack unavailability reason.');
            return reason;
        };
        /** The title-stack suite reuses the paired metadata/status observer under its own prefix and plan; it runs after the OSC 7/8 suite. */
        const observeTitleStack = async (request, budget) => {
            if (!osc78State?.observer?.restored && osc78State?.unavailable !== true) throw new Error('OSC 7/8 suite must restore before title-stack observations.');
            titleStackState ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: titleStackPrefix, includeResolvedColors: true, planOf: titleStackObserverPlan, matchesBaseline: matchesTitleStackBaseline, expose: exposeTitleStackFacts, monotonicHistory: true }) };
            const state = titleStackState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('title-stack fixture ownership or availability changed.');
            if (request.kind === `${titleStackPrefix}-start`) {
                const reason = titleStackStartReason();
                if (reason !== null) {
                    recordTitleStackUnavailable(reason);
                    throw Object.assign(new Error('title-stack fixture is unavailable.'), { code: reason });
                }
            }
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${titleStackPrefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before title-stack observations.');
                }
                appendFileSync(join(output, 'tst-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'tst-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordTitleStackUnavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let oscTitleState;
        const recordOscTitleUnavailable = reason => {
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC title unavailability reason.');
            writeJson(join(output, 'ost-unavailable.json'), { schemaVersion: 1, runId, suiteId: oscTitleSuiteId, status: 'unavailable', reason, plannedCases: oscTitleCaseIds.length });
            oscTitleState.unavailable = true;
        };
        const observeOscTitle = async (request, budget) => {
            const reason = oscTitlePrerequisiteReason(titleStackState?.observer?.restored, titleStackState?.unavailable,
                titleStackState?.unavailable === true ? JSON.parse(readFileSync(join(output, 'tst-unavailable.json'))).reason : null);
            oscTitleState ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: oscTitlePrefix, includeResolvedColors: true, planOf: oscTitleObserverPlan, matchesBaseline: matchesOscTitleBaseline, expose: exposeOscTitleFacts }) };
            const state = oscTitleState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC title fixture ownership or availability changed.');
            if (request.kind === `${oscTitlePrefix}-start` && reason !== null) {
                recordOscTitleUnavailable(reason);
                throw Object.assign(new Error('OSC title fixture is unavailable.'), { code: reason });
            }
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${oscTitlePrefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before OSC title observations.');
                }
                appendFileSync(join(output, 'ost-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'ost-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOscTitleUnavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let osc9State;
        const osc9FocusRecords = [];
        const recordOsc9Unavailable = reason => {
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC 9 unavailability reason.');
            writeJson(join(output, 'osn-unavailable.json'), { schemaVersion: 1, runId, suiteId: osc9SuiteId, status: 'unavailable', reason, plannedCases: osc9CaseIds.length });
            osc9State.unavailable = true;
        };
        /** The parent defocuses (activates Finder) or refocuses the disposable App between observations and retains exactly what it did: the observed window state is the evidence. */
        const performOsc9Action = async (request, budget) => {
            // What is left of this request's shared owner deadline (the lineage checks already spent part of it): the whole action stays inside it.
            const remaining = () => { try { return budget(); } catch { return 0; } };
            const record = await runFocusAction({ action: request.kind.slice(osc9Prefix.length + 1), appPid: app.pid, sleep: ms => new Promise(resolve => setTimeout(resolve, ms)), remaining,
                run: (args, timeout) => spawnSync('/usr/bin/osascript', args, { encoding: 'utf8', timeout }) });
            osc9FocusRecords.push(record);
            writeFileSync(join(output, 'osn-focus.json'), JSON.stringify(osc9FocusRecords, null, 2) + '\n', { mode: 0o600 });
            return record;
        };
        const observeOsc9 = async (request, budget) => {
            // Throws unless the XTGETTCAP suite restored; this suite has no typed-unavailable predecessor, so there is no reason to carry.
            osc9PrerequisiteReason(xtgettcapObserver?.restored, false, null);
            osc9State ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: osc9Prefix, includeResolvedColors: true, planOf: osc9ObserverPlan, matchesBaseline: matchesOsc9Baseline, expose: exposeOsc9Facts }) };
            const state = osc9State;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC 9 fixture ownership or availability changed.');
            if (request.kind === `${osc9Prefix}-defocus` || request.kind === `${osc9Prefix}-refocus`) return performOsc9Action(request, budget);
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${osc9Prefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before OSC 9 observations.');
                }
                appendFileSync(join(output, 'osn-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'osn-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOsc9Unavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let osc720State;
        const osc720ActionRecords = [];
        const recordOsc720Unavailable = reason => {
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected OSC 720 unavailability reason.');
            writeJson(join(output, 'ovu-unavailable.json'), { schemaVersion: 1, runId, suiteId: osc720SuiteId, status: 'unavailable', reason, plannedCases: osc720CaseIds.length });
            osc720State.unavailable = true;
        };
        /** The parent scrolls the disposable App's view up by one routed wheel notch between observations and retains exactly what it did: the observed view position is the evidence. */
        const performOsc720Action = async (request, budget) => {
            let record;
            try {
                record = await runViewAction({ action: request.kind.slice(osc720Prefix.length + 1), budget: () => { try { return budget(); } catch { return 0; } },
                    config: { app, appData, executable, image, profileName, runId, paneId: osc720State.observer.paneId, uid: process.getuid(), workerPid: osc720State.workerPid, workerIdentity, tty: osc720State.tty } });
            } catch (error) {
                // The attempt (request, ownership proofs and the reason, including a dispatched event whose post-action proof failed) is retained even though the owner can only answer with a generic refusal.
                writeJson(join(output, 'ovu-failed-action.json'), { schemaVersion: 1, runId, action: request.kind, error: String(error?.message ?? error), cause: String(error?.cause?.message ?? ''), attempt: error?.inputAttempt ?? null });
                throw error;
            }
            osc720ActionRecords.push(record);
            writeFileSync(join(output, 'ovu-actions.json'), JSON.stringify(osc720ActionRecords, null, 2) + '\n', { mode: 0o600 });
            return record;
        };
        const observeOsc720 = async (request, budget) => {
            // Throws unless the XTGETTCAP suite restored; this suite has no typed-unavailable predecessor, so there is no reason to carry.
            osc720PrerequisiteReason(xtgettcapObserver?.restored, false, null);
            osc720State ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: osc720Prefix, includeResolvedColors: true, planOf: osc720ObserverPlan, matchesBaseline: matchesOsc720Baseline, expose: exposeOsc720Facts, monotonicHistory: true }) };
            const state = osc720State;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('OSC 720 fixture ownership or availability changed.');
            if (osc720ActionKinds.has(request.kind)) return performOsc720Action(request, budget);
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${osc720Prefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before OSC 720 observations.');
                }
                appendFileSync(join(output, 'ovu-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'ovu-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordOsc720Unavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        let notifyState;
        const notifyFocusRecords = [];
        const recordNotifyUnavailable = reason => {
            if (!['screenDetailsUnavailable', 'paneMetadataUnavailable', 'metadataGeometryUnavailable'].includes(reason)) throw new Error('Unexpected notification unavailability reason.');
            writeJson(join(output, 'ntf-unavailable.json'), { schemaVersion: 1, runId, suiteId: notifySuiteId, status: 'unavailable', reason, plannedCases: notifyCaseIds.length });
            notifyState.unavailable = true;
        };
        /** The parent defocuses (activates Finder) or refocuses the disposable App between observations and retains exactly what it did: the observed window state is the evidence. */
        const performNotifyAction = async (request, budget) => {
            const remaining = () => { try { return budget(); } catch { return 0; } };
            const record = await runFocusAction({ action: request.kind.slice(notifyPrefix.length + 1), appPid: app.pid, sleep: ms => new Promise(resolve => setTimeout(resolve, ms)), remaining,
                run: (args, timeout) => spawnSync('/usr/bin/osascript', args, { encoding: 'utf8', timeout }) });
            notifyFocusRecords.push(record);
            writeFileSync(join(output, 'ntf-focus.json'), JSON.stringify(notifyFocusRecords, null, 2) + '\n', { mode: 0o600 });
            return record;
        };
        const observeNotify = async (request, budget) => {
            const reason = notifyPrerequisiteReason(osc9State?.observer?.restored, osc9State?.unavailable === true,
                osc9State?.unavailable === true ? JSON.parse(readFileSync(join(output, 'osn-unavailable.json'))).reason : null);
            notifyState ??= { workerPid: request.workerPid, tty: request.tty,
                observer: new OwnedMetadataObserver({ appData, ownerPid: app.pid, profileName, runId, expectedPaneId: cellObserver.paneId,
                    prefix: notifyPrefix, includeResolvedColors: true, planOf: notifyObserverPlan, matchesBaseline: matchesNotifyBaseline, expose: exposeNotifyFacts }) };
            const state = notifyState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('Notification fixture ownership or availability changed.');
            if (request.kind === `${notifyPrefix}-start` && reason !== null) {
                recordNotifyUnavailable(reason);
                throw Object.assign(new Error('Notification fixture is unavailable.'), { code: reason });
            }
            if (request.kind === `${notifyPrefix}-defocus` || request.kind === `${notifyPrefix}-refocus`) return performNotifyAction(request, budget);
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === `${notifyPrefix}-start` && (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols)) {
                    throw new Error('Original geometry changed before notification observations.');
                }
                appendFileSync(join(output, 'ntf-snapshots.jsonl'), JSON.stringify(state.observer.frames.at(-1)) + '\n');
                return result;
            } catch (error) {
                retainFailedMetadataAttempt(output, request, error, state.observer, 'ntf-failed-observation.json');
                if (initialMetadataRefusal(request, error, state.observer)) recordNotifyUnavailable(error.code);
                throw metadataFailure(request, error, state.observer);
            }
        };
        /** Route owned observations serially, preserving suite restoration and pane identity dependencies. */
        const recordInputUnavailable = reason => {
            const file = 'input-unavailable.json';
            writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: inputSuiteId, status: 'unavailable',
                reason, fixtureStarted: false, plannedExperiments: currentInputPlan.make(24, 100).length });
            inputState.unavailable = { runId, suiteId: inputSuiteId, file, sha256: hash(readFileSync(join(output, file))),
                status: 'unavailable', reason, counts: {} };
        };
        const observeInput = async (request, budget) => {
            if (!metadataState?.observer?.restored && !metadataState?.unavailable) throw new Error('Metadata must restore before input observations.');
            if (!inputState) {
                inputState = { workerPid: request.workerPid, tty: request.tty, recordedFrames: 0, recordedActions: 0 };
                inputState.observer = new OwnedInputObserver({ appData, ownerPid: app.pid, profileName, plan: currentInputPlan,
                    nonce: 'NTILDE_IN_' + runId, expectedPaneId: cellObserver.paneId,
                    performInput: (event, actionBudget) => generateOwnedInput({ app, appData, executable, image, profileName, runId,
                        paneId: inputState.observer.paneId, uid: process.getuid(),
                        workerPid: inputState.workerPid, workerIdentity, tty: inputState.tty }, event, actionBudget) });
                proofs[0].input.actions = inputState.observer.actions;
            }
            const state = inputState;
            if (state.unavailable || state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('Input fixture ownership or availability changed.');
            try {
                const result = await state.observer.handle(request, budget);
                if (request.kind === 'input-start') {
                    if (result.screen.rows !== cellObserver.baseline.rows || result.screen.cols !== cellObserver.baseline.cols) throw new Error('Original geometry changed before input observations.');
                    proofs[0].input.paneId = state.observer.paneId;
                    proofs[0].input.geometry = state.observer.geometry;
                }
                if (request.kind === 'input-seal') proofs[0].input.seal = state.observer.seal;
                return result;
            } catch (error) {
                const initial = request.kind === 'input-start' && ['screenDetailsUnavailable', 'inputGeometryUnavailable'].includes(error.code)
                    && !state.observer.baseline && !state.observer.frames.length && !state.observer.actions.length;
                if (initial) recordInputUnavailable(error.code);
                else if (state.observer.lastAttempt) writeJson(join(output, 'input-failed-observation.json'), state.observer.lastAttempt);
                throw error;
            } finally {
                for (const frame of state.observer.frames.slice(state.recordedFrames)) appendFileSync(join(output, 'input-snapshots.jsonl'), JSON.stringify(frame) + '\n');
                state.recordedFrames = state.observer.frames.length;
                for (const action of state.observer.actions.slice(state.recordedActions)) appendFileSync(join(output, 'input-actions.jsonl'), JSON.stringify(action) + '\n');
                state.recordedActions = state.observer.actions.length;
            }
        };
        const imageEnvironment = { appData, profileName, runId, proofs, deferReport: true, get app() { return app; }, get output() { return output; }, get reference() { return cellObserver; } };
        const observeImageCarrier = (carrier, request, budget, ownership) => observeImageCarrierIn(imageEnvironment, carrier, request, budget, ownership);

        const staticImageCarrier = { label: 'Image', prefix: 'images-', proof: 'staticImages', file: 'image', suiteId: staticImageSuiteId, Observer: OwnedStaticImageObserver,
            captureScale: staticImageCaptureScale,
            pixelDir: 'image-pixels', inputDir: 'image-inputs', planned: { experiments: 5, stages: 23 },
            require: () => requireInputCompletion(inputState), state: () => staticImageState, setState: value => (staticImageState = value),
            priorFrames: () => inputState.observer?.frames ?? [] };
        const animationCarrier = { label: 'Animation', prefix: 'kan-', proof: 'kittyAnimation', file: 'animation', suiteId: animationSuiteId, Observer: OwnedAnimationObserver,
            pixelDir: 'animation-pixels', inputDir: 'animation-inputs', planned: { experiments: animationCases.length, stages: animationPlannedStages },
            require: () => requireStaticImageCompletion(staticImageState), state: () => animationState, setState: value => (animationState = value),
            priorFrames: () => [...(inputState.observer?.frames ?? []), ...(staticImageState.observer?.frames ?? [])] };
        const observeImages = (request, budget, ownership) => observeImageCarrier(staticImageCarrier, request, budget, ownership);
        const observeAnimation = (request, budget, ownership) => observeImageCarrier(animationCarrier, request, budget, ownership);
        const attestQuery = (state, budget) => {
            if (!outputModeVerified || !app?.pid || app.exitCode !== null || app.signalCode !== null)
                throw new Error('Owned query App/output proof is no longer live.');
            const owner = processRecord(app.pid, budget()), worker = processRecord(state.workerPid, budget());
            const appCommand = execFileSync('/bin/ps', ['-p', String(app.pid), '-o', 'command='], { encoding: 'utf8', timeout: budget(), maxBuffer: 16384 });
            const workerCommand = execFileSync('/bin/ps', ['-p', String(worker.pid), '-o', 'command='], { encoding: 'utf8', timeout: budget(), maxBuffer: 16384 });
            assertProcessOwnership({ app: { ...owner, executable: realpathSync(owner.executable) }, worker,
                ownerPid: app.pid, executable, uid: process.getuid(), runId, tty: state.tty, appCommand });
            if (!matchesRecordedWorker(worker, workerIdentity, workerCommand, runId)) throw new Error('Recorded query worker identity or marker changed.');
            return { app: owner, worker, tty: state.tty, appCommand, workerCommand,
                terminalOutput: readOwnedOutputMode(state.tty, budget()), at: new Date().toISOString() };
        };
        const retainQueryJournal = () => {
            if (!queryState?.observer) return;
            const journal = queryState.observer.journal;
            if (journal.initial?.after && !queryState.initialRecorded) {
                writeJson(join(output, 'query-initial.json'), journal.initial); queryState.initialRecorded = true;
            }
            for (const frame of journal.frames.slice(queryState.recordedFrames)) appendFileSync(join(output, 'query-snapshots.jsonl'), JSON.stringify(frame) + '\n');
            queryState.recordedFrames = journal.frames.length;
            for (const action of journal.actions.slice(queryState.recordedActions)) appendFileSync(join(output, 'query-actions.jsonl'), JSON.stringify(action) + '\n');
            queryState.recordedActions = journal.actions.length;
            if (journal.failed && !existsSync(join(output, 'query-failed-observation.json'))) writeJson(join(output, 'query-failed-observation.json'), journal);
        };
        const observeQueries = async (request, budget, owner, worker) => {
            try {
                const payload = { ...request };
                for (const key of ['token', 'runId', 'workerPid', 'tty', 'barrier']) delete payload[key];
                if (request.barrier !== null) throw new Error('Query barriers are retained only in their raw capture.');
                requireInputCompletion(inputState); requireStaticImageCompletion(staticImageState);
                if (inputState.unavailable || staticImageState.unavailable) {
                    if (queryState || request.kind !== 'queries-start' || Object.keys(payload).length !== 1) throw new Error('Query prerequisite refusal must precede all fixture actions.');
                    const file = 'query-unavailable.json';
                    writeJson(join(output, file), { schemaVersion: 1, runId, suiteId: querySuiteId, status: 'unavailable',
                        reason: 'queryPrerequisiteUnavailable', fixtureStarted: false, plannedActions: 44, plannedContracts: 40,
                        observedActions: 0, observedContracts: 0, observedFrames: 0,
                        prerequisites: [['inputEvidence', inputState.unavailable], ['staticImageEvidence', staticImageState.unavailable]]
                            .filter(([, value]) => value).map(([bindingKey, value]) => ({ bindingKey, ...value })) });
                    const unavailable = { runId, suiteId: querySuiteId, file, sha256: hash(readFileSync(join(output, file))),
                        status: 'unavailable', reason: 'queryPrerequisiteUnavailable', counts: {} };
                    queryState = { unavailable };
                    return { status: unavailable.status, reason: unavailable.reason };
                }
                if (!queryState) {
                    if (request.kind !== 'queries-start') throw new Error('Query fixture must start before admission.');
                    const priorChallenges = [...inputState.observer.frames, ...staticImageState.observer.frames]
                        .filter(frame => frame.capture).map(frame => frame.capture.nonces.join(','));
                    if (!queryPriorCounts.includes(priorChallenges.length)) throw new Error('Incomplete earlier query challenges.');
                    queryState = { workerPid: worker.pid, tty: request.tty, recordedFrames: 0, recordedActions: 0 };
                    const binding = { runId, ownerPid: owner.pid, workerPid: worker.pid, uid: worker.uid,
                        appExecutable: owner.executable, workerExecutable: worker.executable, tty: request.tty, profileName, paneId: cellObserver.paneId };
                    queryState.observer = new OwnedQueryObserver({ binding, appData, priorChallenges, checksumReport: settings.AllowRectangleChecksumReport === true, marginsReport: true, noticeReport: true, deviceReport: true, colorReport: true, specialColorReport: true, capabilitiesReport: true, attest: remaining => attestQuery(queryState, remaining) });
                    proofs[0].queries.binding = binding;
                }
                if (queryState.workerPid !== request.workerPid || queryState.tty !== request.tty) throw new Error('Query fixture ownership changed.');
                const result = await queryState.observer.handle(payload, budget);
                const journal = queryState.observer.journal;
                proofs[0].queries.actions = journal.actions;
                if (journal.seal) proofs[0].queries.seal = journal.seal;
                return result;
            } catch (error) { queryState?.observer?.abort(error); throw error; }
            finally { retainQueryJournal(); }
        };
        /** Persist expected-only controller/state facts and bounded failures, without the owner capability. */
        const retainPrivateClipboardJournal = () => {
            if (!privateClipboardState?.observer) return;
            // The expected-only journal contains synthetic seed/nonce values, never arbitrary clipboard data.
            writeFileSync(join(output, 'private-clipboard-journal.json'), privateClipboardEvidenceJson({ ...privateClipboardState.observer.journal, ...(privateClipboardState.failures?.length ? { failures: privateClipboardState.failures, failureFactsTruncated: privateClipboardState.failureFactsTruncated === true } : {}) }), { mode: 0o600 });
        };
        /** Independently reread live process, source, binary, PTY and birth facts inside one shared event budget. */
        const attestPrivateClipboard = (state, budget) => {
            const fact = attestQuery(state, budget);
            assertExecutableUnchanged(executable, image);
            assertOwnedSourcesUnchanged(sourceRepo, context); budget();
            const executableSha256 = hash(readFileSync(executable)); budget();
            const assemblySha256 = context.assemblySha256 === null ? null : hash(readFileSync(join(dirname(executable), 'Ntilde.dll'))); budget();
            return { ...fact, app: { ...fact.app, birth: processBirth(fact.app.pid, budget()) },
                worker: { ...fact.worker, birth: processBirth(fact.worker.pid, budget()) },
                executableSha256, assemblySha256, sourceSnapshotManifestSha256: snapshot.sha256, outputDevice: outputDevice(state.tty) };
        };
        /** Lazily admit Q11 only after the query seal; route the fixed parent API and retain only a closed full report. */
        const observePrivateClipboard = async (request, budget, owner, worker) => {
            try {
                if (Object.keys(request).length !== 6 || !Object.hasOwn(request, 'frame')) throw new Error('Invalid private clipboard owner envelope.');
                requireQueryCompletion(queryState);
                if (queryState.unavailable) throw new Error('Private clipboard requires all sixteen completed prefix suites.');
                if (!privateClipboardState) {
                    if (request.frame?.kind !== 'start') throw new Error('Private clipboard must start at its original Q11 callback.');
                    const first = proofs[0].privateClipboard;
                    privateClipboardState = { workerPid: worker.pid, tty: request.tty };
                    const binding = { runId, ownerPid: owner.pid, workerPid: worker.pid, uid: worker.uid,
                        appExecutable: owner.executable, workerExecutable: worker.executable, tty: request.tty, profileName, paneId: cellObserver.paneId,
                        sourceSnapshotManifestSha256: snapshot.sha256, executableSha256: context.executableSha256, assemblySha256: context.assemblySha256,
                        appBirth: first.appBirth, workerBirth: first.workerBirth, outputDevice: first.outputDevice };
                    const reader = new OwnedCellObserver({ appData, ownerPid: owner.pid, profileName, expectedPaneId: binding.paneId,
                        includeCellDetails: true, includeCursorMode: true, includeOverline: true, includeBufferState: true });
                    privateClipboardState.observer = new OwnedPrivateClipboardObserver({ binding, appData,
                        attest: remaining => attestPrivateClipboard(privateClipboardState, remaining),
                        capture: async remaining => privateClipboardScreen(await reader.capture(remaining)) });
                    first.binding = binding;
                }
                if (privateClipboardState.workerPid !== worker.pid || privateClipboardState.tty !== request.tty) throw new Error('Private clipboard worker changed.');
                const result = await privateClipboardState.observer.handle(request.frame, budget);
                if (request.frame.kind !== 'finish') return result;
                const report = privateClipboardState.observer.report, file = 'private-clipboard-observations.json';
                writeFileSync(join(output, file), privateClipboardEvidenceJson(report), { mode: 0o600 });
                privateClipboardEvidence = { runId, suiteId: ownedPrivateClipboardSuiteId, file,
                    sha256: hash(readFileSync(join(output, file))), counts: { completedProbes: 3, acceptedWrites: 2 }, complete: true };
                return privateClipboardEvidence;
            } catch (error) { rejectDone(error); throw error; }
            finally { retainPrivateClipboardJournal(); }
        };
        const observeCells = async (request, budget) => {
            const prefix = request.kind.split('-')[0];
            if (isOsc633Scope(collectionScope) && [osc9Prefix, notifyPrefix].includes(prefix)) throw new Error('Notification observations are outside this collection scope.');
            if (!isOsc633Scope(collectionScope) && prefix === osc633Prefix) throw new Error('OSC 633 observations are outside this collection scope.');
            if (prefix === 'input') return observeInput(request, budget);
            if (prefix === 'resize') return observeResize(request, budget);
            if (prefix === 'saved') return observeSaved(request, budget);
            if (prefix === 'metadata') return observeMetadata(request, budget);
            if (prefix === 'reflow') return observeReflow(request, budget);
            if (prefix === osc133Prefix) return observeOsc133(request, budget);
            if (prefix === osc633Prefix) return observeOsc633(request, budget);
            if (prefix === osc3008Prefix) return observeOsc3008(request, budget);
            if (prefix === capsPrefix) return observeCaps(request, budget);
            if (prefix === pclPrefix) return observePcl(request, budget);
            if (prefix === dclPrefix) return observeDcl(request, budget);
            if (prefix === dslPrefix) return observeDsl(request, budget);
            if (prefix === osc22Prefix) return observeOsc22(request, budget);
            if (prefix === osc78Prefix) return observeOsc78(request, budget);
            if (prefix === titleStackPrefix) return observeTitleStack(request, budget);
            if (prefix === oscTitlePrefix) return observeOscTitle(request, budget);
            if (prefix === osc9Prefix) return observeOsc9(request, budget);
            if (prefix === osc720Prefix) return observeOsc720(request, budget);
            if (prefix === notifyPrefix) return observeNotify(request, budget);
            if (prefix === 'pixel') return observePixels(request, budget);
            if (prefix === 'color') return observeColors(request, budget);
            if (Object.hasOwn(editingSpecs, prefix)) return observeEditing(prefix, request, budget);
            if (Object.hasOwn(detailSpecs, prefix)) return observeDetails(prefix, request, budget);
            if (prefix === 'grading') {
                // The graded suite runs after the attribute-reading SGR suite.
                if (!sgrObserver?.restored) throw new Error('SGR suite must restore before grading observations.');
                gradingObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_AG_${runId}`, includeAttributes: true, prefix: 'grading', expectedPaneId: cellObserver.paneId });
                const result = await gradingObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'grading-snapshots.jsonl'), JSON.stringify(gradingObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgcolors') {
                // The layered suite runs after the first graded suite.
                if (!gradingObserver?.restored) throw new Error('Grading suite must restore before SGR-colors observations.');
                sgrColorsObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SC_${runId}`, includeAttributes: true, prefix: 'sgcolors', expectedPaneId: cellObserver.paneId });
                const result = await sgrColorsObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgcolors-snapshots.jsonl'), JSON.stringify(sgrColorsObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgrgb') {
                // The RGB suite runs after the SGR-colors suite: its conclusions sit
                // beside the stored-index ones, never replace them.
                if (!sgrColorsObserver?.restored) throw new Error('SGR-colors suite must restore before SGR-RGB observations.');
                sgrRgbObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SR_${runId}`, includeAttributes: true, includeCellDetails: true,
                    includeResolvedColors: true, prefix: 'sgrgb', expectedPaneId: cellObserver.paneId });
                const result = await sgrRgbObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgrgb-snapshots.jsonl'), JSON.stringify(sgrRgbObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgattr') {
                // The attributes suite runs after the SGR-RGB suite: it adds stored
                // attribute conclusions beside the color ones, never replaces them.
                if (!sgrRgbObserver?.restored) throw new Error('SGR-RGB suite must restore before SGR-attribute observations.');
                sgrAttrsObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SA_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sgattr', expectedPaneId: cellObserver.paneId });
                const result = await sgrAttrsObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgattr-snapshots.jsonl'), JSON.stringify(sgrAttrsObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgpal') {
                // The palette suite runs after the SGR-attributes suite: it adds stored and
                // resolved palette conclusions beside the earlier ones, never replaces them.
                if (!sgrAttrsObserver?.restored) throw new Error('SGR-attribute suite must restore before SGR-palette observations.');
                sgrPaletteObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SP_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sgpal', expectedPaneId: cellObserver.paneId });
                const result = await sgrPaletteObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgpal-snapshots.jsonl'), JSON.stringify(sgrPaletteObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgtc') {
                // The truecolor suite runs after the SGR-palette suite and adds its conclusions beside the earlier ones.
                if (!sgrPaletteObserver?.restored) throw new Error('SGR-palette suite must restore before SGR-truecolor observations.');
                sgrTruecolorObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_ST_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sgtc', expectedPaneId: cellObserver.paneId });
                const result = await sgrTruecolorObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgtc-snapshots.jsonl'), JSON.stringify(sgrTruecolorObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgtf') {
                // The finding suite runs after the SGR-truecolor suite and adds its conclusions beside the earlier ones.
                if (!sgrTruecolorObserver?.restored) throw new Error('SGR-truecolor suite must restore before truecolor-finding observations.');
                truecolorFindingObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_TF_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sgtf', expectedPaneId: cellObserver.paneId });
                const result = await truecolorFindingObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgtf-snapshots.jsonl'), JSON.stringify(truecolorFindingObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgus') {
                // The underline-style suite runs after the truecolor-finding suite and adds its conclusions beside the earlier ones.
                if (!truecolorFindingObserver?.restored) throw new Error('Truecolor-finding suite must restore before SGR-underline observations.');
                sgrUnderlineObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SU_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sgus', expectedPaneId: cellObserver.paneId });
                const result = await sgrUnderlineObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgus-snapshots.jsonl'), JSON.stringify(sgrUnderlineObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sguc') {
                // The underline-color suite runs after the underline-style suite and adds its conclusions beside the earlier ones.
                if (!sgrUnderlineObserver?.restored) throw new Error('SGR-underline suite must restore before SGR-underline-color observations.');
                sgrUnderlineColorObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_UC_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sguc', expectedPaneId: cellObserver.paneId });
                const result = await sgrUnderlineColorObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sguc-snapshots.jsonl'), JSON.stringify(sgrUnderlineColorObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgur') {
                // The App-observed underline-resolution suite runs after the underline-color suite and adds its conclusions beside the earlier ones.
                if (!sgrUnderlineColorObserver?.restored) throw new Error('SGR-underline-color suite must restore before underline-resolution observations.');
                underlineResolvedObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_UR_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, includeResolvedUnderlineColors: true, prefix: 'sgur', expectedPaneId: cellObserver.paneId });
                const result = await underlineResolvedObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgur-snapshots.jsonl'), JSON.stringify(underlineResolvedObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgsr') {
                // The selective-reset suite runs after the underline-resolution suite and adds its conclusions beside the earlier ones.
                if (!underlineResolvedObserver?.restored) throw new Error('Underline-resolution suite must restore before SGR selective-reset observations.');
                sgrResetObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SR_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sgsr', expectedPaneId: cellObserver.paneId });
                const result = await sgrResetObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgsr-snapshots.jsonl'), JSON.stringify(sgrResetObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sgcl') {
                // The closure suite runs after the selective-reset suite and adds its conclusions beside the earlier ones.
                if (!sgrResetObserver?.restored) throw new Error('SGR selective-reset suite must restore before SGR closure observations.');
                sgrClosureObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CL_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'sgcl', expectedPaneId: cellObserver.paneId });
                const result = await sgrClosureObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sgcl-snapshots.jsonl'), JSON.stringify(sgrClosureObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'erln') {
                // The erase-in-line suite runs after the SGR closure suite and adds its conclusions beside the earlier ones.
                if (!sgrClosureObserver?.restored) throw new Error('SGR SGR closure suite must restore before erase-in-line observations.');
                eraseLineObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_EL_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'erln', expectedPaneId: cellObserver.paneId });
                const result = await eraseLineObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'erln-snapshots.jsonl'), JSON.stringify(eraseLineObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'ched') {
                // The character-editing suite runs after the erase-in-line suite and adds its conclusions beside the earlier ones.
                if (!eraseLineObserver?.restored) throw new Error('Erase-in-line suite must restore before character-editing observations.');
                charEditObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CE_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, prefix: 'ched', expectedPaneId: cellObserver.paneId });
                const result = await charEditObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'ched-snapshots.jsonl'), JSON.stringify(charEditObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'erdi') {
                // The erase-in-display suite runs after the character-editing suite and adds its conclusions beside the earlier ones.
                if (!charEditObserver?.restored) throw new Error('Character-editing suite must restore before erase-in-display observations.');
                eraseDisplayObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_ED_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, prefix: 'erdi', expectedPaneId: cellObserver.paneId });
                const result = await eraseDisplayObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'erdi-snapshots.jsonl'), JSON.stringify(eraseDisplayObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'ledt') {
                // The line-editing suite runs after the erase-in-display suite and adds its conclusions beside the earlier ones.
                if (!eraseDisplayObserver?.restored) throw new Error('The erase-in-display suite must restore before line-editing observations.');
                lineEditObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_LE_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, includeBufferState: true, prefix: 'ledt', expectedPaneId: cellObserver.paneId });
                const result = await lineEditObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'ledt-snapshots.jsonl'), JSON.stringify(lineEditObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'irm') {
                if (!lineEditObserver?.restored) throw new Error('Line-editing suite must restore before IRM observations.');
                insertReplaceObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: insertReplaceNoncePrefix + runId, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, includeBufferState: true, includeHorizontalMargins: true, prefix: 'irm', expectedPaneId: cellObserver.paneId });
                const result = await insertReplaceObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'irm-snapshots.jsonl'), JSON.stringify(insertReplaceObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'chrs') {
                // The charsets suite runs after the line-editing suite. It requests stored cell details only: attribute
                // strings omit wide-continuation cells and would refuse any row holding a wide character.
                if (!insertReplaceObserver?.restored) throw new Error('IRM suite must restore before charset observations.');
                charsetsObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CS_${runId}`, includeCellDetails: true, prefix: 'chrs', expectedPaneId: cellObserver.paneId });
                const result = await charsetsObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'chrs-snapshots.jsonl'), JSON.stringify(charsetsObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'scrl') {
                // The scrolling/history suite runs after the charsets suite on the main screen and reads buffer state and actual history.
                if (!charsetsObserver?.restored) throw new Error('Charsets suite must restore before scrolling/history observations.');
                scrollbackObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SB_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeResolvedColors: true, includeBufferState: true, prefix: 'scrl', expectedPaneId: cellObserver.paneId });
                const result = await scrollbackObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'scrl-snapshots.jsonl'), JSON.stringify(scrollbackObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'svrs') {
                // The saved-state/reset suite runs after the scrolling/history suite and adds its conclusions beside the earlier ones.
                if (!scrollbackObserver?.restored) throw new Error('Scrolling/history suite must restore before saved-state/reset observations.');
                savedResetObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SR_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, prefix: 'svrs', expectedPaneId: cellObserver.paneId });
                const result = await savedResetObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'svrs-snapshots.jsonl'), JSON.stringify(savedResetObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'erar') {
                // The erase attributes / erase margins suite runs after the saved-state/reset suite and adds its conclusions beside the earlier ones.
                if (!savedResetObserver?.restored) throw new Error('Saved-state/reset suite must restore before erase-attributes observations.');
                eraseAttrsRegionObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_EA_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, prefix: 'erar', expectedPaneId: cellObserver.paneId });
                const result = await eraseAttrsRegionObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'erar-snapshots.jsonl'), JSON.stringify(eraseAttrsRegionObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'atrc') {
                // The attribute-rectangle suite runs after the erase attributes / erase margins suite and adds its conclusions beside the earlier ones.
                if (!eraseAttrsRegionObserver?.restored) throw new Error('Erase attributes / erase margins suite must restore before attribute-rectangle observations.');
                attrRectObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_AR_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, prefix: 'atrc', expectedPaneId: cellObserver.paneId });
                const result = await attrRectObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'atrc-snapshots.jsonl'), JSON.stringify(attrRectObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'curq') {
                // The cursor suite runs after the attribute-rectangle suite on the alternate screen and adds its conclusions beside the earlier ones.
                if (!attrRectObserver?.restored) throw new Error('Attribute-rectangle suite must restore before cursor observations.');
                cursorQualObserver ??= new CursorQualObserver({ output, appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CQ_${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await cursorQualObserver.handle(request, budget);
                appendFileSync(join(output, 'curq-snapshots.jsonl'), JSON.stringify(cursorQualObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'echh') {
                // The erase-character/saved-lines suite runs after the cursor-qualification suite and adds its conclusions beside the earlier ones.
                if (!cursorQualObserver?.restored) throw new Error('Cursor-qualification suite must restore before erase-character/saved-lines observations.');
                eraseCharsHistoryObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_EH_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, prefix: 'echh', expectedPaneId: cellObserver.paneId });
                const result = await eraseCharsHistoryObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'echh-snapshots.jsonl'), JSON.stringify(eraseCharsHistoryObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sels') {
                // The selective-erasure suite runs after the erase-character/saved-lines suite and adds its conclusions beside the earlier ones.
                if (!eraseCharsHistoryObserver?.restored) throw new Error('Erase-character/saved-lines suite must restore before selective-erasure observations.');
                selectiveEraseObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SE_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, includeProtection: true, prefix: 'sels', expectedPaneId: cellObserver.paneId });
                const result = await selectiveEraseObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'sels-snapshots.jsonl'), JSON.stringify(selectiveEraseObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'rect') {
                // The rectangle-editing suite runs after the selective-erasure suite and adds its conclusions beside the earlier ones.
                if (!selectiveEraseObserver?.restored) throw new Error('Selective-erasure suite must restore before rectangle-editing observations.');
                rectEditObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_RC_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, prefix: 'rect', expectedPaneId: cellObserver.paneId });
                const result = await rectEditObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'rect-snapshots.jsonl'), JSON.stringify(rectEditObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'cole') {
                // The column-editing suite runs after the rectangle-editing suite and adds its conclusions beside the earlier ones.
                if (!rectEditObserver?.restored) throw new Error('Rectangle-editing suite must restore before column-editing observations.');
                colEditObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CE_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, includeProtection: true, prefix: 'cole', expectedPaneId: cellObserver.paneId });
                const result = await colEditObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'cole-snapshots.jsonl'), JSON.stringify(colEditObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'csum') {
                // The rectangle-checksum suite runs after the column-editing suite; a report read also journals the raw reply bound to its barrier.
                if (!colEditObserver?.restored) throw new Error('Column-editing suite must restore before rectangle-checksum observations.');
                rectChecksumObserver ??= new RectChecksumObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CK_${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await rectChecksumObserver.handle(request, budget);
                appendFileSync(join(output, 'csum-snapshots.jsonl'), JSON.stringify(rectChecksumObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'xgtc') {
                // The XTGETTCAP suite runs after the OSC title suite; a report read also journals the raw reply list bound to its barrier.
                if (!oscTitleState?.observer?.restored && oscTitleState?.unavailable !== true) throw new Error('OSC title suite must restore before XTGETTCAP observations.');
                xtgettcapObserver ??= new XtgettcapObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_XG_${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await xtgettcapObserver.handle(request, budget);
                appendFileSync(join(output, 'xgtc-snapshots.jsonl'), JSON.stringify(xtgettcapObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === devqPrefix) {
                // The device-query suite runs after the notification suite; a report read also journals the raw reply list bound to its barrier.
                if (isOsc633Scope(collectionScope) ? !xtgettcapObserver?.restored : (!notifyState?.observer?.restored && notifyState?.unavailable !== true)) {
                    throw new Error('The preceding selected suite must restore before device-query observations.');
                }
                devqObserver ??= new DevqObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `${devqNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await devqObserver.handle(request, budget);
                appendFileSync(join(output, 'dvq-snapshots.jsonl'), JSON.stringify(devqObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === cellSizePrefix) {
                if (!devqObserver?.restored) throw new Error('Device-query suite must restore before cell-size observations.');
                cellSizeObserver ??= new CellSizeObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `${cellSizeNonce}${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await cellSizeObserver.handle(request, budget);
                appendFileSync(join(output, 'cell-size-snapshots.jsonl'), JSON.stringify(cellSizeObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === fontSizePrefix) {
                if (!cellSizeObserver?.restored) throw new Error('Cell-size suite must restore before font-size observations.');
                fontSizeObserver ??= new FontSizeObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `${fontSizeNonce}${runId}`, expectedPaneId: cellObserver.paneId });
                try {
                    const result = await fontSizeObserver.handle(request, budget);
                    appendFileSync(join(output, 'font-size-snapshots.jsonl'), JSON.stringify(fontSizeObserver.frames.at(-1)) + '\n');
                    return result;
                } catch (error) {
                    if (fontSizeObserver.lastAttempt?.error)
                        appendFileSync(join(output, 'font-size-failed-observations.jsonl'), JSON.stringify(fontSizeObserver.lastAttempt) + '\n');
                    throw error;
                }
            }
            if (prefix === xcsPrefix) {
                // The xterm color-stack suite runs after the device-query suite; a report read also journals the raw reply list bound to its barrier.
                if (!fontSizeObserver?.restored) throw new Error('Font-size suite must restore before xterm color-stack observations.');
                xcsObserver ??= new XcsObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `${xcsNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await xcsObserver.handle(request, budget);
                appendFileSync(join(output, 'xcs-snapshots.jsonl'), JSON.stringify(xcsObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === xssPrefix) {
                // The xterm SGR-stack suite runs after the color-stack suite; a report read also journals the raw reply list bound to its barrier.
                if (!xcsObserver?.restored) throw new Error('Xterm color-stack suite must restore before xterm SGR-stack observations.');
                xssObserver ??= new XssObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `${xssNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await xssObserver.handle(request, budget);
                appendFileSync(join(output, 'xss-snapshots.jsonl'), JSON.stringify(xssObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === xsvPrefix) {
                // The xterm saved-mode suite runs after the SGR-stack suite; a report read also journals the raw reply list bound to its barrier.
                if (!xssObserver?.restored) throw new Error('Xterm SGR-stack suite must restore before xterm saved-mode observations.');
                xsvObserver ??= new XsvObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `${xsvNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await xsvObserver.handle(request, budget);
                appendFileSync(join(output, 'xsv-snapshots.jsonl'), JSON.stringify(xsvObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === kclPrefix) {
                // The kitty color-control suite runs after the saved-mode suite; a report read also journals the raw reply list bound to its barrier.
                if (!xsvObserver?.restored) throw new Error('Xterm saved-mode suite must restore before kitty color-control observations.');
                kclObserver ??= new KclObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `${kclNoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await kclObserver.handle(request, budget);
                appendFileSync(join(output, 'kcl-snapshots.jsonl'), JSON.stringify(kclObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === osc5Prefix) {
                // The special-color suite runs after the kitty color-control suite; a report read also journals the raw reply list bound to its barrier.
                if (!kclObserver?.restored) throw new Error('Kitty color-control suite must restore before special-color observations.');
                osc5Observer ??= new Osc5Observer({ appData, ownerPid: app.pid, profileName,
                    nonce: `${osc5NoncePrefix}${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await osc5Observer.handle(request, budget);
                appendFileSync(join(output, 'osc5-snapshots.jsonl'), JSON.stringify(osc5Observer.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'sr') {
                // The SGR raster suite follows the Core wrap suite, which has restored the original geometry; its reads bracket a controlled render and carry the exact DECRQSS replies.
                if (!coreWrapState?.observer.restored) throw new Error('Core wrap must restore before Core SGR raster observations.');
                sgrRasterObserver ??= new SgrRasterObserver({ output, appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SR_${runId}`, expectedPaneId: cellObserver.paneId });
                try {
                    const result = await sgrRasterObserver.handleRequest(request, budget);
                    appendFileSync(join(output, 'sr-snapshots.jsonl'), JSON.stringify(sgrRasterObserver.frames.at(-1)) + '\n');
                    return result;
                } catch (error) {
                    writeFileSync(join(output, 'sr-failed-observation.json'), JSON.stringify({ error: String(error) }) + '\n');
                    throw error;
                }
            }
            if (prefix === 'rw') {
                if (!sgrRasterObserver?.restored) throw new Error('Core SGR raster must restore before Core reverse-video and wide-cell observations.');
                reverseWideObserver ??= new ReverseWideObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_RW_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, includeHorizontalMargins: true,
                    prefix: 'rw', expectedPaneId: cellObserver.paneId });
                try {
                    const result = await reverseWideObserver.handleRequest(request, budget);
                    appendFileSync(join(output, 'rw-snapshots.jsonl'), JSON.stringify(reverseWideObserver.frames.at(-1)) + '\n');
                    return result;
                } catch (error) {
                    writeFileSync(join(output, 'rw-failed-observation.json'), JSON.stringify({ attempt: reverseWideObserver.lastAttempt, error: String(error) }) + '\n');
                    throw error;
                }
            }
            if (prefix === 'cw') {
                if (!tabStopsObserver?.restored) throw new Error('Core tab stops must restore before Core wrap.');
                if (!coreWrapState) {
                    if (request.kind !== 'cw-geometry-start') throw new Error('Core wrap must start at original geometry.');
                    coreWrapState = { workerPid: request.workerPid, tty: request.tty, recordedFrames: 0 };
                    coreWrapState.observer = new WrapObserver({ appData, ownerPid: app.pid, profileName, runId,
                        expectedPaneId: cellObserver.paneId, expectedOriginal: { rows: cellObserver.baseline.rows, cols: cellObserver.baseline.cols },
                        performResize: (rows, cols, actionBudget) => resizeOwnedPane({ app, appData, executable, runId,
                            paneId: coreWrapState.observer.paneId, uid: process.getuid(),
                            workerPid: coreWrapState.workerPid, tty: coreWrapState.tty }, rows, cols, actionBudget) });
                }
                const state = coreWrapState;
                if (state.workerPid !== request.workerPid || state.tty !== request.tty) throw new Error('Core wrap worker changed.');
                try {
                    const result = await state.observer.handle(request, budget);
                    if (request.kind === 'cw-seal') {
                        const o = state.observer;
                        const geometry = { paneId: o.paneId, original: o.original, before: o.before, after: o.after, actions: o.actions };
                        proofs[0].coreWrap = geometry; writeJson(join(output, 'cw-geometry.json'), geometry);
                    }
                    return result;
                } finally {
                    for (const frame of state.observer.frames.slice(state.recordedFrames)) {
                        appendFileSync(join(output, 'cw-snapshots.jsonl'), JSON.stringify(frame) + '\n'); state.recordedFrames++;
                    }
                    writeFileSync(join(output, 'cw-progress.json'), JSON.stringify({ phase: state.observer.phase, actions: state.observer.actions,
                        before: state.observer.before, after: state.observer.after, lastAttempt: state.observer.reader.lastAttempt }) + '\n', { mode: 0o600 });
                }
            }
            if (prefix === 'ts') {
                if (!coreEraseObserver?.restored) throw new Error('Core erase must restore before Core tab-stop observations.');
                tabStopsObserver ??= new TabStopsObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_TS_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, includeHorizontalMargins: true,
                    prefix: 'ts', expectedPaneId: cellObserver.paneId });
                try {
                    const result = await tabStopsObserver.handleRequest(request, budget);
                    appendFileSync(join(output, 'ts-snapshots.jsonl'), JSON.stringify(tabStopsObserver.frames.at(-1)) + '\n');
                    return result;
                } catch (error) {
                    writeFileSync(join(output, 'ts-failed-observation.json'), JSON.stringify({ attempt: tabStopsObserver.lastAttempt, error: String(error) }) + '\n');
                    throw error;
                }
            }
            if (prefix === 'ce') {
                if (!textCursorObserver?.restored) throw new Error('Text/cursor suite must restore before Core erase.');
                coreEraseObserver ??= new EraseObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CE_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, includeHorizontalMargins: true,
                    prefix: 'ce', expectedPaneId: cellObserver.paneId });
                try {
                    const result = await coreEraseObserver.handleRequest(request, budget);
                    appendFileSync(join(output, 'ce-snapshots.jsonl'), JSON.stringify(coreEraseObserver.frames.at(-1)) + '\n');
                    return result;
                } catch (error) {
                    writeFileSync(join(output, 'ce-failed-observation.json'), JSON.stringify({ attempt: coreEraseObserver.lastAttempt, error: String(error) }) + '\n');
                    throw error;
                }
            }
            if (prefix === modernCursorPrefix) {
                if (!textCursorObserver?.restored) throw new Error('Text/cursor suite must restore before Modern cursor observations.');
                modernCursorObserver ??= new ModernCursorObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: modernCursorNonce + runId, includeBufferState: true, includeHorizontalMargins: true,
                    prefix: modernCursorPrefix, expectedPaneId: cellObserver.paneId });
                try {
                    const result = await modernCursorObserver.handleRequest(request, budget);
                    appendFileSync(join(output, 'mcur-snapshots.jsonl'), JSON.stringify(modernCursorObserver.frames.at(-1)) + '\n', { mode: 0o600 });
                    return result;
                } catch (error) {
                    appendFileSync(join(output, 'mcur-failed-observations.jsonl'),
                        JSON.stringify({ kind: request.kind, request: request.requestBytes, response: request.response,
                            attempt: modernCursorObserver.lastAttempt, error: String(error) }) + '\n', { mode: 0o600 });
                    throw error;
                }
            }
            if (prefix === 'mmod') {
                if (!modernCursorObserver?.restored) throw new Error('Modern cursor suite must restore before mode observations.');
                modernModesObserver ??= new ModernModesObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: modernModesNonce + runId, includeBufferState: true, prefix: 'mmod', expectedPaneId: cellObserver.paneId });
                try {
                    const result = await modernModesObserver.handleRequest(request, budget);
                    appendFileSync(join(output, 'mmod-snapshots.jsonl'), JSON.stringify(modernModesObserver.frames.at(-1)) + '\n', { mode: 0o600 });
                    return result;
                } catch (error) {
                    appendFileSync(join(output, 'mmod-failed-observations.jsonl'),
                        JSON.stringify({ kind: request.kind, request: request.requestBytes, response: request.response,
                            error: String(error) }) + '\n', { mode: 0o600 });
                    throw error;
                }
            }
            if (prefix === 'tc') {
                if (!coreGapsObserver?.restored || !colorResetObserver?.restored) throw new Error('Core gaps and color reset must restore before text/cursor observations.');
                textCursorObserver ??= new TextCursorObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_TC_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, includeHorizontalMargins: true,
                    prefix: 'tc', expectedPaneId: cellObserver.paneId });
                try {
                    const result = await textCursorObserver.handleRequest(request, budget);
                    appendFileSync(join(output, 'tc-snapshots.jsonl'), JSON.stringify(textCursorObserver.frames.at(-1)) + '\n');
                    return result;
                } catch (error) {
                    writeFileSync(join(output, 'tc-failed-observation.json'), JSON.stringify({ attempt: textCursorObserver.lastAttempt, error: String(error) }) + '\n');
                    throw error;
                }
            }
            if (prefix === 'cg') {
                if (!lrMarginsObserver?.restored) throw new Error('Margins suite must restore before Core gaps.');
                coreGapsObserver ??= new CoreGapsObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CG_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, prefix: 'cg', expectedPaneId: cellObserver.paneId });
                try {
                    const result = await coreGapsObserver.handle(request.kind, budget, request.barrier);
                    appendFileSync(join(output, 'cg-snapshots.jsonl'), JSON.stringify(coreGapsObserver.frames.at(-1)) + '\n');
                    return result;
                } catch (error) {
                    writeFileSync(join(output, 'cg-failed-observation.json'), JSON.stringify({ attempt: coreGapsObserver.lastAttempt, error: String(error) }) + '\n');
                    throw error;
                }
            }
            if (prefix === 'lrmm') {
                // The left/right-margin suite runs after the rectangle-checksum suite; its reads also keep the App's stored horizontal margins.
                if (!rectChecksumObserver?.restored) throw new Error('Rectangle-checksum suite must restore before left/right-margin observations.');
                lrMarginsObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_LM_${runId}`, includeAttributes: true, includeCellDetails: true, includeOverline: true,
                    includeBufferState: true, includeResolvedColors: true, includeProtection: true, includeHorizontalMargins: true, prefix: 'lrmm', expectedPaneId: cellObserver.paneId });
                const result = await lrMarginsObserver.handle(request.kind, budget, request.barrier);
                appendFileSync(join(output, 'lrmm-snapshots.jsonl'), JSON.stringify(lrMarginsObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'crst') {
                // The runtime-color reset suite runs after the left/right-margin suite; its reads also bracket a controlled render and carry the exact query replies.
                if (!lrMarginsObserver?.restored) throw new Error('Left/right-margin suite must restore before runtime-color reset observations.');
                colorResetObserver ??= new ColorResetObserver({ output, appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_CR_${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await colorResetObserver.handle(request, budget);
                appendFileSync(join(output, 'crst-snapshots.jsonl'), JSON.stringify(colorResetObserver.frames.at(-1)) + '\n');
                return result;
            }
            if (prefix === 'selc') {
                selectionColorsObserver ??= new SelectionColorsObserver({ output, appData, ownerPid: app.pid, profileName,
                    nonce: `NTILDE_SL_${runId}`, expectedPaneId: cellObserver.paneId });
                const result = await selectionColorsObserver.handle(request, budget);
                appendFileSync(join(output, 'selc-snapshots.jsonl'), JSON.stringify(selectionColorsObserver.frames.at(-1)) + '\n');
                return result;
            }
            const attributes = request.kind.startsWith('sgr-');
            if (attributes && !cellObserver?.restored) throw new Error('ASCII suite must restore before SGR observations.');
            if (attributes) sgrObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName,
                nonce: `NTILDE_SG_${runId}`, includeAttributes: true, prefix: 'sgr', expectedPaneId: cellObserver.paneId });
            else cellObserver ??= new OwnedCellObserver({ appData, ownerPid: app.pid, profileName, nonce: config.cellNonce });
            const observer = attributes ? sgrObserver : cellObserver;
            const result = await observer.handle(request.kind, budget, request.barrier);
            appendFileSync(join(output, attributes ? 'sgr-snapshots.jsonl' : 'cell-snapshots.jsonl'), JSON.stringify(observer.frames.at(-1)) + '\n');
            return result;
        };
        /** Reject observations until the parent has independently proved untranslated output. */
        const observeUntranslatedCells = (request, budget) => {
            if (!outputModeVerified) throw new Error('Private PTY output mode has not been verified.');
            return observeCells(request, budget);
        };
        /** Retain the first measured lineage and PTY without storing the run capability. */
        const retainFirstProof = (owner, worker, tty, budget) => {
            if (proofs.length !== 0) return;
            proofs.push({ privateClipboard: { policy: ownedPrivateClipboardPolicy, appBirth: processBirth(owner.pid, budget()),
                workerBirth: processBirth(worker.pid, budget()), outputDevice: outputDevice(tty), originalTerminalState: readOwnedTerminalState(tty, budget()) }, app: owner, worker, tty, at: new Date().toISOString(), resize: { policy: ownedResizePolicy, actions: [] }, asciiReflow: { policy: ownedAsciiReflowPolicy, actions: [] }, saved: { policy: ownedSavedPolicy }, metadata: { policy: ownedMetadataPolicy }, input: { policy: ownedInputPolicy, actions: [] }, staticImages: { policy: ownedStaticImagePolicy, actions: [] }, kittyAnimation: { policy: ownedAnimationPolicy, actions: [] }, queries: { policy: ownedQueryPolicy, actions: [] } });
        };
        /** Prepare the fixed collection grid before baseline snapshots, using only the proved private pane. */
        const attestOutputMode = async (request, budget, worker) => {
            const proof = proofs[0];
            if (outputModeVerified || !proof || proof.fontFixtureGeometry) throw new Error('Unexpected private PTY output proof.');
            const reader = new OwnedCellObserver({ appData, ownerPid: app.pid, profileName, nonce: config.cellNonce });
            const { rows, cols } = eraseDisplayGeometry;
            const before = await reader.session(budget);
            proof.fontFixtureGeometry = { before: { paneId: before.paneId, rows: before.rows, cols: before.cols }, target: { rows, cols } };
            if (before.rows !== rows || before.cols !== cols) {
                const action = await resizeOwnedPane({ app, appData, executable, runId, paneId: before.paneId,
                    uid: worker.uid, workerPid: worker.pid, tty: request.tty }, rows, cols, budget);
                proof.fontFixtureGeometry.resize = action;
                if (action.app?.exact !== true || action.app.layoutSettled !== true || action.app.rows !== rows || action.app.cols !== cols)
                    throw new Error('Font fixture could not prepare the required 40×140 grid.');
            }
            reader.paneId = before.paneId;
            const after = await reader.session(budget);
            if (after.rows !== rows || after.cols !== cols) throw new Error('Prepared font fixture grid differs from the contract.');
            const mode = readOwnedOutputMode(request.tty, budget());
            validateOutputGeometry(mode.description, rows, cols);
            proof.terminalOutput = { ...mode, verifiedAt: new Date().toISOString() };
            outputModeVerified = true;
        };
        const observeImageRequest = (request, budget, owner, worker, observe = observeImages) => {
            if (!outputModeVerified) throw new Error('Private PTY output mode has not been verified.');
            const command = execFileSync('/bin/ps', ['-p', String(worker.pid), '-o', 'command='],
                { encoding: 'utf8', timeout: budget(), maxBuffer: 16384 });
            if (!matchesRecordedWorker(worker, workerIdentity, command, runId)) throw new Error('Recorded image worker identity or marker changed.');
            const ownership = { app: owner, worker, tty: request.tty, at: new Date().toISOString(),
                terminalOutput: readOwnedOutputMode(request.tty, budget()) };
            return observe(request, budget, ownership);
        };
        /** Route already authenticated requests serially; preserve each suite's existing response shape and budget. */
        const routeOwnedObservation = async (request, queryTimeout, owner, worker) => {
            if (request.kind === 'private-clipboard') {
                const result = await observePrivateClipboard(request, queryTimeout, owner, worker);
                return { ok: true, ownerPid: app.pid, result };
            }
            if (request.kind?.startsWith('queries-')) {
                const result = await observeQueries(request, queryTimeout, owner, worker);
                return { ok: true, ownerPid: app.pid, ...result };
            }
            if (/^(?:images|kan)-(?:start|admit|bind|read|restore|finish|seal)$/.test(request.kind)) {
                const result = await observeImageRequest(request, queryTimeout, owner, worker, request.kind.startsWith('kan-') ? observeAnimation : observeImages);
                return { ok: true, ownerPid: app.pid, ...result };
            }
            if (untranslatedCellKind(request.kind)
                || coreWrapKinds.has(request.kind)
                || /^(?:resize|reflow)-(?:start|bind|read|apply|finish|abort)$/.test(request.kind)
                || osc9ActionKinds.has(request.kind)
                || osc720ActionKinds.has(request.kind)
                || notifyActionKinds.has(request.kind)
                || /^input-(?:start|bind|control|apply|read|finish|seal)$/.test(request.kind)) {
                const result = await observeUntranslatedCells(request, queryTimeout);
                return { ok: true, ownerPid: app.pid, ...result };
            }
            return null;
        };
        /** Handle proof/done/failure only after lineage verification; done additionally requires close and exact termios. */
        const controlOwnedWorker = async (request, queryTimeout, owner, worker) => {
            if (request.kind === 'prove') {
                // Retain the measured proof, never the capability token.
                retainFirstProof(owner, worker, request.tty, queryTimeout);
            } else if (request.kind === 'raw-output') {
                await attestOutputMode(request, queryTimeout, worker);
            } else if (request.kind === 'done') {
                if (isOsc633Scope(collectionScope) && (osc9State !== undefined || notifyState !== undefined)) throw new Error('Omitted notification suites ran in the scoped collection.');
                requireInputCompletion(inputState);
                requireStaticImageCompletion(staticImageState);
                requireAnimationCompletion(animationState);
                requireQueryCompletion(queryState);
                if (!privateClipboardState?.observer.complete || !privateClipboardEvidence) throw new Error('Private clipboard did not close.');
                const original = proofs[0].privateClipboard.originalTerminalState;
                if (readOwnedTerminalState(request.tty, queryTimeout()) !== original) throw new Error('Original private kernel mode was not restored.');
                proofs[0].privateClipboard.restoredTerminalState = original;
                proofs[0].privateClipboard.restoredAt = new Date().toISOString();
                completed = true;
                resolveDone();
            } else if (request.kind === 'failed') {
                rejectDone(new Error(request.error ?? 'Worker failed.'));
            } else throw new Error('Unknown owner request.');
            return { ok: true, ownerPid: app.pid, ...(request.kind === 'prove' ? { privateClipboard: true, originalTerminalState: proofs[0].privateClipboard.originalTerminalState } : {}) };
        };
        /** Bound owner input to 8 KiB and authenticate before routing; asynchronous refusal must never bypass owned cleanup. */
        const server = createServer(socket => {
            let buffer = '';
            socket.setTimeout(5000, () => socket.destroy());
            socket.on('error', () => {});
            /** Consume one authenticated request; contain failed journal writes and still emit the closed refusal response. */
            socket.on('data', async chunk => {
                buffer += chunk;
                if (buffer.length > 8192) return socket.destroy();
                if (!buffer.includes('\n')) return;
                socket.removeAllListeners('data');
                let request, authenticated = false;
                try {
                    request = JSON.parse(buffer.slice(0, buffer.indexOf('\n')));
                    if (typeof request.token !== 'string' || request.token.length !== token.length
                        || !timingSafeEqual(Buffer.from(request.token), Buffer.from(token)) || request.runId !== runId) {
                        throw new Error('Invalid run capability.');
                    }
                    authenticated = true;
                    if (!app?.pid || app.exitCode !== null || app.signalCode !== null) throw new Error('Owned app is no longer live.');
                    assertExecutableUnchanged(executable, image);
                    // All lineage/mode queries and observations share the existing 4s budget.
                    const queryTimeout = createProcessBudget(4000);
                    const owner = processRecord(app.pid, queryTimeout());
                    const worker = processRecord(request.workerPid, queryTimeout());
                    assertProcessOwnership({ app: { ...owner, executable: realpathSync(owner.executable) }, worker,
                        ownerPid: app.pid, executable, uid: process.getuid(), runId, tty: request.tty,
                        appCommand: execFileSync('/bin/ps', ['-p', String(app.pid), '-o', 'command='], { encoding: 'utf8', timeout: queryTimeout(), maxBuffer: 16384 }) });
                    if (workerIdentity && workerIdentity.pid !== worker.pid) throw new Error('Another worker tried to use this run.');
                    workerIdentity ??= worker;
                    const observation = await routeOwnedObservation(request, queryTimeout, owner, worker);
                    if (observation) { socket.end(JSON.stringify(observation) + '\n'); return; }
                    socket.end(JSON.stringify(await controlOwnedWorker(request, queryTimeout, owner, worker)) + '\n');
                } catch (error) {
                    if (authenticated && privateClipboardState?.observer) {
                        rejectDone(error);
                        try { await retainPrivateClipboardAbort(privateClipboardState, error, 'authenticatedOwnerDispatch', retainPrivateClipboardJournal); }
                        catch (error_) { recordPrivateClipboardRetentionFailure(privateClipboardState, 'authenticatedOwnerDispatch', error_); }
                    }
                    rejectQueryOwnerRequest({ authenticated, observer: queryState?.observer, error, request, reject: rejectDone });
                    socket.end(JSON.stringify(ownerFailure(error, Boolean(privateClipboardState))) + '\n');
                }
            });
        });
        let deadline;
        let logFd;
        let runOutcome = { failed: false }, cleanupOutcome;
        try {
            await Promise.race([done, new Promise((resolve, reject) => {
                server.once('error', reject);
                server.listen(config.socket, resolve);
            })]);
            if (interruption) throw interruption;
            chmodSync(config.socket, 0o600);
            const env = { ...process.env, NTILDE_APPDATA_ROOT: appData, TERMINFO_RUN_ID: runId,
                TERM_PROGRAM: 'Ntilde', TERM_PROGRAM_VERSION: args[3], PATH: dirname(process.execPath) + ':' + process.env.PATH };
            for (const name of ['__CFBundleIdentifier', 'TMUX', 'STY', 'SSH_CONNECTION', 'SSH_TTY',
                'TERMINFO_CAPTURE_DIRECTORY', 'TERMINFO_CLIPBOARD_FIXTURE_RECEIPT', 'TERMINFO_RUNTIME_PROVENANCE']) delete env[name];
            logFd = openSync(join(output, 'app-output.log'), 'wx', 0o600);
            app = launchOwnedApp(lease, executable, runId, env, logFd);
            app.once('error', rejectDone);
            app.once('exit', (code, signal) => { if (!completed) rejectDone(new Error(`Owned app exited before collection (${code ?? signal}).`)); });
            context.ownerPid = app.pid;
            writeJson(join(output, 'context.json'), context);
            // The full legacy collection grew past five minutes of wall time when the special-color suite
            // joined it (the archived static-image run already ran close to the ceiling): every suite's
            // worker phase and the whole-receipt rederivation happen inside this single window, so a hang
            // guard set too tight kills a healthy run during finalization.
            deadline = setTimeout(() => rejectDone(new Error('Owned collection exceeded 10 minutes.')), 600000);
            console.log(`Collecting in disposable Ntilde pid ${app.pid}; results: ${output}`);
            await done;
            assertOwnedSourcesUnchanged(sourceRepo, context);
            const summary = collectionSummary(output, args[3]);
            cellEvidence = retainCellReport(output, cellObserver, runId);
            sgrEvidence = retainCellReport(output, sgrObserver, runId, buildSgrReport, 'sgr-observations.json');
            gradingEvidence = await retainGradingEvidence(output, runId, gradingBundle, upstreamBundleSha256);
            sgrColorsEvidence = await retainSgrColorsEvidence(output, runId, sgrColorsBundle, upstreamBundleSha256);
            sgrRgbEvidence = await retainSgrRgbEvidence(output, runId, sgrRgbBundle, upstreamBundleSha256);
            sgrAttrsEvidence = await retainSgrAttrsEvidence(output, runId, sgrAttrsBundle, upstreamBundleSha256);
            sgrPaletteEvidence = await retainSgrPaletteEvidence(output, runId, sgrPaletteBundle, upstreamBundleSha256);
            sgrTruecolorEvidence = await retainSgrTruecolorEvidence(output, runId, sgrTruecolorBundle, upstreamBundleSha256);
            truecolorFindingEvidence = retainTruecolorFindingEvidence(output, runId);
            sgrUnderlineEvidence = await retainSgrUnderlineEvidence(output, runId, sgrUnderlineBundle, upstreamBundleSha256);
            sgrUnderlineColorEvidence = await retainSgrUnderlineColorEvidence(output, runId, sgrUnderlineColorBundle, upstreamBundleSha256);
            underlineResolvedEvidence = retainUnderlineResolvedEvidence(output, runId);
            sgrResetEvidence = await retainSgrResetEvidence(output, runId, sgrResetBundle, upstreamBundleSha256);
            sgrClosureEvidence = await retainSgrClosureEvidence(output, runId, sgrClosureBundle, upstreamBundleSha256);
            eraseLineEvidence = await retainEraseLineEvidence(output, runId, eraseLineBundle, upstreamBundleSha256);
            charEditEvidence = await retainCharEditEvidence(output, runId, charEditBundle, upstreamBundleSha256);
            eraseDisplayEvidence = await retainEraseDisplayEvidence(output, runId, eraseDisplayBundle, upstreamBundleSha256);
            lineEditEvidence = await retainLineEditEvidence(output, runId, lineEditBundle, upstreamBundleSha256);
            insertReplaceEvidence = await retainInsertReplaceEvidence(output, runId, insertReplaceBundle, upstreamBundleSha256);
            charsetsEvidence = await retainCharsetsEvidence(output, runId, charsetsBundle, upstreamBundleSha256);
            scrollbackEvidence = await retainScrollbackEvidence(output, runId, scrollbackBundle, upstreamBundleSha256);
            savedResetEvidence = await retainSavedResetEvidence(output, runId, savedResetBundle, upstreamBundleSha256);
            eraseAttrsRegionEvidence = await retainEraseAttrsRegionEvidence(output, runId, eraseAttrsRegionBundle, upstreamBundleSha256);
            attrRectEvidence = await retainAttrRectEvidence(output, runId, attrRectBundle, upstreamBundleSha256);
            cursorQualEvidence = await retainCursorQualEvidence(output, runId, cursorQualBundle, upstreamBundleSha256);
            eraseCharsHistoryEvidence = await retainEraseCharsHistoryEvidence(output, runId, eraseCharsHistoryBundle, upstreamBundleSha256);
            selectiveEraseEvidence = await retainSelectiveEraseEvidence(output, runId, selectiveEraseBundle, upstreamBundleSha256);
            rectEditEvidence = await retainRectEditEvidence(output, runId, rectEditBundle, upstreamBundleSha256);
            colEditEvidence = await retainColEditEvidence(output, runId, colEditBundle, upstreamBundleSha256);
            rectChecksumEvidence = await retainRectChecksumEvidence(output, runId, rectChecksumBundle, upstreamBundleSha256);
            lrMarginsEvidence = await retainLrMarginsEvidence(output, runId, lrMarginsBundle, upstreamBundleSha256);
            const coreRunBytes = readFileSync(join(output, 'cg-run.json'));
            const coreFrames = readFileSync(join(output, 'cg-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            const coreAdapter = { id: coreGapsAdapterId, derivedFromAdapterId: lrMarginsAdapterId,
                bundleSha256: coreGapsBundleSha256, upstreamBundleSha256 };
            const coreReport = buildCoreGapsReport(coreFrames, JSON.parse(coreRunBytes), runId, coreAdapter, await import(pathToFileURL(coreGapsBundle).href));
            writeJson(join(output, 'cg-observations.json'), coreReport);
            coreGapsEvidence = { runId, suiteId: coreGapsSuiteId, file: 'cg-observations.json',
                sha256: hash(readFileSync(join(output, 'cg-observations.json'))), runFile: 'cg-run.json', runSha256: hash(coreRunBytes),
                adapterBundleSha256: coreGapsBundleSha256, provisionalUntil: 'cell-receipt.json' };
            colorResetEvidence = await retainColorResetEvidence(output, runId, colorResetBundle, upstreamBundleSha256);
            selectionColorsEvidence = retainSelectionColorsEvidence(output, runId, upstreamBundleSha256);
            const tcRunBytes = readFileSync(join(output, 'tc-run.json'));
            const tcFrames = readFileSync(join(output, 'tc-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            const tcReport = buildTextCursorReport(tcFrames, JSON.parse(tcRunBytes), runId);
            writeJson(join(output, 'tc-observations.json'), tcReport);
            textCursorEvidence = { runId, suiteId: textCursorSuiteId, file: 'tc-observations.json',
                sha256: hash(readFileSync(join(output, 'tc-observations.json'))), runFile: 'tc-run.json', runSha256: hash(tcRunBytes),
                provisionalUntil: 'cell-receipt.json' };
            const modernCursor = deriveModernCursorEvidence(output, runId);
            writeJson(join(output, modernCursor.binding.file), modernCursor.report);
            modernCursorEvidence = modernCursor.binding;
            const modernModes = deriveModernModesEvidence(output, runId);
            writeJson(join(output, modernModes.binding.file), modernModes.report);
            modernModesEvidence = modernModes.binding;
            const ceRunBytes = readFileSync(join(output, 'ce-run.json'));
            const ceFrames = readFileSync(join(output, 'ce-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            writeJson(join(output, 'ce-observations.json'), buildCoreEraseReport(ceFrames, JSON.parse(ceRunBytes), runId));
            coreEraseEvidence = { runId, suiteId: coreEraseSuiteId, file: 'ce-observations.json',
                sha256: hash(readFileSync(join(output, 'ce-observations.json'))), runFile: 'ce-run.json', runSha256: hash(ceRunBytes),
                provisionalUntil: 'cell-receipt.json' };
            const tsRunBytes = readFileSync(join(output, 'ts-run.json'));
            const tsFrames = readFileSync(join(output, 'ts-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            writeJson(join(output, 'ts-observations.json'), buildTabStopsReport(tsFrames, JSON.parse(tsRunBytes), runId));
            tabStopsEvidence = { runId, suiteId: tabStopsSuiteId, file: 'ts-observations.json',
                sha256: hash(readFileSync(join(output, 'ts-observations.json'))), runFile: 'ts-run.json', runSha256: hash(tsRunBytes),
                provisionalUntil: 'cell-receipt.json' };
            if (!coreWrapState?.observer.restored) throw new Error('Core wrap did not restore.');
            const cwRunBytes = readFileSync(join(output, 'cw-run.json'));
            const cwFrames = readFileSync(join(output, 'cw-snapshots.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
            const cwGeometryBytes = readFileSync(join(output, 'cw-geometry.json'));
            writeJson(join(output, 'cw-observations.json'), deriveWrapEvidence(cwFrames, JSON.parse(cwRunBytes), runId, JSON.parse(cwGeometryBytes)));
            coreWrapEvidence = { runId, suiteId: wrapSuiteId, file: 'cw-observations.json',
                sha256: hash(readFileSync(join(output, 'cw-observations.json'))), runFile: 'cw-run.json', runSha256: hash(cwRunBytes),
                geometryFile: 'cw-geometry.json', geometrySha256: hash(cwGeometryBytes), provisionalUntil: 'cell-receipt.json' };
            rgbEvidence = retainDetails('rgb');
            renditionEvidence = retainDetails('rendition');
            cursorEvidence = retainDetails('cursor');
            pixelEvidence = pixelUnavailable ?? retainCellReport(output, pixelObserver, runId,
                (frames, id) => buildPixelReport(frames, id, output), 'pixel-observations.json');
            colorEvidence = colorUnavailable ?? retainCellReport(output, colorObserver, runId,
                (frames, id) => buildColorReport(frames, id, output), 'color-observations.json');
            eraseEvidence = retainEditing('erase');
            editingEvidence = retainEditing('editing');
            historyEvidence = retainEditing('history');
            resizeEvidence = resizeState?.unavailable ?? retainCellReport(output, resizeState?.observer, runId,
                (frames, id) => buildResizeReport(frames, resizeState.observer.actions, id), 'resize-observations.json');
            reflowEvidence = await retainReflowEvidence(output, runId, reflowBundle, upstreamBundleSha256, reflowState?.unavailable ?? null);
            savedEvidence = savedState?.unavailable ?? retainCellReport(output, savedState?.observer, runId, buildSavedReport, 'saved-observations.json');
            metadataEvidence = metadataState?.unavailable ?? retainCellReport(output, metadataState?.observer, runId, buildMetadataReport, 'metadata-observations.json');
            inputEvidence = inputState?.unavailable ?? retainCellReport(output, inputState?.observer, runId,
                () => inputState.observer.report, 'input-observations.json');
            routedInputEvidence = await retainRoutedInputEvidence(output, runId, routedInputBundle, upstreamBundleSha256, inputEvidence, inputState.observer?.seal, inputSuiteId);
            modifyOtherKeysEvidence = await retainModifyOtherKeysEvidence(output, runId, modifyOtherKeysBundle, upstreamBundleSha256, inputEvidence, inputState.observer?.seal, inputSuiteId);
            mexEvidence = await retainMexEvidence(output, runId, mexBundle, upstreamBundleSha256, inputEvidence, inputState.observer?.seal, inputSuiteId);
            pxmEvidence = await retainPxmEvidence(output, runId, pxmBundle, upstreamBundleSha256, inputEvidence, inputState.observer?.seal, inputSuiteId);
            osc133Evidence = await retainOsc133Evidence(output, runId, osc133Bundle, upstreamBundleSha256, osc133State?.unavailable === true);
            if (isOsc633Scope(collectionScope)) osc633Evidence = await retainOsc633Evidence(output, runId, osc633Bundle, upstreamBundleSha256, osc633State?.unavailable === true);
            osc78Evidence = await retainOsc78Evidence(output, runId, osc78Bundle, upstreamBundleSha256, osc78State?.unavailable === true);
            titleStackEvidence = await retainTitleStackEvidence(output, runId, titleStackBundle, upstreamBundleSha256, titleStackState?.unavailable === true);
            xtgettcapEvidence = await retainXtgettcapEvidence(output, runId, xtgettcapBundle, upstreamBundleSha256);
            osc720Evidence = retainOsc720Evidence(output, runId, upstreamBundleSha256, osc720State?.unavailable === true);
            if (!isOsc633Scope(collectionScope)) {
                osc9Evidence = retainOsc9Evidence(output, runId, upstreamBundleSha256, osc9State?.unavailable === true);
                notifyEvidence = retainNotifyEvidence(output, runId, upstreamBundleSha256, notifyState?.unavailable === true);
            }
            devqEvidence = await retainDevqEvidence(output, runId, devqBundle, upstreamBundleSha256);
            const cellSizeRunBytes = readFileSync(join(output, 'cell-size-run.json'));
            const cellSizeFrames = readFileSync(join(output, 'cell-size-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            const cellSizeAdapter = { id: cellSizeAdapterId, bundleSha256: cellSizeBundleSha256, upstreamBundleSha256 };
            const cellSizeReport = buildCellSizeReport(cellSizeFrames, JSON.parse(cellSizeRunBytes), runId, cellSizeAdapter,
                { replayModule: await import(pathToFileURL(cellSizeBundle).href) });
            writeJson(join(output, 'cell-size-observations.json'), cellSizeReport);
            cellSizeEvidence = { runId, suiteId: cellSizeSuiteId, file: 'cell-size-observations.json',
                sha256: hash(readFileSync(join(output, 'cell-size-observations.json'))), runFile: 'cell-size-run.json', runSha256: hash(cellSizeRunBytes),
                adapterBundleSha256: cellSizeBundleSha256, contractsVersion: cellSizeVersion,
                counts: cellSizeCounts(cellSizeReport), provisionalUntil: 'cell-receipt.json' };
            summary.cellSizeEvidence = cellSizeEvidence;
            const fontSizeRunBytes = readFileSync(join(output, 'font-size-run.json'));
            const fontSizeFrames = readFileSync(join(output, 'font-size-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            const fontSizeAdapter = { id: fontSizeAdapterId, bundleSha256: fontSizeBundleSha256, upstreamBundleSha256 };
            const fontSizeReport = buildFontSizeReport(fontSizeFrames, JSON.parse(fontSizeRunBytes), runId, fontSizeAdapter,
                { replayModule: await import(pathToFileURL(fontSizeBundle).href) });
            writeJson(join(output, 'font-size-observations.json'), fontSizeReport);
            fontSizeEvidence = { runId, suiteId: fontSizeSuiteId, file: 'font-size-observations.json',
                sha256: hash(readFileSync(join(output, 'font-size-observations.json'))), runFile: 'font-size-run.json', runSha256: hash(fontSizeRunBytes),
                adapterBundleSha256: fontSizeBundleSha256, contractsVersion: fontSizeVersion,
                counts: fontSizeCounts(fontSizeReport), provisionalUntil: 'cell-receipt.json' };
            summary.fontSizeEvidence = fontSizeEvidence;
            xcsEvidence = await retainXcsEvidence(output, runId, xcsBundle, upstreamBundleSha256);
            xssEvidence = await retainXssEvidence(output, runId, xssBundle, upstreamBundleSha256);
            xsvEvidence = await retainXsvEvidence(output, runId, xsvBundle, upstreamBundleSha256);
            kclEvidence = await retainKclEvidence(output, runId, kclBundle, upstreamBundleSha256);
            osc5Evidence = await retainOsc5Evidence(output, runId, osc5Bundle, upstreamBundleSha256);
            osc3008Evidence = await retainOsc3008Evidence(output, runId, osc3008Bundle, upstreamBundleSha256, osc3008State?.unavailable === true);
            osc22Evidence = await retainOsc22Evidence(output, runId, osc22Bundle, upstreamBundleSha256, osc22State?.unavailable === true);
            capsEvidence = await retainCapsEvidence(output, runId, capsBundle, upstreamBundleSha256);
            pclEvidence = await retainPclEvidence(output, runId, pclBundle, upstreamBundleSha256);
            dclEvidence = await retainDclEvidence(output, runId, dclBundle, upstreamBundleSha256);
            dslEvidence = await retainDslEvidence(output, runId, dslBundle, upstreamBundleSha256);
            oscTitleEvidence = retainOscTitleEvidence(output, runId, upstreamBundleSha256, oscTitleState?.unavailable === true);
            // The worker has completed: grade every retained PNG outside the bounded owner RPC.
            if (!staticImageState?.unavailable) staticImageState?.observer.finalizeReport();
            if (!animationState?.unavailable) animationState?.observer.finalizeReport();
            staticImageEvidence = staticImageState?.unavailable ?? retainCellReport(output, staticImageState?.observer, runId,
                () => staticImageState.observer.report, 'image-observations.json');
            animationEvidence = animationState?.unavailable ?? retainCellReport(output, animationState?.observer, runId,
                () => animationState.observer.report, 'animation-observations.json');
            queryEvidence = retainQueryReport(output, queryState, runId);
            summary.coreGapsEvidence = coreGapsEvidence;
            summary.textCursorEvidence = textCursorEvidence;
            summary.modernCursorEvidence = modernCursorEvidence;
            summary.modernModesEvidence = modernModesEvidence;
            summary.coreEraseEvidence = coreEraseEvidence;
            summary.tabStopsEvidence = tabStopsEvidence;
            const srRunBytes = readFileSync(join(output, 'sr-run.json'));
            const srFrames = readFileSync(join(output, 'sr-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            writeJson(join(output, 'sr-observations.json'), buildSgrRasterReport(srFrames, JSON.parse(srRunBytes), runId, output));
            sgrRasterEvidence = { runId, suiteId: sgrRasterSuiteId, file: 'sr-observations.json',
                sha256: hash(readFileSync(join(output, 'sr-observations.json'))), runFile: 'sr-run.json', runSha256: hash(srRunBytes),
                provisionalUntil: 'cell-receipt.json' };
            const rwRunBytes = readFileSync(join(output, 'rw-run.json'));
            const rwFrames = readFileSync(join(output, 'rw-snapshots.jsonl'), 'utf8').trim().split('\n').map(line => JSON.parse(line));
            writeJson(join(output, 'rw-observations.json'), buildReverseWideReport(rwFrames, JSON.parse(rwRunBytes), runId));
            reverseWideEvidence = { runId, suiteId: reverseWideSuiteId, file: 'rw-observations.json',
                sha256: hash(readFileSync(join(output, 'rw-observations.json'))), runFile: 'rw-run.json', runSha256: hash(rwRunBytes),
                provisionalUntil: 'cell-receipt.json' };
            summary.coreWrapEvidence = coreWrapEvidence;
            summary.sgrRasterEvidence = sgrRasterEvidence;
            summary.reverseWideEvidence = reverseWideEvidence;
            summary.privateClipboardEvidence = privateClipboardEvidence;
            summary.queryEvidence = queryEvidence;
            summary.staticImageEvidence = staticImageEvidence;
            summary.animationEvidence = animationEvidence;
            summary.inputEvidence = inputEvidence;
            summary.metadataEvidence = metadataEvidence;
            summary.savedEvidence = savedEvidence;
            summary.resizeEvidence = resizeEvidence;
            summary.reflowEvidence = reflowEvidence;
            summary.historyEvidence = historyEvidence;
            summary.eraseEvidence = eraseEvidence;
            summary.editingEvidence = editingEvidence;
            summary.colorEvidence = colorEvidence;
            summary.pixelEvidence = pixelEvidence;
            summary.renditionEvidence = renditionEvidence;
            summary.cursorEvidence = cursorEvidence;
            summary.rgbEvidence = rgbEvidence;
            summary.cellEvidence = cellEvidence;
            summary.sgrEvidence = sgrEvidence;
            summary.gradingEvidence = gradingEvidence;
            summary.sgrColorsEvidence = sgrColorsEvidence;
            summary.sgrRgbEvidence = sgrRgbEvidence;
            summary.sgrAttrsEvidence = sgrAttrsEvidence;
            summary.sgrPaletteEvidence = sgrPaletteEvidence;
            summary.sgrTruecolorEvidence = sgrTruecolorEvidence;
            summary.truecolorFindingEvidence = truecolorFindingEvidence;
            summary.sgrUnderlineEvidence = sgrUnderlineEvidence;
            summary.sgrUnderlineColorEvidence = sgrUnderlineColorEvidence;
            summary.underlineResolvedEvidence = underlineResolvedEvidence;
            summary.sgrResetEvidence = sgrResetEvidence;
            summary.sgrClosureEvidence = sgrClosureEvidence;
            summary.eraseLineEvidence = eraseLineEvidence;
            summary.charEditEvidence = charEditEvidence;
            summary.eraseDisplayEvidence = eraseDisplayEvidence;
            summary.lineEditEvidence = lineEditEvidence;
            summary.insertReplaceEvidence = insertReplaceEvidence;
            summary.charsetsEvidence = charsetsEvidence;
            summary.scrollbackEvidence = scrollbackEvidence;
            summary.savedResetEvidence = savedResetEvidence;
            summary.eraseAttrsRegionEvidence = eraseAttrsRegionEvidence;
            summary.attrRectEvidence = attrRectEvidence;
            summary.cursorQualEvidence = cursorQualEvidence;
            summary.eraseCharsHistoryEvidence = eraseCharsHistoryEvidence;
            summary.selectiveEraseEvidence = selectiveEraseEvidence;
            summary.rectEditEvidence = rectEditEvidence;
            summary.colEditEvidence = colEditEvidence;
            summary.rectChecksumEvidence = rectChecksumEvidence;
            summary.lrMarginsEvidence = lrMarginsEvidence;
            summary.routedInputEvidence = routedInputEvidence;
            summary.modifyOtherKeysEvidence = modifyOtherKeysEvidence;
            summary.mexEvidence = mexEvidence;
            summary.pxmEvidence = pxmEvidence;
            summary.osc133Evidence = osc133Evidence;
            summary.osc633Evidence = osc633Evidence;
            summary.osc78Evidence = osc78Evidence;
            summary.titleStackEvidence = titleStackEvidence;
            summary.xtgettcapEvidence = xtgettcapEvidence;
            summary.osc9Evidence = osc9Evidence;
            summary.notifyEvidence = notifyEvidence;
            summary.devqEvidence = devqEvidence;
            summary.xcsEvidence = xcsEvidence;
            summary.xssEvidence = xssEvidence;
            summary.xsvEvidence = xsvEvidence;
            summary.kclEvidence = kclEvidence;
            summary.osc5Evidence = osc5Evidence;
            summary.osc720Evidence = osc720Evidence;
            summary.osc3008Evidence = osc3008Evidence;
            summary.osc22Evidence = osc22Evidence;
            summary.capsEvidence = capsEvidence;
            summary.pclEvidence = pclEvidence;
            summary.dclEvidence = dclEvidence;
            summary.dslEvidence = dslEvidence;
            summary.oscTitleEvidence = oscTitleEvidence;
            summary.selectionColorsEvidence = selectionColorsEvidence;
            summary.colorResetEvidence = colorResetEvidence;
            writeJson(join(output, 'summary.json'), summary);
            console.log(JSON.stringify(summary, null, 2));
        } catch (error) {
            runOutcome = { failed: true, error };
            runOutcome = await retainOwnedFailureSequence(error, [
                async () => { await retainPrivateClipboardAbort(privateClipboardState, error, 'runFailure', retainPrivateClipboardJournal); },
                () => { queryState?.observer?.abort(error); retainQueryJournal(); },
                reason => retainOwnedFailure(output, reason, privateClipboardState),
            ]);
        } finally {
            clearTimeout(deadline);
            preserveScratch = true;
            cleanupOutcome = await captureOwnedCleanup(() => cleanupOwnedRun({ lease, workerIdentity, runId, app, logFd, server, output, proofs, completed, scratch, collectionScope }));
            preserveScratch = cleanupOutcome.failed;
        }
        throwOwnedRunFailures(runOutcome, cleanupOutcome);
    } catch (error) {
        retainPreparationFailure(output, error);
        throw error;
    } finally {
        try {
            // Also handles preparation failures before the app or server is started.
            if (scratch && !preserveScratch) rmSync(scratch, { recursive: true, force: true });
        } finally {
            process.removeListener('SIGINT', onInt);
            process.removeListener('SIGTERM', onTerm);
            process.removeListener('SIGHUP', onHup);
        }
    }
    if (interruption) {
        writeJson(join(output, 'failure.json'), { error: interruption.message, at: new Date().toISOString() });
        throw interruption;
    }
    try {
        assertOwnedSourcesUnchanged(sourceRepo, sourceContext);
        removeSourceSnapshot(sourceRepo);
        const proofPath = join(output, 'ownership-proof.json');
        const proof = JSON.parse(readFileSync(proofPath));
        proof.sourceSnapshot = { policy: sourceSnapshotPolicy, root: sourceRepo, removedAt: new Date().toISOString() };
        writeFileSync(proofPath, JSON.stringify(proof, null, 2) + '\n', { mode: 0o600 });
        completeOwnedReceipt(output, scratch, { ...cellEvidence, sgrEvidence, gradingEvidence, sgrColorsEvidence, sgrRgbEvidence, sgrAttrsEvidence, sgrPaletteEvidence, sgrTruecolorEvidence, truecolorFindingEvidence, sgrUnderlineEvidence, sgrUnderlineColorEvidence, underlineResolvedEvidence, sgrResetEvidence, sgrClosureEvidence, eraseLineEvidence, charEditEvidence, eraseDisplayEvidence, lineEditEvidence, charsetsEvidence, scrollbackEvidence, savedResetEvidence, eraseAttrsRegionEvidence, attrRectEvidence, cursorQualEvidence, eraseCharsHistoryEvidence, selectiveEraseEvidence, rectEditEvidence, colEditEvidence, rectChecksumEvidence, lrMarginsEvidence, colorResetEvidence, coreGapsEvidence, routedInputEvidence, textCursorEvidence, modernCursorEvidence, modernModesEvidence, osc133Evidence, osc633Evidence, osc78Evidence, coreEraseEvidence, tabStopsEvidence, coreWrapEvidence, sgrRasterEvidence, reverseWideEvidence, titleStackEvidence, oscTitleEvidence, selectionColorsEvidence, insertReplaceEvidence, xtgettcapEvidence, modifyOtherKeysEvidence, osc9Evidence, notifyEvidence, devqEvidence, cellSizeEvidence, fontSizeEvidence, xcsEvidence, xssEvidence, xsvEvidence, mexEvidence, pxmEvidence, kclEvidence, osc5Evidence, osc3008Evidence, osc720Evidence, osc22Evidence, capsEvidence, pclEvidence, dclEvidence, dslEvidence, rgbEvidence, renditionEvidence, cursorEvidence, pixelEvidence, colorEvidence, eraseEvidence, editingEvidence, historyEvidence, resizeEvidence, reflowEvidence, savedEvidence, metadataEvidence, inputEvidence, staticImageEvidence, animationEvidence, queryEvidence, privateClipboardEvidence });
    }
    catch (error) { retainPreparationFailure(output, error); throw error; }
}


/** Fixed identity of the persistent-tab animation collection: its receipt, adapter and the one suite it carries. */
const persistentAnimationAdapterId = 'ntilde-owned-kitty-animation-persistent-adapter-v1';
export const persistentAnimationReceiptSuiteId = 'ntilde-owned-kitty-animation-persistent-receipt-v1';
export const persistentRestoreReceiptSuiteId = 'ntilde-owned-kitty-animation-persistent-restore-receipt-v1';
export const persistentComposeReceiptSuiteId = 'ntilde-owned-kitty-animation-persistent-compose-receipt-v1';
export const directComposeReceiptSuiteId = 'ntilde-owned-kitty-animation-direct-compose-receipt-v1';
export const persistentPlaceholdersReceiptSuiteId = 'ntilde-owned-kitty-placeholders-persistent-receipt-v1';
export const directPlaceholdersReceiptSuiteId = 'ntilde-owned-kitty-placeholders-direct-receipt-v1';
export const persistentPlaceholderGridReceiptSuiteId = 'ntilde-owned-kitty-placeholder-grid-persistent-receipt-v1';
export const directPlaceholderGridReceiptSuiteId = 'ntilde-owned-kitty-placeholder-grid-direct-receipt-v1';
// By scope, not suite version: the compose (4) and placeholder (5) suites each run in a persistent and in an ordinary tab, each with its own receipt.
const animationReceiptSuiteIds = { [persistentRestoreScope.id]: persistentRestoreReceiptSuiteId, [persistentComposeScope.id]: persistentComposeReceiptSuiteId, [directComposeScope.id]: directComposeReceiptSuiteId,
    [persistentPlaceholdersScope.id]: persistentPlaceholdersReceiptSuiteId, [directPlaceholdersScope.id]: directPlaceholdersReceiptSuiteId,
    [persistentPlaceholderGridScope.id]: persistentPlaceholderGridReceiptSuiteId, [directPlaceholderGridScope.id]: directPlaceholderGridReceiptSuiteId };

/**
 * The receipt of a persistent-tab animation collection. It binds the one retained suite report, the ownership proof (which records the
 * multiplexer daemon) and the context to this run after cleanup is verified; the publication re-derives the report from the retained journals.
 */
/** Whether the collection's tab is a persistent one (a multiplexer daemon hosts the worker); the ordinary-tab composition collection has none. */
const isPersistentScope = scope => scope.persistence === 'KeepOnClose';

function completePersistentAnimationReceipt(output, scratch, evidence) {
    const proofBytes = readFileSync(join(output, 'ownership-proof.json')), proof = JSON.parse(proofBytes);
    const contextBytes = readFileSync(join(output, 'context.json')), context = JSON.parse(contextBytes);
    if (!proof.completed || !proof.cleanedUpAt || proof.cleanupError || (isPersistentScope(context.collectionScope) && !proof.persistentDaemon) || existsSync(scratch)) throw new Error('Animation-only evidence has no completed cleanup.');
    const binding = evidence.animationEvidence;
    if (binding?.runId !== context.runId || binding.suiteId !== context.animationSuiteId || binding.file !== 'animation-observations.json'
        || hash(readFileSync(join(output, binding.file))) !== binding.sha256) throw new Error('Invalid persistent animation receipt binding.');
    const receipt = { schemaVersion: 1, suiteId: animationReceiptSuiteIds[context.collectionScope.id] ?? persistentAnimationReceiptSuiteId, runId: context.runId, collectionScope: context.collectionScope,
        animationEvidence: binding, ownershipProofSha256: hash(proofBytes), contextSha256: hash(contextBytes), fixtureRemoved: true, completedAt: new Date().toISOString() };
    writeFileSync(join(output, 'persistent-animation-receipt.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
    return receipt;
}

/** The disposable fixture of one persistent animation collection: private settings, a worker profile and the identity the owner server and cleanup share. */
function preparePersistentRun(args, executable, snapshot, lease, output, collectionScope) {
    const scratch = createPrivateScratch();
    try { return preparePersistentRunIn(scratch, args, executable, snapshot, lease, output, collectionScope); }
    catch (error) {
        // The scratch holds the run token: if it cannot be removed, keep both errors and say where it is.
        try { rmSync(scratch, { recursive: true, force: true }); }
        catch (cleanupError) { throw new AggregateError([error, cleanupError], `Persistent run preparation failed and its scratch directory ${scratch} remains.`); }
        throw error;
    }
}

function preparePersistentRunIn(scratch, args, executable, snapshot, lease, output, collectionScope) {
    const appData = join(scratch, 'appdata'), version = collectionScope.suiteVersion ?? currentAnimationVersion;
    mkdirSync(appData, { mode: 0o700 });
    const runId = lease.leaseId, profileName = `terminfo disposable worker ${runId}`, configPath = join(scratch, 'worker.json'), command = join(scratch, 'worker.sh');
    const run = { args, executable, snapshot, lease, output, scratch, appData, runId, profileName, collectionScope, token: randomBytes(32).toString('hex'),
        socketPath: join(scratch, 'owner.sock'), image: statSync(executable), proofs: [], outputModeVerified: false, completed: false, identities: {} };
    writeJson(configPath, { privateClipboard: true, runId, token: run.token, appData, output, executable, collectionScope, profileName, socket: run.socketPath });
    const workerFile = focusedSuite?.workerFile ?? 'worker.mjs';
    const workerScript = join(sourceRepo, 'scripts', 'terminfo', workerFile);
    const profileCommand = focusedSuite?.workerProfile?.({ node: realpathSync(process.execPath), workerScript, configPath, runId });
    if (!profileCommand) {
        writeFileSync(command, `#!/bin/sh\nexec ${quote(process.execPath)} ${quote(workerScript)} ${quote(configPath)} --ntilde-terminfo-worker=${runId}\n`, { flag: 'wx', mode: 0o700 });
    }
    const settings = ownedSettings({ profileId: randomUUID(), profileName, command: profileCommand?.Command ?? command, scratch, persistence: collectionScope.persistence });
    if (profileCommand) settings.Profiles[0].Arguments = profileCommand.Arguments;
    if (focusedSuite) {
        settings.AllowOsc52ClipboardWrite = false;
        settings.AgentAccessActEnabled = focusedSuite.allowGeneratedInput === true;
        focusedSuite.prepareSettings?.(settings);
    }
    writeJson(join(appData, 'settings.json'), settings);
    writeJson(join(output, 'initial-settings.json'), settings);
    const { digests } = retainSourceCopies(output);
    run.context = { adapter: focusedSuite ? collectionScope.id : persistentAnimationAdapterId, collectionScope, appVersion: args[3], appVersionSource: 'operator supplied; not independently verified',
        sourceSnapshotPolicy, sourceSnapshotManifestSha256: snapshot.sha256, sourceSnapshotRoot: sourceRepo, ...digests,
        initialSettingsSha256: hash(readFileSync(join(output, 'initial-settings.json'))), executable, executableSha256: hash(readFileSync(executable)),
        assemblySha256: existsSync(join(dirname(executable), 'Ntilde.dll')) ? hash(readFileSync(join(dirname(executable), 'Ntilde.dll'))) : null,
        nodeVersion: process.version, startedAt: new Date().toISOString(), runId,
        ...(!focusedSuite ? { animationSuiteId: animationSuiteIds[version], ownedAnimationPolicy: ownedAnimationPolicies[version] } : {}) };
    if (focusedSuite) return run;
    const cases = animationCasesByVersion[version];
    run.version = version; run.relaunches = [];
    run.carrier = { label: 'Animation', prefix: 'kan-', proof: 'kittyAnimation', file: 'animation', suiteId: animationSuiteIds[version], Observer: version === currentAnimationVersion ? OwnedAnimationObserver : animationObserverOf(version),
        pixelDir: 'animation-pixels', inputDir: 'animation-inputs', planned: { experiments: cases.length, stages: cases.reduce((total, item) => total + item.stages.length, 0) },
        require() {}, state: () => run.animationState, setState: value => (run.animationState = value), priorFrames: () => [] };
    run.imageEnvironment = { appData, profileName, runId, proofs: run.proofs, get app() { return run.app; }, output, reference: undefined };
    return run;
}

/** The worker's first proof: the lineage and kernel terminal state every later restoration is checked against. */
function retainPersistentFirstProof(run, owner, worker, tty, budget) {
    if (run.proofs.length > 0) return;
    run.proofs.push({ privateClipboard: { policy: ownedPrivateClipboardPolicy, appBirth: processBirth(owner.pid, budget()), workerBirth: processBirth(worker.pid, budget()),
        outputDevice: outputDevice(tty), originalTerminalState: readOwnedTerminalState(tty, budget()) }, app: owner, worker, tty, at: new Date().toISOString(),
        ...(!focusedSuite ? { kittyAnimation: { policy: ownedAnimationPolicies[run.version] },
            ...(run.version === restoreAnimationVersion ? { relaunches: run.relaunches } : {}) } : {}) });
}

/** Admit one relaunch request and carry it out: the App is terminated and started again, and the answer follows once the new pane shows the restored screen. */
async function answerRelaunchRequest(run, request) {
    if (!run.outputModeVerified || run.version !== restoreAnimationVersion) throw new Error('A relaunch is only valid in the restore collection after the output proof.');
    admitRelaunch(run, request, animationSuites[run.version]);
    run.relaunchInFlight = relaunchPersistentApp(run);
    // A relaunch that fails after the outgoing App exited leaves nothing to finish the run: reject it with the cause instead of waiting for the deadline.
    try { await run.relaunchInFlight; } catch (error) { run.reject(error); throw error; }
    return {};
}

function requireScopedWorker(run, worker, budget) {
    if (!run.outputModeVerified) throw new Error('Private PTY output mode has not been verified.');
    const command = execFileSync('/bin/ps', ['-p', String(worker.pid), '-o', 'command='], { encoding: 'utf8', timeout: budget(), maxBuffer: 16384 });
    if (!matchesRecordedWorker(worker, run.identities.worker, command, run.runId)) throw new Error('Recorded worker identity or marker changed.');
}

function answerScopedObservation(run, request, budget, { owner, worker, daemon }) {
    requireScopedWorker(run, worker, budget);
    if (focusedSuite) {
        run.focusedState ??= new focusedSuite.Collection(run);
        const ownership = focusedSuite.imageOwnership ? { app: owner, worker, tty: request.tty, at: new Date().toISOString(),
            terminalOutput: readOwnedOutputMode(request.tty, budget()) } : undefined;
        return run.focusedState.observe(request, budget, ownership);
    }
    const { tty } = request;
    return observeImageCarrierIn(run.imageEnvironment, run.carrier, request, budget, { app: owner, worker, ...(daemon ? { daemon: daemon.record } : {}), tty, at: new Date().toISOString(),
        terminalOutput: readOwnedOutputMode(tty, budget()), ...(run.relaunches?.length ? { relaunch: run.relaunches.at(-1) } : {}) });
}

function finishScopedRequest(run, tty, budget) {
    if (focusedSuite) {
        if (!run.focusedState?.restored) throw new Error('Incomplete focused observations or pane restoration.');
    } else requireAnimationCompletion(run.animationState);
    const terminal = run.proofs[0].privateClipboard;
    if (readOwnedTerminalState(tty, budget()) !== terminal.originalTerminalState) throw new Error('Original private kernel mode was not restored.');
    Object.assign(terminal, { restoredTerminalState: terminal.originalTerminalState, restoredAt: new Date().toISOString() });
    run.completed = true;
    run.resolve();
    return {};
}

/** Answer one lineage-proved owner request of the scoped collection. */
async function answerPersistentRequest(run, request, budget, lineage) {
    const [proofs, tty] = [run.proofs, request.tty];
    if (request.kind === 'kan-relaunch') return answerRelaunchRequest(run, request);
    if (request.kind.startsWith(focusedSuite?.prefix ?? 'kan-')) return answerScopedObservation(run, request, budget, lineage);
    switch (request.kind) {
        case 'prove':
            retainPersistentFirstProof(run, lineage.owner, lineage.worker, tty, budget);
            return { privateClipboard: true, originalTerminalState: proofs[0].privateClipboard.originalTerminalState };
        case 'raw-output':
            if (run.outputModeVerified || !proofs.length) throw new Error('Unexpected private PTY output proof.');
            proofs[0].terminalOutput = { ...readOwnedOutputMode(tty, budget()), verifiedAt: new Date().toISOString() };
            run.outputModeVerified = true;
            return {};
        case 'done':
            return finishScopedRequest(run, tty, budget);
        case 'failed':
            run.reject(new Error(request.error ?? 'Worker failed.'));
            return {};
        default:
            throw new Error('Unknown owner request.');
    }
}

/** Authenticate one owner request, prove App, multiplexer daemon and worker lineage, then answer it. */
async function handlePersistentRequest(run, text) {
    const request = JSON.parse(text);
    if (typeof request.token !== 'string' || request.token.length !== run.token.length
        || !timingSafeEqual(Buffer.from(request.token), Buffer.from(run.token)) || request.runId !== run.runId) throw new Error('Invalid run capability.');
    const { app, executable, appData, runId } = run;
    if (!app?.pid || app.exitCode !== null || app.signalCode !== null) throw new Error('Owned app is no longer live.');
    assertExecutableUnchanged(executable, run.image);
    const budget = createProcessBudget(4000), owner = processRecord(app.pid, budget()), worker = processRecord(request.workerPid, budget());
    // An ordinary tab has no daemon: the worker must be the App's own child (assertProcessOwnership checks that when no daemon is passed).
    const daemon = isPersistentScope(run.collectionScope) ? readPersistentDaemon(worker.ppid, app.pid, appData, budget(), { firstAppBirth: run.proofs[0]?.privateClipboard?.appBirth }) : undefined;
    if (daemon && run.identities.daemon && run.identities.daemon.pid !== daemon.record.pid) throw new Error('Another multiplexer daemon tried to use this run.');
    assertProcessOwnership({ app: { ...owner, executable: realpathSync(owner.executable) }, worker, ownerPid: app.pid, executable, uid: process.getuid(), runId, tty: request.tty, daemon, appData,
        appCommand: execFileSync('/bin/ps', ['-p', String(app.pid), '-o', 'command='], { encoding: 'utf8', timeout: budget(), maxBuffer: 16384 }) });
    if (run.identities.worker && run.identities.worker.pid !== worker.pid) throw new Error('Another worker tried to use this run.');
    run.identities.worker ??= worker;
    if (daemon) {
        run.identities.daemon ??= persistentDaemonIdentity(daemon);
        run.daemonProof ??= { identity: run.identities.daemon, appData, command: `${daemon.record.executable} mux serve`, birth: daemon.birth, appBirth: daemon.appBirth, descriptor: daemon.descriptor };
    }
    return { ok: true, ownerPid: app.pid, ...(await answerPersistentRequest(run, request, budget, { owner, worker, daemon })) };
}

/** The owner socket: one bounded, authenticated request per connection; a refusal is answered, never thrown into the run. */
function createPersistentOwnerServer(run) {
    return createServer(socket => {
        let buffer = '';
        socket.setTimeout(5000, () => socket.destroy());
        socket.on('error', () => {});
        socket.on('data', async chunk => {
            buffer += chunk;
            if (buffer.length > 8192) return socket.destroy();
            if (!buffer.includes('\n')) return;
            socket.removeAllListeners('data');
            socket.setTimeout(90000, () => socket.destroy()); // a relaunch request outlives the five-second idle window of the others
            try { socket.end(JSON.stringify(await handlePersistentRequest(run, buffer.slice(0, buffer.indexOf('\n')))) + '\n'); }
            catch (error) { socket.end(JSON.stringify(ownerFailure(error, false)) + '\n'); }
        });
    });
}

/** Start (or restart) the owned App on the run's private root; the only call that launches one in the persistent collections. */
function startPersistentApp(run) {
    const app = launchOwnedApp(run.lease, run.executable, run.runId, run.env, run.logFd);
    run.app = app;
    app.once('error', run.reject);
    // Only the App a relaunch is replacing may exit unannounced; any other exit, the new App's during its start included, fails the run at once.
    app.once('exit', (code, signal) => { if (!run.completed && run.outgoing !== app) run.reject(new Error(`Owned app exited before collection (${code ?? signal}).`)); });
    return app;
}

/** The App's agent endpoint answers with this run's one local pane: the previous session was reattached or a fresh one spawned (the next lineage proof tells which). */
async function waitForReattachedPane(run, deadline = Date.now() + 60000) {
    if (run.stopping) throw new Error('The run stopped while the relaunched App was starting.');
    // The endpoint descriptor still names the previous App until the new one publishes its own, so the lookup itself may throw: that only means "not yet".
    const endpoint = () => observerEndpoint(run.appData, run.app.pid);
    const sessions = await Promise.resolve().then(() => agentRequest(endpoint(), 'listSessions', {}, 2000)).then(value => value.sessions, () => undefined);
    // The pane exists before its session attaches: wait until it shows the restored screen (the label line the carrier bound before the relaunch), so the first read sees the snapshot.
    const restored = sessions?.length === 1 && sessions[0].kind === 'local' && !sessions[0].windowless && sessions[0].profileName === run.profileName
        && await agentRequest(endpoint(), 'readScreen', { paneId: sessions[0].paneId }, 2000).then(screen => screen.lines?.[0] === 'NTILDE_IMG_' + run.runId, () => false);
    if (run.stopping) throw new Error('The run stopped while the relaunched App was starting.');
    if (restored) return;
    if (Date.now() > deadline) throw new Error('The relaunched App did not show the persistent pane.');
    await new Promise(resolve => setTimeout(resolve, 250));
    await waitForReattachedPane(run, deadline);
}

/**
 * Terminate the App (SIGTERM, not a graceful quit) and start it again on the same private root while the multiplexer daemon and the worker keep running (`KeepOnClose`). The App
 * saves its session after each attach, so a killed App leaves the file the next one restores; the new App's pane reattaches `IfUnattached`.
 */
async function relaunchPersistentApp(run) {
    const previous = run.app;
    run.outgoing = previous;
    try {
        const { escalated } = await terminateLaunchedApp(previous);
        if (run.stopping) throw new Error('The run stopped before the App was started again.');
        for (const [what, pid] of [['shell', run.identities.worker.pid], ['multiplexer daemon', run.identities.daemon.pid]]) {
            if (!workerExists(pid)) throw new Error(`The ${what} ended with the App.`);
        }
        const startedAt = new Date().toISOString(), next = startPersistentApp(run);
        await waitForReattachedPane(run);
        run.relaunches.push({ from: previous.pid, to: next.pid, appBirth: processBirth(next.pid), startedAt, at: new Date().toISOString(), terminatedBy: escalated ? 'SIGKILL' : 'SIGTERM' });
    } finally { run.outgoing = undefined; }
}

/** Start the disposable App and wait for the worker's completion; the evidence is retained only for a restored, sealed suite. */
async function collectPersistentAnimation(run, server) {
    const { output, runId, appData, args, collectionScope } = run;
    await Promise.race([run.done, new Promise((resolve, reject) => { server.once('error', reject); server.listen(run.socketPath, resolve); })]);
    if (run.interruption) throw run.interruption;
    chmodSync(run.socketPath, 0o600);
    const env = { ...process.env, NTILDE_APPDATA_ROOT: appData, TERMINFO_RUN_ID: runId, TERM_PROGRAM: 'Ntilde', TERM_PROGRAM_VERSION: args[3], PATH: dirname(process.execPath) + ':' + process.env.PATH };
    for (const name of ['__CFBundleIdentifier', 'TMUX', 'STY', 'SSH_CONNECTION', 'SSH_TTY']) delete env[name];
    run.logFd = openSync(join(output, 'app-output.log'), 'wx', 0o600);
    run.env = focusedSuite?.prepareLaunchEnvironment?.(run, env) ?? env;
    startPersistentApp(run);
    writeJson(join(output, 'context.json'), { ...run.context, ownerPid: run.app.pid });
    run.deadline = setTimeout(() => run.reject(new Error(`Persistent animation collection exceeded ${collectionScope.deadlineMs / 60000} minutes.`)), collectionScope.deadlineMs);
    console.log(`Collecting in disposable Ntilde pid ${run.app.pid} (${isPersistentScope(collectionScope) ? 'persistent' : 'ordinary'} tab); results: ${output}`);
    await run.done;
    assertOwnedSourcesUnchanged(sourceRepo, run.context);
    if (focusedSuite) return {};
    if (run.animationState?.unavailable) throw new Error('Persistent animation fixture was unavailable: ' + run.animationState.unavailable.reason);
    return { animationEvidence: retainCellReport(output, run.animationState?.observer, runId, () => run.animationState.observer.report, 'animation-observations.json') };
}

/**
 * Collect only the Kitty animation suite in a persistent (mux-backed, KeepOnClose) tab. The App starts the multiplexer daemon, which
 * hosts the worker, so ownership is proved through that daemon (ownership.mjs) and cleanup stops it. No other owned suite runs and the
 * full collection's receipt is not produced: this run has its own, narrower receipt.
 */
async function persistentAnimationMain(args, executable, snapshot, collectionScope) {
    let interruption, run, output, lease, resolveDone, rejectDone;
    const done = new Promise((resolve, reject) => { resolveDone = resolve; rejectDone = reject; });
    done.catch(() => {});
    const interrupted = signal => { interruption ??= new Error(`Interrupted by ${signal}.`); process.exitCode = 1; rejectDone(interruption); };
    const handlers = ['SIGINT', 'SIGTERM', 'SIGHUP'].map(signal => [signal, () => interrupted(signal)]);
    for (const [signal, handler] of handlers) process.on(signal, handler);
    if (['SIGINT', 'SIGTERM', 'SIGHUP'].includes(process.env.NTILDE_TERMINFO_PENDING_SIGNAL)) interrupted(process.env.NTILDE_TERMINFO_PENDING_SIGNAL);
    try {
        lease = await acquireDesktopLease(() => interruption);
        mkdirSync(join(repo, 'artifacts', 'terminfo'), { recursive: true });
        output = mkdtempSync(join(repo, 'artifacts', 'terminfo', 'owned-'));
        writeFileSync(join(output, 'source-snapshot.json'), snapshot.bytes, { flag: 'wx', mode: 0o600 });
        run = preparePersistentRun(args, executable, snapshot, lease, output, collectionScope);
        Object.assign(run, { done, resolve: resolveDone, reject: error => { run.stopping = true; rejectDone(error); } });
        Object.defineProperty(run, 'interruption', { get: () => interruption });
        if (interruption) throw interruption;
        const outcome = await runPersistentAnimation(run);
        if (interruption) throw interruption;
        console.log(JSON.stringify({ runId: run.runId, output,
            ...(focusedSuite ? { verdict: outcome.receipt.verdict } : { counts: outcome.receipt.animationEvidence.counts }) }, null, 2));
    } catch (error) {
        retainPreparationFailure(output, error);
        throw error;
    } finally {
        try { if (run?.scratch && !run.preserveScratch) rmSync(run.scratch, { recursive: true, force: true }); }
        finally { for (const [signal, handler] of handlers) process.removeListener(signal, handler); }
    }
}

/** Run, clean up (the App, worker and daemon), then finish the receipt: a failure keeps the fixture and the evidence. */
async function runPersistentAnimation(run) {
    const server = createPersistentOwnerServer(run);
    let evidence, failure;
    const collect = () => collectPersistentAnimation(run, server);
    try { evidence = await (focusedSuite?.withFixture ? focusedSuite.withFixture(run, collect) : collect()); }
    catch (error) { failure = error; }
    clearTimeout(run.deadline);
    // A relaunch still in flight must finish (or give up) before cleanup, or its new App could outlive the cleanup that targets the old one.
    run.stopping = true;
    await run.relaunchInFlight?.catch(() => {});
    run.preserveScratch = true;
    const cleanup = await captureOwnedCleanup(() => cleanupOwnedRun({ lease: run.lease, workerIdentity: run.identities.worker, daemonIdentity: run.identities.daemon, daemonProof: run.daemonProof,
        executable: run.executable, appData: run.appData, runId: run.runId, app: run.app, logFd: run.logFd, server, output: run.output, proofs: run.proofs, completed: run.completed,
        scratch: run.scratch, collectionScope: run.collectionScope }));
    run.preserveScratch = cleanup.failed;
    if (failure) retainOwnedFailure(run.output, failure, undefined);
    throwOwnedRunFailures({ failed: failure !== undefined, error: failure }, cleanup);
    rmSync(run.scratch, { recursive: true, force: true });
    assertOwnedSourcesUnchanged(sourceRepo, run.context);
    removeSourceSnapshot(sourceRepo);
    const proofPath = join(run.output, 'ownership-proof.json'), proof = JSON.parse(readFileSync(proofPath));
    proof.sourceSnapshot = { policy: sourceSnapshotPolicy, root: sourceRepo, removedAt: new Date().toISOString() };
    writeFileSync(proofPath, JSON.stringify(proof, null, 2) + '\n', { mode: 0o600 });
    return { receipt: focusedSuite ? focusedSuite.completeReceipt(run.output, run.scratch)
        : completePersistentAnimationReceipt(run.output, run.scratch, evidence) };
}

try {
    await main();
} catch (error) {
    console.error(`[terminfo-owned] ${error.message}`);
    process.exitCode = 1;
}
import { adaptReflowCollector, asciiReflowAdapterId } from './terminfo/ascii-reflow-grading-collector.mjs';
import { asciiReflowContractsVersion, asciiReflowSuiteId, ownedAsciiReflowPolicy } from './terminfo/ascii-reflow-contracts.mjs';
import { buildReflowReport, reflowCounts } from './terminfo/ascii-reflow-grading.mjs';
import { OwnedReflowObserver } from './terminfo/ascii-reflow-observer.mjs';
