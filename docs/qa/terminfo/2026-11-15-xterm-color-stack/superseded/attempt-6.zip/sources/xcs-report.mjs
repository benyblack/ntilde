// Bounded owned xterm color-stack exchanges. One request list earns a bounded *sequence* of complete OSC color replies followed by the DA barrier that orders the exchange. Every reply is retained
// byte for byte; whether it is the right reply for the request is the contract's business, never this parser's. A complete DA barrier with no reply before it is an explicitly absent reply list
// (the silence of a push or pop), never a reply guessed from state.
const esc = '\x1b';
/** A complete DA reply: ESC, then [?, parameters and c (the ESC is checked outside the pattern). */
const isBarrier = text => typeof text === 'string' && text.startsWith(esc) && /^\[\?[\d;]+c$/.test(text.slice(1));
/** The longest string-reply body (the bytes between the introducer and ST) one retained reply may hold. */
const bodyLimit = 128;
/** The most replies one exchange may retain. */
export const xcsReplyLimit = 8;
/** The longest exchange: bounded replies plus a DA barrier. */
const exchangeLimit = 1024;

/** The fence's expectation tag for one xterm color-stack exchange (identity-compared, never parsed). */
export const xcsReportExpectation = Object.freeze({ kind: 'xterm-color-stack' });

/** Whether `text` is ESC ], at most 128 bytes without ESC, then (when `closed`) ST or (when not) at most a lone trailing ESC. */
function stringShape(text, closed) {
    if (!text.startsWith(esc + ']')) return false;
    let body = text.slice(2);
    if (closed) {
        if (!body.endsWith(esc + '\\')) return false;
        body = body.slice(0, -2);
    } else if (body.endsWith(esc)) {
        body = body.slice(0, -1);
    }
    return body.length <= bodyLimit && !body.includes(esc);
}

/** The most bytes one retained reply (an OSC string, or an unexpected chunk of other bytes) may hold. */
const replyLimit = 160;
/** A DA reply anywhere in a string: the barrier that orders an exchange. */
const barrierAnywhere = /\x1b\[\?[\d;]+c/;

/** Refuse anything but one bounded reply: a complete OSC string, or an unexpected chunk of other bytes (a push or pop that answers with anything is evidence, not an error). Neither may hold a DA barrier. */
export function parseXcsReply(raw) {
    if (typeof raw !== 'string' || raw.length === 0 || raw.length > replyLimit || barrierAnywhere.test(raw)) throw new Error('Unexpected xterm-color-stack reply.');
    return { raw };
}

/** Where one OSC reply ends in `rest` (at its ST or its BEL, whichever comes first), or -1 while incomplete. */
function replyEnd(rest) {
    const st = rest.indexOf(esc + '\\'), bel = rest.indexOf('\x07');
    if (st < 0 && bel < 0) return -1;
    if (bel >= 0 && (st < 0 || bel < st)) return bel + 1;
    return st + 2;
}

/**
 * Parse the accumulated bytes of one exchange: any number of complete bounded replies followed by the DA barrier. A reply is a complete OSC string or, for bytes that are not an OSC string, one unexpected
 * chunk up to the barrier (retained byte for byte: the pinned probe treats any output as an invalid reply and the contract as a mismatch). Null means incomplete. A complete DA without a reply is an
 * explicitly absent reply list, never a reply guessed from state.
 */
export function parseXcsFrame(bytes) {
    if (typeof bytes !== 'string' || bytes.length > exchangeLimit) throw new Error('Oversized xterm-color-stack barrier.');
    const replies = [];
    let rest = bytes;
    for (;;) {
        const length = rest.startsWith(esc + ']') ? replyEnd(rest) : -1;
        // An OSC string that never terminates before a DA barrier is not a reply: it falls through and is retained as an unexpected chunk.
        if (rest.startsWith(esc + ']') && length < 0 && !barrierAnywhere.test(rest)) {
            // A barrier may still be arriving: a trailing partial DA reply (ESC, ESC [, ESC [ ? and digits) is not part of the string.
            if (!stringShape(rest.replace(/\x1b(?:\[(?:\?[\d;]*)?)?$/, ''), false)) throw new Error('Unexpected xterm-color-stack bytes.');
            return null;
        }
        if (length >= 0) {
            if (replies.length === xcsReplyLimit) throw new Error('Too many xterm-color-stack replies.');
            replies.push(parseXcsReply(rest.slice(0, length)).raw);
            rest = rest.slice(length);
            continue;
        }
        if (!rest || (esc + '[?').startsWith(rest)) return null;
        if (isBarrier(rest)) return { barrier: rest, replies };
        const barrier = barrierAnywhere.exec(rest);
        if (barrier === null) {
            if (rest.length > replyLimit + 32) throw new Error('Oversized xterm-color-stack reply.');
            return null;
        }
        if (barrier.index === 0) {
            // A complete DA reply followed by more bytes is not a single barrier.
            if (rest.length !== barrier[0].length) throw new Error('Unexpected xterm-color-stack barrier bytes.');
            return { barrier: rest, replies };
        }
        if (replies.length === xcsReplyLimit) throw new Error('Too many xterm-color-stack replies.');
        replies.push(parseXcsReply(rest.slice(0, barrier.index)).raw);
        rest = rest.slice(barrier.index);
    }
}

/** A retained exchange: its raw replies (or explicit absence) and DA barrier. */
export function validateXcsExchange(value) {
    if (!value || typeof value !== 'object' || Object.keys(value).length !== 2 || !isBarrier(value.barrier)
        || value.barrier.length > 128 || !Array.isArray(value.replies) || value.replies.length > xcsReplyLimit) {
        throw new Error('Invalid retained xterm-color-stack report.');
    }
    return { barrier: value.barrier, replies: value.replies.map(raw => parseXcsReply(raw).raw) };
}
