using Ntilde.Shell;
using Ntilde.Shell.Backup;
using Avalonia;
using Avalonia.Media;
using System;
using Ntilde.Platform;
using Ntilde.Pty;
using Ntilde.VT;
using Velopack;

namespace Ntilde;

class Program
{
    // Initialization code. Don't use any Avalonia, third-party APIs or any
    // SynchronizationContext-reliant code before AppMain is called: things aren't initialized
    // yet and stuff might break.
    [STAThread]
    public static void Main(string[] args)
    {
        try
        {
            // Velopack install/update/uninstall hooks re-invoke this exe with their own
            // arguments and expect to be serviced before anything else happens - including
            // before our own CLI-mode dispatch below, which would otherwise treat a hook
            // argument as an unrecognised command line. Run() returns immediately for a
            // normal launch, and exits the process for a hook invocation. Harmless when the
            // app was not installed by Velopack (portable zip, winget, dev runs).
            //
            // Velopack also applies an already-downloaded update here by default. That must not
            // happen behind a live multiplexer daemon the apply would kill - one running from inside
            // the install root (Phase 5 R10) - nor, with SessionPersistence off, behind any live daemon,
            // as before Phase 5: the in-app apply path asks before closing its sessions and shuts it
            // down first, and this one would do neither (spec §9).
            _ = Ntilde.Shell.Clipboard.PrivateClipboardQaMode.Process;

            VelopackApp velopack = VelopackApp.Build();

            // The install directory goes on the user PATH, so a prompt finds ntilde.com there
            // (Phase 4 spec §11.4). Fast callbacks run only when Velopack starts this exe for that
            // stage, and the process exits after them; a normal start never reaches them. Velopack
            // offers them on Windows only, which is where they are needed.
            //
            // Uninstall also stops the local multiplexer daemon and removes its copies (Phase 5 Task 21): the daemon runs
            // from a copy outside the install root, so the uninstall would otherwise leave it, and every shell, running.
            // First, within the hook's time budget: the PATH's WM_SETTINGCHANGE broadcast can wait seconds on hung windows.
            if (OperatingSystem.IsWindows())
            {
                velopack = velopack
                    .OnAfterInstallFastCallback(static _ => UserPathRegistration.Ensure(InstallDirectory()))
                    .OnAfterUpdateFastCallback(static _ => UserPathRegistration.Ensure(InstallDirectory()))
                    .OnBeforeUninstallFastCallback(static _ =>
                    {
                        Ntilde.Shell.Mux.MuxUninstall.Run();
                        UserPathRegistration.Remove(InstallDirectory());
                    });
            }

            velopack
                .SetAutoApplyOnStartup(ShouldAutoApplyUpdateOnStartup(args, LiveDaemonBlocksStartupApply))
                .Run();

            if (VtReportCommand.IsSupportedCliMode(args))
            {
                CliConsoleBindings.Prepare();
                Environment.ExitCode = VtReportCommand.Execute(args, Console.Out, Console.Error);
                return;
            }

            if (SshAskPassCommand.IsSupportedCliMode(args))
            {
                CliConsoleBindings.Prepare();
                Environment.ExitCode = SshAskPassCommand.Execute(args, Console.Out, Console.Error);
                return;
            }

            // Headless replay (A4) — the self-contained AOT bundle ships no separate
            // Ntilde.Cli, so the app executable serves `--replay <file>` itself.
            // Rooting ReplayCommand here also keeps AOT trimming from dropping it.
            if (ReplayCommand.IsSupportedCliMode(args))
            {
                CliConsoleBindings.Prepare();
                Environment.ExitCode = ReplayCommand.Execute(args, Console.Out, Console.Error);
                return;
            }

            // Same reasoning as ReplayCommand above: `backup` must be servable by this
            // executable directly, because the AOT/self-contained bundle this dispatch chain
            // exists for ships no Ntilde.Cli. Task 7 originally wired BackupCommand only
            // into the dev-only Cli shim, which left it unreachable (falling through to the GUI
            // launch below) in exactly the build shape this feature has to work in. Rooting it
            // here also keeps AOT trimming from dropping it, same as ReplayCommand.
            if (BackupCommand.IsSupportedCliMode(args))
            {
                CliConsoleBindings.Prepare();
                Environment.ExitCode = BackupCommand.Execute(args, Console.Out, Console.Error);
                return;
            }

            if (Ntilde.Shell.Mux.MuxCommand.IsSupportedCliMode(args))
            {
                // ntilde.com waits for a mux verb's exit code, so its release event is not for us - and
                // the daemon `attach` may start would pass it on to every shell it hosts (spec §11.3).
                LauncherRelease.Discard();

                // serve is a daemon: it must not attach to the launching console (it detaches from it).
                // attach (and probe-console, which mirrors it) is interactive: it needs a real console, allocated if the parent has none.
                if (Ntilde.Shell.Mux.MuxCommand.NeedsInteractiveConsole(args)) Ntilde.Shell.Mux.MuxCommand.AttachedToParentConsole = CliConsoleBindings.PrepareInteractive();
                else if (!Ntilde.Shell.Mux.MuxCommand.IsServe(args)) CliConsoleBindings.Prepare();
                Environment.ExitCode = Ntilde.Shell.Mux.MuxCommand.Execute(args, Console.Out, Console.Error);
                return;
            }

            // No CLI mode matched: this is the GUI. When ntilde.com started us it is waiting for our exit
            // code with the prompt blocked; release it now, before any startup work (spec §11.3).
            LauncherRelease.Signal();

            // Attach the debug-log sink before anything logs. Placed after the CLI dispatches
            // above, which return without ever writing to it — a `--replay` or `backup`
            // invocation has no business truncating the GUI's log.
            AppLogger.Initialize();

            // The PTY layer cannot reference VT (Pty_must_not_depend_on_Vt), so it reports through its
            // own sink; bridge it here so its diagnostics reach the same debug log as everything else.
            // Before #109 they went to Console.WriteLine, i.e. nowhere in a GUI process.
            PtyLogger.Sink = static (level, message) => TerminalLogger.Log(ToLogLevel(level), message);

            // Narrow the library default (Debug) to what a shipping app should keep. Debug is
            // where the per-event diagnostics live — every unhandled control sequence, every
            // cursor-blink decision — and they are produced on the parse and render threads at
            // the rate the remote sends bytes. Kept behind an env var rather than a build flag so
            // a bug report can ask for the detail without asking for a debug build.
            TerminalLogger.MinimumLevel = ResolveLogLevel();

            // Log startup info
            TerminalLogger.Log("Ntilde started with args: " + string.Join(" ", args));
            TerminalLogger.Log("Log file path: " + AppLogger.GetLogFilePath());
            TerminalLogger.Log("Build: " + DescribeBuild());

            // Why Velopack was told not to apply a staged update at this start, decided before the log was up.
            if (Ntilde.Update.MuxUpdateCompatibility.DescribeStartupApplyHold(s_startupApplyHold) is { } held) TerminalLogger.Log(held);

            // A verification run's local update feed (NTILDE_UPDATE_SOURCE_DIR), or a value of it that is ignored: said
            // at startup, before any update check, so the log never hides where updates come from. Only the verification
            // install honours it (ruling R1), so the running install's app id goes in: VelopackApp.Run() above has set
            // the locator by now when this process is a Velopack install, and nothing has when it is not.
            string? veloAppId = Velopack.Locators.VelopackLocator.IsCurrentSet ? Velopack.Locators.VelopackLocator.Current.AppId : null;
            _ = Ntilde.Update.UpdateSourceOverride.ResolveFromEnvironment(veloAppId, out string? updateSourceNote);
            if (updateSourceNote is not null) TerminalLogger.Log(updateSourceNote);

            StartupPerformanceTracker.StartNewCurrent();

            // GUI path only (CLI and installer-hook invocations returned above), and not from App:
            // headless tests build App too and must not get a background full-GC timer.
            IdleMemoryReclaimer.Start();

            BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        }
        catch (Exception ex)
        {
            TerminalLogger.Log("Startup error: " + ex.ToString());
            AppPaths.EnsureInitialized();
            System.IO.File.WriteAllText(AppPaths.StartupErrorFilePath, ex.ToString());
            throw;
        }
    }

    /// <summary>
    /// Whether Velopack may apply a staged update while starting up. Never for a <c>mux</c> CLI mode
    /// (the daemon, or a verb talking to it), and not for the GUI while a live daemon is in the
    /// apply's way (<see cref="LiveDaemonBlocksStartupApply"/>): in both cases the staged update waits
    /// for the in-app apply, which confirms and stops the daemon. <paramref name="liveDaemon"/> is
    /// only asked for the GUI case, so CLI starts never read the disk.
    /// </summary>
    internal static bool ShouldAutoApplyUpdateOnStartup(string[] args, Func<bool> liveDaemon) =>
        ShouldAutoApplyUpdateOnStartup(args, liveDaemon, Environment.GetEnvironmentVariable);

    /// <summary>
    /// <see cref="ShouldAutoApplyUpdateOnStartup(string[], Func{bool})"/>, reading the environment through
    /// <paramref name="environment"/>. Never for the askpass helper either: ssh starts this executable for a prompt with
    /// nobody necessarily at the screen (an automatic reconnect), the mode set by flag or by <c>NTILDE_SSH_ASKPASS=1</c>.
    /// </summary>
    internal static bool ShouldAutoApplyUpdateOnStartup(string[] args, Func<bool> liveDaemon, Func<string, string?> environment)
    {
        ArgumentNullException.ThrowIfNull(args);
        ArgumentNullException.ThrowIfNull(liveDaemon);
        ArgumentNullException.ThrowIfNull(environment);
        if (Ntilde.Shell.Mux.MuxCommand.IsSupportedCliMode(args)) return false;
        if (SshAskPassCommand.IsSupportedCliMode(args, environment)) return false;
        return !liveDaemon();
    }

    /// <summary>
    /// The startup gate's question (Phase 5 R10): is a live local daemon in the apply's way? One Velopack's apply would
    /// kill - its image inside this install's root, or not known to be outside it - always is; a daemon running from its
    /// own copy (<see cref="Ntilde.Shell.Mux.MuxDaemonImage"/>) survives the apply and holds the update back only with
    /// SessionPersistence off, which keeps the gate as it was before Phase 5. "Live" means a daemon that answers a 200 ms
    /// probe-connect, not merely a descriptor naming a pid that happens to still be alive - pids get recycled
    /// (<see cref="Ntilde.Mux.Daemon.MuxStartupProbe"/>). Only then are the descriptor, the image (one process lookup)
    /// and the setting read - the setting straight from settings.json under the same root the descriptor is in
    /// (<see cref="Ntilde.Shell.Mux.SessionPersistenceMode.IsOffInSettingsFile"/>; AppPaths is not touched this early).
    /// </summary>
    private static bool LiveDaemonBlocksStartupApply()
    {
        s_startupApplyHold = StartupApplyHoldAt(Ntilde.Mux.Contracts.MuxDiscovery.GetRootDirectory(), Ntilde.Shell.Mux.MuxDaemonImage.CurrentVelopackInstallRoot());
        return s_startupApplyHold != Ntilde.Update.StartupApplyHold.None;
    }

    /// <summary>
    /// What the startup gate decided (<see cref="LiveDaemonBlocksStartupApply"/>), kept for debug.log: the gate runs before
    /// AppLogger is up, and Main logs why it held once it is (PR #511 heads-up). None when it did not hold or never ran.
    /// </summary>
    private static Ntilde.Update.StartupApplyHold s_startupApplyHold;

    /// <summary>
    /// <see cref="LiveDaemonBlocksStartupApply"/>'s composition for the app-data root <paramref name="appDataRoot"/>: the
    /// gate's reason (<see cref="Ntilde.Update.MuxUpdateCompatibility.StartupApplyHoldFor"/>; any but None holds), with the
    /// descriptor and settings.json both read under that root. <paramref name="installRoot"/> is this install's Velopack
    /// root (null when there is none); <paramref name="connect"/> is the probe's connect, and <paramref name="daemonImagePath"/>
    /// the descriptor's daemon's image (<see cref="Ntilde.Update.MuxUpdateCompatibility.DaemonImagePath"/>), seams for tests.
    /// </summary>
    internal static Ntilde.Update.StartupApplyHold StartupApplyHoldAt(string appDataRoot, string? installRoot, Func<string, TimeSpan, System.IO.Stream>? connect = null,
        Func<Ntilde.Mux.Contracts.MuxEndpointDescriptor, string?>? daemonImagePath = null)
    {
        string descriptorPath = Ntilde.Mux.Contracts.MuxDiscovery.GetDescriptorPath(appDataRoot);
        return Ntilde.Update.MuxUpdateCompatibility.StartupApplyHoldFor(
            installRoot,
            () => Ntilde.Mux.Daemon.MuxStartupProbe.IsDaemonLive(descriptorPath, TimeSpan.FromMilliseconds(200), connect),
            () => Ntilde.Mux.Contracts.MuxDiscovery.TryReadDescriptor(descriptorPath, out Ntilde.Mux.Contracts.MuxEndpointDescriptor? descriptor) ? descriptor : null,
            daemonImagePath ?? Ntilde.Update.MuxUpdateCompatibility.DaemonImagePath,
            () => Ntilde.Shell.Mux.SessionPersistenceMode.IsOffInSettingsFile(System.IO.Path.Combine(appDataRoot, "settings.json")));
    }

    /// <summary>
    /// The directory a Velopack hook runs this exe from: the install's stable <c>current</c> folder, which
    /// holds ntilde.com beside it (spec §11.4). Null only if the process path is unknown, which
    /// <see cref="UserPathRegistration"/> logs and skips.
    /// </summary>
    private static string? InstallDirectory() => System.IO.Path.GetDirectoryName(Environment.ProcessPath);

    /// <summary>
    /// Maps the PTY layer's severity onto the app's.
    /// </summary>
    /// <remarks>
    /// Written out rather than cast. The two enums happen to agree member-for-member today, so
    /// <c>(LogLevel)level</c> would work and would keep working right up until someone inserted a member
    /// into one of them, at which point every PTY message would be silently mislevelled.
    /// <c>PtyLogLevelsMatchAppLogLevels</c> in the architecture tests pins the correspondence.
    /// </remarks>
    /// <summary>
    /// The debug log's threshold, from <c>NTILDE_LOG_LEVEL</c> (debug|info|warning|error).
    /// Defaults to Info: enough for the startup banner, the session lifecycle and every warning
    /// or error, without the per-event stream that made <c>debug.log</c> grow by gigabytes a day.
    /// </summary>
    internal static LogLevel ResolveLogLevel()
    {
        string? requested = Environment.GetEnvironmentVariable("NTILDE_LOG_LEVEL");
        if (string.IsNullOrWhiteSpace(requested))
        {
            return LogLevel.Info;
        }

        return requested.Trim().ToLowerInvariant() switch
        {
            "debug" or "trace" or "verbose" => LogLevel.Debug,
            "info" => LogLevel.Info,
            "warning" or "warn" => LogLevel.Warning,
            "error" => LogLevel.Error,
            // An unrecognized value is a typo in a diagnostic knob, and silently keeping the
            // default is how someone spends an afternoon wondering where their logs went.
            _ => LogLevel.Debug,
        };
    }

    internal static LogLevel ToLogLevel(PtyLogLevel level) => level switch
    {
        PtyLogLevel.Debug => LogLevel.Debug,
        PtyLogLevel.Info => LogLevel.Info,
        PtyLogLevel.Warning => LogLevel.Warning,
        PtyLogLevel.Error => LogLevel.Error,
        _ => LogLevel.Info,
    };

    // Identifies exactly which build is running, so a stale side-by-side copy is obvious
    // in debug.log. Reports git SHA (stamped at compile via the StampGitInfo MSBuild target),
    // the binary path, and its on-disk build time. This is the line that would have
    // immediately flagged the "net10.0 - Copy" stale-binary crash incident.
    internal static string DescribeBuild()
    {
        var asm = System.Reflection.Assembly.GetExecutingAssembly();

        string sha = "unknown";
        foreach (var meta in asm.GetCustomAttributes(typeof(System.Reflection.AssemblyMetadataAttribute), false))
        {
            if (meta is System.Reflection.AssemblyMetadataAttribute m && m.Key == "GitSha")
            {
                sha = string.IsNullOrEmpty(m.Value) ? "unknown" : m.Value;
                break;
            }
        }

        // Environment.ProcessPath is correct under both normal and single-file/AOT hosting;
        // Assembly.Location is always empty under single-file/AOT (IL3000), so it is no fallback.
        string path = Environment.ProcessPath ?? string.Empty;
        string builtAt = "?";
        try
        {
            if (!string.IsNullOrEmpty(path) && System.IO.File.Exists(path))
            {
                builtAt = System.IO.File.GetLastWriteTime(path).ToString("yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
            }
        }
        catch
        {
            // Best-effort diagnostics only — never let build-info logging break startup.
        }

        return $"sha={sha} built={builtAt} path={path}";
    }

    // Avalonia configuration, don't remove; also used by visual designer.
    public static AppBuilder BuildAvaloniaApp()
        => AppBuilder.Configure<App>()
            .UsePlatformDetect()
            // MainWindow is a client-side-decorated window: ExtendClientAreaToDecorationsHint plus
            // NtildeWindowDecorationsTheme (App.axaml) draw our own min/max/close buttons, and the
            // title bar overlay reserves a 140px right margin for them. On Windows and macOS that
            // opt-in is enough. On X11 - which is what Linux gets from UsePlatformDetect, including
            // under Wayland compositors via XWayland - Avalonia 12 gates drawn decorations behind
            // this backend option, default false: without it IsExtendedIntoWindowDecorations stays
            // false, the decorations theme is never instantiated, and the caption buttons simply do
            // not exist. Under a compositor that draws no titlebar of its own (Hyprland, Sway) the
            // window then has no close/maximize/minimize affordance at all, and the reserved 140px
            // sits empty. Not Force*: only windows that opt in should get CSD, so SettingsWindow,
            // AboutWindow, ConnectionManagerWindow and ReplayWindow keep their WM decorations.
            //
            // Expect close ALONE on a tiling compositor, and that is correct rather than a leftover
            // of the bug: the theme hides minimize/maximize on :not(:has-minimize)/:not(:has-maximize),
            // and X11 sets neither pseudoclass unless the window manager advertises the action. On
            // Hyprland it does not, and measured behaviour agrees - setting WindowState to Maximized
            // or Minimized there leaves it at Normal, so those two buttons would be inert. The same
            // theme shows all three under a WM that does advertise them.
            //
            // Experimental in 12.0.4 ("used mostly for testing"), hence the suppression. Recheck on
            // the next Avalonia bump: if the flag graduates, drop the pragma; if it is removed,
            // this call is what has to be replaced, not the XAML.
#pragma warning disable AVALONIA_X11_CSD
            .With(new X11PlatformOptions { EnableDrawnDecorations = true })
#pragma warning restore AVALONIA_X11_CSD
            .WithInterFont()
            .With(new FontManagerOptions
            {
                FontFamilyMappings = BundledFontCatalog.CreateFontFamilyMappings(),
                DefaultFamilyName = BundledFontCatalog.DefaultTerminalFontFamily
            })
            .LogToTrace();
}
