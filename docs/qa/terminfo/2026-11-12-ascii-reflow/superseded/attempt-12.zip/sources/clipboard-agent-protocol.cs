namespace Ntilde.AgentHost.Contracts;

/// <summary>
/// Protocol constants for the agent-host control channel between the running
/// app (endpoint) and the MCP server (client). See
/// docs/plans/2026-07-07-agent-host-a1-observe-design.md.
///
/// Wire format: newline-delimited JSON frames (<see cref="AgentHostRequest"/> /
/// <see cref="AgentHostResponse"/>), UTF-8, one frame per line. The transport
/// is a per-user local endpoint: a named pipe on Windows
/// (<see cref="WindowsPipeNamePrefix"/> + user SID, CurrentUserOnly), a unix
/// domain socket (mode 0600) on Linux/macOS. The endpoint is discovered via
/// <see cref="DiscoveryFileName"/> next to settings.json.
/// </summary>
public static class AgentHostProtocol
{
    /// <summary>Limits for the explicitly requested stored-cell projection of readScreen.</summary>
    public const int MaxCellDetailCells = 8192;
    public const int MaxCellDetailRuns = 1024;

    /// <summary>Bounds on explicitly requested visible-pane grids.</summary>
    public const int MaxResizeRows = 128;
    public const int MaxResizeCols = 256;

    /// <summary>
    /// Wire protocol version. The server rejects requests whose version does
    /// not match with <see cref="ErrorCodes.VersionMismatch"/>.
    /// </summary>
    public const int Version = 1;

    /// <summary>Discovery file written next to settings.json while the endpoint is up.</summary>
    public const string DiscoveryFileName = "agent-endpoint.json";

    /// <summary>Windows named-pipe name prefix; the user SID is appended.</summary>
    public const string WindowsPipeNamePrefix = "ntilde-agent-";

    /// <summary>Unix domain socket file name (created in the app's runtime directory).</summary>
    public const string UnixSocketFileName = "agent.sock";

    /// <summary>Server-side cap on scrollback lines returned per request.</summary>
    public const int MaxScrollbackLinesPerRequest = 2000;

    /// <summary>Server-side cap on a waitForEvents long-poll (client read timeouts must exceed this).</summary>
    public const int MaxWaitForEventsTimeoutMs = 25_000;

    /// <summary>Capacity of the server's event ring; older events are evicted and reported via oldestSeq.</summary>
    public const int EventRingCapacity = 256;

    /// <summary>
    /// Per-session retention budget for the flight recorder ring behind
    /// <c>exportReplay</c> (A4): total payload bytes plus a fixed per-event
    /// overhead of recent raw output/resize events kept in memory while the
    /// observe endpoint is running.
    /// </summary>
    public const long FlightRecorderMaxBytesPerSession = 2 * 1024 * 1024;

    /// <summary>Subfolder of the recordings directory where agent-triggered exports land (A4).</summary>
    public const string AgentExportsSubdirectory = "agent-exports";

    /// <summary>
    /// Ceiling on the pixel area a single <c>captureScreen</c> may render (A5).
    /// A pane's image is its whole grid at 1:1, so a very large window on a very
    /// small font could otherwise ask for a bitmap of hundreds of megabytes.
    /// </summary>
    public const long MaxCapturePixels = 16_000_000;

    /// <summary>Maximum detached image entries in one opt-in capture. Overflow is explicit/incomplete.</summary>
    public const int MaxCaptureImagePlacements = 512;

    /// <summary>
    /// Ceiling on a PNG returned inline (base64 in the result frame) by
    /// <c>captureScreen</c>. Past this the file is still written and its path
    /// returned; only the inline copy is dropped, so one screenshot cannot
    /// flood the caller's context or the NDJSON channel.
    /// </summary>
    public const int MaxInlineCaptureBytes = 3 * 1024 * 1024;

    /// <summary>Bounded synthetic presentation time for controlled offscreen captures.</summary>
    public const long MaxCapturePresentationTimeMs = 60_000;

    /// <summary>
    /// Ceiling on <c>captureScreen</c>'s render scale. A pane renders at 1 device
    /// pixel per DIP by default, which for a typical 8x16 cell puts an 80x24 grid
    /// at 640x384 — legible, but thin for reading a TUI back out of the image. The
    /// scale is named by the caller rather than taken from the monitor, so it stays
    /// deterministic: the same buffer at the same scale is the same bytes.
    /// </summary>
    public const double MaxCaptureScale = 3.0;

    /// <summary>Wire values for <c>captureScreen</c>'s capture mode.</summary>
    public static class CaptureModes
    {
        /// <summary>
        /// Headless re-render from the buffer (default). Deterministic, needs no
        /// visual tree, and so works for a pane that is hidden, occluded, or in a
        /// minimized window.
        /// </summary>
        public const string Render = "render";

        /// <summary>
        /// WYSIWYG capture of the on-screen control. Carries what the render path
        /// cannot — the user's background image and window opacity — at the cost of
        /// needing the pane laid out in a live window, and of not being reproducible.
        /// </summary>
        public const string Live = "live";
    }

    /// <summary>Method names. Observe-only; later milestones append, they never repurpose.</summary>
    public static class Methods
    {
        public const string ListSessions = "listSessions";
        public const string ReadScreen = "readScreen";
        public const string ReadPaneMetadata = "readPaneMetadata";
        /// <summary>Private startup-QA passive native wait fact for the current direct local pane.</summary>
        public const string ReadNativeChildWait = "readNativeChildWait";
        public const string ReadScrollback = "readScrollback";
        public const string GetSessionStatus = "getSessionStatus";
        public const string WaitForEvents = "waitForEvents";

        /// <summary>
        /// A4: writes a session's flight recording (recent output + resizes,
        /// never input) to a replay v2 file and returns its path. Additive in
        /// protocol version 1; requires the replay-export setting on top of
        /// the observe toggle.
        /// </summary>
        public const string ExportReplay = "exportReplay";

        /// <summary>
        /// A3 (act, permissioned): injects input into a live session,
        /// byte-faithful and replay-recorded like human keystrokes. Requires
        /// the separate <c>AgentAccessActEnabled</c> opt-in on top of observe,
        /// plus per-profile allowlisting for SSH sessions.
        /// </summary>
        public const string SendInput = "sendInput";

        /// <summary>A3: opens a new tab running a local or allowlisted-SSH profile by name. Returns the new paneId.</summary>
        public const string SpawnSession = "spawnSession";

        /// <summary>A3: closes a live pane by id.</summary>
        public const string CloseSession = "closeSession";

        /// <summary>Permissioned raw input: one bounded keypad, text or mouse event for the current visible direct local pane.</summary>
        public const string GeneratePaneInput = "generatePaneInput";

        /// <summary>Permissioned App-window resize for a single visible direct local pane.</summary>
        public const string ResizePane = "resizePane";

        /// <summary>Act-only private QA storage in an explicitly activated disposable process; never the native clipboard.</summary>
        public const string ClipboardFixture = "clipboardFixture";

        /// <summary>
        /// A5: captures a pane as a PNG and returns its path (plus, on request, the
        /// image inline). Additive in protocol version 1. Observe tier, gated by the
        /// observe toggle alone like every other read: the pane's own agent-access
        /// indicator (#339) lights on a capture, which is where a user sees it.
        /// </summary>
        public const string CaptureScreen = "captureScreen";
    }

    /// <summary>Server-side cap on a single <c>sendInput</c> payload, in bytes (A3).</summary>
    public const int MaxSendInputBytes = 32 * 1024;

    /// <summary>Wire values for session status (A2). See the A2 design doc for exact semantics.</summary>
    public static class StatusKinds
    {
        public const string Running = "running";
        public const string AwaitingInput = "awaitingInput";
        public const string Idle = "idle";
        public const string Exited = "exited";
    }

    /// <summary>
    /// Wire values for <c>needsUser</c> (#610): what the server asked an SSH connection an agent opened, which only the
    /// user can give. Ntilde never shows a sign-in dialog for such a connection, so it ends instead, and its exited status
    /// carries one of these.
    /// </summary>
    public static class NeedsUserReasons
    {
        /// <summary>The server's host key, which the user has not trusted yet.</summary>
        public const string HostKey = "hostKey";

        /// <summary>A host key other than the one the user trusted for this server.</summary>
        public const string ChangedHostKey = "changedHostKey";

        /// <summary>
        /// A password Ntilde had no saved one to answer with: none is saved, the saved one was refused, or a jump host
        /// asked (the profile's password is only ever sent to its target).
        /// </summary>
        public const string Password = "password";

        /// <summary>The passphrase of the user's private key.</summary>
        public const string Passphrase = "passphrase";

        /// <summary>A keyboard-interactive question, such as a one-time code.</summary>
        public const string KeyboardInteractive = "keyboardInteractive";

        /// <summary>
        /// Signing in needs the user, and the connection cannot say with what - a password, a passphrase or a code. A
        /// persistent-remote tab reports this (#631): its host's sign-in classifies only that it needed someone.
        /// </summary>
        public const string SignIn = "signIn";
    }

    /// <summary>Wire values for status confidence: how the status was derived.</summary>
    public static class StatusConfidences
    {
        /// <summary>Shell-integration events (prompt/command lifecycle) drive the status.</summary>
        public const string Precise = "precise";

        /// <summary>PTY-level signals only (child processes, alt screen, output activity).</summary>
        public const string Heuristic = "heuristic";
    }

    /// <summary>Wire values for event types on the waitForEvents channel.</summary>
    public static class EventTypes
    {
        public const string StatusChanged = "statusChanged";
        public const string CommandFinished = "commandFinished";
        public const string Bell = "bell";
        public const string Stalled = "stalled";
        public const string SessionOpened = "sessionOpened";
        public const string SessionClosed = "sessionClosed";
    }

    /// <summary>Stable machine-readable error codes carried in <see cref="AgentHostError.Code"/>.</summary>
    public static class ErrorCodes
    {
        public const string VersionMismatch = "versionMismatch";
        public const string MalformedRequest = "malformedRequest";
        public const string UnknownMethod = "unknownMethod";
        public const string SessionNotFound = "sessionNotFound";
        public const string Internal = "internal";

        /// <summary>The requested complete cell-detail projection exceeds its cell or run budget.</summary>
        public const string ScreenDetailsUnavailable = "screenDetailsUnavailable";
        public const string PaneMetadataUnavailable = "paneMetadataUnavailable";
        public const string NativeChildWaitUnavailable = "nativeChildWaitUnavailable";

        /// <summary>
        /// A4: <c>exportReplay</c> was called but the user has not enabled
        /// "Agent replay export" in settings (a second default-off gate on top
        /// of the observe toggle, per the DIRECTION permission table).
        /// </summary>
        public const string ExportDisabled = "exportDisabled";

        /// <summary>
        /// A4: the session exists but no flight recording is available to
        /// export right now (its PTY session is not yet published, was torn
        /// down, or the export failed to write).
        /// </summary>
        public const string ExportUnavailable = "exportUnavailable";

        /// <summary>
        /// A3: an acting method (<c>sendInput</c> and later spawn/close) was
        /// called but the user has not enabled "Agent access (act)" — the
        /// separate default-off opt-in that gates all acting, on top of observe.
        /// </summary>
        public const string ActDisabled = "actDisabled";

        /// <summary>
        /// A3: the target (or named) SSH profile has not been allowlisted for
        /// agent access (<c>AllowAgentAccess</c> is off). Local sessions are
        /// governed by the act toggle alone and never hit this.
        /// </summary>
        public const string ProfileNotAllowed = "profileNotAllowed";

        /// <summary>A3: <c>spawnSession</c> named a profile that matched no local or SSH profile.</summary>
        public const string ProfileNotFound = "profileNotFound";

        /// <summary>A3: the target session exists but its process has already exited — input goes nowhere.</summary>
        public const string SessionNotRunning = "sessionNotRunning";

        /// <summary>
        /// A3: the endpoint is running but the UI action executor is not
        /// published (startup/teardown race). Distinct from
        /// <see cref="ActDisabled"/>: the user opted in, the app just can't act
        /// this instant — safe to retry.
        /// </summary>
        public const string ActUnavailable = "actUnavailable";

        /// <summary>The bounded generated event cannot safely dispatch or its current-pane lease/deadline is unavailable.</summary>
        public const string GeneratedInputUnavailable = "generatedInputUnavailable";

        /// <summary>The pane cannot safely use the visible local-window resize operation.</summary>
        public const string ResizeUnavailable = "resizeUnavailable";

        /// <summary>A3: <c>spawnSession</c> resolved a profile but the tab failed to open.</summary>
        public const string SpawnFailed = "spawnFailed";

        /// <summary>
        /// A5: the session exists but cannot be captured right now. In
        /// <c>render</c> mode: the pane has not been laid out and measured yet, is
        /// being torn down, or its grid exceeds <see cref="MaxCapturePixels"/> at
        /// the requested scale. In <c>live</c> mode: the window is not up, or the
        /// pane is not on screen to be photographed. The message says which, and
        /// points a live-mode caller back at <c>render</c>.
        /// </summary>
        public const string CaptureUnavailable = "captureUnavailable";

        /// <summary>
        /// Phase 5: the daemon that holds this session is too old for this request. A windowless session (see
        /// <see cref="SessionInfo.Windowless"/>) on a multiplexer daemon that predates screen reads: its status is
        /// still reported, its screen cannot be read.
        /// </summary>
        public const string Unsupported = "unsupported";
    }
}
