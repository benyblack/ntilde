using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using Ntilde.VT;
using Ntilde.Pty;

namespace Ntilde.Shell
{
    public class TerminalSettings
    {
        private static string SettingsPath => AppPaths.SettingsFilePath;

        public double FontSize { get; set; } = 14;
        public int MaxHistory { get; set; } = 10000;
        public string FontFamily { get; set; } = BundledFontCatalog.DefaultTerminalFontFamily;
        public string ThemeName { get; set; } = "Default";
        public double WindowOpacity { get; set; } = 1.0;
        public string BlurEffect { get; set; } = "Acrylic";

        /// <summary>
        /// Interface scale: zoom for the app chrome (tabs, sidebars, dialogs, settings), applied on
        /// top of OS display scaling. 1.0 = 100%. Independent of <see cref="FontSize"/>, which only
        /// sizes terminal text; the terminal pane is inside the scaled window, so it grows with this
        /// too. Clamped to <see cref="UiScale.Minimum"/>–<see cref="UiScale.Maximum"/> at apply time.
        /// </summary>
        public double UiScale { get; set; } = Ntilde.Shell.UiScale.Default;

        /// <summary>
        /// Where the tab strip lives: "Horizontal" (title-bar strip, the default) or
        /// "Vertical" (left sidebar with per-tab agent status and output preview).
        /// Parsed case-insensitively; unrecognized values behave as "Horizontal".
        /// </summary>
        public string TabStripOrientation { get; set; } = "Horizontal";

        /// <summary>
        /// Sidebar width in px when <see cref="TabStripOrientation"/> is "Vertical".
        /// Clamped to 140–600 at apply time.
        /// </summary>
        public double VerticalTabStripWidth { get; set; } = 220;

        public bool EnableLigatures { get; set; }
        public bool EnableComplexShaping { get; set; } = true;

        /// <summary>
        /// The least contrast terminal text keeps against its background, as a WCAG ratio. Text
        /// below it is lightened or darkened (hue kept) until it reaches it; 1 is off. For themes
        /// whose palette collides with their own background, such as GitHub Light, where ANSI
        /// black is the foreground's near twin. Clamped to 1-21 when applied.
        /// </summary>
        public double MinimumContrast { get; set; } = 1.0;
        public string CursorStyle { get; set; } = "Underline";
        public bool CursorBlink { get; set; } = true;
        public bool BellAudioEnabled { get; set; } = true;
        public bool BellVisualEnabled { get; set; } = true;
        public bool SmoothScrolling { get; set; } = true;
        // Initial value of DEC mode ?1007 (alternate scroll, issue #828). Default on, as in most
        // terminals: on the alternate screen with mouse reporting off, the wheel sends Up/Down
        // keys, so less, man and git's pager scroll. A program's own DECSET/DECRST ?1007 overrides
        // this until RIS; off keeps the wheel inert there instead.
        public bool AlternateScroll { get; set; } = true;
        public bool EnableLinkDetection { get; set; } = true;
        // Kill switch for Kitty keyboard disambiguation and repeat/release reporting
        // (issue #266 / PR #277 review, Blocker 2). Default on. When false: TerminalView
        // never calls TryEncodeKittyKey (so every key falls through to the legacy encoding
        // path unconditionally, even if a TUI pushed flag 1), and AnsiParser answers the
        // CSI ? u query with flags 0 regardless of the actual pushed stack state, so a TUI
        // that queries capabilities does not believe the protocol is active. This is the
        // user's escape hatch if a keyboard layout hits the AltGr carve-out's accepted
        // trade-off or any other unforeseen encoding issue - flip this off instead of having
        // to fight the TUI that turned the protocol on.
        public bool EnableKittyKeyboardProtocol { get; set; } = true;

        // Opt-in for native (non-tunneled) kitty graphics APC on Windows, where ConPTY was
        // historically assumed to strip image escapes (docs/IMAGE_PROTOCOL_SUPPORT.md M4.2).
        // Live probing showed modern ConPTY passes well-formed APC through intact, so when on,
        // AnsiParser trusts what arrived: capability probes are answered OK and images decode,
        // as they always have on Linux/macOS. When off, the old behavior holds (probe -> ERR,
        // images skipped); the OSC 1339 tunnel is unaffected either way. Default on: a ConPTY
        // that does strip APC simply never delivers the probe, so the client falls back on its
        // own, and a corrupted payload that does arrive fails decode as a silent skip.
        public bool AllowNativeKittyGraphics { get; set; } = true;
        // Settings gate for OSC 52 and OSC 5522 clipboard writes (issue #268). Default on for
        // local sessions: AnsiParser.OnClipboardWrite always fires (VT stays policy-free),
        // and this flag is what TerminalPane checks before actually touching the system
        // clipboard. Read (answering an OSC 52 query with real clipboard contents) is never
        // implemented regardless of this setting - it only ever gates the write path.
        // Single global setting for now, no per-profile override: an SSH session forwarding
        // OSC 52 from a remote TUI is indistinguishable from a local one at this layer, so a
        // profile-scoped opt-in (e.g. disabling for untrusted SSH hosts specifically) is
        // future work rather than a v1 requirement.
        public bool AllowOsc52ClipboardWrite { get; set; } = true;
        // DECRQCRA rectangle checksum report (CSI Pi;Pg;Pt;Pl;Pb;Pr * y). Default off, as in xterm: the checksum of a
        // one-cell rectangle names the character in it, so a program answered cell by cell can read back the whole screen,
        // including earlier commands' output. Direct panes only; persistent (mux) sessions stay silent.
        public bool AllowRectangleChecksumReport { get; set; }
        // Scroll units forwarded per wheel notch. For own-buffer scrolling this is lines
        // per notch; for a mouse-reporting TUI it is wheel clicks per notch. Higher =
        // smoother/finer (more steps per notch), lower = coarser. Matters most for
        // high-resolution touchpads, which emit many sub-notch wheel events.
        public double WheelLinesPerNotch { get; set; } = 3.0;
        public string PaneClosePolicy { get; set; } = "Confirm";
        // What happens to a pane when its shell exits (#311). Three values: "Graceful" (the default)
        // closes it on a clean exit (code 0) and keeps it with the exit banner otherwise; "Never" always
        // keeps the pane and shows the banner; "Always" closes it whatever the code. The default shipped
        // as "Never" while a local PTY still reported 0 for every exit — a policy cannot tell a clean
        // exit from a crash when every exit looks clean. #313 (Windows) and #323 (Unix) made the code the
        // child's real status, so "Graceful" now means what it says. SSH panes ignore this and always keep
        // their reconnect banner. Unrecognised values behave as "Never" — a typo must not be more
        // destructive than the default.
        public string ShellExitPolicy { get; set; } = "Graceful";
        /// <summary>
        /// Which agent attention tiers reach the tab strip: "WritesOnly"
        /// (default) or "All". Unrecognised values behave as "WritesOnly" — a
        /// typo must not make the chrome noisier than the default. Read by
        /// MainWindow, which owns the tab strip; the pane never reads it, so it
        /// is deliberately absent from TerminalPane.ApplySettings.
        /// </summary>
        public string AgentIndicatorTabRollup { get; set; } = "WritesOnly";
        /// <summary>What a settings file without <see cref="SessionPersistence"/> gets (spec R3).</summary>
        public const string DefaultSessionPersistence = Ntilde.Shell.Mux.SessionPersistenceMode.KeepOnClose;
        /// <summary>
        /// "Off" or "KeepOnClose" (default: <see cref="DefaultSessionPersistence"/>): with "KeepOnClose", local
        /// shells run in the <c>ntilde mux</c> daemon and survive closing the window, a crash and a restart
        /// (docs/USER_MANUAL.md, "Persistent sessions"). Unrecognised values behave as "Off" - a typo must never
        /// start a background daemon. Read by MainWindow (which picks the session factory for new panes); the
        /// pane never reads it, so it is deliberately absent from TerminalPane.ApplySettings.
        /// </summary>
        public string SessionPersistence { get; set; } = DefaultSessionPersistence;
        public System.Collections.Generic.Dictionary<string, string> Keybindings { get; set; } = new();

        // Title bar customization. Deltas only: an id absent here takes its TitleBarCatalog default,
        // so a catalog entry added in a later version appears for existing users without a migration.
        // Values are TitleBarItemState names ("Pinned" / "Overflow" / "Hidden"); anything unparseable
        // falls back to the entry's default rather than throwing.
        public System.Collections.Generic.Dictionary<string, string> TitleBarItems { get; set; } = new();

        // Display order for the pinned set. Ids it does not name follow in catalog order.
        public System.Collections.Generic.List<string> TitleBarOrder { get; set; } = new();

        public System.Collections.Generic.List<TabTemplateRule> TabTemplateRules { get; set; } = new();

        // Background Image Settings
        public string BackgroundImagePath { get; set; } = "";
        public double BackgroundImageOpacity { get; set; } = 0.5;
        public string BackgroundImageStretch { get; set; } = "UniformToFill"; // Options: "None", "Acrylic", "Mica"

        public bool QuakeModeEnabled { get; set; } = true;
        public string GlobalHotkey { get; set; } = "Alt+OemTilde";
        // Disabled by default as of 0.3: the Command Assist feature isn't production-ready
        // yet. This master flag gates the whole feature; users can opt in via Settings.
        public bool CommandAssistEnabled { get; set; }

        // Gates command capture and history-sourced suggestions only. It is not a second master
        // switch: with this off the bubble, popup, path suggestions, Help and Fix all still work
        // (V2 Phase 3b task 3 - it used to take the whole feature down).
        public bool CommandAssistHistoryEnabled { get; set; } = true;
        public int CommandAssistMaxHistoryEntries { get; set; } = 5000;

        // The passive typing bubble (V2 Phase 3b task 1): after two typed characters the bubble shows
        // the top-ranked history/path suggestion without being asked. On by default when the master
        // flag is on, because a feature nobody can see is the problem this phase exists to fix; off
        // restores the M4.3 quiet behavior, where a passive bubble only ever offers path completions.
        //
        // CommandAssistAutoHideInAltScreen used to sit here. It was never read: hiding the overlay
        // when a full-screen TUI takes the alternate screen is unconditional, and a setting that
        // could switch it off would only ever let the assist paint over vim. Deleted in Phase 3b
        // rather than wired up; unknown keys in settings.json are ignored on load, so an existing
        // file that still carries it loads fine.
        public bool CommandAssistPassiveBubbleEnabled { get; set; } = true;
        public bool CommandAssistShellIntegrationEnabled { get; set; } = true;
        public bool CommandAssistPowerShellIntegrationEnabled { get; set; } = true;
        // On by default since the native backend reached parity (agent auth, jump chains, all
        // three forward kinds, SFTP) and every gap warns instead of degrading silently. Users
        // whose settings.json already stores an explicit false keep it — this default only
        // reaches fresh installs and settings files predating the field.
        public bool ExperimentalNativeSshEnabled { get; set; } = true;
        // Agent-host observe surface (docs/agent-host/DIRECTION.md, milestone A1).
        // Off by default: when false, no local IPC endpoint exists at all and AI
        // agents cannot read any terminal session. Observe-only in v1 — there is
        // no acting capability behind this flag.
        public bool AgentAccessObserveEnabled { get; set; }
        // A4 sub-gate on top of the observe toggle: allows agents to export a
        // session's recent output as a replay file (ntilde.export_replay).
        // Exports contain output and resize events only — never typed input
        // (privacy decision in docs/plans/2026-07-07-agent-host-a4-replay-design.md).
        // Off by default; both toggles must be on for an export to succeed.
        public bool AgentReplayExportEnabled { get; set; }
        // A3 act surface: separate default-off opt-in letting agents type into,
        // spawn, and close sessions (ntilde.send_input / spawn_session /
        // close_session). On top of observe; SSH sessions additionally require
        // per-profile allowlisting. Every acting call is shown in the agent
        // activity journal. Off by default.
        public bool AgentAccessActEnabled { get; set; }
        // In-app toast when a command that ran ≥30s finishes in an unfocused
        // pane (A2 PR4, absorbs ROADMAP §5.2). Off by default.
        public bool LongCommandNotificationsEnabled { get; set; }
        // In-app toast for an explicit OSC 9 desktop-notification sequence (#271),
        // e.g. Claude Code's completion pings. Same focus policy as the long-command
        // toast (suppressed when the pane is focused); the difference is that the
        // program asked for the notification rather than the terminal inferring it.
        // Off by default, matching LongCommandNotificationsEnabled.
        public bool Osc9NotificationsEnabled { get; set; }
        // Per-tab progress + Windows taskbar progress from OSC 9;4 sequences (#271),
        // e.g. Claude Code's terminalProgressBarEnabled. Purely ambient chrome —
        // default on so tooling that reports progress just works; this exists as the
        // off switch.
        public bool Osc9ProgressReportingEnabled { get; set; } = true;
        // Governs the once-per-launch background update check (#91). Default on: an installed
        // build that never learns about a fix is worse than a single anonymous request to
        // GitHub's releases API 10 seconds after launch. Off stops all background traffic; the
        // command palette's "Check for updates" still works, because that is the user asking
        // rather than the app polling. Ignored entirely when the app was not installed by
        // Velopack (portable zip, winget, dev runs) - there is nothing to update.
        public bool AutomaticUpdateChecks { get; set; } = true;

        public System.Collections.Generic.List<TerminalProfile> Profiles { get; set; } = new();
        public Guid DefaultProfileId { get; set; }

        private TerminalTheme? _activeTheme;
        private ThemeManager? _themeManager;

        [JsonIgnore]
        public ThemeManager ThemeManager => _themeManager ??= new ThemeManager();

        [JsonIgnore]
        public TerminalTheme ActiveTheme
        {
            get
            {
                if (_activeTheme == null || _activeTheme.Name != ThemeName)
                {
                    ThemeManager.LoadThemes();
                    _activeTheme = ThemeManager.GetTheme(ThemeName);
                }
                return _activeTheme;
            }
            set => _activeTheme = value;
        }

        public void RefreshActiveTheme()
        {
            _activeTheme = null;
        }

        public static System.Collections.Generic.List<TerminalProfile> GetDefaultProfiles()
            => GetDefaultProfiles(CommandIsInstalled);

        /// <summary>
        /// Builds the first-run profile list, keeping only the shells that are actually
        /// installed. <paramref name="commandExists"/> is the seam the tests drive; production
        /// passes <see cref="CommandIsInstalled"/>.
        /// </summary>
        /// <remarks>
        /// The list used to be unconditional, which meant a "PowerShell" profile pointing at
        /// <c>pwsh.exe</c> on machines with no PowerShell 7 — a visible, dead entry that failed
        /// to spawn with a raw FFI error. Every developer machine has pwsh, so it survived seven
        /// months until the first install on someone else's PC. Same latent bug on Linux, where
        /// a Zsh profile was created whether or not zsh existed.
        ///
        /// Known limitation: profiles persist after first run, so installing PowerShell 7 later
        /// does not make the profile appear — it has to be added by hand. Re-probing on every
        /// load was rejected because it would resurrect profiles the user deliberately deleted.
        /// </remarks>
        internal static System.Collections.Generic.List<TerminalProfile> GetDefaultProfiles(
            Func<string, bool> commandExists)
            => GetDefaultProfiles(DefaultProfileCandidates(), commandExists);

        /// <summary>
        /// Filters <paramref name="candidates"/> down to the shells that are installed,
        /// dropping a command that an earlier candidate already added.
        /// </summary>
        internal static System.Collections.Generic.List<TerminalProfile> GetDefaultProfiles(
            (string Name, string Command)[] candidates,
            Func<string, bool> commandExists)
        {
            ArgumentNullException.ThrowIfNull(commandExists);

            var profiles = new System.Collections.Generic.List<TerminalProfile>();
            var addedCommands = new System.Collections.Generic.HashSet<string>(System.StringComparer.Ordinal);
            foreach ((string name, string command) in candidates)
            {
                if (!commandExists(command) || !addedCommands.Add(command))
                {
                    continue;
                }

                profiles.Add(new TerminalProfile { Name = name, Command = command });
            }

            if (profiles.Count == 0)
            {
                // A probe can fail wholesale — an empty PATH makes every lookup false. The
                // constructor immediately does Profiles[0].Id, so an empty list is a startup
                // crash: strictly worse than one profile that might not launch. Fall back to
                // the shell the platform is guaranteed to have.
                (string Name, string Command) floor = OperatingSystem.IsWindows()
                    ? ("Command Prompt", "cmd.exe")
                    : ("Shell", "/bin/sh");
                profiles.Add(new TerminalProfile { Name = floor.Name, Command = floor.Command });
            }

            return profiles;
        }

        /// <summary>The first-run candidates for this platform. On Unix the detected login
        /// shell leads, so <c>DefaultProfileId</c> lands on the shell the user actually uses
        /// rather than whichever fixed entry happens to exist.</summary>
        private static (string Name, string Command)[] DefaultProfileCandidates() => OperatingSystem.IsWindows()
            ? WindowsProfileCandidates
            : UnixProfileCandidates(ShellHelper.GetDefaultShell());

        /// <summary>
        /// The Windows first-run candidates, in <see cref="ShellHelper.GetDefaultShell"/>'s order.
        /// <c>DefaultProfileId</c> is the first installed one, so the settings default and every
        /// path that substitutes the default shell (restore, a blank command, the mux daemon) pick
        /// the same shell. They used to disagree (#349): this list led with cmd, so a machine with
        /// PowerShell installed defaulted to cmd here and to PowerShell everywhere else.
        /// </summary>
        internal static readonly (string Name, string Command)[] WindowsProfileCandidates =
        {
            ("PowerShell", "pwsh.exe"),
            ("Windows PowerShell", "powershell.exe"),
            ("Command Prompt", "cmd.exe"),
        };

        /// <summary>
        /// The Unix first-run candidates: the login shell, then the fixed trio. A login shell
        /// that collides with the trio (a zsh user's <c>/bin/zsh</c>) is dropped by the dedup
        /// in the profile builder, not here — this stays a plain list so callers can see what
        /// was offered.
        /// </summary>
        internal static (string Name, string Command)[] UnixProfileCandidates(string loginShell)
            => new[]
            {
                ("Default Shell", loginShell),
                ("Bash", "/bin/bash"),
                ("Zsh", "/bin/zsh"),
                ("Shell", "/bin/sh"),
            };

        private static bool CommandIsInstalled(string command)
            => OperatingSystem.IsWindows()
                ? ShellHelper.InPath(command)
                : File.Exists(command);

        public TerminalSettings()
        {
            Profiles = GetDefaultProfiles();
            DefaultProfileId = Profiles[0].Id;
        }

        public static TerminalSettings Load()
        {
            AppPaths.EnsureInitialized();
            return LoadFromPath(SettingsPath);
        }

        [System.Text.Json.Serialization.JsonIgnore]
        public bool CredentialMigrationPending { get; private set; }

        private bool _credentialMigrationRequiresReload;

        internal static TerminalSettings LoadFromPath(string settingsPath, VaultService? migrationVault = null)
        {
            bool migrationReady = LegacyProfilePasswordMigration.TryMigrate(settingsPath, () => migrationVault ?? new VaultService());
            TerminalSettings settings = ReadSettingsOrRecover(settingsPath, allowRepair: migrationReady, out string loadedPath);
            if (!migrationReady)
                settings._credentialMigrationRequiresReload = !LegacyProfilePasswordMigration.ReconcileLoadedIds(settingsPath, loadedPath, settings);
            ValidateLoadedProfiles(settings);
            ValidateDefaultProfile(settings);
            settings.CredentialMigrationPending = !migrationReady;
            return settings;
        }

        private static TerminalSettings ReadSettingsOrRecover(string settingsPath, bool allowRepair, out string loadedPath)
        {
            loadedPath = settingsPath;
            if (!File.Exists(settingsPath)) return new TerminalSettings();
            try
            {
                string json = File.ReadAllText(settingsPath);
                return JsonSerializer.Deserialize(json, AppJsonContext.Default.TerminalSettings) ?? new TerminalSettings();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[Settings] '{settingsPath}' is unreadable ({ex.Message}); trying backup.");
                return RecoverSettings(settingsPath, allowRepair, out loadedPath);
            }
        }

        private static TerminalSettings RecoverSettings(string settingsPath, bool allowRepair, out string loadedPath)
        {
            loadedPath = string.Empty;
            // Quarantine the evidence before recovering from the last good copy (#167).
            try { File.Copy(settingsPath, settingsPath + ".corrupt", overwrite: true); }
            catch { /* best effort */ }
            var fromBackup = TryLoadOrNull(settingsPath + ".bak");
            if (fromBackup == null)
            {
                System.Diagnostics.Debug.WriteLine($"[Settings] Backup '{settingsPath}.bak' is also unreadable; falling back to defaults.");
                return new TerminalSettings();
            }
            loadedPath = settingsPath + ".bak";
            // A locked keyring may have left the only legacy credential in the backup. Repairing
            // with the deserialized (credential-free) settings would destroy that source copy.
            if (!allowRepair) return fromBackup;
            // Repair immediately so subsequent launches do not repeat quarantine/recovery (#178).
            try
            {
                AtomicFile.WriteAllTextWithoutBackup(settingsPath, JsonSerializer.Serialize(fromBackup, AppJsonContext.Default.TerminalSettings));
            }
            catch (Exception repairEx)
            {
                System.Diagnostics.Debug.WriteLine($"[Settings] Failed to repair '{settingsPath}' from backup: {repairEx.Message}");
            }
            return fromBackup;
        }

        private static void ValidateLoadedProfiles(TerminalSettings settings)
        {
            // Post-load validation
            if (settings.Profiles == null || settings.Profiles.Count == 0)
            {
                settings.Profiles = GetDefaultProfiles();
            }
            else
            {
                // Cross-platform polish: If we don't have any profile that matches a known shell for this OS,
                // add the defaults for this OS so the user isn't stuck with invalid shells from another OS.
                // "Usable here" means the command is not addressed to another OS - the same
                // predicate the restore and launch paths use. It used to mean "the command exists",
                // which made this disagree with them: a profile they would happily open could still
                // be judged unusable here, and vice versa.
                bool nativeShellsFound = settings.Profiles.Exists(p =>
                    p.Type == ConnectionType.Local &&
                    !ShellHelper.IsCommandForAnotherPlatform(p.Command));

                if (!nativeShellsFound)
                {
                    foreach (var def in GetDefaultProfiles())
                    {
                        if (!settings.Profiles.Exists(p => p.Command == def.Command))
                        {
                            settings.Profiles.Add(def);
                        }
                    }
                }
            }

            if (settings.TabTemplateRules == null)
            {
                settings.TabTemplateRules = new System.Collections.Generic.List<TabTemplateRule>();
            }

        }

        private static void ValidateDefaultProfile(TerminalSettings settings)
        {
            // Ensure we have a valid default profile
            bool defaultValid = settings.Profiles.Exists(p => p.Id == settings.DefaultProfileId);
            if (settings.DefaultProfileId == Guid.Empty || !defaultValid)
            {
                settings.DefaultProfileId = settings.Profiles[0].Id;
            }
            else
            {
                // If the default profile is a local command that doesn't exist on this OS, 
                // try to pick a more appropriate default for the current platform.
                var currentDefault = settings.Profiles.Find(p => p.Id == settings.DefaultProfileId);
                if (currentDefault != null && currentDefault.Type == ConnectionType.Local)
                {
                    // Reassigning someone's default profile is not a small thing to do silently, so
                    // it now happens only when the command could not run on this OS at all. The
                    // existence check reached much further than that: a default whose command was a
                    // quoted path, or carried inline arguments, was swapped out even though opening
                    // it worked - which is what made the same profile behave differently depending on
                    // whether it was the default or picked from a session.
                    if (ShellHelper.IsCommandForAnotherPlatform(currentDefault.Command))
                    {
                        var better = settings.Profiles.Find(p =>
                            p.Type == ConnectionType.Local &&
                            !ShellHelper.IsCommandForAnotherPlatform(p.Command));

                        if (better != null)
                        {
                            settings.DefaultProfileId = better.Id;
                        }
                    }
                }
            }

        }

        private static TerminalSettings? TryLoadOrNull(string path)
        {
            try
            {
                if (!File.Exists(path)) return null;
                string json = File.ReadAllText(path);
                return JsonSerializer.Deserialize(json, AppJsonContext.Default.TerminalSettings);
            }
            catch
            {
                return null;
            }
        }

        public void Save() => _ = TrySave(out _);

        public bool TrySave(out string error)
        {
            try { AppPaths.EnsureInitialized(); }
            catch (Exception ex) { error = ex.Message; return false; }
            return TrySaveToPath(SettingsPath, () => new VaultService(), out error);
        }

        internal bool TrySaveToPath(string settingsPath, Func<VaultService> vaultFactory, out string error)
        {
            try
            {
                if (_credentialMigrationRequiresReload)
                {
                    error = "Legacy profile identities could not be loaded safely. Unlock credential storage and restart Ntilde before saving settings. The original files are preserved.";
                    return false;
                }
                if (!LegacyProfilePasswordMigration.TryMigrate(settingsPath, vaultFactory))
                {
                    CredentialMigrationPending = true;
                    error = $"A saved password could not be moved to OS credential storage. Unlock or install a credential store, then retry. The original files are preserved at {settingsPath} and its .bak recovery copy; you can correct or remove an invalid legacy entry there. Settings were not saved.";
                    return false;
                }
                CredentialMigrationPending = false;
                string json = JsonSerializer.Serialize(this, AppJsonContext.Default.TerminalSettings);
                // A primary left malformed during locked-keyring recovery must not replace the good backup.
                if (File.Exists(settingsPath) && TryLoadOrNull(settingsPath) is null)
                    AtomicFile.WriteAllTextWithoutBackup(settingsPath, json);
                else
                    AtomicFile.WriteAllText(settingsPath, json);
                error = string.Empty;
                return true;
            }
            catch (Exception ex)
            {
                error = $"Settings could not be saved: {ex.Message}";
                System.Diagnostics.Debug.WriteLine($"[Settings] Save failed: {ex.Message}");
                return false;
            }
        }
    }
}
