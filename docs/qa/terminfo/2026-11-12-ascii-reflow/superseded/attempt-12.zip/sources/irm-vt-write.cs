using System;
using System.Globalization;
using System.Linq;
using System.Text;
using Ntilde.VT.Storage;

namespace Ntilde.VT
{
    public partial class TerminalBuffer
    {
        public void WriteChar(char c)
        {
            bool lockTaken = EnterWriteLockIfNeeded();
            try
            {
                WriteCharCore(c);
            }
            finally { ExitWriteLockIfNeeded(Lock, lockTaken); }
            Invalidate();
        }

        private void WriteCharCore(char c)
        {
            // Only treat as control if it's not a grapheme component (ZWJ, Variation Selectors)
            if (char.IsControl(c) && !char.IsSurrogate(c) && c != '\u200D' && !(c >= '\uFE00' && c <= '\uFE0F'))
            {
                _highSurrogateBuffer = null;
                HandleControlCode(c);
                _isAfterZwj = false;
                _lastCharCol = -1;
            }
            else
            {
                if (char.IsHighSurrogate(c))
                {
                    _highSurrogateBuffer = c;
                    return;
                }

                string grapheme;
                if (_highSurrogateBuffer.HasValue && char.IsLowSurrogate(c))
                {
                    grapheme = new string(new[] { _highSurrogateBuffer.Value, c });
                    _highSurrogateBuffer = null;
                }
                else
                {
                    _highSurrogateBuffer = null;
                    grapheme = c.ToString();
                }

                WriteGraphemeInternal(grapheme);
            }
        }

        private void FlushGrapheme()
        {
            // No-op in new simplified logic, but kept for compatibility if called elsewhere
            _highSurrogateBuffer = null;
        }

        private void HandleControlCode(char c)
        {
            // Cursor logic extracted from old WriteChar
            if (c == '\r')
            {
                _cursorCol = CarriageReturnColumnNoLock;
                _prevCursorCol = _cursorCol;
                _prevCursorRow = _cursorRow;
                _isPendingWrap = false;
            }
            else if (c == '\n' || c == '\u000B' || c == '\u000C') // LF, VT, FF
            {
                if (_cursorRow >= 0 && _cursorRow < Rows) _viewport[_cursorRow].IsWrapped = false;

                // VT100: LF moves to the same horizontal position on the next line. With New Line Mode (LNM)
                // it also returns, after the index as in xterm: a cursor between the margins at the bottom margin
                // scrolls the band first, then goes to the left margin (column 0 without margins).
                AdvanceCursorRowForLineFeed();
                if (Modes.IsLineFeedNewLineMode)
                {
                    _cursorCol = CarriageReturnColumnNoLock;
                }
                _isPendingWrap = false;
            }
            else if (c == '\b')
            {
                StepCursorBack(Modes.IsReverseWrapMode && Modes.IsAutoWrapMode, skipWideContinuation: true);
            }
            else if (c == '\t')
            {
                HorizontalTab();
            }
        }

        /// <summary>
        /// CUB (CSI Ps D). Without reverse-wraparound it clamps at column 0, exactly as before. With ?45 and
        /// auto-wrap (?7) both set each step is the same one BS takes (xterm's CursorBack serves both), so it
        /// may cross a soft wrap and a pending wrap is consumed first.
        /// </summary>
        public void CursorBackward(int count)
        {
            bool lockTaken = EnterWriteLockIfNeeded();
            try
            {
                if (!(Modes.IsReverseWrapMode && Modes.IsAutoWrapMode))
                {
                    _cursorCol = Math.Max(LeftEdgeForCursorNoLock, _cursorCol - count);
                    _isPendingWrap = false;
                    return;
                }

                for (int step = 0; step < count; step++)
                {
                    if (!StepCursorBack(reverseWrap: true, skipWideContinuation: false)) break;
                }
            }
            finally { ExitWriteLockIfNeeded(Lock, lockTaken); }
        }

        /// <summary>
        /// One backward step (BS, or one column of CUB). BS lands on the lead cell of a wide glyph (<paramref name="skipWideContinuation"/>); CUB counts physical columns. Returns false when the cursor could not move.
        /// Reverse-wraparound (xterm ?45, only with ?7 set): a pending wrap is consumed without moving, and at the
        /// left edge the cursor returns to the last column of the previous row, but only across a soft wrap. A hard
        /// line break, the top of the screen and the top margin of the scrolling region holding the cursor are
        /// never crossed. Without it a pending wrap is cleared by the usual one-cell move.
        /// </summary>
        private bool StepCursorBack(bool reverseWrap, bool skipWideContinuation)
        {
            if (reverseWrap && _isPendingWrap)
            {
                _isPendingWrap = false;
                return true;
            }

            _isPendingWrap = false;
            // The left margin stops the cursor while it is at or right of it; left of it, the first column does.
            int leftEdge = LeftEdgeForCursorNoLock;
            if (_cursorCol > leftEdge)
            {
                _cursorCol--;

                if (skipWideContinuation && _cursorRow >= 0 && _cursorRow < Rows)
                {
                    var row = _viewport[_cursorRow];
                    while (_cursorCol > leftEdge && row.Cells[_cursorCol].IsWideContinuation)
                    {
                        _cursorCol--;
                    }
                }

                return true;
            }

            if (!reverseWrap || _cursorRow <= 0 || _cursorRow >= Rows) return false;
            bool inRegion = _cursorRow >= ScrollTop && _cursorRow <= ScrollBottom;
            if (_cursorRow <= (inRegion ? ScrollTop : 0)) return false;
            if (!_viewport[_cursorRow - 1].IsWrapped) return false;

            _cursorRow--;
            _cursorCol = RightMargin;
            var previous = _viewport[_cursorRow];
            while (skipWideContinuation && _cursorCol > 0 && previous.Cells[_cursorCol].IsWideContinuation)
            {
                _cursorCol--;
            }

            return true;
        }

        public void WriteContent(string text, bool ignored = false)
        {
            if (string.IsNullOrEmpty(text)) return;

            bool lockTaken = EnterWriteLockIfNeeded();
            try
            {
                WriteContentCore(text);
            }
            finally { ExitWriteLockIfNeeded(Lock, lockTaken); }
            Invalidate();
        }

        private void WriteContentCore(string text)
        {
            FlushGrapheme(); // Ensure any single char buffered by WriteChar is handled

            // Every printable character of all output comes through here, so the segmentation used
            // to dominate allocation: StringInfo.GetTextElementEnumerator boxes an enumerator and
            // GetTextElement() allocates a *string per grapheme* — for plain ASCII, one string per
            // character. Cat-ing a large file produced garbage on the order of gigabytes (#165).
            //
            // GetNextTextElementLength gives the same segmentation over a span without allocating,
            // and WriteGraphemeInternal now takes a span, so a string is only materialized when one
            // actually has to be stored (an extended-grapheme side-table entry).
            ReadOnlySpan<char> remaining = text.AsSpan();
            while (!remaining.IsEmpty)
            {
                int length = NextTextElementLength(remaining);
                WriteGraphemeInternal(remaining.Slice(0, length));
                remaining = remaining.Slice(length);
            }
        }

        /// <summary>
        /// Length of the grapheme cluster starting at index 0, with a fast path for ASCII.
        /// </summary>
        /// <remarks>
        /// The fast path is exact rather than approximate: every character that can extend a cluster
        /// — combining marks, variation selectors, ZWJ, regional indicators, surrogates — is at
        /// U+0300 or above, so an ASCII character followed by another ASCII character is always a
        /// complete cluster on its own. That covers the overwhelming majority of terminal output
        /// without consulting the segmentation tables at all.
        /// </remarks>
        private static int NextTextElementLength(ReadOnlySpan<char> text)
        {
            char first = text[0];
            if (first < 0x80 && (text.Length == 1 || text[1] < 0x80))
            {
                return 1;
            }

            return StringInfo.GetNextTextElementLength(text);
        }

        // Span, not string: WriteContentCore segments without allocating, and a string is only
        // materialized below where one has to be stored in a side table (#165).
        private void WriteGraphemeInternal(ReadOnlySpan<char> grapheme)
        {
            if (grapheme.IsEmpty) return;

            // Guard against lone surrogates from broken UTF-8 (e.g. Yazi on WSL via ConPTY).
            // EnumerateRunes().First() internally calls new Rune(char) which throws on surrogates.
            Rune firstRune;
            if (grapheme.Length == 1)
            {
                if (!Rune.TryCreate(grapheme[0], out firstRune))
                    firstRune = new Rune('?'); // Replace invalid with ? placeholder
            }
            else
            {
                // Was EnumerateRunes().FirstOrDefault(...), which boxed the struct enumerator via
                // LINQ once per multi-char grapheme (#165).
                if (Rune.DecodeFromUtf16(grapheme, out firstRune, out _) != System.Buffers.OperationStatus.Done)
                {
                    firstRune = new Rune('?');
                }
            }
            bool isZeroWidthComponent = UnicodeWidth.IsZeroWidthGraphemeComponent(firstRune);
            if (_textSizingBlocks != null && (isZeroWidthComponent || _isAfterZwj || UnicodeWidth.IsSingleRegionalIndicator(grapheme)) && TryAppendToSizedBlock(grapheme)) return;


            // ATTACHMENT LOGIC:

            // If it's a combining mark OR we just had a ZWJ, try to attach to the previous cell.
            // We allow this even if _lastCharCol is -1, as the look-back logic can find the base.
            bool mayAttachToPrevious =
                _cursorRow == _lastCharRow &&
                (isZeroWidthComponent || _isAfterZwj || UnicodeWidth.IsSingleRegionalIndicator(grapheme));

            if (mayAttachToPrevious)
            {
                int attachCol = -1;

                // 1. Try sequential marker first
                if (_lastCharCol >= 0 && _cursorCol >= _lastCharCol && _cursorCol <= _lastCharCol + 8)
                {
                    // Verify if this is a suitable base for skin tones (look back for a non-space)
                    int searchCol = Math.Min(_cursorCol, Cols - 1);
                    while (searchCol >= 0)
                    {
                        var target = _viewport[_cursorRow].Cells[searchCol];

                        if (target.IsWideContinuation || _viewport[_cursorRow].GetTextSizing(searchCol) != null) { searchCol--; continue; }
                        if (target.HasExtendedText || (target.Character != ' ' && target.Character != '\0'))
                        {
                            attachCol = searchCol;
                            break;
                        }
                        searchCol--;
                        if (searchCol < _lastCharCol - 4) break; // Don't look too far back
                    }
                }

                // 2. Look-back fallback (only if sequential marker didn't find anything)
                if (attachCol < 0 && _cursorCol > 0)
                {
                    var prev = _viewport[_cursorRow].Cells[_cursorCol - 1];
                    if (prev.IsWideContinuation && _cursorCol > 1)
                    {
                        attachCol = _cursorCol - 2;
                    }
                    else if (prev.HasExtendedText || (prev.Character != ' ' && prev.Character != '\0'))
                    {
                        attachCol = _cursorCol - 1;
                    }
                }

                // Sized attachments must update their immutable block and every piece together.
                if (attachCol >= 0 && _viewport[_cursorRow].GetTextSizing(attachCol) == null)
                {
                    var row = _viewport[_cursorRow];
                    ref var cell = ref row.Cells[attachCol];
                    if (!cell.IsWideContinuation)
                    {
                        string existing = row.GetExtendedText(attachCol) ?? cell.Character.ToString();
                        if (!UnicodeWidth.ShouldAttachToPrevious(existing, grapheme, _isAfterZwj))
                        {
                            goto NormalWrite;
                        }

                        // Concatenation has to allocate here regardless: the merged cluster is stored
                        // in the side table. string.Concat(span, span) avoids the interim allocation
                        // an implicit ToString() would add.
                        string merged = string.Concat(existing.AsSpan(), grapheme);
                        row.SetExtendedText(attachCol, merged);
                        cell.HasExtendedText = true;
                        cell.IsDirty = true; // Force redraw
                        row.TouchRevision();

                        // Re-evaluate width of the merged cluster
                        int newWidth = GetGraphemeWidth(merged);
                        row.NoteColumnsWritten(Math.Min(Cols, attachCol + Math.Max(1, newWidth)));

                        // ALWAYS enforce wide flag and continuation for width >= 2
                        if (newWidth >= 2)
                        {
                            cell.IsWide = true;
                            if (attachCol + 1 < Cols)
                            {
                                // Width expansion overwrites the adjacent cell; retire its whole sized rectangle first.
                                int absoluteRow = TextSizingAbsoluteRow(_cursorRow);
                                EraseTextSizingRange(attachCol + 1, attachCol + 2, absoluteRow, absoluteRow + 1);
                                // Ensure next cell is a continuation
                                ref var nextCell = ref row.Cells[attachCol + 1];
                                bool expandedIntoNextCell = false;
                                if (!nextCell.IsWideContinuation)
                                {
                                    SyncPackedState();
                                    nextCell = new TerminalCell(' ', _packedFg, _packedBg, (ushort)(_packedFlags | (ushort)TerminalCellFlags.WideContinuation));
                                    row.SetExtendedText(attachCol + 1, null); // Ensure no old text remains
                                    row.SetHyperlink(attachCol + 1, row.GetHyperlink(attachCol));
                                    row.SetUnderline(attachCol + 1, UnderlineForWrite); // the continuation takes the pen's flags
                                    expandedIntoNextCell = true;
                                }

                                // If the cursor was waiting at the next cell, and we just expanded into it, push the cursor forward.
                                if (expandedIntoNextCell && _cursorCol == attachCol + 1)
                                {
                                    _cursorCol++;
                                    if (_cursorCol > Cols) _cursorCol = Cols;
                                }
                            }
                        }
                    }


                    _isAfterZwj = EndsWithZwj(grapheme);
                    Invalidate();
                    return; // CRITICAL: Stop here, don't write again to current cursor
                }
            } // End of attachment attempt logic

            // NORMAL WRITE LOGIC:
        NormalWrite:
            // With no eligible preceding base, a mark on a sized cell extends that rectangle.
            if (isZeroWidthComponent && _textSizingBlocks != null && TryAppendToSizedBlockAtColumn(_cursorCol, grapheme)) return;
            int width = GetGraphemeWidth(grapheme);

            // Handle Pending Wrap State (M1.3)
            // With horizontal margins a wrap returns to the left margin, and the wrapped text is not one reflowable line: no soft-wrap mark.
            if (_isPendingWrap && !isZeroWidthComponent && !_isAfterZwj)
            {
                if (_cursorRow >= 0 && _cursorRow < Rows && !HasHorizontalMargins) _viewport[_cursorRow].SetSoftWrap(Cols);
                _cursorCol = LeftMargin;
                AdvanceCursorRowForLineFeed();
                _isPendingWrap = false;
            }

            // The right edge is the right margin, or the last column once the cursor is right of the right margin.
            int rightEdge = RightEdgeForCursorNoLock;

            // Handle auto-wrap
            if (Modes.IsAutoWrapMode)
            {
                if (_cursorCol + width > rightEdge + 1)
                {
                    if (_cursorRow >= 0 && _cursorRow < Rows && !HasHorizontalMargins) _viewport[_cursorRow].SetSoftWrap(_cursorCol);
                    _cursorCol = LeftMargin;
                    AdvanceCursorRowForLineFeed();
                    _isPendingWrap = false;
                    rightEdge = RightEdgeForCursorNoLock;
                }
            }
            else
            {
                // Clamp to the edge. A character wider than the whole row (wide in a 1-column terminal)
                // starts at column 0 and loses its continuation, as on the autowrap path.
                if (_cursorCol + width > rightEdge + 1) _cursorCol = Math.Max(0, rightEdge + 1 - width);
            }

            if (_textSizingBlocks != null) PrepareTextSizingOverwrite(Math.Max(1, width));

            // Write to buffer
            if (_cursorRow >= 0 && _cursorRow < Rows && _cursorCol >= 0 && _cursorCol < Cols)
            {
                if (Modes.IsInsertMode) InsertCharactersInternal(width);

                var row = _viewport[_cursorRow];
                row.NoteColumnsWritten(Math.Min(Cols, _cursorCol + Math.Max(1, width)));

                SyncPackedState();

                // Protection is only touched when the pen protects or the row already holds records: plain output pays one null check.
                bool tracksProtection = _state.IsCharacterProtected || row.HasProtectionEntries;

                // Clear continuations and old extended text
                for (int i = 0; i < width && _cursorCol + i < Cols; i++)
                {
                    row.Cells[_cursorCol + i] = new TerminalCell(' ', _packedFg, _packedBg, _packedFlags);
                    row.SetExtendedText(_cursorCol + i, null);
                    row.SetHyperlink(_cursorCol + i, null);
                    row.SetUnderline(_cursorCol + i, null);
                    if (tracksProtection) row.SetProtected(_cursorCol + i, false);
                }

                ushort flags = _packedFlags;
                if (width >= 2) flags |= (ushort)TerminalCellFlags.Wide;
                if (grapheme.Length > 1 || (grapheme.Length == 1 && char.IsSurrogate(grapheme[0]))) flags |= (ushort)TerminalCellFlags.HasExtendedText;

                row.Cells[_cursorCol] = new TerminalCell(grapheme[0], _packedFg, _packedBg, flags);
                if ((flags & (ushort)TerminalCellFlags.HasExtendedText) != 0)
                {
                    row.SetExtendedText(_cursorCol, grapheme.ToString());
                }
                row.SetHyperlink(_cursorCol, _currentHyperlink);
                row.SetUnderline(_cursorCol, UnderlineForWrite);
                if (tracksProtection) row.SetProtected(_cursorCol, _state.IsCharacterProtected); // a wide glyph's protection lives on its anchor

                if (width >= 2 && _cursorCol + 1 < Cols)
                {
                    int maxCont = Math.Min(width, Cols - _cursorCol);
                    for (int i = 1; i < maxCont; i++)
                    {
                        row.Cells[_cursorCol + i] = new TerminalCell(' ', _packedFg, _packedBg, (ushort)(_packedFlags | (ushort)TerminalCellFlags.WideContinuation));
                        row.SetExtendedText(_cursorCol + i, null);
                        row.SetHyperlink(_cursorCol + i, _currentHyperlink);
                        row.SetUnderline(_cursorCol + i, UnderlineForWrite);
                    }
                }

                row.TouchRevision();
                _lastCharCol = _cursorCol;
                _lastCharRow = _cursorRow;
                _cursorCol += width;
            }

            // Update Pending Wrap State
            if (Modes.IsAutoWrapMode && _cursorCol > rightEdge)
            {
                _isPendingWrap = true;
                _cursorCol = rightEdge;
            }
            if (!Modes.IsAutoWrapMode && _cursorCol > rightEdge)
            {
                _cursorCol = rightEdge;
            }

            if (_cursorCol > _maxColThisRow) _maxColThisRow = _cursorCol;
            _prevCursorCol = _cursorCol;
            _prevCursorRow = _cursorRow;
            this._isAfterZwj = EndsWithZwj(grapheme);
        }

        private void AdvanceCursorRowForLineFeed()
        {
            if (_cursorRow >= ScrollTop && _cursorRow == ScrollBottom)
            {
                // With horizontal margins only a cursor between them scrolls the region; outside them it stays at the bottom margin.
                if (CursorInHorizontalMarginsNoLock) ScrollUpInternal();
                _cursorRow = ScrollBottom;
                return;
            }

            _cursorRow = Math.Min(_cursorRow + 1, Rows - 1);
        }

        /// <summary>
        /// Whether <paramref name="grapheme"/> ends on a ZWJ (U+200D), and so ended <em>expecting a
        /// continuation</em> — the question <c>_isAfterZwj</c> is asked to answer.
        /// </summary>
        /// <remarks>
        /// #236: this used to return true for a ZWJ <em>anywhere</em> in the cluster, and the comment
        /// claimed that as deliberate. But a *completed* ZWJ sequence contains ZWJ without ending on
        /// one, so the flag stayed set and the next grapheme — any grapheme — attached to it. Printing
        /// a family emoji followed by a space merged the space into the family.
        ///
        /// The flag has to stay true for an incomplete sequence: grapheme segmentation keeps a
        /// trailing ZWJ attached to its base (GB9), so a PTY read that ends mid-join hands the write
        /// path a cluster like "man + ZWJ" and the emoji completing it arrives in the next read.
        ///
        /// Testing the last <c>char</c> is exact rather than a shortcut: U+200D is in the BMP and is
        /// not a surrogate, so it can only ever be a whole trailing rune, never the tail half of an
        /// astral one.
        /// </remarks>
        private static bool EndsWithZwj(ReadOnlySpan<char> grapheme)
        {
            return !grapheme.IsEmpty && grapheme[^1] == '\u200D';
        }

        /// <summary>
        /// Scrolls the viewport up by one line.
        /// Respects the scrolling region (ScrollTop/ScrollBottom).
        /// Only adds to scrollback if scrolling the entire screen.
        /// </summary>
        public void ScrollUp()
        {
            bool lockTaken = EnterWriteLockIfNeeded();
            try
            {
                ScrollUpInternal();
            }
            finally { ExitWriteLockIfNeeded(Lock, lockTaken); }
            Invalidate(); // Notify outside lock (optional, Invalidate delegates)
        }

        private void ScrollUpInternal()
        {
            // Horizontal margins scroll only the band between them, never into scrollback.
            if (HasHorizontalMargins)
            {
                ScrollBandNoLock(ScrollTop, ScrollBottom, LeftMargin, RightMargin, 1, up: true, ThemeBlankCell());
                return;
            }

            // Check if we are scrolling the explicit region or full screen
            bool isFullScreenScroll = (ScrollTop == 0 && ScrollBottom == Rows - 1);

            if (!isFullScreenScroll || _isAltScreen)
            {
                int top = TextSizingAbsoluteRow(ScrollTop);
                int bottom = TextSizingAbsoluteRow(ScrollBottom + 1);
                EraseTextSizingAcrossBoundary(top);
                EraseTextSizingAcrossBoundary(bottom);
                EraseTextSizingRange(0, Cols, top, top + 1);
            }

            // 1. If full screen and main screen, add to scrollback
            if (isFullScreenScroll && !_isAltScreen)
            {
                long prevEvicted = _scrollback.TotalRowsEvicted;

                // This copies the cell array into the page-based store;
                // No TerminalRow object is stored in scrollback anymore.
                var evictingRow = _viewport[0];
                _scrollback.AppendRow(evictingRow);


                long newlyEvicted = _scrollback.TotalRowsEvicted - prevEvicted;

                // If we evicted rows (pages), all following rows shifted down in absolute index
                // So we must decrement CellY for ALL images by the number of evicted rows.
                if (newlyEvicted > 0)
                {
                    for (int i = _images.Count - 1; i >= 0; i--)
                    {
                        var img = _images[i];
                        // Eviction shifts the MAIN-screen absolute coordinate space only;
                        // alt-screen images are viewport-relative and must not move.
                        if (img.IsAltScreenImage) continue;

                        int delta = newlyEvicted > int.MaxValue ? int.MaxValue : (int)newlyEvicted;
                        img.CellY -= delta;
                        // If the image's entire area is now before the new index 0, prune it.
                        if (img.CellY + img.CellHeight <= 0)
                        {
                            RetireImage(img);
                            _images.RemoveAt(i);
                        }
                    }
                }
            }
            else
            {
                // Regional scroll-up or Alternate screen scroll (no scrollback growth)
                // Images that are partially or fully in the region need to be shifted UP (CellY--)
                int absTop = _isAltScreen ? ScrollTop : (_scrollback.Count + ScrollTop);
                int absBottom = _isAltScreen ? ScrollBottom : (_scrollback.Count + ScrollBottom);

                for (int i = _images.Count - 1; i >= 0; i--)
                {
                    var img = _images[i];
                    // Scroll only moves images of the ACTIVE screen: coordinates of the
                    // inactive screen live in a different space (absolute vs viewport-
                    // relative) and would be corrupted by this shift.
                    if (img.IsAltScreenImage != _isAltScreen) continue;

                    // If image overlaps with the scrolling region, it moves.
                    // Accurate overlap: Ends after top AND Starts before bottom.
                    if (img.IsSticky && img.CellY + img.CellHeight > absTop && img.CellY <= absBottom)
                    {
                        img.CellY--;
                        if (ClipSixelImage(img, absTop, absBottom))
                        {
                            RetireImage(img);
                            _images.RemoveAt(i);
                            continue;
                        }

                        // If image moved entirely above the region (and it was a regional scroll),
                        // we might prune it if it's no longer visible in the region.
                        // However, standard sticky images just move. Pruning only on MaxHistory is safer.
                        if (img.CellY + img.CellHeight <= absTop && !isFullScreenScroll)
                        {
                            // Optional: _images.RemoveAt(i); 
                        }
                    }
                }
            }

            // 2. Shift rows up within the region
            for (int i = ScrollTop; i < ScrollBottom; i++)
            {
                _viewport[i] = _viewport[i + 1];
            }

            // 3. Create new blank line at the bottom of the region: a new row, with an Id of its own.
            _viewport[ScrollBottom] = new TerminalRow(Cols, Theme.Foreground, Theme.Background);

            // A move is not an edit (#657): the rows keep their revisions. What is keyed by viewport index - the
            // snapshot's row-cell cache, the dirty tracking - also keys by row Id, so a row that arrives at an index is
            // redrawn there; and the row-picture cache, keyed by (Id, revision), replays the moved row's picture at
            // its new y. Touching every row here made all of them miss, every frame output scrolled.
        }

        /// <summary>
        /// Scrolls the viewport down by one line.
        /// Respects the scrolling region (ScrollTop/ScrollBottom).
        /// Lines scrolled off the bottom are lost.
        /// </summary>
        public void ScrollDown()
        {
            bool lockTaken = EnterWriteLockIfNeeded();
            try
            {
                ScrollDownInternal();
            }
            finally { ExitWriteLockIfNeeded(Lock, lockTaken); }
            Invalidate();
        }

        private void ScrollDownInternal()
        {
            if (HasHorizontalMargins)
            {
                ScrollBandNoLock(ScrollTop, ScrollBottom, LeftMargin, RightMargin, 1, up: false, ThemeBlankCell());
                return;
            }

            int sizedTop = TextSizingAbsoluteRow(ScrollTop);
            int sizedBottom = TextSizingAbsoluteRow(ScrollBottom + 1);
            EraseTextSizingAcrossBoundary(sizedTop);
            EraseTextSizingAcrossBoundary(sizedBottom);
            EraseTextSizingRange(0, Cols, sizedBottom - 1, sizedBottom);
            // Update images: Shift images in the region DOWN (CellY++)
            int absTop = _isAltScreen ? ScrollTop : (_scrollback.Count + ScrollTop);
            int absBottom = _isAltScreen ? ScrollBottom : (_scrollback.Count + ScrollBottom);

            for (int i = _images.Count - 1; i >= 0; i--)
            {
                var img = _images[i];
                // Only the active screen's images move (see ScrollUpInternal).
                if (img.IsAltScreenImage != _isAltScreen) continue;

                // If image overlaps with the scrolling region, it moves.
                if (img.IsSticky && img.CellY + img.CellHeight > absTop && img.CellY < absBottom)
                {
                    img.CellY++;
                    bool clipped = ClipSixelImage(img, absTop, absBottom);
                    // If the image moves below the region, remove it
                    if (clipped || img.CellY > absBottom)
                    {
                        RetireImage(img);
                        _images.RemoveAt(i);
                    }
                }
            }

            // Shift rows down within the region
            for (int i = ScrollBottom; i > ScrollTop; i--)
            {
                _viewport[i] = _viewport[i - 1];
            }

            // Create new blank line at the top of the region
            _viewport[ScrollTop] = new TerminalRow(Cols, Theme.Foreground, Theme.Background);

            // Moved rows keep their revisions, as in ScrollUpInternal (#657).
        }

        public void InsertCharacters(int count)
        {
            bool lockTaken = EnterWriteLockIfNeeded();
            try
            {
                InsertCharactersInternal(count);
            }
            finally
            {
                ExitWriteLockIfNeeded(Lock, lockTaken);
            }
            Invalidate();
        }

        private void InsertCharactersInternal(int count)
        {
            // Lock must be held by caller
            if (_cursorRow < 0 || _cursorRow >= Rows) return;
            // With horizontal margins ICH acts only between them, from the cursor to the right margin.
            if (!CursorInHorizontalMarginsNoLock) return;
            int edge = RightMargin + 1;
            var empty = new TerminalCell(' ', CurrentForeground, CurrentBackground, false, false, IsDefaultForeground, IsDefaultBackground, false, CurrentFgIndex, CurrentBgIndex, false, false, false, false, false, false);

            int endCol = Math.Min(_cursorCol + count, edge);
            var row = _viewport[_cursorRow];
            if (edge < Cols)
            {
                EraseTextSizingRange(_cursorCol, edge, TextSizingAbsoluteRow(_cursorRow), TextSizingAbsoluteRow(_cursorRow) + 1);
                RetireWideAcross(row, edge, empty); // a glyph straddling the right margin would leave a half behind
            }
            else
            {
                EraseTextSizingForShift(insert: true, Math.Max(0, endCol - _cursorCol));
            }
            row.WrappedColumns = null;
            row.WrittenColumns = Cols;

            // A glyph pushed against the right edge loses its continuation off the end; its anchor must not stay protected there.
            // (A glyph that is already an edge anchor keeps its record: nothing was cut.)
            bool edgeCut = edge - 1 - count >= _cursorCol && row.Cells[edge - 1 - count].IsWide;
            // Shift characters to right
            // Start from end, move char at (c - count) to c
            for (int c = edge - 1; c >= endCol; c--)
            {
                row.Cells[c] = row.Cells[c - count];
            }

            // The extended-grapheme and hyperlink side tables are keyed by column, so they have to
            // move with the cells they describe — otherwise a cell keeps HasExtendedText while its
            // string stays behind at the old column (#164). Insert mode reaches this per printable
            // character, hence the HasRowMetadata guard.
            if (row.HasRowMetadata) row.ShiftRowMetadata(_cursorCol, count, Cols, edge);
            if (edgeCut) row.SetProtected(edge - 1, false);
            // Inside a right margin the cut glyph's anchor would sit beside cells it does not own: retire it.
            if (edgeCut && edge < Cols) BlankCell(row, edge - 1, empty);

            for (int c = _cursorCol; c < endCol; c++)
            {
                row.Cells[c] = empty;
            }
            row.TouchRevision();
        }

        public void DeleteCharacters(int count)
        {
            bool lockTaken = EnterWriteLockIfNeeded();
            try
            {
                DeleteCharactersInternal(count);
            }
            finally { ExitWriteLockIfNeeded(Lock, lockTaken); }
            Invalidate();
        }

        private void DeleteCharactersInternal(int count)
        {
            if (_cursorRow < 0 || _cursorRow >= Rows) return;
            // With horizontal margins DCH acts only between them; blanks enter at the right margin.
            if (!CursorInHorizontalMarginsNoLock) return;
            int edge = RightMargin + 1;

            // Clamp to the columns available from the cursor. Without this, a count larger than
            // the line width (e.g. CSI 9999 P, or the parser's max parameter) makes endCol go
            // negative and the fill loop below index Cells[-n] → IndexOutOfRangeException.
            int maxDeletable = edge - _cursorCol;
            if (maxDeletable <= 0) return;
            if (count > maxDeletable) count = maxDeletable;

            int endCol = edge - count;
            var empty = new TerminalCell(' ', CurrentForeground, CurrentBackground, false, false, IsDefaultForeground, IsDefaultBackground, false, CurrentFgIndex, CurrentBgIndex);
            var row = _viewport[_cursorRow];
            if (edge < Cols)
            {
                EraseTextSizingRange(_cursorCol, edge, TextSizingAbsoluteRow(_cursorRow), TextSizingAbsoluteRow(_cursorRow) + 1);
                RetireWideAcross(row, edge, empty); // a glyph straddling the right margin would leave a half behind
            }
            else
            {
                EraseTextSizingForShift(insert: false, count);
            }
            // Deleting a continuation leaves its anchor beside whatever shifts in next, which could be another glyph's continuation:
            // the anchor's record must go with the half that is deleted, or the two would read as one protected glyph.
            if (_cursorCol > 0 && row.Cells[_cursorCol].IsWideContinuation && row.Cells[_cursorCol - 1].IsWide) row.SetProtected(_cursorCol - 1, false);
            row.WrappedColumns = null;
            row.WrittenColumns = Cols;

            // Shift characters to left
            for (int c = _cursorCol; c < endCol; c++)
            {
                row.Cells[c] = row.Cells[c + count];
            }

            // Side tables follow the cells (#164). Entries in the deleted range are dropped; the
            // blanked tail columns end up with no entries, matching the empty cells written below.
            if (row.HasRowMetadata) row.ShiftRowMetadata(_cursorCol, -count, Cols, edge);

            // Update images on this row: shift those to the right of cursor left
            int absY = _isAltScreen ? _cursorRow : (_scrollback.Count + _cursorRow);
            for (int i = _images.Count - 1; i >= 0; i--)
            {
                var img = _images[i];
                // Only the active screen's images move (see ScrollUpInternal).
                if (img.IsAltScreenImage != _isAltScreen) continue;

                if (img.IsSticky && img.CellY == absY && img.CellX >= _cursorCol && img.CellX < edge)
                {
                    img.CellX -= count;
                    if (img.CellX < _cursorCol)
                    {
                        // If it shifted but still starts before cursor? 
                        // Actually, it should probably be removed if its original range was partially deleted.
                        // But for simplicity, if it moves left of cursor, we let it stay or part-clip it.
                        // Most terminals don't handle this perfectly. Let's just shift it.
                    }
                }
            }

            // Fill gap at end with empty cells
            for (int c = endCol; c < edge; c++)
            {
                row.Cells[c] = empty;
            }
            row.TouchRevision();
        }
    }
}
