import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
// Complete source/input inventory shared by retention and v8 validation.
export const ownedSourceFiles = Object.freeze({
    runnerSourceSha256: 'terminfo-owned.mjs',
    adapterSourceSha256: 'collector.mjs',
    ownershipSourceSha256: 'ownership.mjs',
    workerSourceSha256: 'worker.mjs',
    runtimeSourceSha256: 'runtime.mjs',
    observerSourceSha256: 'agent-observer.mjs',
    cellSuiteSourceSha256: 'cells.mjs',
    cellFenceSourceSha256: 'terminal-fence.mjs',
    attributeSourceSha256: 'attributes.mjs',
    sgrSuiteSourceSha256: 'sgr.mjs',
    cellDetailsSourceSha256: 'cell-details.mjs',
    rgbSuiteSourceSha256: 'rgb.mjs',
    renditionSuiteSourceSha256: 'rendition.mjs',
    cursorSuiteSourceSha256: 'cursor.mjs',
    pixelCaptureSourceSha256: 'pixels-capture.mjs',
    pixelSuiteSourceSha256: 'pixels.mjs',
    pixelCasesSourceSha256: 'pixels-cases.mjs',
    pixelPngSourceSha256: 'pixels-png.mjs',
    colorCaptureSourceSha256: 'color-capture.mjs',
    colorSuiteSourceSha256: 'colors.mjs',
    colorCasesSourceSha256: 'color-cases.mjs',
    colorQuerySourceSha256: 'color-query.mjs',
    editingStateSourceSha256: 'editing-state.mjs',
    editingCasesSourceSha256: 'editing-cases.mjs',
    editingExpectationsSourceSha256: 'editing-expectations.mjs',
    editingCaptureSourceSha256: 'editing-capture.mjs',
    editingSuiteSourceSha256: 'editing.mjs',
    metadataCasesSourceSha256: 'metadata-cases.mjs',
    metadataCaptureSourceSha256: 'metadata-capture.mjs',
    metadataStateSourceSha256: 'metadata-state.mjs',
    metadataExpectationsSourceSha256: 'metadata-expectations.mjs',
    metadataSuiteSourceSha256: 'metadata.mjs',
    metadataReceiptSourceSha256: 'metadata-receipt.mjs',
    savedCasesSourceSha256: 'saved-cases.mjs',
    savedCaptureSourceSha256: 'saved-capture.mjs',
    savedSuiteSourceSha256: 'saved.mjs',
    savedExpectationsSourceSha256: 'saved-expectations.mjs',
    savedReceiptSourceSha256: 'saved-receipt.mjs',
    resizeCasesSourceSha256: 'resize-cases.mjs',
    resizeCaptureSourceSha256: 'resize-capture.mjs',
    resizeSuiteSourceSha256: 'resize.mjs',
    resizeActionSourceSha256: 'resize-action.mjs',
    resizeReceiptSourceSha256: 'resize-receipt.mjs',
    historyCasesSourceSha256: 'history-cases.mjs',
    historyCaptureSourceSha256: 'history-capture.mjs',
    historySuiteSourceSha256: 'history.mjs',
    terminalOutputSourceSha256: 'terminal-output.mjs',
    receiptSourceSha256: 'receipt.mjs',
    collectorManifestSha256: 'collector-package.json',
    collectorLockSha256: 'collector-package-lock.json',
    sourceRegistrySourceSha256: 'owned-sources.mjs',
});

export const ownedSourcePath = (root, file) => join(root, 'scripts', file === 'terminfo-owned.mjs' ? file : 'terminfo/' + file);
/** Reject edits after the original snapshot, before publishing completed observation evidence. */
export function assertOwnedSourcesUnchanged(root, context) {
    for (const [key, file] of Object.entries(ownedSourceFiles)) {
        const digest = createHash('sha256').update(readFileSync(ownedSourcePath(root, file))).digest('hex');
        if (digest !== context[key]) throw new Error('Owned source changed before completion: ' + file);
    }
}
