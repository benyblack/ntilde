using Avalonia;
using Avalonia.Media;
using Avalonia.Platform;
using Avalonia.Rendering.SceneGraph;
using Avalonia.Skia;
using SkiaSharp;
using SkiaSharp.HarfBuzz;
using System;
using System.Buffers;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using Ntilde.VT;
using Ntilde.Rendering;
using Ntilde.Shell.Theming;

namespace Ntilde.Shell
{
    public sealed partial class TerminalDrawOperation : ICustomDrawOperation
    {
        // Throttle render-path error logging: a persistent draw failure fires every frame, so
        // rate-limit to avoid flooding the log (and previously, unbounded error.log growth).
        private static long _lastRenderErrorLogTicks;
        private static readonly long RenderErrorLogIntervalTicks = TimeSpan.FromSeconds(5).Ticks;

        private readonly TerminalBuffer _buffer;
        private readonly CellMetrics _metrics;
        private readonly int _scrollOffset;
        private readonly SelectionState _selection;
        private readonly bool _selectionRelativeToViewport;
        private readonly List<SearchMatch>? _searchMatches;
        private readonly int _activeSearchIndex;
        private readonly Typeface _typeface;
        private readonly double _fontSize;
        private readonly Rect _bounds;
        private readonly GlyphTypeface _glyphTypeface;
        private readonly SharedSKTypeface? _skTypeface;
        private readonly SharedSKFont? _skFont;
        private readonly bool _enableLigatures;
        private readonly ConcurrentDictionary<string, SKTypeface?> _fallbackCache;
        private readonly SKTypeface[] _fallbackChain;
        private readonly float _opacity;
        private readonly bool _hideCursor;
        private readonly bool _textBlinkVisible;
        private readonly long? _presentationTimeMs;
        private readonly bool _preferredCursorBlink;
        private readonly bool _fillBackground;
        private readonly bool _collectRenderDetails;
        private readonly bool _collectImageDetails;
        private readonly Action? _afterSnapshotForTest;
        internal RenderedFrameInfo? RenderedFrame { get; private set; }
        private readonly Action<bool>? _reportTextBlinkCells;
        private readonly CursorStyle? _preferredCursorStyle;
        private readonly double _renderScaling;
        private readonly int _bufferRows;
        private readonly int _bufferCols;
        private readonly RowImageCache? _rowCache;
        private readonly bool _enableComplexShaping;
        private readonly double _minimumContrast;

        // Per frame: a run's (foreground, background) pair resolves the same way every time, and a
        // screen has few distinct pairs, so the lightness search runs once per pair.
        private Dictionary<(uint Fg, uint Bg, uint Overlay), SKColor>? _contrastAdjusted;
        private readonly GlyphCache? _glyphCache;
        private IDisposable? _cacheLease; // the view's caches (TerminalRenderCaches), held until Dispose
        private readonly int _cellWidthDevicePx;
        private readonly int _cellHeightDevicePx;
        private readonly PixelGrid _pixelGrid;
        private readonly NativeRasterPresenterContext? _nativeRasterPresenter;
        private readonly NativeSixelViewProjection? _nativeSixelProjection;
        internal bool NativeRasterUnavailable { get; private set; }
        private readonly bool _showRenderHud;

        /// <summary>
        /// True when this pass is not a frame of the live view (an agent-host capture, a PNG
        /// export, a golden render), so it takes an isolated snapshot that leaves the buffer's
        /// live row-diff baseline alone. See <see cref="RenderSnapshotRequest.Isolated"/>.
        /// </summary>
        private readonly bool _isolatedSnapshot;
        private readonly Action? _requestImageFrame;
        private bool _wasAltScreenLastFrame;

        private static readonly bool GlyphDiagnosticsEnabled = IsEnvFlagEnabled("NTILDE_DIAG_GLYPH");
        private static readonly bool GridDiagnosticsEnabled = IsEnvFlagEnabled("NTILDE_DIAG_GRID");
        private static readonly bool ForceKnownGoodBoxFont = IsEnvFlagEnabled("NTILDE_FORCE_BOX_FONT");
        // On by default: font-supplied box glyphs do not span the full cell height on most
        // installed fonts, leaving a gap at every row boundary so vertical borders render as
        // dashed ladders. The primitive path fills cell-edge to cell-edge. Set
        // NTILDE_BOX_PRIMITIVES=0 to fall back to font glyphs.
        private static readonly bool UseBoxDrawingPrimitives = IsEnvFlagEnabled("NTILDE_BOX_PRIMITIVES", defaultValue: true);
        private static readonly bool UseBlockElementPrimitives = IsEnvFlagEnabled("NTILDE_BLOCK_PRIMITIVES");
        private static readonly AsyncLocal<TestPrimitiveRenderOverride?> PrimitiveRenderOverrideForTests = new();
        private static readonly ConcurrentDictionary<string, byte> GlyphDiagOnce = new();
        private static readonly string[] KnownGoodBoxFonts = { "JetBrains Mono NL", "JetBrainsMonoNL NFM", "JetBrainsMonoNL Nerd Font Mono", "Cascadia Mono PL", "Cascadia Mono", "JetBrains Mono", "DejaVu Sans Mono", "Consolas", "Cascadia Code" };
        private static Lazy<RenderPerfWriter?> SharedRenderPerfWriter = new(RenderPerfWriter.CreateFromEnvironment);

        // Batching for DrawAtlas
        private const int InitialAtlasBatchCapacity = 128;
        private SKRect[] _alphaRects = new SKRect[InitialAtlasBatchCapacity];
        private SKRotationScaleMatrix[] _alphaXforms = new SKRotationScaleMatrix[InitialAtlasBatchCapacity];
        private SKColor[] _alphaColors = new SKColor[InitialAtlasBatchCapacity];
        private SKRect[] _colorRects = new SKRect[InitialAtlasBatchCapacity];
        private SKRotationScaleMatrix[] _colorXforms = new SKRotationScaleMatrix[InitialAtlasBatchCapacity];
        private SKRect[]? _alphaRectsScratch;
        private SKRotationScaleMatrix[]? _alphaXformsScratch;
        private SKColor[]? _alphaColorsScratch;
        private SKRect[]? _colorRectsScratch;
        private SKRotationScaleMatrix[]? _colorXformsScratch;
        private int _alphaCount;
        private int _alphaScratchPrevCount;
        private int _colorCount;
        private int _colorScratchPrevCount;
        private readonly SKPaint _bgFillPaint = new();
        private readonly SKPaint _decoStrokePaint = new();
        private readonly SKPaint _blockFillPaint = new();
        private readonly SKPaint _shadeFillPaint = new();
        private readonly SKPaint _atlasAlphaPaint = new();
        private readonly SKPaint _atlasColorPaint = new();
        private readonly Dictionary<SKTypeface, SKFont> _fallbackFontCache = new(SKTypefaceReferenceComparer.Instance);
        private readonly Dictionary<SKTypeface, ShapingResources> _shapingCache = new(SKTypefaceReferenceComparer.Instance);
        private const int RunBuilderInitialCapacity = 256;
        private const int RunBuilderMaxCapacity = 4096;
        private readonly StringBuilder _runBuilder = new(capacity: RunBuilderInitialCapacity);

        /// <summary>
        /// The per-cell text of the run being built, parallel to <see cref="_runBuilder"/>.
        /// </summary>
        /// <remarks>
        /// #234: the per-glyph draw path used to re-split <c>runText</c> by *rune*, so every
        /// multi-codepoint cluster was rasterized in pieces and its composed glyph never produced.
        /// Re-segmenting the concatenated run is not the fix either — cluster boundaries do not have
        /// to line up with cell boundaries, and segmenting across a boundary would merge two cells
        /// into one glyph. Keeping the cell texts is exact: each entry is the cell's own text, and
        /// each cell's width was already measured from that same string when the run was built.
        /// </remarks>
        private readonly List<string> _runCellTexts = new(capacity: 64);
        private float[]? _colEdges;
        private float[]? _rowEdges;
        private int _colEdgesCount;
        private int _rowEdgesCount;
        private RenderPerfMetrics _framePerfMetrics;
        // Set by Render() from the Avalonia lease; direct DrawTerminalInternal callers draw offscreen.
        private string _renderBackend = RenderBackend.Offscreen;
        private long _frameAllocStartBytes;
        private int _frameOtherDrawCalls;
        private bool _collectFramePerfMetrics;

        private struct RowRenderItem
        {
            public int AbsRow;
            public SKPicture? CachedPicture;
            public SelectionRowSnapshot? LigatureSelection;
            public RenderRowSnapshot? Snapshot;
            public bool HasBlinkInk { get; set; }
        }

        private class FrameSnapshot
        {
            public SKColor ThemeBg;
            public SKColor ThemeFg;
            public SKColor CursorColor;
            public CursorStyle CursorStyle;
            public bool CursorVisible { get; set; }
            public bool CursorBlinkEnabled { get; set; }
            public TerminalRenderColors RenderColors;
            public List<RowRenderItem> RowItems = new();
            public List<RenderImageSnapshot> Images = new();
        }

        private sealed class ShapingResources
        {
            public SKShaper Shaper { get; }
            public SKFont Font { get; }

            public ShapingResources(SKShaper shaper, SKFont font)
            {
                Shaper = shaper;
                Font = font;
            }
        }

        private sealed class TestPrimitiveRenderOverride
        {
            public bool UseBoxDrawingPrimitives { get; init; }
            public bool UseBlockElementPrimitives { get; init; }
        }

        private sealed class PrimitiveRenderOverrideScope : IDisposable
        {
            private readonly TestPrimitiveRenderOverride? _previous;
            private bool _disposed;

            public PrimitiveRenderOverrideScope(TestPrimitiveRenderOverride? previous)
            {
                _previous = previous;
            }

            public void Dispose()
            {
                if (_disposed)
                {
                    return;
                }

                _disposed = true;
                PrimitiveRenderOverrideForTests.Value = _previous;
            }
        }

        public Rect Bounds => _bounds;

        /// <summary>
        /// Freezes draw inputs and independent native presenter/capture densities before acquiring font resources.
        /// </summary>
        public TerminalDrawOperation(
            Rect bounds,
            TerminalBuffer buffer,
            int scrollOffset,
            SelectionState selection,
            List<SearchMatch>? searchMatches,
            int activeSearchIndex,
            CellMetrics metrics,
            Typeface typeface,
            double fontSize,
            GlyphTypeface glyphTypeface,
            SharedSKTypeface? skTypeface,
            SharedSKFont? skFont,
            bool enableLigatures,
            ConcurrentDictionary<string, SKTypeface?> fallbackCache,
            SKTypeface[] fallbackChain,
            double opacity,
            bool hideCursor,
            double renderScaling = 1.0,
            int snapshotRows = 0,
            int snapshotCols = 0,
            int totalLines = 0,
            int cursorRow = 0,
            int cursorCol = 0,
            RowImageCache? rowCache = null,
            bool enableComplexShaping = true,
            GlyphCache? glyphCache = null,
            bool showRenderHud = false,
            bool isolatedSnapshot = false,
            double minimumContrast = 1.0,
            IDisposable? cacheLease = null,
            Action? requestImageFrame = null,
            CursorStyle? preferredCursorStyle = null,
            bool textBlinkVisible = true,
            Action<bool>? reportTextBlinkCells = null,
            long? presentationTimeMs = null,
            bool preferredCursorBlink = true,
            bool fillBackground = false,
            bool collectRenderDetails = false,
            bool selectionRelativeToViewport = false,
            bool collectImageDetails = false,
            Action? afterSnapshotForTest = null,
            double? nativePresenterDevicePixelsPerDip = null)
        {
            if (buffer.SixelRasterPolicyVersion != 0 && (!double.IsFinite(renderScaling) ||
                !float.IsFinite((float)renderScaling) || (float)renderScaling <= 0))
                throw new ArgumentOutOfRangeException(nameof(renderScaling));
            _nativeRasterPresenter = nativePresenterDevicePixelsPerDip is double presenterScale
                ? new NativeRasterPresenterContext(presenterScale) : null;
            _bounds = bounds;
            _preferredCursorStyle = preferredCursorStyle;
            _cacheLease = cacheLease;
            _buffer = buffer;
            _scrollOffset = scrollOffset;
            _selection = selection;
            _selectionRelativeToViewport = selectionRelativeToViewport;
            _searchMatches = searchMatches;
            _activeSearchIndex = activeSearchIndex;
            _metrics = metrics;
            _typeface = typeface;
            _fontSize = fontSize;
            _glyphTypeface = glyphTypeface;
            _skTypeface = skTypeface;
            _skTypeface?.Increment();
            _skFont = skFont;
            _skFont?.Increment();
            _enableLigatures = enableLigatures;
            _fallbackCache = fallbackCache;
            _fallbackChain = fallbackChain;
            _opacity = (float)Math.Clamp(opacity, 0.0, 1.0);
            _hideCursor = hideCursor;
            _textBlinkVisible = presentationTimeMs.HasValue
                ? TextBlinkAnimation.IsVisibleAtMilliseconds(presentationTimeMs.Value) : textBlinkVisible;
            _presentationTimeMs = presentationTimeMs;
            _preferredCursorBlink = preferredCursorBlink;
            _fillBackground = fillBackground;
            _collectRenderDetails = collectRenderDetails;
            _collectImageDetails = collectImageDetails;
            _afterSnapshotForTest = afterSnapshotForTest;
            _reportTextBlinkCells = reportTextBlinkCells;
            _renderScaling = renderScaling;
            _bufferRows = snapshotRows;
            _bufferCols = snapshotCols;
            _rowCache = rowCache;
            _enableComplexShaping = enableComplexShaping;
            _minimumContrast = minimumContrast;
            _glyphCache = glyphCache;
            _showRenderHud = showRenderHud;
            _isolatedSnapshot = isolatedSnapshot;
            _requestImageFrame = requestImageFrame;
            _pixelGrid = CreatePixelGrid(_metrics, _renderScaling);
            if (_nativeRasterPresenter is { } presenter)
                _nativeSixelProjection = new(_pixelGrid.CellWidthPx * presenter.DevicePixelsPerDip / _renderScaling,
                    _pixelGrid.CellHeightPx * presenter.DevicePixelsPerDip / _renderScaling);
            _cellWidthDevicePx = _pixelGrid.CellWidthPx;
            _cellHeightDevicePx = _pixelGrid.CellHeightPx;
        }

        // Capture sizing and painting must use exactly the same snapping and origin.
        internal static PixelGrid CreatePixelGrid(CellMetrics metrics, double renderScaling)
        {
            int DevicePx(double logical) => (int)Math.Round(logical * renderScaling, MidpointRounding.AwayFromZero);
            int cellHeight = Math.Max(1, DevicePx(metrics.CellHeight));
            return new PixelGrid(
                originXPx: DevicePx(4f),
                originYPx: 0,
                cellWidthPx: Math.Max(1, DevicePx(metrics.CellWidth)),
                cellHeightPx: cellHeight,
                baselineOffsetPx: DevicePx(metrics.Baseline),
                underlineOffsetPx: DevicePx(metrics.CellHeight - Math.Max(1.5f, metrics.CellHeight * 0.12f)),
                strikeOffsetPx: (int)Math.Round(cellHeight * 0.52, MidpointRounding.AwayFromZero));
        }

        // Fit within the original full cell envelope before viewport/row clipping. Keep its
        // top-left anchor; the protocol does not require a shared centering convention.
        private static SKRect FitImageWithin(SKRect envelope, int pixelWidth, int pixelHeight)
        {
            if (pixelWidth <= 0 || pixelHeight <= 0) return envelope;
            float scale = Math.Min(envelope.Width / pixelWidth, envelope.Height / pixelHeight);
            return new SKRect(envelope.Left, envelope.Top,
                envelope.Left + pixelWidth * scale, envelope.Top + pixelHeight * scale);
        }

        private SnapshotSelectionRange? CaptureSyntheticSelection(TerminalRenderSnapshot snapshot)
        {
            if (!_selectionRelativeToViewport || snapshot.SelectionRows.Length == 0) return null;
            var first = snapshot.SelectionRows.Array[0];
            var last = snapshot.SelectionRows.Array[snapshot.SelectionRows.Length - 1];
            return new SnapshotSelectionRange(first.AbsRow - snapshot.AbsDisplayStart, first.ColStart,
                last.AbsRow - snapshot.AbsDisplayStart, last.ColEnd);
        }

        public void Dispose()
        {
            _skFont?.Dispose();
            _skTypeface?.Dispose();

            _alphaCount = 0;
            _alphaScratchPrevCount = 0;
            _colorCount = 0;
            _colorScratchPrevCount = 0;
            ReturnEdgeBuffers();
            _bgFillPaint.Dispose();
            _decoStrokePaint.Dispose();
            _blockFillPaint.Dispose();
            _shadeFillPaint.Dispose();
            _atlasAlphaPaint.Dispose();
            _atlasColorPaint.Dispose();
            DisposeAndClearShapingCache();
            DisposeAndClearFallbackFontCache();

            // Last: the caches this operation drew with may be disposed with it, when the view let them go (#644).
            _cacheLease?.Dispose();
            _cacheLease = null;
        }

        public bool Equals(ICustomDrawOperation? other) => false;
        public bool HitTest(Point p) => _bounds.Contains(p);

        public void Render(ImmediateDrawingContext context)
        {
            var leaseFeature = context.TryGetFeature<ISkiaSharpApiLeaseFeature>();
            if (leaseFeature == null) return;

            using var lease = leaseFeature.Lease();
            var canvas = lease.SkCanvas;
            _renderBackend = RenderBackend.Describe(lease.GrContext);

            canvas.Save();
            using var snapshotToDispose = DrawTerminalInternal(canvas);
            canvas.Restore();
        }

        // Step 3 optimization: rely on row pictures (or the DrawRowTextFromSnapshot fallback) to paint non-default backgrounds.
        private const bool UseRowPicturesForBackgrounds = true;

        // Step 5: Always build SKPictures for dirty rows — skipping caching causes stale
        // cache hits on subsequent frames (mass invalidation "ghost" bug).
        private const int MaxPictureBuildsPerFrame = int.MaxValue;
        private const float MassInvalidationThreshold = 0.5f; // kept for stats only
        private const int SpanRenderMaxSpansPerRow = 6;
        private const float SpanRenderCoverageFallbackThreshold = 0.70f;

        // Drop-in replacement for TerminalDrawOperation.DrawTerminal(SKCanvas canvas)
        // Fixes:
        // 1) DrainDisposalsAndApplyClearIfRequested() is called OUTSIDE _buffer lock
        // 2) Preserves row->Y mapping even if some rows are missing (uses VisualRow)
        // 3) Uses a single snapshotted absDisplayStart for consistent image/overlay/cursor mapping

        internal TerminalRenderSnapshot? DrawTerminalInternal(SKCanvas canvas)
        {
            // Snapshot session: brackets this pass's snapshot copy through its last
            // DrawBitmap. Retired image handles are only disposed once every session that
            // started at or before their retire tick has ended (TerminalBuffer enforces it),
            // so disposal is exact for BOTH pipelines that drive this method — the live view
            // frame and agent-host captures — regardless of how long a pass runs.
            int snapshotSession = _buffer.BeginSnapshotSession();
            try
            {
                return DrawTerminalInternalCore(canvas, snapshotSession);
            }
            finally
            {
                _buffer.EndSnapshotSession(snapshotSession);
            }
        }

        /// <summary>
        /// Paints one coherent terminal snapshot while the caller holds its image snapshot session through the final bitmap draw.
        /// Live frames bound deferred image work; isolated captures materialize their selected images without draining retired handles.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Maintainability", "S3776", Justification = "Pre-existing frame pipeline. Controlled captures record snapshot presentation facts and fill their own background here to preserve one-draw provenance; splitting the full pipeline is outside this capture change.")]
        private TerminalRenderSnapshot? DrawTerminalInternalCore(SKCanvas canvas, int snapshotSession)
        {
            try
            {
                // Render-thread safe boundary: drain deferred disposals & apply clear requests.
                _rowCache?.DrainDisposalsAndApplyClearIfRequested();
                _glyphCache?.DrainDisposals();

                // NOTE: retired inline-image handles are intentionally NOT drained here.
                // This draw operation is also driven by TerminalSnapshotRenderer (agent-host
                // capture) on its own thread, so a drain at this point is not tied to one
                // pipeline's frame sequence and could dispose a bitmap another concurrent
                // snapshot is still drawing (#166 review). The owning TerminalView drains
                // instead, and TerminalBuffer's snapshot-session gate (see the session
                // bracket at the top of DrawTerminalInternal) is what makes that drain safe
                // for captures of any duration.

                RenderPerfWriter? perfWriter = BeginFramePerfMetrics();
                var frame = new FrameSnapshot();
                var snapshotRequest = new RenderSnapshotRequest
                {
                    ViewportRows = _bufferRows,
                    ViewportCols = _bufferCols,
                    ScrollOffset = _scrollOffset,
                    Selection = _selection,
                    SelectionRelativeToViewport = _selectionRelativeToViewport,
                    SearchMatches = _searchMatches,
                    ActiveSearchIndex = _activeSearchIndex,
                    Isolated = _isolatedSnapshot,
                    SnapshotSessionId = snapshotSession,
                    NativeSixelProjection = _nativeSixelProjection,
                };
                TerminalRenderSnapshot renderSnapshot = _buffer.CaptureRenderSnapshot(snapshotRequest, out long readLockMs);
                RendererStatistics.RecordBufferReadLockTimeMs(readLockMs);

                int bufferRows = renderSnapshot.ViewportRows;
                int bufferCols = renderSnapshot.ViewportCols;
                int absDisplayStart = renderSnapshot.AbsDisplayStart;
                byte alpha = (byte)(255 * _opacity);
                int dirtySpanCount = renderSnapshot.DirtySpans.Length;
                var spansByRow = new List<DirtySpan>[bufferRows];
                for (int i = 0; i < dirtySpanCount; i++)
                {
                    var span = renderSnapshot.DirtySpans.Array[i];
                    if ((uint)span.Row >= (uint)bufferRows)
                    {
                        continue;
                    }

                    var bucket = spansByRow[span.Row];
                    if (bucket == null)
                    {
                        bucket = new List<DirtySpan>(4);
                        spansByRow[span.Row] = bucket;
                    }

                    bucket.Add(span);
                }

                int dirtyRowCount = 0;
                for (int i = 0; i < spansByRow.Length; i++)
                {
                    if (spansByRow[i] != null && spansByRow[i]!.Count > 0)
                    {
                        dirtyRowCount++;
                    }
                }
                var frameSw = System.Diagnostics.Stopwatch.StartNew();
                frame.ThemeBg = new SKColor(renderSnapshot.Theme.Background.R, renderSnapshot.Theme.Background.G, renderSnapshot.Theme.Background.B, alpha);
                frame.ThemeFg = new SKColor(renderSnapshot.Theme.Foreground.R, renderSnapshot.Theme.Foreground.G, renderSnapshot.Theme.Foreground.B, 255);
                frame.CursorColor = new SKColor(renderSnapshot.Theme.CursorColor.R, renderSnapshot.Theme.CursorColor.G, renderSnapshot.Theme.CursorColor.B, 255);
                frame.CursorStyle = renderSnapshot.CursorStyleIsDefault
                    ? _preferredCursorStyle ?? renderSnapshot.CursorStyle : renderSnapshot.CursorStyle;
                frame.RenderColors = TerminalRenderColors.For(renderSnapshot.Theme.Source ?? UnthemedSnapshotTheme);
                frame.CursorBlinkEnabled = renderSnapshot.CursorStyleIsDefault ? _preferredCursorBlink : renderSnapshot.CursorBlinkEnabled;
                frame.CursorVisible = !_hideCursor && renderSnapshot.CursorVisible &&
                    (!_presentationTimeMs.HasValue || !frame.CursorBlinkEnabled || _textBlinkVisible);
                if (_collectRenderDetails)
                {
                    RenderedFrame = new RenderedFrameInfo(renderSnapshot.Theme, frame.RenderColors, _pixelGrid,
                        bufferRows, bufferCols, renderSnapshot.CursorRow, renderSnapshot.CursorCol,
                        frame.CursorStyle, frame.CursorVisible, frame.CursorBlinkEnabled,
                        CaptureSyntheticSelection(renderSnapshot));
                }
                if (_fillBackground)
                {
                    var background = renderSnapshot.Theme.Background;
                    canvas.Clear(new SKColor(background.R, background.G, background.B, background.A));
                }

                if (renderSnapshot.Images.Length > 0 && renderSnapshot.Images.Array != null)
                {
                    frame.Images = new List<RenderImageSnapshot>(renderSnapshot.Images.Length);
                    for (int i = 0; i < renderSnapshot.Images.Length; i++)
                    {
                        frame.Images.Add(renderSnapshot.Images.Array[i]);
                    }
                }
                else
                {
                    frame.Images = new List<RenderImageSnapshot>();
                }

                // Per-call test path only. CaptureRenderSnapshot has released the buffer lock;
                // the existing snapshot-session lease still protects the copied image handles.
                _afterSnapshotForTest?.Invoke();

                // IMPORTANT: Always add exactly one RowRenderItem per visual row
                // so render loop can safely use r for Y positioning.
                // Skip row picture cache for AltScreen (mc, vim, htop etc.) — these apps
                // redraw every row on every focus/resize, giving near-zero cache hit rate.
                // Caching only wastes native Skia memory (~1-5MB per SKPicture × 90 entries).
                bool isAltScreen = _buffer.IsAltScreenActive;
                bool useRowCache = _rowCache != null && !isAltScreen;
                if (!useRowCache && _rowCache != null && !_wasAltScreenLastFrame)
                {
                    // First AltScreen frame: clear any pictures cached from the main-screen session.
                    _rowCache.RequestClear();
                }
                _wasAltScreenLastFrame = isAltScreen;
                bool containsTextBlinkInk = false;
                int ligatureSelectionIndex = 0;

                for (int r = 0; r < bufferRows; r++)
                {
                    RenderRowSnapshot rowSnapshot = r < renderSnapshot.RowsData.Length && renderSnapshot.RowsData.Array != null
                        ? renderSnapshot.RowsData.Array[r]
                        : new RenderRowSnapshot
                        {
                            AbsRow = absDisplayStart + r,
                            Cols = 0,
                            Cells = Array.Empty<RenderCellSnapshot>(),
                            Revision = 0,
                            RowId = 0
                        };

                    var item = new RowRenderItem
                    {
                        AbsRow = rowSnapshot.AbsRow,
                        CachedPicture = null,
                        Snapshot = null
                    };

                    bool hasRenderableRow = rowSnapshot.Cols > 0 && rowSnapshot.Cells.Length >= rowSnapshot.Cols && rowSnapshot.RowId != 0;
                    if (hasRenderableRow)
                    {
                        if (_enableLigatures && ligatureSelectionIndex < renderSnapshot.SelectionRows.Length)
                        {
                            var selected = renderSnapshot.SelectionRows.Array[ligatureSelectionIndex];
                            if (selected.AbsRow == rowSnapshot.AbsRow)
                            {
                                item.LigatureSelection = selected;
                                ligatureSelectionIndex++;
                            }
                        }
                        item.HasBlinkInk = ContainsBlinkInk(rowSnapshot);
                        containsTextBlinkInk |= item.HasBlinkInk;
                        // A pre-animation picture must not become the span baseline when blinking ends.
                        if (useRowCache && item.HasBlinkInk) _rowCache?.InvalidateRow(rowSnapshot.RowId);
                        item.CachedPicture = useRowCache && !item.HasBlinkInk && item.LigatureSelection is null ? _rowCache?.Get(rowSnapshot.RowId, rowSnapshot.Revision) : null;

                        if (item.CachedPicture != null)
                        {
                            RendererStatistics.RecordRowCacheHit();
                            IncrementRowPictureCacheHit();
                        }
                        else
                        {
                            RendererStatistics.RecordRowCacheMiss();
                            IncrementRowPictureCacheMiss();
                            item.Snapshot = rowSnapshot;
                            RendererStatistics.RecordRowSnapshot();
                        }
                    }

                    frame.RowItems.Add(item);
                }
                _reportTextBlinkCells?.Invoke(containsTextBlinkInk);

                // --------------------
                // Render Phase (LOCK RELEASED)
                // --------------------
                using var bgPaint = new SKPaint { Style = SKPaintStyle.Fill };
                using var fgPaint = new SKPaint { Style = SKPaintStyle.Fill, IsAntialias = true };
                using var selectionPaint = new SKPaint { Color = ToSkColor(frame.RenderColors.Selection) };
                using var matchPaint = new SKPaint { Color = ToSkColor(frame.RenderColors.SearchMatch) };
                using var activeMatchPaint = new SKPaint { Color = ToSkColor(frame.RenderColors.SearchMatchActive) };
                SKColor? selectionForeground = frame.RenderColors.SelectionForeground is { } selectionFg ? ToSkColor(selectionFg) : null;

                // 1. Force Avalonia composition to completely wipe the reused SwapChain frame (destroys old ghost pixels)
                canvas.Clear(SKColors.Empty);

                // 2. Paint the terminal's theme background layer (with alpha) over the pristine canvas
                bgPaint.Color = frame.ThemeBg;
                bgPaint.BlendMode = SKBlendMode.SrcOver;
                canvas.DrawRect(0, 0, (float)Bounds.Width, (float)Bounds.Height, bgPaint);
                IncrementRectDrawCall();

                float paddingLeft = FromDevicePx(_pixelGrid.OriginXPx);
                float paddingTop = FromDevicePx(_pixelGrid.OriginYPx);
                float[] colEdges = EnsureCellEdgeGrid(ref _colEdges, ref _colEdgesCount, bufferCols, _pixelGrid.OriginXPx, _pixelGrid.CellWidthPx);
                float[] rowEdges = EnsureCellEdgeGrid(ref _rowEdges, ref _rowEdgesCount, bufferRows, _pixelGrid.OriginYPx, _pixelGrid.CellHeightPx);

                int dirtyCells = 0;
                int buildsThisFrame = 0;
                int spanRenderCount = 0;
                int rowRenderCount = 0;
                int maxBuilds = MaxPictureBuildsPerFrame; // always unlimited

                // Pass 3: Text
                var tf = _skTypeface?.Typeface ?? SKTypeface.FromFamilyName(_typeface.FontFamily.Name);
                LogPrimaryFontDiagnostics(tf);
                using var font = (_skFont?.Font != null)
                    ? new SKFont(_skFont.Font.Typeface, _skFont.Font.Size)
                    : new SKFont(tf, (float)_fontSize);

                font.Edging = SKFontEdging.Antialias;

                // Draw rows in visual order. RowItems count == bufferRows by construction.
                for (int r = 0; r < frame.RowItems.Count; r++)
                {
                    var item = frame.RowItems[r];
                    var rowSpans = (r < spansByRow.Length) ? spansByRow[r] : null;

                    int rowTopPx = _pixelGrid.YForRowTop(r);
                    int baselinePx = _pixelGrid.YForBaseline(r);
                    float rowTopY = FromDevicePx(rowTopPx);
                    float baselineY = FromDevicePx(baselinePx);

                    if (item.CachedPicture != null)
                    {
                        canvas.DrawPicture(item.CachedPicture, 0, rowTopY);
                        IncrementOtherDrawCall();
                        dirtyCells += bufferCols;
                        continue;
                    }

                    if (item.Snapshot.HasValue)
                    {
                        var snapshot = item.Snapshot.Value;
                        // Span repaint clears and clips in single-width column space, so a double-size row is always drawn whole.
                        // A change can reshape adjacent cells throughout an ASCII run.
                        bool shouldUseSpanRendering = !_enableLigatures && !item.HasBlinkInk && snapshot.LineSize == LineSize.SingleWidth
                            && rowSpans is { Count: > 0 } && ShouldUseSpanRenderingForRow(rowSpans, snapshot.Cols);

                        SKPicture? previousRowPicture = null;
                        if (shouldUseSpanRendering)
                        {
                            if (!(_rowCache?.TryGetLatestByRowId(snapshot.RowId, out previousRowPicture, out _) ?? false))
                            {
                                shouldUseSpanRendering = false;
                            }
                        }

                        if (shouldUseSpanRendering && previousRowPicture != null)
                        {
                            // Base row from previous cached revision, then repaint dirty spans only.
                            canvas.DrawPicture(previousRowPicture, 0, rowTopY);
                            IncrementOtherDrawCall();

                            int dirtyCellsInRow = 0;
                            for (int i = 0; i < rowSpans!.Count; i++)
                            {
                                var span = rowSpans[i];
                                int spanStart = Math.Max(0, span.ColStart - 1);
                                int spanEndExclusive = Math.Min(snapshot.Cols, span.ColEnd + 1);
                                if (spanEndExclusive <= spanStart)
                                {
                                    continue;
                                }

                                // OVERLAP FIX: Erase the dirty span bounding box before redrawing it.
                                // DrawRowTextFromSnapshot skips default background painting, so drawing over previousRowPicture 
                                // will leave ghost text mixed with the new text if not cleared.
                                float sx1 = GetColEdge(colEdges, spanStart, paddingLeft);
                                float sx2 = GetColEdge(colEdges, spanEndExclusive, paddingLeft);
                                float sH = FromDevicePx(_pixelGrid.CellHeightPx);
                                canvas.DrawRect(sx1, rowTopY, sx2 - sx1, sH, bgPaint);
                                IncrementRectDrawCall();

                                DrawRowTextFromSnapshot(
                                    canvas,
                                    snapshot,
                                    rowTopY: rowTopY,
                                    baselineY: baselineY,
                                    colEdges: colEdges,
                                    font,
                                    fgPaint,
                                    frame.ThemeFg,
                                    frame.ThemeBg,
                                    renderSnapshot.Theme,
                                    alpha,
                                    tf,
                                    drawBackgrounds: true,
                                    spanColStart: spanStart,
                                    spanColEndExclusive: spanEndExclusive);

                                spanRenderCount++;
                                dirtyCellsInRow += Math.Max(0, span.ColEnd - span.ColStart);
                            }

                            dirtyCells += dirtyCellsInRow;

                            // Refresh cache entry for the new revision (full-row picture for future frames).
                            // Skip when useRowCache=false (AltScreen) — no point recording a picture we won't store.
                            if (useRowCache && !item.HasBlinkInk && buildsThisFrame < maxBuilds)
                            {
                                var recSw = System.Diagnostics.Stopwatch.StartNew();
                                using var recorder = new SKPictureRecorder();
                                using var rowCanvas = recorder.BeginRecording(new SKRect(0, 0, (float)Bounds.Width, FromDevicePx(_pixelGrid.CellHeightPx)));
                                DrawRowTextFromSnapshot(
                                    rowCanvas,
                                    snapshot,
                                    rowTopY: 0f,
                                    baselineY: FromDevicePx(_pixelGrid.BaselineOffsetPx),
                                    colEdges: colEdges,
                                    font,
                                    fgPaint,
                                    frame.ThemeFg,
                                    frame.ThemeBg,
                                    renderSnapshot.Theme,
                                    alpha,
                                    tf,
                                    drawBackgrounds: true);

                                var picture = recorder.EndRecording();
                                _rowCache!.Add(snapshot.RowId, snapshot.Revision, picture);
                                IncrementPictureBuild();

                                recSw.Stop();
                                RendererStatistics.RecordRowPictureRecorded();
                                RendererStatistics.RecordRowPictureRecordTime(recSw.ElapsedMilliseconds);
                                buildsThisFrame++;
                            }
                        }
                        else if (buildsThisFrame < maxBuilds)
                        {
                            rowRenderCount++;
                            if (useRowCache && !item.HasBlinkInk && item.LigatureSelection is null)
                            {
                                // Record into a picture so it can be cached and replayed on future frames.
                                var recSw = System.Diagnostics.Stopwatch.StartNew();
                                using var recorder = new SKPictureRecorder();
                                using var rowCanvas = recorder.BeginRecording(new SKRect(0, 0, (float)Bounds.Width, FromDevicePx(_pixelGrid.CellHeightPx)));

                                DrawRowTextFromSnapshot(
                                    rowCanvas,
                                    snapshot,
                                    rowTopY: 0f,
                                    baselineY: FromDevicePx(_pixelGrid.BaselineOffsetPx),
                                    colEdges: colEdges,
                                    font,
                                    fgPaint,
                                    frame.ThemeFg,
                                    frame.ThemeBg,
                                    renderSnapshot.Theme,
                                    alpha,
                                    tf,
                                    drawBackgrounds: true);

                                var picture = recorder.EndRecording();
                                _rowCache!.Add(snapshot.RowId, snapshot.Revision, picture);
                                canvas.DrawPicture(picture, 0, rowTopY);
                                IncrementOtherDrawCall();
                                IncrementPictureBuild();

                                recSw.Stop();
                                RendererStatistics.RecordRowPictureRecorded();
                                RendererStatistics.RecordRowPictureRecordTime(recSw.ElapsedMilliseconds);
                                buildsThisFrame++;
                            }
                            else
                            {
                                // AltScreen / cache disabled: draw directly — no SKPicture allocation.
                                DrawRowTextFromSnapshot(
                                    canvas,
                                    snapshot,
                                    rowTopY: rowTopY,
                                    baselineY: baselineY,
                                    colEdges: colEdges,
                                    font,
                                    fgPaint,
                                    frame.ThemeFg,
                                    frame.ThemeBg,
                                    renderSnapshot.Theme,
                                    alpha,
                                    tf,
                                    drawBackgrounds: true,
                                    ligatureSelection: item.LigatureSelection);
                            }
                        }
                        else
                        {
                            rowRenderCount++;
                            // Budget exhausted: draw direct from snapshot (Correct BUT non-cached fallback)
                            DrawRowTextFromSnapshot(
                                canvas,
                                snapshot,
                                rowTopY: rowTopY,
                                baselineY: baselineY,
                                colEdges: colEdges,
                                font,
                                fgPaint,
                                frame.ThemeFg,
                                frame.ThemeBg,
                                renderSnapshot.Theme,
                                alpha,
                                tf,
                                drawBackgrounds: true,
                                ligatureSelection: item.LigatureSelection);
                        }

                        if (!shouldUseSpanRendering)
                        {
                            dirtyCells += bufferCols;
                        }
                    }
                }

                // Bound first-frame work for live panes; exports still materialize every image.
                int remainingImageDecodes = _requestImageFrame is null || _isolatedSnapshot ? int.MaxValue : 1;
                bool pendingImageDecode = false;
                // Metadata borrows the exact leased placements and bitmap used below, never a later buffer read.
                var imageFacts = _collectImageDetails ? RenderedImageFrame.From(frame.Images, absDisplayStart) : null;
                // Pass 2: Images
                using (var imagePaint = new SKPaint { Color = new SKColor(255, 255, 255, alpha) })
                using (var imageBgPaint = new SKPaint { Color = frame.ThemeBg, Style = SKPaintStyle.Fill, IsAntialias = false })
                {
                    for (int imageIndex = 0; imageIndex < frame.Images.Count; imageIndex++)
                    {
                        var img = frame.Images[imageIndex];
                        int visualY = img.CellY - absDisplayStart;
                        if (img.NativeRaster is not null)
                        {
                            var nativeBitmap = DrawNativeSixel(canvas, img, visualY,
                                imagePaint, imageBgPaint, ref remainingImageDecodes, ref pendingImageDecode);
                            if (nativeBitmap is not null && imageFacts is { Complete: true })
                                imageFacts.Placements[imageIndex] = imageFacts.Placements[imageIndex] with
                                { BitmapWidthPx = nativeBitmap.Width, BitmapHeightPx = nativeBitmap.Height };
                            continue;
                        }
                        if (visualY + img.CellHeight > 0 && visualY < bufferRows)
                        {
                            // The image's columns are its anchor row's: twice as wide on a double-size row.
                            float x = LineSizeX(GetColEdge(colEdges, img.CellX, paddingLeft), img.LineSize);
                            float x2 = LineSizeX(GetColEdge(colEdges, img.CellX + img.CellWidth, paddingLeft), img.LineSize);
                            float y = GetRowEdge(rowEdges, visualY, paddingTop);
                            float y2 = GetRowEdge(rowEdges, visualY + img.CellHeight, paddingTop);
                            float w = x2 - x;
                            float h = y2 - y;

                            var rect = new SKRect(x, y, x + w, y + h);

                            canvas.Save();
                            canvas.ClipRect(new SKRect(paddingLeft, 0, (float)Bounds.Width, (float)Bounds.Height));
                            // A Unicode placeholder run shows its part of a bitmap fitted into a larger grid: only its own cells may be painted.
                            bool isPlaceholderRun = img.GridColumns > 0;
                            if (isPlaceholderRun) canvas.ClipRect(rect);
                            if (img.ClipTopRows > 0 || img.ClipBottomRows > 0 || img.ClipRightColumns > 0)
                            {
                                canvas.ClipRect(new SKRect(x,
                                    GetRowEdge(rowEdges, visualY + img.ClipTopRows, paddingTop),
                                    LineSizeX(GetColEdge(colEdges, img.CellX + img.CellWidth - img.ClipRightColumns, paddingLeft), img.LineSize),
                                    GetRowEdge(rowEdges, visualY + img.CellHeight - img.ClipBottomRows, paddingTop)));
                            }
                            // Clear image target region first so transparent/semi-transparent
                            // image pixels do not reveal previously drawn text layers.
                            // A placeholder run keeps its own cells' background colour instead, shown through transparent pixels.
                            using var runBgPaint = isPlaceholderRun ? PlaceholderBackgroundPaint(img, renderSnapshot.Theme) : null;
                            canvas.DrawRect(rect, runBgPaint ?? imageBgPaint);
                            IncrementRectDrawCall();
                            SKBitmap? bitmap = img.ImageHandle as SKBitmap;
                            if (img.ImageHandle is DeferredSixelImage deferred)
                            {
                                bitmap = deferred.GetBitmap(ref remainingImageDecodes, out bool pending);
                                pendingImageDecode |= pending;
                            }
                            if (img.ImageHandle is NativeSixelImage native)
                            {
                                bitmap = native.GetBitmap(ref remainingImageDecodes, out bool pending);
                                pendingImageDecode |= pending;
                            }
                            if (bitmap is { } bmp)
                            {
                                SKRect fitArea = isPlaceholderRun ? PlaceholderGrid(img, visualY, colEdges, rowEdges, paddingLeft, paddingTop) : rect;
                                SKRect destination = isPlaceholderRun || img.PreserveAspectRatio ? FitImageWithin(fitArea, bmp.Width, bmp.Height) : rect;
                                // Every run of a placement fits the bitmap into the same single-width grid, so the runs
                                // sample it alike; a run on a double-size row then shows its part twice as wide.
                                if (isPlaceholderRun && img.LineSize != LineSize.SingleWidth)
                                    destination = new SKRect(LineSizeX(destination.Left, img.LineSize), destination.Top,
                                        LineSizeX(destination.Right, img.LineSize), destination.Bottom);
                                canvas.DrawBitmap(bmp, destination, imagePaint);
                                if (imageFacts is { Complete: true })
                                    imageFacts.Placements[imageIndex] = imageFacts.Placements[imageIndex] with
                                    { BitmapWidthPx = bmp.Width, BitmapHeightPx = bmp.Height };
                                IncrementOtherDrawCall();
                            }
                            canvas.Restore();
                        }
                    }
                }

                if (imageFacts is not null && RenderedFrame is { } rendered)
                    RenderedFrame = rendered with { Images = imageFacts };
                if (pendingImageDecode) _requestImageFrame?.Invoke();

                // Redraws the text of [colStart, colEndExclusive) on visual row r over an overlay
                // just drawn on top of it, so a selection, search match or block cursor is a fill
                // under the glyphs rather than a veil over them: a theme's explicit selection color
                // is usually opaque. Backgrounds are not redrawn; the overlay is the background.
                void RedrawTextOver(int r, int colStart, int colEndExclusive, SKColor? foregroundOverride, SKColor? overlayFill = null)
                {
                    if (renderSnapshot.RowsData.Array == null || r < 0 || r >= renderSnapshot.RowsData.Length)
                    {
                        return;
                    }

                    var row = renderSnapshot.RowsData.Array[r];
                    if (row.Cols <= 0 || row.Cells.Length < row.Cols)
                    {
                        return;
                    }

                    DrawRowTextFromSnapshot(
                        canvas,
                        row,
                        rowTopY: FromDevicePx(_pixelGrid.YForRowTop(r)),
                        baselineY: FromDevicePx(_pixelGrid.YForBaseline(r)),
                        colEdges: colEdges,
                        font,
                        fgPaint,
                        frame.ThemeFg,
                        frame.ThemeBg,
                        renderSnapshot.Theme,
                        alpha,
                        tf,
                        drawBackgrounds: false,
                        spanColStart: colStart,
                        spanColEndExclusive: colEndExclusive,
                        foregroundOverride: foregroundOverride,
                        overlayFill: overlayFill,
                        ligatureSelection: frame.RowItems[r].LigatureSelection);
                }

                // Pass 4: Overlays (Selection / Search)
                int selectionIndex = 0;
                int matchIndex = 0;
                var selectionRows = renderSnapshot.SelectionRows;
                var searchHighlights = renderSnapshot.SearchHighlights;
                for (int r = 0; r < bufferRows; r++)
                {
                    float y = FromDevicePx(_pixelGrid.YForRowTop(r));
                    float rowBottom = FromDevicePx(_pixelGrid.YForRowTop(r + 1));
                    float rowHeight = rowBottom - y;
                    int absRow = absDisplayStart + r;

                    while (selectionIndex < selectionRows.Length && selectionRows.Array[selectionIndex].AbsRow < absRow)
                    {
                        selectionIndex++;
                    }

                    int selTemp = selectionIndex;
                    while (selTemp < selectionRows.Length && selectionRows.Array[selTemp].AbsRow == absRow)
                    {
                        var sel = selectionRows.Array[selTemp];
                        LineSize overlayLineSize = LineSizeOfVisualRow(renderSnapshot, r);
                        float x1 = LineSizeX(GetColEdge(colEdges, sel.ColStart, paddingLeft), overlayLineSize);
                        float x2 = LineSizeX(GetColEdge(colEdges, sel.ColEnd + 1, paddingLeft), overlayLineSize);
                        canvas.DrawRect(x1, y, x2 - x1, rowHeight, selectionPaint);
                        IncrementRectDrawCall();
                        RedrawTextOver(r, sel.ColStart, sel.ColEnd + 1, selectionForeground, selectionPaint.Color);
                        selTemp++;
                    }

                    // Sub-linear scan for search matches (assumes highlights are sorted by AbsRow)
                    while (matchIndex < searchHighlights.Length && searchHighlights.Array[matchIndex].AbsRow < absRow)
                    {
                        matchIndex++;
                    }

                    int tempIdx = matchIndex;
                    while (tempIdx < searchHighlights.Length && searchHighlights.Array[tempIdx].AbsRow == absRow)
                    {
                        var m = searchHighlights.Array[tempIdx];
                        var p = m.IsActive ? activeMatchPaint : matchPaint;
                        LineSize overlayLineSize = LineSizeOfVisualRow(renderSnapshot, r);
                        float x1 = LineSizeX(GetColEdge(colEdges, m.StartCol, paddingLeft), overlayLineSize);
                        float x2 = LineSizeX(GetColEdge(colEdges, m.EndCol + 1, paddingLeft), overlayLineSize);
                        canvas.DrawRect(x1, y, x2 - x1, rowHeight, p);
                        IncrementRectDrawCall();
                        RedrawTextOver(r, m.StartCol, m.EndCol + 1, foregroundOverride: null, overlayFill: p.Color);
                        tempIdx++;
                    }
                }

                // Cursor (optional policy: hide cursor when scrolled back)
                if (frame.CursorVisible && _scrollOffset == 0)
                {
                    // CursorRow indexes the buffer's own viewport, so it is anchored on the buffer's row count,
                    // not the view's. The two differ between a layout and the resize that follows it (the
                    // 60ms throttle, or a session that applies resizes from its stream); anchoring on the
                    // view's count put the cursor a row above the prompt for each row a pane had just grown.
                    int absCursorRow = (renderSnapshot.TotalLines - renderSnapshot.BufferRows) + renderSnapshot.CursorRow;
                    int visualRow = absCursorRow - absDisplayStart;

                    if (visualRow >= 0 && visualRow < bufferRows)
                    {
                        // On a double-size line the cursor is two cells wide and cannot sit past the line's last column,
                        // where a vertical move may have left it until the next character is written.
                        LineSize cursorLineSize = LineSizeOfVisualRow(renderSnapshot, visualRow);
                        int cursorDrawCol = cursorLineSize == LineSize.SingleWidth
                            ? renderSnapshot.CursorCol
                            : Math.Min(renderSnapshot.CursorCol, TerminalBuffer.ColumnsForLineSize(cursorLineSize, renderSnapshot.BufferCols) - 1);
                        float x1 = LineSizeX(FromDevicePx(_pixelGrid.XForCol(cursorDrawCol)), cursorLineSize);
                        float x2 = LineSizeX(FromDevicePx(_pixelGrid.XForCol(cursorDrawCol + 1)), cursorLineSize);
                        int rowTopPx = _pixelGrid.YForRowTop(visualRow);
                        int rowBottomPx = _pixelGrid.YForRowTop(visualRow + 1);
                        float rowTop = FromDevicePx(rowTopPx);
                        float rowBottom = FromDevicePx(rowBottomPx);
                        float rowHeight = rowBottom - rowTop;
                        using var cursorPaint = new SKPaint { Color = frame.CursorColor, Style = SKPaintStyle.Fill };

                        switch (frame.CursorStyle)
                        {
                            case CursorStyle.Block:
                                {
                                    canvas.DrawRect(x1, rowTop, x2 - x1, rowHeight, cursorPaint);
                                    IncrementRectDrawCall();
                                    // The glyph under the block, in the theme's cursor text color
                                    // (it used to be hidden by the opaque rect).
                                    int cursorCol = cursorDrawCol;
                                    int cursorEnd = cursorCol + 1;
                                    if (renderSnapshot.RowsData.Array != null && visualRow < renderSnapshot.RowsData.Length)
                                    {
                                        var cursorRow = renderSnapshot.RowsData.Array[visualRow];
                                        if (cursorCol >= 0 && cursorCol < cursorRow.Cells.Length && cursorRow.Cells[cursorCol].IsWide)
                                        {
                                            cursorEnd = cursorCol + 2;
                                        }
                                    }

                                    canvas.Save();
                                    canvas.ClipRect(new SKRect(x1, rowTop, x2, rowBottom));
                                    RedrawTextOver(visualRow, cursorCol, cursorEnd, ToSkColor(frame.RenderColors.CursorText));
                                    canvas.Restore();
                                    break;
                                }
                            case CursorStyle.Beam:
                                {
                                    int beamWPx = Math.Max(1, (int)Math.Floor(_pixelGrid.CellWidthPx * 0.14));
                                    float beamW = FromDevicePx(beamWPx);
                                    canvas.DrawRect(x1, rowTop, beamW, rowHeight, cursorPaint);
                                    IncrementRectDrawCall();
                                    break;
                                }
                            case CursorStyle.Underline:
                            default:
                                {
                                    float uY = FromDevicePx(_pixelGrid.YForUnderline(visualRow));
                                    float underlineH = FromDevicePx(Math.Max(1, ToDevicePx(2)));
                                    canvas.DrawRect(x1, uY, x2 - x1, underlineH, cursorPaint);
                                    IncrementRectDrawCall();
                                    break;
                                }
                        }
                    }
                }

                if (GridDiagnosticsEnabled)
                {
                    DrawDebugCellGrid(canvas, colEdges, _colEdgesCount, rowEdges, _rowEdgesCount);
                }

                frameSw.Stop();
                RendererStatistics.RecordFrameRenderTime(frameSw.ElapsedMilliseconds);
                RendererStatistics.RecordFrame(fullRedraw: true, dirtyCells: dirtyCells);
                if (_collectFramePerfMetrics || _showRenderHud)
                {
                    _framePerfMetrics.DirtySpanCount = dirtySpanCount;
                    _framePerfMetrics.SpanRenderCount = spanRenderCount;
                    _framePerfMetrics.RowRenderCount = rowRenderCount;
                    _framePerfMetrics.DirtyCellsEstimated = dirtyCells;
                    _framePerfMetrics.FrameTimeMs = frameSw.Elapsed.TotalMilliseconds;
                    _framePerfMetrics.FrameIndex = RendererStatistics.TotalFrames;
                    _framePerfMetrics.Backend = _renderBackend;
                }

                if (_showRenderHud)
                {
                    DrawPerformanceHud(canvas, _framePerfMetrics, alpha);
                }

                CompleteFramePerfMetrics(perfWriter, frameSw.Elapsed.TotalMilliseconds, dirtyRowCount, dirtySpanCount);

                return renderSnapshot;
            }
            catch (Exception ex)
            {
                long now = DateTime.UtcNow.Ticks;
                if (now - _lastRenderErrorLogTicks >= RenderErrorLogIntervalTicks)
                {
                    _lastRenderErrorLogTicks = now;
                    TerminalLogger.Error("Render frame failed (rate-limited). " + ex);
                }
                throw;
            }
            finally
            {
                DisposeAndClearShapingCache();
                DisposeAndClearFallbackFontCache();
            }
        }

        private TerminalRenderSnapshot? DrawTerminal(SKCanvas canvas)
            => DrawTerminalInternal(canvas);

        private void DrawPerformanceHud(SKCanvas canvas, RenderPerfMetrics metrics, byte alpha)
        {
            float hudWidth = 280f;
            float hudHeight = 106f;
            float padding = 10f;
            float margin = 10f;

            // Top Right
            float x = (float)Bounds.Width - hudWidth - margin;
            float y = margin;

            using var bgPaint = new SKPaint
            {
                Color = new SKColor(0, 0, 0, (byte)(alpha * 0.85f)),
                Style = SKPaintStyle.Fill,
                IsAntialias = true
            };
            canvas.DrawRoundRect(new SKRect(x, y, x + hudWidth, y + hudHeight), 4, 4, bgPaint);

            using var borderPaint = new SKPaint
            {
                Color = new SKColor(100, 100, 100, alpha),
                Style = SKPaintStyle.Stroke,
                StrokeWidth = 1,
                IsAntialias = true
            };
            canvas.DrawRoundRect(new SKRect(x, y, x + hudWidth, y + hudHeight), 4, 4, borderPaint);

            using var textPaint = new SKPaint
            {
                Color = new SKColor(0, 255, 0, alpha),
                IsAntialias = true
            };
            using var textFont = new SKFont(SKTypeface.Default, 12f);

            float textX = x + padding;
            float textY = y + padding + 12f;
            float lineHeight = 16f;

            canvas.DrawText($"Frame: {metrics.FrameTimeMs:F2} ms", textX, textY, SKTextAlign.Left, textFont, textPaint);
            textY += lineHeight;
            canvas.DrawText($"Dirty Cells: {metrics.DirtyCellsEstimated} | Rows: {metrics.DirtyRows}", textX, textY, SKTextAlign.Left, textFont, textPaint);
            textY += lineHeight;
            canvas.DrawText($"Draws: {metrics.DrawCallsTotal} (Cache:{metrics.RowPictureCacheHits}/{metrics.RowPictureCacheMisses})", textX, textY, SKTextAlign.Left, textFont, textPaint);
            textY += lineHeight;
            canvas.DrawText($"Atlas Builds: {metrics.AtlasAlphaGlyphs}/{metrics.AtlasColorGlyphs} | Mem: {metrics.AllocBytesThisFrame / 1024.0:F1} kb", textX, textY, SKTextAlign.Left, textFont, textPaint);
            textY += lineHeight;
            canvas.DrawText($"Backend: {metrics.Backend ?? RenderBackend.Offscreen}", textX, textY, SKTextAlign.Left, textFont, textPaint);
        }

        private void FlushBatches(SKCanvas canvas)
        {
            if (_glyphCache == null) return;

            var (alphaAtlas, colorAtlas) = _glyphCache.GetAtlasImages();
            int alphaGlyphs = _alphaCount;
            int colorGlyphs = _colorCount;
            int atlasDrawCalls = 0;

            if (alphaGlyphs > 0)
            {
                var alphaRectsScratch = EnsureScratchCapacity(ref _alphaRectsScratch, alphaGlyphs);
                var alphaXformsScratch = EnsureScratchCapacity(ref _alphaXformsScratch, alphaGlyphs);
                var alphaColorsScratch = EnsureScratchCapacity(ref _alphaColorsScratch, alphaGlyphs);
                Array.Copy(_alphaRects, alphaRectsScratch, alphaGlyphs);
                Array.Copy(_alphaXforms, alphaXformsScratch, alphaGlyphs);
                Array.Copy(_alphaColors, alphaColorsScratch, alphaGlyphs);
                if (_alphaScratchPrevCount > alphaGlyphs)
                {
                    int tailLength = _alphaScratchPrevCount - alphaGlyphs;
                    Array.Clear(alphaRectsScratch, alphaGlyphs, tailLength);
                    Array.Clear(alphaXformsScratch, alphaGlyphs, tailLength);
                    Array.Clear(alphaColorsScratch, alphaGlyphs, tailLength);
                }
                _alphaScratchPrevCount = alphaGlyphs;

                _atlasAlphaPaint.Style = SKPaintStyle.Fill;
                _atlasAlphaPaint.IsAntialias = false;
                canvas.DrawAtlas(
                    alphaAtlas,
                    alphaRectsScratch,
                    alphaXformsScratch,
                    alphaColorsScratch,
                    SKBlendMode.Modulate,
                    new SKSamplingOptions(SKFilterMode.Nearest),
                    _atlasAlphaPaint);
                atlasDrawCalls++;

                _alphaCount = 0;
            }

            if (colorGlyphs > 0)
            {
                var colorRectsScratch = EnsureScratchCapacity(ref _colorRectsScratch, colorGlyphs);
                var colorXformsScratch = EnsureScratchCapacity(ref _colorXformsScratch, colorGlyphs);
                Array.Copy(_colorRects, colorRectsScratch, colorGlyphs);
                Array.Copy(_colorXforms, colorXformsScratch, colorGlyphs);
                if (_colorScratchPrevCount > colorGlyphs)
                {
                    int tailLength = _colorScratchPrevCount - colorGlyphs;
                    Array.Clear(colorRectsScratch, colorGlyphs, tailLength);
                    Array.Clear(colorXformsScratch, colorGlyphs, tailLength);
                }
                _colorScratchPrevCount = colorGlyphs;

                _atlasColorPaint.Style = SKPaintStyle.Fill;
                _atlasColorPaint.IsAntialias = false;
                canvas.DrawAtlas(
                    colorAtlas,
                    colorRectsScratch,
                    colorXformsScratch,
                    null,
                    SKBlendMode.SrcOver,
                    new SKSamplingOptions(SKFilterMode.Linear),
                    _atlasColorPaint);
                atlasDrawCalls++;

                _colorCount = 0;
            }

            if (atlasDrawCalls > 0)
            {
                RecordFlush(alphaGlyphs, colorGlyphs, atlasDrawCalls);
            }
        }

        private void AddAlphaBatchEntry(SKRect rect, SKRotationScaleMatrix xform, SKColor color)
        {
            EnsureAlphaBatchCapacity(_alphaCount + 1);
            int index = _alphaCount++;
            _alphaRects[index] = rect;
            _alphaXforms[index] = xform;
            _alphaColors[index] = color;
        }

        private void AddColorBatchEntry(SKRect rect, SKRotationScaleMatrix xform)
        {
            EnsureColorBatchCapacity(_colorCount + 1);
            int index = _colorCount++;
            _colorRects[index] = rect;
            _colorXforms[index] = xform;
        }

        private void EnsureAlphaBatchCapacity(int requiredCount)
        {
            if (_alphaRects.Length >= requiredCount)
            {
                return;
            }

            int current = _alphaRects.Length;
            int newCapacity = Math.Max(requiredCount, Math.Max(InitialAtlasBatchCapacity, current == 0 ? InitialAtlasBatchCapacity : current * 2));
            Array.Resize(ref _alphaRects, newCapacity);
            Array.Resize(ref _alphaXforms, newCapacity);
            Array.Resize(ref _alphaColors, newCapacity);
        }

        private void EnsureColorBatchCapacity(int requiredCount)
        {
            if (_colorRects.Length >= requiredCount)
            {
                return;
            }

            int current = _colorRects.Length;
            int newCapacity = Math.Max(requiredCount, Math.Max(InitialAtlasBatchCapacity, current == 0 ? InitialAtlasBatchCapacity : current * 2));
            Array.Resize(ref _colorRects, newCapacity);
            Array.Resize(ref _colorXforms, newCapacity);
        }

        private static T[] EnsureScratchCapacity<T>(ref T[]? buffer, int requiredCount)
        {
            if (requiredCount <= 0)
            {
                return buffer ??= Array.Empty<T>();
            }

            if (buffer == null)
            {
                buffer = new T[Math.Max(InitialAtlasBatchCapacity, requiredCount)];
                return buffer;
            }

            if (buffer.Length >= requiredCount)
            {
                return buffer;
            }

            int newCapacity = buffer.Length == 0 ? InitialAtlasBatchCapacity : buffer.Length;
            while (newCapacity < requiredCount)
            {
                newCapacity = Math.Max(InitialAtlasBatchCapacity, newCapacity * 2);
            }

            Array.Resize(ref buffer, newCapacity);
            return buffer;
        }

        private SKFont GetOrCreateFallbackFont(SKTypeface tf)
        {
            if (_fallbackFontCache.TryGetValue(tf, out var cached))
            {
                return cached;
            }

            var created = new SKFont(tf, (float)_fontSize) { Edging = SKFontEdging.Antialias };
            _fallbackFontCache[tf] = created;
            return created;
        }

        private ShapingResources GetOrCreateShapingResources(SKTypeface tf)
        {
            if (_shapingCache.TryGetValue(tf, out var cached))
            {
                return cached;
            }

            var font = new SKFont(tf, (float)_fontSize) { Edging = SKFontEdging.Antialias };
            var shaper = new SKShaper(tf);
            var created = new ShapingResources(shaper, font);
            _shapingCache[tf] = created;
            return created;
        }

        private void DisposeAndClearFallbackFontCache()
        {
            if (_fallbackFontCache.Count == 0)
            {
                return;
            }

            foreach (var cached in _fallbackFontCache.Values)
            {
                cached.Dispose();
            }

            _fallbackFontCache.Clear();
        }

        private void DisposeAndClearShapingCache()
        {
            if (_shapingCache.Count == 0)
            {
                return;
            }

            foreach (var resources in _shapingCache.Values)
            {
                resources.Shaper.Dispose();
                resources.Font.Dispose();
            }

            _shapingCache.Clear();
        }

        private static bool ContainsBlinkInk(RenderRowSnapshot row)
        {
            if (!row.ContainsBlink) return false;
            for (int col = 0; col < Math.Min(row.Cols, row.Cells.Length); col++)
                if (CellHasBlinkInk(row.Cells[col])) return true;
            return false;
        }

        private static bool CellHasBlinkInk(RenderCellSnapshot cell)
        {
            if (!cell.IsBlink || cell.IsHidden || cell.IsWideContinuation) return false;
            if (cell.IsStrikethrough || cell.Underline?.Overline == true) return true;
            if (cell.IsUnderline && (cell.Underline is { HasColor: true } || cell.Underline?.Style is > UnderlineStyle.Single)) return true;
            if (cell.TextSizing is { } sized) return ContainsNonWhitespace(sized.Block.Text);
            if (cell.Text is { } text) return ContainsNonWhitespace(text);
            return cell.Character != '\0' && !char.IsWhiteSpace(cell.Character);
        }

        private int DrawRowTextFromSnapshot(
            SKCanvas canvas,
            RenderRowSnapshot snapshot,
            float rowTopY,
            float baselineY,
            float[] colEdges,
            SKFont font,
            SKPaint fgPaint,
            SKColor themeFg,
            SKColor themeBg,
            RenderThemeSnapshot themeSnapshot,
            byte alpha,
            SKTypeface primaryTf,
            bool drawBackgrounds,
            int spanColStart = 0,
            int spanColEndExclusive = int.MaxValue,
            SKColor? foregroundOverride = null,
            SKColor? overlayFill = null,
            SelectionRowSnapshot? ligatureSelection = null)
        {
            const float paddingLeft = 4f;
            int cellsRendered = 0;
            float snappedCellHeight = FromDevicePx(_cellHeightDevicePx);
            int rowTopPx = ToDevicePx(rowTopY);
            int baselinePx = ToDevicePx(baselineY);
            int rowIndex = _pixelGrid.CellHeightPx > 0 ? (rowTopPx - _pixelGrid.OriginYPx) / _pixelGrid.CellHeightPx : 0;
            float rowTopYDip = FromDevicePx(rowTopPx);
            float baselineYDip = FromDevicePx(baselinePx);
            int effectiveSpanStart = Math.Clamp(spanColStart, 0, snapshot.Cols);
            int effectiveSpanEnd = Math.Clamp(spanColEndExclusive, effectiveSpanStart, snapshot.Cols);
            if (effectiveSpanEnd <= effectiveSpanStart)
            {
                return 0;
            }

            // A double-size line is the same row drawn through a transform: every x doubles about the grid origin, and a
            // double-height half also doubles y and shows its half through the row's own band. Everything below, the
            // span clip included, is then in the row's own column space.
            bool lineSizeScaled = BeginLineSizeTransform(canvas, snapshot.LineSize, snapshot.BufferCols > 0 ? snapshot.BufferCols : snapshot.Cols, rowTopYDip, snappedCellHeight);
            bool glyphAtlasWasSuppressed = _suppressGlyphAtlas;
            _suppressGlyphAtlas |= lineSizeScaled;

            bool hasSpanClip = effectiveSpanStart > 0 || effectiveSpanEnd < snapshot.Cols;
            if (hasSpanClip)
            {
                float clipX1 = FromDevicePx(_pixelGrid.XForCol(effectiveSpanStart));
                float clipX2 = FromDevicePx(_pixelGrid.XForCol(effectiveSpanEnd));
                canvas.Save();
                canvas.ClipRect(new SKRect(clipX1, rowTopYDip, clipX2, rowTopYDip + snappedCellHeight));
            }

            try
            {
                if (_runBuilder.Capacity > RunBuilderMaxCapacity)
                {
                    // Guard against permanently retaining very large capacities after outlier runs.
                    _runBuilder.Clear();
                    _runBuilder.Capacity = RunBuilderInitialCapacity;
                }

                if (_runCellTexts.Capacity > RunBuilderMaxCapacity)
                {
                    _runCellTexts.Clear();
                    _runCellTexts.Capacity = 64;
                }

                var runBuilder = _runBuilder;
                var runCellTexts = _runCellTexts;

                int c = 0;
                while (c < snapshot.Cols)
                {
                    var cell = snapshot.Cells[c];
                    if (cell.IsWideContinuation)
                    {
                        c++;
                        continue;
                    }
                    if (cell.TextSizing is { } sized)
                    {
                        if (sized.ColumnOffset == 0)
                            cellsRendered += DrawSizedTextRow(canvas, cell, sized, c, new SizedTextRowPaint
                            {
                                RowTop = rowTopYDip,
                                Baseline = baselineYDip,
                                RowHeight = snappedCellHeight,
                                Paint = fgPaint,
                                ThemeFg = themeFg,
                                ThemeBg = themeBg,
                                Theme = themeSnapshot,
                                Alpha = alpha,
                                Primary = primaryTf,
                                DrawBackgrounds = drawBackgrounds,
                                HasVisibleText = ContainsNonWhitespace(sized.Block.Text),
                                SuppressInk = cell.IsHidden || (cell.IsBlink && !_textBlinkVisible),
                                ForegroundOverride = foregroundOverride,
                                OverlayFill = overlayFill
                            });
                        c++;
                        continue;
                    }

                    var cb = ResolveCellBackground(cell, themeBg, alpha, themeSnapshot);
                    var cf = ResolveCellForeground(cell, themeFg, alpha, themeSnapshot);
                    bool runIsBold = cell.IsBold;
                    bool runIsItalic = cell.IsItalic;
                    bool runIsUnderline = cell.IsUnderline;
                    CellUnderline? runUnderline = cell.Underline;
                    bool runIsStrikethrough = cell.IsStrikethrough;
                    bool runIsFaint = cell.IsFaint;
                    bool runIsHidden = cell.IsHidden;
                    bool runIsBlink = cell.IsBlink;
                    var bg = cell.IsInverse ? cf : cb;
                    var fg = EnforceMinimumContrast(PresentedTextColor(cell, cf, cb), bg, overlayFill);
                    if (runIsFaint)
                    {
                        fg = BlendTowards(fg, bg, 0.5f);
                    }

                    if (foregroundOverride is { } overrideFg)
                    {
                        fg = overrideFg;
                    }

                    runBuilder.Clear();
                    runCellTexts.Clear();
                    int totalRunWidth = 0;
                    bool runNeedsComplexShaping = false;
                    bool runHasBoxDrawing = false;
                    bool runHasComplexShapingGlyph = false;
                    bool runIsAscii = false;
                    int k = c;

                    while (k < snapshot.Cols)
                    {
                        var next = snapshot.Cells[k];
                        if (next.TextSizing != null) break;
                        if (next.IsWideContinuation)
                        {
                            k++;
                            continue;
                        }

                        var ncb = ResolveCellBackground(next, themeBg, alpha, themeSnapshot);
                        var ncf = ResolveCellForeground(next, themeFg, alpha, themeSnapshot);
                        var nbg = next.IsInverse ? ncf : ncb;
                        var nfg = EnforceMinimumContrast(PresentedTextColor(next, ncf, ncb), nbg, overlayFill);
                        if (next.IsFaint)
                        {
                            nfg = BlendTowards(nfg, nbg, 0.5f);
                        }

                        if (foregroundOverride is { } nextOverrideFg)
                        {
                            nfg = nextOverrideFg;
                        }

                        if (nfg != fg || nbg != bg)
                            break;
                        if (next.IsBold != runIsBold ||
                            next.IsItalic != runIsItalic ||
                            next.IsUnderline != runIsUnderline ||
                            !Equals(next.Underline, runUnderline) ||
                            next.IsStrikethrough != runIsStrikethrough ||
                            next.IsFaint != runIsFaint ||
                            next.IsHidden != runIsHidden ||
                            next.IsBlink != runIsBlink)
                            break;

                        string cellText = NormalizeTextElementForRender(next.Text ?? next.Character.ToString());
                        bool cellIsAscii = _enableLigatures && !next.IsWide && cellText.Length == 1
                            && cellText[0] is >= ' ' and <= '~';
                        if (k == c) runIsAscii = cellIsAscii;
                        else if (cellIsAscii != runIsAscii || (runIsAscii && ligatureSelection is { } selection
                            && (k == selection.ColStart || k == selection.ColEnd + 1)))
                            break;

                        bool cellHasBoxDrawing = ContainsBoxDrawing(cellText);
                        bool cellNeedsComplexShaping = _enableComplexShaping && ContainsRunesRequiringComplexShaping(cellText);

                        if (k > c)
                        {
                            // Keep box-drawing runs isolated from icon/complex-shaping runs so
                            // snapped box primitives are not bypassed by mixed run shaping.
                            if ((runHasBoxDrawing && cellNeedsComplexShaping) ||
                                (runHasComplexShapingGlyph && cellHasBoxDrawing))
                            {
                                break;
                            }

                            // Keep complex-script shaping runs isolated from plain LTR runs.
                            // Mixing prefixes like "Arabic: " with Arabic text in a single shaper
                            // run can produce incorrect bidi/shaping output.
                            if ((runHasComplexShapingGlyph && !cellNeedsComplexShaping) ||
                                (!runHasComplexShapingGlyph && cellNeedsComplexShaping))
                            {
                                break;
                            }
                        }

                        runHasBoxDrawing |= cellHasBoxDrawing;
                        runHasComplexShapingGlyph |= cellNeedsComplexShaping;
                        runNeedsComplexShaping = runHasComplexShapingGlyph && !runHasBoxDrawing;

                        runBuilder.Append(cellText);
                        runCellTexts.Add(cellText);
                        int w = GetSafeGraphemeWidth(cellText); // GetGraphemeWidth is thread-safe
                        totalRunWidth += w;
                        k++;
                    }

                    int runStartCol = c;
                    int runEndCol = c + totalRunWidth;
                    if (runEndCol <= effectiveSpanStart)
                    {
                        c = k;
                        continue;
                    }

                    if (runStartCol >= effectiveSpanEnd)
                    {
                        break;
                    }

                    string runText = runBuilder.ToString();
                    float rx = FromDevicePx(_pixelGrid.XForCol(c));
                    float rx2 = FromDevicePx(_pixelGrid.XForCol(c + totalRunWidth));
                    fgPaint.Color = fg;
                    float rw = rx2 - rx;
                    float strokeWidth = Math.Max(1f, (float)(_metrics.CellHeight * 0.06));

                    // Backgrounds (when requested)
                    if (drawBackgrounds && bg != themeBg && bg.Alpha != 0)
                    {
                        _bgFillPaint.Color = bg;
                        _bgFillPaint.Style = SKPaintStyle.Fill;
                        _bgFillPaint.IsAntialias = false;
                        canvas.DrawRect(rx, rowTopYDip, rw, snappedCellHeight, _bgFillPaint);
                        IncrementRectDrawCall();
                    }

                    if (runIsHidden || (runIsBlink && !_textBlinkVisible))
                    {
                        cellsRendered += totalRunWidth;
                        c = k;
                        continue;
                    }

                    // Fonts here and in the fallback/shaping caches belong to this draw operation.
                    // Set every run, including normal runs, so adjacent styles cannot bleed.
                    font.Embolden = runIsBold;
                    bool appliedItalicTransform = false;
                    if (runIsItalic)
                    {
                        FlushBatches(canvas);
                        canvas.Save();
                        canvas.Translate(rx, baselineYDip);
                        canvas.Skew(-0.22f, 0f);
                        canvas.Translate(-rx, -baselineYDip);
                        appliedItalicTransform = true;
                    }

                    bool hasLigatureClip = runIsAscii && DrawAsciiLigatures(canvas, runText, c, rowTopYDip,
                        snappedCellHeight, baselineYDip, font, fgPaint, primaryTf);
                    if (runNeedsComplexShaping)
                    {
                        FlushBatches(canvas);
                        int fallbackChar = FindFirstMissingGlyphCodePoint(runText, primaryTf);
                        SKTypeface tfToUse = fallbackChar != 0
                            ? ResolveTypefaceForCodePoint(fallbackChar, primaryTf)
                            : primaryTf;

                        bool useLayer = totalRunWidth > 1;
                        if (useLayer)
                        {
                            canvas.SaveLayer(new SKRect(rx, rowTopYDip, rx + rw, rowTopYDip + (float)_metrics.CellHeight), null);
                        }

                        var shapingResources = GetOrCreateShapingResources(tfToUse ?? primaryTf);
                        var shapedFont = shapingResources.Font;
                        shapedFont.Embolden = runIsBold;
                        var shaper = shapingResources.Shaper;
                        LogBoxRunDiagnostics(runText, totalRunWidth, shapedFont, shapedFont.MeasureText(runText));
                        canvas.DrawShapedText(shaper, runText, rx, baselineYDip, shapedFont, fgPaint);
                        IncrementShapedTextRun();
                        IncrementTextDrawCall();

                        if (useLayer) canvas.Restore();
                        cellsRendered += totalRunWidth;
                    }
                    else
                    {
                        if (_glyphCache != null && !runIsItalic)
                        {
                            // The shortcut skips the decorations below, so a run of blanks carrying a styled or colored
                            // underline (#270) or strikethrough takes the per-glyph path so its decoration is painted.
                            if (!hasLigatureClip && runUnderline is null && !runIsStrikethrough && ShouldDrawRunDirectWhenGlyphCacheEnabled(runText))
                            {
                                FlushBatches(canvas);
                                canvas.DrawText(runText, rx, baselineYDip, font, fgPaint);
                                IncrementTextDrawCall();
                                IncrementDirectDrawTextCall();
                                cellsRendered += totalRunWidth;
                                c = k;
                                continue;
                            }

                            int cellX = c;
                            float yBaselineSnap = baselineYDip;
                            // #172 item 2: the sprite's position now comes from the atlas entry's own ink
                            // bearing rather than from the font's ascent, so there is no single per-run
                            // glyph Y any more. Snapping to the device-pixel grid still happens, just per
                            // glyph and against the baseline.
                            int baselineDevicePx = ToDevicePx(yBaselineSnap);
                            float invScale = (float)(1.0 / _renderScaling);
                            _blockFillPaint.Color = fg;
                            _blockFillPaint.Style = SKPaintStyle.Fill;
                            _blockFillPaint.IsAntialias = false;

                            // One iteration per grapheme cluster, not per rune (#234). Everything in this
                            // body already takes a cluster string and behaves correctly given one; the
                            // enumerator is what was wrong.
                            foreach (string grapheme in new RunGraphemeEnumerator(runCellTexts))
                            {
                                int graphemeWidth = GetSafeGraphemeWidth(grapheme);
                                float xIdxSnap = FromDevicePx(_pixelGrid.XForCol(cellX));

                                int fallbackChar = FindFirstMissingGlyphCodePoint(grapheme, primaryTf);
                                SKFont glyphFont = font;
                                if (fallbackChar != 0)
                                {
                                    var glyphTf = ResolveTypefaceForCodePoint(fallbackChar, primaryTf);
                                    if (glyphTf != primaryTf)
                                    {
                                        glyphFont = GetOrCreateFallbackFont(glyphTf);
                                    }
                                }

                                glyphFont.Embolden = runIsBold;

                                if (GlyphDiagnosticsEnabled && IsSingleRuneInRange(grapheme, 0x2500, 0x257F))
                                {
                                    float measuredGlyphWidth = glyphFont.MeasureText(grapheme);
                                    float expectedGlyphWidth = graphemeWidth * _metrics.CellWidth;
                                    string glyphFamily = glyphFont.Typeface?.FamilyName ?? "unknown";
                                    string diagKey = $"boxglyph:{glyphFamily}:{grapheme}";
                                    string diagMsg = $"[GlyphDiag] box-glyph='{grapheme}' font='{glyphFamily}' measuredDip={measuredGlyphWidth:F4} expectedDip={expectedGlyphWidth:F4} delta={measuredGlyphWidth - expectedGlyphWidth:F4}";
                                    LogDiagOnce(diagKey, diagMsg);
                                }

                                float cellX1 = xIdxSnap;
                                float cellX2 = FromDevicePx(_pixelGrid.XForCol(cellX + graphemeWidth));
                                float cellW = cellX2 - cellX1;
                                float cellH = snappedCellHeight;
                                bool hasSingleRune = TryGetSingleRuneCodePoint(grapheme, out int graphemeCodePoint);
                                bool isBlockShadeOrQuadrant = hasSingleRune && graphemeCodePoint >= 0x2580 && graphemeCodePoint <= 0x259F;
                                bool isBrailleGlyph = hasSingleRune && graphemeCodePoint >= 0x2800 && graphemeCodePoint <= 0x28FF;
                                bool isBlackSquareGlyph = hasSingleRune && graphemeCodePoint == 0x25A0;
                                bool graphGlyphMissing = false;
                                if ((isBlockShadeOrQuadrant || isBrailleGlyph || isBlackSquareGlyph) &&
                                    (glyphFont.Typeface == null || !glyphFont.Typeface.ContainsGlyph(graphemeCodePoint)))
                                {
                                    graphGlyphMissing = true;
                                }
                                bool usePrimitiveBlockLike = IsBlockElementPrimitiveRenderingEnabled() || isBlockShadeOrQuadrant || isBlackSquareGlyph || graphGlyphMissing;
                                bool usePrimitiveBraille = IsBlockElementPrimitiveRenderingEnabled() || graphGlyphMissing;

                                // Prefer primitives for block/shade/quadrant bar glyphs to guarantee
                                // seam-free cell fills. For braille, keep font rendering unless
                                // primitives are enabled or the current typeface lacks the glyph.
                                if (usePrimitiveBlockLike &&
                                    TryGetBlockFillRect(grapheme, out int xStartEighths, out int xEndEighths, out int yStartEighths, out int yEndEighths))
                                {
                                    FlushBatches(canvas);

                                    float fillX1 = xStartEighths == 0 ? cellX1 : SnapX(cellX1 + (cellW * (xStartEighths / 8f)));
                                    float fillX2 = xEndEighths == 8 ? cellX2 : SnapX(cellX1 + (cellW * (xEndEighths / 8f)));
                                    float rowBottom = rowTopYDip + cellH;
                                    float fillY1 = yStartEighths == 0 ? rowTopYDip : SnapY(rowTopYDip + (cellH * (yStartEighths / 8f)));
                                    float fillY2 = yEndEighths == 8 ? rowBottom : SnapY(rowTopYDip + (cellH * (yEndEighths / 8f)));
                                    if (fillX2 > fillX1 && fillY2 > fillY1)
                                    {
                                        canvas.DrawRect(fillX1, fillY1, fillX2 - fillX1, fillY2 - fillY1, _blockFillPaint);
                                        IncrementRectDrawCall();
                                    }

                                    cellX += graphemeWidth;
                                    continue;
                                }

                                if (usePrimitiveBlockLike && TryGetShadeFillAlpha(grapheme, out float shadeAlpha))
                                {
                                    FlushBatches(canvas);
                                    byte shadeA = (byte)Math.Clamp((int)Math.Round(fg.Alpha * shadeAlpha), 0, 255);
                                    _shadeFillPaint.Color = new SKColor(fg.Red, fg.Green, fg.Blue, shadeA);
                                    _shadeFillPaint.Style = SKPaintStyle.Fill;
                                    _shadeFillPaint.IsAntialias = false;
                                    if (cellW > 0 && cellH > 0)
                                    {
                                        canvas.DrawRect(cellX1, rowTopYDip, cellW, cellH, _shadeFillPaint);
                                        IncrementRectDrawCall();
                                    }

                                    cellX += graphemeWidth;
                                    continue;
                                }

                                if (usePrimitiveBlockLike && TryGetQuadrantFillMask(grapheme, out byte quadrantMask))
                                {
                                    FlushBatches(canvas);
                                    DrawQuadrantSubcells(canvas, quadrantMask, cellX1, rowTopYDip, cellW, cellH, _blockFillPaint);
                                    cellX += graphemeWidth;
                                    continue;
                                }

                                if (usePrimitiveBraille && TryGetBraillePattern(grapheme, out byte brailleMask))
                                {
                                    FlushBatches(canvas);
                                    DrawBrailleSubcells(canvas, brailleMask, cellX1, rowTopYDip, cellW, cellH, _blockFillPaint);
                                    cellX += graphemeWidth;
                                    continue;
                                }

                                // Only flush the text batch for code points the primitive path can
                                // actually draw. The 0x2500-0x257F block is much wider than our
                                // segment table (dashed variants, mixed-weight joins, diagonals), and
                                // flushing for those cost a batch break and then fell through to the
                                // font anyway.
                                if (IsBoxDrawingPrimitiveRenderingEnabled() &&
                                    TryGetSingleRuneCodePoint(grapheme, out int cpBox) &&
                                    IsHandledBoxDrawingCodepoint(cpBox))
                                {
                                    FlushBatches(canvas);
                                    if (TryDrawBoxDrawingGlyph(canvas, grapheme, cellX1, rowTopYDip, cellW, cellH, fg))
                                    {
                                        cellX += graphemeWidth;
                                        continue;
                                    }
                                }

                                if (ShouldForceDirectTextForGraphGlyph(grapheme))
                                {
                                    FlushBatches(canvas);
                                    DrawDirectGrapheme(
                                        canvas,
                                        grapheme,
                                        xIdxSnap,
                                        yBaselineSnap,
                                        glyphFont,
                                        fgPaint,
                                        cellX1,
                                        rowTopYDip,
                                        cellW,
                                        cellH);
                                    cellX += graphemeWidth;
                                    continue;
                                }

                                if (ShouldBypassGlyphAtlasForGrapheme(grapheme))
                                {
                                    FlushBatches(canvas);
                                    DrawDirectGrapheme(
                                        canvas,
                                        grapheme,
                                        xIdxSnap,
                                        yBaselineSnap,
                                        glyphFont,
                                        fgPaint,
                                        cellX1,
                                        rowTopYDip,
                                        cellW,
                                        cellH);
                                    cellX += graphemeWidth;
                                    continue;
                                }

                                // Atlas sprites are rasterized at the cell size; a scaled row draws its glyphs as text instead.
                                GlyphSprite? cached = _suppressGlyphAtlas ? null : _glyphCache.GetOrAdd(grapheme, glyphFont, (float)_renderScaling, fg);

                                if (cached != null)
                                {
                                    var sprite = cached.Value;

                                    // Offsets are integer device pixels from the pen origin, and both
                                    // xIdxSnap and the baseline are already on the device-pixel grid, so
                                    // the sprite stays pixel-aligned and therefore sharp.
                                    float spriteX = FromDevicePx(ToDevicePx(xIdxSnap) + sprite.OffsetX);
                                    float spriteY = FromDevicePx(baselineDevicePx + sprite.OffsetY);
                                    var xform = SKRotationScaleMatrix.Create(invScale, 0, spriteX, spriteY, 0, 0);
                                    if (sprite.Type == AtlasType.Alpha8)
                                    {
                                        AddAlphaBatchEntry(sprite.Rect, xform, fg);
                                    }
                                    else
                                    {
                                        AddColorBatchEntry(sprite.Rect, xform);
                                    }
                                }
                                else
                                {
                                    FlushBatches(canvas);
                                    canvas.DrawText(grapheme, xIdxSnap, yBaselineSnap, glyphFont, fgPaint);
                                    IncrementTextDrawCall();
                                    IncrementDirectDrawTextCall();
                                }
                                cellX += graphemeWidth;
                            }
                            LogBoxRunDiagnostics(runText, totalRunWidth, font, font.MeasureText(runText));
                        }
                        else
                        {
                            canvas.DrawText(runText, rx, baselineYDip, font, fgPaint);
                            IncrementTextDrawCall();
                            IncrementDirectDrawTextCall();
                        }
                        cellsRendered += totalRunWidth;
                    }

                    if (hasLigatureClip)
                    {
                        FlushBatches(canvas);
                        canvas.Restore();
                    }

                    if (appliedItalicTransform)
                    {
                        canvas.Restore();
                    }

                    // A plain underline stays trimmed to the visible text, as it has been since e25e6bd (a guard that
                    // came with a CSI-leader misparse fix). A styled or colored one (#270) is only ever there because
                    // an application asked for it with SGR 4:x, 21 or 58 - an editor's squiggle on trailing whitespace,
                    // say - so it is drawn across the whole run, blanks included, as other terminals draw it.
                    bool styledUnderline = runUnderline is { HasColor: true } || runUnderline?.Style is > UnderlineStyle.Single;
                    bool underlineHasVisibleText = runIsUnderline && (styledUnderline || ContainsNonWhitespace(runText));
                    if (underlineHasVisibleText || runIsStrikethrough || runUnderline?.Overline == true)
                    {
                        _decoStrokePaint.Color = fg;
                        _decoStrokePaint.IsAntialias = true;
                        _decoStrokePaint.Style = SKPaintStyle.Stroke;
                        _decoStrokePaint.StrokeWidth = strokeWidth;

                        if (underlineHasVisibleText)
                        {
                            float underlineX1 = rx;
                            float underlineX2 = rx + rw;
                            if (!styledUnderline && TryGetUnderlineBounds(runCellTexts, c, colEdges, paddingLeft, out float trimmedX1, out float trimmedX2))
                            {
                                underlineX1 = trimmedX1;
                                underlineX2 = trimmedX2;
                            }

                            float underlineY = FromDevicePx(_pixelGrid.YForUnderline(rowIndex));
                            float rowBottomY = FromDevicePx(_pixelGrid.YForRowTop(rowIndex) + _pixelGrid.CellHeightPx);
                            if (runUnderline is { HasColor: true })
                            {
                                _decoStrokePaint.Color = ResolveUnderlineColor(runUnderline, themeSnapshot);
                            }

                            DrawUnderline(canvas, runUnderline?.Style ?? UnderlineStyle.Single, underlineX1, underlineX2, underlineY, rowBottomY, strokeWidth);
                            IncrementRectDrawCall();
                        }

                        if (runUnderline?.Overline == true)
                        {
                            _decoStrokePaint.Color = fg;
                            float overlineY = rowTopYDip + (strokeWidth / 2);
                            canvas.DrawLine(rx, overlineY, rx + rw, overlineY, _decoStrokePaint);
                            IncrementRectDrawCall();
                        }

                        if (runIsStrikethrough)
                        {
                            _decoStrokePaint.Color = fg; // the underline may have taken its own color
                            float strikeY = FromDevicePx(_pixelGrid.YForStrike(rowIndex));
                            canvas.DrawLine(rx, strikeY, rx + rw, strikeY, _decoStrokePaint);
                            IncrementRectDrawCall();
                        }
                    }

                    c = k;
                }

                FlushBatches(canvas);
                return cellsRendered;
            }
            finally
            {
                if (hasSpanClip)
                {
                    canvas.Restore();
                }

                _suppressGlyphAtlas = glyphAtlasWasSuppressed;
                if (lineSizeScaled) canvas.Restore();
            }
        }

        private static bool ShouldUseSpanRenderingForRow(List<DirtySpan> rowSpans, int rowCols)
        {
            if (rowSpans.Count == 0 || rowCols <= 0)
            {
                return false;
            }

            if (rowSpans.Count > SpanRenderMaxSpansPerRow)
            {
                return false;
            }

            int covered = 0;
            for (int i = 0; i < rowSpans.Count; i++)
            {
                covered += Math.Max(0, rowSpans[i].ColEnd - rowSpans[i].ColStart);
            }

            return covered < (int)Math.Ceiling(rowCols * SpanRenderCoverageFallbackThreshold);
        }

        private static bool IsEnvFlagEnabled(string name)
        {
            string? raw = Environment.GetEnvironmentVariable(name);
            return raw == "1" || string.Equals(raw, "true", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Reads a flag that is on unless explicitly disabled. Unset keeps <paramref name="defaultValue"/>;
        /// "0"/"false" turns it off, "1"/"true" turns it on. Unrecognised values keep the default.
        /// </summary>
        private static bool IsEnvFlagEnabled(string name, bool defaultValue)
        {
            string? raw = Environment.GetEnvironmentVariable(name);
            if (string.IsNullOrWhiteSpace(raw)) return defaultValue;
            if (raw == "1" || string.Equals(raw, "true", StringComparison.OrdinalIgnoreCase)) return true;
            if (raw == "0" || string.Equals(raw, "false", StringComparison.OrdinalIgnoreCase)) return false;
            return defaultValue;
        }

        private static bool IsBoxDrawingPrimitiveRenderingEnabled()
        {
            TestPrimitiveRenderOverride? overrideFlags = PrimitiveRenderOverrideForTests.Value;
            return overrideFlags?.UseBoxDrawingPrimitives ?? UseBoxDrawingPrimitives;
        }

        private static bool IsBlockElementPrimitiveRenderingEnabled()
        {
            TestPrimitiveRenderOverride? overrideFlags = PrimitiveRenderOverrideForTests.Value;
            return overrideFlags?.UseBlockElementPrimitives ?? UseBlockElementPrimitives;
        }

        /// <summary>Ambient default, so a test override can pin one primitive path without disturbing the other.</summary>
        internal static bool DefaultBoxDrawingPrimitivesEnabledForTests => UseBoxDrawingPrimitives;

        /// <inheritdoc cref="DefaultBoxDrawingPrimitivesEnabledForTests"/>
        internal static bool DefaultBlockElementPrimitivesEnabledForTests => UseBlockElementPrimitives;

        internal static IDisposable PushPrimitiveRenderingOverrideForTests(bool useBoxDrawingPrimitives, bool useBlockElementPrimitives)
        {
            TestPrimitiveRenderOverride? previous = PrimitiveRenderOverrideForTests.Value;
            PrimitiveRenderOverrideForTests.Value = new TestPrimitiveRenderOverride
            {
                UseBoxDrawingPrimitives = useBoxDrawingPrimitives,
                UseBlockElementPrimitives = useBlockElementPrimitives
            };

            return new PrimitiveRenderOverrideScope(previous);
        }

        internal static void ResetRenderPerfWriterForTests()
        {
            if (SharedRenderPerfWriter.IsValueCreated)
            {
                try
                {
                    SharedRenderPerfWriter.Value?.Dispose();
                }
                catch
                {
                    // Keep test helper non-fatal.
                }
            }

            SharedRenderPerfWriter = new Lazy<RenderPerfWriter?>(RenderPerfWriter.CreateFromEnvironment);
        }

        private RenderPerfWriter? BeginFramePerfMetrics()
        {
            RenderPerfWriter? writer = SharedRenderPerfWriter.Value;
            if (writer == null)
            {
                _collectFramePerfMetrics = false;
                _framePerfMetrics = default;
                _frameOtherDrawCalls = 0;
                _frameAllocStartBytes = 0;
                return null;
            }

            _collectFramePerfMetrics = true;
            _framePerfMetrics = default;
            _frameOtherDrawCalls = 0;
            _framePerfMetrics.FrameIndex = writer.NextFrameIndex();
            _frameAllocStartBytes = GC.GetAllocatedBytesForCurrentThread();
            return writer;
        }

        private void CompleteFramePerfMetrics(RenderPerfWriter? writer, double frameTimeMs, int dirtyRows, int dirtySpans)
        {
            if (!_collectFramePerfMetrics || writer == null)
            {
                return;
            }

            _framePerfMetrics.FrameTimeMs = frameTimeMs;
            _framePerfMetrics.DirtyRows = dirtyRows;
            _framePerfMetrics.DirtySpansTotal = dirtySpans;

            long allocDelta = GC.GetAllocatedBytesForCurrentThread() - _frameAllocStartBytes;
            _framePerfMetrics.AllocBytesThisFrame = allocDelta > 0 ? allocDelta : 0;
            _framePerfMetrics.DrawCallsTotal = _framePerfMetrics.DrawCallsText + _framePerfMetrics.DrawCallsRects + _frameOtherDrawCalls;
            writer.TryWrite(_framePerfMetrics);
        }

        private void IncrementRowPictureCacheHit()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _framePerfMetrics.RowPictureCacheHits++;
            }
        }

        private void IncrementRowPictureCacheMiss()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _framePerfMetrics.RowPictureCacheMisses++;
            }
        }

        private void IncrementPictureBuild()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _framePerfMetrics.PictureBuilds++;
            }
        }

        private void IncrementRectDrawCall()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _framePerfMetrics.DrawCallsRects++;
            }
        }

        private void IncrementTextDrawCall()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _framePerfMetrics.DrawCallsText++;
            }
        }

        private void IncrementDirectDrawTextCall()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _framePerfMetrics.DirectDrawTextCount++;
            }
        }

        private void IncrementShapedTextRun()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _framePerfMetrics.ShapedTextRuns++;
            }
        }

        private void IncrementOtherDrawCall()
        {
            if (_collectFramePerfMetrics || _showRenderHud)
            {
                _frameOtherDrawCalls++;
            }
        }

        private void RecordFlush(int alphaGlyphs, int colorGlyphs, int atlasDrawCalls)
        {
            if (!_collectFramePerfMetrics && !_showRenderHud)
            {
                return;
            }

            _framePerfMetrics.FlushCount++;
            _framePerfMetrics.AtlasAlphaGlyphs += alphaGlyphs;
            _framePerfMetrics.AtlasColorGlyphs += colorGlyphs;
            _frameOtherDrawCalls += atlasDrawCalls;
        }

        private int ToDevicePx(double logical)
            => (int)Math.Round(logical * _renderScaling, MidpointRounding.AwayFromZero);

        private float FromDevicePx(int px)
            => (float)(px / _renderScaling);

        /// <inheritdoc cref="FromDevicePx(int)"/>
        /// <remarks>For geometry that lands between pixels, such as the centreline of an odd-width stroke.</remarks>
        private float FromDevicePxF(double px)
            => (float)(px / _renderScaling);

        private float Snap(double logical)
            => (float)(Math.Round(logical * _renderScaling, MidpointRounding.AwayFromZero) / _renderScaling);

        private float SnapX(double logicalX) => Snap(logicalX);

        private float SnapY(double logicalY) => Snap(logicalY);

        private float[] EnsureCellEdgeGrid(ref float[]? buffer, ref int usedCount, int cellCount, int originPx, int deviceCellSize)
        {
            int count = Math.Max(0, cellCount);
            int required = count + 1;
            if (buffer == null || buffer.Length < required)
            {
                var rented = ArrayPool<float>.Shared.Rent(required);
                if (buffer != null)
                {
                    ArrayPool<float>.Shared.Return(buffer, clearArray: false);
                }

                buffer = rented;
            }

            usedCount = required;
            for (int i = 0; i <= count; i++)
            {
                buffer[i] = FromDevicePx(originPx + (i * deviceCellSize));
            }
            return buffer;
        }

        /// <summary>The paint for a placeholder run's own background: its RGB colour or palette entry, or null for the theme background.</summary>
        private static SKPaint? PlaceholderBackgroundPaint(in RenderImageSnapshot run, RenderThemeSnapshot theme)
        {
            SKColor fill;
            if (run.TileBackgroundIndex is { } index)
            {
                TermColor entry = ResolvePaletteIndex(index, theme);
                fill = new SKColor(entry.R, entry.G, entry.B, 255);
            }
            else if (run.TileBackground is { } rgb) fill = new SKColor(rgb.R, rgb.G, rgb.B, rgb.A);
            else return null;
            return new SKPaint { Color = fill, Style = SKPaintStyle.Fill, IsAntialias = false };
        }

        /// <summary>
        /// The whole grid of a Unicode placeholder run's virtual placement, which may reach past the run, past the visible rows and past the
        /// first column: the run only paints its own cells, but the bitmap is fitted into the grid they are part of.
        /// </summary>
        private SKRect PlaceholderGrid(in RenderImageSnapshot run, int visualY, float[] colEdges, float[] rowEdges, float paddingLeft, float paddingTop)
        {
            int firstColumn = run.CellX - run.GridColumn;
            int firstRow = visualY - run.GridRow;
            return new SKRect(
                GetColEdge(colEdges, firstColumn, paddingLeft),
                GetRowEdge(rowEdges, firstRow, paddingTop),
                GetColEdge(colEdges, firstColumn + run.GridColumns, paddingLeft),
                GetRowEdge(rowEdges, firstRow + run.GridRows, paddingTop));
        }

        private float GetColEdge(float[] colEdges, int colIndex, float paddingLeft)
        {
            // Bounds-check the USED count, not the pooled array's Length: EnsureCellEdgeGrid
            // rents from ArrayPool, so Length is capacity and slots past _colEdgesCount hold
            // stale values. An image wider than the grid (colEdges[122] on an 86-col pane)
            // read one of those zeros as an edge, flipped the rect width negative, and the
            // frame silently painted nothing. Beyond the valid edges the geometry is linear,
            // so fall through to the pixel grid.
            if ((uint)colIndex < (uint)_colEdgesCount) return colEdges[colIndex];
            return FromDevicePx(_pixelGrid.XForCol(colIndex));
        }

        private float GetRowEdge(float[] rowEdges, int rowIndex, float paddingTop)
        {
            if ((uint)rowIndex < (uint)_rowEdgesCount) return rowEdges[rowIndex];
            return FromDevicePx(_pixelGrid.YForRowTop(rowIndex));
        }

        private void DrawDebugCellGrid(SKCanvas canvas, float[] colEdges, int colEdgeCount, float[] rowEdges, int rowEdgeCount)
        {
            using var gridPaint = new SKPaint
            {
                Color = new SKColor(0, 200, 255, 72),
                Style = SKPaintStyle.Stroke,
                IsAntialias = false,
                StrokeWidth = Math.Max(1f, FromDevicePx(1))
            };

            float y1 = rowEdgeCount > 0 ? rowEdges[0] : 0f;
            float y2 = rowEdgeCount > 0 ? rowEdges[rowEdgeCount - 1] : (float)Bounds.Height;
            for (int i = 0; i < colEdgeCount; i++)
            {
                float x = colEdges[i];
                canvas.DrawLine(x, y1, x, y2, gridPaint);
            }
        }

        private void ReturnEdgeBuffers()
        {
            if (_colEdges != null)
            {
                ArrayPool<float>.Shared.Return(_colEdges);
                _colEdges = null;
                _colEdgesCount = 0;
            }

            if (_rowEdges != null)
            {
                ArrayPool<float>.Shared.Return(_rowEdges);
                _rowEdges = null;
                _rowEdgesCount = 0;
            }
        }

        private static void LogDiagOnce(string key, string message)
        {
            if (!GlyphDiagnosticsEnabled) return;
            if (GlyphDiagOnce.TryAdd(key, 0))
            {
                TerminalLogger.Log(message);
            }
        }

        private void LogPrimaryFontDiagnostics(SKTypeface primaryTf)
        {
            if (!GlyphDiagnosticsEnabled) return;
            string key = $"fontcfg:{_typeface.FontFamily.Name}:{primaryTf.FamilyName}:{_fontSize}:{_renderScaling}";
            string message = $"[GlyphDiag] configured='{_typeface.FontFamily.Name}' primary='{primaryTf.FamilyName}' size={_fontSize:F2} scaling={_renderScaling:F3} cellDip={_metrics.CellWidth:F4}x{_metrics.CellHeight:F4} cellPx={_cellWidthDevicePx}x{_cellHeightDevicePx}";
            LogDiagOnce(key, message);
        }

        private static bool ContainsBoxDrawing(string text)
        {
            foreach (var rune in text.EnumerateRunes())
            {
                int cp = rune.Value;
                if (cp >= 0x2500 && cp <= 0x257F) return true;
            }
            return false;
        }

        private static bool ContainsRunesRequiringComplexShaping(string text)
        {
            foreach (var rune in text.EnumerateRunes())
            {
                int cp = rune.Value;
                if ((cp >= 0x0590 && cp <= 0x0FFF) || // Complex scripts
                    (cp >= 0x1F300 && cp <= 0x1FAFF) || // Emoji
                    IsRegionalIndicatorRune(cp) ||       // Flag emoji sequences
                    (cp >= 0x2600 && cp <= 0x27BF) ||   // Dingbats/symbols
                    (cp == 0x200D) ||                    // ZWJ
                                                         // Keycap sequences ("1" + FE0F + 20E3) and any other VS16-promoted emoji.
                                                         // Without these the run falls through to the per-rune loop below, which calls
                                                         // the glyph cache once per *rune* rather than per grapheme cluster - so the
                                                         // digit, the selector and the enclosing keycap are rasterized separately and
                                                         // the composed glyph is never produced at all. Flags already reach the shaper
                                                         // via IsRegionalIndicatorRune for exactly this reason (#172).
                    (cp == 0xFE0F) ||                    // VARIATION SELECTOR-16
                    (cp == 0x20E3))                      // COMBINING ENCLOSING KEYCAP
                {
                    return true;
                }
            }
            return false;
        }

        private void DrawDirectGrapheme(
            SKCanvas canvas,
            string grapheme,
            float x,
            float baselineY,
            SKFont glyphFont,
            SKPaint paint,
            float cellX,
            float cellY,
            float cellW,
            float cellH)
        {
            if (!IsSingleRuneInRange(grapheme, 0x2500, 0x257F) || cellW <= 0 || cellH <= 0)
            {
                canvas.DrawText(grapheme, x, baselineY, glyphFont, paint);
                IncrementTextDrawCall();
                IncrementDirectDrawTextCall();
                return;
            }

            // Clip box-drawing glyphs to their exact cell to avoid tiny vertical overlap
            // artifacts when stacked row-by-row with font rendering.
            canvas.Save();
            canvas.ClipRect(SKRect.Create(cellX, cellY, cellW, cellH));

            using var crispFont = new SKFont(glyphFont.Typeface ?? SKTypeface.Default, glyphFont.Size)
            {
                Edging = SKFontEdging.Alias,
                Hinting = SKFontHinting.Full,
                Embolden = glyphFont.Embolden
            };
            canvas.DrawText(grapheme, x, baselineY, crispFont, paint);
            IncrementTextDrawCall();
            IncrementDirectDrawTextCall();
            canvas.Restore();
        }

        private static bool IsBoxDrawingCodePoint(int cp)
            => cp >= 0x2500 && cp <= 0x257F;

        private static bool IsRegionalIndicatorRune(int codePoint)
            => codePoint >= 0x1F1E6 && codePoint <= 0x1F1FF;

        private static bool IsAmbiguousSymbolCodePoint(int codePoint)
            => codePoint >= 0x2600 && codePoint <= 0x27BF;

        private static bool IsEmojiTypefaceFamily(SKTypeface? typeface)
        {
            string family = typeface?.FamilyName ?? string.Empty;
            return family.Contains("Emoji", StringComparison.OrdinalIgnoreCase);
        }

        private void LogBoxRunDiagnostics(string runText, int runCells, SKFont runFont, float measuredWidth)
        {
            if (!GlyphDiagnosticsEnabled || !ContainsBoxDrawing(runText)) return;

            float expectedWidth = runCells * _metrics.CellWidth;
            string sample = runText.Length <= 24 ? runText : runText.Substring(0, 24);
            string key = $"boxrun:{runFont.Typeface?.FamilyName}:{sample}:{runCells}";
            string msg = $"[GlyphDiag] box-run font='{runFont.Typeface?.FamilyName}' cells={runCells} measuredDip={measuredWidth:F4} expectedDip={expectedWidth:F4} delta={measuredWidth - expectedWidth:F4} sample='{sample}'";
            LogDiagOnce(key, msg);
        }

        private static int FindFirstMissingGlyphCodePoint(string text, SKTypeface primaryTf)
        {
            foreach (var rune in text.EnumerateRunes())
            {
                int cp = rune.Value;
                if (cp > 127 && (IsRegionalIndicatorRune(cp) || !primaryTf.ContainsGlyph(cp)))
                {
                    return cp;
                }
            }

            return 0;
        }

        private static int GetSafeGraphemeWidth(string textElement)
        {
            if (string.IsNullOrEmpty(textElement)) return 0;
            try
            {
                return UnicodeWidth.GetGraphemeWidth(textElement);
            }
            catch (ArgumentOutOfRangeException)
            {
                return 1;
            }
            catch (ArgumentException)
            {
                return 1;
            }
        }

        private static int GetRuneWidth(Rune rune)
        {
            return UnicodeWidth.GetRuneWidth(rune);
        }

        private static bool IsCombiningRune(Rune rune)
        {
            return UnicodeWidth.IsZeroWidthGraphemeComponent(rune);
        }

        private static string NormalizeTextElementForRender(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return " ";
            }

            bool hasInvalidSurrogate = false;
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                if (char.IsHighSurrogate(ch))
                {
                    if (i + 1 >= text.Length || !char.IsLowSurrogate(text[i + 1]))
                    {
                        hasInvalidSurrogate = true;
                        break;
                    }
                    i++;
                    continue;
                }

                if (char.IsLowSurrogate(ch))
                {
                    hasInvalidSurrogate = true;
                    break;
                }
            }

            if (!hasInvalidSurrogate)
            {
                return text;
            }

            var sb = new StringBuilder(text.Length);
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                if (char.IsHighSurrogate(ch))
                {
                    if (i + 1 < text.Length && char.IsLowSurrogate(text[i + 1]))
                    {
                        sb.Append(ch);
                        sb.Append(text[i + 1]);
                        i++;
                    }
                    else
                    {
                        sb.Append('\uFFFD');
                    }
                    continue;
                }

                if (char.IsLowSurrogate(ch))
                {
                    sb.Append('\uFFFD');
                }
                else
                {
                    sb.Append(ch);
                }
            }

            return sb.ToString();
        }

        private SKTypeface ResolveTypefaceForCodePoint(int codePoint, SKTypeface primaryTf)
        {
            if (codePoint <= 127)
            {
                return primaryTf;
            }

            if (IsBoxDrawingCodePoint(codePoint))
            {
                if (!ForceKnownGoodBoxFont && primaryTf.ContainsGlyph(codePoint))
                {
                    return primaryTf;
                }

                string boxLookupKey = $"box:{codePoint}";
                if (_fallbackCache.TryGetValue(boxLookupKey, out var cachedBoxTypeface))
                {
                    return cachedBoxTypeface ?? primaryTf;
                }

                var knownGood = ResolveKnownGoodBoxTypeface(codePoint);
                if (knownGood != null)
                {
                    if (knownGood != primaryTf)
                    {
                        LogDiagOnce(
                            $"box-font-mismatch:{primaryTf.FamilyName}:{knownGood.FamilyName}",
                            $"[GlyphDiag][Warn] box-drawing fallback primary='{primaryTf.FamilyName}' resolved='{knownGood.FamilyName}' codePoint=U+{codePoint:X4}");
                    }
                    _fallbackCache.TryAdd(boxLookupKey, knownGood);
                    return knownGood;
                }

                _fallbackCache.TryAdd(boxLookupKey, primaryTf);
                return primaryTf;
            }

            if (primaryTf.ContainsGlyph(codePoint))
            {
                return primaryTf;
            }

            string lookupKey = codePoint.ToString(CultureInfo.InvariantCulture);
            if (!_fallbackCache.TryGetValue(lookupKey, out var tfToUse))
            {
                SKTypeface? found = null;
                if ((codePoint >= 0x1F300 && codePoint <= 0x1FAFF) ||
                    IsRegionalIndicatorRune(codePoint))
                {
                    found = SKTypeface.FromFamilyName("Segoe UI Emoji");
                }

                if (found == null && IsAmbiguousSymbolCodePoint(codePoint))
                {
                    foreach (var tfChain in _fallbackChain)
                    {
                        if (!IsEmojiTypefaceFamily(tfChain) && tfChain.ContainsGlyph(codePoint))
                        {
                            found = tfChain;
                            break;
                        }
                    }
                }

                if (found == null)
                {
                    foreach (var tfChain in _fallbackChain)
                    {
                        if (tfChain.ContainsGlyph(codePoint))
                        {
                            found = tfChain;
                            break;
                        }
                    }
                }
                found ??= SKFontManager.Default.MatchCharacter(codePoint);
                _fallbackCache.TryAdd(lookupKey, found);
                tfToUse = found;
            }

            return tfToUse ?? primaryTf;
        }

        private static SKTypeface? ResolveKnownGoodBoxTypeface(int codePoint)
        {
            foreach (string family in KnownGoodBoxFonts)
            {
                using var candidate = SKTypeface.FromFamilyName(family);
                if (candidate != null && candidate.ContainsGlyph(codePoint))
                {
                    return SKTypeface.FromFamilyName(family);
                }
            }
            return null;
        }

        private static bool TryGetBlockFillRect(
            string grapheme,
            out int xStartEighths,
            out int xEndEighths,
            out int yStartEighths,
            out int yEndEighths)
        {
            xStartEighths = 0;
            xEndEighths = 0;
            yStartEighths = 0;
            yEndEighths = 0;

            var enumerator = grapheme.EnumerateRunes().GetEnumerator();
            if (!enumerator.MoveNext()) return false;
            int cp = enumerator.Current.Value;
            if (enumerator.MoveNext()) return false; // Multi-rune grapheme: not a simple block element.

            // Full block.
            if (cp == 0x2588)
            {
                xStartEighths = 0; xEndEighths = 8;
                yStartEighths = 0; yEndEighths = 8;
                return true;
            }

            // Black square (U+25A0) is used by btop meter bars.
            // Keep full width to avoid seams, but use a centered 4/8 height
            // so visual weight is closer to common terminal glyph rendering.
            if (cp == 0x25A0)
            {
                xStartEighths = 0; xEndEighths = 8;
                yStartEighths = 2; yEndEighths = 6;
                return true;
            }

            // Left-filled block elements (U+2589..U+258F).
            if (cp >= 0x2589 && cp <= 0x258F)
            {
                xStartEighths = 0;
                xEndEighths = 8 - (cp - 0x2588);
                yStartEighths = 0;
                yEndEighths = 8;
                return true;
            }

            // Right half block (U+2590).
            if (cp == 0x2590)
            {
                xStartEighths = 4; xEndEighths = 8;
                yStartEighths = 0; yEndEighths = 8;
                return true;
            }

            // Upper half block (U+2580).
            if (cp == 0x2580)
            {
                xStartEighths = 0; xEndEighths = 8;
                yStartEighths = 0; yEndEighths = 4;
                return true;
            }

            // Lower n/8 block elements (U+2581..U+2587).
            if (cp >= 0x2581 && cp <= 0x2587)
            {
                int n = cp - 0x2580; // 1..7
                xStartEighths = 0; xEndEighths = 8;
                yStartEighths = 8 - n; yEndEighths = 8;
                return true;
            }

            // Upper one eighth block (U+2594).
            if (cp == 0x2594)
            {
                xStartEighths = 0; xEndEighths = 8;
                yStartEighths = 0; yEndEighths = 1;
                return true;
            }

            // Right one eighth block (U+2595).
            if (cp == 0x2595)
            {
                xStartEighths = 7; xEndEighths = 8;
                yStartEighths = 0; yEndEighths = 8;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Walks the grapheme clusters of a run, cell by cell.
        /// </summary>
        /// <remarks>
        /// A struct with its own <c>GetEnumerator</c> so <c>foreach</c> binds to it directly: this runs
        /// once per run per frame, and an iterator method would allocate a state machine each time.
        ///
        /// Segmentation is restricted to a single cell's text on purpose. Cluster boundaries are not
        /// guaranteed to coincide with cell boundaries — a cell can hold a cluster ending in a ZWJ if a
        /// PTY read split mid-join — and segmenting the concatenated run would then fuse two cells into
        /// one glyph while the column arithmetic still advanced by two.
        ///
        /// Conversely, a cell's text is *usually* exactly one cluster but not always: the VT write
        /// path's ZWJ attachment can leave two clusters in one cell (a trailing ZWJ followed by a
        /// non-pictographic character does not join under GB11). So each cell is still segmented rather
        /// than assumed to be a single cluster — but the common single-cluster and single-char cases
        /// return the cell's own string, allocating nothing where the old code allocated per rune.
        /// </remarks>
        private struct RunGraphemeEnumerator
        {
            private readonly List<string> _cellTexts;
            private int _cellIndex;
            private int _offset;

            public RunGraphemeEnumerator(List<string> cellTexts)
            {
                _cellTexts = cellTexts;
                _cellIndex = 0;
                _offset = 0;
                Current = string.Empty;
            }

            public string Current { get; private set; }

            public RunGraphemeEnumerator GetEnumerator() => this;

            public bool MoveNext()
            {
                while (_cellIndex < _cellTexts.Count)
                {
                    string cell = _cellTexts[_cellIndex];
                    if (_offset >= cell.Length)
                    {
                        _cellIndex++;
                        _offset = 0;
                        continue;
                    }

                    int remaining = cell.Length - _offset;
                    int length = remaining == 1
                        ? 1 // A single char is a whole cluster; skip the segmentation tables.
                        : StringInfo.GetNextTextElementLength(cell, _offset);

                    Current = _offset == 0 && length == cell.Length
                        ? cell // The common case: the cell is one cluster, so reuse its string.
                        : cell.Substring(_offset, length);
                    _offset += length;
                    return true;
                }

                Current = string.Empty;
                return false;
            }
        }

        private static bool IsSingleRuneInRange(string grapheme, int minCodePointInclusive, int maxCodePointInclusive)
        {
            if (!TryGetSingleRuneCodePoint(grapheme, out int cp)) return false;
            return cp >= minCodePointInclusive && cp <= maxCodePointInclusive;
        }

        private static bool ShouldDrawRunDirectWhenGlyphCacheEnabled(string runText)
        {
            bool hasRune = false;
            foreach (var rune in runText.EnumerateRunes())
            {
                hasRune = true;
                // Keep this optimization for whitespace-only runs.
                // Graph/box/braille runs must flow through per-grapheme rendering so
                // primitive and fallback logic can prevent tofu and seam artifacts.
                if (!Rune.IsWhiteSpace(rune))
                {
                    return false;
                }
            }

            return hasRune;
        }

        private static bool ShouldBypassGlyphAtlasForGrapheme(string grapheme)
        {
            if (!TryGetSingleRuneCodePoint(grapheme, out int cp)) return false;

            if (cp >= 0x2500 && cp <= 0x257F) return true; // Box drawing
            if (cp >= 0x2580 && cp <= 0x259F) return true; // Block elements + shades + quadrants
            if (cp >= 0x2800 && cp <= 0x28FF) return true; // Braille patterns
            if (cp >= 0x25A0 && cp <= 0x25FF) return true; // Geometric block symbols

            return false;
        }

        private static bool ShouldForceDirectTextForGraphGlyph(string grapheme)
        {
            if (!TryGetSingleRuneCodePoint(grapheme, out int cp)) return false;

            if (cp >= 0x2500 && cp <= 0x257F) return true; // Box drawing
            if (cp >= 0x2580 && cp <= 0x259F) return true; // Block elements + shades + quadrants
            if (cp >= 0x2800 && cp <= 0x28FF) return true; // Braille patterns
            if (cp >= 0x25A0 && cp <= 0x25FF) return true; // Geometric symbols used by TUIs

            return false;
        }

        private static bool TryGetShadeFillAlpha(string grapheme, out float alphaMultiplier)
        {
            alphaMultiplier = 0f;
            if (!TryGetSingleRuneCodePoint(grapheme, out int cp)) return false;

            alphaMultiplier = cp switch
            {
                0x2591 => 0.28f, // light shade
                0x2592 => 0.50f, // medium shade
                0x2593 => 0.72f, // dark shade
                _ => 0f
            };

            return alphaMultiplier > 0f;
        }

        private static bool TryGetBraillePattern(string grapheme, out byte mask)
        {
            mask = 0;
            if (!TryGetSingleRuneCodePoint(grapheme, out int cp)) return false;
            if (cp < 0x2800 || cp > 0x28FF) return false;
            mask = (byte)(cp - 0x2800);
            return true;
        }

        private static bool TryGetQuadrantFillMask(string grapheme, out byte mask)
        {
            mask = 0;
            if (!TryGetSingleRuneCodePoint(grapheme, out int cp)) return false;

            // Bit layout: 1=UL, 2=UR, 4=LL, 8=LR.
            mask = cp switch
            {
                0x2596 => 0b0100, // lower left
                0x2597 => 0b1000, // lower right
                0x2598 => 0b0001, // upper left
                0x2599 => 0b1101, // upper left + lower left + lower right
                0x259A => 0b1001, // upper left + lower right
                0x259B => 0b0111, // upper left + upper right + lower left
                0x259C => 0b1011, // upper left + upper right + lower right
                0x259D => 0b0010, // upper right
                0x259E => 0b0110, // upper right + lower left
                0x259F => 0b1110, // upper right + lower left + lower right
                _ => 0
            };

            return mask != 0;
        }

        private void DrawQuadrantSubcells(SKCanvas canvas, byte mask, float x, float y, float w, float h, SKPaint paint)
        {
            if (mask == 0 || w <= 0 || h <= 0) return;

            float xMid = SnapX(x + (w * 0.5f));
            float yMid = SnapY(y + (h * 0.5f));
            float x2 = x + w;
            float y2 = y + h;

            if ((mask & 0b0001) != 0 && xMid > x && yMid > y) canvas.DrawRect(x, y, xMid - x, yMid - y, paint);       // UL
            if ((mask & 0b0010) != 0 && x2 > xMid && yMid > y) canvas.DrawRect(xMid, y, x2 - xMid, yMid - y, paint);   // UR
            if ((mask & 0b0100) != 0 && xMid > x && y2 > yMid) canvas.DrawRect(x, yMid, xMid - x, y2 - yMid, paint);   // LL
            if ((mask & 0b1000) != 0 && x2 > xMid && y2 > yMid) canvas.DrawRect(xMid, yMid, x2 - xMid, y2 - yMid, paint); // LR
        }

        private const int SegUp = 1 << 0;
        private const int SegDown = 1 << 1;
        private const int SegLeft = 1 << 2;
        private const int SegRight = 1 << 3;

        /// <summary>
        /// True when <paramref name="cp"/> is a box-drawing code point the primitive renderer has a
        /// segment definition for. Callers use this to avoid breaking the text batch for code points
        /// that would fall through to font rendering anyway.
        /// </summary>
        internal static bool IsHandledBoxDrawingCodepoint(int cp)
            => TryGetBoxDrawingSegments(cp, out _, out _, out _);

        private static bool TryGetBoxDrawingSegments(int cp, out int seg, out bool isDouble, out bool isRoundedArc)
        {
            seg = 0;
            isDouble = false;
            isRoundedArc = false;

            if (cp < 0x2500 || cp > 0x257F) return false;

            switch (cp)
            {
                // Light single-line set used by TUIs
                case 0x2500: seg = SegLeft | SegRight; break; // ─
                case 0x2502: seg = SegUp | SegDown; break; // │
                case 0x250C: seg = SegRight | SegDown; break; // ┌
                case 0x2510: seg = SegLeft | SegDown; break; // ┐
                case 0x2514: seg = SegRight | SegUp; break; // └
                case 0x2518: seg = SegLeft | SegUp; break; // ┘
                case 0x251C: seg = SegUp | SegDown | SegRight; break; // ├
                case 0x2524: seg = SegUp | SegDown | SegLeft; break; // ┤
                case 0x252C: seg = SegLeft | SegRight | SegDown; break; // ┬
                case 0x2534: seg = SegLeft | SegRight | SegUp; break; // ┴
                case 0x253C: seg = SegUp | SegDown | SegLeft | SegRight; break; // ┼

                // Heavy variants rendered as thicker strokes
                case 0x2501: seg = SegLeft | SegRight; break; // ━
                case 0x2503: seg = SegUp | SegDown; break; // ┃
                case 0x250F: seg = SegRight | SegDown; break; // ┏
                case 0x2513: seg = SegLeft | SegDown; break; // ┓
                case 0x2517: seg = SegRight | SegUp; break; // ┗
                case 0x251B: seg = SegLeft | SegUp; break; // ┛
                case 0x2523: seg = SegUp | SegDown | SegRight; break; // ┣
                case 0x252B: seg = SegUp | SegDown | SegLeft; break; // ┫
                case 0x2533: seg = SegLeft | SegRight | SegDown; break; // ┳
                case 0x253B: seg = SegLeft | SegRight | SegUp; break; // ┻
                case 0x254B: seg = SegUp | SegDown | SegLeft | SegRight; break; // ╋

                // Double-line common set
                case 0x2550: seg = SegLeft | SegRight; isDouble = true; break; // ═
                case 0x2551: seg = SegUp | SegDown; isDouble = true; break; // ║
                case 0x2554: seg = SegRight | SegDown; isDouble = true; break; // ╔
                case 0x2557: seg = SegLeft | SegDown; isDouble = true; break; // ╗
                case 0x255A: seg = SegRight | SegUp; isDouble = true; break; // ╚
                case 0x255D: seg = SegLeft | SegUp; isDouble = true; break; // ╝
                case 0x2560: seg = SegUp | SegDown | SegRight; isDouble = true; break; // ╠
                case 0x2563: seg = SegUp | SegDown | SegLeft; isDouble = true; break; // ╣
                case 0x2566: seg = SegLeft | SegRight | SegDown; isDouble = true; break; // ╦
                case 0x2569: seg = SegLeft | SegRight | SegUp; isDouble = true; break; // ╩
                case 0x256C: seg = SegUp | SegDown | SegLeft | SegRight; isDouble = true; break; // ╬

                // Light rounded corners used by TUIs (superfile/lazygit/etc)
                case 0x256D: seg = SegRight | SegDown; isRoundedArc = true; break; // ╭
                case 0x256E: seg = SegLeft | SegDown; isRoundedArc = true; break; // ╮
                case 0x256F: seg = SegLeft | SegUp; isRoundedArc = true; break; // ╯
                case 0x2570: seg = SegRight | SegUp; isRoundedArc = true; break; // ╰

                default:
                    return false;
            }

            return true;
        }

        private bool TryDrawBoxDrawingGlyph(SKCanvas canvas, string grapheme, float x, float y, float w, float h, SKColor color)
        {
            if (!TryGetSingleRuneCodePoint(grapheme, out int cp)) return false;
            if (!TryGetBoxDrawingSegments(cp, out int seg, out bool isDouble, out bool isRoundedArc)) return false;

            int x1px = ToDevicePx(x);
            int y1px = ToDevicePx(y);
            int x2px = ToDevicePx(x + w);
            int y2px = ToDevicePx(y + h);
            if (x2px <= x1px || y2px <= y1px) return false;

            int xMidPx = (x1px + x2px) / 2;
            int yMidPx = (y1px + y2px) / 2;

            int baseThick = Math.Max(1, Math.Min(_cellWidthDevicePx, _cellHeightDevicePx) / 10);
            // Heavy/light both get grid-aligned fill; heavy naturally appears bolder via 2px where possible.
            int thickPx = (cp == 0x2501 || cp == 0x2503 || cp == 0x250F || cp == 0x2513 || cp == 0x2517 || cp == 0x251B || cp == 0x2523 || cp == 0x252B || cp == 0x2533 || cp == 0x253B || cp == 0x254B)
                ? Math.Max(1, baseThick + 1)
                : baseThick;
            int gapPx = Math.Max(1, thickPx + 1);

            using var p = new SKPaint
            {
                Color = color,
                Style = SKPaintStyle.Fill,
                IsAntialias = false
            };

            static void DrawRectPx(SKCanvas c, SKPaint paint, int px1, int py1, int px2, int py2, Func<int, float> fromPx)
            {
                if (px2 <= px1 || py2 <= py1) return;
                c.DrawRect(fromPx(px1), fromPx(py1), fromPx(px2 - px1), fromPx(py2 - py1), paint);
            }

            void DrawHorizontal(int startPx, int endPx, int centerYPx, int strokePx)
            {
                int top = centerYPx - (strokePx / 2);
                int bottom = top + strokePx;
                DrawRectPx(canvas, p, startPx, top, endPx, bottom, FromDevicePx);
            }

            void DrawVertical(int startPx, int endPx, int centerXPx, int strokePx)
            {
                int left = centerXPx - (strokePx / 2);
                int right = left + strokePx;
                DrawRectPx(canvas, p, left, startPx, right, endPx, FromDevicePx);
            }

            void DrawRoundedCornerStroke(int cornerSeg, int strokePx)
            {
                int halfW = Math.Max(1, (x2px - x1px) / 2);
                int halfH = Math.Max(1, (y2px - y1px) / 2);
                int strokeSlack = Math.Max(1, strokePx / 2);

                // Half the smaller half-cell, so the straight runs still reach from the cell edge
                // most of the way to the midpoint the way the ─ and │ primitives do. A radius of a
                // whole half-cell turns the corner into a full-quadrant sweep that reads as a
                // diagonal chamfer with a stepped notch where the two borders should meet.
                int radiusCeiling = Math.Max(1, Math.Min(halfW, halfH) - strokeSlack);
                int radiusPx = Math.Clamp(Math.Min(halfW, halfH) / 2, 1, radiusCeiling);

                bool goesRight = (cornerSeg & SegRight) != 0;
                bool goesDown = (cornerSeg & SegDown) != 0;
                if (goesRight == ((cornerSeg & SegLeft) != 0)) return; // not one of the four arcs
                if (goesDown == ((cornerSeg & SegUp) != 0)) return;

                // The straight parts are the same grid-aligned fills the other box primitives use, so
                // an arc cell joins its neighbours seamlessly.
                if (goesRight) DrawHorizontal(xMidPx + radiusPx, x2px, yMidPx, strokePx);
                else DrawHorizontal(x1px, xMidPx - radiusPx, yMidPx, strokePx);

                if (goesDown) DrawVertical(yMidPx + radiusPx, y2px, xMidPx, strokePx);
                else DrawVertical(y1px, yMidPx - radiusPx, xMidPx, strokePx);

                // Centre of the stroke those fills produced: DrawHorizontal/DrawVertical span
                // [c - strokePx/2, c - strokePx/2 + strokePx), which is offset by half a pixel from
                // the midpoint for odd stroke widths. The arc has to ride the same centreline.
                float hCenterY = yMidPx - (strokePx / 2) + (strokePx / 2f);
                float vCenterX = xMidPx - (strokePx / 2) + (strokePx / 2f);
                float arcStartX = goesRight ? xMidPx + radiusPx : xMidPx - radiusPx;
                float arcEndY = goesDown ? yMidPx + radiusPx : yMidPx - radiusPx;

                using var roundedPaint = new SKPaint
                {
                    Color = color,
                    Style = SKPaintStyle.Stroke,
                    // The straight runs stay crisp because they are pixel fills; the curve is the one
                    // part that needs coverage blending, or a small-radius turn is a visible staircase.
                    IsAntialias = true,
                    StrokeWidth = FromDevicePxF(Math.Max(1, strokePx)),
                    StrokeCap = SKStrokeCap.Butt,
                    StrokeJoin = SKStrokeJoin.Round
                };

                using var path = new SKPath();
                path.MoveTo(FromDevicePxF(arcStartX), FromDevicePxF(hCenterY));
                // Control point on the corner vertex — where the two centrelines cross. Putting it on
                // the arc's centre instead bows the curve away from the corner and past the diagonal.
                path.QuadTo(
                    FromDevicePxF(vCenterX), FromDevicePxF(hCenterY),
                    FromDevicePxF(vCenterX), FromDevicePxF(arcEndY));

                canvas.Save();
                canvas.ClipRect(SKRect.Create(FromDevicePx(x1px), FromDevicePx(y1px), FromDevicePx(x2px - x1px), FromDevicePx(y2px - y1px)));
                canvas.DrawPath(path, roundedPaint);
                canvas.Restore();
            }

            if (isRoundedArc)
            {
                DrawRoundedCornerStroke(seg, thickPx);
                return true;
            }

            if (isDouble)
            {
                if ((seg & SegLeft) != 0 || (seg & SegRight) != 0)
                {
                    int yA = yMidPx - gapPx;
                    int yB = yMidPx + gapPx;
                    if ((seg & SegLeft) != 0) { DrawHorizontal(x1px, xMidPx, yA, thickPx); DrawHorizontal(x1px, xMidPx, yB, thickPx); }
                    if ((seg & SegRight) != 0) { DrawHorizontal(xMidPx, x2px, yA, thickPx); DrawHorizontal(xMidPx, x2px, yB, thickPx); }
                }

                if ((seg & SegUp) != 0 || (seg & SegDown) != 0)
                {
                    int xA = xMidPx - gapPx;
                    int xB = xMidPx + gapPx;
                    if ((seg & SegUp) != 0) { DrawVertical(y1px, yMidPx, xA, thickPx); DrawVertical(y1px, yMidPx, xB, thickPx); }
                    if ((seg & SegDown) != 0) { DrawVertical(yMidPx, y2px, xA, thickPx); DrawVertical(yMidPx, y2px, xB, thickPx); }
                }
            }
            else
            {
                if ((seg & SegLeft) != 0) DrawHorizontal(x1px, xMidPx, yMidPx, thickPx);
                if ((seg & SegRight) != 0) DrawHorizontal(xMidPx, x2px, yMidPx, thickPx);
                if ((seg & SegUp) != 0) DrawVertical(y1px, yMidPx, xMidPx, thickPx);
                if ((seg & SegDown) != 0) DrawVertical(yMidPx, y2px, xMidPx, thickPx);

                bool hasH = (seg & (SegLeft | SegRight)) != 0;
                bool hasV = (seg & (SegUp | SegDown)) != 0;
                if (hasH && hasV)
                {
                    int cx1 = xMidPx - (thickPx / 2);
                    int cy1 = yMidPx - (thickPx / 2);
                    DrawRectPx(canvas, p, cx1, cy1, cx1 + thickPx, cy1 + thickPx, FromDevicePx);
                }
            }

            return true;
        }

        private void DrawBrailleSubcells(SKCanvas canvas, byte mask, float x, float y, float w, float h, SKPaint paint)
        {
            if (mask == 0 || w <= 0 || h <= 0) return;

            float subW = w * 0.5f;
            float subH = h * 0.25f;
            float dotW = subW * 0.56f;
            float dotH = subH * 0.56f;

            // Braille bit mapping: 1/2/3/7 on left column, 4/5/6/8 on right column.
            DrawBrailleDotInSubcell(canvas, mask, bit: 0, col: 0, row: 0, x, y, subW, subH, dotW, dotH, paint);
            DrawBrailleDotInSubcell(canvas, mask, bit: 1, col: 0, row: 1, x, y, subW, subH, dotW, dotH, paint);
            DrawBrailleDotInSubcell(canvas, mask, bit: 2, col: 0, row: 2, x, y, subW, subH, dotW, dotH, paint);
            DrawBrailleDotInSubcell(canvas, mask, bit: 3, col: 1, row: 0, x, y, subW, subH, dotW, dotH, paint);
            DrawBrailleDotInSubcell(canvas, mask, bit: 4, col: 1, row: 1, x, y, subW, subH, dotW, dotH, paint);
            DrawBrailleDotInSubcell(canvas, mask, bit: 5, col: 1, row: 2, x, y, subW, subH, dotW, dotH, paint);
            DrawBrailleDotInSubcell(canvas, mask, bit: 6, col: 0, row: 3, x, y, subW, subH, dotW, dotH, paint);
            DrawBrailleDotInSubcell(canvas, mask, bit: 7, col: 1, row: 3, x, y, subW, subH, dotW, dotH, paint);
        }

        private void DrawBrailleDotInSubcell(
            SKCanvas canvas,
            byte mask,
            int bit,
            int col,
            int row,
            float x,
            float y,
            float subW,
            float subH,
            float dotW,
            float dotH,
            SKPaint paint)
        {
            if ((mask & (1 << bit)) == 0) return;

            float cx = x + ((col + 0.5f) * subW);
            float cy = y + ((row + 0.5f) * subH);
            float x1 = SnapX(cx - (dotW * 0.5f));
            float x2 = SnapX(cx + (dotW * 0.5f));
            float y1 = SnapY(cy - (dotH * 0.5f));
            float y2 = SnapY(cy + (dotH * 0.5f));
            if (x2 > x1 && y2 > y1)
            {
                canvas.DrawRect(x1, y1, x2 - x1, y2 - y1, paint);
            }
        }

        private static bool TryGetSingleRuneCodePoint(string grapheme, out int codePoint)
        {
            codePoint = 0;
            var enumerator = grapheme.EnumerateRunes().GetEnumerator();
            if (!enumerator.MoveNext()) return false;
            codePoint = enumerator.Current.Value;
            return !enumerator.MoveNext();
        }

        private static bool ContainsNonWhitespace(string text)
        {
            foreach (char ch in text)
            {
                if (!char.IsWhiteSpace(ch)) return true;
            }

            return false;
        }

        private sealed class SKTypefaceReferenceComparer : IEqualityComparer<SKTypeface>
        {
            public static readonly SKTypefaceReferenceComparer Instance = new();

            public bool Equals(SKTypeface? x, SKTypeface? y)
                => ReferenceEquals(x, y);

            public int GetHashCode(SKTypeface obj)
                => RuntimeHelpers.GetHashCode(obj);
        }

        /// <remarks>
        /// #234: this took the concatenated run text and enumerated it by rune, so its column
        /// arithmetic could disagree with <c>totalRunWidth</c> — which the caller sums from each
        /// *cell's* cluster width. A keycap cell measures 2 columns as a cluster but 1 as runes (the
        /// selector and the enclosing keycap are zero-width), so the underline came up short. Driving
        /// both from the same per-cell strings makes the two agree by construction.
        /// </remarks>
        private bool TryGetUnderlineBounds(List<string> runCellTexts, int runStartCol, float[] colEdges, float paddingLeft, out float x1, out float x2)
        {
            x1 = 0f;
            x2 = 0f;

            int cellOffset = 0;
            int startCellOffset = -1;
            int endCellOffsetExclusive = -1;

            foreach (string grapheme in new RunGraphemeEnumerator(runCellTexts))
            {
                int w = GetSafeGraphemeWidth(grapheme);
                if (w <= 0) continue;

                if (ContainsNonWhitespace(grapheme))
                {
                    if (startCellOffset < 0) startCellOffset = cellOffset;
                    endCellOffsetExclusive = cellOffset + w;
                }

                cellOffset += w;
            }

            if (startCellOffset < 0 || endCellOffsetExclusive <= startCellOffset)
            {
                return false;
            }

            x1 = GetColEdge(colEdges, runStartCol + startCellOffset, paddingLeft);
            x2 = GetColEdge(colEdges, runStartCol + endCellOffsetExclusive, paddingLeft);
            return x2 > x1;
        }

        private static SKColor BlendTowards(SKColor source, SKColor target, float t)
        {
            t = Math.Clamp(t, 0f, 1f);
            byte r = (byte)(source.Red + ((target.Red - source.Red) * t));
            byte g = (byte)(source.Green + ((target.Green - source.Green) * t));
            byte b = (byte)(source.Blue + ((target.Blue - source.Blue) * t));
            return new SKColor(r, g, b, source.Alpha);
        }

        /// <summary>
        /// The Minimum contrast setting: a foreground under the ratio against what it is drawn on
        /// moves in lightness, hue kept, until it reaches it. "What it is drawn on" is the cell's
        /// background, or for text redrawn over a selection or search match, that fill composited
        /// onto it. Applied before faint, so faint text stays dimmer than its neighbours.
        /// </summary>
        private SKColor EnforceMinimumContrast(SKColor fg, SKColor bg, SKColor? overlayFill = null)
        {
            if (_minimumContrast <= 1.0)
            {
                return fg;
            }

            var key = ((uint)fg, (uint)bg, overlayFill is { } o ? (uint)o : 0u);
            _contrastAdjusted ??= new Dictionary<(uint Fg, uint Bg, uint Overlay), SKColor>();
            if (_contrastAdjusted.TryGetValue(key, out var cached))
            {
                return cached;
            }

            var text = Color.FromArgb(0xFF, fg.Red, fg.Green, fg.Blue);
            var surface = Color.FromArgb(0xFF, bg.Red, bg.Green, bg.Blue);
            if (overlayFill is { } fill)
            {
                surface = ThemeColorMath.Composite(Color.FromArgb(fill.Alpha, fill.Red, fill.Green, fill.Blue), surface);
            }

            var adjusted = ThemeColorMath.Contrast(text, surface) >= _minimumContrast
                ? fg
                : WithSkAlpha(ReachContrast(text, surface, _minimumContrast), fg.Alpha);
            _contrastAdjusted[key] = adjusted;
            return adjusted;
        }

        /// <summary>
        /// The smallest lightness move, up or down, that reaches <paramref name="target"/>; if
        /// neither direction can, the direction that gets closest. Both are tried because a
        /// luma rule mis-sides saturated colors: on pure red, which it calls dark, lightening tops
        /// out at 4:1 while darkening reaches 5.25:1.
        /// </summary>
        private static Color ReachContrast(Color text, Color surface, double target)
        {
            Color best = text;
            double bestRatio = ThemeColorMath.Contrast(text, surface);
            for (int step = 1; step <= 100; step++)
            {
                double delta = step / 100.0;
                foreach (var candidate in new[] { ThemeColorMath.ShiftLightness(text, delta), ThemeColorMath.ShiftLightness(text, -delta) })
                {
                    double ratio = ThemeColorMath.Contrast(candidate, surface);
                    if (ratio >= target)
                    {
                        return candidate;
                    }

                    if (ratio > bestRatio)
                    {
                        best = candidate;
                        bestRatio = ratio;
                    }
                }
            }

            return best;
        }

        private static SKColor WithSkAlpha(Color color, byte alpha) => new(color.R, color.G, color.B, alpha);

        private static SKColor EnsureReadableForeground(SKColor fg, SKColor bg, SKColor fallback)
        {
            if (fg.Red != bg.Red || fg.Green != bg.Green || fg.Blue != bg.Blue) return fg;

            // If fg collides with bg, swap to theme fallback or its inverse contrast.
            if (fallback.Red != bg.Red || fallback.Green != bg.Green || fallback.Blue != bg.Blue)
            {
                return new SKColor(fallback.Red, fallback.Green, fallback.Blue, fg.Alpha);
            }

            int luminance = (299 * bg.Red + 587 * bg.Green + 114 * bg.Blue) / 1000;
            byte v = luminance > 127 ? (byte)0 : (byte)255;
            return new SKColor(v, v, v, fg.Alpha);
        }

        // Internal so the agent host's resolved-color projection resolves through the exact
        // same precedence as the draw path rather than a copy of it.
        internal static SKColor ResolveCellForeground(RenderCellSnapshot cell, SKColor themeFg, byte alpha, RenderThemeSnapshot themeSnapshot)
        {
            if (cell.IsDefaultForeground) return themeFg;
            if (cell.FgIndex >= 0)
            {
                var c = ResolvePaletteIndex(cell.FgIndex, themeSnapshot);
                return new SKColor(c.R, c.G, c.B, 255);
            }
            return new SKColor(cell.Foreground.R, cell.Foreground.G, cell.Foreground.B, 255);
        }

        /// <summary>
        /// The text color a cell presents before contrast, faint and override adjustment: its resolved
        /// foreground, or its resolved background under inverse video. The draw path and the agent
        /// host's underline projection both take it from here.
        /// </summary>
        internal static SKColor PresentedTextColor(RenderCellSnapshot cell, SKColor resolvedForeground, SKColor resolvedBackground)
            => cell.IsInverse ? resolvedBackground : resolvedForeground;

        /// <summary>Where a cell's underline color comes from at the theme-resolution stage.</summary>
        internal enum UnderlineColorSource { None, Inherit, Palette, Literal }

        /// <summary>One cell's underline color at the theme-resolution stage.</summary>
        internal readonly record struct UnderlineResolution(UnderlineColorSource Source, short PaletteIndex, bool InheritsBackground, SKColor Color);

        /// <summary>
        /// The underline color the draw path would stroke, resolved at the same stage as
        /// <see cref="ResolveCellForeground"/>: no underline draws nothing; an explicit SGR 58 color
        /// (palette index through the theme, else literal) is used as stored, untouched by inverse, faint,
        /// minimum contrast or the foreground override; otherwise the stroke keeps the run's text color
        /// (<see cref="PresentedTextColor"/>). The theme defaults are the presented ones, so DECSCNM is
        /// already folded in. Shared with the agent host so the projection cannot drift from the draw path.
        /// </summary>
        internal static UnderlineResolution ResolveCellUnderline(RenderCellSnapshot cell, SKColor themeFg, SKColor themeBg, RenderThemeSnapshot themeSnapshot)
        {
            if (!cell.IsUnderline) return new UnderlineResolution(UnderlineColorSource.None, -1, false, default);
            if (cell.Underline is { HasColor: true } underline)
            {
                var color = ResolveUnderlineColor(underline, themeSnapshot);
                return underline.ColorIndex >= 0
                    ? new UnderlineResolution(UnderlineColorSource.Palette, underline.ColorIndex, false, color)
                    : new UnderlineResolution(UnderlineColorSource.Literal, -1, false, color);
            }
            var text = PresentedTextColor(cell, ResolveCellForeground(cell, themeFg, 255, themeSnapshot), ResolveCellBackground(cell, themeBg, 255, themeSnapshot));
            return new UnderlineResolution(UnderlineColorSource.Inherit, -1, cell.IsInverse, text);
        }

        /// <summary>The SGR 58 underline color (#270): a palette index through the theme, as the foreground's is, or RGB.</summary>
        internal static SKColor ResolveUnderlineColor(CellUnderline underline, RenderThemeSnapshot themeSnapshot)
        {
            TermColor c = underline.ColorIndex >= 0
                ? ResolvePaletteIndex(underline.ColorIndex, themeSnapshot)
                : underline.Color!.Value;
            return new SKColor(c.R, c.G, c.B, 255);
        }

        /// <summary>
        /// One run's underline in its style (#270), from <paramref name="x1"/> to <paramref name="x2"/> on
        /// <paramref name="y"/>, kept above <paramref name="rowBottom"/>. Strokes with <see cref="_decoStrokePaint"/>
        /// as set up by the caller, and leaves it as it found it.
        /// </summary>
        private void DrawUnderline(SKCanvas canvas, UnderlineStyle style, float x1, float x2, float y, float rowBottom, float stroke)
        {
            switch (style)
            {
                case UnderlineStyle.Double:
                    {
                        // Two lines with a stroke's gap between them, the lower one kept inside the cell.
                        float lower = Math.Min(y + stroke, rowBottom - (stroke / 2));
                        float upper = lower - (2 * stroke);
                        canvas.DrawLine(x1, upper, x2, upper, _decoStrokePaint);
                        canvas.DrawLine(x1, lower, x2, lower, _decoStrokePaint);
                        break;
                    }

                case UnderlineStyle.Curly:
                    DrawCurlyUnderline(canvas, x1, x2, y, rowBottom, stroke);
                    break;

                case UnderlineStyle.Dotted:
                case UnderlineStyle.Dashed:
                    {
                        float on = style == UnderlineStyle.Dotted ? stroke : stroke * 3;
                        float off = style == UnderlineStyle.Dotted ? stroke : stroke * 2;
                        // Phased by the absolute x, so the pattern runs on unbroken from one run into the next.
                        using SKPathEffect dash = SKPathEffect.CreateDash([on, off], x1 % (on + off));
                        _decoStrokePaint.PathEffect = dash;
                        canvas.DrawLine(x1, y, x2, y, _decoStrokePaint);
                        _decoStrokePaint.PathEffect = null;
                        break;
                    }

                default:
                    canvas.DrawLine(x1, y, x2, y, _decoStrokePaint);
                    break;
            }
        }

        /// <summary>
        /// A wave of one period per cell, a stroke either side of <paramref name="y"/>; raised when its trough
        /// would leave the cell.
        /// </summary>
        private void DrawCurlyUnderline(SKCanvas canvas, float x1, float x2, float y, float rowBottom, float stroke)
        {
            float amplitude = stroke;
            float center = Math.Min(y, rowBottom - amplitude - (stroke / 2));
            float halfPeriod = FromDevicePx(_pixelGrid.CellWidthPx) / 2;
            if (halfPeriod <= 0 || x2 <= x1) return;

            using var path = new SKPath();
            path.MoveTo(x1, center);
            float x = x1;
            bool crest = true;
            while (x < x2)
            {
                float next = Math.Min(x + halfPeriod, x2);
                // A quadratic's peak sits halfway to its control point, so the control is two amplitudes out.
                float reach = 2 * amplitude * ((next - x) / halfPeriod);
                path.QuadTo((x + next) / 2, crest ? center - reach : center + reach, next, center);
                x = next;
                crest = !crest;
            }

            canvas.DrawPath(path, _decoStrokePaint);
        }

        // Internal for the same reason as ResolveCellForeground: one resolution precedence.
        internal static SKColor ResolveCellBackground(RenderCellSnapshot cell, SKColor themeBg, byte alpha, RenderThemeSnapshot themeSnapshot)
        {
            if (cell.IsDefaultBackground) return themeBg;

            SKColor resolved;
            if (cell.BgIndex >= 0)
            {
                var c = ResolvePaletteIndex(cell.BgIndex, themeSnapshot);
                resolved = new SKColor(c.R, c.G, c.B, 255);
            }
            else
            {
                resolved = new SKColor(cell.Background.R, cell.Background.G, cell.Background.B, 255);
            }

            // Under window transparency (alpha < 255), an explicit background whose color is
            // identical to the theme background must stay just as transparent as a default-background
            // cell. Remote programs routinely paint the default color explicitly — e.g. SGR 40 on a
            // dark theme where Background == ANSI black, or an erase-line/-screen issued while a
            // default-equal background is active. Returning the alpha-baked themeBg here (instead of
            // an opaque copy) lets the existing `bg != themeBg` draw guard skip the fill, so these
            // cells show the see-through theme layer rather than an opaque island. This is the
            // "solid block at the top of a fresh SSH session" bug.
            if (alpha != 255 &&
                resolved.Red == themeBg.Red &&
                resolved.Green == themeBg.Green &&
                resolved.Blue == themeBg.Blue)
            {
                return themeBg;
            }

            return resolved;
        }

        /// <summary>The theme the render colors derive from when a snapshot carries none (hand-built snapshots).</summary>
        private static readonly TerminalTheme UnthemedSnapshotTheme = new();

        private static SKColor ToSkColor(Avalonia.Media.Color color) => new(color.R, color.G, color.B, color.A);

        private static TermColor ResolvePaletteIndex(int index, RenderThemeSnapshot themeSnapshot)
        {
            if (themeSnapshot.AnsiPalette != null && (uint)index < (uint)themeSnapshot.AnsiPalette.Length)
                return themeSnapshot.AnsiPalette[index];
            // Legacy/hand-built snapshots may carry only sixteen palette entries.
            if (index < 16) return themeSnapshot.Foreground;

            // 16-231: xterm 6x6x6 cube.
            if (index < 232)
            {
                index -= 16;
                int r = index / 36;
                int g = (index / 6) % 6;
                int b = index % 6;

                static byte ToByte(int v) => (byte)(v == 0 ? 0 : (v * 40 + 55));
                return TermColor.FromRgb(ToByte(r), ToByte(g), ToByte(b));
            }

            // 232-255: xterm grayscale ramp.
            if (index < 256)
            {
                index -= 232;
                byte v = (byte)(index * 10 + 8);
                return TermColor.FromRgb(v, v, v);
            }

            return themeSnapshot.Foreground;
        }
    }
}
